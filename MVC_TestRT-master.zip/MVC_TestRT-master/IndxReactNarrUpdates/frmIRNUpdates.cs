﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace IndxReactNarrUpdates
{
    public partial class frmIRNUpdates : Form
    {
        private IList<PatchFile> PatchFiles
        {
            get;
            set;
        }

        public frmIRNUpdates()
        {
            InitializeComponent();
        }

        public frmIRNUpdates(IList<PatchFile> patchFiles) : this()
        {
            this.PatchFiles = patchFiles;
        }

        private void frmIRNUpdates_Load(object sender, EventArgs e)
        {
            try
            {
                RunPatchUpdates();

                this.Close();
            }
            catch (Exception)
            {                
                throw;
            }
        }

        private void RunPatchUpdates()
        {
            CheckForIllegalCrossThreadCalls = false;

            this.Refresh();

            this.Visible = true;
            this.Cursor = Cursors.WaitCursor;

            try
            {
                if (this.PatchFiles != null && this.PatchFiles.Count > 0)
                {
                    lblPatchUpdateStatus.Text = "Found new updates ...";
                    Application.DoEvents();

                    System.Threading.Thread.Sleep(500);

                    lblDownloadStatus.Text = "Downloading files ...";
                    Application.DoEvents();

                    AppPatchUpdates.Download(this.PatchFiles);

                    lblDownloadStatus.Text = "Download completed.";
                    Application.DoEvents();
                    System.Threading.Thread.Sleep(200);
                }
            }
            catch (Exception ex)
            {
                AppPatchUpdates.WriteErrorLog(ex.ToString());
                lblPatchUpdateStatus.Text = "Failed to download patch files.";
                lblPatchUpdateStatus.Refresh();
                Thread.Sleep(500);
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }
    }
}
