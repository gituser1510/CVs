﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace IndxReactNarrUpdates
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
           
            try
            {
                GetPatchUpdateFiles();
            }
            catch (Exception ex)
            {
                AppPatchUpdates.WriteErrorLog(ex.ToString());
            }
        }

        private static void GetPatchUpdateFiles()
        {
            int setupNumber = 3;
            int patchNumber = 1;
            int maxBuildNumber = 1;
            IList<PatchFile> patchFiles = null;

            // Copy Config.xml file to application path.
            AppPatchUpdates.DownloadConfigFile();
            AppPatchUpdates.GetPatchReleaseInfo(out setupNumber, out patchNumber);

            try
            {
                patchFiles = AppPatchUpdates.GetPublishedFiles(setupNumber, patchNumber, out maxBuildNumber);
            }
            catch (Exception ex)
            {
                AppPatchUpdates.WriteErrorLog(ex.ToString());
            }

            if (patchFiles != null && patchFiles.Count > 0)
            {
                frmIRNUpdates irnUpdates = new frmIRNUpdates(patchFiles);
                irnUpdates.Show();

                AppPatchUpdates.UpdatePatchReleaseInfo(setupNumber, maxBuildNumber);
            }

            //Start IRN application
            StartMainApplication();
        }

        /// <summary>
        /// To Start main application - IRN.exe
        /// </summary>
        private static void StartMainApplication()
        {           
            try
            {
                string mainAppPath = Path.Combine(Application.StartupPath, "IRN.exe");
                Process.Start(mainAppPath);              
            }
            catch (Exception ex)
            {
                AppPatchUpdates.WriteErrorLog(ex.ToString());
            }
        }
    }
}
