﻿namespace IndxReactNarrUpdates
{
    partial class frmIRNUpdates
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMain = new System.Windows.Forms.Panel();
            this.lblDownloadStatus = new System.Windows.Forms.Label();
            this.lblPatchUpdateStatus = new System.Windows.Forms.Label();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.Gainsboro;
            this.pnlMain.BackgroundImage = global::IndxReactNarrUpdates.Properties.Resources.path_updates_screen;
            this.pnlMain.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pnlMain.Controls.Add(this.lblDownloadStatus);
            this.pnlMain.Controls.Add(this.lblPatchUpdateStatus);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(386, 257);
            this.pnlMain.TabIndex = 0;
            // 
            // lblDownloadStatus
            // 
            this.lblDownloadStatus.AutoSize = true;
            this.lblDownloadStatus.BackColor = System.Drawing.Color.Transparent;
            this.lblDownloadStatus.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDownloadStatus.ForeColor = System.Drawing.Color.Navy;
            this.lblDownloadStatus.Location = new System.Drawing.Point(32, 146);
            this.lblDownloadStatus.Name = "lblDownloadStatus";
            this.lblDownloadStatus.Size = new System.Drawing.Size(51, 19);
            this.lblDownloadStatus.TabIndex = 2;
            this.lblDownloadStatus.Text = "-------";
            // 
            // lblPatchUpdateStatus
            // 
            this.lblPatchUpdateStatus.AutoSize = true;
            this.lblPatchUpdateStatus.BackColor = System.Drawing.Color.Transparent;
            this.lblPatchUpdateStatus.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPatchUpdateStatus.ForeColor = System.Drawing.Color.Navy;
            this.lblPatchUpdateStatus.Location = new System.Drawing.Point(32, 113);
            this.lblPatchUpdateStatus.Name = "lblPatchUpdateStatus";
            this.lblPatchUpdateStatus.Size = new System.Drawing.Size(154, 19);
            this.lblPatchUpdateStatus.TabIndex = 1;
            this.lblPatchUpdateStatus.Text = "Checking for updates ...";
            // 
            // frmIRNUpdates
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(386, 257);
            this.Controls.Add(this.pnlMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmIRNUpdates";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frmIRNUpdates_Load);
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Label lblPatchUpdateStatus;
        private System.Windows.Forms.Label lblDownloadStatus;
    }
}

