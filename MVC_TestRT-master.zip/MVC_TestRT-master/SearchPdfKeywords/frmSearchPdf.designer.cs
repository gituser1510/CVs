﻿namespace SearchPdfKeywords
{
    partial class frmSearchPdf
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSrch_pdf = new System.Windows.Forms.TextBox();
            this.btnPdf = new System.Windows.Forms.Button();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvResluts = new System.Windows.Forms.DataGridView();
            this.colTAN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colKeys_Found = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.pnlNewKey = new System.Windows.Forms.Panel();
            this.rbnDelKey = new System.Windows.Forms.RadioButton();
            this.rbnAddKey = new System.Windows.Forms.RadioButton();
            this.btnAdd_DelKey = new System.Windows.Forms.Button();
            this.txtNewKey = new System.Windows.Forms.TextBox();
            this.dgvKeyWords = new System.Windows.Forms.DataGridView();
            this.colKeyWord = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSaveInDB = new System.Windows.Forms.Button();
            this.btnExport = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblFolder = new System.Windows.Forms.Label();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResluts)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.pnlNewKey.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKeyWords)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSearch
            // 
            this.btnSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSearch.Location = new System.Drawing.Point(1047, 33);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 27);
            this.btnSearch.TabIndex = 0;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtSrch_pdf
            // 
            this.txtSrch_pdf.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSrch_pdf.BackColor = System.Drawing.Color.White;
            this.txtSrch_pdf.Location = new System.Drawing.Point(103, 4);
            this.txtSrch_pdf.Name = "txtSrch_pdf";
            this.txtSrch_pdf.ReadOnly = true;
            this.txtSrch_pdf.Size = new System.Drawing.Size(926, 25);
            this.txtSrch_pdf.TabIndex = 1;
            // 
            // btnPdf
            // 
            this.btnPdf.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPdf.Location = new System.Drawing.Point(1047, 2);
            this.btnPdf.Name = "btnPdf";
            this.btnPdf.Size = new System.Drawing.Size(75, 27);
            this.btnPdf.TabIndex = 4;
            this.btnPdf.Text = "Browse";
            this.btnPdf.UseVisualStyleBackColor = true;
            this.btnPdf.Click += new System.EventHandler(this.btnPdf_Click);
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.dgvResluts);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1136, 589);
            this.pnlMain.TabIndex = 6;
            // 
            // dgvResluts
            // 
            this.dgvResluts.AllowUserToAddRows = false;
            this.dgvResluts.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.dgvResluts.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvResluts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvResluts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResluts.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTAN,
            this.colKeys_Found});
            this.dgvResluts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvResluts.Location = new System.Drawing.Point(0, 268);
            this.dgvResluts.Name = "dgvResluts";
            this.dgvResluts.ReadOnly = true;
            this.dgvResluts.Size = new System.Drawing.Size(1136, 321);
            this.dgvResluts.TabIndex = 9;
            this.dgvResluts.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvResluts_RowPostPaint);
            // 
            // colTAN
            // 
            this.colTAN.HeaderText = "TAN";
            this.colTAN.Name = "colTAN";
            this.colTAN.ReadOnly = true;
            this.colTAN.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colKeys_Found
            // 
            this.colKeys_Found.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colKeys_Found.HeaderText = "KeyWords Found";
            this.colKeys_Found.Name = "colKeys_Found";
            this.colKeys_Found.ReadOnly = true;
            this.colKeys_Found.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.White;
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlTop.Controls.Add(this.pnlNewKey);
            this.pnlTop.Controls.Add(this.dgvKeyWords);
            this.pnlTop.Controls.Add(this.btnSaveInDB);
            this.pnlTop.Controls.Add(this.btnExport);
            this.pnlTop.Controls.Add(this.label1);
            this.pnlTop.Controls.Add(this.btnSearch);
            this.pnlTop.Controls.Add(this.lblFolder);
            this.pnlTop.Controls.Add(this.txtSrch_pdf);
            this.pnlTop.Controls.Add(this.btnPdf);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1136, 268);
            this.pnlTop.TabIndex = 8;
            // 
            // pnlNewKey
            // 
            this.pnlNewKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlNewKey.Controls.Add(this.rbnDelKey);
            this.pnlNewKey.Controls.Add(this.rbnAddKey);
            this.pnlNewKey.Controls.Add(this.btnAdd_DelKey);
            this.pnlNewKey.Controls.Add(this.txtNewKey);
            this.pnlNewKey.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlNewKey.Location = new System.Drawing.Point(0, 230);
            this.pnlNewKey.Name = "pnlNewKey";
            this.pnlNewKey.Size = new System.Drawing.Size(1132, 34);
            this.pnlNewKey.TabIndex = 12;
            // 
            // rbnDelKey
            // 
            this.rbnDelKey.AutoSize = true;
            this.rbnDelKey.Location = new System.Drawing.Point(97, 5);
            this.rbnDelKey.Name = "rbnDelKey";
            this.rbnDelKey.Size = new System.Drawing.Size(94, 21);
            this.rbnDelKey.TabIndex = 5;
            this.rbnDelKey.TabStop = true;
            this.rbnDelKey.Text = "Delete Key";
            this.rbnDelKey.UseVisualStyleBackColor = true;
            // 
            // rbnAddKey
            // 
            this.rbnAddKey.AutoSize = true;
            this.rbnAddKey.Location = new System.Drawing.Point(7, 5);
            this.rbnAddKey.Name = "rbnAddKey";
            this.rbnAddKey.Size = new System.Drawing.Size(80, 21);
            this.rbnAddKey.TabIndex = 4;
            this.rbnAddKey.TabStop = true;
            this.rbnAddKey.Text = "Add Key";
            this.rbnAddKey.UseVisualStyleBackColor = true;
            // 
            // btnAdd_DelKey
            // 
            this.btnAdd_DelKey.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAdd_DelKey.Location = new System.Drawing.Point(1046, 2);
            this.btnAdd_DelKey.Name = "btnAdd_DelKey";
            this.btnAdd_DelKey.Size = new System.Drawing.Size(75, 27);
            this.btnAdd_DelKey.TabIndex = 3;
            this.btnAdd_DelKey.Text = "Save";
            this.btnAdd_DelKey.UseVisualStyleBackColor = true;
            this.btnAdd_DelKey.Click += new System.EventHandler(this.btnNewKey_Click);
            // 
            // txtNewKey
            // 
            this.txtNewKey.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNewKey.BackColor = System.Drawing.Color.White;
            this.txtNewKey.Location = new System.Drawing.Point(197, 3);
            this.txtNewKey.Name = "txtNewKey";
            this.txtNewKey.Size = new System.Drawing.Size(831, 25);
            this.txtNewKey.TabIndex = 2;
            // 
            // dgvKeyWords
            // 
            this.dgvKeyWords.AllowUserToAddRows = false;
            this.dgvKeyWords.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Info;
            this.dgvKeyWords.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvKeyWords.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvKeyWords.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvKeyWords.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKeyWords.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colKeyWord});
            this.dgvKeyWords.Location = new System.Drawing.Point(103, 33);
            this.dgvKeyWords.Name = "dgvKeyWords";
            this.dgvKeyWords.ReadOnly = true;
            this.dgvKeyWords.Size = new System.Drawing.Size(926, 195);
            this.dgvKeyWords.TabIndex = 11;
            this.dgvKeyWords.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvKeyWords_RowPostPaint);
            // 
            // colKeyWord
            // 
            this.colKeyWord.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colKeyWord.HeaderText = "KeyWord";
            this.colKeyWord.Name = "colKeyWord";
            this.colKeyWord.ReadOnly = true;
            // 
            // btnSaveInDB
            // 
            this.btnSaveInDB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSaveInDB.Location = new System.Drawing.Point(1047, 200);
            this.btnSaveInDB.Name = "btnSaveInDB";
            this.btnSaveInDB.Size = new System.Drawing.Size(75, 27);
            this.btnSaveInDB.TabIndex = 10;
            this.btnSaveInDB.Text = "Save";
            this.btnSaveInDB.UseVisualStyleBackColor = true;
            this.btnSaveInDB.Click += new System.EventHandler(this.btnSaveInDB_Click);
            // 
            // btnExport
            // 
            this.btnExport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExport.Location = new System.Drawing.Point(1047, 167);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(75, 27);
            this.btnExport.TabIndex = 9;
            this.btnExport.Text = "Export";
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "Keys to Search";
            // 
            // lblFolder
            // 
            this.lblFolder.AutoSize = true;
            this.lblFolder.Location = new System.Drawing.Point(17, 8);
            this.lblFolder.Name = "lblFolder";
            this.lblFolder.Size = new System.Drawing.Size(85, 17);
            this.lblFolder.TabIndex = 6;
            this.lblFolder.Text = "Select Folder";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // frmSearchPdf
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1136, 589);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmSearchPdf";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Search Pdf - Keywords";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmSearchPdf_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResluts)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlNewKey.ResumeLayout(false);
            this.pnlNewKey.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKeyWords)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtSrch_pdf;
        private System.Windows.Forms.Button btnPdf;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Label lblFolder;
        private System.Windows.Forms.DataGridView dgvResluts;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTAN;
        private System.Windows.Forms.DataGridViewTextBoxColumn colKeys_Found;
        private System.Windows.Forms.Button btnSaveInDB;
        private System.Windows.Forms.DataGridView dgvKeyWords;
        private System.Windows.Forms.DataGridViewTextBoxColumn colKeyWord;
        private System.Windows.Forms.Panel pnlNewKey;
        private System.Windows.Forms.Button btnAdd_DelKey;
        private System.Windows.Forms.TextBox txtNewKey;
        private System.Windows.Forms.RadioButton rbnDelKey;
        private System.Windows.Forms.RadioButton rbnAddKey;
    }
}

