﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using org.pdfbox.pdmodel;
using org.pdfbox.util;
using System.IO;
using System.Collections;
using MSExcel = Microsoft.Office.Interop.Excel;


namespace SearchPdfKeywords
{
    public partial class frmSearchPdf : Form
    {
        public frmSearchPdf()
        {
            InitializeComponent();
        }

        DataTable KeyWordsData = null;
        DataTable dtResults = null;
        public string ApplicationName = "";

        private void frmSearchPdf_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;

                GetDictionaryKeywordsAndBindToGrid();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {                
                if (!string.IsNullOrEmpty(txtSrch_pdf.Text.Trim()))
                {
                    Cursor = Cursors.WaitCursor;

                     DirectoryInfo dirInfo = new DirectoryInfo(txtSrch_pdf.Text);
                     if (dirInfo != null)
                     {
                         List<FileInfo> lstPdfFiles = dirInfo.GetFiles("*.pdf").ToList();
                     }

                    ArrayList lstPdfs = GetPdfFilesFromFolder(txtSrch_pdf.Text);
                    DataTable dtKeyVals = (DataTable)dgvKeyWords.DataSource;//GetKeyWords();

                    if (lstPdfs != null && dtKeyVals != null)
                    {
                        if (lstPdfs.Count > 0)
                        {
                            dtResults = new DataTable();
                            dtResults.Columns.Add("TAN");
                            dtResults.Columns.Add("KeysFound");

                            DataRow dRow = null;

                            PDDocument _pdfdoc = null;
                            PDFTextStripper _txtstripper = null;
                            string fileDtls = "";
                            string strKeys = "";

                            dgvResluts.AutoGenerateColumns = false;
                            dgvResluts.DataSource = dtResults;
                            dgvResluts.Columns[0].DataPropertyName = "TAN";
                            dgvResluts.Columns[1].DataPropertyName = "KeysFound";

                            string strTAN = "";

                            _txtstripper = new PDFTextStripper();
                            _pdfdoc = new PDDocument();
                            for (int i = 0; i < lstPdfs.Count; i++)
                            {
                                dRow = dtResults.NewRow();

                                strTAN = "";
                                strTAN = Path.GetFileName(lstPdfs[i].ToString().Replace(".pdf", ""));
                                strTAN = strTAN.Replace(".patent.fulltext.000001", "");
                                strTAN = strTAN.Replace(".PDF", "");
                                dRow["TAN"] = strTAN;

                                strKeys = "";

                                try
                                {
                                    _txtstripper.resetEngine();
                                    _pdfdoc = PDDocument.load(lstPdfs[i].ToString());
                                    //_txtstripper = new PDFTextStripper();                                   

                                    try
                                    {
                                        fileDtls = _txtstripper.getText(_pdfdoc).ToUpper();

                                        if (fileDtls != "")
                                        {
                                            for (int kindx = 0; kindx < dtKeyVals.Rows.Count; kindx++)
                                            {
                                                if (fileDtls.Contains(dtKeyVals.Rows[kindx]["keyword"].ToString().Trim().ToUpper()))
                                                {
                                                    if (strKeys.Trim() == "")
                                                    {
                                                        strKeys = dtKeyVals.Rows[kindx]["keyword"].ToString().Trim();
                                                    }
                                                    else
                                                    {
                                                        strKeys = strKeys + ", " + dtKeyVals.Rows[kindx]["keyword"].ToString().Trim();
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    catch
                                    {

                                    }

                                    _pdfdoc.close();

                                    dRow["KeysFound"] = strKeys;
                                    dtResults.Rows.Add(dRow);

                                    Application.DoEvents();
                                }
                                catch
                                {

                                }
                            }
                        }
                    }
                    Cursor = Cursors.Default;
                }         
            }
            catch (Exception ex)
            {
                throw ex;
            }              
        }

        private ArrayList GetPdfFilesFromFolder(string _folderpath)
        {
            ArrayList alstPdfs = null;
            try
            {
                if (!string.IsNullOrEmpty(_folderpath.Trim()))
                {
                    DirectoryInfo dirInfo = new DirectoryInfo(_folderpath);
                    if (dirInfo != null)
                    {
                       FileInfo[] objFInfo = dirInfo.GetFiles("*.pdf");
                       if (objFInfo != null)
                       {
                           if (objFInfo.Length > 0)
                           {
                               alstPdfs = new ArrayList();
                               foreach (FileInfo _file in objFInfo)
                               {
                                   alstPdfs.Add(_file.FullName);
                               }
                           }
                       }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return alstPdfs;
        }       

        private void btnPdf_Click(object sender, EventArgs e)
        {
            try
            {
                if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
                {
                    txtSrch_pdf.Text = folderBrowserDialog1.SelectedPath;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        private void dgvResluts_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvResluts.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvResluts.Font);

                if (dgvResluts.RowHeadersWidth < (int)(size.Width + 20)) dgvResluts.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }        

        private bool ExportToExcelFromDataTable(string filename, System.Data.DataTable dtresult)
        {
            bool blStatus = false;
            try
            {
                // Create an Excel object and add workbook...
                MSExcel.Application excel = new MSExcel.Application();
                MSExcel.Workbook workbook = excel.Application.Workbooks.Add(true); // true for object template???

                // Add column headings...
                int iCol = 0;
                foreach (DataColumn c in dtresult.Columns)
                {
                    iCol++;
                    excel.Cells[1, iCol] = c.ColumnName;
                }
                // for each row of data...
                int iRow = 0;
                foreach (DataRow r in dtresult.Rows)
                {
                    iRow++;

                    // add each row's cell data...
                    iCol = 0;
                    foreach (DataColumn c in dtresult.Columns)
                    {
                        iCol++;
                        excel.Cells[iRow + 1, iCol] = r[c.ColumnName];
                    }
                }

                // Global missing reference for objects we are not defining...
                object missing = System.Reflection.Missing.Value;

                // If wanting to Save the workbook...
                workbook.SaveAs(filename, MSExcel.XlFileFormat.xlXMLSpreadsheet, missing, missing, false, false, MSExcel.XlSaveAsAccessMode.xlNoChange,
                                missing, missing, missing, missing, missing);

                // If wanting to make Excel visible and activate the worksheet...
                excel.Visible = true;
                MSExcel.Worksheet worksheet = (MSExcel.Worksheet)excel.ActiveSheet;
                ((MSExcel._Worksheet)worksheet).Activate();

                // If wanting excel to shutdown...
                ((MSExcel._Application)excel).Quit();
                blStatus = true;
                return blStatus;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return blStatus;
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtResults != null)
                {
                    if (dtResults.Rows.Count > 0)
                    {
                        SaveFileDialog _sDialog = new SaveFileDialog();
                        _sDialog.Filter = "XlS|*.xls";

                        if (_sDialog.ShowDialog() == DialogResult.OK)
                        {
                            if (ExportToExcelFromDataTable(_sDialog.FileName, dtResults))
                            {
                                MessageBox.Show("Exported to excel successfully", "Search Pdf",MessageBoxButtons.OK,MessageBoxIcon.Information);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void btnSaveInDB_Click(object sender, EventArgs e)
        {
            try
            {
                if(dgvResluts.DataSource != null)
                {
                    DataTable dtKeys = (DataTable)dgvResluts.DataSource;
                    if (dtKeys != null)
                    {
                        if (dtKeys.Rows.Count > 0)
                        { 
                            List<string> lstTANs = new List<string>();
                            List<string> lstKeywords = new List<string>();

                            lstTANs = dtKeys.AsEnumerable().Select(r => r.Field<string>("TAN")).ToList();
                            lstKeywords = dtKeys.AsEnumerable().Select(r => r.Field<string>("KeysFound")).ToList();

                            if (OrganicIndexingDB.UpdateTANKeyWords(ApplicationName, "", lstTANs, lstKeywords))
                            {
                                MessageBox.Show("TAN - Keywords saved successfully", "Search Pdf-Keywords", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else
                            {
                                MessageBox.Show("Error in saving TAN keywords", "Search Pdf-Keywords", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }                                            
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void GetDictionaryKeywordsAndBindToGrid()
        {
            try
            {
                KeyWordsData = null;// ReactDB.GetDictionaryTermsOnType("PDF_KEYWORD");
                if (KeyWordsData != null)
                {
                    dgvKeyWords.AutoGenerateColumns = false;
                    dgvKeyWords.DataSource = KeyWordsData;
                    colKeyWord.DataPropertyName = "FREE_TEXT";                   
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        private void dgvKeyWords_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvKeyWords.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvKeyWords.Font);

                if (dgvKeyWords.RowHeadersWidth < (int)(size.Width + 20)) dgvKeyWords.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
                
        private void btnNewKey_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtNewKey.Text.Trim()))
                {
                    string strOpt = rbnAddKey.Checked ? "INSERT" : "DELETE";                   
                   
                    //if (DAL.CASRxnDataAccess.Insert_Delete_KeyWord(txtNewKey.Text.Trim(), strOpt))
                    //{
                    //    MessageBox.Show(strOpt + " operation done successfully", "Keywords", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //    GetDictionaryKeywordsAndBindToGrid();
                    //}
                    //else
                    //{
                    //    MessageBox.Show(strOpt + " failed","Keywords",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    //}
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
       
    }
}
