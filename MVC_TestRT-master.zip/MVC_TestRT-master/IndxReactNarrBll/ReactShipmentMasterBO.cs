﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBll
{
    public class ReactShipmentMasterBO
    {
        public string ShipmentName { get; set; }
        public string Application { get; set; }

        public string TAN { get; set; }
        public string CAN { get; set; }
        public string TANType { get; set; }
        public string JournalName { get; set; }
        public string IssueName { get; set; }
        public string JournalYear { get; set; }

        public string[] NUM { get; set; }
        public string[] REG_NO { get; set; }
        public string[] Formula { get; set; }
        public string[] IUPACName { get; set; }
        public string[] OtherNames { get; set; }
        public string[] PeptideSeq { get; set; }
        public string[] NuclicAcidSeq { get; set; }
        public string[] MolHexCode { get; set; }
        public string[] AbsStereo { get; set; }

        public int UR_ID { get; set; }
    }
}
