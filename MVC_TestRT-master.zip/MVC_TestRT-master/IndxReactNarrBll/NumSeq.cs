﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace IndxReactNarrBll
{
    public class NumSeq
    {
        public int Num { get; set; }
        public int Seq { get; set; }

    }
}
