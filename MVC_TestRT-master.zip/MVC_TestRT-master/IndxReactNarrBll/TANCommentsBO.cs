﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBll
{
    public class TANCommentsBO
    {
        public int TAN_ID { get; set; }
        public List<string> TC_IDs { get; set; }
        public List<string> TAN_Comments { get; set; }
        public List<string> Comments_Type { get; set; }
        public int UR_ID { get; set; }
    }
}
