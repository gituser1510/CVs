﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBll
{
    public class ManageSeries8000
    {
        public int TS_ID { get; set; }
        public int TAN_ID { get; set; }
        public int Ser8000Val { get; set; }
        public string SubstName { get; set; }
        public string SubstLocation { get; set; }
        public string SubstAuthorName { get; set; }
        public string SubstOtherName { get; set; }
        public object SubstMolecule { get; set; }
        public string Option { get; set; }
        public int CreatedBy { get; set; }
    }
}
