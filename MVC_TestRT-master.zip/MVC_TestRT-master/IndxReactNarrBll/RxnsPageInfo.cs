﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBll
{
    public class RxnsPageInfo
    {
        public List<Int32> RxnIDs
        {
            get;
            set;
        }

        public List<Int32> PageNos
        {
            get;
            set;
        }

        public List<String> PageLabels
        {
            get;
            set;
        }        
    }
}
