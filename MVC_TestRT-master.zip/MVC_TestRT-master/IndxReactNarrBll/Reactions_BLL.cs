﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text; 
#endregion

namespace IndxReactNarrBLL
{
   public class ReactionsBLL
    {
        #region Public Variables

        public int ID
        { get; set; }

        public int Patent_ID
        { get; set; } 
       
        public int RXNNUM
        { get; set; }

        public int RXNSEQ
        { get; set; }

        public int UserID
        { get; set; }

        public string UserRole
        { get; set; }

        #endregion
    }
}
