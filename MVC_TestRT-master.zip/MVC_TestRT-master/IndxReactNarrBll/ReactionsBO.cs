﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text; 
#endregion

namespace IndxReactNarrBLL
{
   public class ReactionsBO
    {
        #region Public Variables

        public int RXN_ID
        { get; set; }

        public int TAN_ID
        { get; set; } 
       
        public int RXN_NUM
        { get; set; }

        public int RXN_SEQ
        { get; set; }

        public int UserID
        { get; set; }

        public string UserRole
        { get; set; }
          
        public int UR_ID
        { get; set; }

        #endregion
    }
}
