﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IndxReactNarrBll
{
   public class ExpProcedures
    {
        public String TAN
        {
            get;
            set;
        }

        public String CAN
        {
            get;
            set;
        }

        public String DOI
        {
            get;
            set;
        }   
     
        public String CODEN
        {
            get;
            set;
        }

        public int DocSeq
        {
            get;
            set;
        }

        public String Publisher_Family
        {
            get;
            set;
        }

        public String Doc_Type
        {
            get;
            set;
        }

        public List<String> RXN_NUM
        {
            get;
            set;
        }

        public List<String> RXN_Seq
        {
            get;
            set;
        }

        public List<String> RXN_Id
        {
            get;
            set;
        }

        public List<String> SubstRxnNarID
        {
            get;
            set;
        }
        public List<String> SubstIds
        {
            get;
            set;
        }               
        public List<String> SubstRegNos
        {
            get;
            set;
        }
        public List<String> SubstRoles
        {
            get;
            set;
        }
               
        public List<String> File_Type
        {
            get;
            set;
        }
        public List<String> File_Id
        {
            get;
            set;
        }
        public List<String> File_Name
        {
            get;
            set;
        }
        public List<String> File_UUID
        {
            get;
            set;
        }

        public int UR_ID { get; set; }
    
       //New properties for Narratives extended task - 19th Feb 2016

        //public List<String> AnalogousNumSeqList { get; set; }
        public List<String> AnalogousRxnNarIdList { get; set; }
        public List<String> RxnNarIDList { get; set; }
        public List<Int32> RxnPageNoList { get; set; }
        public List<String> RxnPageLabelList { get; set; }
        public List<String> RxnTextLineList { get; set; }
        public List<String> RxnDocRefList { get; set; }
        public List<Double> RxnXPageSizeList { get; set; }
        public List<Double> RxnXPageOffsetList { get; set; }
        public List<Double> RxnYPageSizeList { get; set; }
        public List<Double> RxnYPageOffsetList { get; set; }
        public List<String> RxnParaList { get; set; }
        public List<String> RxnDataList { get; set; }
    }
}
