﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBll
{
    public class NarrReactionsBO
    {      
        public int RXN_ID
        { get; set; }

        public int TAN_ID
        { get; set; }

        public int RXN_NUM
        { get; set; }

        public int RXN_SEQ
        { get; set; }

        public int? RxnDocID
        { get; set; }

        public string PageNo
        { get; set; }
        
        public string PageLabel
        { get; set; }

        public string XOffSet
        { get; set; }

        public string YOffSet
        { get; set; }

        public double XPageSize
        { get; set; }

        public double YPageSize
        { get; set; }

        public string TextLine
        { get; set; }

        public string Para
        { get; set; }

        public string Data
        { get; set; }

        public string IsAnalogous
        { get; set; }

        public int? AnalogousRxnID
        { get; set; }

        public string NoExpDetails
        { get; set; }

        public string IsMissingRxn
        { get; set; }

        public string IsGeneralTypical
        { get; set; }

        public int UserID
        { get; set; }

        public string UserRole
        { get; set; }

        public string IsRxnCompleted
        { get; set; }

        public string YieldText
        { get; set; }

        public string ProcedureText
        { get; set; }

        public string IsNoPageLabel
        { get; set; }

        public string IsMappingUpdated
        { get; set; }

        public RxnFindings ReactionFindings { get; set; }
    }
}
