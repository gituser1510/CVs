﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text; 
#endregion
/////////////////////////////////////////////// CAS Reactant Tool///////////////////////////////////////////////////////////
///Start Data:
///End Data:
///Author:
///Developed by:
namespace IndxReactNarrBLL
{
    public class OrgRefBO
    {
        #region Public Variables
        public int ID
        { get; set; }
        public int Entity_ID
        { get; set; }
        public int Descriptor_ID
        { get; set; }
        public int NRNREG
        { get; set; }
        public int NRNNUM
        { get; set; }
        public string Descriptor
        { get; set; } 
        #endregion
    }
}
