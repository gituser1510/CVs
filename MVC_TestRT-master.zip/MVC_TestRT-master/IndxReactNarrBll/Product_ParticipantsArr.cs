﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBll
{
    public class Product_ParticipantsArr
    {
        public int ReactionID { get; set; }
        
        public List<int> RPP_ID { get; set; }
        
        public List<int?> RxnStageID { get; set; }

        public List<string> PPType { get; set; }

        public List<string> Yield { get; set; }

        public List<int> SeriesNumID { get; set; }

        public List<string> SeriesType { get; set; }

        public List<int> DisplayOrder { get; set; }

        public int UserID { get; set; }
    }
}
