﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBll
{
    public class ShipmentMasterBO
    {
        public string ShipmentName { get; set; }
        public string Application { get; set; }        
        public string[] Shipment_TANs { get; set; }
        public string[] TAN_CAN { get; set; }
        public string[] TAN_Type { get; set; }
        public string[] Journals { get; set; }
        public string[] Issue { get; set; }
        public string[] Year { get; set; }
        public int[] Section { get; set; }
        public string[] Title { get; set; }
        public string[] Abstract { get; set; }
        public string[] Language { get; set; }        
        public int UR_ID { get; set; }
    }
}
