﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBll
{
    public class NarrShipmentMasterBO
    {
        public string ShipmentName { get; set; }
        public string Application { get; set; }
        public string TAN { get; set; }
        public string CAN { get; set; }
        public string DOI { get; set; }
        public string Coden { get; set; }
        public string DocSeq { get; set; }
        public string Publisher { get; set; }
        public string TANType { get; set; }
        public List<string> RXN_NUMList { get; set; }
        public List<string> RXN_SEQList { get; set; }
        public List<int> RxnIdentifierList { get; set; }
        public List<string> FileNameList { get; set; }
        public List<string> FileTypeList { get; set; }
        public List<string> FileIdentifierList { get; set; }
        public List<string> FileUUIdList { get; set; } 
        public int UR_ID { get; set; }       
    }
}
