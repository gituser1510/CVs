﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text; 
#endregion
/////////////////////////////////////////////// CAS Reactant Tool///////////////////////////////////////////////////////////
///Start Data:
///End Data:
///Author:
///Developed by:
namespace IndxReactNarrBLL
{
    public class RXN_STAGE_BLL
    {
        #region Public Variables
        public int ID
        { get; set; }
        public int Reaction_ID
        { get; set; } 
        #endregion
    }
    public class RXN_SUB_STAGE_BLL
    {
        #region Public Variables
        public int ID
        { get; set; }
        public int Reaction_Stage_ID
        { get; set; }
        public int sub_satge_reaction_sequence
        { get; set; } 
        #endregion
    }

}
