﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBLL
{
    public class IndexingNUMInfo
    {
        public int TAN_ID { get; set; }
        public int TAN_NUM_ID { get; set; }
        public int NUM { get; set; }       
        public int? Reg_No { get; set; }
        public string NUMType { get; set; }
        public string DPT_RS { get; set; }
        public string NoStructure { get; set; }
        public string PolymerStructure { get; set; }
        public string PAR { get; set; }
        public string CTH { get; set; }
        public string CTH_Type { get; set; }
        public string NUM_TMD { get; set; }
        public string HMD { get; set; }
        public string AMD { get; set; }
        public string NUMRole { get; set; }
        public string NUMNote { get; set; }
        public string StructureMolFile { get; set; }
        public string StructureInchi { get; set; }
        public byte[] StructureImage { get; set; }
        public string IsTradeNamePolymer { get; set; }
        public string IsCrossReferred { get; set; }
        public string IsFileReviewRequire { get; set; }
        public string CrossReferenceTo { get; set; }

        public string SrcDocIndexTerm { get; set; }
        public int? IndexTermSrcDocID { get; set; }

        public string Option { get; set; }
        public int URID { get; set; } 
    }
}
