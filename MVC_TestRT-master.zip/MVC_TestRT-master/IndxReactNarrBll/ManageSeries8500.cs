﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBll
{
    public class ManageSeries8500
    {
        public int TS_ID { get; set; }
        public int TAN_ID { get; set; }
        public int OrgRefID { get; set; }
        public int Ser8500Val { get; set; }
        public string Option { get; set; }
        public int CreatedBy { get; set; }
    }
}
