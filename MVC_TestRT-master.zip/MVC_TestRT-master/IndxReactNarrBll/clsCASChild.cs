﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBLL
{
    public class clsCASChild
    {

      
        public int SerialNumber
        {
            get;
            set;
        }
        public int ReactionID  //datatype need to check
        {
            get;
            set;
        }

        public int ReactionCasReactantNumber  //datatype need to check
        {
            get;
            set;
        }
        public int Rxnseq  
        {
            get;
            set;
        }
        public string DocRef
        {
            get;
            set;

        }
        public int PageNumber
        {
            get;
            set;
        }
        public string PageLabel
        {
            get;
            set;
        }
        public string filename
        {
            get;
            set;
        }    
        public string XResUnit
        {
            get;
            set;
        }
        public int XResValue
        {
            get;
            set;
        }
        public double XPageSize
        {
            get;
            set;
        }
        public double XOffset
        {
            get;
            set;
        }
        public string YResUnit
        {
            get;
            set;
        }
        public int YResValue
        {
            get;
            set;
        }
        public double YPageSize
        {
            get;
            set;
        }
        public double YOffset
        {
            get;
            set;
        }
        public string TextLine
        {
            get;
            set;
        }
        public string NarrativeID
        {
            get;
            set;
        }
        public string Para
        {
            get;
            set;

        }
        public string Para1
        {
            get;
            set;

        }
        public string Data
        {
            get;
            set;
        }
        public string Data1
        {
            get;
            set;
        }
        public int DocumentID
        {
            get;
            set;
        }
        public bool isGeneralTypical
        {
            get;
            set;
        }

        public bool IsAnalogous
        {
            get;
            set;
        }

        public int AnalogousTo
        {
            get;
            set;
        }

        public bool IsMissingReaction
        {
            get;
            set;
        }

        public bool IsCurationComplete
        {
            get;
            set;
        }

        //
        public bool noexperimentaldetails
        {
            get;
            set;
        }
        public int  ReviewedByURID
        {
            get;
            set;
        }
    }
}
