﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBLL
{
    public class AppLoginTrack
    {
        #region Property Procedures

        public int UserID
        { get; set; }

        public int RoleID
        { get; set; }

        public string WindowsUserID
        { get; set; }

        public string SystemName
        { get; set; }

        public string SystemIPAddress
        { get; set; }

        public string SelOperation
        { get; set; }

        public string AppVersion
        { get; set; } 

        #endregion
    }
}
