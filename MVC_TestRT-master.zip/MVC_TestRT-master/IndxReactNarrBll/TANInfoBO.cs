﻿
#region Namespaces

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text; 

#endregion

namespace IndxReactNarrBLL
{
    public class TANInfoBO
    {
        #region Property Procedures

        public int TAN_ID
        { get; set; }

        public string Source
        { get; set; }

        public string ShipmentName
        { get; set; }

        public int Version
        { get; set; }        

        public string TAN
        { get; set; }

        public string CAN
        { get; set; }

        public string Analyst
        { get; set; }

        public string Comments
        { get; set; }

        public string BatchNo
        { get; set; }

        public int UserID
        { get; set; }

        public string TAN_Type
        { get; set; }

        #endregion
    }
}
