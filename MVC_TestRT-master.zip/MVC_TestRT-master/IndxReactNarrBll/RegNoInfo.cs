﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CASRxnPilotBLL
{
    public class RegNoInfo
    {
        public int NUM { get; set; }
        public int RegNo { get; set; }
        public string IUPACName { get; set; }
        public string MolFormula { get; set; }
        public string[] MolFormulas { get; set; }
        public string[] MolHexCodes { get; set; }
        public string[] MolAbsStereos { get; set; }
        public string MolSynonyms { get; set; }
        public string MolProteinSeq { get; set; }
        public string MolNuclicAcidSeq { get; set; }
        public string NoteTable{ get; set; }
    }
}
