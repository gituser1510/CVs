﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBLL
{
    public class UserErrors
    {
        public int BT_ID { get; set; }
        public int? ProdErrCnt { get; set; }
        public int? ReactErrCnt { get; set; }
        public int? AgentErrCnt { get; set; }
        public int? CatalyErrCnt { get; set; }
        public int? SolvErrCnt { get; set; }
        public int? CvtErrCnt { get; set; }
        public int? FreeTextErrCnt { get; set; }
        public int? TempErrCnt { get; set; }
        public int? TimeErrCnt { get; set; }
        public int? PresErrCnt { get; set; }
        public int? PhErrCnt { get; set; }
        public int? DelRxnCnt { get; set; }
        public int? AddedRxnCnt { get; set; }
        public int? OtherErrCnt { get; set; }
        public string Comments { get; set; }
        public int RepByUrID { get; set; }
        public string RepToUserName { get; set; }
        public string RepToUserRole { get; set; }
    }
}
