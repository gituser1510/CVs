﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBll
{
    public class RxnSearchNoteArr
    {
        public List<int> RSN_ID
        { get; set; }

        public List<int> RxnStageID
        { get; set; }

        public List<string> CVT
        { get; set; }

        public List<string> FreeText
        { get; set; }

        public List<string> NoteLevel
        { get; set; }

        public List<int> DisplayOrder
        { get; set; }

        public int UserID
        { get; set; }

    }
}
