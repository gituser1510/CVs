﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBll
{
    public class clsMaster
    {
        public string JournalArticalID
        {
            get;
            set;
        }
        public string TAN
        {
            get;
            set;
        }
        public string CAN
        {
            get;
            set;
        }
        public string DOI
        {
            get;
            set;
        }
        public string SupplementID
        {
            get;
            set;
        }
        public int ID
        {
            get;
            set;
        }

        public string Username
        {
            get;
            set;
        }
    }
}
