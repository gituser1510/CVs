﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBLL
{
    public class TANInfo
    {
        public string ShipmentName { get; set; }
        public string ShipmentNo { get; set; }
        public string TAN { get; set; }
        public int TANId { get; set; }
        public string IsReviewTAN { get; set; }

        public int SectionID { get; set; }
        public string SectionName { get; set; }
        public string SectionDesc { get; set; }
        public string SectionCode { get; set; }

        public string TMD { get; set; }
        public List<Int64> TKIDs { get; set; }
        public List<string> Keys { get; set; }
        public List<Int16> KeysOrder { get; set; }
        public List<Int64> TPIDs { get; set; }
        public List<string> PAR_Text { get; set; }
        public List<string> PAR_Rtf { get; set; }
        public List<Int64> PARIDs { get; set; }
        public List<Int16> PARsOrder { get; set; }
        public int UserId { get; set; }
        public int UserRoleID { get; set; }
    }
}
