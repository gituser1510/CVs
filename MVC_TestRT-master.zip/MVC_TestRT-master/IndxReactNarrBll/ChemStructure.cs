﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBll
{
    public class ChemStructure
    {
        public string SeriesNum { get; set; }
        public string RegNo { get; set; }
        public string[] MolHexArr { get; set; }
        public string MolName { get; set; }
        public string[] AbsoluteStrereo { get; set; }
        public string[] MolFormulas { get; set; }
        public string MolFormula { get; set; }
        public string MolSynonym { get; set; }
        public object MolStructure { get; set; }
        public string PeptideSeq { get; set; }
        public string NuclicAcidSeq { get; set; }
    }
}
