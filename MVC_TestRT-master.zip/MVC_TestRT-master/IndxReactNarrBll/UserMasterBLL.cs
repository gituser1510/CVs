﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBLL
{
    public class UserMasterBLL
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string EmpName { get; set; }
        public string UserPassword { get; set; }
        public string EmailAddress { get; set; }
        public string Status { get; set; }
        public string OptionType { get; set; }
        public char IsLDAPUser { get; set; }
    }

    public class UserProfileBLL
    {
        public int UserId { get; set; }
        public int RoleId { get; set; }
        public int ProjectManagerURID { get; set; }
        public int QualityAnalystURID { get; set; }
        public int ReviewerAnalystURID { get; set; }
        public int AnalystURID { get; set; }
        public int ToolManagerURID { get; set; }
        public string Status { get; set; }
        public string OptionType { get; set; }
        public string ApplicationName { get; set; }
        public string ModuleName { get; set; }
    }
}
