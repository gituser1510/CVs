﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBll
{
    public class TaskStatus
    {
        public int TAN_ID { get; set; }
        public int Task_ID { get; set; }
        public int TaskAllocation_ID { get; set; }
        //public int Role_ID { get; set; }
        public int UR_ID { get; set; }
        public string TaskStatusName { get; set; }
        public string TaskComments { get; set; }
    }
}
