﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBll
{
    public class RxnFindings
    {
        public int RxnID
        {
            get;
            set;
        }

        public List<Int32> RxnIDs
        {
            get;
            set;
        }

        public List<Int32> FindingIDs
        {
            get;
            set;
        }

        public List<String> FindingTypes
        {
            get;
            set;
        }

        public List<String> FindingValues
        {
            get;
            set;
        }

        public List<String> RefCompounds
        {
            get;
            set;
        }

    }
}
