﻿
#region Namespaces

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

#endregion

namespace IndxReactNarrBLL
{
    public class Product_ParticipantBO
    {
        #region Property Procedures

        public int RPP_ID  { get; set; }

        public int RxnID { get; set; }

        public int? RxnStageID  { get; set; }

        public string PPType { get; set; }        
                
        public string Yield { get; set; }

        public int SeriesNumID { get; set; }

        public string SeriesType { get; set; }
        
        public int DisplayOrder { get; set; }

        public int UserID { get; set; }

        #endregion
    }
}
