﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBll
{
    public class DictionaryTerm
    {
        public int DTK_ID { get; set; }
        public string DTK_Value { get; set; }
        public string DTK_Type { get; set; }
        public string Option { get; set; }
    }
}
