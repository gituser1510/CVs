﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBll
{
    public class ApplicationError
    {
        public string UserName { get; set; }
        public string RoleName { get; set; }
        public string AppError { get; set; }
    }
}
