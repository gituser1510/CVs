﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBll
{
    public class FindReplaceBO
    {
        public List<int> Rxn_IDs { get; set; }
        public List<string> FieldNames { get; set; }
        public List<string> FieldValues { get; set; }
    }
}
