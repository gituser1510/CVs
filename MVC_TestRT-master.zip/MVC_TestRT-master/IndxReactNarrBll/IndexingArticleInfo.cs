﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBLL
{
    public class IndexingTANInfo
    {
        public int TAN_ID { get; set; }
        public string TAN_Name { get; set; }
        public string ShipmentName { get; set; }
        public string BatchNo { get; set; }
        public int Section { get; set; }
        public int? SubSection { get; set; }
        public string CrossReference { get; set; }
        public string SpaHdr { get; set; }
        public string Title { get; set; }
        public string Abstract { get; set; }
        public string TMD { get; set; }
        public string Comments { get; set; }
        public string CommentsType { get; set; }
        public string Keywords { get; set; }
        public string ReviewTAN { get; set; }
        public string QueryTAN { get; set; }
        public string IncludeInREP { get; set; }
        public int URID { get; set; }
    }
}
