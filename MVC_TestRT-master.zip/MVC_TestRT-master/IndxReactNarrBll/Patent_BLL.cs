﻿
#region Namespaces

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text; 

#endregion

namespace IndxReactNarrBLL
{
    public class PatentBLL
    {

        #region Property Procedures

        public int ID
        { get; set; }

        public string Source
        { get; set; }

        public string FileName
        { get; set; }

        public int Version
        { get; set; }        

        public string TAN
        { get; set; }

        public string CAN
        { get; set; }

        public string Analyst
        { get; set; }

        public string Comments
        { get; set; }

        public string BatchNo
        { get; set; }

        public int UserID
        { get; set; }

        public string TAN_Type
        { get; set; }

        #endregion
    }
}
