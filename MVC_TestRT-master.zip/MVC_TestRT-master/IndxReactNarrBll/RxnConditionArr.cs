﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBll
{
    public class RxnConditionArr
    {
        public List<int> RC_ID { get; set; }

        public List<int> RxnStageID { get; set; }

        public List<string> Temperature { get; set; }

        public List<string> Pressure { get; set; }

        public List<string> pH { get; set; }

        public List<string> Time { get; set; }

        public List<string> TempType { get; set; }

        public List<string> TimeType { get; set; }

        public List<string> PHType { get; set; }

        public List<string> PressureType { get; set; }

        public List<int> DisplayOrder { get; set; }

        public int UserID { get; set; }
       
    }
}
