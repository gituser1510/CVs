﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBLL
{
    public class clserrortrack
    {
        public int documentID
        {
            get;
            set;
        }
        public int reactionID
        {
            get;
            set;
        }
        public int reported_by_ur_id
        {
            get;
            set;
        }

        public int reported_to_ur_id
        {
            get;
            set;
        }
        public string  tablename
        {
            get;
            set;
        }
        public string columnname
        {
            get;
            set;
        }
        public string oldvalue
        {
            get;
            set;
        }
        public string newvalue
        {
            get;
            set;
        }
    }
}
