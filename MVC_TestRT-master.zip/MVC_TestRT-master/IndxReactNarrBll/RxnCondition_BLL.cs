﻿
#region Namespaces

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text; 

#endregion

namespace IndxReactNarrBLL
{
    public class RxnCondition_BLL
    {
        #region Public Variables

        public int ID
        { get; set; }

        public int Rxn_Stage_ID
        { get; set; }

        public string Temperature
        { get; set; }

        public string Pressure
        { get; set; }

        public string pH
        { get; set; }

        public string Time
        { get; set; }

        public string TempType
        { get; set; }

        public string TimeType
        { get; set; }

        public string PHType
        { get; set; }

        public string PressureType
        { get; set; }

        public int UserID
        { get; set; }

        #endregion
    }
}
