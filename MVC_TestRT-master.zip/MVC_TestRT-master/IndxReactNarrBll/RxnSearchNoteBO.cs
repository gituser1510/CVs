﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

#endregion

namespace IndxReactNarrBLL
{
    public class RxnSearchNoteBO
    {
        public int RSN_ID
        { get; set; }

        public int RXN_Stage_ID
        { get; set; }

        public string CVT
        { get; set; }

        public string FreeText
        { get; set; }

        public string NoteLevel
        { get; set; }

        public int DisplayOrder
        { get; set; }

        public int UserID
        { get; set; }
    }
}
