﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

#endregion

namespace IndxReactNarrBLL
{
    public class Reaction_Search_Note_BLL
    {
        public int ID
        { get; set; }

        public int RXN_Stage_ID
        { get; set; }

        public string RSN_CVT
        { get; set; }

        public string RSN_FREE_TEXT
        { get; set; }

        public string RSN_Combined
        { get; set; }

        public int UserID
        { get; set; }
    }
}
