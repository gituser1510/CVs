﻿using System;
using System.Collections.Generic;


namespace IndxReactNarrBll
{
   public class CTH_Properties
    {
       public int CTH_ID
       {
           get;
           set;
       }
 
        public String Name
        {
            get;
            set;
        }
       
       public String Class
        {
            get;
            set;
        }
       
       public String Type
        {
            get;
            set;
        }
       
       public String CategoryType
        {
            get;
            set;
        }
       
       public String Status
        {
            get;
            set;
        }        
    }
}
