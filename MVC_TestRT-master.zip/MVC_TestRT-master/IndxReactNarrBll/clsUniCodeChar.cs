﻿namespace IndxReactNarrBll
{
    public class UniCodeChar
    {
        public string NarId { get; set; }
        public char UniChar { get; set; }
        public int Position { get; set; }
        //   public int UserControlSerialNo { get; set; }
        public string ErrField { get; set; }
        public string Word { get; set; }
    }
}
