﻿
#region Namespaces

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

#endregion

namespace IndxReactNarrBLL
{
    public class ProductBLL
    {
        #region Property Procedures

        public int ID
        { get; set; }

        public int Reaction_ID
        { get; set; }

        public string Name
        { get; set; }

        public object Mol_Sketch
        { get; set; }
                
        public string Yield
        { get; set; }

        public string NrnReg
        { get; set; }

        public byte[] Mol_Image
        { get; set; }

        public int P_Num
        { get; set; }

        public int P_9000
        { get; set; }

        public int P_8500
        { get; set; }

        public int P_8000
        { get; set; }

        public string Subst_Defn
        { get; set; }

        public int Subst_Num
        { get; set; }

        public string Subst_Loc
        { get; set; }

        public string Subst_Name
        { get; set; }

        public object Subst_Molecule
        { get; set; }

        public string Subst_Author_Name
        { get; set; }

        public string Subst_Other_Name
        { get; set; }

        public int UserID
        { get; set; }

        #endregion
    }
}
