﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBLL
{
    public class PTTProductivity
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string UserRole { get; set; }
        public int PTT_UserID { get; set; }
        public int ApplicationID { get; set; }
        public int SupervisorID { get; set; }
        public int Productivity { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }

        public DateTime ProductivityDate { get; set; }
        public string[] UsersList { get; set; }
        public string[] UsersRoles { get; set; }
        public int[] ActivityCodes { get; set; }
        public double[] ProductivityVals { get; set; }
        public string ProjectName { get; set; }
        public string ProjectToolName { get; set; }
        public string SubmittedByUser { get; set; }

    }
}
