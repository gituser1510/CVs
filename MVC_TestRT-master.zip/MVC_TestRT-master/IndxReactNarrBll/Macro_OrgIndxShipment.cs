﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarrBll
{
    public class Macro_OrgIndxShipment
    {
        public string ShipmentName { get; set; }
        public string Application { get; set; }
        public string TAN { get; set; }
        public string CAN { get; set; }
        public string TANType { get; set; }
        public string Language { get; set; }
        public string Issue { get; set; }
        public string Title { get; set; }
        public string Abstract { get; set; }
        public Int32 Section { get; set; }
        public string Year { get; set; }
        public string JournalName { get; set; } 
        public List<string> FileNameList { get; set; }
        public List<string> FileTypeList { get; set; }        
        public List<string> FileUUIdList { get; set; }
        public int UR_ID { get; set; }
    }
}
