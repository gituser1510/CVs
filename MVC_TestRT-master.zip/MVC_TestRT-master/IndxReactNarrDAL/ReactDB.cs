﻿
#region Namespaces

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using Npgsql;
//using NpgsqlTypes;
using IndxReactNarrBLL;
using System.Data;
using System.Data.Common;
using Oracle.ManagedDataAccess.Client;
using IndxReactNarrBll;

#endregion

namespace IndxReactNarrDAL
{
    public class ReactDB
    {
        #region CASREACT application main Methods

        //====================New Procedures from 26July10====================

        //public static bool DeleteTAN(int _tan_patentID, string batch_name)
        //{
        //    NpgsqlConnection con = null;
        //    try
        //    {
        //        con = Connection.GetConnection();
        //        NpgsqlCommand cmd = new NpgsqlCommand();
        //        cmd.Connection = con;
        //        cmd.CommandText = "casrxn.delete_tan";
        //        cmd.CommandType = System.Data.CommandType.StoredProcedure;

        //        NpgsqlParameter p_Patent_ID = new NpgsqlParameter();
        //        p_Patent_ID.ParameterName = "p_patent_id";
        //        p_Patent_ID.DbType = System.Data.DbType.Int32;
        //        p_Patent_ID.Value = _tan_patentID;
        //        cmd.Parameters.Add(p_Patent_ID);

        //        NpgsqlParameter p_Batch = new NpgsqlParameter();
        //        p_Batch.ParameterName = "p_batchname";
        //        p_Batch.DbType = System.Data.DbType.String;
        //        p_Batch.Value = _tan_patentID;
        //        cmd.Parameters.Add(p_Batch);

        //        con.Open();
        //        cmd.ExecuteScalar();
        //        return true;
        //    }
        //    catch (NpgsqlException ex)
        //    {
        //        con.Close();
        //        throw ex;
        //    }
        //    finally
        //    {
        //        con.Close();
        //    }
        //}

        public static DataTable Get_ReactionsData_on_TAN(string _tanid)
        {
            DataTable _dtReactions = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_REACTIONS_ON_TAN";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIC_TAN_NAME", OracleDbType.Varchar2).Value = _tanid;
                    oraCmd.Parameters.Add("PORC_RESULTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    DataSet dsResults = new DataSet();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dsResults);
                    if (dsResults != null)
                    {
                        if (dsResults.Tables.Count > 0)
                        {
                            if (dsResults.Tables[0] != null)
                            {
                                _dtReactions = dsResults.Tables[0];
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _dtReactions;

        }

        public static DataTable Get_Batch_TAN_NRNNUM_REG_Details(string _tan)
        {
            DataTable _dsDetails = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_BATCH_TAN_NRNNUM_REG_DTLS";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIC_TAN", OracleDbType.Varchar2).Value = _tan;
                    oraCmd.Parameters.Add("PORC_RESULTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    DataSet dsResults = new DataSet();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dsResults);
                    if (dsResults != null)
                    {
                        if (dsResults.Tables.Count > 0)
                        {
                            if (dsResults.Tables[0] != null)
                            {
                                _dsDetails = dsResults.Tables[0];
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _dsDetails;


        }



        public static DataTable GetStagelLevelRSN_FreeText_Details()
        {

            DataTable dtSTAGEFreeText = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_RSN_DICT_TYPE_DETAILS";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIC_DICT_TYPE", OracleDbType.Varchar2).Value = "STAGE";
                    oraCmd.Parameters.Add("PORC_RESULTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    DataSet dsResults = new DataSet();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dsResults);
                    if (dsResults != null)
                    {
                        if (dsResults.Tables.Count > 0)
                        {
                            if (dsResults.Tables[0] != null)
                            {
                                dtSTAGEFreeText = dsResults.Tables[0];
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtSTAGEFreeText;


        }


        public static DataTable Get_RxnNum_RxnSeq_On_PatentID(int _patent_id)
        {
            DataTable _dsDetails = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_RXN_NUM_RXN_SEQ_ON_TANID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = _patent_id;
                    oraCmd.Parameters.Add("PORC_RESULTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    DataSet dsResults = new DataSet();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dsResults);
                    if (dsResults != null)
                    {
                        if (dsResults.Tables.Count > 0)
                        {
                            if (dsResults.Tables[0] != null && dsResults.Tables[0].Rows.Count > 0)
                            {
                                _dsDetails = dsResults.Tables[0];
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _dsDetails;


        }

        public static DataTable GetStructuresOnRegNo(int tanNumID, int regno, string numtype)
        {
            DataTable dtStructures = null;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "REACT.GET_STRUCTURE_ON_REGNO";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Parameters.Add("PIN_REG_NO", OracleDbType.Int32).Value = regno;
                        oraCmd.Parameters.Add("PIN_TAN_NUM_ID", OracleDbType.Int32).Value = tanNumID;
                        oraCmd.Parameters.Add("PIC_NUM_TYPE", OracleDbType.Varchar2).Value = numtype;
                        oraCmd.Parameters.Add("PORC_STRUCTURES", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                        dtStructures = new DataTable();
                        OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                        oraAdpt.Fill(dtStructures);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtStructures;
        }

        public static DataTable GetStructureImageOnRegNo(int tan_id, int regno)
        {
            DataTable dtStructures = null;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "REACT.GET_STRUCTURE_IMAGE_ON_TAN_ID";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tan_id;
                        oraCmd.Parameters.Add("PIN_REG_NO", OracleDbType.Int32).Value = regno;
                        oraCmd.Parameters.Add("PORC_STRUCT_IMAGES", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                        dtStructures = new DataTable();
                        OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                        oraAdpt.Fill(dtStructures);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtStructures;
        }

        public static void CheckDuplicateStructureOnInchi(string _src_inchi, out string _p_num, out string _p_regno)
        {
            string num = null;
            string reg_No = null;

            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oCmd = new OracleCommand())
                    {
                        OracleParameter[] oPrms = new OracleParameter[3];

                        oPrms[0] = new OracleParameter("PIC_INCHI", OracleDbType.Varchar2, 250, _src_inchi, ParameterDirection.Input);
                        oPrms[1] = new OracleParameter("POC_NUM", OracleDbType.Int32, 4, null, ParameterDirection.Output);
                        oPrms[2] = new OracleParameter("POC_REG_NO", OracleDbType.Int32, 9, null, ParameterDirection.Output);


                        oCmd.CommandText = "REACT.CHECK_DUP_STRUCTURE";
                        oCmd.CommandType = CommandType.StoredProcedure;
                        oCmd.Connection = dbCon;
                        oCmd.Parameters.AddRange(oPrms);

                        dbCon.Open();
                        oCmd.ExecuteNonQuery();
                        num = oPrms[1].Value != null ? oPrms[4].Value.ToString() : "";
                        reg_No = oPrms[2].Value != null ? oPrms[2].Value.ToString() : "";
                        dbCon.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            _p_num = num;
            _p_regno = reg_No;

            //object objPNum = null;
            //NpgsqlConnection con = null;
            //try
            //{
            //    con = Connection.GetConnection();
            //    con.Open();
            //    //NpgsqlTransaction tr = con.BeginTransaction();

            //    NpgsqlCommand cmd = new NpgsqlCommand();
            //    cmd.Connection = con;
            //    cmd.CommandText = "casrxn.check_dup_structure";
            //    cmd.CommandType = CommandType.StoredProcedure;

            //    NpgsqlParameter p_InchiKey = new NpgsqlParameter();
            //    p_InchiKey.ParameterName = "p_inchi";
            //    p_InchiKey.DbType = DbType.String;
            //    p_InchiKey.Value = _src_inchi;
            //    cmd.Parameters.Add(p_InchiKey);

            //    NpgsqlParameter po_NumVal = new NpgsqlParameter();
            //    po_NumVal.ParameterName = "po_num";
            //    po_NumVal.DbType = DbType.String;
            //    po_NumVal.Direction = ParameterDirection.Output;
            //    cmd.Parameters.Add(po_NumVal);

            //    NpgsqlParameter po_RegNum = new NpgsqlParameter();
            //    po_RegNum.ParameterName = "po_regno";
            //    po_RegNum.DbType = DbType.String;
            //    po_RegNum.Direction = ParameterDirection.Output;
            //    cmd.Parameters.Add(po_RegNum);

            //    cmd.ExecuteNonQuery();
            //    con.Close();

            //    _p_num = po_NumVal.Value.ToString();
            //    _p_regno = po_RegNum.Value.ToString();
            //}
            //catch (NpgsqlException ex)
            //{
            //    con.Close();
            //    throw ex;
            //}
            //finally
            //{
            //    con.Close();
            //}
        }

        public static DataTable Get_RSNDetails_On_TAN(string _tan)
        {

            DataTable dtRSNDetails = null;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "REACT.GET_RSN_DTLS_ON_TAN";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Parameters.Add("PIC_TAN_NAME", OracleDbType.Varchar2).Value = _tan;
                        oraCmd.Parameters.Add("PORC_RESULTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                        dtRSNDetails = new DataTable();
                        OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                        oraAdpt.Fill(dtRSNDetails);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtRSNDetails;

        }

        public static DataTable Get_RSNDetails_On_BatchName_No(string batchName, int batchNo)
        {

            DataTable dtRSNDetails = null;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "REACT.GET_RSN_DTLS_ON_BATCH_NAME_NO";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Parameters.Add("PIN_BATCH_NO", OracleDbType.Varchar2).Value = batchNo;
                        oraCmd.Parameters.Add("PIC_BATCH_NAME", OracleDbType.Varchar2).Value = batchName;
                        oraCmd.Parameters.Add("PORC_RESULTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                        dtRSNDetails = new DataTable();
                        OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                        oraAdpt.Fill(dtRSNDetails);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtRSNDetails;

        }

        public static bool Update_RSN_FreeText_On_RSNID(int _rsnid, string _freetext)
        {
            bool blStatus = false;

            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "REACT.UPDATE_RSN_FREETEXT_ON_RSN_ID";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Parameters.Add("PIN_RSN_ID", OracleDbType.Int32).Value = _rsnid;
                        oraCmd.Parameters.Add("PIC_FREE_TEXT", OracleDbType.Varchar2).Value = _freetext;
                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        oraCon.Close();
                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return blStatus;
        }

        public static bool UpdateRSNFreeTextOnRSNID(RxnSearchNoteArr rsnArr)
        {
            bool blStatus = false;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "REACT.UPDATE_RSN_FREETEXT_ON_RSN_ID";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        OracleParameter paRSNIDs = new OracleParameter();
                        paRSNIDs.ParameterName = "PINA_RSN_ID";
                        paRSNIDs.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRSNIDs.OracleDbType = OracleDbType.Int32;
                        paRSNIDs.Value = rsnArr.RSN_ID.Count > 0 ? rsnArr.RSN_ID.ToArray() : new Int32[1] { 0 };
                        oraCmd.Parameters.Add(paRSNIDs);

                        OracleParameter paFreeText = new OracleParameter();
                        paFreeText.ParameterName = "PICA_FREE_TEXT";
                        paFreeText.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFreeText.OracleDbType = OracleDbType.Varchar2;
                        paFreeText.Value = rsnArr.FreeText.Count > 0 ? rsnArr.FreeText.ToArray() : new string[1] { "" };
                        oraCmd.Parameters.Add(paFreeText);

                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        oraCon.Close();
                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return blStatus;
        }

        #endregion


        public static string GetCANOnBatchTAN(string _batchname, string _tan)
        {

            string strCAN = null;

            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GETCANONBATCHTAN";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIC_BATCH_NAME", OracleDbType.Varchar2).Value = _batchname;
                    oraCmd.Parameters.Add("PIC_TAN_NAME", OracleDbType.Varchar2).Value = _tan;
                    oraCmd.Parameters.Add("PORC_RESULTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    DataTable dtResults = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtResults);
                    if (dtResults != null)
                    {
                        if (dtResults.Rows.Count > 0)
                        {
                            strCAN = System.DBNull.Value.Equals(dtResults.Rows[0]["CAN"]) || (dtResults.Rows[0]["CAN"] == null) ? "" : dtResults.Rows[0]["CAN"].ToString();

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            //try
            //{
            //    using (OracleConnection oraCon = DataConnection.GetOracleConnection())
            //    {
            //        using (OracleCommand oraCmd = new OracleCommand())
            //        {
            //            oraCmd.Connection = oraCon;
            //            oraCmd.CommandText = string.Format("SELECT CAN FROM SHIPMENT_TANS ST,SHIPMENT_MASTER SM WHERE ST.SHIPMENT_ID=SM.SHIPMENT_ID AND  SH.SHIPMENT_NAME = {0} AND TAN_NAME={1}", _batchname, _tan);

            //            oraCon.Open();

            //       object    objCAN = oraCmd.ExecuteScalar();

            //            oraCon.Close();
            //            strCAN = objCAN.ToString();
            //        }
            //    }


            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}

            return strCAN;

        }

        #region New Oracle Methods by Sairam from 11th June 2014

        public static DataTable GetUsersByApplicationModule(string application, string module)
        {
            DataTable dtUsers = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "USER_MANAGEMENT.GET_APP_MODULE_USERS";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIC_APPLICATION", OracleDbType.Varchar2).Value = application;
                    oraCmd.Parameters.Add("PIC_MODULE", OracleDbType.Varchar2).Value = module;
                    oraCmd.Parameters.Add("PORC_USERS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtUsers = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtUsers);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtUsers;
        }

        public static DataTable GetShipmentDetailsByAppName(string appName, out DataTable dtTAN_Types)
        {
            DataTable dtShipment_Names = null;
            DataTable dtTAN_Typs = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_SHIP_TAN_TYPE_BY_APP";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIC_APPLICATION", OracleDbType.Varchar2).Value = appName;
                    oraCmd.Parameters.Add("PORC_SHIPMENTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    oraCmd.Parameters.Add("PORC_TAN_TYPE", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    DataSet dsResults = new DataSet();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dsResults);

                    if (dsResults != null)
                    {
                        if (dsResults.Tables.Count > 0)
                        {
                            if (dsResults.Tables[0] != null)
                            {
                                dtShipment_Names = dsResults.Tables[0];
                                dtTAN_Typs = dsResults.Tables[1];
                            }
                        }
                    }

                }
            }
            catch (Exception ex)
            {

                throw ex;
            }

            dtTAN_Types = dtTAN_Typs;
            return dtShipment_Names;
        }

        public static DataTable GetUnAssignedTANSOnShipment(string application, string module, int shipmentID, int batchNo)
        {
            DataTable dtTANs = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "TASK_MANAGEMENT.GET_UNASSIGNED_TANS";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIC_APPLICATION", OracleDbType.Varchar2).Value = application;
                    oraCmd.Parameters.Add("PIC_MODULE", OracleDbType.Varchar2).Value = module;
                    oraCmd.Parameters.Add("PIN_SHIPMENT_ID", OracleDbType.Int32).Value = shipmentID;
                    oraCmd.Parameters.Add("PIN_BATCH_NO", OracleDbType.Int32).Value = batchNo;
                    oraCmd.Parameters.Add("PORC_TANS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtTANs = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtTANs);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtTANs;
        }

        public static DataTable GetUserTaskCountsOnApplicationModule(string application, string module)
        {
            DataTable dtTANs = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "TASK_MANAGEMENT.GET_USER_TASK_CNTS";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIC_APPLICATION", OracleDbType.Varchar2).Value = application;
                    oraCmd.Parameters.Add("PIC_MODULE", OracleDbType.Varchar2).Value = module;
                    oraCmd.Parameters.Add("PORC_USER_TASK_CNTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtTANs = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtTANs);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtTANs;
        }

        public static DataTable GetTANDetailsOnTANID(int tanID)
        {
            DataTable dtTANDtls = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_TAN_DTLS_ON_TAN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanID;
                    oraCmd.Parameters.Add("PORC_TAN_DTLS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtTANDtls = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtTANDtls);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtTANDtls;
        }

        public static DataTable GetTANDetailsOnTANName(string tanName)
        {
            DataTable dtTANDtls = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_TAN_DTLS_ON_TAN_NAME";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIC_TAN_NAME", OracleDbType.Varchar2, 9).Value = tanName;
                    oraCmd.Parameters.Add("PORC_TAN_DTLS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtTANDtls = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtTANDtls);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtTANDtls;
        }

        public static DataTable GetTANDetailsOnTANIDForExport(int tanID)
        {
            DataTable dtTANDtls = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_TAN_DTLS_ON_TAN_ID_EXPORT";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanID;
                    oraCmd.Parameters.Add("PORC_TAN_DTLS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtTANDtls = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtTANDtls);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtTANDtls;
        }

        public static DataTable GetTANDetailedReportOnTAN(string tanName, out DataTable commentsData)
        {
            DataTable dtTANReport = null;
            DataTable dtComments = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REPORTS.GET_TAN_REPORT_ON_TAN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIC_TAN_NAME", OracleDbType.Varchar2).Value = tanName;
                    oraCmd.Parameters.Add("PORC_TAN_REPORT", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    oraCmd.Parameters.Add("PORC_TAN_COMMENTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    DataSet dsResults = new DataSet();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dsResults);
                    if (dsResults != null)
                    {
                        if (dsResults.Tables.Count == 2)
                        {
                            dtTANReport = dsResults.Tables[0];
                            dtComments = dsResults.Tables[1];
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            commentsData = dtComments;
            return dtTANReport;
        }

        public static DataTable GetTANParticipantCountsOnTAN(string tanName, out DataTable condsData, out DataTable ser8000Data)
        {
            DataTable dtPartpnts = null;
            DataTable dtConds = null;
            DataTable dtSer8000 = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REPORTS.GET_TAN_PARTPNTS_COUNT";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIC_TAN_NAME", OracleDbType.Varchar2).Value = tanName;
                    oraCmd.Parameters.Add("PORC_PARTPNTS_COUNT", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    oraCmd.Parameters.Add("PORC_CONDITIONS_COUNT", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    oraCmd.Parameters.Add("PORC_8000_COUNT", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    DataSet dsResults = new DataSet();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dsResults);

                    if (dsResults != null)
                    {
                        if (dsResults.Tables.Count == 3)
                        {
                            dtPartpnts = dsResults.Tables[0];
                            dtConds = dsResults.Tables[1];
                            dtSer8000 = dsResults.Tables[2];
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            condsData = dtConds;
            ser8000Data = dtSer8000;
            return dtPartpnts;
        }

        public static DataTable GetNUM_RegNoDetailsOnTANID(int tanID)
        {
            DataTable dtNumRegNo = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_NUM_REGNO_DTLS_ON_TAN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanID;
                    oraCmd.Parameters.Add("PORC_NUM_DTLS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtNumRegNo = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtNumRegNo);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtNumRegNo;
        }

        public static DataTable GetRxnNUM_RegNoDetailsOnTANID(int tanID)
        {
            DataTable dtNumRegNo = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_RXN_NUM_REGNOS_ON_TAN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanID;
                    oraCmd.Parameters.Add("PORC_NUM_DTLS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtNumRegNo = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtNumRegNo);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtNumRegNo;
        }

        public static DataTable GetReactionsOnTANID(int tanID)
        {
            DataTable dtReactions = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_REACTIONS_ON_TAN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIC_TAN_ID", OracleDbType.Int32).Value = tanID;
                    oraCmd.Parameters.Add("PORC_RESULTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtReactions = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtReactions);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtReactions;
        }

        public static DataTable GetReactionStagesOnRxnID(int reactionid)
        {
            DataTable dtStages = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_RXN_STAGES_ON_RXN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_RXN_ID", OracleDbType.Int32).Value = reactionid;
                    oraCmd.Parameters.Add("PORC_RXN_STAGES", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtStages = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtStages);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtStages;
        }

        public static DataTable GetProductAndParticipantsOnRxnID(int reactionid, int tanid)
        {
            DataTable dtProdParpnts = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_PP_DTLS_ON_RXN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_RXN_ID", OracleDbType.Int32).Value = reactionid;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanid;
                    oraCmd.Parameters.Add("PORC_PROD_PART_DTLS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtProdParpnts = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtProdParpnts);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtProdParpnts;
        }

        public static DataTable GetRSNDetailsOnRxnID(int reactionid)
        {
            DataTable dtRSN = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_RSN_DETAILS_ON_RXN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_RXN_ID", OracleDbType.Int32).Value = reactionid;
                    oraCmd.Parameters.Add("PORC_RSN", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtRSN = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtRSN);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtRSN;
        }

        public static DataTable GetConditionsDetailsOnRxnID(int reactionid)
        {
            DataTable dtConditions = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_RXN_CONDITIONS_ON_RXN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_RXN_ID", OracleDbType.Int32).Value = reactionid;
                    oraCmd.Parameters.Add("PORC_RXN_CONDS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtConditions = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtConditions);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtConditions;
        }

        public static int GetReactionNewParticipantID(string partpnttype, int reactionid, int rxnstageid, int disporder, string before_after, int created_by)
        {
            int partpantID = 0;
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "REACT.GET_NEW_PARTICIPANT_ID";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        oraCmd.Parameters.Add("PIN_RXN_ID", OracleDbType.Int32).Value = reactionid;
                        oraCmd.Parameters.Add("PIN_RXN_STAGE_ID", OracleDbType.Int32).Value = rxnstageid;
                        oraCmd.Parameters.Add("PIC_PARTICIPANT_TYPE", OracleDbType.Varchar2).Value = partpnttype;
                        oraCmd.Parameters.Add("PIN_DISPLAY_ORDER", OracleDbType.Int32).Value = disporder;
                        oraCmd.Parameters.Add("PIC_BEFORE_AFTER", OracleDbType.Varchar2).Value = before_after;
                        OracleParameter opPartpntID = new OracleParameter("POC_PARTICIPANT_ID", OracleDbType.Int32, 10, ParameterDirection.Output);
                        oraCmd.Parameters.Add(opPartpntID);

                        dbCon.Open();
                        oraCmd.ExecuteNonQuery();
                        partpantID = opPartpntID.Value != null ? int.Parse(opPartpntID.Value.ToString()) : 0;
                        dbCon.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return partpantID;
        }

        public static int InsertAndGetNewReactionID(int tanID, int rxnNum, int rxnNum_Insert, int rxnSeq_insert, int display_order, string series_type, int ser_num_id, int created_by)
        {
            int newRxnID = 0;
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "REACT.INSERT_NEW_REACTION_ID";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanID;
                        oraCmd.Parameters.Add("PIN_RXNNUM", OracleDbType.Int32).Value = rxnNum;

                        oraCmd.Parameters.Add("PIN_RXNNUM_INSERT", OracleDbType.Int32).Value = rxnNum_Insert;
                        oraCmd.Parameters.Add("PIN_RXNSEQ_INSERT", OracleDbType.Int32).Value = rxnSeq_insert;
                        oraCmd.Parameters.Add("PIN_DISPLAY_ORDER", OracleDbType.Int32).Value = display_order;
                        //oraCmd.Parameters.Add("PIC_BEFORE_AFTER", OracleDbType.Varchar2).Value = before_after;
                        oraCmd.Parameters.Add("PIC_SER_TYPE", OracleDbType.Varchar2).Value = series_type;
                        oraCmd.Parameters.Add("PIN_SER_TAN_NUM_ID", OracleDbType.Int32).Value = ser_num_id;

                        oraCmd.Parameters.Add("PON_RXN_ID", OracleDbType.Int32).Direction = ParameterDirection.Output;

                        dbCon.Open();
                        oraCmd.ExecuteNonQuery();
                        newRxnID = oraCmd.Parameters["PON_RXN_ID"].Value != null ? int.Parse(oraCmd.Parameters["PON_RXN_ID"].Value.ToString()) : 0;
                        dbCon.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return newRxnID;
        }

        public static int GetNewProductID(int reactionid, int created_by)
        {
            int productID = 0;
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "REACT.GET_NEW_PRODUCT_ID";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        oraCmd.Parameters.Add("PIN_RXN_ID", OracleDbType.Int32).Value = reactionid;
                        OracleParameter opProductID = new OracleParameter("PON_RPP_ID", OracleDbType.Int32, 10, ParameterDirection.Output);
                        oraCmd.Parameters.Add(opProductID);

                        dbCon.Open();
                        oraCmd.ExecuteNonQuery();
                        productID = opProductID.Value != null ? int.Parse(opProductID.Value.ToString()) : 0;
                        dbCon.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return productID;
        }

        public static int GetNewStageID(int reactionid, int disporder, string before_after, int created_by)
        {
            int newStageID = 0;
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "REACT.GET_RXN_NEW_STAGE_ID";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        oraCmd.Parameters.Add("PIN_RXN_ID", OracleDbType.Int32).Value = reactionid;
                        oraCmd.Parameters.Add("PIN_DISPLAY_ORDER", OracleDbType.Int32).Value = disporder;
                        oraCmd.Parameters.Add("PIC_BEFORE_AFTER", OracleDbType.Varchar2).Value = before_after;
                        oraCmd.Parameters.Add("PIN_CREATED_BY", OracleDbType.Int32).Value = created_by;
                        OracleParameter opPartpntID = new OracleParameter("PON_STAGE_ID", OracleDbType.Int32, 10, ParameterDirection.Output);
                        oraCmd.Parameters.Add(opPartpntID);

                        dbCon.Open();
                        oraCmd.ExecuteNonQuery();
                        newStageID = opPartpntID.Value != null ? int.Parse(opPartpntID.Value.ToString()) : 0;
                        dbCon.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return newStageID;
        }

        public static DataTable GetRsnCVT_FreeTextOnType(string dictType)
        {
            DataTable dtRSN = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_RSN_DICT_TYPE_DETAILS";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIC_DICT_TYPE", OracleDbType.Varchar2).Value = dictType;
                    oraCmd.Parameters.Add("PORC_RESULTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtRSN = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtRSN);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtRSN;
        }

        public static DataTable GetSolventBoilingPoints()
        {
            DataTable dtSolvBPnts = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_SOLVENT_BOITPOINTS_DETAILS";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PORC_RESULTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtSolvBPnts = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtSolvBPnts);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtSolvBPnts;

        }

        public static bool UpdateProduct_ParticipantsData(Product_ParticipantBO prod_partpnt)
        {
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "REACT.UPDATE_RXN_PARTICIPANTS";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        oraCmd.Parameters.Add("PIN_RPP_ID", OracleDbType.Int32).Value = prod_partpnt.RPP_ID;
                        oraCmd.Parameters.Add("PIN_RXN_ID", OracleDbType.Int32).Value = prod_partpnt.RxnID;
                        oraCmd.Parameters.Add("PIN_RXN_STAGE_ID", OracleDbType.Int32).Value = prod_partpnt.RxnStageID;
                        oraCmd.Parameters.Add("PIC_PP_TYPE", OracleDbType.Varchar2).Value = prod_partpnt.PPType;
                        oraCmd.Parameters.Add("PIC_SER_TYPE", OracleDbType.Varchar2).Value = prod_partpnt.SeriesType;
                        oraCmd.Parameters.Add("PIN_SER_TAN_NUM_ID", OracleDbType.Int32).Value = prod_partpnt.SeriesNumID;
                        oraCmd.Parameters.Add("PIC_YIELD", OracleDbType.Varchar2).Value = prod_partpnt.Yield;
                        oraCmd.Parameters.Add("PIN_DISPLAY_ORDER", OracleDbType.Int32).Value = prod_partpnt.DisplayOrder;
                        oraCmd.Parameters.Add("POC_STATUS", OracleDbType.Varchar2, 100).Direction = ParameterDirection.Output;

                        dbCon.Open();
                        oraCmd.ExecuteNonQuery();
                        dbCon.Close();
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return false;
        }

        public static bool UpdateConditionsData(RxnConditionBO coditions)
        {
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "REACT.UPDATE_RXN_CONDITION";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        oraCmd.Parameters.Add("PIN_RC_ID", OracleDbType.Int32).Value = coditions.RC_ID;
                        oraCmd.Parameters.Add("PIN_RXN_STAGE_ID ", OracleDbType.Int32).Value = coditions.Rxn_Stage_ID;

                        oraCmd.Parameters.Add("PIC_TEMPERATURE", OracleDbType.Varchar2).Value = coditions.Temperature;
                        oraCmd.Parameters.Add("PIC_PRESSURE ", OracleDbType.Varchar2).Value = coditions.Pressure;
                        oraCmd.Parameters.Add("PIC_PH", OracleDbType.Varchar2).Value = coditions.pH;
                        oraCmd.Parameters.Add("PIC_RC_TIME ", OracleDbType.Varchar2).Value = coditions.Time;

                        oraCmd.Parameters.Add("PIC_TEMP_TYPE", OracleDbType.Varchar2).Value = coditions.TempType;
                        oraCmd.Parameters.Add("PIC_TIME_TYPE ", OracleDbType.Varchar2).Value = coditions.TimeType;
                        oraCmd.Parameters.Add("PIC_PH_TYPE", OracleDbType.Varchar2).Value = coditions.PHType;
                        oraCmd.Parameters.Add("PIC_PRESSURE_TYPE ", OracleDbType.Varchar2).Value = coditions.PressureType;
                        oraCmd.Parameters.Add("PIN_DISPLAY_ORDER", OracleDbType.Int32).Value = coditions.DisplayOrder;
                        //oraCmd.Parameters.Add("PIN_CREATED_BY", OracleDbType.Int32).Value = created_by;

                        dbCon.Open();
                        oraCmd.ExecuteNonQuery();
                        dbCon.Close();
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }

        public static bool UpdateRSNData(RxnSearchNoteBO rsn)
        {
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "REACT.UPDATE_RXN_SEARCH_NOTE";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        oraCmd.Parameters.Add("PIN_RSN_ID", OracleDbType.Int32).Value = rsn.RSN_ID;
                        oraCmd.Parameters.Add("PIN_RXN_STAGE_ID", OracleDbType.Int32).Value = rsn.RXN_Stage_ID;
                        oraCmd.Parameters.Add("PIC_CVT", OracleDbType.Varchar2).Value = rsn.CVT;
                        oraCmd.Parameters.Add("PIC_FREE_TEXT", OracleDbType.Varchar2).Value = rsn.FreeText;
                        oraCmd.Parameters.Add("PIC_NOTE_LEVEL", OracleDbType.Varchar2).Value = rsn.NoteLevel;
                        oraCmd.Parameters.Add("PIN_DISPLAY_ORDER", OracleDbType.Int32).Value = rsn.DisplayOrder;
                        //oraCmd.Parameters.Add("PIN_CREATED_BY", OracleDbType.Int32).Value = created_by;

                        dbCon.Open();
                        oraCmd.ExecuteNonQuery();
                        dbCon.Close();
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }

        public static bool DeleteReactionParticipant(int partpnt_id, string partpnt_type)
        {
            bool blStatus = false;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "REACT.DELETE_PARTICIPANT_RSN_COND";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Parameters.Add("PIN_PARTICIPANT_ID", OracleDbType.Int32).Value = partpnt_id;
                        oraCmd.Parameters.Add("PIC_PARTICIPANT_TYPE", OracleDbType.Varchar2).Value = partpnt_type;

                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        oraCon.Close();
                        blStatus = true;

                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return blStatus;
        }

        public static bool DeleteReactionStage(int rxnstageid)
        {
            bool blStatus = false;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "REACT.DELETE_RXN_STAGES";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Parameters.Add("PIN_RXN_STAGE_ID", OracleDbType.Int32).Value = rxnstageid;
                        oraCmd.Parameters.Add("POC_STATUS", OracleDbType.Varchar2, 50).Direction = ParameterDirection.Output;

                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        string strStatus = oraCmd.Parameters["POC_STATUS"].Value != null ? oraCmd.Parameters["POC_STATUS"].Value.ToString() : "";
                        oraCon.Close();

                        if (strStatus.ToUpper() == "SUCCESS")
                        {
                            blStatus = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return blStatus;
        }

        public static bool DeleteReaction(int _reaction_id, int _patent_id, int _rxnnum, int _rxnseq)
        {
            bool blStatus = false;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "REACT.DELETE_REACTION";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Parameters.Add("PIN_RXN_ID", OracleDbType.Int32).Value = _reaction_id;
                        oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = _patent_id;
                        oraCmd.Parameters.Add("PIN_RXN_NUM", OracleDbType.Int32).Value = _rxnnum;
                        oraCmd.Parameters.Add("PIN_RXN_SEQ", OracleDbType.Int32).Value = _rxnseq;
                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        oraCon.Close();
                        blStatus = true;

                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return blStatus;

        }

        #region TAN Comments realted methods

        public static DataTable GetTANCommentsOnTANID(int tanID)
        {
            DataTable dtComments = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_COMMENTS_ON_TAN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanID;
                    oraCmd.Parameters.Add("PORC_COMMENTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtComments = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtComments);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtComments;
        }

        public static bool UpdateCommentsOnTANID(TANCommentsBO tanComments)
        {
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "REACT.UPDATE_TAN_COMMENTS";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanComments.TAN_ID;

                        OracleParameter paTCIDs = new OracleParameter();
                        paTCIDs.ParameterName = "PINA_TC_ID";
                        paTCIDs.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paTCIDs.OracleDbType = OracleDbType.Int32;
                        if (tanComments.TC_IDs.Count > 0)
                        {
                            paTCIDs.Value = tanComments.TC_IDs.ToArray();
                        }
                        else
                        {
                            paTCIDs.Value = new Int32[1] { 0 };
                            paTCIDs.Size = 0;
                        }
                        oraCmd.Parameters.Add(paTCIDs);

                        OracleParameter paCommentsType = new OracleParameter();
                        paCommentsType.ParameterName = "PICA_COMMENT_TYPE";
                        paCommentsType.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paCommentsType.OracleDbType = OracleDbType.Varchar2;
                        if (tanComments.Comments_Type.Count > 0)
                        {
                            paCommentsType.Value = tanComments.Comments_Type.ToArray();
                        }
                        else
                        {
                            paCommentsType.Value = new string[1] { "" };
                            paCommentsType.Size = 0;
                        }
                        oraCmd.Parameters.Add(paCommentsType);

                        OracleParameter paComments = new OracleParameter();
                        paComments.ParameterName = "PICA_TAN_COMMENT";
                        paComments.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paComments.OracleDbType = OracleDbType.Varchar2;
                        if (tanComments.TAN_Comments.Count > 0)
                        {

                            paComments.Value = tanComments.TAN_Comments.ToArray();
                        }
                        else
                        {
                            paComments.Value = new string[1] { "" };
                            paComments.Size = 0;
                        }
                        oraCmd.Parameters.Add(paComments);

                        oraCmd.Parameters.Add("PIN_CREATED_BY", OracleDbType.Int32).Value = tanComments.UR_ID;

                        dbCon.Open();
                        oraCmd.ExecuteNonQuery();
                        dbCon.Close();
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }

        #endregion

        #region Manage 8000 Series related methods

        public static DataTable GetSeries8000DetailsOnTAN(int tanID)
        {
            DataTable dtSer8000 = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_8000_SERIES_DTLS_ON_TAN";
                    oraCmd.CommandType = CommandType.StoredProcedure;

                    oraCmd.Parameters.Add("PIN_TAN_ID ", OracleDbType.Int32).Value = tanID;
                    oraCmd.Parameters.Add("PORC_8000_SERIES", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtSer8000 = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtSer8000);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtSer8000;
        }

        public static bool UpdateSeries8000DetailsOnTAN(ManageSeries8000 manageSer8000)
        {
            bool blStatus = false;
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oCmd = new OracleCommand())
                    {
                        oCmd.CommandText = "REACT.DML_TAN_SERIES_8000";
                        oCmd.CommandType = CommandType.StoredProcedure;
                        oCmd.Connection = dbCon;

                        oCmd.Parameters.Add("PIN_TS_ID ", OracleDbType.Int32).Value = manageSer8000.TS_ID;
                        oCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = manageSer8000.TAN_ID;
                        oCmd.Parameters.Add("PIN_SER8000", OracleDbType.Int32).Value = manageSer8000.Ser8000Val;
                        oCmd.Parameters.Add("PIC_SUBST_NAME", OracleDbType.Varchar2).Value = manageSer8000.SubstName;
                        oCmd.Parameters.Add("PIC_SUBST_LOC", OracleDbType.Varchar2).Value = manageSer8000.SubstLocation;
                        oCmd.Parameters.Add("PIC_SUBST_MOLE", OracleDbType.Clob).Value = manageSer8000.SubstMolecule;
                        oCmd.Parameters.Add("PIC_AUTHOR_NAME", OracleDbType.Varchar2).Value = manageSer8000.SubstAuthorName;
                        oCmd.Parameters.Add("PIC_OTHER_NAME", OracleDbType.Varchar2).Value = manageSer8000.SubstOtherName;
                        oCmd.Parameters.Add("PIC_OPTION", OracleDbType.Varchar2).Value = manageSer8000.Option;
                        oCmd.Parameters.Add("POC_STATUS", OracleDbType.Varchar2, 50).Direction = ParameterDirection.Output;

                        dbCon.Open();
                        oCmd.ExecuteNonQuery();
                        dbCon.Close();
                        if (oCmd.Parameters["POC_STATUS"].Value != null)
                        {
                            string strTemp = oCmd.Parameters["POC_STATUS"].Value.ToString();
                            blStatus = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return blStatus;
        }

        #endregion

        public static DataTable GetSeries9000OrgRefMasterData()
        {
            DataTable ser9000Data = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_ORGREF_DATA";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PORC_RESULTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    ser9000Data = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(ser9000Data);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ser9000Data;
        }

        #region Manage Series 8500 related methods

        public static DataTable GetOrgRefMasterDataOnNumType(int serval)
        {
            DataTable ser9000_8500Data = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_ORGREF_DATA_ON_NUM_TYPE";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_NUM", OracleDbType.Int32).Value = serval;
                    oraCmd.Parameters.Add("PORC_ORGREF_DTLS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    ser9000_8500Data = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(ser9000_8500Data);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ser9000_8500Data;
        }

        public static DataTable GetSeries8500DetailsOnTAN(ManageSeries8500 manageSer8500)
        {
            DataTable dtSer8500 = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_8500_SERIES_DTLS_ON_TAN";
                    oraCmd.CommandType = CommandType.StoredProcedure;

                    oraCmd.Parameters.Add("PIN_TAN_ID ", OracleDbType.Int32).Value = manageSer8500.TAN_ID;
                    oraCmd.Parameters.Add("PORC_8500_SERIES", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtSer8500 = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtSer8500);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtSer8500;
        }

        public static DataTable GetSavedSeriesDataOnTANAndSeriesValue(int tanid, int tsid, int servalue, int serType)
        {
            DataTable dtSeriesVals = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_SAVED_SERIES_ON_TAN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanid;
                    oraCmd.Parameters.Add("PIN_TS_ID", OracleDbType.Int32).Value = tsid;
                    oraCmd.Parameters.Add("PIN_SERIES_VALUE", OracleDbType.Int32).Value = servalue;
                    oraCmd.Parameters.Add("PIN_SER_TYPE", OracleDbType.Int32).Value = serType;
                    oraCmd.Parameters.Add("PORC_SAVED_SERIES", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtSeriesVals = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtSeriesVals);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtSeriesVals;
        }

        public static bool UpdateSeries8500DetailsOnTAN(ManageSeries8500 manageSer8500, out DataTable ser8500data_out)
        {
            bool blStatus = false;
            DataTable dtSer8500 = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.CommandText = "REACT.DML_TAN_SERIES_8500";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();

                    oraCmd.Parameters.Add("PIN_TS_ID ", OracleDbType.Int32).Value = manageSer8500.TS_ID;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = manageSer8500.TAN_ID;
                    oraCmd.Parameters.Add("PIN_ORGREF_ID", OracleDbType.Int32).Value = manageSer8500.OrgRefID;
                    oraCmd.Parameters.Add("PIN_SERIES_8500", OracleDbType.Int32).Value = manageSer8500.Ser8500Val;
                    oraCmd.Parameters.Add("PIC_OPTION", OracleDbType.Varchar2).Value = manageSer8500.Option;

                    oraCmd.Parameters.Add("POC_STATUS", OracleDbType.Varchar2, 100).Direction = ParameterDirection.Output;
                    oraCmd.Parameters.Add("PORC_SERIES_8500", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    dtSer8500 = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtSer8500);

                    if (oraCmd.Parameters["POC_STATUS"].Value != null)
                    {
                        string strTemp = oraCmd.Parameters["POC_STATUS"].Value.ToString();
                    }
                    blStatus = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            ser8500data_out = dtSer8500;
            return blStatus;
        }

        public static DataTable GetSeries8500DetailsOnTAN(int tanID)
        {
            DataTable dtSer8500 = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_TAN_8500_SERIES_ON_TANID";
                    oraCmd.CommandType = CommandType.StoredProcedure;

                    oraCmd.Parameters.Add("PIN_TAN_ID ", OracleDbType.Int32).Value = tanID;
                    oraCmd.Parameters.Add("PORC_TAN_8500_DLTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtSer8500 = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtSer8500);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtSer8500;
        }

        #endregion

        #region Search RegNos Methods

        public static DataTable GetRegNo_SubstNameSearchResults(int tanid, string seriestype, int seriesnumid)
        {
            DataTable dtResults = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_REGNO_SUBNSTNAME_SEARCH";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanid;
                    oraCmd.Parameters.Add("PIC_SER_TYPE", OracleDbType.Varchar2).Value = seriestype;
                    oraCmd.Parameters.Add("PIN_SERIES_ID", OracleDbType.Varchar2).Value = seriesnumid;
                    oraCmd.Parameters.Add("PORC_RESULTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtResults = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtResults);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtResults;
        }

        public static DataTable GetRegNoSubstNameSearchResults_Generic(int tanid, int regNo, string substName)
        {
            DataTable dtResults = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_REGNO_SUBNAME_SRCH_GENERIC";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanid;
                    oraCmd.Parameters.Add("PIN_REGNO", OracleDbType.Int32).Value = regNo;
                    oraCmd.Parameters.Add("PIC_SUBST_NAME", OracleDbType.Varchar2).Value = substName;
                    oraCmd.Parameters.Add("PORC_REGNO_SUBST_DTLS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtResults = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtResults);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtResults;
        }

        #endregion

        public static DataTable GetXMLConvDetails()
        {
            DataTable dtConvDetails = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "GET_XMLCONVERSION_DETAILS";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PORC_RESULTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    DataSet dsResults = new DataSet();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dsResults);
                    if (dsResults != null)
                    {
                        if (dsResults.Tables.Count > 0)
                        {
                            if (dsResults.Tables[0] != null)
                            {
                                dtConvDetails = dsResults.Tables[0];
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtConvDetails;
        }

        public static DataTable GetTANsOnShipmentName_TANType(string shipName, string tanType)
        {
            DataTable dtTAN_Names = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_TANS_BY_SHIPMENT_TAN_TYPE";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIC_SHIPMENT_NAME", OracleDbType.Varchar2).Value = shipName;
                    oraCmd.Parameters.Add("PIC_TAN_TYPE", OracleDbType.Varchar2).Value = tanType;
                    oraCmd.Parameters.Add("PORC_RECORDS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    DataTable dtResults = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtResults);

                    if (dtResults != null)
                    {
                        if (dtResults.Rows.Count > 0)
                        {

                            dtTAN_Names = dtResults;
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dtTAN_Names;
        }

        public static bool Update_TAN_Batch_Details(int batch_No, List<Int64> ltTAN_IDs)
        {
            bool blStatus = false;
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oCmd = new OracleCommand())
                    {
                        OracleParameter paTAN_Names = new OracleParameter();
                        paTAN_Names.ParameterName = "PINA_TAN_IDS";
                        paTAN_Names.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paTAN_Names.OracleDbType = OracleDbType.Int64;
                        if (ltTAN_IDs.Count > 0)
                        {

                            paTAN_Names.Value = ltTAN_IDs.ToArray();
                        }
                        else
                        {
                            paTAN_Names.Value = new Int32[1] { 0 };
                            paTAN_Names.Size = 0;
                        }
                        oCmd.Parameters.Add(paTAN_Names);
                        oCmd.Parameters.Add("PIN_BATCHNO", OracleDbType.Int32).Value = batch_No;


                        oCmd.CommandText = "REACT.UPDATE_TAN_BATCH_NO";
                        oCmd.CommandType = CommandType.StoredProcedure;
                        oCmd.Connection = dbCon;
                        dbCon.Open();
                        oCmd.ExecuteNonQuery();
                        dbCon.Close();
                        blStatus = true;
                    }
                }
            }

            catch (Exception ex)
            {
                blStatus = false;

            }

            return blStatus;
        }

        public static bool CheckInsert8500NrnRegData(string _tan, int _ser8500, int _nrnreg, string _descriptor)
        {
            bool blStatus = false;
            int rec_CNT = 0;
            string strMessage = null;
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oCmd = new OracleCommand())
                    {
                        OracleParameter[] oPrms = new OracleParameter[5];

                        oPrms[0] = new OracleParameter("PIC_TAN_NAME", OracleDbType.Varchar2, 20, _tan, ParameterDirection.Input);
                        oPrms[1] = new OracleParameter("PIN_SERIES8500", OracleDbType.Int32, 3, _ser8500, ParameterDirection.Input);
                        oPrms[2] = new OracleParameter("PIN_NRNREG", OracleDbType.Int32, 10, _nrnreg, ParameterDirection.Input);
                        oPrms[3] = new OracleParameter("PIC_DISCRIPTOR", OracleDbType.Varchar2, 10, _descriptor, ParameterDirection.Input);
                        oPrms[4] = new OracleParameter("POC_STATUS", OracleDbType.Varchar2, 10, null, ParameterDirection.Output);

                        oCmd.CommandText = "REACT.CHECK_INSERT_8500_NRNREG";
                        oCmd.CommandType = CommandType.StoredProcedure;
                        oCmd.Connection = dbCon;
                        oCmd.Parameters.AddRange(oPrms);

                        dbCon.Open();
                        oCmd.ExecuteNonQuery();
                        strMessage = oPrms[4].Value != null ? oPrms[4].Value.ToString() : null;
                        dbCon.Close();
                        if (strMessage == "SUCCESS")
                        {
                            blStatus = true;
                        }
                        else
                        {
                            blStatus = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return blStatus;
        }

        public static int DuplicateReactionData(int tanID, int rxnID_Old, int rxnnum_new, int rxnseq_new, int dispOrder, string seriesType, int serNUMId, int created_by, out int rxnseq_new_out)
        {
            int rxn_ID = 0;
            int rxn_seq = 0;
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oCmd = new OracleCommand())
                    {
                        oCmd.CommandText = "REACT.DUPLICATE_REACTION_DATA";
                        oCmd.CommandType = CommandType.StoredProcedure;
                        oCmd.Connection = dbCon;

                        OracleParameter[] oPrms = new OracleParameter[10];

                        oPrms[0] = new OracleParameter("PIN_RXN_ID_OLD", OracleDbType.Int32, rxnID_Old, ParameterDirection.Input);
                        oPrms[1] = new OracleParameter("PIN_TAN_ID", OracleDbType.Int32, tanID, ParameterDirection.Input);
                        oPrms[2] = new OracleParameter("PIN_RXN_NUM", OracleDbType.Int32, rxnnum_new, ParameterDirection.Input);
                        oPrms[3] = new OracleParameter("PIN_RXN_SEQ", OracleDbType.Int32, rxnseq_new, ParameterDirection.Input);

                        oPrms[4] = new OracleParameter("PIC_SERIES_TYPE", OracleDbType.Varchar2, 10, seriesType, ParameterDirection.Input);
                        oPrms[5] = new OracleParameter("PIN_NUM_ID", OracleDbType.Int32, serNUMId, ParameterDirection.Input);

                        oPrms[6] = new OracleParameter("PIN_DISPLAY_ORDER", OracleDbType.Int32, dispOrder, ParameterDirection.Input);
                        //oPrms[6] = new OracleParameter("PIC_BEFORE_AFTER", OracleDbType.Varchar2, 10, before_after, ParameterDirection.Input);
                        //oPrms[7] = new OracleParameter("PIN_BEFORE_AFTER_RXN_ID", OracleDbType.Int32, bef_aft_rxnID, ParameterDirection.Input);

                        oPrms[7] = new OracleParameter("PIN_UR_ID", OracleDbType.Int32, created_by, ParameterDirection.Input);
                        oPrms[8] = new OracleParameter("PON_RXN_ID_NEW", OracleDbType.Int32, ParameterDirection.Output);
                        oPrms[9] = new OracleParameter("PON_RXNSEQ_NEW", OracleDbType.Int32, ParameterDirection.Output);

                        oCmd.Parameters.AddRange(oPrms);

                        dbCon.Open();
                        oCmd.ExecuteNonQuery();
                        //if (oPrms[8].Value != null)
                        //{
                        //    rxn_ID = (Int32)oPrms[8].Value;
                        //}
                        rxn_ID = oPrms[8].Value != null ? Convert.ToInt32(oPrms[8].Value.ToString()) : 0;
                        rxn_seq = oPrms[9].Value != null ? Convert.ToInt32(oPrms[9].Value.ToString()) : 0;
                        dbCon.Close();
                    }

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            rxnseq_new_out = rxn_seq;
            return rxn_ID;
            #region MyRegion
            //NpgsqlConnection con = null;
            //try
            //{
            //    con = Connection.GetConnection();
            //    NpgsqlCommand cmd = new NpgsqlCommand();
            //    cmd.Connection = con;
            //    cmd.CommandText = "casrxn.duplicate_reaction_data";
            //    cmd.CommandType = System.Data.CommandType.StoredProcedure;

            //    NpgsqlParameter p_PatentID = new NpgsqlParameter();
            //    p_PatentID.ParameterName = "p_patent_id";
            //    p_PatentID.DbType = System.Data.DbType.Int32;
            //    p_PatentID.Value = _patent_id;
            //    cmd.Parameters.Add(p_PatentID);

            //    NpgsqlParameter p_RxnNum_Old = new NpgsqlParameter();
            //    p_RxnNum_Old.ParameterName = "p_rxnnum_old";
            //    p_RxnNum_Old.DbType = System.Data.DbType.Int32;
            //    p_RxnNum_Old.Value = _rxnnum_old;
            //    cmd.Parameters.Add(p_RxnNum_Old);

            //    NpgsqlParameter p_RxnSeq_Old = new NpgsqlParameter();
            //    p_RxnSeq_Old.ParameterName = "p_rxnseq_old";
            //    p_RxnSeq_Old.DbType = System.Data.DbType.Int32;
            //    p_RxnSeq_Old.Value = _rxnseq_old;
            //    cmd.Parameters.Add(p_RxnSeq_Old);

            //    NpgsqlParameter p_RxnNum_New = new NpgsqlParameter();
            //    p_RxnNum_New.ParameterName = "p_rxnnum_new";
            //    p_RxnNum_New.DbType = System.Data.DbType.Int32;
            //    p_RxnNum_New.Value = _rxnnum_new;
            //    cmd.Parameters.Add(p_RxnNum_New);

            //    NpgsqlParameter p_DispOrder = new NpgsqlParameter();
            //    p_DispOrder.ParameterName = "p_disp_order";
            //    p_DispOrder.DbType = System.Data.DbType.Int32;
            //    p_DispOrder.Value = _displayOrd;
            //    cmd.Parameters.Add(p_DispOrder);

            //    NpgsqlParameter p_Before_After = new NpgsqlParameter();
            //    p_Before_After.ParameterName = "p_before_after";
            //    p_Before_After.DbType = System.Data.DbType.String;
            //    p_Before_After.Value = _before_after;
            //    cmd.Parameters.Add(p_Before_After);

            //    NpgsqlParameter p_CreatedBy = new NpgsqlParameter();
            //    p_CreatedBy.ParameterName = "p_created_by";
            //    p_CreatedBy.DbType = System.Data.DbType.Int32;
            //    p_CreatedBy.Value = _created_by;
            //    cmd.Parameters.Add(p_CreatedBy);

            //    NpgsqlParameter p_Rxn_ID_New = new NpgsqlParameter();
            //    p_Rxn_ID_New.ParameterName = "po_rxn_id_new";
            //    p_Rxn_ID_New.DbType = System.Data.DbType.Int32;
            //    p_Rxn_ID_New.Direction = ParameterDirection.Output;
            //    cmd.Parameters.Add(p_Rxn_ID_New);

            //    NpgsqlParameter p_RxnSeq_New = new NpgsqlParameter();
            //    p_RxnSeq_New.ParameterName = "po_rxnseq_new";
            //    p_RxnSeq_New.DbType = System.Data.DbType.Int32;
            //    p_RxnSeq_New.Direction = ParameterDirection.Output;
            //    cmd.Parameters.Add(p_RxnSeq_New);

            //    con.Open();
            //    object objRetVal = cmd.ExecuteScalar();

            //    _rxnseq_new_out = Convert.ToInt32(p_RxnSeq_New.Value);
            //    return Convert.ToInt32(p_Rxn_ID_New.Value);
            //}
            //catch (NpgsqlException ex)
            //{
            //    con.Close();
            //    throw ex;
            //}
            //finally
            //{
            //    con.Close();
            //}
            //return 0; 
            #endregion
        }

        #region Export Methods

        public static DataTable GetConditionDataOnTAN(int tanID)
        {
            DataTable condsDtls = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_RXN_CONDITIONS_ON_TAN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Varchar2).Value = tanID;
                    oraCmd.Parameters.Add("PORC_RXN_CONDS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    condsDtls = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(condsDtls);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return condsDtls;


        }

        public static DataTable GetRSNDetailsOnTAN(int tanID)
        {
            DataTable rsnDetails = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_RSN_DETAILS_ON_TAN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Varchar2).Value = tanID;
                    oraCmd.Parameters.Add("PORC_RSN", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    rsnDetails = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(rsnDetails);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return rsnDetails;


        }

        public static DataTable GetProduct_ParticipantsDataOnTAN(int tanID)
        {
            DataTable prod_partpants = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_PP_DTLS_ON_TAN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;

                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanID;
                    oraCmd.Parameters.Add("PORC_PROD_PART_DTLS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    prod_partpants = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(prod_partpants);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return prod_partpants;
        }

        public static DataTable GetStagesOnTAN(int tanID)
        {
            DataTable stageDetails = null;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "REACT.GET_RXN_STAGES_ON_TAN_ID";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Varchar2).Value = tanID;
                        oraCmd.Parameters.Add("PORC_RESULTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                        stageDetails = new DataTable();
                        OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                        oraAdpt.Fill(stageDetails);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return stageDetails;


        }

        #endregion

        public static bool UpdateReactionStatusOnRole(ReactionsBO reaction)
        {
            bool blStatus = false;
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "REACT.UPDATE_RXN_STATUS";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        oraCmd.Parameters.Add("PIC_ROLE_NAME", OracleDbType.Varchar2).Value = reaction.UserRole;
                        oraCmd.Parameters.Add("PIN_RXN_ID", OracleDbType.Int32).Value = reaction.RXN_ID;
                        oraCmd.Parameters.Add("PIN_COMPLETED_BY_ID", OracleDbType.Int32).Value = reaction.UR_ID;
                        oraCmd.Parameters.Add("POC_STATUS", OracleDbType.Varchar2, 50).Direction = ParameterDirection.Output;

                        dbCon.Open();
                        oraCmd.ExecuteNonQuery();
                        dbCon.Close();
                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return blStatus;
        }

        public static DataTable GetDailyStatusReport(string application, DateTime statusDate)
        {
            DataTable dailyStatusRep = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "NARRATIVES.GET_DAILY_STATUS_CNT";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIC_APPLICATION_NAME", OracleDbType.Varchar2).Value = application;
                    oraCmd.Parameters.Add("PID_STATUS_DATE", OracleDbType.Date).Value = statusDate;
                    oraCmd.Parameters.Add("PORC_DAILY_STATUS_CNT", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dailyStatusRep = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dailyStatusRep);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dailyStatusRep;
        }

        public static DataTable GetMonthlyStatusReport(DateTime fromDate, DateTime toDate)
        {
            DataTable monthlyRep = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_DAILY_STATUS_REPORT";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PID_FROM_DATE", OracleDbType.Date).Value = fromDate;
                    oraCmd.Parameters.Add("PID_TO_DATE", OracleDbType.Date).Value = toDate;
                    oraCmd.Parameters.Add("PORC_RECORDS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    monthlyRep = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(monthlyRep);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return monthlyRep;
        }

        public static DataTable GetMultipleShipmentsStatusReport(List<int> shipmentIDs, int batchNo)
        {
            DataTable shipmentReport = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REPORTS.RXN_SHIPMENT_REPORT";
                    oraCmd.CommandType = CommandType.StoredProcedure;

                    OracleParameter paShipmentIDs = new OracleParameter();
                    paShipmentIDs.ParameterName = "PINA_SHIPMENT_ID";
                    paShipmentIDs.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                    paShipmentIDs.OracleDbType = OracleDbType.Int32;
                    paShipmentIDs.Value = shipmentIDs.Count > 0 ? shipmentIDs.ToArray() : new Int32[1] { 0 };
                    oraCmd.Parameters.Add(paShipmentIDs);

                    oraCmd.Parameters.Add("PIN_BATCH_NO", OracleDbType.Int32).Value = batchNo;
                    oraCmd.Parameters.Add("PORC_RXN_SHP_REPORT", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    shipmentReport = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(shipmentReport);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return shipmentReport;
        }

        #region Temperature Comments Methods

        public static DataTable GetPlusOrMinusTemperatureData(int tanID)
        {
            DataTable plusminusTemps = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_RXN_COND_TEMP_ON_TAN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanID;
                    oraCmd.Parameters.Add("PORC_TEMP_DLTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    plusminusTemps = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(plusminusTemps);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return plusminusTemps;
        }

        public static DataTable Get8000And8500ValuesOnTAN_ID(int tanID)
        {
            DataTable serVals = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_SER_TYPE_DLTS_ON_TAN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanID;
                    oraCmd.Parameters.Add("PORC_SER_TYPE_DLTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    serVals = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(serVals);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return serVals;
        }

        public static DataTable GetReactantsOnTAN_ID(int tanID)
        {
            DataTable serVals = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_REACTANT_ON_TAN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanID;
                    oraCmd.Parameters.Add("PORC_RECTANTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    serVals = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(serVals);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return serVals;
        }

        #endregion

        #region TAN Keyword Search Methods

        public static DataTable GetDictionaryTermsOnType(string dictType)
        {
            DataTable dtUserDict = null;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "REACT.GET_RSN_FREE_USER_DICT_DETAILS";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Parameters.Add("PIC_DICT_TYPE", OracleDbType.Varchar2).Value = dictType;
                        oraCmd.Parameters.Add("PORC_USER_DICT", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                        dtUserDict = new DataTable();
                        OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                        oraAdpt.Fill(dtUserDict);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtUserDict;
        }

        #endregion

        #endregion

        #region FreeText Dictionary

        public static string UpdateFreeTextDictionary(DictionaryTerm dictTerm, out DataTable ser8500data_out)
        {
            string strStatus = "";
            DataTable dtFreeText = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.CommandText = "REACT.DML_DICT_TERM_KEYWORDS";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();

                    oraCmd.Parameters.Add("PIN_DTK_ID ", OracleDbType.Int32).Value = dictTerm.DTK_ID;
                    oraCmd.Parameters.Add("PIC_DTK_TYPE", OracleDbType.Varchar2).Value = dictTerm.DTK_Type;
                    oraCmd.Parameters.Add("PIC_DTK_VALUE", OracleDbType.Varchar2).Value = dictTerm.DTK_Value;
                    oraCmd.Parameters.Add("PIC_OPTION", OracleDbType.Varchar2).Value = dictTerm.Option;

                    oraCmd.Parameters.Add("POC_STATUS", OracleDbType.Varchar2, 100).Direction = ParameterDirection.Output;
                    oraCmd.Parameters.Add("PORC_TERM_KEYWORDS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    dtFreeText = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtFreeText);

                    if (oraCmd.Parameters["POC_STATUS"].Value != null)
                    {
                        strStatus = oraCmd.Parameters["POC_STATUS"].Value.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            ser8500data_out = dtFreeText;
            return strStatus;
        }

        #endregion

        #region New Methods for handling arrays

        public static bool UpdateProduct_ParticipantsData_Array(Product_ParticipantsArr prod_partpnt)
        {
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "REACT.UPDATE_RXN_PARTICIPANTS";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        oraCmd.Parameters.Add("PIN_RXN_ID", OracleDbType.Int32).Value = prod_partpnt.ReactionID;

                        OracleParameter paRPPIDs = new OracleParameter();
                        paRPPIDs.ParameterName = "PINA_RPP_ID";
                        paRPPIDs.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRPPIDs.OracleDbType = OracleDbType.Int32;
                        paRPPIDs.Value = prod_partpnt.RPP_ID.Count > 0 ? prod_partpnt.RPP_ID.ToArray() : new Int32[1] { 0 };
                        oraCmd.Parameters.Add(paRPPIDs);

                        OracleParameter paRxnStageIDs = new OracleParameter();
                        paRxnStageIDs.ParameterName = "PINA_RXN_STAGE_ID";
                        paRxnStageIDs.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRxnStageIDs.OracleDbType = OracleDbType.Int32;
                        if (prod_partpnt.RxnStageID.Count > 0)
                        {
                            paRxnStageIDs.Value = prod_partpnt.RxnStageID.ToArray();
                        }
                        else
                        {
                            paRxnStageIDs.Value = new Int32[1] { 0 };
                            paRxnStageIDs.Size = 0;
                        }
                        oraCmd.Parameters.Add(paRxnStageIDs);

                        OracleParameter paPPType = new OracleParameter();
                        paPPType.ParameterName = "PICA_PP_TYPE";
                        paPPType.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paPPType.OracleDbType = OracleDbType.Varchar2;
                        paPPType.Value = prod_partpnt.PPType.Count > 0 ? prod_partpnt.PPType.ToArray() : new string[1] { "" };
                        oraCmd.Parameters.Add(paPPType);

                        OracleParameter paSerType = new OracleParameter();
                        paSerType.ParameterName = "PICA_SER_TYPE";
                        paSerType.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paSerType.OracleDbType = OracleDbType.Varchar2;
                        paSerType.Value = prod_partpnt.SeriesType.Count > 0 ? prod_partpnt.SeriesType.ToArray() : new string[1] { "" };
                        oraCmd.Parameters.Add(paSerType);

                        OracleParameter paSerNumIDs = new OracleParameter();
                        paSerNumIDs.ParameterName = "PINA_SER_TAN_NUM_ID";
                        paSerNumIDs.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paSerNumIDs.OracleDbType = OracleDbType.Int32;
                        paSerNumIDs.Value = prod_partpnt.SeriesNumID.Count > 0 ? prod_partpnt.SeriesNumID.ToArray() : new Int32[1] { 0 };
                        oraCmd.Parameters.Add(paSerNumIDs);

                        OracleParameter paYield = new OracleParameter();
                        paYield.ParameterName = "PICA_YIELD";
                        paYield.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paYield.OracleDbType = OracleDbType.Varchar2;
                        paYield.Value = prod_partpnt.Yield.Count > 0 ? prod_partpnt.Yield.ToArray() : new string[1] { "" };
                        oraCmd.Parameters.Add(paYield);

                        OracleParameter paDispOrder = new OracleParameter();
                        paDispOrder.ParameterName = "PINA_DISPLAY_ORDER";
                        paDispOrder.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paDispOrder.OracleDbType = OracleDbType.Int32;
                        paDispOrder.Value = prod_partpnt.DisplayOrder.Count > 0 ? prod_partpnt.DisplayOrder.ToArray() : new Int32[1] { 0 };
                        oraCmd.Parameters.Add(paDispOrder);

                        oraCmd.Parameters.Add("POC_STATUS", OracleDbType.Varchar2, 100).Direction = ParameterDirection.Output;

                        dbCon.Open();
                        oraCmd.ExecuteNonQuery();
                        dbCon.Close();
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return false;
        }

        public static bool UpdateConditionsData_Array(RxnConditionArr conditions)
        {
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "REACT.UPDATE_RXN_CONDITION";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        OracleParameter paRSNIDs = new OracleParameter();
                        paRSNIDs.ParameterName = "PINA_RC_ID";
                        paRSNIDs.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRSNIDs.OracleDbType = OracleDbType.Int32;
                        paRSNIDs.Value = conditions.RC_ID.Count > 0 ? conditions.RC_ID.ToArray() : new Int32[1] { 0 };
                        oraCmd.Parameters.Add(paRSNIDs);

                        OracleParameter paRxnStageIDs = new OracleParameter();
                        paRxnStageIDs.ParameterName = "PINA_RXN_STAGE_ID";
                        paRxnStageIDs.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRxnStageIDs.OracleDbType = OracleDbType.Int32;
                        paRxnStageIDs.Value = conditions.RxnStageID.Count > 0 ? conditions.RxnStageID.ToArray() : new Int32[1] { 0 };
                        oraCmd.Parameters.Add(paRxnStageIDs);

                        OracleParameter paTemp = new OracleParameter();
                        paTemp.ParameterName = "PICA_TEMPERATURE";
                        paTemp.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paTemp.OracleDbType = OracleDbType.Varchar2;
                        paTemp.Value = conditions.Temperature.Count > 0 ? conditions.Temperature.ToArray() : new string[1] { "" };
                        oraCmd.Parameters.Add(paTemp);

                        OracleParameter paPressure = new OracleParameter();
                        paPressure.ParameterName = "PICA_PRESSURE";
                        paPressure.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paPressure.OracleDbType = OracleDbType.Varchar2;
                        paPressure.Value = conditions.Pressure.Count > 0 ? conditions.Pressure.ToArray() : new string[1] { "" };
                        oraCmd.Parameters.Add(paPressure);

                        OracleParameter paPH = new OracleParameter();
                        paPH.ParameterName = "PICA_PH";
                        paPH.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paPH.OracleDbType = OracleDbType.Varchar2;
                        paPH.Value = conditions.pH.Count > 0 ? conditions.pH.ToArray() : new string[1] { "" };
                        oraCmd.Parameters.Add(paPH);

                        OracleParameter paTime = new OracleParameter();
                        paTime.ParameterName = "PICA_RC_TIME";
                        paTime.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paTime.OracleDbType = OracleDbType.Varchar2;
                        paTime.Value = conditions.Time.Count > 0 ? conditions.Time.ToArray() : new string[1] { "" };
                        oraCmd.Parameters.Add(paTime);

                        OracleParameter paTempType = new OracleParameter();
                        paTempType.ParameterName = "PICA_TEMP_TYPE";
                        paTempType.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paTempType.OracleDbType = OracleDbType.Varchar2;
                        paTempType.Value = conditions.TempType.Count > 0 ? conditions.TempType.ToArray() : new string[1] { "" };
                        oraCmd.Parameters.Add(paTempType);

                        OracleParameter paTimeType = new OracleParameter();
                        paTimeType.ParameterName = "PICA_TIME_TYPE";
                        paTimeType.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paTimeType.OracleDbType = OracleDbType.Varchar2;
                        paTimeType.Value = conditions.TimeType.Count > 0 ? conditions.TimeType.ToArray() : new string[1] { "" };
                        oraCmd.Parameters.Add(paTimeType);

                        OracleParameter paPhType = new OracleParameter();
                        paPhType.ParameterName = "PICA_PH_TYPE";
                        paPhType.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paPhType.OracleDbType = OracleDbType.Varchar2;
                        paPhType.Value = conditions.PHType.Count > 0 ? conditions.PHType.ToArray() : new string[1] { "" };
                        oraCmd.Parameters.Add(paPhType);

                        OracleParameter paPresType = new OracleParameter();
                        paPresType.ParameterName = "PICA_PRESSURE_TYPE";
                        paPresType.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paPresType.OracleDbType = OracleDbType.Varchar2;
                        paPresType.Value = conditions.PressureType.Count > 0 ? conditions.PressureType.ToArray() : new string[1] { "" };
                        oraCmd.Parameters.Add(paPresType);

                        OracleParameter paDispOrder = new OracleParameter();
                        paDispOrder.ParameterName = "PINA_DISPLAY_ORDER";
                        paDispOrder.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paDispOrder.OracleDbType = OracleDbType.Int32;
                        paDispOrder.Value = conditions.DisplayOrder.Count > 0 ? conditions.DisplayOrder.ToArray() : new Int32[1] { 0 };
                        oraCmd.Parameters.Add(paDispOrder);

                        //oraCmd.Parameters.Add("POC_STATUS", OracleDbType.Varchar2, 100).Direction = ParameterDirection.Output;

                        dbCon.Open();
                        oraCmd.ExecuteNonQuery();
                        dbCon.Close();
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }

        public static bool UpdateRSNData_Array(RxnSearchNoteArr rsn)
        {
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "REACT.UPDATE_RXN_SEARCH_NOTE";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        OracleParameter paRSNIDs = new OracleParameter();
                        paRSNIDs.ParameterName = "PINA_RSN_ID";
                        paRSNIDs.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRSNIDs.OracleDbType = OracleDbType.Int32;
                        paRSNIDs.Value = rsn.RSN_ID.Count > 0 ? rsn.RSN_ID.ToArray() : new Int32[1] { 0 };
                        oraCmd.Parameters.Add(paRSNIDs);

                        OracleParameter paRxnStageIDs = new OracleParameter();
                        paRxnStageIDs.ParameterName = "PINA_RXN_STAGE_ID";
                        paRxnStageIDs.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRxnStageIDs.OracleDbType = OracleDbType.Int32;
                        paRxnStageIDs.Value = rsn.RxnStageID.Count > 0 ? rsn.RxnStageID.ToArray() : new Int32[1] { 0 };
                        oraCmd.Parameters.Add(paRxnStageIDs);

                        OracleParameter paCVT = new OracleParameter();
                        paCVT.ParameterName = "PICA_CVT";
                        paCVT.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paCVT.OracleDbType = OracleDbType.Varchar2;
                        paCVT.Value = rsn.CVT.Count > 0 ? rsn.CVT.ToArray() : new string[1] { "" };
                        oraCmd.Parameters.Add(paCVT);

                        OracleParameter paFreeText = new OracleParameter();
                        paFreeText.ParameterName = "PICA_FREE_TEXT";
                        paFreeText.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFreeText.OracleDbType = OracleDbType.Varchar2;
                        paFreeText.Value = rsn.FreeText.Count > 0 ? rsn.FreeText.ToArray() : new string[1] { "" };
                        oraCmd.Parameters.Add(paFreeText);

                        OracleParameter paNoteLevel = new OracleParameter();
                        paNoteLevel.ParameterName = "PICA_NOTE_LEVEL";
                        paNoteLevel.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paNoteLevel.OracleDbType = OracleDbType.Varchar2;
                        paNoteLevel.Value = rsn.NoteLevel.Count > 0 ? rsn.NoteLevel.ToArray() : new string[1] { "" };
                        oraCmd.Parameters.Add(paNoteLevel);

                        OracleParameter paDispOrder = new OracleParameter();
                        paDispOrder.ParameterName = "PINA_DISPLAY_ORDER";
                        paDispOrder.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paDispOrder.OracleDbType = OracleDbType.Int32;
                        paDispOrder.Value = rsn.DisplayOrder.Count > 0 ? rsn.DisplayOrder.ToArray() : new Int32[1] { 0 };
                        oraCmd.Parameters.Add(paDispOrder);

                        //oraCmd.Parameters.Add("POC_STATUS", OracleDbType.Varchar2, 100).Direction = ParameterDirection.Output;

                        dbCon.Open();
                        oraCmd.ExecuteNonQuery();
                        dbCon.Close();
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }

        #endregion

        public static DataTable GetToolManagerFinalChecks(string selectedOpt, string shipmentName, int batchNo)
        {
            DataTable dtFinalChecks = null;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "REACT.FINAL_CHECK_GET_DATA";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Parameters.Add("PIC_DATA_FOR", OracleDbType.Varchar2).Value = selectedOpt;
                        oraCmd.Parameters.Add("PIC_SHIPMENT_NAME", OracleDbType.Varchar2).Value = shipmentName;
                        oraCmd.Parameters.Add("PIN_BATCH_NO", OracleDbType.Int32).Value = batchNo;
                        oraCmd.Parameters.Add("PORC_DATA", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                        dtFinalChecks = new DataTable();
                        OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                        oraAdpt.Fill(dtFinalChecks);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtFinalChecks;
        }

        public static bool MoveTansToAnotherBatch(List<int> liTanIDS, string batchNo)
        {
            bool blStatus = false;
            try
            {

                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "REACT.UPDATE_TAN_BATCH_NO";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        OracleParameter paShipmentIDs = new OracleParameter();
                        paShipmentIDs.ParameterName = "PINA_TAN_IDS";
                        paShipmentIDs.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paShipmentIDs.OracleDbType = OracleDbType.Int32;
                        paShipmentIDs.Value = liTanIDS.Count > 0 ? liTanIDS.ToArray() : new Int32[1] { 0 };
                        oraCmd.Parameters.Add(paShipmentIDs);

                        oraCmd.Parameters.Add("PIN_BATCH_NO", OracleDbType.Int32).Value = batchNo;

                        dbCon.Open();
                        oraCmd.ExecuteNonQuery();
                        dbCon.Close();
                        blStatus = true;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return blStatus;

        }

        public static DataTable GetRxnNumSeqOnTanID(int tanID)
        {
            DataTable dtNumSeq = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REACT.GET_RXN_NUM_SEQ_ON_TAN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanID;
                    oraCmd.Parameters.Add("PORC_RESULTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtNumSeq = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtNumSeq);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dtNumSeq;
        }
    }
}
