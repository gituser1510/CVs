﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Oracle.ManagedDataAccess.Client;
using IndxReactNarrBll;

namespace IndxReactNarrDAL
{
    /// <summary>
    ///  Class to do operations releated task management activities.
    /// </summary>
    public class TaskManagementDB
    {
        /// <summary>
        /// Get User tasks by userid & role id
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <param name="roleId">Role ID</param>
        /// <returns>Data Table: User Tasks by RoleId and User Id</returns>
        public static DataTable GetUserTasksOnModule(int userRoleId, string application, string module)
        {
            DataTable dtUserTasks = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "TASK_MANAGEMENT.GET_USER_TASKS";
                    oraCmd.CommandType = CommandType.StoredProcedure;

                    oraCmd.Parameters.Add("PIC_APPLICATION", OracleDbType.Varchar2).Value = application;
                    oraCmd.Parameters.Add("PIC_MODULE", OracleDbType.Varchar2).Value = module;
                    oraCmd.Parameters.Add("PIN_UR_ID", OracleDbType.Int32).Value = userRoleId;
                    oraCmd.Parameters.Add("PORC_RECORDS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                   
                    dtUserTasks = new DataTable();                   
                    using (OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd))
                    {
                        oraAdpt.Fill(dtUserTasks);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtUserTasks;
        }

        /// <summary>
        /// Update Task Status
        /// </summary>
        /// <param name="taskStatus"></param>
        /// <returns>true/false</returns>
        public static bool UpdateUserTaskStatus(TaskStatus taskStatus)
        {
            bool blStatus = false;
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "TASK_MANAGEMENT.UPDATE_TASK_STATUS";
                        //oraCmd.CommandText = "TASK_MANAGEMENT_TS.UPDATE_TASK_STATUS";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        oraCmd.Parameters.Add("PIN_TASK_ID", OracleDbType.Int32).Value = taskStatus.Task_ID;
                        oraCmd.Parameters.Add("PIN_TASK_ALLOC_ID", OracleDbType.Int32).Value = taskStatus.TaskAllocation_ID;
                        oraCmd.Parameters.Add("PIN_ROLE_ID", OracleDbType.Int32).Value = taskStatus.UR_ID;
                        oraCmd.Parameters.Add("PIC_STATUS", OracleDbType.Varchar2).Value = taskStatus.TaskStatusName;
                        oraCmd.Parameters.Add("PIC_REMARKS", OracleDbType.Varchar2).Value = taskStatus.TaskComments;

                        dbCon.Open();
                        oraCmd.ExecuteNonQuery();
                        dbCon.Close();
                        blStatus = true;                       
                    }
                }
            }
            catch (Exception ex)
            {
                blStatus = false;
            }
            return blStatus;
        }

        /// <summary>
        /// Update Task Assignment details
        /// </summary>
        /// <param name="application"></param>
        /// <param name="module"></param>
        /// <param name="shipmentID"></param>
        /// <param name="teamUserID"></param>
        /// <param name="tanIDs"></param>
        /// <returns></returns>
        public static bool UpdateTaskAssignmentDetails(string application, string module, int shipmentID, long teamUserID, List<Int32> tanIDs)
        {
            bool blStatus = false;
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "TASK_MANAGEMENT.TASK_ALLOC_TO_CURATION";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        oraCmd.Parameters.Add("PIC_APPLICATION", OracleDbType.Varchar2).Value = application;
                        oraCmd.Parameters.Add("PIC_MODULE", OracleDbType.Varchar2).Value = module;
                        oraCmd.Parameters.Add("PIN_SHIPMENT_ID", OracleDbType.Int32).Value = shipmentID;
                        oraCmd.Parameters.Add("PIN_TEAM_USER_ID", OracleDbType.Int32).Value = teamUserID;

                        OracleParameter paTANIDs = new OracleParameter();
                        paTANIDs.ParameterName = "PINA_TAN_IDS";
                        paTANIDs.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paTANIDs.OracleDbType = OracleDbType.Int64;
                        if (tanIDs.Count > 0)
                        {

                            paTANIDs.Value = tanIDs.ToArray();
                        }
                        else
                        {
                            paTANIDs.Value = new Int32[1] { 0 };
                            paTANIDs.Size = 0;
                        }
                        oraCmd.Parameters.Add(paTANIDs);

                        dbCon.Open();
                        oraCmd.ExecuteNonQuery();
                        dbCon.Close();
                        blStatus = true;
                    }
                }
            }

            catch (Exception ex)
            {
                blStatus = false;
            }
            return blStatus;
        }

        /// <summary>
        /// Gets Assigned TANs in the Shipment
        /// </summary>
        /// <param name="application"></param>
        /// <param name="module"></param>
        /// <param name="shipmentID"></param>
        /// <param name="batchNo"></param>
        /// <returns>Datatable</returns>
        public static DataTable GetAssignedTANsOnShipment(string application, string module, int shipmentID, int batchNo)
        {
            DataTable dtTANs = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "TASK_MANAGEMENT.GET_BATCH_TAN_DETAILS";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIC_APPLICATION", OracleDbType.Varchar2).Value = application;
                    oraCmd.Parameters.Add("PIC_MODULE", OracleDbType.Varchar2).Value = module;
                    oraCmd.Parameters.Add("PIN_SHIPMENT_ID", OracleDbType.Int32).Value = shipmentID;
                    oraCmd.Parameters.Add("PIN_BATCH_NO", OracleDbType.Int32).Value = batchNo;
                    oraCmd.Parameters.Add("PORC_TAN_DETAILS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtTANs = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtTANs);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtTANs;
        }

        #region Task Modification & Cancel Methods

        public static DataTable GetUserAssignedTasks(int userRoleId)
        {
            DataTable dtUserTasks = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "TASK_MANAGEMENT.MT_GET_USER_TASKS";
                    oraCmd.CommandType = CommandType.StoredProcedure;

                    oraCmd.Parameters.Add("PIN_UR_ID", OracleDbType.Int32).Value = userRoleId;
                    oraCmd.Parameters.Add("PORC_USER_TASKS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    dtUserTasks = new DataTable();
                    using (OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd))
                    {
                        oraAdpt.Fill(dtUserTasks);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtUserTasks;
        }

        public static bool CancelTaskAssignment(List<Int32> taskIDs)
        {
            bool blStatus = false;
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "TASK_MANAGEMENT.MT_CANCEL_TASKS";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        OracleParameter paTaskID = new OracleParameter();
                        paTaskID.ParameterName = "PIAN_TASK_IDS";
                        paTaskID.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paTaskID.OracleDbType = OracleDbType.Int64;
                        if (taskIDs.Count > 0)
                        {
                            paTaskID.Value = taskIDs.ToArray();
                        }
                        else
                        {
                            paTaskID.Value = new Int32[1] { 0 };
                            paTaskID.Size = 0;
                        }
                        oraCmd.Parameters.Add(paTaskID);

                        oraCmd.Parameters.Add("POC_STATUS", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

                        dbCon.Open();
                        oraCmd.ExecuteNonQuery();
                        dbCon.Close();

                        if (oraCmd.Parameters["POC_STATUS"].Value != null)
                        {
                            if (oraCmd.Parameters["POC_STATUS"].Value.ToString() == "SUCCESS")
                            {
                                blStatus = true;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                blStatus = false;
            }
            return blStatus;
        }

        public static bool ModifyTaskAssignment(List<Int32> taskAllocIDs, int userRoleID, int toolMgrURID)
        {
            bool blStatus = false;
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "TASK_MANAGEMENT.MT_REASSIGN_REFS";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        OracleParameter paAllocID = new OracleParameter();
                        paAllocID.ParameterName = "PIAN_TASK_ALLOC_IDS";
                        paAllocID.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paAllocID.OracleDbType = OracleDbType.Int64;
                        if (taskAllocIDs.Count > 0)
                        {
                            paAllocID.Value = taskAllocIDs.ToArray();
                        }
                        else
                        {
                            paAllocID.Value = new Int32[1] { 0 };
                            paAllocID.Size = 0;
                        }
                        oraCmd.Parameters.Add(paAllocID);

                        oraCmd.Parameters.Add("PIN_UR_ID", OracleDbType.Int32).Value = userRoleID;
                        oraCmd.Parameters.Add("PIN_PM_UR_ID", OracleDbType.Int32).Value = toolMgrURID;
                        oraCmd.Parameters.Add("POC_STATUS", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

                        dbCon.Open();
                        oraCmd.ExecuteNonQuery();
                        dbCon.Close();

                        //if (oraCmd.Parameters["POC_STATUS"].Value != null)
                        //{
                        //    if (oraCmd.Parameters["POC_STATUS"].Value.ToString() == "SUCCESS")
                        //   {
                        blStatus = true;
                        //    }
                        //}
                    }
                }
            }
            catch (Exception ex)
            {
                blStatus = false;
            }
            return blStatus;
        }

        public static DataTable GetUsersTaskCountsOnRole(string application, string module, int RoleId)
        {
            DataTable dtResult = null;
            try
            {
                using (OracleConnection conn = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand command = conn.CreateCommand())
                    {
                        command.CommandText = "TASK_MANAGEMENT.MT_GET_USER_DETAILS";
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.Add("PIC_APPLICATION", OracleDbType.Varchar2, application, ParameterDirection.Input);
                        command.Parameters.Add("PIC_MODULE", OracleDbType.Varchar2, module, ParameterDirection.Input);
                        command.Parameters.Add("PIN_ROLE_ID", OracleDbType.Int32, RoleId, ParameterDirection.Input);
                        command.Parameters.Add("PORC_USER_DETAILS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                        using (OracleDataAdapter dataAdapter = new OracleDataAdapter(command))
                        {
                            dtResult = new DataTable("UserDetails");
                            try
                            {
                                dataAdapter.Fill(dtResult);
                            }
                            catch (OracleException)
                            {
                                throw;
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return dtResult;
        }

        #endregion
    }
}
