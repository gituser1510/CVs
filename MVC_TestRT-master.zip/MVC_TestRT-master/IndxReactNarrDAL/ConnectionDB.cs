﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Oracle.ManagedDataAccess.Client;
using System.Configuration;

namespace IndxReactNarrDAL
{   
    public class ConnectionDB
    {                       
        /// <summary>
        /// Gets an instance of oracle connection.
        /// </summary>
        /// <returns></returns>
        public static OracleConnection GetOracleConnection()
        {           
            return new OracleConnection(GetConnectionString());
        }

        /// <summary>
        /// Gets an instance of oracle connection string.
        /// </summary>
        public static string GetConnectionString()
        {
            string conString = string.Format("Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST={0})(PORT={1})))"
            + "(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME={2})));User Id={3};Password={4}; "
            + " Connection Timeout=60;Validate Connection = true; Pooling = false", AppConfiguration.Host, AppConfiguration.Port,
            AppConfiguration.Database, AppConfiguration.UserName, AppConfiguration.Password);

            //string conString = string.Format("Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST={0})(PORT={1})))"
            //+ "(CONNECT_DATA=(SERVER=DEDICATED)(SID={2})));User Id={3};Password={4}; "
            //+ " Connection Timeout=60;Validate Connection = true; Pooling = false", AppConfiguration.Host, AppConfiguration.Port,
            //AppConfiguration.Database, AppConfiguration.UserName, AppConfiguration.Password);

            return conString;
        }
    }
}
