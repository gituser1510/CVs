﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Oracle.ManagedDataAccess.Client;

namespace IndxReactNarrDAL
{
    public class DeliveryManagementDB
    {
        public static DataTable GetDeliveries(string AppName)
        {
            DataTable dtDeliveries = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "DELIVERY_PKG.GET_DELIVERIES";
                    oraCmd.CommandType = CommandType.StoredProcedure;

                    oraCmd.Parameters.Add("PIC_APPLICATION", OracleDbType.Varchar2).Value = AppName;
                    oraCmd.Parameters.Add("PORC_DELIVERIES", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                   
                    dtDeliveries = new DataTable();                   
                    using (OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd))
                    {
                        oraAdpt.Fill(dtDeliveries);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtDeliveries;
           
        }

        public static DataTable GetDeliveriesTansByDeliveryID(int DELIVERY_ID)
        {
            DataTable dtDeliveryTans = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "DELIVERY_PKG.GET_DELIVERED_TANS";
                    oraCmd.CommandType = CommandType.StoredProcedure;

                    oraCmd.Parameters.Add("PIN_DELIVERY_ID", OracleDbType.Int32).Value = DELIVERY_ID;
                    oraCmd.Parameters.Add("PORC_TANS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    dtDeliveryTans = new DataTable();
                    using (OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd))
                    {
                        oraAdpt.Fill(dtDeliveryTans);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtDeliveryTans;
        }
    }
}
