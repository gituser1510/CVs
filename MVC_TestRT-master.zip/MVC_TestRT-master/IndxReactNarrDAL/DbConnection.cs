﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Oracle.DataAccess.Client;

namespace IndxReactNarrDAL
{
    public class DbConnection
    {
        static string conHostName = "172.21.0.45";
        static string conPort = "1522";
        static string conDatabase = "SCIBASE_PROD_NEW";
        static string dbUserName = "DAT_PROD";
        static string dbPwd = "DAT_PROD";
        static string conString = "";

        public static OracleConnection GetOracleConnection()
        {
            OracleConnection con = null;
            try
            {
                //conString = string.Format("Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST={0})(PORT={1})))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME={2})));User Id={3};Password={4};"
                //+ " Connection Timeout=60;Validate Connection = true", conHostName, conPort, conDatabase, dbUserName, dbPwd);

                con = new OracleConnection("User Id=CAS_IRN_DEV;Password=CAS_IRN_DEV;Data source=GOSTAR_CORP;");
                //con = new OracleConnection(conString); 
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return con;
        }
    }
}
