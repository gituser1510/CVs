﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IndxReactNarrBll;
using Oracle.ManagedDataAccess.Client;

namespace IndxReactNarrDAL
{
    public class ShipmentMasterDB
    {
        public static bool UpdateIndexingShipmentData(ShipmentMasterBO indxShipment)
        {
            bool blStatus = false;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "SHIPMENT_MANAGEMENT.UPDATE_INDX_SHIPMENT_DATA";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        oraCmd.Parameters.Add("PIC_APPLICATION_NAME", OracleDbType.Varchar2).Value = indxShipment.Application;
                        oraCmd.Parameters.Add("PIC_SHIPMENT_NAME", OracleDbType.Varchar2).Value = indxShipment.ShipmentName;
                       
                        OracleParameter paTANs = new OracleParameter();
                        paTANs.ParameterName = "PICA_TAN";
                        paTANs.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paTANs.OracleDbType = OracleDbType.Varchar2;
                        if (indxShipment.Shipment_TANs != null)
                        {
                            if (indxShipment.Shipment_TANs.Length > 0)
                            {
                                paTANs.Value = indxShipment.Shipment_TANs;
                            }
                            else
                            {
                                paTANs.Value = new string[1] { "" };
                                paTANs.Size = 0;
                            }
                        }
                        else
                        {
                            paTANs.Value = new string[1] { "" };
                            paTANs.Size = 0;
                        }
                        oraCmd.Parameters.Add(paTANs);

                        OracleParameter paCAN = new OracleParameter();
                        paCAN.ParameterName = "PICA_CAN";
                        paCAN.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paCAN.OracleDbType = OracleDbType.Varchar2;
                        if (indxShipment.TAN_CAN != null)
                        {
                            if (indxShipment.TAN_CAN.Length > 0)
                            {
                                paCAN.Value = indxShipment.TAN_CAN;
                            }
                            else
                            {
                                paCAN.Value = new string[1] { "" };
                                paCAN.Size = 0;
                            }
                        }
                        else
                        {
                            paCAN.Value = new string[1] { "" };
                            paCAN.Size = 0;
                        }
                        oraCmd.Parameters.Add(paCAN);

                        OracleParameter paTANType = new OracleParameter();
                        paTANType.ParameterName = "PICA_TAN_TYPE";
                        paTANType.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paTANType.OracleDbType = OracleDbType.Varchar2;
                        if (indxShipment.TAN_Type != null)
                        {
                            if (indxShipment.TAN_Type.Length > 0)
                            {
                                paTANType.Value = indxShipment.TAN_Type;
                            }
                            else
                            {
                                paTANType.Value = new string[1] { "" };
                                paTANType.Size = 0;
                            }
                        }
                        else
                        {
                            paTANType.Value = new string[1] { "" };
                            paTANType.Size = 0;
                        }
                        oraCmd.Parameters.Add(paTANType);                       

                        OracleParameter paJournal = new OracleParameter();
                        paJournal.ParameterName = "PICA_JOURNAL_NAME";
                        paJournal.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paJournal.OracleDbType = OracleDbType.Varchar2;
                        if (indxShipment.Journals != null)
                        {
                            if (indxShipment.Journals.Length > 0)
                            {
                                paJournal.Value = indxShipment.Journals;
                            }
                            else
                            {
                                paJournal.Value = new string[1] { "" };
                                paJournal.Size = 0;
                            }
                        }
                        else
                        {
                            paJournal.Value = new string[1] { "" };
                            paJournal.Size = 0;
                        }
                        oraCmd.Parameters.Add(paJournal);

                        OracleParameter paIssue = new OracleParameter();
                        paIssue.ParameterName = "PICA_ISSUE";
                        paIssue.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paIssue.OracleDbType = OracleDbType.Varchar2;
                        if (indxShipment.Issue != null)
                        {
                            if (indxShipment.Issue.Length > 0)
                            {
                                paIssue.Value = indxShipment.Issue;
                            }
                            else
                            {
                                paIssue.Value = new string[1] { null };
                                paIssue.Size = 0;
                            }
                        }
                        else
                        {
                            paIssue.Value = new string[1] { null };
                            paIssue.Size = 0;
                        }
                        oraCmd.Parameters.Add(paIssue);

                        OracleParameter paYear = new OracleParameter();
                        paYear.ParameterName = "PICA_YEAR ";
                        paYear.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paYear.OracleDbType = OracleDbType.Varchar2;
                        if (indxShipment.Year != null)
                        {
                            if (indxShipment.Year.Length > 0)
                            {
                                paYear.Value = indxShipment.Year;
                            }
                            else
                            {
                                paYear.Value = new string[1] { null };
                                paIssue.Size = 0;
                            }
                        }
                        else
                        {
                            paYear.Value = new string[1] { null };
                            paYear.Size = 0;
                        }
                        oraCmd.Parameters.Add(paYear);

                        OracleParameter paSection = new OracleParameter();
                        paSection.ParameterName = "PINA_SECTION ";
                        paSection.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paSection.OracleDbType = OracleDbType.Int32;
                        if (indxShipment.Section != null)
                        {
                            if (indxShipment.Section.Length > 0)
                            {
                                paSection.Value = indxShipment.Section;
                            }
                            else
                            {
                                paSection.Value = new string[1] { null };
                                paSection.Size = 0;
                            }
                        }
                        else
                        {
                            paSection.Value = new string[1] { null };
                            paSection.Size = 0;
                        }
                        oraCmd.Parameters.Add(paSection);

                        OracleParameter paTitle = new OracleParameter();
                        paTitle.ParameterName = "PICA_TITLE";
                        paTitle.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paTitle.OracleDbType = OracleDbType.Varchar2;
                        if (indxShipment.Title != null)
                        {
                            if (indxShipment.Title.Length > 0)
                            {
                                paTitle.Value = indxShipment.Title;
                            }
                            else
                            {
                                paTitle.Value = new string[1] { null };
                                paTitle.Size = 0;
                            }
                        }
                        else
                        {
                            paTitle.Value = new string[1] { null };
                            paTitle.Size = 0;
                        }
                        oraCmd.Parameters.Add(paTitle);

                        OracleParameter paAbstract = new OracleParameter();
                        paAbstract.ParameterName = "PICA_ABSTRACT";
                        paAbstract.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paAbstract.OracleDbType = OracleDbType.Varchar2;
                        if (indxShipment.Abstract != null)
                        {
                            if (indxShipment.Title.Length > 0)
                            {
                                paAbstract.Value = indxShipment.Abstract;
                            }
                            else
                            {
                                paAbstract.Value = new string[1] { null };
                                paAbstract.Size = 0;
                            }
                        }
                        else
                        {
                            paAbstract.Value = new string[1] { null };
                            paAbstract.Size = 0;
                        }
                        oraCmd.Parameters.Add(paAbstract);

                        OracleParameter paLanguage = new OracleParameter();
                        paLanguage.ParameterName = "PICA_LANGUAGE";
                        paLanguage.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paLanguage.OracleDbType = OracleDbType.Varchar2;
                        if (indxShipment.Language != null)
                        {
                            if (indxShipment.Language.Length > 0)
                            {
                                paLanguage.Value = indxShipment.Language;
                            }
                            else
                            {
                                paLanguage.Value = new string[1] { null };
                                paLanguage.Size = 0;
                            }
                        }
                        else
                        {
                            paLanguage.Value = new string[1] { null };
                            paLanguage.Size = 0;
                        }
                        oraCmd.Parameters.Add(paLanguage);

                        oraCmd.Parameters.Add("PIN_CREATED_BY", OracleDbType.Int32).Value = indxShipment.UR_ID;

                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();

                        oraCon.Close();
                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return blStatus;
        }

        public static string UpdateMacro_OrganicShipmentData_Xml(Macro_OrgIndxShipment indxShipment)
        {
            string strStatus = "";
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "SHIPMENT_MANAGEMENT.UPDATE_INDX_SHIPMENT_DATA_XML";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        oraCmd.Parameters.Add("PIC_APPLICATION_NAME", OracleDbType.Varchar2).Value = indxShipment.Application;
                        oraCmd.Parameters.Add("PIC_SHIPMENT_NAME", OracleDbType.Varchar2).Value = indxShipment.ShipmentName;
                        oraCmd.Parameters.Add("PIC_TAN", OracleDbType.Varchar2).Value = indxShipment.TAN;
                        oraCmd.Parameters.Add("PIC_CAN", OracleDbType.Varchar2).Value = indxShipment.CAN;
                        oraCmd.Parameters.Add("PIC_TAN_TYPE", OracleDbType.Varchar2).Value = indxShipment.TANType;
                        oraCmd.Parameters.Add("PIC_JOURNAL_NAME", OracleDbType.Varchar2).Value = indxShipment.JournalName;
                        oraCmd.Parameters.Add("PIC_ISSUE", OracleDbType.Varchar2).Value = indxShipment.Issue;
                        oraCmd.Parameters.Add("PIC_YEAR", OracleDbType.Varchar2).Value = indxShipment.Year;
                        oraCmd.Parameters.Add("PIN_SECTION", OracleDbType.Varchar2).Value = indxShipment.Section;
                        oraCmd.Parameters.Add("PIC_TITLE", OracleDbType.Varchar2).Value = indxShipment.Title;
                        oraCmd.Parameters.Add("PIC_ABSTRACT", OracleDbType.Varchar2).Value = indxShipment.Abstract;
                        oraCmd.Parameters.Add("PIC_LANGUAGE", OracleDbType.Varchar2).Value = indxShipment.Language;

                        OracleParameter paFileNames = new OracleParameter();
                        paFileNames.ParameterName = "PICA_FILENAME";
                        paFileNames.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFileNames.OracleDbType = OracleDbType.Varchar2;
                        if (indxShipment.FileNameList != null && indxShipment.FileNameList.Count > 0)
                        {
                            paFileNames.Value = indxShipment.FileNameList.ToArray();
                        }
                        else
                        {
                            paFileNames.Value = new string[1] { "" };
                            paFileNames.Size = 0;
                        }
                        oraCmd.Parameters.Add(paFileNames);

                        OracleParameter paFileTypes = new OracleParameter();
                        paFileTypes.ParameterName = "PICA_FILETYPE";
                        paFileTypes.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFileTypes.OracleDbType = OracleDbType.Varchar2;
                        if (indxShipment.FileTypeList != null && indxShipment.FileTypeList.Count > 0)
                        {
                            paFileTypes.Value = indxShipment.FileTypeList.ToArray();
                        }
                        else
                        {
                            paFileTypes.Value = new string[1] { "" };
                            paFileTypes.Size = 0;
                        }
                        oraCmd.Parameters.Add(paFileTypes);

                        OracleParameter paFileUUIDs = new OracleParameter();
                        paFileUUIDs.ParameterName = "PICA_FILE_UUID";
                        paFileUUIDs.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFileUUIDs.OracleDbType = OracleDbType.Varchar2;
                        if (indxShipment.FileUUIdList != null && indxShipment.FileUUIdList.Count > 0)
                        {
                            paFileUUIDs.Value = indxShipment.FileUUIdList.ToArray();
                        }
                        else
                        {
                            paFileUUIDs.Value = new string[1] { "" };
                            paFileUUIDs.Size = 0;
                        }
                        oraCmd.Parameters.Add(paFileUUIDs);

                        oraCmd.Parameters.Add("PIN_CREATED_BY", OracleDbType.Int32).Value = indxShipment.UR_ID;

                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        oraCon.Close();

                        strStatus = "Insert Success";
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return strStatus;
        }

        public static string UpdateNarrativesShipmentData(NarrShipmentMasterBO narrShipment)
        {          
            string strStatus = "";
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "SHIPMENT_MANAGEMENT.UPDATE_NAR_SHIPMENT_DATA";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        oraCmd.Parameters.Add("PIC_APPLICATION_NAME", OracleDbType.Varchar2).Value = narrShipment.Application;
                        oraCmd.Parameters.Add("PIC_SHIPMENT_NAME", OracleDbType.Varchar2).Value = narrShipment.ShipmentName;                        
                        oraCmd.Parameters.Add("PIC_TAN", OracleDbType.Varchar2).Value = narrShipment.TAN;
                        oraCmd.Parameters.Add("PIC_TAN_TYPE", OracleDbType.Varchar2).Value = narrShipment.TANType;
                        oraCmd.Parameters.Add("PIC_CAN", OracleDbType.Varchar2).Value = narrShipment.CAN;
                        oraCmd.Parameters.Add("PIC_DOI", OracleDbType.Varchar2).Value = narrShipment.DOI;                       

                        OracleParameter paRxnNum = new OracleParameter();
                        paRxnNum.ParameterName = "PINA_RXN_NUM";
                        paRxnNum.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRxnNum.OracleDbType = OracleDbType.Int32;
                        if (narrShipment.RXN_NUMList != null)
                        {
                            if (narrShipment.RXN_NUMList.Count > 0)
                            {
                                paRxnNum.Value = narrShipment.RXN_NUMList.ToArray();
                            }
                            else
                            {
                                paRxnNum.Value = new string[1] { "" };
                                paRxnNum.Size = 0;
                            }
                        }
                        else
                        {
                            paRxnNum.Value = new string[1] { "" };
                            paRxnNum.Size = 0;
                        }
                        oraCmd.Parameters.Add(paRxnNum);

                        OracleParameter paRxnSeq = new OracleParameter();
                        paRxnSeq.ParameterName = "PINA_RXN_SEQ";
                        paRxnSeq.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRxnSeq.OracleDbType = OracleDbType.Int32;
                        if (narrShipment.RXN_SEQList != null)
                        {
                            if (narrShipment.RXN_SEQList.Count > 0)
                            {
                                paRxnSeq.Value = narrShipment.RXN_SEQList.ToArray();
                            }
                            else
                            {
                                paRxnSeq.Value = new string[1] { "" };
                                paRxnSeq.Size = 0;
                            }
                        }
                        else
                        {
                            paRxnSeq.Value = new string[1] { "" };
                            paRxnSeq.Size = 0;
                        }
                        oraCmd.Parameters.Add(paRxnSeq);

                        OracleParameter paFileName = new OracleParameter();
                        paFileName.ParameterName = "PICA_FILENAME";
                        paFileName.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFileName.OracleDbType = OracleDbType.Varchar2;
                        if (narrShipment.FileNameList != null)
                        {
                            if (narrShipment.FileNameList.Count > 0)
                            {
                                paFileName.Value = narrShipment.FileNameList.ToArray();
                            }
                            else
                            {
                                paFileName.Value = new string[1] { "" };
                                paFileName.Size = 0;
                            }
                        }
                        else
                        {
                            paFileName.Value = new string[1] { "" };
                            paFileName.Size = 0;
                        }
                        oraCmd.Parameters.Add(paFileName);

                        OracleParameter paFileType = new OracleParameter();
                        paFileType.ParameterName = "PICA_FILETYPE";
                        paFileType.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFileType.OracleDbType = OracleDbType.Varchar2;
                        if (narrShipment.FileTypeList != null)
                        {
                            if (narrShipment.FileTypeList.Count > 0)
                            {
                                paFileType.Value = narrShipment.FileTypeList.ToArray();
                            }
                            else
                            {
                                paFileType.Value = new string[1] { "" };
                                paFileType.Size = 0;
                            }
                        }
                        else
                        {
                            paFileType.Value = new string[1] { "" };
                            paFileType.Size = 0;
                        }
                        oraCmd.Parameters.Add(paFileType);

                        oraCmd.Parameters.Add("PIN_CREATED_BY", OracleDbType.Int32).Value = narrShipment.UR_ID;

                        OracleParameter pStatus = new OracleParameter();
                        pStatus.ParameterName = "POC_STATUS";
                        pStatus.Size = 100;
                        pStatus.OracleDbType = OracleDbType.Varchar2;
                        pStatus.Direction = ParameterDirection.Output;
                        oraCmd.Parameters.Add(pStatus);      

                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        oraCon.Close();

                        if (pStatus.Value != null)
                        {
                            strStatus = pStatus.Value.ToString().ToUpper();           
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return strStatus;
        }

        public static string UpdateReactShipmentData(ReactShipmentMasterBO reactShipment)
        {
            string strStatus = "";
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "SHIPMENT_MANAGEMENT.UPDATE_REACT_SHIPMENT_DATA";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        oraCmd.Parameters.Add("PIC_APPLICATION_NAME", OracleDbType.Varchar2).Value = reactShipment.Application;
                        oraCmd.Parameters.Add("PIC_SHIPMENT_NAME", OracleDbType.Varchar2).Value = reactShipment.ShipmentName;
                        oraCmd.Parameters.Add("PIC_TAN", OracleDbType.Varchar2).Value = reactShipment.TAN;
                        oraCmd.Parameters.Add("PIC_CAN", OracleDbType.Varchar2).Value = reactShipment.CAN;
                        oraCmd.Parameters.Add("PIC_TAN_TYPE", OracleDbType.Varchar2).Value = reactShipment.TANType;

                        oraCmd.Parameters.Add("PIC_JOURNAL_NAME", OracleDbType.Varchar2).Value = reactShipment.JournalName;
                        oraCmd.Parameters.Add("PIC_ISSUE", OracleDbType.Varchar2).Value = reactShipment.IssueName;
                        oraCmd.Parameters.Add("PIC_JOURNAL_YEAR", OracleDbType.Varchar2).Value = reactShipment.JournalYear;

                        OracleParameter paNum = new OracleParameter();
                        paNum.ParameterName = "PINA_NUM";
                        paNum.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paNum.OracleDbType = OracleDbType.Int32;
                        if (reactShipment.NUM != null)
                        {
                            if (reactShipment.NUM.Length > 0)
                            {
                                paNum.Value = reactShipment.NUM;
                            }
                            else
                            {
                                paNum.Value = new string[1] { "" };
                                paNum.Size = 0;
                            }
                        }
                        else
                        {
                            paNum.Value = new string[1] { "" };
                            paNum.Size = 0;
                        }
                        oraCmd.Parameters.Add(paNum);

                        OracleParameter paRegNo = new OracleParameter();
                        paRegNo.ParameterName = "PINA_REGNO";
                        paRegNo.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRegNo.OracleDbType = OracleDbType.Int32;
                        if (reactShipment.REG_NO != null)
                        {
                            if (reactShipment.REG_NO.Length > 0)
                            {
                                paRegNo.Value = reactShipment.REG_NO;
                            }
                            else
                            {
                                paRegNo.Value = new string[1] { "" };
                                paRegNo.Size = 0;
                            }
                        }
                        else
                        {
                            paRegNo.Value = new string[1] { "" };
                            paRegNo.Size = 0;
                        }
                        oraCmd.Parameters.Add(paRegNo);

                        OracleParameter paFormula = new OracleParameter();
                        paFormula.ParameterName = "PICA_FORMULA";
                        paFormula.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFormula.OracleDbType = OracleDbType.Varchar2;
                        if (reactShipment.Formula != null)
                        {
                            if (reactShipment.Formula.Length > 0)
                            {
                                paFormula.Value = reactShipment.Formula;
                            }
                            else
                            {
                                paFormula.Value = new string[1] { "" };
                                paFormula.Size = 0;
                            }
                        }
                        else
                        {
                            paFormula.Value = new string[1] { "" };
                            paFormula.Size = 0;
                        }
                        oraCmd.Parameters.Add(paFormula);

                        OracleParameter paIUPAC = new OracleParameter();
                        paIUPAC.ParameterName = "PICA_IUPAC_NAME";
                        paIUPAC.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paIUPAC.OracleDbType = OracleDbType.Varchar2;
                        if (reactShipment.IUPACName != null)
                        {
                            if (reactShipment.IUPACName.Length > 0)
                            {
                                paIUPAC.Value = reactShipment.IUPACName;
                            }
                            else
                            {
                                paIUPAC.Value = new string[1] { "" };
                                paIUPAC.Size = 0;
                            }
                        }
                        else
                        {
                            paIUPAC.Value = new string[1] { "" };
                            paIUPAC.Size = 0;
                        }
                        oraCmd.Parameters.Add(paIUPAC);

                        OracleParameter paPepSeq = new OracleParameter();
                        paPepSeq.ParameterName = "PICA_PEPTIDE_SEQ";
                        paPepSeq.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paPepSeq.OracleDbType = OracleDbType.Varchar2;
                        if (reactShipment.PeptideSeq != null)
                        {
                            if (reactShipment.PeptideSeq.Length > 0)
                            {
                                paPepSeq.Value = reactShipment.PeptideSeq;
                            }
                            else
                            {
                                paPepSeq.Value = new string[1] { "" };
                                paPepSeq.Size = 0;
                            }
                        }
                        else
                        {
                            paPepSeq.Value = new string[1] { "" };
                            paPepSeq.Size = 0;
                        }
                        oraCmd.Parameters.Add(paPepSeq);

                        OracleParameter paNuclicSeq = new OracleParameter();
                        paNuclicSeq.ParameterName = "PICA_NUCLIC_ACID_SEQ";
                        paNuclicSeq.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paNuclicSeq.OracleDbType = OracleDbType.Varchar2;
                        if (reactShipment.NuclicAcidSeq != null)
                        {
                            if (reactShipment.NuclicAcidSeq.Length > 0)
                            {
                                paNuclicSeq.Value = reactShipment.NuclicAcidSeq;
                            }
                            else
                            {
                                paNuclicSeq.Value = new string[1] { "" };
                                paNuclicSeq.Size = 0;
                            }
                        }
                        else
                        {
                            paNuclicSeq.Value = new string[1] { "" };
                            paNuclicSeq.Size = 0;
                        }
                        oraCmd.Parameters.Add(paNuclicSeq);

                        OracleParameter paOtherNames = new OracleParameter();
                        paOtherNames.ParameterName = "PICA_OTHER_NAMES";
                        paOtherNames.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paOtherNames.OracleDbType = OracleDbType.Varchar2;
                        if (reactShipment.OtherNames != null)
                        {
                            if (reactShipment.OtherNames.Length > 0)
                            {
                                paOtherNames.Value = reactShipment.OtherNames;
                            }
                            else
                            {
                                paOtherNames.Value = new string[1] { "" };
                                paOtherNames.Size = 0;
                            }
                        }
                        else
                        {
                            paOtherNames.Value = new string[1] { "" };
                            paOtherNames.Size = 0;
                        }
                        oraCmd.Parameters.Add(paOtherNames);

                        OracleParameter paMolHexCode = new OracleParameter();
                        paMolHexCode.ParameterName = "PICA_MOL_HEX_CODE";
                        paMolHexCode.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paMolHexCode.OracleDbType = OracleDbType.Varchar2;
                        if (reactShipment.MolHexCode != null)
                        {
                            if (reactShipment.MolHexCode.Length > 0)
                            {
                                paMolHexCode.Value = reactShipment.MolHexCode;
                            }
                            else
                            {
                                paMolHexCode.Value = new string[1] { "" };
                                paMolHexCode.Size = 0;
                            }
                        }
                        else
                        {
                            paMolHexCode.Value = new string[1] { "" };
                            paMolHexCode.Size = 0;
                        }
                        oraCmd.Parameters.Add(paMolHexCode);

                        OracleParameter paAbsStereo = new OracleParameter();
                        paAbsStereo.ParameterName = "PICA_ABSOLUTE_STEREO";
                        paAbsStereo.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paAbsStereo.OracleDbType = OracleDbType.Varchar2;
                        if (reactShipment.AbsStereo != null && reactShipment.AbsStereo.Length > 0)
                        {
                            paAbsStereo.Value = reactShipment.AbsStereo;
                        }
                        else
                        {
                            paIUPAC.Value = new string[1] { "" };
                            paIUPAC.Size = 0;
                        }
                        oraCmd.Parameters.Add(paAbsStereo);

                        oraCmd.Parameters.Add("PIN_CREATED_BY", OracleDbType.Int32).Value = reactShipment.UR_ID;

                        OracleParameter pStatus = new OracleParameter();
                        pStatus.ParameterName = "POC_STATUS";
                        pStatus.Size = 100;
                        pStatus.OracleDbType = OracleDbType.Varchar2;
                        pStatus.Direction = ParameterDirection.Output;
                        oraCmd.Parameters.Add(pStatus);

                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        oraCon.Close();

                        if (pStatus.Value != null)
                        {
                            strStatus = pStatus.Value.ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return strStatus;
        }

        public static bool CheckForDuplicateShipment(ShipmentMasterBO shipMaster)
        {
            bool blStatus = false;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "SHIPMENT_MANAGEMENT.CHECK_DUPLICATE_SHIPMENT";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        oraCmd.Parameters.Add("PIC_SHIPMENT_NAME", OracleDbType.Varchar2).Value = shipMaster.ShipmentName;
                        oraCmd.Parameters.Add("PIC_APPLICATION_NAME", OracleDbType.Varchar2).Value = shipMaster.Application;

                        OracleParameter pStatus = new OracleParameter();
                        pStatus.ParameterName = "POC_RESULT";
                        pStatus.Size = 100;
                        pStatus.OracleDbType = OracleDbType.Varchar2;
                        pStatus.Direction = ParameterDirection.Output;
                        oraCmd.Parameters.Add(pStatus);      

                        oraCon.Open();
                         oraCmd.ExecuteScalar();
                         if (pStatus.Value != null)
                         {
                             if (pStatus.Value.ToString().ToUpper() == "DUPLICATE SHIPMENT NAME")
                             {
                                 blStatus = true;
                             }
                         }
                    }
                }
            }
            catch (Exception ex)
            {                
                throw ex;
            }            
            return blStatus;
        }

        public static DataTable GetTANsForExportOnApp_Shipment(string applicationName, string shipmentName, int batchNo)
        {
            DataTable tanDtls = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "SHIPMENT_MANAGEMENT.GET_TANS_FOR_EXP_ON_APP_SHIP";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIC_APPLICATION_NAME", OracleDbType.Varchar2).Value = applicationName;
                    oraCmd.Parameters.Add("PIC_SHIPMENT_NAME", OracleDbType.Varchar2).Value = shipmentName;
                    oraCmd.Parameters.Add("PIN_BATCH_NO", OracleDbType.Int32).Value = batchNo;
                    oraCmd.Parameters.Add("PORC_TANS_EXPORT", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    tanDtls = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(tanDtls);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return tanDtls;
        }

        public static string UpdateExperimentalProceduresShipmentData(ExpProcedures narrShipment, string shipmentName, string applicationName)
        {
            string strStatus = "";
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "SHIPMENT_MANAGEMENT.UPDATE_EXPPROC_SHIPMENT_DATA";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        oraCmd.Parameters.Add("PIC_APPLICATION_NAME", OracleDbType.Varchar2).Value = applicationName;
                        oraCmd.Parameters.Add("PIC_SHIPMENT_NAME", OracleDbType.Varchar2).Value = shipmentName;
                        oraCmd.Parameters.Add("PIC_TAN", OracleDbType.Varchar2).Value = narrShipment.TAN;
                        oraCmd.Parameters.Add("PIC_TAN_TYPE", OracleDbType.Varchar2).Value = narrShipment.Doc_Type;
                        oraCmd.Parameters.Add("PIC_CAN", OracleDbType.Varchar2).Value = narrShipment.CAN;
                        oraCmd.Parameters.Add("PIC_DOI", OracleDbType.Varchar2).Value = narrShipment.DOI;

                        oraCmd.Parameters.Add("PIN_DOC_SEQ", OracleDbType.Int32).Value = narrShipment.DocSeq;
                        oraCmd.Parameters.Add("PIC_CODEN", OracleDbType.Varchar2).Value = narrShipment.CODEN;
                        oraCmd.Parameters.Add("PIC_PUBLISHER", OracleDbType.Varchar2).Value = narrShipment.Publisher_Family;

                        OracleParameter paRxnNum = new OracleParameter();
                        paRxnNum.ParameterName = "PINA_RXN_NUM";
                        paRxnNum.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRxnNum.OracleDbType = OracleDbType.Int32;
                        if (narrShipment.RXN_NUM != null && narrShipment.RXN_NUM.Count > 0)
                        {
                            paRxnNum.Value = narrShipment.RXN_NUM.ToArray();
                        }
                        else
                        {
                            paRxnNum.Value = new string[1] { "" };
                            paRxnNum.Size = 0;
                        }
                        oraCmd.Parameters.Add(paRxnNum);

                        OracleParameter paRxnSeq = new OracleParameter();
                        paRxnSeq.ParameterName = "PINA_RXN_SEQ";
                        paRxnSeq.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRxnSeq.OracleDbType = OracleDbType.Int32;
                        if (narrShipment.RXN_Seq != null && narrShipment.RXN_Seq.Count > 0)
                        {
                            paRxnSeq.Value = narrShipment.RXN_Seq.ToArray();
                        }
                        else
                        {
                            paRxnSeq.Value = new string[1] { "" };
                            paRxnSeq.Size = 0;
                        }
                        oraCmd.Parameters.Add(paRxnSeq);

                        OracleParameter paRxnIdentifier = new OracleParameter();
                        paRxnIdentifier.ParameterName = "PINA_RXN_IDENTIFIER";
                        paRxnIdentifier.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRxnIdentifier.OracleDbType = OracleDbType.Int32;
                        if (narrShipment.RXN_Id != null && narrShipment.RXN_Id.Count > 0)
                        {
                            paRxnIdentifier.Value = narrShipment.RXN_Id.ToArray();
                        }
                        else
                        {
                            paRxnIdentifier.Value = new string[1] { "" };
                            paRxnIdentifier.Size = 0;
                        }
                        oraCmd.Parameters.Add(paRxnIdentifier);

                        OracleParameter paSubstId = new OracleParameter();
                        paSubstId.ParameterName = "PICA_RXN_SUBST_ID";
                        paSubstId.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paSubstId.OracleDbType = OracleDbType.Varchar2;
                        if (narrShipment.SubstIds != null && narrShipment.SubstIds.Count > 0)
                        {
                            paSubstId.Value = narrShipment.SubstIds.ToArray();
                        }
                        else
                        {
                            paSubstId.Value = new string[1] { "" };
                            paSubstId.Size = 0;
                        }
                        oraCmd.Parameters.Add(paSubstId);

                        OracleParameter paSubstRegNo = new OracleParameter();
                        paSubstRegNo.ParameterName = "PICA_RXN_SUBST_REGNO";
                        paSubstRegNo.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paSubstRegNo.OracleDbType = OracleDbType.Varchar2;
                        if (narrShipment.SubstRegNos != null && narrShipment.SubstRegNos.Count > 0)
                        {
                            paSubstRegNo.Value = narrShipment.SubstRegNos.ToArray();
                        }
                        else
                        {
                            paSubstRegNo.Value = new string[1] { "" };
                            paSubstRegNo.Size = 0;
                        }
                        oraCmd.Parameters.Add(paSubstRegNo);

                        OracleParameter paSubstRole = new OracleParameter();
                        paSubstRole.ParameterName = "PICA_RXN_SUBST_ROLE";
                        paSubstRole.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paSubstRole.OracleDbType = OracleDbType.Varchar2;
                        if (narrShipment.SubstRoles != null && narrShipment.SubstRoles.Count > 0)
                        {
                            paSubstRole.Value = narrShipment.SubstRoles.ToArray();
                        }
                        else
                        {
                            paSubstRole.Value = new string[1] { "" };
                            paSubstRole.Size = 0;
                        }
                        oraCmd.Parameters.Add(paSubstRole);
                        
                        OracleParameter paFileName = new OracleParameter();
                        paFileName.ParameterName = "PICA_FILENAME";
                        paFileName.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFileName.OracleDbType = OracleDbType.Varchar2;
                        if (narrShipment.File_Name != null && narrShipment.File_Name.Count > 0)
                        {
                            paFileName.Value = narrShipment.File_Name.ToArray();
                        }
                        else
                        {
                            paFileName.Value = new string[1] { "" };
                            paFileName.Size = 0;
                        }
                        oraCmd.Parameters.Add(paFileName);

                        OracleParameter paFileType = new OracleParameter();
                        paFileType.ParameterName = "PICA_FILETYPE";
                        paFileType.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFileType.OracleDbType = OracleDbType.Varchar2;
                        if (narrShipment.File_Type != null && narrShipment.File_Type.Count > 0)
                        {
                            paFileType.Value = narrShipment.File_Type.ToArray();
                        }
                        else
                        {
                            paFileType.Value = new string[1] { "" };
                            paFileType.Size = 0;
                        }
                        oraCmd.Parameters.Add(paFileType);

                        OracleParameter paFileIdentifier = new OracleParameter();
                        paFileIdentifier.ParameterName = "PICA_FILEIDENTIFIER";
                        paFileIdentifier.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFileIdentifier.OracleDbType = OracleDbType.Varchar2;
                        if (narrShipment.File_Id != null && narrShipment.File_Id.Count > 0)
                        {
                            paFileIdentifier.Value = narrShipment.File_Id.ToArray();
                        }
                        else
                        {
                            paFileIdentifier.Value = new string[1] { "" };
                            paFileIdentifier.Size = 0;
                        }
                        oraCmd.Parameters.Add(paFileIdentifier);

                        OracleParameter paFileUUID = new OracleParameter();
                        paFileUUID.ParameterName = "PICA_FILE_UUID";
                        paFileUUID.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFileUUID.OracleDbType = OracleDbType.Varchar2;
                        if (narrShipment.File_UUID != null && narrShipment.File_UUID.Count > 0)
                        {
                            paFileUUID.Value = narrShipment.File_UUID.ToArray();
                        }
                        else
                        {
                            paFileUUID.Value = new string[1] { "" };
                            paFileUUID.Size = 0;
                        }
                        oraCmd.Parameters.Add(paFileUUID);

                        oraCmd.Parameters.Add("PIN_CREATED_BY", OracleDbType.Int32).Value = narrShipment.UR_ID;

                        OracleParameter pStatus = new OracleParameter();
                        pStatus.ParameterName = "POC_STATUS";
                        pStatus.Size = 100;
                        pStatus.OracleDbType = OracleDbType.Varchar2;
                        pStatus.Direction = ParameterDirection.Output;
                        oraCmd.Parameters.Add(pStatus);

                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        oraCon.Close();

                        if (pStatus.Value != null)
                        {
                            strStatus = pStatus.Value.ToString().ToUpper();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return strStatus;
        }

        //New validation on 19th Feb 2016
        public static string UpdateExperimentalProcedures_NarrativesShipmentData(ExpProcedures expProcShipment, string shipmentName, string applicationName)
        {
            string strStatus = "";
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "SHIPMENT_MANAGEMENT.UPDATE_EXPPROC_SHIPMENT_DATA_N";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        oraCmd.Parameters.Add("PIC_APPLICATION_NAME", OracleDbType.Varchar2).Value = applicationName;
                        oraCmd.Parameters.Add("PIC_SHIPMENT_NAME", OracleDbType.Varchar2).Value = shipmentName;
                        oraCmd.Parameters.Add("PIC_TAN", OracleDbType.Varchar2).Value = expProcShipment.TAN;
                        oraCmd.Parameters.Add("PIC_TAN_TYPE", OracleDbType.Varchar2).Value = expProcShipment.Doc_Type;
                        oraCmd.Parameters.Add("PIC_CAN", OracleDbType.Varchar2).Value = expProcShipment.CAN;
                        oraCmd.Parameters.Add("PIC_DOI", OracleDbType.Varchar2).Value = expProcShipment.DOI;

                        oraCmd.Parameters.Add("PIN_DOC_SEQ", OracleDbType.Int32).Value = expProcShipment.DocSeq;
                        oraCmd.Parameters.Add("PIC_CODEN", OracleDbType.Varchar2).Value = expProcShipment.CODEN;
                        oraCmd.Parameters.Add("PIC_PUBLISHER", OracleDbType.Varchar2).Value = expProcShipment.Publisher_Family;

                        OracleParameter paRxnNum = new OracleParameter();
                        paRxnNum.ParameterName = "PINA_RXN_NUM";
                        paRxnNum.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRxnNum.OracleDbType = OracleDbType.Int32;
                        if (expProcShipment.RXN_NUM != null && expProcShipment.RXN_NUM.Count > 0)
                        {
                            paRxnNum.Value = expProcShipment.RXN_NUM.ToArray();
                        }
                        else
                        {
                            paRxnNum.Value = new string[1] { "" };
                            paRxnNum.Size = 0;
                        }
                        oraCmd.Parameters.Add(paRxnNum);

                        OracleParameter paRxnSeq = new OracleParameter();
                        paRxnSeq.ParameterName = "PINA_RXN_SEQ";
                        paRxnSeq.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRxnSeq.OracleDbType = OracleDbType.Int32;
                        if (expProcShipment.RXN_Seq != null && expProcShipment.RXN_Seq.Count > 0)
                        {
                            paRxnSeq.Value = expProcShipment.RXN_Seq.ToArray();
                        }
                        else
                        {
                            paRxnSeq.Value = new string[1] { "" };
                            paRxnSeq.Size = 0;
                        }
                        oraCmd.Parameters.Add(paRxnSeq);

                        OracleParameter paRxnNarID = new OracleParameter();
                        paRxnNarID.ParameterName = "PICA_RXN_NAR_ID";
                        paRxnNarID.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRxnNarID.OracleDbType = OracleDbType.Varchar2;
                        if (expProcShipment.RxnNarIDList != null && expProcShipment.RxnNarIDList.Count > 0)
                        {
                            paRxnNarID.Value = expProcShipment.RxnNarIDList.ToArray();
                        }
                        else
                        {
                            paRxnNarID.Value = new string[1] { "" };
                            paRxnNarID.Size = 0;
                        }
                        oraCmd.Parameters.Add(paRxnNarID);

                        OracleParameter paAnalgRxnNarID = new OracleParameter();
                        paAnalgRxnNarID.ParameterName = "PICA_ANALOG_NAR_ID";
                        paAnalgRxnNarID.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paAnalgRxnNarID.OracleDbType = OracleDbType.Varchar2;
                        if (expProcShipment.AnalogousRxnNarIdList != null && expProcShipment.AnalogousRxnNarIdList.Count > 0)
                        {
                            paAnalgRxnNarID.Value = expProcShipment.AnalogousRxnNarIdList.ToArray();
                        }
                        else
                        {
                            paAnalgRxnNarID.Value = new string[1] { "" };
                            paAnalgRxnNarID.Size = 0;
                        }
                        oraCmd.Parameters.Add(paAnalgRxnNarID);

                        OracleParameter paRxnIdentifier = new OracleParameter();
                        paRxnIdentifier.ParameterName = "PINA_RXN_IDENTIFIER";
                        paRxnIdentifier.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRxnIdentifier.OracleDbType = OracleDbType.Int32;
                        if (expProcShipment.RXN_Id != null && expProcShipment.RXN_Id.Count > 0)
                        {
                            paRxnIdentifier.Value = expProcShipment.RXN_Id.ToArray();
                        }
                        else
                        {
                            paRxnIdentifier.Value = new string[1] { "" };
                            paRxnIdentifier.Size = 0;
                        }
                        oraCmd.Parameters.Add(paRxnIdentifier);
                                               
                        //=================New paramenters for Exp. Procedures Narratives - 19th Feb 2016===============
                        
                        OracleParameter paPageNo = new OracleParameter();
                        paPageNo.ParameterName = "PINA_PAGE_NO";
                        paPageNo.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paPageNo.OracleDbType = OracleDbType.Int32;
                        if (expProcShipment.RxnPageNoList != null && expProcShipment.RxnPageNoList.Count > 0)
                        {
                            paPageNo.Value = expProcShipment.RxnPageNoList.ToArray();
                        }
                        else
                        {
                            paPageNo.Value = new string[1] { "" };
                            paPageNo.Size = 0;
                        }
                        oraCmd.Parameters.Add(paPageNo);

                        OracleParameter paPageLabel = new OracleParameter();
                        paPageLabel.ParameterName = "PICA_PAGE_LABEL";
                        paPageLabel.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paPageLabel.OracleDbType = OracleDbType.Varchar2;
                        if (expProcShipment.RxnPageLabelList != null && expProcShipment.RxnPageLabelList.Count > 0)
                        {
                            paPageLabel.Value = expProcShipment.RxnPageLabelList.ToArray();
                        }
                        else
                        {
                            paPageLabel.Value = new string[1] { "" };
                            paPageLabel.Size = 0;
                        }
                        oraCmd.Parameters.Add(paPageLabel);

                        OracleParameter paDocRef = new OracleParameter();
                        paDocRef.ParameterName = "PICA_DOC_REF";
                        paDocRef.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paDocRef.OracleDbType = OracleDbType.Varchar2;
                        if (expProcShipment.RxnDocRefList != null && expProcShipment.RxnDocRefList.Count > 0)
                        {
                            paDocRef.Value = expProcShipment.RxnDocRefList.ToArray();
                        }
                        else
                        {
                            paDocRef.Value = new string[1] { "" };
                            paDocRef.Size = 0;
                        }
                        oraCmd.Parameters.Add(paDocRef);

                        OracleParameter paXPageOffset = new OracleParameter();
                        paXPageOffset.ParameterName = "PINA_OFFSET_X";
                        paXPageOffset.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paXPageOffset.OracleDbType = OracleDbType.Double;
                        if (expProcShipment.RxnXPageOffsetList != null && expProcShipment.RxnXPageOffsetList.Count > 0)
                        {
                            paXPageOffset.Value = expProcShipment.RxnXPageOffsetList.ToArray();
                        }
                        else
                        {
                            paXPageOffset.Value = new string[1] { "" };
                            paXPageOffset.Size = 0;
                        }
                        oraCmd.Parameters.Add(paXPageOffset);

                        OracleParameter paYPageOffset = new OracleParameter();
                        paYPageOffset.ParameterName = "PINA_OFFSET_Y";
                        paYPageOffset.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paYPageOffset.OracleDbType = OracleDbType.Double;
                        if (expProcShipment.RxnYPageOffsetList != null && expProcShipment.RxnYPageOffsetList.Count > 0)
                        {
                            paYPageOffset.Value = expProcShipment.RxnYPageOffsetList.ToArray();
                        }
                        else
                        {
                            paYPageOffset.Value = new string[1] { "" };
                            paYPageOffset.Size = 0;
                        }
                        oraCmd.Parameters.Add(paYPageOffset);

                        OracleParameter paXPageSize = new OracleParameter();
                        paXPageSize.ParameterName = "PINA_PAGE_SIZE_X";
                        paXPageSize.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paXPageSize.OracleDbType = OracleDbType.Double;
                        if (expProcShipment.RxnXPageSizeList != null && expProcShipment.RxnXPageSizeList.Count > 0)
                        {
                            paXPageSize.Value = expProcShipment.RxnXPageSizeList.ToArray();
                        }
                        else
                        {
                            paXPageSize.Value = new string[1] { "" };
                            paXPageSize.Size = 0;
                        }
                        oraCmd.Parameters.Add(paXPageSize);

                        OracleParameter paYPageSize = new OracleParameter();
                        paYPageSize.ParameterName = "PINA_PAGE_SIZE_Y";
                        paYPageSize.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paYPageSize.OracleDbType = OracleDbType.Double;
                        if (expProcShipment.RxnYPageSizeList != null && expProcShipment.RxnYPageSizeList.Count > 0)
                        {
                            paYPageSize.Value = expProcShipment.RxnYPageSizeList.ToArray();
                        }
                        else
                        {
                            paYPageSize.Value = new string[1] { "" };
                            paYPageSize.Size = 0;
                        }
                        oraCmd.Parameters.Add(paYPageSize);

                        OracleParameter paRxnTextLine = new OracleParameter();
                        paRxnTextLine.ParameterName = "PICA_TEXT_LINE";
                        paRxnTextLine.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRxnTextLine.OracleDbType = OracleDbType.Varchar2;
                        if (expProcShipment.RxnTextLineList != null && expProcShipment.RxnTextLineList.Count > 0)
                        {
                            paRxnTextLine.Value = expProcShipment.RxnTextLineList.ToArray();
                        }
                        else
                        {
                            paRxnTextLine.Value = new string[1] { "" };
                            paRxnTextLine.Size = 0;
                        }
                        oraCmd.Parameters.Add(paRxnTextLine);

                        OracleParameter paRxnPara = new OracleParameter();
                        paRxnPara.ParameterName = "PICA_PARA";
                        paRxnPara.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRxnPara.OracleDbType = OracleDbType.Varchar2;
                        if (expProcShipment.RxnParaList != null && expProcShipment.RxnParaList.Count > 0)
                        {
                            paRxnPara.Value = expProcShipment.RxnParaList.ToArray();
                        }
                        else
                        {
                            paRxnPara.Value = new string[1] { "" };
                            paRxnPara.Size = 0;
                        }
                        oraCmd.Parameters.Add(paRxnPara);

                        OracleParameter paRxnData = new OracleParameter();
                        paRxnData.ParameterName = "PICA_DATA";
                        paRxnData.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRxnData.OracleDbType = OracleDbType.Varchar2;
                        if (expProcShipment.RxnDataList != null && expProcShipment.RxnDataList.Count > 0)
                        {
                            paRxnData.Value = expProcShipment.RxnDataList.ToArray();
                        }
                        else
                        {
                            paRxnData.Value = new string[1] { "" };
                            paRxnData.Size = 0;
                        }
                        oraCmd.Parameters.Add(paRxnData);

                        //=======================================================================================
                        OracleParameter paSubstNarID = new OracleParameter();
                        paSubstNarID.ParameterName = "PICA_RXN_SUBST_NAR_ID";
                        paSubstNarID.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paSubstNarID.OracleDbType = OracleDbType.Varchar2;
                        if (expProcShipment.SubstRxnNarID != null && expProcShipment.SubstRxnNarID.Count > 0)
                        {
                            paSubstNarID.Value = expProcShipment.SubstRxnNarID.ToArray();
                        }
                        else
                        {
                            paSubstNarID.Value = new string[1] { "" };
                            paSubstNarID.Size = 0;
                        }
                        oraCmd.Parameters.Add(paSubstNarID);

                        
                        OracleParameter paSubstId = new OracleParameter();
                        paSubstId.ParameterName = "PICA_RXN_SUBST_ID";
                        paSubstId.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paSubstId.OracleDbType = OracleDbType.Varchar2;
                        if (expProcShipment.SubstIds != null && expProcShipment.SubstIds.Count > 0)
                        {
                            paSubstId.Value = expProcShipment.SubstIds.ToArray();
                        }
                        else
                        {
                            paSubstId.Value = new string[1] { "" };
                            paSubstId.Size = 0;
                        }
                        oraCmd.Parameters.Add(paSubstId);

                        OracleParameter paSubstRegNo = new OracleParameter();
                        paSubstRegNo.ParameterName = "PICA_RXN_SUBST_REGNO";
                        paSubstRegNo.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paSubstRegNo.OracleDbType = OracleDbType.Varchar2;
                        if (expProcShipment.SubstRegNos != null && expProcShipment.SubstRegNos.Count > 0)
                        {
                            paSubstRegNo.Value = expProcShipment.SubstRegNos.ToArray();
                        }
                        else
                        {
                            paSubstRegNo.Value = new string[1] { "" };
                            paSubstRegNo.Size = 0;
                        }
                        oraCmd.Parameters.Add(paSubstRegNo);

                        OracleParameter paSubstRole = new OracleParameter();
                        paSubstRole.ParameterName = "PICA_RXN_SUBST_ROLE";
                        paSubstRole.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paSubstRole.OracleDbType = OracleDbType.Varchar2;
                        if (expProcShipment.SubstRoles != null && expProcShipment.SubstRoles.Count > 0)
                        {
                            paSubstRole.Value = expProcShipment.SubstRoles.ToArray();
                        }
                        else
                        {
                            paSubstRole.Value = new string[1] { "" };
                            paSubstRole.Size = 0;
                        }
                        oraCmd.Parameters.Add(paSubstRole);

                        OracleParameter paFileName = new OracleParameter();
                        paFileName.ParameterName = "PICA_FILENAME";
                        paFileName.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFileName.OracleDbType = OracleDbType.Varchar2;
                        if (expProcShipment.File_Name != null && expProcShipment.File_Name.Count > 0)
                        {
                            paFileName.Value = expProcShipment.File_Name.ToArray();
                        }
                        else
                        {
                            paFileName.Value = new string[1] { "" };
                            paFileName.Size = 0;
                        }
                        oraCmd.Parameters.Add(paFileName);

                        OracleParameter paFileType = new OracleParameter();
                        paFileType.ParameterName = "PICA_FILETYPE";
                        paFileType.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFileType.OracleDbType = OracleDbType.Varchar2;
                        if (expProcShipment.File_Type != null && expProcShipment.File_Type.Count > 0)
                        {
                            paFileType.Value = expProcShipment.File_Type.ToArray();
                        }
                        else
                        {
                            paFileType.Value = new string[1] { "" };
                            paFileType.Size = 0;
                        }
                        oraCmd.Parameters.Add(paFileType);

                        OracleParameter paFileIdentifier = new OracleParameter();
                        paFileIdentifier.ParameterName = "PICA_FILEIDENTIFIER";
                        paFileIdentifier.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFileIdentifier.OracleDbType = OracleDbType.Varchar2;
                        if (expProcShipment.File_Id != null && expProcShipment.File_Id.Count > 0)
                        {
                            paFileIdentifier.Value = expProcShipment.File_Id.ToArray();
                        }
                        else
                        {
                            paFileIdentifier.Value = new string[1] { "" };
                            paFileIdentifier.Size = 0;
                        }
                        oraCmd.Parameters.Add(paFileIdentifier);

                        OracleParameter paFileUUID = new OracleParameter();
                        paFileUUID.ParameterName = "PICA_FILE_UUID";
                        paFileUUID.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFileUUID.OracleDbType = OracleDbType.Varchar2;
                        if (expProcShipment.File_UUID != null && expProcShipment.File_UUID.Count > 0)
                        {
                            paFileUUID.Value = expProcShipment.File_UUID.ToArray();
                        }
                        else
                        {
                            paFileUUID.Value = new string[1] { "" };
                            paFileUUID.Size = 0;
                        }
                        oraCmd.Parameters.Add(paFileUUID);

                        //OracleParameter paFileDocRef = new OracleParameter();
                        //paFileDocRef.ParameterName = "PICA_FILE_DOC_REF";
                        //paFileDocRef.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        //paFileDocRef.OracleDbType = OracleDbType.Varchar2;
                        //if (expProcShipment.File_Id != null && expProcShipment.File_Id.Count > 0)
                        //{
                        //    paFileDocRef.Value = expProcShipment.File_Id.ToArray();
                        //}
                        //else
                        //{
                        //    paFileDocRef.Value = new string[1] { "" };
                        //    paFileDocRef.Size = 0;
                        //}
                        //oraCmd.Parameters.Add(paFileDocRef);

                        oraCmd.Parameters.Add("PIN_CREATED_BY", OracleDbType.Int32).Value = expProcShipment.UR_ID;
                                        
                        OracleParameter pStatus = new OracleParameter();
                        pStatus.ParameterName = "POC_STATUS";
                        pStatus.Size = 100;
                        pStatus.OracleDbType = OracleDbType.Varchar2;
                        pStatus.Direction = ParameterDirection.Output;
                        oraCmd.Parameters.Add(pStatus);

                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        oraCon.Close();

                        if (pStatus.Value != null)
                        {
                            strStatus = pStatus.Value.ToString().ToUpper();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return strStatus;
        }
    }
}
