﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Oracle.ManagedDataAccess.Client;
using IndxReactNarrBll;

namespace IndxReactNarrDAL
{
    public class NarrativesDB
    {       
        public static DataTable GetSpecialCharsReplacementsOnApplication(string appName)
        {
            DataTable xmlRepData = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "NARRATIVES.GET_SPE_CHAR_REPLACE_ON_APP";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIC_APPLICATION_NAME", OracleDbType.Varchar2).Value = appName;
                    oraCmd.Parameters.Add("PORC_SPECIAL_CHARCTERS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    xmlRepData = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(xmlRepData);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return xmlRepData;
        }
        
        public static DataTable GetTANDocumentsOnTANID(int tanid)
        {
            DataTable dtDocuments = null;           
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "NARRATIVES.GET_TAN_DOCUMENTS_ON_TAN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanid;
                    oraCmd.Parameters.Add("PORC_TAN_DOCUMENTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtDocuments = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtDocuments);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtDocuments;
        }

        public static DataTable GetTANReactionsOnTANID(int tanid)
        {
            DataTable dtReactions = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "NARRATIVES.GET_REACTIONS_ON_TAN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanid;
                    oraCmd.Parameters.Add("PORC_REACTIONS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtReactions = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtReactions);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtReactions;
        }

        public static DataTable GetTANReactionsOnTANID_ForTreeView(int tanid)
        {
            DataTable dtReactions = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "NARRATIVES.GET_REACTIONS_ON_TAN_ID_T";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanid;
                    oraCmd.Parameters.Add("PORC_REACTIONS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtReactions = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtReactions);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtReactions;
        }

        public static DataTable GetReactionDataOnRxnID(int reactionID)
        {
            DataTable dtReactions = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "NARRATIVES.GET_REACTIONS_ON_RXN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_RXN_ID", OracleDbType.Int32).Value = reactionID;
                    oraCmd.Parameters.Add("PORC_REACTIONS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtReactions = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtReactions);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtReactions;
        }

        public static DataTable GetReactionSubstancesOnRxnID(int reactionID)
        {
            DataTable rxnSubstances = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "NARRATIVES.GET_RXN_SUBSTANCES";
                    //oraCmd.CommandText = "NARRATIVES.GET_SUBSTANCES_ON_RXN_ID_PILOT";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_RXN_ID", OracleDbType.Int32).Value = reactionID;
                    oraCmd.Parameters.Add("PORC_SUBSTANCES", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    rxnSubstances = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(rxnSubstances);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return rxnSubstances;
        }

        public static DataTable GetTANReactionsForExportOnTANID(int tanid)
        {
            DataTable dtReactions = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "NARRATIVES.GET_REACTIONS_ON_TAN_ID_EXPORT";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanid;
                    oraCmd.Parameters.Add("PORC_REACTIONS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtReactions = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtReactions);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtReactions;
        }

        public static bool UpdateNarrReactionData(NarrReactionsBO narRxn)
        {
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "NARRATIVES.UPDATE_NARR_REACTION_INFO";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = oraCon;

                        oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = narRxn.TAN_ID;
                        oraCmd.Parameters.Add("PIN_RXN_ID", OracleDbType.Int32).Value = narRxn.RXN_ID;
                        oraCmd.Parameters.Add("PIN_TAN_DOC_ID", OracleDbType.Int32).Value = narRxn.RxnDocID;
                        oraCmd.Parameters.Add("PIC_PAGE_NO", OracleDbType.Varchar2).Value = narRxn.PageNo;
                        oraCmd.Parameters.Add("PIC_PAGE_LABEL", OracleDbType.Varchar2).Value = narRxn.PageLabel;
                        oraCmd.Parameters.Add("PIC_X_OFFSET", OracleDbType.Varchar2).Value = narRxn.XOffSet;
                        oraCmd.Parameters.Add("PIC_Y_OFFSET", OracleDbType.Varchar2).Value = narRxn.YOffSet;
                        oraCmd.Parameters.Add("PIC_TEXTLINE", OracleDbType.Varchar2).Value = narRxn.TextLine;
                        oraCmd.Parameters.Add("PIC_IS_ANALOGOUS", OracleDbType.Varchar2).Value = narRxn.IsAnalogous;
                        oraCmd.Parameters.Add("PIC_ANALO_RXN_ID", OracleDbType.Varchar2).Value = narRxn.AnalogousRxnID;
                        oraCmd.Parameters.Add("PIC_GENRL_TYPICAL", OracleDbType.Varchar2).Value = narRxn.IsGeneralTypical;
                        oraCmd.Parameters.Add("PIC_NO_EXP_DTLS", OracleDbType.Varchar2).Value = narRxn.NoExpDetails;                        
                        oraCmd.Parameters.Add("PIC_IS_MISSING_RXN", OracleDbType.Varchar2).Value = narRxn.IsMissingRxn;
                        oraCmd.Parameters.Add("PIC_PARA_TEXT", OracleDbType.Clob).Value = narRxn.Para;
                        oraCmd.Parameters.Add("PIC_DATA_TEXT", OracleDbType.Clob).Value = narRxn.Data;
                        oraCmd.Parameters.Add("PIN_PAGE_SIZE_X", OracleDbType.Double).Value = narRxn.XPageSize;
                        oraCmd.Parameters.Add("PIN_PAGE_SIZE_Y", OracleDbType.Double).Value = narRxn.YPageSize;
                        oraCmd.Parameters.Add("PIC_COMPLETE_STATUS", OracleDbType.Varchar2).Value = narRxn.IsRxnCompleted;
                        oraCmd.Parameters.Add("PIN_UR_ID", OracleDbType.Int32).Value = narRxn.UserID;

                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        oraCon.Close();
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }

        public static bool UpdateExperimentalProcReactionData(NarrReactionsBO narRxn)
        {
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {

                        oraCmd.CommandText = "NARRATIVES.UPDATE_EXP_PROCEDURE_INFO_NEW";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = oraCon;

                        oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = narRxn.TAN_ID;
                        oraCmd.Parameters.Add("PIN_RXN_ID", OracleDbType.Int32).Value = narRxn.RXN_ID;
                        oraCmd.Parameters.Add("PIN_TAN_DOC_ID", OracleDbType.Int32).Value = narRxn.RxnDocID;
                        oraCmd.Parameters.Add("PIC_PAGE_NO", OracleDbType.Varchar2).Value = narRxn.PageNo;
                        oraCmd.Parameters.Add("PIC_PAGE_LABEL", OracleDbType.Varchar2).Value = narRxn.PageLabel;
                        oraCmd.Parameters.Add("PIC_X_OFFSET", OracleDbType.Varchar2).Value = narRxn.XOffSet;
                        oraCmd.Parameters.Add("PIC_Y_OFFSET", OracleDbType.Varchar2).Value = narRxn.YOffSet;
                        oraCmd.Parameters.Add("PIC_TEXTLINE", OracleDbType.Varchar2).Value = narRxn.TextLine;
                        oraCmd.Parameters.Add("PIC_IS_ANALOGOUS", OracleDbType.Varchar2).Value = narRxn.IsAnalogous;
                        oraCmd.Parameters.Add("PIC_ANALO_RXN_ID", OracleDbType.Varchar2).Value = narRxn.AnalogousRxnID;
                        oraCmd.Parameters.Add("PIC_GENRL_TYPICAL", OracleDbType.Varchar2).Value = narRxn.IsGeneralTypical;
                        oraCmd.Parameters.Add("PIC_NO_EXP_DTLS", OracleDbType.Varchar2).Value = narRxn.NoExpDetails;
                        oraCmd.Parameters.Add("PIC_IS_MISSING_RXN", OracleDbType.Varchar2).Value = narRxn.IsMissingRxn;
                        oraCmd.Parameters.Add("PIC_PARA_TEXT", OracleDbType.Clob).Value = narRxn.Para;
                        oraCmd.Parameters.Add("PIC_DATA_TEXT", OracleDbType.Clob).Value = narRxn.Data;
                        oraCmd.Parameters.Add("PIC_PROCEDURE_TEXT", OracleDbType.Clob).Value = narRxn.ProcedureText;
                        oraCmd.Parameters.Add("PIC_YIELD_TEXT", OracleDbType.Clob).Value = narRxn.YieldText;
                        oraCmd.Parameters.Add("PIN_PAGE_SIZE_X", OracleDbType.Double).Value = narRxn.XPageSize;
                        oraCmd.Parameters.Add("PIN_PAGE_SIZE_Y", OracleDbType.Double).Value = narRxn.YPageSize;
                        oraCmd.Parameters.Add("PIC_IS_NO_PAGE_LABEL", OracleDbType.Varchar2).Value = narRxn.IsNoPageLabel;

                        oraCmd.Parameters.Add("PIC_IS_MAPPING_UPDATED", OracleDbType.Varchar2).Value = narRxn.IsMappingUpdated;

                        oraCmd.Parameters.Add("PIC_COMPLETE_STATUS", OracleDbType.Varchar2).Value = narRxn.IsRxnCompleted;
                        oraCmd.Parameters.Add("PIN_UR_ID", OracleDbType.Int32).Value = narRxn.UserID;

                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        oraCon.Close();
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }

        public static bool UpdateFindReplaceReactionsData(FindReplaceBO findRepl)
        {
            bool blStatus = false;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "NARRATIVES.FIND_REPLACE_REACTION_DATA";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = oraCon;

                        OracleParameter paRxnIDs = new OracleParameter();
                        paRxnIDs.ParameterName = "PINA_REACTION_IDS";
                        paRxnIDs.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRxnIDs.OracleDbType = OracleDbType.Int32;
                        if (findRepl.Rxn_IDs != null)
                        {
                            if (findRepl.Rxn_IDs.Count > 0)
                            {
                                paRxnIDs.Value = findRepl.Rxn_IDs.ToArray();
                            }
                            else
                            {
                                paRxnIDs.Value = new string[1] { "" };
                                paRxnIDs.Size = 0;
                            }
                        }
                        else
                        {
                            paRxnIDs.Value = new string[1] { "" };
                            paRxnIDs.Size = 0;
                        }
                        oraCmd.Parameters.Add(paRxnIDs);

                        OracleParameter paFields = new OracleParameter();
                        paFields.ParameterName = "PICA_FIELD_NAMES";
                        paFields.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFields.OracleDbType = OracleDbType.Varchar2;
                        if (findRepl.FieldNames != null)
                        {
                            if (findRepl.FieldNames.Count > 0)
                            {
                                paFields.Value = findRepl.FieldNames.ToArray();
                            }
                            else
                            {
                                paFields.Value = new string[1] { "" };
                                paFields.Size = 0;
                            }
                        }
                        else
                        {
                            paFields.Value = new string[1] { "" };
                            paFields.Size = 0;
                        }
                        oraCmd.Parameters.Add(paFields);

                        OracleParameter paFieldValues = new OracleParameter();
                        paFieldValues.ParameterName = "PICA_FIELD_VALUES";
                        paFieldValues.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFieldValues.OracleDbType = OracleDbType.Varchar2;
                        if (findRepl.FieldNames != null)
                        {
                            if (findRepl.FieldNames.Count > 0)
                            {
                                paFieldValues.Value = findRepl.FieldValues.ToArray();
                            }
                            else
                            {
                                paFieldValues.Value = new string[1] { "" };
                                paFieldValues.Size = 0;
                            }
                        }
                        else
                        {
                            paFieldValues.Value = new string[1] { "" };
                            paFieldValues.Size = 0;
                        }
                        oraCmd.Parameters.Add(paFieldValues);
                        oraCmd.Parameters.Add("POC_STATUS", OracleDbType.Varchar2, 50).Direction = ParameterDirection.Output;

                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        oraCon.Close();

                        if (oraCmd.Parameters["POC_STATUS"].Value != null)
                        {
                            if (!string.IsNullOrEmpty(oraCmd.Parameters["POC_STATUS"].Value.ToString()))
                            {
                                blStatus = true;
                            }
                        }                       
                    }
                }
            }
            catch (Exception ex)
            {
                //throw ex;
            }
            return blStatus;
        }

        public static DataTable GetDailyStatusReport(string application, string module, DateTime statusDate, DateTime endDate)
        {
            DataTable dailyStatusRep = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REPORTS.RXN_USER_PR_BETEEN_DATES";//NAR_USER_PR_BETEEN_DATES
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIC_APPLICATION", OracleDbType.Varchar2).Value = application;
                    oraCmd.Parameters.Add("PIC_MODULE", OracleDbType.Varchar2).Value = module;
                    oraCmd.Parameters.Add("PID_START_DATE", OracleDbType.Date).Value = statusDate;
                    oraCmd.Parameters.Add("PID_END_DATE", OracleDbType.Date).Value = endDate;
                    oraCmd.Parameters.Add("PORC_NARR_DAILY_STATUS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dailyStatusRep = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dailyStatusRep);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dailyStatusRep;
        }

        public static DataTable GetShipmentsOverAllStatusReport(string application)
        {
            DataTable dailyStatusRep = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "REPORTS.NARR_SHIPMENT_STATUS";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIC_APPLICATION", OracleDbType.Varchar2).Value = application;
                    oraCmd.Parameters.Add("PORC_SHP_TAN_STATUS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dailyStatusRep = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dailyStatusRep);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dailyStatusRep;
        }

        public static DataTable GetFindingTypesMasterData()
        {
            DataTable findingTypes = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "NARRATIVES.GET_FINDING_TYPES";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PORC_FINDING_TYPES", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    findingTypes = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(findingTypes);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return findingTypes;
        }

        public static DataTable GetMaterialsMasterData()
        {
            DataTable materialsMaster = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "NARRATIVES.GET_MATERIALS_MASTER_DATA";
                    //oraCmd.CommandText = "NARRATIVES.GET_MATERIALS_DATA_PILOT";
                    oraCmd.CommandType = CommandType.StoredProcedure;

                    oraCmd.Parameters.Add("PORC_MATERIALS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    materialsMaster = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(materialsMaster);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return materialsMaster;
        }

        public static DataTable GetReactionFindingsOnRxnID(int reactionID)
        {
            DataTable rxnFindings = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "NARRATIVES.GET_RXN_FINDINGS";
                    //oraCmd.CommandText = "NARRATIVES.GET_RXN_FINDINGS_ON_RXN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_RXN_ID", OracleDbType.Int32).Value = reactionID;
                    oraCmd.Parameters.Add("PORC_FINDINGS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    rxnFindings = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(rxnFindings);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return rxnFindings;
        }

        public static string UpdateReactionFindings(RxnFindings rxnFinding)
        {
            string strStatus = "";
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "NARRATIVES.UPDATE_RXN_FINDINGS";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        oraCmd.Parameters.Add("PIN_RXN_ID", OracleDbType.Int32).Value = rxnFinding.RxnID;                       
                                               
                        OracleParameter paFindingType = new OracleParameter();
                        paFindingType.ParameterName = "PICA_FINDING_TYPE";
                        paFindingType.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFindingType.OracleDbType = OracleDbType.Varchar2;
                        if (rxnFinding.FindingTypes != null && rxnFinding.FindingTypes.Count > 0)
                        {
                            paFindingType.Value = rxnFinding.FindingTypes.ToArray();
                        }
                        else
                        {
                            paFindingType.Value = new string[1] { "" };
                            paFindingType.Size = 0;
                        }
                        oraCmd.Parameters.Add(paFindingType);

                        OracleParameter paFindingValue = new OracleParameter();
                        paFindingValue.ParameterName = "PICA_FINDING_VALUE";
                        paFindingValue.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFindingValue.OracleDbType = OracleDbType.Varchar2;
                        if (rxnFinding.FindingValues != null && rxnFinding.FindingValues.Count > 0)
                        {
                            paFindingValue.Value = rxnFinding.FindingValues.ToArray();
                        }
                        else
                        {
                            paFindingValue.Value = new string[1] { "" };
                            paFindingValue.Size = 0;
                        }
                        oraCmd.Parameters.Add(paFindingValue);

                        OracleParameter paRefCompound = new OracleParameter();
                        paRefCompound.ParameterName = "PICA_REF_COMPOUND";
                        paRefCompound.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRefCompound.OracleDbType = OracleDbType.Varchar2;
                        if (rxnFinding.RefCompounds != null && rxnFinding.RefCompounds.Count > 0)
                        {
                            paRefCompound.Value = rxnFinding.RefCompounds.ToArray();
                        }
                        else
                        {
                            paRefCompound.Value = new string[1] { "" };
                            paRefCompound.Size = 0;
                        }
                        oraCmd.Parameters.Add(paRefCompound);
                                                   
                        //OracleParameter pStatus = new OracleParameter();
                        //pStatus.ParameterName = "POC_STATUS";
                        //pStatus.Size = 100;
                        //pStatus.OracleDbType = OracleDbType.Varchar2;
                        //pStatus.Direction = ParameterDirection.Output;
                        //oraCmd.Parameters.Add(pStatus);

                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        oraCon.Close();                        
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return strStatus;
        }

        public static DataTable GetTANSubstancesOnTANID(int tanid)
        {
            DataTable dtSubstances = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "NARRATIVES.GET_TAN_SUBSTANCES";
                    //oraCmd.CommandText = "NARRATIVES.GET_SUBSTANCES_ON_TAN_ID_PILOT";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanid;
                    oraCmd.Parameters.Add("PORC_SUBSTANCES", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtSubstances = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtSubstances);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtSubstances;
        }

        public static DataTable GetTANFindingsOnTANID(int tanid)
        {
            DataTable dtFindings = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "NARRATIVES.GET_TAN_FINDINGS";                   
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanid;
                    oraCmd.Parameters.Add("PORC_FINDINGS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtFindings = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtFindings);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtFindings;
        }

        public static DataTable GetProcedureStepsOnReactionIDs(List<int> rxnIDs)
        {
            DataTable dtProcSteps = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "NARRATIVES.GET_PRC_STEPS_ON_RXN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                
                    OracleParameter paRxnIds = new OracleParameter();
                    paRxnIds.ParameterName = "PINA_RXN_IDS";
                    paRxnIds.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                    paRxnIds.OracleDbType = OracleDbType.Int32;
                    if (rxnIDs != null && rxnIDs.Count > 0)
                    {
                        paRxnIds.Value = rxnIDs.ToArray();
                    }
                    else
                    {
                        paRxnIds.Value = new string[1] { "" };
                        paRxnIds.Size = 0;
                    }
                    oraCmd.Parameters.Add(paRxnIds);

                    oraCmd.Parameters.Add("PORC_PRC_STEPS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtProcSteps = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtProcSteps);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtProcSteps;
        }

        public static DataSet GetProcedureStepsAndSubstancesOnReactionIDs(List<int> rxnIDs)
        {
            DataSet dsProcSteps = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "NARRATIVES.GET_PRC_STEPS_SUBSTS_ON_RXN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;

                    OracleParameter paRxnIds = new OracleParameter();
                    paRxnIds.ParameterName = "PINA_RXN_IDS";
                    paRxnIds.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                    paRxnIds.OracleDbType = OracleDbType.Int32;
                    if (rxnIDs != null && rxnIDs.Count > 0)
                    {
                        paRxnIds.Value = rxnIDs.ToArray();
                    }
                    else
                    {
                        paRxnIds.Value = new string[1] { "" };
                        paRxnIds.Size = 0;
                    }
                    oraCmd.Parameters.Add(paRxnIds);

                    oraCmd.Parameters.Add("PORC_PRC_STEPS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    oraCmd.Parameters.Add("PORC_SUBSTANCES", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dsProcSteps = new DataSet();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dsProcSteps);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsProcSteps;
        }

        public static bool UpdateReactionsProcedureSteps(List<int> rxnIDs, List<string> procSteps)
        {
            bool blStatus = false;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "NARRATIVES.UPDATE_PRC_STEPS";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        OracleParameter paRxnIds = new OracleParameter();
                        paRxnIds.ParameterName = "PINA_RXN_IDS";
                        paRxnIds.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRxnIds.OracleDbType = OracleDbType.Int32;
                        if (rxnIDs != null && rxnIDs.Count > 0)
                        {
                            paRxnIds.Value = rxnIDs.ToArray();
                        }
                        else
                        {
                            paRxnIds.Value = new string[1] { "" };
                            paRxnIds.Size = 0;
                        }
                        oraCmd.Parameters.Add(paRxnIds);

                        OracleParameter paPrcSteps = new OracleParameter();
                        paPrcSteps.ParameterName = "PICA_PRC_STEPS";
                        paPrcSteps.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paPrcSteps.OracleDbType = OracleDbType.Varchar2;
                        if (procSteps != null && procSteps.Count > 0)
                        {
                            paPrcSteps.Value = procSteps.ToArray();
                        }
                        else
                        {
                            paPrcSteps.Value = new string[1] { "" };
                            paPrcSteps.Size = 0;
                        }
                        oraCmd.Parameters.Add(paPrcSteps);
                                     
                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        oraCon.Close();

                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return blStatus;
        }

        public static DataTable GetReactionFindingsOnReactionIDs(List<int> rxnIDs)
        {
            DataTable dtRxnFindings = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "NARRATIVES.GET_FINDINGS_ON_RXN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;

                    OracleParameter paRxnIds = new OracleParameter();
                    paRxnIds.ParameterName = "PINA_RXN_IDS";
                    paRxnIds.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                    paRxnIds.OracleDbType = OracleDbType.Int32;
                    if (rxnIDs != null && rxnIDs.Count > 0)
                    {
                        paRxnIds.Value = rxnIDs.ToArray();
                    }
                    else
                    {
                        paRxnIds.Value = new string[1] { "" };
                        paRxnIds.Size = 0;
                    }
                    oraCmd.Parameters.Add(paRxnIds);

                    oraCmd.Parameters.Add("PORC_FINDINGS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtRxnFindings = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtRxnFindings);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtRxnFindings;
        }

        public static DataTable GetReactionFindingsOnTanIDs(List<int> lstTanIDs)
        {
            DataTable dtTanFindings = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "NARRATIVES.GET_FINDINGS_ON_TAN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;

                    OracleParameter paRxnIds = new OracleParameter();
                    paRxnIds.ParameterName = "PINA_TAN_IDS";
                    paRxnIds.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                    paRxnIds.OracleDbType = OracleDbType.Int32;
                    if (lstTanIDs != null && lstTanIDs.Count > 0)
                    {
                        paRxnIds.Value = lstTanIDs.ToArray();
                    }
                    else
                    {
                        paRxnIds.Value = new string[1] { "" };
                        paRxnIds.Size = 0;
                    }
                    oraCmd.Parameters.Add(paRxnIds);

                    oraCmd.Parameters.Add("PORC_FINDINGS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtTanFindings = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtTanFindings);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtTanFindings;
        }

        public static DataSet GetShipmentTANReactionsAndFindingsOnTanIDs(List<int> lstTanIDs)
        {
            DataSet dsTanRxnFindings = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "NARRATIVES.GET_SHIPMENT_RXNS_FINDINGS";
                    oraCmd.CommandType = CommandType.StoredProcedure;

                    OracleParameter paRxnIds = new OracleParameter();
                    paRxnIds.ParameterName = "PINA_TAN_IDS";
                    paRxnIds.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                    paRxnIds.OracleDbType = OracleDbType.Int32;
                    if (lstTanIDs != null && lstTanIDs.Count > 0)
                    {
                        paRxnIds.Value = lstTanIDs.ToArray();
                    }
                    else
                    {
                        paRxnIds.Value = new string[1] { "" };
                        paRxnIds.Size = 0;
                    }
                    oraCmd.Parameters.Add(paRxnIds);

                    oraCmd.Parameters.Add("PORC_REACTIONS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    oraCmd.Parameters.Add("PORC_FINDINGS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dsTanRxnFindings = new DataSet();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dsTanRxnFindings);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsTanRxnFindings;
        }

        public static bool UpdateShipmentTANsReactionFindings(RxnFindings rxnFinding)
        {
            bool blStatus = false;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "NARRATIVES.UPDATE_RXN_FINDINGS_NEW";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        
                        OracleParameter paRxnID = new OracleParameter();
                        paRxnID.ParameterName = "PINA_RXN_ID";
                        paRxnID.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRxnID.OracleDbType = OracleDbType.Int32;
                        if (rxnFinding.RxnIDs != null && rxnFinding.RxnIDs.Count > 0)
                        {
                            paRxnID.Value = rxnFinding.RxnIDs.ToArray();
                        }
                        else
                        {
                            paRxnID.Value = new string[1] { "" };
                            paRxnID.Size = 0;
                        }
                        oraCmd.Parameters.Add(paRxnID);

                        OracleParameter paFindingID = new OracleParameter();
                        paFindingID.ParameterName = "PINA_FINDING_ID";
                        paFindingID.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFindingID.OracleDbType = OracleDbType.Int32;
                        if (rxnFinding.FindingIDs != null && rxnFinding.FindingIDs.Count > 0)
                        {
                            paFindingID.Value = rxnFinding.FindingIDs.ToArray();
                        }
                        else
                        {
                            paFindingID.Value = new string[1] { "" };
                            paFindingID.Size = 0;
                        }
                        oraCmd.Parameters.Add(paFindingID);

                        OracleParameter paFindingType = new OracleParameter();
                        paFindingType.ParameterName = "PICA_FINDING_TYPE";
                        paFindingType.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFindingType.OracleDbType = OracleDbType.Varchar2;
                        if (rxnFinding.FindingTypes != null && rxnFinding.FindingTypes.Count > 0)
                        {
                            paFindingType.Value = rxnFinding.FindingTypes.ToArray();
                        }
                        else
                        {
                            paFindingType.Value = new string[1] { "" };
                            paFindingType.Size = 0;
                        }
                        oraCmd.Parameters.Add(paFindingType);

                        OracleParameter paFindingValue = new OracleParameter();
                        paFindingValue.ParameterName = "PICA_FINDING_VALUE";
                        paFindingValue.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paFindingValue.OracleDbType = OracleDbType.Varchar2;
                        if (rxnFinding.FindingValues != null && rxnFinding.FindingValues.Count > 0)
                        {
                            paFindingValue.Value = rxnFinding.FindingValues.ToArray();
                        }
                        else
                        {
                            paFindingValue.Value = new string[1] { "" };
                            paFindingValue.Size = 0;
                        }
                        oraCmd.Parameters.Add(paFindingValue);

                        OracleParameter paRefCompound = new OracleParameter();
                        paRefCompound.ParameterName = "PICA_REF_COMPOUND";
                        paRefCompound.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRefCompound.OracleDbType = OracleDbType.Varchar2;
                        if (rxnFinding.RefCompounds != null && rxnFinding.RefCompounds.Count > 0)
                        {
                            paRefCompound.Value = rxnFinding.RefCompounds.ToArray();
                        }
                        else
                        {
                            paRefCompound.Value = new string[1] { "" };
                            paRefCompound.Size = 0;
                        }
                        oraCmd.Parameters.Add(paRefCompound);

                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        oraCon.Close();

                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return blStatus;
        }

        public static DataTable GetReactionsPageInfoOnTanIDs(List<int> lstTanIDs)
        {
            DataTable dtTanPageInfo = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "NARRATIVES.GET_SHIPMENT_RXNS_PAGE_INFO";
                    oraCmd.CommandType = CommandType.StoredProcedure;

                    OracleParameter paRxnIds = new OracleParameter();
                    paRxnIds.ParameterName = "PINA_TAN_IDS";
                    paRxnIds.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                    paRxnIds.OracleDbType = OracleDbType.Int32;
                    if (lstTanIDs != null && lstTanIDs.Count > 0)
                    {
                        paRxnIds.Value = lstTanIDs.ToArray();
                    }
                    else
                    {
                        paRxnIds.Value = new string[1] { "" };
                        paRxnIds.Size = 0;
                    }
                    oraCmd.Parameters.Add(paRxnIds);

                    oraCmd.Parameters.Add("PORC_REACTIONS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtTanPageInfo = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtTanPageInfo);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtTanPageInfo;
        }

        public static bool UpdateShipmentTANsPageInformation(RxnsPageInfo rxnsPageinfo)
        {
            bool blStatus = false;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "NARRATIVES.UPDATE_SHIPMENT_TANS_PAGE_INFO";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        OracleParameter paRxnID = new OracleParameter();
                        paRxnID.ParameterName = "PINA_RXN_ID";
                        paRxnID.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paRxnID.OracleDbType = OracleDbType.Int32;
                        if (rxnsPageinfo.RxnIDs != null && rxnsPageinfo.RxnIDs.Count > 0)
                        {
                            paRxnID.Value = rxnsPageinfo.RxnIDs.ToArray();
                        }
                        else
                        {
                            paRxnID.Value = new string[1] { "" };
                            paRxnID.Size = 0;
                        }
                        oraCmd.Parameters.Add(paRxnID);

                        OracleParameter paPageNo = new OracleParameter();
                        paPageNo.ParameterName = "PINA_PAGE_NO";
                        paPageNo.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paPageNo.OracleDbType = OracleDbType.Int32;
                        if (rxnsPageinfo.PageNos != null && rxnsPageinfo.PageNos.Count > 0)
                        {
                            paPageNo.Value = rxnsPageinfo.PageNos.ToArray();
                        }
                        else
                        {
                            paPageNo.Value = new string[1] { "" };
                            paPageNo.Size = 0;
                        }
                        oraCmd.Parameters.Add(paPageNo);

                        OracleParameter paPageLabel = new OracleParameter();
                        paPageLabel.ParameterName = "PICA_PAGE_LABEL";
                        paPageLabel.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paPageLabel.OracleDbType = OracleDbType.Varchar2;
                        if (rxnsPageinfo.PageLabels != null && rxnsPageinfo.PageLabels.Count > 0)
                        {
                            paPageLabel.Value = rxnsPageinfo.PageLabels.ToArray();
                        }
                        else
                        {
                            paPageLabel.Value = new string[1] { "" };
                            paPageLabel.Size = 0;
                        }
                        oraCmd.Parameters.Add(paPageLabel);
                                                
                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        oraCon.Close();

                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return blStatus;
        }

        public static DataTable GetFindingTypeReplacements()
        {
            DataTable dtReplacements = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "NARRATIVES.GET_RXN_FINDING_REPLACEMENTS";                    
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PORC_REPLACEMENTS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtReplacements = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtReplacements);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtReplacements;
        }

        public static bool UpdateTANDocumentPageLabelBlank(int tanID, int tanDocID, char blankY_N)
        {
            bool blStatus = false;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "NARRATIVES.UPDATE_PAGE_LABEL_BLANK";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanID;
                        oraCmd.Parameters.Add("PIN_TAN_DOC_ID", OracleDbType.Int32).Value = tanDocID;
                        oraCmd.Parameters.Add("PIC_LABEL_OPTION", OracleDbType.Char).Value = blankY_N;

                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        oraCon.Close();

                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return blStatus;
        }

        public static bool UpdateCommbinedDocStatus(int TAN_ID, int tanDocID, char Status)
        {
            bool blStatus = false;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "NARRATIVES.UPDATE_COMBINED_DOC_STATUS";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = TAN_ID;
                        oraCmd.Parameters.Add("PIN_TAN_DOC_ID", OracleDbType.Int32).Value = tanDocID;
                        oraCmd.Parameters.Add("PIC_COMB_DOC_OPTION", OracleDbType.Char).Value = Status;

                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        oraCon.Close();

                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return blStatus; 
        }
    }
}
