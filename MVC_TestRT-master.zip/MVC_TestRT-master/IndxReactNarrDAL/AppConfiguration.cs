﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace IndxReactNarrDAL
{
    class AppConfiguration
    {
        /// <summary>
        /// Gets the host name of the oracle server.
        /// </summary>
        public static string Host
        {
            get
            {
                return ConfigurationManager.AppSettings["HOSTNAME"];
            }
        }

        /// <summary>
        /// Gets the Port of the oracle server.
        /// </summary>
        public static string Port
        {
            get
            {
                return ConfigurationManager.AppSettings["PORTNUMBER"];
            }
        }

        /// <summary>
        /// Gets the database name of the oracle server.
        /// </summary>
        public static string Database
        {
            get
            {
                return ConfigurationManager.AppSettings["DATABASE"];
            }
        }

        /// <summary>
        /// Gets the schema name of the oracle server.
        /// </summary>
        public static string UserName
        {
            get
            {
                return ConfigurationManager.AppSettings["USERNAME"];
            }
        }

        /// <summary>
        /// Gets the schema password of the oracle server.
        /// </summary>
        public static string Password
        {
            get
            {
                return ConfigurationManager.AppSettings["PASSWORD"];
            }
        }
    }
}
