﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IndxReactNarrBLL;
using Oracle.ManagedDataAccess.Client;
using IndxReactNarrBll;

namespace IndxReactNarrDAL
{
   public class OrganicIndexingDB
    {
       public static DataTable GetIndexingRoleIndicators()
        {
            DataTable dtIndexRoles = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "ORGANIC_INDEXING.GET_ROLE_INDICATORS";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PORC_ROLE_INDS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtIndexRoles = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtIndexRoles);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dtIndexRoles;
        }

        public static DataTable GetIndexingConceptTextHeadings()
        {
            DataTable dtCTH = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "ORGANIC_INDEXING.GET_CONCEPT_TEXT_HEADINGS";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PORC_CTH", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    dtCTH = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtCTH);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtCTH;
        }
               
        public static DataTable GetIndexingSectionMasterDetails()
        {
            DataTable dtSections = null;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "ORGANIC_INDEXING.GET_SECTION_MASTER_DTLS";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Parameters.Add("PORC_SECTION_DTLS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                        dtSections = new DataTable();
                        OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                        oraAdpt.Fill(dtSections);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtSections;
        }

        public static DataTable GetIndexingSubSections()
        {
            DataTable dtSubSections = null;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "ORGANIC_INDEXING.GET_SUB_SECTION_DLTS";
                        oraCmd.CommandType = CommandType.StoredProcedure;               
                        oraCmd.Parameters.Add("PORC_SUB_SECTIONS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                        dtSubSections = new DataTable();
                        OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                        oraAdpt.Fill(dtSubSections);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtSubSections;
        }

        public static bool UpdateIndexingTANInfo(IndexingTANInfo tanInfo)
        {
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "ORGANIC_INDEXING.UPDATE_TAN_INFO";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanInfo.TAN_ID;
                        oraCmd.Parameters.Add("PIC_TITLE", OracleDbType.Varchar2).Value = tanInfo.Title;
                        oraCmd.Parameters.Add("PIC_ABSTRACT", OracleDbType.Varchar2).Value = tanInfo.Abstract;
                        oraCmd.Parameters.Add("PIN_SECTION", OracleDbType.Int32).Value = tanInfo.Section;
                        oraCmd.Parameters.Add("PIN_SUB_SECTION", OracleDbType.Int32).Value = tanInfo.SubSection;
                        oraCmd.Parameters.Add("PIC_CROSS_REF", OracleDbType.Varchar2).Value = tanInfo.CrossReference;
                        oraCmd.Parameters.Add("PIC_TMD", OracleDbType.Varchar2).Value = tanInfo.TMD;
                        oraCmd.Parameters.Add("PIC_COMMENTS", OracleDbType.Varchar2).Value = tanInfo.Comments;
                        oraCmd.Parameters.Add("PIC_COMMENT_TYPE", OracleDbType.Varchar2).Value = tanInfo.CommentsType;
                        oraCmd.Parameters.Add("PIC_SPA_HDR", OracleDbType.Varchar2).Value = tanInfo.SpaHdr;

                        oraCmd.Parameters.Add("PIC_KEYWORDS", OracleDbType.Varchar2).Value = tanInfo.Keywords;
                        oraCmd.Parameters.Add("PIC_REVIEW_TAN", OracleDbType.Varchar2).Value = tanInfo.ReviewTAN;
                        oraCmd.Parameters.Add("PIC_QUERY_TAN", OracleDbType.Varchar2).Value = tanInfo.QueryTAN;
                        oraCmd.Parameters.Add("PIN_MODIFIED_BY", OracleDbType.Int32).Value = tanInfo.URID;                       
                        
                        dbCon.Open();
                        oraCmd.ExecuteNonQuery();
                        dbCon.Close();
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }

        public static bool UpdateIndexingNUMInfo(IndexingNUMInfo numInfo)
        {
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "ORGANIC_INDEXING.DML_TAN_NUMS";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = numInfo.TAN_ID;
                        oraCmd.Parameters.Add("PIN_TAN_NUM_ID", OracleDbType.Int32).Value = numInfo.TAN_NUM_ID;
                        oraCmd.Parameters.Add("PIN_NUM", OracleDbType.Int32).Value = numInfo.NUM;
                        oraCmd.Parameters.Add("PIN_REGNO", OracleDbType.Int32).Value = numInfo.Reg_No;
                        oraCmd.Parameters.Add("PIC_NUM_TYPE", OracleDbType.Varchar2).Value = numInfo.NUMType;
                        oraCmd.Parameters.Add("PIC_DPT_RS", OracleDbType.Varchar2).Value = numInfo.DPT_RS;
                        oraCmd.Parameters.Add("PIC_PAR", OracleDbType.Varchar2).Value = numInfo.PAR;
                        oraCmd.Parameters.Add("PIC_HMD", OracleDbType.Varchar2).Value = numInfo.HMD;
                        oraCmd.Parameters.Add("PIC_AMD", OracleDbType.Varchar2).Value = numInfo.AMD;
                        oraCmd.Parameters.Add("PIC_NUM_ROLE", OracleDbType.Varchar2).Value = numInfo.NUMRole;
                        oraCmd.Parameters.Add("PIC_NUM_NOTE", OracleDbType.Varchar2).Value = numInfo.NUMNote;
                        oraCmd.Parameters.Add("PIC_CTH", OracleDbType.Varchar2).Value = numInfo.CTH;
                        oraCmd.Parameters.Add("PIC_CTH_TYPE", OracleDbType.Varchar2).Value = numInfo.CTH_Type;
                        oraCmd.Parameters.Add("PIC_NUM_TMD", OracleDbType.Varchar2).Value = numInfo.NUM_TMD;
                        oraCmd.Parameters.Add("PIC_NO_STRUCT", OracleDbType.Varchar2).Value = numInfo.NoStructure;
                        oraCmd.Parameters.Add("PIC_IS_POLYMER", OracleDbType.Varchar2).Value = numInfo.PolymerStructure;
                        oraCmd.Parameters.Add("PIC_MOL_FILE", OracleDbType.Varchar2).Value = numInfo.StructureMolFile;
                        oraCmd.Parameters.Add("PIC_INCHI_KEY", OracleDbType.Varchar2).Value = numInfo.StructureInchi;
                        oraCmd.Parameters.Add("PIB_MOL_IMAGE", OracleDbType.Blob).Value = numInfo.StructureImage;

                        oraCmd.Parameters.Add("PIC_IS_TRADE_NAME_POLYMER", OracleDbType.Varchar2).Value = numInfo.IsTradeNamePolymer;
                        oraCmd.Parameters.Add("PIC_IS_REQ_FILE_REVIEW", OracleDbType.Varchar2).Value = numInfo.IsFileReviewRequire;
                        oraCmd.Parameters.Add("PIC_CROSS_REF_POLYMER", OracleDbType.Varchar2).Value = numInfo.CrossReferenceTo;
                        oraCmd.Parameters.Add("PIC_IS_CROSS_REF", OracleDbType.Varchar2).Value = numInfo.IsCrossReferred;
                        
                        oraCmd.Parameters.Add("PIN_UR_ID", OracleDbType.Int32).Value = numInfo.URID;
                        oraCmd.Parameters.Add("PIC_OPTION", OracleDbType.Varchar2).Value = numInfo.Option;                        
                        oraCmd.Parameters.Add("POC_STATUS", OracleDbType.Varchar2, 50).Direction = ParameterDirection.Output;
                        dbCon.Open();
                        oraCmd.ExecuteNonQuery();
                        dbCon.Close();

                        //if (oraCmd.Parameters["POC_STATUS"].Value != null)
                        //{
                        //   string strStatus = oraCmd.Parameters["POC_STATUS"].Value.ToString();
                        //}

                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }

        public static bool UpdateIndexingNUMInfo_XML(IndexingNUMInfo numInfo)
        {
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "ORGANIC_INDEXING.DML_TAN_NUMS_XML";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = numInfo.TAN_ID;
                        oraCmd.Parameters.Add("PIN_TAN_NUM_ID", OracleDbType.Int32).Value = numInfo.TAN_NUM_ID;
                        oraCmd.Parameters.Add("PIN_NUM", OracleDbType.Int32).Value = numInfo.NUM;
                        oraCmd.Parameters.Add("PIN_REGNO", OracleDbType.Int32).Value = numInfo.Reg_No;
                        oraCmd.Parameters.Add("PIC_NUM_TYPE", OracleDbType.Varchar2).Value = numInfo.NUMType;
                        oraCmd.Parameters.Add("PIC_DPT_RS", OracleDbType.Varchar2).Value = numInfo.DPT_RS;
                        oraCmd.Parameters.Add("PIC_PAR", OracleDbType.Varchar2).Value = numInfo.PAR;
                        oraCmd.Parameters.Add("PIC_HMD", OracleDbType.Varchar2).Value = numInfo.HMD;
                        oraCmd.Parameters.Add("PIC_AMD", OracleDbType.Varchar2).Value = numInfo.AMD;
                        oraCmd.Parameters.Add("PIC_NUM_ROLE", OracleDbType.Varchar2).Value = numInfo.NUMRole;
                        oraCmd.Parameters.Add("PIC_NUM_NOTE", OracleDbType.Varchar2).Value = numInfo.NUMNote;
                        oraCmd.Parameters.Add("PIC_CTH", OracleDbType.Varchar2).Value = numInfo.CTH;
                        oraCmd.Parameters.Add("PIC_CTH_TYPE", OracleDbType.Varchar2).Value = numInfo.CTH_Type;
                        oraCmd.Parameters.Add("PIC_NUM_TMD", OracleDbType.Varchar2).Value = numInfo.NUM_TMD;
                        oraCmd.Parameters.Add("PIC_NO_STRUCT", OracleDbType.Varchar2).Value = numInfo.NoStructure;
                        oraCmd.Parameters.Add("PIC_IS_POLYMER", OracleDbType.Varchar2).Value = numInfo.PolymerStructure;
                        oraCmd.Parameters.Add("PIC_MOL_FILE", OracleDbType.Varchar2).Value = numInfo.StructureMolFile;
                        oraCmd.Parameters.Add("PIC_INCHI_KEY", OracleDbType.Varchar2).Value = numInfo.StructureInchi;
                        oraCmd.Parameters.Add("PIB_MOL_IMAGE", OracleDbType.Blob).Value = numInfo.StructureImage;

                        oraCmd.Parameters.Add("PIC_IS_TRADE_NAME_POLYMER", OracleDbType.Varchar2).Value = numInfo.IsTradeNamePolymer;
                        oraCmd.Parameters.Add("PIC_IS_REQ_FILE_REVIEW", OracleDbType.Varchar2).Value = numInfo.IsFileReviewRequire;
                        oraCmd.Parameters.Add("PIC_CROSS_REF_POLYMER", OracleDbType.Varchar2).Value = numInfo.CrossReferenceTo;
                        oraCmd.Parameters.Add("PIC_IS_CROSS_REF", OracleDbType.Varchar2).Value = numInfo.IsCrossReferred;

                        oraCmd.Parameters.Add("PIC_SRC_INDX_TERM", OracleDbType.Varchar2).Value = numInfo.SrcDocIndexTerm;
                        oraCmd.Parameters.Add("PIN_SRC_DOC_ID", OracleDbType.Int32).Value = numInfo.IndexTermSrcDocID;

                        oraCmd.Parameters.Add("PIN_UR_ID", OracleDbType.Int32).Value = numInfo.URID;
                        oraCmd.Parameters.Add("PIC_OPTION", OracleDbType.Varchar2).Value = numInfo.Option;
                        oraCmd.Parameters.Add("POC_STATUS", OracleDbType.Varchar2, 50).Direction = ParameterDirection.Output;
                        dbCon.Open();
                        oraCmd.ExecuteNonQuery();
                        dbCon.Close();

                        //if (oraCmd.Parameters["POC_STATUS"].Value != null)
                        //{
                        //   string strStatus = oraCmd.Parameters["POC_STATUS"].Value.ToString();
                        //}

                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }

        public static DataTable GetIndexingNUMsOnTANID(int tanid, string numType)
        {
            DataTable dtNUMs = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "ORGANIC_INDEXING.GET_INDX_NUMS_DTLS_ON_TAN_ID";
                    oraCmd.CommandType = CommandType.StoredProcedure;

                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanid;
                    oraCmd.Parameters.Add("PIC_NUM_TYPE", OracleDbType.Varchar2).Value = numType;
                    oraCmd.Parameters.Add("PORC_NUM_DTLS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                   
                    dtNUMs = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtNUMs);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtNUMs;
        }

        public static DataTable GetIndexingQueryTANs(List<Int32> tanIDs)
        {
            DataTable dtQueryTANs = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "ORGANIC_INDEXING.GET_QUERY_TAN_DTLS";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    
                    OracleParameter paTANIDs = new OracleParameter();
                    paTANIDs.ParameterName = "PINA_TAN_IDS";
                    paTANIDs.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                    paTANIDs.OracleDbType = OracleDbType.Int64;
                    if (tanIDs.Count > 0)
                    {
                        paTANIDs.Value = tanIDs.ToArray();
                    }
                    else
                    {
                        paTANIDs.Value = new Int32[1] { 0 };
                        paTANIDs.Size = 0;
                    }
                    oraCmd.Parameters.Add(paTANIDs);
                    oraCmd.Parameters.Add("PORC_QUERY_TANS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    dtQueryTANs = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtQueryTANs);
                }
            }
            catch (Exception ex)
            {               
                throw ex;
            }
            return dtQueryTANs;
        }

        public static DataTable GetMacroIndexingQueryTANs(List<Int32> tanIDs)
        {
            DataTable dtQueryTANs = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "ORGANIC_INDEXING.GET_MACRO_QUERY_TAN_DTLS";
                    oraCmd.CommandType = CommandType.StoredProcedure;

                    OracleParameter paTANIDs = new OracleParameter();
                    paTANIDs.ParameterName = "PINA_TAN_IDS";
                    paTANIDs.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                    paTANIDs.OracleDbType = OracleDbType.Int64;
                    if (tanIDs.Count > 0)
                    {
                        paTANIDs.Value = tanIDs.ToArray();
                    }
                    else
                    {
                        paTANIDs.Value = new Int32[1] { 0 };
                        paTANIDs.Size = 0;
                    }
                    oraCmd.Parameters.Add(paTANIDs);
                    oraCmd.Parameters.Add("PORC_QUERY_TANS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    dtQueryTANs = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtQueryTANs);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtQueryTANs;
        }

        public static DataTable GetIndexingNUMsOnTANIDForSdfExport(int tanid)
        {
            DataTable dtNUMs = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "ORGANIC_INDEXING.GET_NUMS_DTLS_ON_TAN_SDF";
                    oraCmd.CommandType = CommandType.StoredProcedure;

                    oraCmd.Parameters.Add("PIN_TAN_ID", OracleDbType.Int32).Value = tanid;                  
                    oraCmd.Parameters.Add("PORC_NUM_DTLS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    dtNUMs = new DataTable();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dtNUMs);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtNUMs;
        }

        public static bool UpdateTANKeyWords(string application, string shipment, List<string> tansList, List<string> keywordsList)
        {
            bool blStatus = false;
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "ORGANIC_INDEXING.UPDATE_KEYWORDS_ON_APP_TAN";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        oraCmd.Parameters.Add("PIC_APPLICATION", OracleDbType.Varchar2).Value = application;
                        oraCmd.Parameters.Add("PIC_SHIPMENT", OracleDbType.Varchar2).Value = shipment;

                        OracleParameter paTAN_Names = new OracleParameter();
                        paTAN_Names.ParameterName = "PICA_TANS";
                        paTAN_Names.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paTAN_Names.OracleDbType = OracleDbType.Varchar2;
                        if (tansList.Count > 0)
                        {

                            paTAN_Names.Value = tansList.ToArray();
                        }
                        else
                        {
                            paTAN_Names.Value = new string[1] { "" };
                            paTAN_Names.Size = 0;
                        }
                        oraCmd.Parameters.Add(paTAN_Names);

                        OracleParameter paKeywords = new OracleParameter();
                        paKeywords.ParameterName = "PICA_KEYWORDS";
                        paKeywords.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paKeywords.OracleDbType = OracleDbType.Varchar2;
                        if (keywordsList.Count > 0)
                        {

                            paKeywords.Value = keywordsList.ToArray();
                        }
                        else
                        {
                            paKeywords.Value = new string[1] { "" };
                            paKeywords.Size = 0;
                        }
                        oraCmd.Parameters.Add(paKeywords);

                        oraCmd.Parameters.Add("POC_STATUS ", OracleDbType.Varchar2, 50).Direction = ParameterDirection.Output;

                        dbCon.Open();
                        oraCmd.ExecuteNonQuery();
                        dbCon.Close();
                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return blStatus;
        }

        public static bool UpdateAndGetIndexingCTHInfo(List<CTH_Properties> cthsInfoList, string applicationName)
        {
            bool blStatus = false;
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.CommandText = "CTH_BULK_INSERTS";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = dbCon;

                        oraCmd.Parameters.Add("PIC_APPLICATION", OracleDbType.Varchar2).Value = applicationName;

                        OracleParameter paCthID = new OracleParameter();
                        paCthID.ParameterName = "PINA_CTH_ID";
                        paCthID.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paCthID.OracleDbType = OracleDbType.Int32;
                        paCthID.Value = cthsInfoList.Count > 0 ? cthsInfoList.Select(x => x.CTH_ID).ToArray() : new Int32[1] { 0 };
                        oraCmd.Parameters.Add(paCthID);

                        OracleParameter paCthClass = new OracleParameter();
                        paCthClass.ParameterName = "PICA_CTH_CLASS";
                        paCthClass.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paCthClass.OracleDbType = OracleDbType.Varchar2;
                        paCthClass.Value = cthsInfoList.Count > 0 ? cthsInfoList.Select(x => x.Class).ToArray() : new string[1] { "" };
                        oraCmd.Parameters.Add(paCthClass);

                        OracleParameter paCthName = new OracleParameter();
                        paCthName.ParameterName = "PICA_CTH_NAME";
                        paCthName.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paCthName.OracleDbType = OracleDbType.Varchar2;
                        paCthName.Value = cthsInfoList.Count > 0 ? cthsInfoList.Select(x => x.Name).ToArray() : new string[1] { "" };
                        oraCmd.Parameters.Add(paCthName);

                        OracleParameter paCthType = new OracleParameter();
                        paCthType.ParameterName = "PICA_CTH_TYPE";
                        paCthType.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paCthType.OracleDbType = OracleDbType.Varchar2;
                        paCthType.Value = cthsInfoList.Count > 0 ? cthsInfoList.Select(x => x.Type).ToArray() : new string[1] { "" };
                        oraCmd.Parameters.Add(paCthType);

                        OracleParameter paCategoryType = new OracleParameter();
                        paCategoryType.ParameterName = "PICA_CATEGORY_TYPE";
                        paCategoryType.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paCategoryType.OracleDbType = OracleDbType.Varchar2;
                        paCategoryType.Value = cthsInfoList.Count > 0 ? cthsInfoList.Select(x => x.CategoryType).ToArray() : new string[1] { "" };
                        oraCmd.Parameters.Add(paCategoryType);

                        oraCmd.Parameters.Add("PORC_CTH", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                        DataTable cthData = new DataTable();
                        OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                        oraAdpt.Fill(cthData);
                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return blStatus;
        }
   }
}
