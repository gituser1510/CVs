﻿#region Name Spaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Oracle.ManagedDataAccess.Client;
using IndxReactNarrBLL;
#endregion

namespace IndxReactNarrDAL
{
    /// <summary>
    /// Class UserMasterDAL - All dml and Retrival opeartions.
    /// </summary>
    public class UserManagementDB
    {
        
        /// <summary>
        /// Create Users
        /// </summary>
        /// <param name="userMaster">Object: class reference object of UserMasterBLL</param>
        /// <returns>string : status message</returns>
        public static string CreateUser(UserMasterBLL userMaster)
        {
            string strUserStatus = "";
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oCmd = new OracleCommand())
                    {
                        OracleParameter[] oPrms = new OracleParameter[8];

                        oPrms[0] = new OracleParameter("PIN_USER_ID", OracleDbType.Int32, userMaster.UserId, ParameterDirection.Input);
                        oPrms[1] = new OracleParameter("PIC_USER_NAME", OracleDbType.Varchar2, 100, userMaster.UserName, ParameterDirection.Input);
                        oPrms[2] = new OracleParameter("PIC_EMAIL_ID", OracleDbType.Varchar2, 100, userMaster.EmailAddress, ParameterDirection.Input);
                        oPrms[3] = new OracleParameter("PIC_PASSWORD", OracleDbType.Varchar2, 100, userMaster.UserPassword, ParameterDirection.Input);
                        oPrms[4] = new OracleParameter("PIC_IS_ACTIVE", OracleDbType.Varchar2, 1, userMaster.Status, ParameterDirection.Input);
                        oPrms[5] = new OracleParameter("PIC_OP_TYPE", OracleDbType.Varchar2, 10, userMaster.OptionType, ParameterDirection.Input);
                        oPrms[6] = new OracleParameter("PIC_IS_LDAP_USER", OracleDbType.Char, 1, userMaster.IsLDAPUser, ParameterDirection.Input);
                        oPrms[7] = new OracleParameter("POC_STATUS", OracleDbType.Varchar2, 100, null, ParameterDirection.Output);

                        oCmd.CommandText = "USER_MANAGEMENT.SAVE_USER";
                        oCmd.CommandType = CommandType.StoredProcedure;
                        oCmd.Connection = dbCon;
                        oCmd.Parameters.AddRange(oPrms);

                        dbCon.Open();
                        oCmd.ExecuteNonQuery();
                        strUserStatus = oPrms[7].Value != null ? oPrms[7].Value.ToString() : "";
                        dbCon.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return strUserStatus;
        }

        /// <summary>
        /// Create Profile
        /// </summary>
        /// <param name="userRole">Object: class reference object of UserProfileBLL</param>
        /// <returns>string : status message</returns>
        public static string CreateProfile(UserProfileBLL userRole)
        {
            string strUserStatus = "";
            try
            {
                using (OracleConnection dbCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oCmd = new OracleCommand())
                    {
                        oCmd.CommandText = "USER_MANAGEMENT.SAVE_USER_ROLE";
                        oCmd.CommandType = CommandType.StoredProcedure;
                        oCmd.Connection = dbCon;

                        OracleParameter[] oPrms = new OracleParameter[5];

                        oPrms[0] = new OracleParameter("PIN_USER_ID", OracleDbType.Int32, userRole.UserId, ParameterDirection.Input);
                        oPrms[1] = new OracleParameter("PIN_ROLE_ID", OracleDbType.Int32, userRole.RoleId, ParameterDirection.Input);
                        oPrms[2] = new OracleParameter("PIC_APPLICATIONNAME", OracleDbType.Varchar2, userRole.ApplicationName, ParameterDirection.Input);
                        oPrms[3] = new OracleParameter("PIC_MODULE", OracleDbType.Varchar2, userRole.ModuleName, ParameterDirection.Input);
                        oPrms[4] = new OracleParameter("POC_STATUS", OracleDbType.Varchar2, 100, null, ParameterDirection.Output);
                                               
                        oCmd.Parameters.AddRange(oPrms);

                        dbCon.Open();
                        oCmd.ExecuteNonQuery();
                        strUserStatus = oPrms[4].Value != null ? oPrms[4].Value.ToString() : "";
                        dbCon.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return strUserStatus;
        }

        /// <summary>
        /// Get all Users
        /// </summary>
        /// <returns>Data Table: - Get all users details</returns>
        public static DataTable GetUserDetails()
        {
            DataTable dtUserDetails = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "USER_MANAGEMENT.GET_USERS";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PORC_USERS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    DataSet dsResults = new DataSet();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dsResults);
                    if (dsResults != null)
                    {
                        if (dsResults.Tables.Count > 0)
                        {
                            if (dsResults.Tables[0] != null)
                            {
                                dtUserDetails = dsResults.Tables[0];
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtUserDetails;
        }
        
        /// <summary>
        /// Get all Active Users
        /// </summary>
        /// <returns>Data Table: - Get all users details</returns>
        public static DataTable GetActiveUserDetails()
        {
            DataTable dtUserDetails = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "USER_MANAGEMENT.GET_ACTIVE_USERS";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PORC_USERS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    DataSet dsResults = new DataSet();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dsResults);
                    if (dsResults != null)
                    {
                        if (dsResults.Tables.Count > 0)
                        {
                            if (dsResults.Tables[0] != null)
                            {
                                dtUserDetails = dsResults.Tables[0];
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtUserDetails;
        }
        
        /// <summary>
        /// Get all roles
        /// </summary>
        /// <returns>Data Table: - Get all roles</returns>
        public static DataTable GetRoles()
        {
            DataTable dtRoles = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "USER_MANAGEMENT.GET_ROLES";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PORC_ROLES", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    DataSet dsResults = new DataSet();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dsResults);

                    if (dsResults != null)
                    {
                        if (dsResults.Tables.Count > 0)
                        {
                            if (dsResults.Tables[0] != null)
                            {
                                dtRoles = dsResults.Tables[0];
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtRoles;
        }

        /// <summary>
        /// Get Team Lead Details by Role
        /// </summary>
        /// <param name="roleId">int: role Id</param>
        /// <returns>Data Table: - Get Team Lead Details</returns>
        public static DataTable GetTeamLeadDetails(int roleId)
        {
            DataTable dtRoles = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "USERS_TEAM_MANAGEMENT.GET_MANAGERS_BY_ROLE";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PIN_ROLE_ID", OracleDbType.Int32).Value = roleId;
                    oraCmd.Parameters.Add("PORC_MANAGERS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    DataSet dsResults = new DataSet();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dsResults);

                    if (dsResults != null)
                    {
                        if (dsResults.Tables.Count > 0)
                        {
                            if (dsResults.Tables[0] != null)
                            {
                                dtRoles = dsResults.Tables[0];
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtRoles;
        }
        
        /// <summary>
        /// Get Incharge Details by Role and TL
        /// </summary>
        /// <param name="roleId">int: current user role Id</param>
        /// <param name="teamLeadUrId">int: TL user id</param>
        /// <returns>Data Table: - Get Incharge Details by Role and TL</returns>
        public static DataTable GetInchargeDetails(int roleId, int teamLeadUrId)
        {
            DataTable dtInchargeDetails = null;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "USERS_TEAM_MANAGEMENT.GET_INCHARGE_NAMES";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Parameters.Add("PIN_ROLE_ID", OracleDbType.Int32).Value = roleId;
                        oraCmd.Parameters.Add("PIN_TEAM_LEAD_UR_ID", OracleDbType.Int32).Value = teamLeadUrId == 0 ? Convert.DBNull : teamLeadUrId;
                        oraCmd.Parameters.Add("PORC_INCHARGE_NAMES", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                        DataSet dsResults = new DataSet();
                        OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                        oraAdpt.Fill(dsResults);

                        if (dsResults != null)
                        {
                            if (dsResults.Tables.Count > 0)
                            {
                                if (dsResults.Tables[0] != null)
                                {
                                    dtInchargeDetails = dsResults.Tables[0];
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtInchargeDetails;
        }
        
        /// <summary>
        /// Get all user profile details
        /// </summary>
        /// <returns>Data Table: - Get all user profile details</returns>
        public static DataTable GetUserProfileDetails()
        {
            DataTable dtUserDetails = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "USER_MANAGEMENT.GET_ACTIVE_USER_ROLES";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PORC_USER_ROLE_DETAILS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    DataSet dsResults = new DataSet();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dsResults);
                    if (dsResults != null)
                    {
                        if (dsResults.Tables.Count > 0)
                        {
                            if (dsResults.Tables[0] != null)
                            {
                                dtUserDetails = dsResults.Tables[0];
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtUserDetails;
        }

        //GET_TEAM_LEADER_CURATION_TEAM

        /// <summary>
        ///  Get all users in Team(QC.Analyst/Rev.Analyst/Analyst) by Team Leader Id.
        /// </summary>
        /// <param name="teamLeaderUserRoleId">int: Team Leader UR_Id</param>
        /// <returns>Data Table - Get All Users In Team By TeamLeader UserRole Id</returns>
        public static DataTable GetAllUsersInTeamByTeamLeaderUserRoleId(int teamLeaderUserRoleId)
        {
            DataTable dtAllUsersInTeam = null;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        //Initialization & settings
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "USERS_TEAM_MANAGEMENT.GET_TEAM_LEADER_CURATION_TEAM";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        //Parameters                        
                        oraCmd.Parameters.Add("PIN_TL_UR_ID", OracleDbType.Int32).Value = teamLeaderUserRoleId;
                        oraCmd.Parameters.Add("PORC_CURATION_TEAM", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                        // Filling data to out parameter ref-cursor to data table.
                        dtAllUsersInTeam = new DataTable();
                        OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                        oraAdpt.Fill(dtAllUsersInTeam);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtAllUsersInTeam;
        }
 
        /// <summary>
        /// Get user details by user name and role id.
        /// </summary>
        /// <param name="userName">string: user name</param>
        /// <param name="roleId">int: role id</param>
        /// <returns>Data Table - All details including</returns>
        public static DataTable GetUserDetailsByUserNameAndRoleId(string userName, int roleId,string application, string module)
        {
            DataTable dtUserDetails = null;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {                       
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "USER_MANAGEMENT.GET_USER_DETAILS";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        oraCmd.Parameters.Add("PIC_APPLICATION", OracleDbType.Varchar2).Value = application;
                        oraCmd.Parameters.Add("PIC_USER_NAME", OracleDbType.Varchar2).Value = userName;
                        oraCmd.Parameters.Add("PIN_ROLE_ID", OracleDbType.Int32).Value = roleId;
                        oraCmd.Parameters.Add("PIC_MODULE", OracleDbType.Varchar2).Value = module;
                        oraCmd.Parameters.Add("PORC_USER_DETAILS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                                                
                        dtUserDetails = new DataTable();
                        OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                        oraAdpt.Fill(dtUserDetails);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtUserDetails;
        }

        /// <summary>
        /// Method used to In Activate User Role
        /// </summary>
        /// <param name="selUserRoleID">int: user role map id</param>
        /// <param name="statusMsg">string out: status message</param>
        /// <returns>Bool: true - sucess, false - failed.</returns>
        public static bool InActivateUserRole( int selUserRoleID, out string statusMsg)
        {
            bool blStatus = false;
            string strTemp = string.Empty;

            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "USER_MANAGEMENT.INACTIVATE_USER_ROLE";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                       //PIN_UR_ID
                        oraCmd.Parameters.Add("PIN_UR_ID", OracleDbType.Int32).Value = selUserRoleID;

                        OracleParameter paStatus = new OracleParameter();
                        paStatus.Direction = ParameterDirection.Output;
                        paStatus.OracleDbType = OracleDbType.Varchar2;
                        paStatus.Size = 200;
                        oraCmd.Parameters.Add(paStatus);


                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        blStatus = true;
                        oraCon.Close();

                        if (paStatus.Value != null)
                        {
                            if (paStatus.Value.ToString().Length > 0)
                            {
                                strTemp = paStatus.Value.ToString();
                            }
                            else
                            {
                                strTemp = paStatus.Value.ToString();
                            }
                        }

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            statusMsg = strTemp;
            return blStatus;
        }

        public static bool InActivateTeamUser(int userRoleID, out string statusMsg)
        {
            bool blStatus = false;
            string strTemp = string.Empty;

            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "USER_MANAGEMENT.INACTIVATE_TEAM_USERS";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        //PIN_UR_ID
                        oraCmd.Parameters.Add("PIN_TEAM_USER_ID", OracleDbType.Int32).Value = userRoleID;

                        OracleParameter paStatus = new OracleParameter();
                        paStatus.Direction = ParameterDirection.Output;
                        paStatus.OracleDbType = OracleDbType.Varchar2;
                        paStatus.Size = 200;
                        oraCmd.Parameters.Add(paStatus);


                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        blStatus = true;
                        oraCon.Close();

                        if (paStatus.Value != null)
                        {
                            if (paStatus.Value.ToString().Length > 0)
                            {
                                strTemp = paStatus.Value.ToString();
                            }
                            else
                            {
                                strTemp = paStatus.Value.ToString();
                            }
                        }

                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            statusMsg = strTemp;
            return blStatus;
        }

        public static DataTable GetUserDetailsByApplicationAndRoleID(string strApplicationName, string strModuleName, int role_ID)
        {
            DataTable dtUserDetails = null;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        //Initialization & settings
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "USER_MANAGEMENT.GET_USERNAMES_BY_APP_MOD";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        //Parameters                        
                        oraCmd.Parameters.Add("PIC_APPLICATION", OracleDbType.Varchar2).Value = strApplicationName;
                        oraCmd.Parameters.Add("PIC_MODULE", OracleDbType.Varchar2).Value = strModuleName;
                        oraCmd.Parameters.Add("PIN_ROLE_ID", OracleDbType.Int32).Value = role_ID;
                        oraCmd.Parameters.Add("PORC_RECORDS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                        // Filling data to out parameter ref-cursor to data table.
                        dtUserDetails = new DataTable();
                        OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                        oraAdpt.Fill(dtUserDetails);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtUserDetails;
        }

        public static string CreateTeamStructure(UserProfileBLL userProfile)
        {           
            string strUserStatus = "";
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {                   
                        oraCmd.CommandText = "USER_MANAGEMENT.DML_TEAM_USERS";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                        oraCmd.Connection = oraCon;
                        oraCmd.Parameters.Add("PIC_APPLICATION", OracleDbType.Varchar2).Value = userProfile.ApplicationName;
                        oraCmd.Parameters.Add("PIC_MODULE", OracleDbType.Varchar2).Value = userProfile.ModuleName;
                        oraCmd.Parameters.Add("PIN_ANLST_UR_ID", OracleDbType.Int32).Value = userProfile.AnalystURID == 0 ? Convert.DBNull : userProfile.AnalystURID;
                        oraCmd.Parameters.Add("PIN_QUAL_ANLST_UR_ID", OracleDbType.Int32).Value = userProfile.QualityAnalystURID == 0 ? Convert.DBNull : userProfile.QualityAnalystURID;
                        oraCmd.Parameters.Add("PIN_REV_ANLST_UR_ID", OracleDbType.Int32).Value = userProfile.ReviewerAnalystURID == 0 ? Convert.DBNull : userProfile.ReviewerAnalystURID;
                        oraCmd.Parameters.Add("POC_STATUS", OracleDbType.Varchar2, 100).Direction = ParameterDirection.Output; 
                                       
                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();
                        oraCon.Close();

                        strUserStatus = oraCmd.Parameters["POC_STATUS"].Value != null ? oraCmd.Parameters["POC_STATUS"].Value.ToString() : "";                       
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return strUserStatus;
        }

        public static DataTable GetUserTeamUsersDetails()
        {
            DataTable dtTeamUserDetails = null;
            try
            {
                using (OracleCommand oraCmd = new OracleCommand())
                {
                    oraCmd.Connection = ConnectionDB.GetOracleConnection();
                    oraCmd.CommandText = "USER_MANAGEMENT.GET_TEAM_USERS";
                    oraCmd.CommandType = CommandType.StoredProcedure;
                    oraCmd.Parameters.Add("PORC_RECORDS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    DataSet dsResults = new DataSet();
                    OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                    oraAdpt.Fill(dsResults);
                    if (dsResults != null)
                    {
                        if (dsResults.Tables.Count > 0)
                        {
                            if (dsResults.Tables[0] != null)
                            {
                                dtTeamUserDetails = dsResults.Tables[0];
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtTeamUserDetails;
        }

        public static DataTable GetUsersByApplication(string strApplicationName, string strModuleName, int role_ID)
        {
            DataTable dtUserDetails = null;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        //Initialization & settings
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "USER_MANAGEMENT.GET_USERNAMES_BY_APP_MOD";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        //Parameters                        
                        oraCmd.Parameters.Add("PIC_APPLICATION", OracleDbType.Varchar2).Value = strApplicationName;
                        oraCmd.Parameters.Add("PIC_MODULE", OracleDbType.Varchar2).Value = strModuleName;
                        oraCmd.Parameters.Add("PIN_ROLE_ID", OracleDbType.Int32).Value = role_ID;
                        oraCmd.Parameters.Add("PORC_RECORDS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                        // Filling data to out parameter ref-cursor to data table.
                        dtUserDetails = new DataTable();
                        OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                        oraAdpt.Fill(dtUserDetails);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtUserDetails;
        }

        public static DataTable CheckUserProfileDetails(string appName, string moduleName)
        {
            DataTable dtUserProfileDetails = null;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        //Initialization & settings
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "USER_MANAGEMENT.CHECK_TOOLMANAGER_ISEXIST";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        //Parameters                        
                        oraCmd.Parameters.Add("PIC_APPLICATION", OracleDbType.Varchar2).Value = appName;
                        oraCmd.Parameters.Add("PIC_MODULE", OracleDbType.Varchar2).Value = moduleName;
                        oraCmd.Parameters.Add("PORC_RECORDS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                        // Filling data to out parameter ref-cursor to data table.
                        dtUserProfileDetails = new DataTable();
                        OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                        oraAdpt.Fill(dtUserProfileDetails);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtUserProfileDetails;
        }

        public static DataTable GetUserCredentialsByUserNameAndPassword(string userName, string userPassword)
        {
            DataTable dtUserCredentials = null;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        //Initialization & settings
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "USER_MANAGEMENT.GET_USER_CREDENTIALS";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        //Parameters                        
                        oraCmd.Parameters.Add("PIC_USER_NAME", OracleDbType.Varchar2).Value = userName;
                        oraCmd.Parameters.Add("PIC_PASSWORD", OracleDbType.Varchar2).Value = userPassword;
                        oraCmd.Parameters.Add("PORC_RECORDS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                        // Filling data to out parameter ref-cursor to data table.
                        dtUserCredentials = new DataTable();
                        OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                        oraAdpt.Fill(dtUserCredentials);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtUserCredentials;
        }

        public static DataTable GetApplicationActiveUsers(string appName)
        {
            DataTable usersDetails = null;
            try
            {
                using (OracleConnection oraCon = ConnectionDB.GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {                       
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "USER_MANAGEMENT.GET_ACTIVE_USERS_BY_APP";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                      
                        oraCmd.Parameters.Add("PIC_APPLICATION", OracleDbType.Varchar2).Value = appName;
                        oraCmd.Parameters.Add("PORC_ACTIVE_USERS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                        usersDetails = new DataTable();
                        OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                        oraAdpt.Fill(usersDetails);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return usersDetails;
        }
    }
}