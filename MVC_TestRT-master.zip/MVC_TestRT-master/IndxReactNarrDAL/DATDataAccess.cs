﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IndxReactNarrBLL;
using Oracle.ManagedDataAccess.Client;

namespace IndxReactNarrDAL
{
    public class DATDataAccess
    {
        static string conHostName = "172.21.0.45";
        static string conPort = "1522";
        static string conDatabase = "SCIBASE_PROD_NEW";       
        static string dbUserName = "DAT_PROD";
        static string dbPwd = "DAT_PROD";
        static string conString = "";

        public static OracleConnection GetOracleConnection()
        {
            OracleConnection con = null;
            try
            {
                 //conString = string.Format("Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST={0})(PORT={1})))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME={2})));User Id={3};Password={4};"
                 //+ " Connection Timeout=60;Validate Connection = true", conHostName, conPort, conDatabase, dbUserName, dbPwd);

                con = new OracleConnection("User Id=DAT_PROD;Password=DAT_PROD;Data source=SCIBASE_PROD_NEW;");
                //con = new OracleConnection(conString); 
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return con;
        }

        //public static DataTable GetUserWorkedHours(PTTProductivity pttProd)
        //{            
        //    DataTable dtWorkedHrs = null;
        //    try
        //    {
        //        using (OracleConnection oraCon = GetOracleConnection())
        //        {
        //            using (OracleCommand oraCmd = new OracleCommand())
        //            {
        //                oraCmd.Connection = oraCon;
        //                oraCmd.CommandText = "GET_WORKED_HOURS";
        //                oraCmd.CommandType = CommandType.StoredProcedure;

        //                oraCmd.Parameters.Add("PIN_APPL_USER_ID", System.Data.OracleClient.OracleType.VarChar).Value = pttProd.UserName;
        //                oraCmd.Parameters.Add("PIC_APPL_ID", System.Data.OracleClient.OracleType.Int32).Value = pttProd.ApplicationID;
        //                oraCmd.Parameters.Add("PIN_USER_PROD", System.Data.OracleClient.OracleType.Int32).Value = pttProd.Productivity;
        //                oraCmd.Parameters.Add("PIC_PROD_DATE", System.Data.OracleClient.OracleType.VarChar).Value = pttProd.FromDate;                       
        //                oraCmd.Parameters.Add("PIC_USER_ROLE_NAME", System.Data.OracleClient.OracleType.VarChar).Value = pttProd.UserRole;

        //                dtWorkedHrs = new DataTable();
        //                OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
        //                oraAdpt.Fill(dtWorkedHrs);        
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }            
        //    return dtWorkedHrs;
        //}

        public static DataTable GetUserWorkedHours(PTTProductivityBO pttProd)
        {
            DataTable dtWorkedHrs = null;
            try
            {
                using (OracleConnection oraCon = GetOracleConnection())
                {
                    using (OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "USER_PRODUCTIVITY_UPDATES.GET_USER_TASK_HOURS";
                        oraCmd.CommandType = CommandType.StoredProcedure;

                        oraCmd.Parameters.Add("PIC_PROJECT_NAME", OracleDbType.Varchar2).Value = pttProd.ProjectName;
                       // oraCmd.Parameters.Add("PID_START_DATE", OracleDbType.Date).Value = pttProd.ProdStartDate;
                        //oraCmd.Parameters.Add("PID_END_DATE", OracleDbType.Date).Value = pttProd.ProdEndDate;
                        
                        OracleParameter paUsers = new OracleParameter();
                        paUsers.ParameterName = "PICA_USERS";
                        paUsers.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paUsers.OracleDbType = OracleDbType.Varchar2;
                        if (pttProd.UsersList != null)
                        {
                            if (pttProd.UsersList.Length > 0)
                            {
                                paUsers.Value = pttProd.UsersList;
                            }
                            else
                            {
                                paUsers.Value = new string[1] { "" };
                                paUsers.Size = 0;
                            }
                        }
                        else
                        {
                            paUsers.Value = new string[1] { "" };
                            paUsers.Size = 0;
                        }
                        oraCmd.Parameters.Add(paUsers);

                        oraCmd.Parameters.Add("PORC_USER_TASK_HOURS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                        dtWorkedHrs = new DataTable();
                        OracleDataAdapter oraAdpt = new OracleDataAdapter(oraCmd);
                        oraAdpt.Fill(dtWorkedHrs);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtWorkedHrs;
        }

        public static bool UpdateUserProductivity(PTTProductivityBO pttProd)
        {
            bool blStatus = false;
            try
            {
                using(OracleConnection oraCon = GetOracleConnection())
                {
                    using(OracleCommand oraCmd = new OracleCommand())
                    {
                        oraCmd.Connection = oraCon;
                        oraCmd.CommandText = "USER_PRODUCTIVITY_UPDATES.UPDATE_USER_PRODUCTIVITY";
                        oraCmd.CommandType = CommandType.StoredProcedure;
                                                
                        OracleParameter paUsers = new OracleParameter();
                        paUsers.ParameterName = "PICA_USER_ID";
                        paUsers.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paUsers.OracleDbType = OracleDbType.Varchar2;
                        if (pttProd.UsersList != null)
                        {
                            if (pttProd.UsersList.Length > 0)
                            {
                                paUsers.Value = pttProd.UsersList;
                            }
                            else
                            {
                                paUsers.Value = new string[1] { "" };
                                paUsers.Size = 0;
                            }
                        }
                        else
                        {
                            paUsers.Value = new string[1] { "" };
                            paUsers.Size = 0;
                        }
                        oraCmd.Parameters.Add(paUsers);

                        OracleParameter paUserRoles = new OracleParameter();
                        paUserRoles.ParameterName = "PICA_USER_ROLE_NAME";
                        paUserRoles.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paUserRoles.OracleDbType = OracleDbType.Varchar2;
                        if (pttProd.UsersRoles != null)
                        {
                            if (pttProd.UsersRoles.Length > 0)
                            {
                                paUserRoles.Value = pttProd.UsersRoles;
                            }
                            else
                            {
                                paUserRoles.Value = new string[1] { "" };
                                paUserRoles.Size = 0;
                            }
                        }
                        else
                        {
                            paUserRoles.Value = new string[1] { "" };
                            paUserRoles.Size = 0;
                        }
                        oraCmd.Parameters.Add(paUserRoles);

                        OracleParameter paActivityCode = new OracleParameter();
                        paActivityCode.ParameterName = "PICA_DAT_ACT_CODE";
                        paActivityCode.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paActivityCode.OracleDbType = OracleDbType.Varchar2;
                        if (pttProd.ActivityCodes != null)
                        {
                            if (pttProd.ActivityCodes.Length > 0)
                            {
                                paActivityCode.Value = pttProd.ActivityCodes;
                            }
                            else
                            {
                                paActivityCode.Value = new string[1] { "" };
                                paActivityCode.Size = 0;
                            }
                        }
                        else
                        {
                            paActivityCode.Value = new string[1] { "" };
                            paActivityCode.Size = 0;
                        }
                        oraCmd.Parameters.Add(paActivityCode);

                        oraCmd.Parameters.Add("PIC_APP_TOOL_NAME", OracleDbType.Varchar2).Value = pttProd.ProjectToolName;
                        oraCmd.Parameters.Add("PIC_DAT_PROJECT_NAME", OracleDbType.Varchar2).Value = pttProd.ProjectName;
                        oraCmd.Parameters.Add("PIC_SUBMITTED_USER_ID", OracleDbType.Varchar2).Value = pttProd.SubmittedByUser;

                        OracleParameter paProdDate = new OracleParameter();
                        paProdDate.ParameterName = "PIDA_PRODUCTIVITY_DATE";
                        paProdDate.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paProdDate.OracleDbType = OracleDbType.Date;
                        if (pttProd.ProductivityDate != null)
                        {
                            //if (pttProd.ProductivityDate.Length > 0)
                            //{
                            //    paProdDate.Value = pttProd.ProductivityDate;
                            //}
                            //else
                            //{
                            //    paProdDate.Value = new string[1] { "" };
                            //    paProdDate.Size = 0;
                            //}
                        }
                        else
                        {
                            paProdDate.Value = new string[1] { "" };
                            paProdDate.Size = 0;
                        }
                        oraCmd.Parameters.Add(paProdDate);              

                        OracleParameter paProductivity = new OracleParameter();
                        paProductivity.ParameterName = "PINA_PRODUCTIVITY";
                        paProductivity.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
                        paProductivity.OracleDbType = OracleDbType.Double;
                        if (pttProd.ProductivityVals != null)
                        {
                            if (pttProd.ProductivityVals.Length > 0)
                            {
                                paProductivity.Value = pttProd.ProductivityVals;
                            }
                            else
                            {
                                paProductivity.Value = new string[1] { null };
                                paProductivity.Size = 0;
                            }
                        }
                        else
                        {
                            paProductivity.Value = new string[1] { null };
                            paProductivity.Size = 0;
                        }
                        oraCmd.Parameters.Add(paProductivity);

                        oraCon.Open();
                        oraCmd.ExecuteNonQuery();

                        oraCon.Close();
                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }            
            return blStatus;
        }
    }
}
