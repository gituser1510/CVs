﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using iTextSharp.text.pdf;
using iTextSharp.text;
using System.IO;
using IndxReactNarr.Common;
using System.Data;
using iTextSharp.text.html.simpleparser;
using IndxReactNarr.Generic;

namespace IndxReactNarr.PdfExport
{
   public class NumsExportToPdf
    {
        #region Pdf Color settings

        BaseColor bgcolNUMInfo = new BaseColor(204, 255, 204);

        BaseColor bgDetails = new BaseColor(255, 239, 213);

        private iTextSharp.text.Font fontTinyItalic = FontFactory.GetFont("Arial", 7, iTextSharp.text.Font.NORMAL);

        #endregion
       
        #region Public Properties
        public DataTable TanNUMsData { get; set; }
        public DataTable TANDetails { get; set; }
        public string PdfFilePath { get; set; } 
        #endregion

        StyleSheet styles;
       
        public bool ExportTanNUMsToPDF()
        {
            bool blStatus = false;
            Document objPdf = null;
            PdfPTable PdfDetails = null;
            PdfPCell pcName = null;
            PdfPCell pcPeptide_Seq = null;
            PdfPCell pcNeuclicAcid_seq = null;
            PdfPCell pcOtherNames = null;
            PdfPCell pcStruture = null;
            PdfPCell pcAbsStereo = null;

            try
            {
                if (TanNUMsData != null)
                {
                    objPdf = new Document();
                    PdfWriter writer = PdfWriter.GetInstance(objPdf, new FileStream(PdfFilePath, FileMode.Create));

                    writer.SetFullCompression();
                    writer.StrictImageSequence = true;
                    writer.SetLinearPageMode();

                    objPdf.Open();

                    //iTextSharp.text.Image chemimg = null;
                    //iTextSharp.text.Font georgia = FontFactory.GetFont("georgia", 10f);

                    //Define font style
                    #region MyRegion
                    styles = new StyleSheet();
                    styles.LoadTagStyle("th", "size", "8px");
                    styles.LoadTagStyle("th", "face", "helvetica");
                    styles.LoadTagStyle("span", "size", "7px");
                    styles.LoadTagStyle("span", "face", "helvetica");
                    styles.LoadTagStyle("td", "size", "7px");
                    styles.LoadTagStyle("td", "face", "helvetica");
                    #endregion

                    PdfPTable ptHeader = GetPdfHeaderTable();
                    objPdf.Add(ptHeader);


                    if (TanNUMsData.Rows.Count > 0)
                    {
                        PdfDetails = new PdfPTable(1);
                        PdfDetails.WidthPercentage = 100;
                        PdfDetails.SpacingAfter = 8f;

                        for (int i = 0; i < TanNUMsData.Rows.Count; i++)
                        {
                            PdfDetails.Rows.Clear();

                            pcName = new PdfPCell(new Phrase("Name : " + TanNUMsData.Rows[i]["IUPAC_NAME"].ToString().Trim(), fontTinyItalic));
                            pcPeptide_Seq = new PdfPCell(new Phrase("Peptide Sequence : " + TanNUMsData.Rows[i]["PEPTIDE_SEQ"].ToString().Trim(), fontTinyItalic));
                            pcNeuclicAcid_seq = new PdfPCell(new Phrase("Neuclic Acid Sequence : " + TanNUMsData.Rows[i]["NUCLIC_ACID_SEQ"].ToString().Trim(), fontTinyItalic));
                            pcOtherNames = new PdfPCell(new Phrase("Other Names : " + TanNUMsData.Rows[i]["OTHER_NAMES"].ToString().Trim().Replace("\r\n", ", "), fontTinyItalic));

                            pcAbsStereo = new PdfPCell(new Phrase("Absolute Stereo : " + TanNUMsData.Rows[i]["ABSOLUTE_STEREO"].ToString().Trim().Replace("\r\n", ", "), fontTinyItalic));

                            pcName.BackgroundColor = bgDetails;
                            pcPeptide_Seq.BackgroundColor = bgDetails;
                            pcNeuclicAcid_seq.BackgroundColor = bgDetails;
                            pcOtherNames.BackgroundColor = bgDetails;
                            pcAbsStereo.BackgroundColor = bgDetails;

                            PdfDetails.AddCell(BindNUMsinfoToPdf(i));
                            PdfDetails.AddCell(pcName);
                            PdfDetails.AddCell(pcAbsStereo);
                            PdfDetails.AddCell(pcPeptide_Seq);
                            PdfDetails.AddCell(pcNeuclicAcid_seq);
                            PdfDetails.AddCell(pcOtherNames);

                            //string[] MolHexCodes = new string[] { TanNUMsData.Rows[i]["MOL_HEX_CODE"].ToString().Trim() };
                            string[] MolHexCodes = TanNUMsData.Rows[i]["MOL_HEX_CODE"].ToString().Trim().Split(new string[] { "<CSIM>" }, StringSplitOptions.RemoveEmptyEntries);

                            if (MolHexCodes.Any())
                            {
                                for (int j = 0; j < MolHexCodes.Length; j++)
                                {
                                    if (MolHexCodes[j] != null && !string.IsNullOrEmpty(MolHexCodes[j].ToString().Trim()))
                                    {
                                        try
                                        {
                                            iTextSharp.text.Image chemimg = HexCodeToStructureImage.GetITextImageOnHexCode(MolHexCodes[j].Trim(), TanNUMsData.Rows[i]["REG_NO"].ToString());

                                            if (chemimg != null)
                                            {
                                                chemimg.ScaleToFit(100f, 100f);
                                                //chemimg.Alignment =iTextSharp.text.Image.ALIGN_CENTER;
                                                pcStruture = new PdfPCell(chemimg, true);
                                            }
                                            else
                                            {
                                                pcStruture = new PdfPCell(new Phrase("Structure generation error", fontTinyItalic));
                                            }

                                            pcStruture = new PdfPCell(chemimg);
                                            pcStruture.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                                            PdfDetails.AddCell(pcStruture);
                                        }
                                        catch
                                        {
                                            objPdf.Add(new Chunk("Structure Error", FontFactory.GetFont("Arial", 10, 3, iTextSharp.text.BaseColor.RED)));
                                        }
                                    }
                                }
                            }
                            objPdf.Add(PdfDetails);
                        }
                    }

                    #region commented

                    //for (int i = 0; i < dtNUMs.Rows.Count; i++)
                    //{
                    //    //strRxnHdr = "Reaction - " + (i + 1).ToString() + "      Num - " + dtReactions.Rows[i]["RXN_NUM"].ToString() + " Seq " + dtReactions.Rows[i]["RXN_SEQ"].ToString();
                    //    //rxnCell = new PdfPCell(new Phrase(strRxnHdr, fontTinyItalic));
                    //    //rxnCell.Colspan = intProdCnt + intReactCnt;
                    //    //rxnCell.HorizontalAlignment = PdfPCell.ALIGN_LEFT;// 0; //0=Left, 1=Centre, 2=Right
                    //    //rxnCell.VerticalAlignment = PdfPCell.ALIGN_TOP;
                    //    //rxnCell.BackgroundColor = bgcolRxnNo;
                    //    //PdfTable.AddCell(rxnCell);

                    //    //pcPartpnt.Colspan = intProdCnt + intReactCnt;
                    //    ////pcPartpnt.BackgroundColor =  bgcolRxnPartpnt;
                    //    //pcPartpnt.VerticalAlignment = Element.ALIGN_TOP;
                    //    //pcPartpnt.HorizontalAlignment = 0;// Element.ALIGN_LEFT; //0=Left, 1=Centre, 2=Right                                   
                    //    //PdfTable.AddCell(pcPartpnt);

                    //    //Add Pdf Table to Pdf Document
                    //    objPdf.Add(PdfTable);
                    //} 
                    #endregion

                    #region commented
                    //strRSN_CVT_Rxn = "";
                    //strRSN_FT_Rxn = "";
                    //strRSN_FT_Stage = "";

                    //intRxnID = Convert.ToInt32(dtReactions.Rows[i]["RXN_ID"].ToString().Trim());

                    ////Get Products & Reactants on Reaction ID
                    //dtProdTbl = GetProductDataOnReactionID(intRxnID);
                    //dtReactantTbl = GetReactantsDataOnReactionID(intRxnID);

                    ////Get Products & Reactants for Reaction formation on Reaction ID
                    //dtProdTbl = GetProductsForProdFormation(dtProdTbl, intRxnID, "PRODUCT");
                    //dtReactantTbl = GetProductsForProdFormation(dtReactantTbl, intRxnID, "REACTANT"); //GetReactantsForProdFormation(dtReactantTbl);

                    //intReactCnt = dtReactantTbl != null ? dtReactantTbl.Rows.Count : 0;
                    //intProdCnt = dtProdTbl != null ? dtProdTbl.Rows.Count : 0; 
                    #endregion

                    objPdf.Close();
                    blStatus = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        //Bind NUMS to PDF
        private PdfPTable BindNUMsinfoToPdf(int index)
        {
            PdfPTable ptNUMS = null;
            PdfPCell pcNUM = null;
            PdfPCell pcReg_NO = null;
            PdfPCell pcFormula = null;

            try
            {
                ptNUMS = new PdfPTable(3);
                ptNUMS.WidthPercentage = 100;
                ptNUMS.SpacingAfter = 8f;


                pcNUM = new PdfPCell(new Phrase("NUM : " + TanNUMsData.Rows[index]["NUM"].ToString().Trim(), fontTinyItalic));
                pcReg_NO = new PdfPCell(new Phrase("Registry No : " + TanNUMsData.Rows[index]["REG_NO"].ToString().Trim(), fontTinyItalic));
                pcFormula = new PdfPCell(new Phrase("Formula : " + TanNUMsData.Rows[index]["FORMULA"].ToString().Trim(), fontTinyItalic));

                pcNUM.BackgroundColor = bgcolNUMInfo;
                pcReg_NO.BackgroundColor = bgcolNUMInfo;
                pcFormula.BackgroundColor = bgcolNUMInfo;

                ptNUMS.AddCell(pcNUM);
                ptNUMS.AddCell(pcReg_NO);
                ptNUMS.AddCell(pcFormula);

                return ptNUMS;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return ptNUMS;
        }

        //Get PDF Header table
        private PdfPTable GetPdfHeaderTable()
        {
            PdfPTable ptHdr = null;
            PdfPCell pcInfo = null;
            PdfPCell pcTAN = null;
            PdfPCell pcCAN = null;
            PdfPCell pcBatch = null;

            try
            {
                ptHdr = new PdfPTable(3);
                ptHdr.WidthPercentage = 100;
                ptHdr.SpacingAfter = 8f;

                pcInfo = new PdfPCell(new Phrase("GVKBio Sciences Pvt. Ltd Internal document", fontTinyItalic));
                pcInfo.Colspan = 3;
                pcInfo.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                pcInfo.BackgroundColor = bgcolNUMInfo;// new BaseColor(255, 160, 122);
                ptHdr.AddCell(pcInfo);

                #region Code commented
                ////Add GVKBio Logo
                //System.Drawing.Image oImage = System.Drawing.Image.FromFile(Application.StartupPath.ToString() + "\\gvkbio-logo.png");
                ////Bitmap imge = new Bitmap();
                //iTextSharp.text.Image imgLogo = iTextSharp.text.Image.GetInstance(oImage, System.Drawing.Imaging.ImageFormat.Jpeg);
                //imgLogo.ScaleToFit(107f, 28f);
                //imgLogo.ScaleAbsolute((float)107f, (float)28f);
                ////imgLogo.Alignment = iTextSharp.text.Image.TEXTWRAP | iTextSharp.text.Image.ALIGN_CENTER;
                //PdfPCell pcLogo = new PdfPCell(imgLogo);
                //pcLogo.Colspan = 1;                   
                //pcLogo.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                //pcLogo.BackgroundColor = bgcolTANInfo;// new BaseColor(255, 160, 122);
                //ptHdr.AddCell(pcLogo); 
                #endregion

                pcTAN = new PdfPCell(new Phrase("TAN - " + TANDetails.Rows[0]["TAN_NAME"].ToString().Trim(), fontTinyItalic));
                pcCAN = new PdfPCell(new Phrase("CAN - " + TANDetails.Rows[0]["CAN"].ToString().Trim(), fontTinyItalic));
                pcBatch = new PdfPCell(new Phrase("Batch - " + TANDetails.Rows[0]["BATCH_NO"].ToString().Trim(), fontTinyItalic));

                pcTAN.BackgroundColor = bgDetails;
                pcCAN.BackgroundColor = bgDetails;
                pcBatch.BackgroundColor = bgDetails;

                #region MyRegion
                //pcTAN.Border = PdfPCell.NO_BORDER;
                //pcCAN.Border = PdfPCell.NO_BORDER;
                //pcDOI.Border = PdfPCell.NO_BORDER;
                //pcBatch.Border = PdfPCell.NO_BORDER; 
                #endregion

                ptHdr.AddCell(pcTAN);
                ptHdr.AddCell(pcCAN);
                ptHdr.AddCell(pcBatch);               
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return ptHdr;
        }
    }
}

