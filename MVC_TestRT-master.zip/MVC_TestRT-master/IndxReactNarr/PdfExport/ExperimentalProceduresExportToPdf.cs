﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using iTextSharp.text.pdf;
using System.Data;
using iTextSharp.text;
using IndxReactNarr.Generic;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.html;
using System.IO;

namespace IndxReactNarr.PdfExport
{
    public class ExperimentalProceduresExportToPdf
    {
        #region Pdf Color settings

        BaseColor bgcolTANInfo = new BaseColor(204, 255, 204);
        BaseColor bgcolCAN = new BaseColor(204, 255, 204);
        BaseColor bgcolDOI = new BaseColor(204, 255, 204);
        BaseColor bgcolRxnNo = new BaseColor(255, 239, 213);
        //BaseColor bgcolNumSeq = new BaseColor(209, 238, 238);//(255, 215, 0);
        //BaseColor bgcolNarId = new BaseColor(209, 238, 238);//(255, 215, 0);
        //BaseColor bgcolDocRef = new BaseColor(238, 245, 238);
        //BaseColor bgcolFileName = new BaseColor(255, 204, 153);//(255, 215, 0);
        //BaseColor bgcolPageNum = new BaseColor(255, 239, 213);
        //BaseColor bgcolPageLabel = new BaseColor(255, 239, 213);
        //BaseColor bgcolX = new BaseColor(245, 255, 250);
        //BaseColor bgcolXPageSize = new BaseColor(245, 255, 250);
        //BaseColor bgcolXOffSet = new BaseColor(245, 255, 250);
        //BaseColor bgcolY = new BaseColor(245, 255, 250);
        //BaseColor bgcolYPageSize = new BaseColor(245, 255, 250);
        //BaseColor bgcolYOffSet = new BaseColor(245, 255, 250);
        BaseColor bgcolTextLine = new BaseColor(245, 255, 250);
        BaseColor bgcolPara1 = new BaseColor(245, 255, 250);
        BaseColor bgcolPara2 = new BaseColor(245, 255, 250);
        BaseColor bgcolData = new BaseColor(245, 255, 250);
        
        private iTextSharp.text.Font fontTinyItalic = FontFactory.GetFont("Arial", 7, iTextSharp.text.Font.NORMAL);
        private iTextSharp.text.Font fontItalic = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.COURIER, 14, iTextSharp.text.Font.BOLD);
        iTextSharp.text.Font georgia = FontFactory.GetFont("georgia", 10f);
        
        #endregion

        #region Public variables

        BaseFont baseFont;
        iTextSharp.text.Font font;
        StyleSheet styles1;
        iTextSharp.text.pdf.PdfWriter objPdfWriter;
        iTextSharp.text.Document doc;

        PdfPTable ptHdr = null;
        PdfPCell pcInfo = null;
        PdfPCell pcGVKInfo = null;
        PdfPCell pcTAN = null;
        PdfPCell pcCAN = null;
        PdfPCell pcDOI = null;

        PdfPCell pcTextLine;       
        PdfPCell pcPara;       
        PdfPCell pcData;
        PdfPCell pcYieldText;
        PdfPCell pcProcedureText;

        List<IElement> lstPartpnt = null;

        DataTable TANFindings = null;

        #endregion

        //Export TAN data to pdf
        public bool ExportTANData(DataTable tanDetails, DataTable tanReactions,DataTable tanFindings, string outfileName)
        {
            bool blStatus = true;
            try
            {
                if (tanDetails != null && tanReactions != null && !string.IsNullOrEmpty(outfileName))
                {
                    if (tanDetails.Rows.Count > 0)
                    {
                        using (doc = new iTextSharp.text.Document())
                        {
                            TANFindings = tanFindings;
                            
                            //Define Font & Style settings
                            #region Font & Stype settings

                            styles1 = new StyleSheet();

                            styles1.LoadTagStyle("body", "face", "times-roman");
                            styles1.LoadTagStyle("body", "size", "8pt");
                            styles1.LoadTagStyle("body", HtmlTags.ENCODING, BaseFont.IDENTITY_H);

                            //styles1.LoadTagStyle("sub", "face", "arial");
                            styles1.LoadTagStyle("sub", "size", "5pt");
                            styles1.LoadTagStyle("sup", "size", "5pt");

                            //styles1.LoadTagStyle("b", "size", "10pt");
                            styles1.LoadTagStyle("b", "face", "arial");
                            //styles1.LoadTagStyle("b", HtmlTags.FONTSTYLE, "bold");
                            //styles1.LoadTagStyle("b", "color", "red");
                            //styles1.LoadTagStyle("b", HtmlTags.ENCODING, BaseFont.IDENTITY_H);

                            //styles1.LoadTagStyle("i", "size", "10pt");
                            styles1.LoadTagStyle("i", "face", "arial");
                            styles1.LoadTagStyle("i", HtmlTags.FONTSTYLE, "i");
                            //styles1.LoadTagStyle("i", HtmlTags.ENCODING, BaseFont.IDENTITY_H);
                            //styles1.LoadTagStyle("italic", "font-weight", "italic");

                            baseFont = BaseFont.CreateFont("C:\\Windows\\Fonts\\ARIALUNI.TTF", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
                            font = new iTextSharp.text.Font(baseFont, iTextSharp.text.Font.DEFAULTSIZE, iTextSharp.text.Font.NORMAL);

                            #endregion

                            // Creating new pdf document.
                            objPdfWriter = iTextSharp.text.pdf.PdfWriter.GetInstance(doc, new FileStream(outfileName, FileMode.Create));
                            doc.Open();
                            doc.AddTitle(tanDetails.Rows[0]["TAN_NAME"].ToString().Trim());

                            // Binding Header data of tan,can,doi.
                            string strTan = tanDetails.Rows[0]["TAN_NAME"].ToString().Trim();
                            string strCAN = tanDetails.Rows[0]["CAN"] != null ? tanDetails.Rows[0]["CAN"].ToString().Trim() : "";
                            string strDOI = tanDetails.Rows[0]["DOI"] != null ? tanDetails.Rows[0]["DOI"].ToString().Trim() : "";

                            PdfPTable ptReactions = null;

                            #region MyRegion
                            ////Define font style
                            //styles = new StyleSheet();
                            //////styles.LoadTagStyle("th", "size", "8px");
                            //////styles.LoadTagStyle("th", "face", "helvetica");
                            //////styles.LoadTagStyle("span", "size", "7px");
                            //////styles.LoadTagStyle("span", "face", "helvetica");
                            ////styles.LoadTagStyle("td", "size", "7px");
                            ////styles.LoadTagStyle("td", "face", "helvetica");

                            ////styles.LoadTagStyle(HtmlTags.TABLE, HtmlTags.SIZE, "17px");
                            ////styles.LoadTagStyle(HtmlTags.BOLD, HtmlTags.SIZE, "18px");
                            ////styles.LoadTagStyle(HtmlTags.ITALIC, HtmlTags.FONT, "helvetica");
                            ////HtmlTags.ITALIC, HtmlTags.FONT, );

                            //styleData = new StyleSheet();
                            ////styleData.LoadTagStyle(HtmlTags.P, HtmlTags.COLOR, "#ff0000");
                            ////styleData.LoadTagStyle(HtmlTags.UL, HtmlTags.INDENT, "10");
                            ////styleData.LoadTagStyle(HtmlTags.LI, HtmlTags.LEADING, "16"); 
                            #endregion

                            //Add Pdf Header to document
                            PdfPTable ptHeader = GetPdfHeaderTable(strTan, strCAN, strDOI);
                            doc.Add(ptHeader);

                            DataRow drReaction;
                            PdfPTable ptRxnHdr;
                            PdfPTable ptReaction;

                            if (tanReactions != null && tanReactions.Rows.Count > 0)
                            {
                                for (int i = 0; i < tanReactions.Rows.Count; i++)
                                {
                                    // Creating table with columns.
                                    ptReactions = new PdfPTable(1);

                                    //Create instance of the pdf table and set the number of column in that table
                                    ptReactions.SpacingAfter = 4f;
                                    ptReactions.HorizontalAlignment = 0;//0=Left, 1=Centre, 2=Right                                
                                    ptReactions.TotalWidth = 800f;// doc.PageSize.Width;
                                    ptReactions.KeepTogether = true;
                                    ptReactions.WidthPercentage = 100;

                                    drReaction = tanReactions.Rows[i];

                                    //Reaction Id,nar id, seq id,...etc.
                                    ptRxnHdr = GetReactionHeaderTable(strTan, drReaction);
                                    ptReactions.AddCell(ptRxnHdr);
                                    //doc.Add(ptReactioHeader);

                                    //TextLine, Para1, Para2, Data                                        
                                    ptReaction = GetReactionTable(strTan, drReaction);
                                    ptReactions.AddCell(ptReaction);

                                    //Add Pdf Table to Pdf Document
                                    doc.Add(ptReactions);
                                }
                            }
                            //Close Pdf Document
                            doc.Close();
                            blStatus = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        //Get PDF Header table
        private PdfPTable GetPdfHeaderTable(string tan, string can, string doi)
        {
            try
            {
                ptHdr = new PdfPTable(3);
                ptHdr.WidthPercentage = 100;
                ptHdr.SpacingAfter = 8f;

                pcGVKInfo = new PdfPCell(new Phrase("GVKBio Sciences Pvt. Ltd internal document", fontTinyItalic));
                pcGVKInfo.Colspan = 3;
                pcGVKInfo.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                pcGVKInfo.BackgroundColor = bgcolTANInfo;// new BaseColor(255, 160, 122);              
                ptHdr.AddCell(pcGVKInfo);

                pcInfo = new PdfPCell(new Phrase(tan + " - Experimental Procedures", fontTinyItalic));
                pcInfo.Colspan = 3;
                pcInfo.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                pcInfo.BackgroundColor = bgcolTANInfo;// new BaseColor(255, 160, 122);
                ptHdr.AddCell(pcInfo);

                pcTAN = new PdfPCell(new Phrase("TAN - " + tan, fontTinyItalic));
                pcCAN = new PdfPCell(new Phrase("CAN - " + can, fontTinyItalic));
                pcDOI = new PdfPCell(new Phrase("DOI - " + doi, fontTinyItalic));
                //pcBatch = new PdfPCell(new Phrase("Batch - " + BatchName, fontTinyItalic));

                pcTAN.BackgroundColor = bgcolTANInfo;
                pcCAN.BackgroundColor = bgcolCAN;
                pcDOI.BackgroundColor = bgcolDOI;
                // pcBatch.BackgroundColor = bgcolRxnNo;

                //pcTAN.Border = PdfPCell.NO_BORDER;
                //pcCAN.Border = PdfPCell.NO_BORDER;
                //pcDOI.Border = PdfPCell.NO_BORDER;
                //pcBatch.Border = PdfPCell.NO_BORDER;

                ptHdr.AddCell(pcTAN);
                ptHdr.AddCell(pcCAN);
                ptHdr.AddCell(pcDOI);
                // ptHdr.AddCell(pcBatch);
                
                return ptHdr;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return ptHdr;
        }

        //Get Reaction Header table
        private PdfPTable GetReactionHeaderTable(string tanId, DataRow rxnRowData)
        {
            PdfPTable ptRxnHdr = null;
            try
            {
                if (rxnRowData != null)
                {
                    //Create Nested Table for Reaction header - Reaction.No, Num-Seq.No and Page info                                                                    
                    ptRxnHdr = new PdfPTable(5);

                    PdfPCell pcRxnNo = null;
                    PdfPCell pcNumSeq = null;
                    PdfPCell pcDocRef = null;
                    PdfPCell pcNarId = null;
                    PdfPCell pcFileName = null;
                    PdfPCell pcPageNum = null;
                    PdfPCell pcPageLabel = null;
                    PdfPCell pcX = null;
                    PdfPCell pcXPageSize = null;
                    PdfPCell pcXOffSet = null;
                    PdfPCell pcY = null;
                    PdfPCell pcYPageSize = null;
                    PdfPCell pcYOffSet = null;
                    PdfPCell pcIsGeneralTypical = null;
                    PdfPCell pcNoExpDetails = null;

                    ptRxnHdr.WidthPercentage = 100;
                    //ptRxnHdr.SpacingAfter = 8f;

                    pcRxnNo = new PdfPCell(new Phrase("Reaction - " + rxnRowData["RXN_NUM"].ToString(), fontTinyItalic));
                    pcNumSeq = new PdfPCell(new Phrase("Seq - " + rxnRowData["RXN_SEQ"].ToString(), fontTinyItalic));
                    pcNarId = new PdfPCell(new Phrase(rxnRowData["RXN_NAR_ID"].ToString(), fontTinyItalic));

                    pcDocRef = new PdfPCell(new Phrase("DocRef - " + rxnRowData["DOC_REF"].ToString(), fontTinyItalic));
                    pcFileName = new PdfPCell(new Phrase(rxnRowData["FILE_NAME"].ToString(), fontTinyItalic));
                    pcXPageSize = new PdfPCell(new Phrase("X Page size - " + rxnRowData["PAGE_SIZE_X"].ToString(), fontTinyItalic));
                    pcYPageSize = new PdfPCell(new Phrase("Y Page size - " + rxnRowData["PAGE_SIZE_Y"].ToString(), fontTinyItalic));

                    pcPageNum = new PdfPCell(new Phrase("Page Number - " + rxnRowData["PAGE_NO"].ToString(), fontTinyItalic));
                    pcPageLabel = new PdfPCell(new Phrase("Page Label - " + rxnRowData["PAGE_LABEL"].ToString(), fontTinyItalic));
                    pcX = new PdfPCell(new Phrase("X ResUnit - ", fontTinyItalic));

                    pcXOffSet = new PdfPCell(new Phrase("X Offset - " + rxnRowData["OFFSET_X"].ToString(), fontTinyItalic));
                    pcIsGeneralTypical = new PdfPCell(new Phrase("GeneralTypical - " + rxnRowData["IS_GENERAL_TYPICAL"].ToString(), fontTinyItalic));
                    pcNoExpDetails = new PdfPCell(new Phrase("No Exp.Details - " + rxnRowData["NO_EXP_DETAILS"].ToString(), fontTinyItalic));
                    pcY = new PdfPCell(new Phrase("Y ResUnit - ", fontTinyItalic));

                    pcYOffSet = new PdfPCell(new Phrase("Y Offset - " + rxnRowData["OFFSET_Y"].ToString(), fontTinyItalic));

                    pcRxnNo.BackgroundColor = bgcolRxnNo;
                    pcNumSeq.BackgroundColor = bgcolRxnNo; // bgcolNumSeq;
                    pcNarId.BackgroundColor = bgcolRxnNo; // bgcolNarId;
                    pcDocRef.BackgroundColor = bgcolRxnNo; // bgcolDocRef;
                    pcFileName.BackgroundColor = bgcolRxnNo; // bgcolFileName;
                    pcPageNum.BackgroundColor = bgcolRxnNo; // bgcolPageNum;
                    pcPageLabel.BackgroundColor = bgcolRxnNo; // bgcolPageLabel;
                    pcX.BackgroundColor = bgcolRxnNo; // bgcolX;
                    pcXPageSize.BackgroundColor = bgcolRxnNo; // bgcolXPageSize;
                    pcXOffSet.BackgroundColor = bgcolRxnNo; // bgcolXOffSet;
                    pcY.BackgroundColor = bgcolRxnNo; // bgcolY;
                    pcYPageSize.BackgroundColor = bgcolRxnNo; // bgcolYPageSize;
                    pcYOffSet.BackgroundColor = bgcolRxnNo; // bgcolYOffSet;
                    pcIsGeneralTypical.BackgroundColor = bgcolRxnNo;
                    pcNoExpDetails.BackgroundColor = bgcolRxnNo;

                    #region MyRegion
                    //pcRxnNo.Border = PdfPCell.NO_BORDER;
                    //pcNumSeq.Border = PdfPCell.NO_BORDER;
                    //pcNarId.Border = PdfPCell.NO_BORDER;
                    //pcDocRef.Border = PdfPCell.NO_BORDER;
                    //pcFileName.Border = PdfPCell.NO_BORDER;
                    //pcPageNum.Border = PdfPCell.NO_BORDER;
                    //pcPageLabel.Border = PdfPCell.NO_BORDER;
                    //pcX.Border = PdfPCell.NO_BORDER;
                    //pcXPageSize.Border = PdfPCell.NO_BORDER;
                    //pcXOffSet.Border = PdfPCell.NO_BORDER;
                    //pcY.Border = PdfPCell.NO_BORDER;
                    //pcYPageSize.Border = PdfPCell.NO_BORDER;
                    //pcYOffSet.Border = PdfPCell.NO_BORDER;
                    //pcIsGeneralTypical.Border = PdfPCell.NO_BORDER;
                    //pcNoExpDetails.Border = PdfPCell.NO_BORDER;

                    //pcRxnNo.Padding = 5f;
                    //pcNumSeq.Padding = 5f;
                    //pcDocRef.Padding = 5f;
                    //pcFileName.Padding = 5f;
                    //pcPageNum.Padding = 5f;
                    //pcPageLabel.Padding = 5f;
                    //pcX.Padding = 5f;
                    //pcXPageSize.Padding = 5f;
                    //pcXOffSet.Padding = 5f;
                    //pcY.Padding = 5f;
                    //pcYPageSize.Padding = 5f;
                    //pcYOffSet.Padding = 5f;
                    //pcIsGeneralTypical.Padding = 5f;
                    //pcNoExpDetails.Padding = 5f; 
                    #endregion

                    ptRxnHdr.AddCell(pcRxnNo);
                    ptRxnHdr.AddCell(pcNumSeq);
                    ptRxnHdr.AddCell(pcNarId);
                    ptRxnHdr.AddCell(pcDocRef);
                    ptRxnHdr.AddCell(pcFileName);
                    ptRxnHdr.AddCell(pcPageNum);
                    ptRxnHdr.AddCell(pcPageLabel);
                    ptRxnHdr.AddCell(pcX);
                    ptRxnHdr.AddCell(pcXPageSize);
                    ptRxnHdr.AddCell(pcXOffSet);
                    ptRxnHdr.AddCell(pcIsGeneralTypical);
                    ptRxnHdr.AddCell(pcNoExpDetails);
                    ptRxnHdr.AddCell(pcY);
                    ptRxnHdr.AddCell(pcYPageSize);
                    ptRxnHdr.AddCell(pcYOffSet);

                    return ptRxnHdr;
                }               
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return ptRxnHdr;
        }

        //Get Reaction Data Table  
        private PdfPTable GetReactionTable(string strTanId, DataRow _rxnRowData)
        {
            PdfPTable ptRxnData = new PdfPTable(1);
            try
            {
                if (_rxnRowData != null)
                {
                    //BaseFont bfHeaderColor = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, true);
                    //iTextSharp.text.Font FontHeader = new iTextSharp.text.Font(bfHeaderColor, 9, iTextSharp.text.Font.NORMAL, iTextSharp.text.BaseColor.BLACK);
                    iTextSharp.text.Font FontHeader = FontFactory.GetFont("arial", 8f);

                    ptRxnData.WidthPercentage = 100;

                    pcTextLine = GetHtmlContentCell(_rxnRowData["TEXT_LINE"].ToString());
                    pcYieldText = GetHtmlContentCell(_rxnRowData["YIELD_TEXT"].ToString());
                    pcPara = GetHtmlContentCell(_rxnRowData["PARA_TEXT"].ToString());
                    pcData = GetHtmlContentCell(_rxnRowData["DATA_TEXT"].ToString());
                    pcProcedureText = GetHtmlContentCell(_rxnRowData["PROCEDURE_TEXT"].ToString());

                    pcTextLine.Padding = 3f;
                    pcYieldText.Padding = 3f;
                    pcPara.Padding = 3f;
                    pcData.Padding = 3f;
                    pcProcedureText.Padding = 3f;

                    pcTextLine.BackgroundColor = bgcolTextLine;
                    pcYieldText.BackgroundColor = bgcolTextLine;
                    pcPara.BackgroundColor = bgcolPara1;
                    pcData.BackgroundColor = bgcolData;
                    pcProcedureText.BackgroundColor = bgcolData;

                    ptRxnData.AddCell(new Phrase("TextLine", FontHeader));
                    ptRxnData.AddCell(pcTextLine);

                    ptRxnData.AddCell(new Phrase("Yield Text", FontHeader));
                    ptRxnData.AddCell(pcYieldText);

                    ptRxnData.AddCell(new Phrase("Para", FontHeader));
                    ptRxnData.AddCell(pcPara);

                    ptRxnData.AddCell(new Phrase("Data", FontHeader));
                    ptRxnData.AddCell(pcData);

                    ptRxnData.AddCell(new Phrase("Procedure Text", FontHeader));
                    ptRxnData.AddCell(pcProcedureText);

                    //Add Reaction Findings
                    int rxnID = Convert.ToInt32(_rxnRowData["RXN_ID"].ToString());
                    ptRxnData.AddCell(new Phrase("Reaction Findings", FontHeader));
                    ptRxnData.AddCell(GetReactionFindingsTable(rxnID));
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return ptRxnData;
        }

        // Adding html data to PDF       
        private PdfPCell GetHtmlContentCell(string htmlData)
        {
            PdfPCell pcPartpnt = new PdfPCell();
            try
            {
                if (!string.IsNullOrEmpty(htmlData))
                {
                    //Replace Bold/Italic tags
                    string strHtml = htmlData;
                    strHtml = strHtml.Replace("<bold>", "<b>");
                    strHtml = strHtml.Replace("</bold>", "</b>");
                    strHtml = strHtml.Replace("<ital>", "<i>");
                    strHtml = strHtml.Replace("</ital>", "</i>");
                    strHtml = strHtml.Replace("\r\n", "<br>");
                    // Convert HTML tags to PDF.               
                    lstPartpnt = HTMLWorker.ParseToList(new StringReader(strHtml), styles1);
                    //pcPartpnt = new PdfPCell();

                    Paragraph prgHtml;

                    // if Data has text add to pdf.
                    if (lstPartpnt.Count != 0)
                    {
                        //Add Participants string in a row cell to Pdf Table
                        foreach (IElement iEle in lstPartpnt)
                        {
                            prgHtml = iEle as Paragraph;
                            prgHtml.Font = font;
                            pcPartpnt.AddElement(prgHtml);
                            //pcPartpnt.AddElement(iEle);                         
                        }
                    }
                    else
                    {
                        // TODO.  if data is not available in perticular cell display empty cell.
                        pcPartpnt = new PdfPCell(new Phrase(" "));
                        pcPartpnt.ExtraParagraphSpace = 5f;
                    }

                    pcPartpnt.VerticalAlignment = Element.ALIGN_TOP;
                    pcPartpnt.HorizontalAlignment = 0;
                    return pcPartpnt;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return pcPartpnt;
        }

        //Get Reaction Data Table  
        private PdfPTable GetReactionFindingsTable(int rxnID)
        {
            PdfPTable ptRxnFindings = new PdfPTable(3);
            try
            {
                if (TANFindings != null && TANFindings.Rows.Count > 0)
                {
                    ptRxnFindings.WidthPercentage = 100;
                    Font FontHeader = FontFactory.GetFont("arial", 8f);

                    DataView dvTemp = TANFindings.Copy().DefaultView;
                    dvTemp.RowFilter = "RXN_ID =" + rxnID;
                    DataTable rxnFindings = dvTemp.ToTable();
                    if (rxnFindings != null && rxnFindings.Rows.Count > 0)
                    {
                        ptRxnFindings.AddCell(new Phrase("Finding Name", FontHeader));                       
                        ptRxnFindings.AddCell(new Phrase("Ref.Substance", FontHeader));
                        ptRxnFindings.AddCell(new Phrase("Finding Value", FontHeader));

                        PdfPCell pcFindingValue = null;
                        PdfPCell pcFindingType = null;
                        PdfPCell pcRefSubst = null;

                        for (int i = 0; i < rxnFindings.Rows.Count; i++)
                        {
                            pcFindingType = GetHtmlContentCell(rxnFindings.Rows[i]["FINDING_TYPE"].ToString());
                            pcRefSubst = GetHtmlContentCell(rxnFindings.Rows[i]["REFERENCE_SUBSTANCE"].ToString());
                            pcFindingValue = GetHtmlContentCell(rxnFindings.Rows[i]["FINDING_VALUE"].ToString());
                                                       
                            pcFindingValue.BackgroundColor = bgcolTextLine;
                            pcFindingType.BackgroundColor = bgcolTextLine;
                            pcRefSubst.BackgroundColor = bgcolPara1;

                            ptRxnFindings.AddCell(pcFindingType);
                            ptRxnFindings.AddCell(pcRefSubst);                           
                            ptRxnFindings.AddCell(pcFindingValue);                            
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return ptRxnFindings;
        }
    }
}
