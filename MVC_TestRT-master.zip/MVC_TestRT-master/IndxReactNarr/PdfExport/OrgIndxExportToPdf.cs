﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using iTextSharp.text.pdf;
using System.Data;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text;
using iTextSharp.text.html;
using System.IO;
using System.Windows.Forms;
using MarkupConverter;
using IndxReactNarr.Generic;

namespace IndxReactNarr.PdfExport
{
    public class OrgIndxExportToPdf
    {
        //private IMarkupConverter markupConverter;
        //public OrgIndxExportToPdf()
        //{
        //    markupConverter = new MarkupConverter.MarkupConverter();
        //}

        #region Pdf Color settings

        BaseColor bgcolTANInfo = new BaseColor(204, 255, 204);
        BaseColor bgcolCAN = new BaseColor(204, 255, 204);
        BaseColor bgcolDOI = new BaseColor(204, 255, 204);
        BaseColor bgcolRxnNo = new BaseColor(255, 239, 213);       
        BaseColor bgcolTextLine = new BaseColor(245, 255, 250);
        BaseColor bgcolPara1 = new BaseColor(245, 255, 250);
        BaseColor bgcolPara2 = new BaseColor(245, 255, 250);
        BaseColor bgcolData = new BaseColor(245, 255, 250);


        private iTextSharp.text.Font fontTinyItalic = FontFactory.GetFont("Arial", 7, iTextSharp.text.Font.NORMAL);
        private iTextSharp.text.Font fontItalic = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.COURIER, 14, iTextSharp.text.Font.BOLD);
        iTextSharp.text.Font georgia = FontFactory.GetFont("georgia", 10f);


        #endregion

        #region Public variables

        BaseFont baseFont;
        iTextSharp.text.Font font;
        StyleSheet styles1;
        StyleSheet styles2;
        iTextSharp.text.pdf.PdfWriter objPdfWriter;
        iTextSharp.text.Document doc;

        PdfPTable ptHdr = null;
        PdfPCell pcInfo = null;
        PdfPCell pcGVKInfo = null;
        PdfPCell pcTAN = null;
        PdfPCell pcSection = null;
        PdfPCell pcSubSec = null;
        PdfPCell pcCrossRef = null;

        PdfPCell pcSpaHdr = null;
        PdfPCell pcRevTAN = null;
        PdfPCell pcQryTAN = null;

        PdfPCell pcTextLine;
        PdfPCell pcPara1;
        PdfPCell pcPara2;
        PdfPCell pcData;

        List<IElement> lstPartpnt = null;
        float rowHeight = 60f;

        #endregion

       
        RichTextBox rtb = null;

        //Export TAN data to pdf
        public bool ExportTANData(DataTable tanDetails, DataTable tanPARNums, DataTable tanCTHNums,string outfileName)
        {
            bool blStatus = true;
            try
            {
                if (tanDetails != null && tanPARNums != null && !string.IsNullOrEmpty(outfileName))
                {
                    if (tanDetails.Rows.Count > 0)
                    {
                        using (doc = new iTextSharp.text.Document())
                        {
                            //Define Font & Style settings
                            #region Font & Stype settings

                            styles1 = new StyleSheet();

                            styles1.LoadTagStyle("body", "face", "times-roman");
                            styles1.LoadTagStyle("body", "size", "8pt");
                            styles1.LoadTagStyle("body", HtmlTags.ENCODING, BaseFont.IDENTITY_H);

                            //styles1.LoadTagStyle("sub", "face", "arial");
                            styles1.LoadTagStyle("sub", "size", "5pt");
                            styles1.LoadTagStyle("sup", "size", "5pt");

                            //styles1.LoadTagStyle("b", "size", "10pt");
                            styles1.LoadTagStyle("b", "face", "arial");                            

                            //styles1.LoadTagStyle("i", "size", "10pt");
                            styles1.LoadTagStyle("i", "face", "arial");
                            styles1.LoadTagStyle("i", HtmlTags.FONTSTYLE, "i");
                            //styles1.LoadTagStyle("i", HtmlTags.ENCODING, BaseFont.IDENTITY_H);
                            //styles1.LoadTagStyle("italic", "font-weight", "italic");

                            baseFont = BaseFont.CreateFont("C:\\Windows\\Fonts\\ARIALUNI.TTF", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
                            font = new iTextSharp.text.Font(baseFont, iTextSharp.text.Font.DEFAULTSIZE, iTextSharp.text.Font.NORMAL);

                            styles2 = new StyleSheet();
                            styles2.LoadTagStyle("th", "size", "8px");
                            styles2.LoadTagStyle("th", "face", "helvetica");
                            styles2.LoadTagStyle("span", "size", "7px");
                            styles2.LoadTagStyle("span", "face", "helvetica");
                            styles2.LoadTagStyle("td", "size", "7px");
                            styles2.LoadTagStyle("td", "face", "helvetica");
                            styles2.LoadTagStyle("br", "face", "helvetica");
                            styles2.LoadTagStyle("br", HtmlTags.BR, "7px");

                            #endregion

                            // Creating new pdf document.
                            objPdfWriter = iTextSharp.text.pdf.PdfWriter.GetInstance(doc, new FileStream(outfileName, FileMode.Create));
                            doc.Open();
                            doc.AddTitle(tanDetails.Rows[0]["TAN_NAME"].ToString().Trim());
                                                                                                         
                            //Add Pdf Header to document
                            PdfPTable ptHeader = GetPdfHeaderTable(tanDetails.Rows[0]);
                            doc.Add(ptHeader);

                            //Add Article Info to document
                            PdfPTable ptArticleInfo = GetArticleInfoHeaderTable(tanDetails.Rows[0], tanCTHNums, tanPARNums);
                            doc.Add(ptArticleInfo);
                            
                            //Close Pdf Document
                            doc.Close();
                            blStatus = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        // Get PDF Header table
        private PdfPTable GetPdfHeaderTable(DataRow rowData)
        {
            try
            {
                if (rowData != null)
                {

                    ptHdr = new PdfPTable(7);
                    ptHdr.WidthPercentage = 100;
                    ptHdr.SpacingAfter = 8f;

                    string strTan = rowData["TAN_NAME"].ToString().Trim();
                    string strSection = rowData["TAN_SECTION"] != null ? rowData["TAN_SECTION"].ToString().Trim() : "";
                    string strSubSec = rowData["SUB_SECTION"] != null ? rowData["SUB_SECTION"].ToString().Trim() : "";
                    string strCrossRef = rowData["CROSS_REFERENCE"] != null ? rowData["CROSS_REFERENCE"].ToString().Trim() : "";
                    string strSPA_HDR = rowData["SPA_HDR"] != null ? rowData["SPA_HDR"].ToString().Trim() : "-";
                    string strReviewTAN = rowData["REVIEW_TAN"] != null ? rowData["REVIEW_TAN"].ToString().Trim() : "-";
                    string strQueryTAN = rowData["QUERY_TAN"] != null ? rowData["QUERY_TAN"].ToString().Trim() : "-";

                    pcGVKInfo = new PdfPCell(new Phrase("GVKBio Sciences Pvt. Ltd internal document", fontTinyItalic));
                    pcGVKInfo.Colspan = 7;
                    pcGVKInfo.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                    pcGVKInfo.BackgroundColor = bgcolTANInfo;// new BaseColor(255, 160, 122);              
                    ptHdr.AddCell(pcGVKInfo);

                    pcInfo = new PdfPCell(new Phrase(strTan + " - Organic Indexing", fontTinyItalic));
                    pcInfo.Colspan = 7;
                    pcInfo.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                    pcInfo.BackgroundColor = bgcolTANInfo;// new BaseColor(255, 160, 122);
                    ptHdr.AddCell(pcInfo);

                    pcTAN = new PdfPCell(new Phrase("TAN - " + strTan, fontTinyItalic));
                    pcSection = new PdfPCell(new Phrase("Section - " + strSection, fontTinyItalic));
                    pcSubSec = new PdfPCell(new Phrase("Sub.Section - " + strSubSec, fontTinyItalic));
                    pcCrossRef = new PdfPCell(new Phrase("Cross Ref.- " + strCrossRef, fontTinyItalic));

                    pcSpaHdr = new PdfPCell(new Phrase("SPA HDR - " + strSPA_HDR, fontTinyItalic));
                    pcRevTAN = new PdfPCell(new Phrase("Review TAN - " + strReviewTAN, fontTinyItalic));
                    pcQryTAN = new PdfPCell(new Phrase("Query TAN - " + strQueryTAN, fontTinyItalic));
                   
                    pcTAN.BackgroundColor = bgcolTANInfo;
                    pcSection.BackgroundColor = bgcolCAN;
                    pcSubSec.BackgroundColor = bgcolDOI;
                    pcCrossRef.BackgroundColor = bgcolDOI;
                    pcSpaHdr.BackgroundColor = bgcolDOI;
                    pcRevTAN.BackgroundColor = bgcolDOI;
                    pcQryTAN.BackgroundColor = bgcolDOI;
                    // pcBatch.BackgroundColor = bgcolRxnNo;

                    //pcTAN.Border = PdfPCell.NO_BORDER;
                    //pcCAN.Border = PdfPCell.NO_BORDER;
                    //pcDOI.Border = PdfPCell.NO_BORDER;
                    //pcBatch.Border = PdfPCell.NO_BORDER;

                    ptHdr.AddCell(pcTAN);
                    ptHdr.AddCell(pcSection);
                    ptHdr.AddCell(pcSubSec);
                    ptHdr.AddCell(pcCrossRef);

                    ptHdr.AddCell(pcSpaHdr);
                    ptHdr.AddCell(pcRevTAN);
                    ptHdr.AddCell(pcQryTAN);

                    return ptHdr;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return ptHdr;
        }

        // Adding html data to PDF       
        private PdfPCell GetHtmlContentCell(string htmlData)
        {
            PdfPCell pcPartpnt = new PdfPCell();
            try
            {
                if (!string.IsNullOrEmpty(htmlData))
                {
                    //Replace Bold/Italic tags
                    string strHtml = htmlData;
                    strHtml = strHtml.Replace("<bold>", "<b>");
                    strHtml = strHtml.Replace("</bold>", "</b>");
                    strHtml = strHtml.Replace("<ital>", "<i>");
                    strHtml = strHtml.Replace("</ital>", "</i>");
                    //strHtml = strHtml.Replace("\r\n", Chunk.NEWLINE.ToString());
                    //strHtml = strHtml.Replace("\r\n", "\n");
                    strHtml = strHtml.Replace("\r\n", "<br />");
                    #region MyRegion
                    //using (rtb = new RichTextBox())
                    //{
                    //    //Get Participatns text from RichTextBox object
                    //    rtb.Rtf = hrmlRtfConv.GetRTFfromHTMLString(strHtml);

                    //    //Get Participants elements from RichTextBox Rtf and convert to HTML
                    //    lstPartpnt = HTMLWorker.ParseToList(new StringReader(markupConverter.ConvertRtfToHtml(rtb.Rtf)), styles2);

                    //    //iTextSharp.text.html.simpleparser.HTMLWorker hw = new iTextSharp.text.html.simpleparser.HTMLWorker(doc);
                    //    //hw.Parse(new StringReader(markupConverter.ConvertRtfToHtml(objRTB.Rtf)));                                                                
                    //    // Convert HTML tags to PDF.               
                    //    //lstPartpnt = HTMLWorker.ParseToList(new StringReader(strHtml), styles1);
                    //} 
                    #endregion

                    //Convert HTML tags to PDF.               
                    lstPartpnt = HTMLWorker.ParseToList(new StringReader(strHtml), styles2);  //styles2     
                                       
                    Paragraph prgHtml;

                    // if Data has text add to pdf.
                    if (lstPartpnt.Count != 0)
                    {
                        //Add Participants string in a row cell to Pdf Table
                        foreach (IElement iEle in lstPartpnt)
                        {
                            prgHtml = iEle as Paragraph;
                            prgHtml.Font = font;                             
                            pcPartpnt.AddElement(prgHtml);                           
                        }
                    }
                    else
                    {
                        // TODO.  if data is not available in perticular cell display empty cell.
                        pcPartpnt = new PdfPCell(new Phrase(" "));
                        pcPartpnt.ExtraParagraphSpace = 5f;
                    }

                    pcPartpnt.VerticalAlignment = Element.ALIGN_TOP;
                    pcPartpnt.HorizontalAlignment = 0;                      
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return pcPartpnt;
        }

        //Get Artilce Info Header table
        private PdfPTable GetArticleInfoHeaderTable(DataRow artRowData, DataTable cthNUMs, DataTable parNUMs)
        {
            PdfPTable ptArticleInfo = null;
            try
            {
                if (artRowData != null)
                {
                    //Create Nested Table for Reaction header - Reaction.No, Num-Seq.No and Page info                                                                    
                    ptArticleInfo = new PdfPTable(1);

                    PdfPCell pcTitle = null;
                    PdfPCell pcAbstract = null;
                    PdfPCell pcTMD = null;
                    PdfPCell pcKeywords = null;

                    ptArticleInfo.WidthPercentage = 100;
                    //ptRxnHdr.SpacingAfter = 8f;
                                       
                    pcTitle = GetHtmlContentCell(artRowData["TITLE"].ToString());
                    pcAbstract = GetHtmlContentCell(artRowData["ABSTRACT"].ToString());                    
                    pcTMD = GetHtmlContentCell(artRowData["TMD"].ToString()); 
                   
                    string strKeywords = artRowData["KEYWORDS"].ToString();
                    strKeywords = strKeywords.Replace("``", "\r\n");
                    pcKeywords = new PdfPCell(new Phrase(strKeywords, fontTinyItalic));

                    pcTitle.BackgroundColor = bgcolRxnNo;
                    pcAbstract.BackgroundColor = bgcolRxnNo;
                    pcTMD.BackgroundColor = bgcolRxnNo;
                    pcTitle.PaddingBottom = 8f;
                    pcAbstract.PaddingBottom = 8f;
                    pcTMD.PaddingBottom = 8f;

                    ptArticleInfo.AddCell("Title");
                    ptArticleInfo.AddCell(pcTitle);
                    ptArticleInfo.AddCell("Abstract");
                    ptArticleInfo.AddCell(pcAbstract);
                    ptArticleInfo.AddCell("TMD");
                    ptArticleInfo.AddCell(pcTMD);
                    ptArticleInfo.AddCell("Keywords");
                    ptArticleInfo.AddCell(pcKeywords);

                    //NUM - CTH
                    if (cthNUMs != null && cthNUMs.Rows.Count > 0)
                    {
                        ptArticleInfo.AddCell("NUM-CTH");
                        PdfPCell pcCTHNums = new PdfPCell(GetCTH_NUMsTable(cthNUMs));
                        pcCTHNums.Border = PdfPCell.NO_BORDER;
                        ptArticleInfo.AddCell(pcCTHNums);
                    }

                    //NUM - PAR
                    if (parNUMs != null && parNUMs.Rows.Count > 0)
                    {
                        ptArticleInfo.AddCell("NUM-PAR");

                        PdfPCell pcPARNums = new PdfPCell(GetPAR_NUMsTable(parNUMs));
                        pcPARNums.Border = PdfPCell.NO_BORDER;
                        ptArticleInfo.AddCell(pcPARNums);
                    }                   
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString()); 
            }
            return ptArticleInfo;
        }

        /// <summary>
        /// Gets the CTH - NUMs table
        /// </summary>
        /// <param name="cthNUMs"></param>
        /// <returns></returns>
        private PdfPTable GetCTH_NUMsTable(DataTable cthNUMs)
        {
            PdfPTable ptNumInfo = null;
            try
            {
                if (cthNUMs != null)
                {
                    if (cthNUMs.Rows.Count > 0)
                    {
                        ptNumInfo = new PdfPTable(3);
                        ptNumInfo.WidthPercentage = 100;

                        foreach(DataRow dr in cthNUMs.Rows)
                        {
                            PdfPCell pcNUM = new PdfPCell(new Phrase("NUM - " + dr["NUM"].ToString(), fontTinyItalic));
                            PdfPCell pcNumType = new PdfPCell(new Phrase("Type - " + dr["CTH_TYPE"].ToString(), fontTinyItalic));
                            PdfPCell pcRole = new PdfPCell(new Phrase("Role - " + dr["NUM_ROLE"].ToString(), fontTinyItalic));

                            pcNUM.BackgroundColor = bgcolTANInfo;
                            pcNumType.BackgroundColor = bgcolTANInfo;
                            pcRole.BackgroundColor = bgcolTANInfo;

                            ptNumInfo.AddCell(pcNUM);
                            ptNumInfo.AddCell(pcNumType);
                            ptNumInfo.AddCell(pcRole);

                            //CTH
                            ptNumInfo.AddCell(new Phrase("CTH", fontTinyItalic));
                            PdfPCell pcCTH = new PdfPCell(new Phrase(dr["CTH"].ToString(), fontTinyItalic));
                            pcCTH.Colspan = 2;
                            ptNumInfo.AddCell(pcCTH);

                            //TMD
                            if (!string.IsNullOrEmpty(dr["NUM_TMD"].ToString()))
                            {
                                ptNumInfo.AddCell(new Phrase("TMD", fontTinyItalic));
                                PdfPCell pcTMD = new PdfPCell(new Phrase(dr["NUM_TMD"].ToString(), fontTinyItalic));
                                pcTMD.Colspan = 2;
                                ptNumInfo.AddCell(pcTMD);
                            }

                            //HMD
                            if (!string.IsNullOrEmpty(dr["HMD"].ToString()))
                            {
                                ptNumInfo.AddCell(new Phrase("HMD", fontTinyItalic));
                                PdfPCell pcHMD = new PdfPCell(new Phrase(dr["HMD"].ToString(), fontTinyItalic));
                                pcHMD.Colspan = 2;
                                ptNumInfo.AddCell(pcHMD);
                            }                           
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return ptNumInfo;
        }
        
        /// <summary>
        /// Gets the CTH - PARs table
        /// </summary>
        /// <param name="parNUMs"></param>
        /// <returns></returns>
        private PdfPTable GetPAR_NUMsTable(DataTable parNUMs)
        {
            PdfPTable ptPAR = null;
            try
            {
                if (parNUMs != null)
                {
                    if (parNUMs.Rows.Count > 0)
                    {
                        //Main Table
                        ptPAR = new PdfPTable(1);
                        ptPAR.WidthPercentage = 100;
                       
                        iTextSharp.text.Image chemimg = null;

                        PdfPCell pcTMD = null;
                        PdfPCell pcAMD = null;
                        PdfPCell pcHMD = null;
                        
                        foreach (DataRow dr in parNUMs.Rows)
                        {                                                      
                            //Child Table 1    
                            PdfPTable ptNumInfo = new PdfPTable(5);
                            ptNumInfo.WidthPercentage = 100;

                            PdfPCell pcNUM = new PdfPCell(new Phrase("NUM - " + dr["NUM"].ToString(), fontTinyItalic));
                            PdfPCell pcRegNo = new PdfPCell(new Phrase("Reg.No - " + dr["REG_NO"].ToString(), fontTinyItalic));
                            PdfPCell pcRole = new PdfPCell(new Phrase("Role - " + dr["NUM_ROLE"].ToString(), fontTinyItalic));
                            PdfPCell pcDPTRs = new PdfPCell(new Phrase("DPT:RS - " + dr["DPT_RS"].ToString(), fontTinyItalic));
                            PdfPCell pcNoStruct = new PdfPCell(new Phrase("No Structure - " + dr["NO_STRUCT"].ToString(), fontTinyItalic));

                            pcNUM.Border = PdfPCell.NO_BORDER;
                            pcRegNo.Border = PdfPCell.NO_BORDER;
                            pcRole.Border = PdfPCell.NO_BORDER;
                            pcDPTRs.Border = PdfPCell.NO_BORDER;
                            pcNoStruct.Border = PdfPCell.NO_BORDER;
                           
                            pcNUM.BackgroundColor = bgcolTANInfo;
                            pcRegNo.BackgroundColor = bgcolTANInfo;
                            pcRole.BackgroundColor = bgcolTANInfo;
                            pcDPTRs.BackgroundColor = bgcolTANInfo;
                            pcNoStruct.BackgroundColor = bgcolTANInfo;
                            
                            ptNumInfo.AddCell(pcNUM);
                            ptNumInfo.AddCell(pcRegNo);
                            ptNumInfo.AddCell(pcRole);
                            ptNumInfo.AddCell(pcDPTRs);
                            ptNumInfo.AddCell(pcNoStruct);

                            ptPAR.AddCell(ptNumInfo);

                            //Child table 2
                            PdfPTable ptPARInfo = new PdfPTable(1);

                            //PAR
                            if (!string.IsNullOrEmpty(dr["PAR"].ToString()))
                            {
                                ptPARInfo.AddCell(new Phrase("PAR", fontTinyItalic));
                                //PdfPCell pcCTH = new PdfPCell(new Phrase(dr["PAR"].ToString(), fontTinyItalic));
                                PdfPCell pcPAR = GetHtmlContentCell(dr["PAR"].ToString());
                                ptPARInfo.AddCell(pcPAR);
                            }
                             
                            //TMD
                            if (!string.IsNullOrEmpty(dr["NUM_TMD"].ToString()))
                            {
                                ptPARInfo.AddCell(new Phrase("TMD", fontTinyItalic));
                                pcTMD = new PdfPCell(new Phrase(dr["NUM_TMD"].ToString(), fontTinyItalic));                                
                                ptPARInfo.AddCell(pcTMD);
                            }

                            //AMD
                            if (!string.IsNullOrEmpty(dr["AMD"].ToString()))
                            {
                                ptPARInfo.AddCell(new Phrase("AMD", fontTinyItalic));
                                pcAMD = new PdfPCell(new Phrase(dr["AMD"].ToString(), fontTinyItalic));                                
                                ptPARInfo.AddCell(pcAMD);
                            }

                            //HMD
                            if (!string.IsNullOrEmpty(dr["HMD"].ToString()))
                            {
                                ptPARInfo.AddCell(new Phrase("HMD", fontTinyItalic));
                                pcHMD = new PdfPCell(new Phrase(dr["HMD"].ToString(), fontTinyItalic));                               
                                ptPARInfo.AddCell(pcHMD);
                            }

                            //Child table 3
                            PdfPTable ptPAR_Struct = new PdfPTable(2);
                            //ptPAR_Struct
                            PdfPCell pcParData = new PdfPCell(ptPARInfo);
                            pcParData.Border = PdfPCell.NO_BORDER;
                            ptPAR_Struct.AddCell(pcParData);

                            PdfPCell pcImgCell = null;

                            //Structure
                            if (dr["MOL_IMAGE"] != null)
                            {
                                try
                                {
                                    chemimg = iTextSharp.text.Image.GetInstance(dr["MOL_IMAGE"] as byte[]);
                                    chemimg.ScaleToFit(50f, 50f);
                                    chemimg.ScaleAbsolute((float)50f, (float)50f);
                                    chemimg.Alignment = iTextSharp.text.Image.TEXTWRAP | iTextSharp.text.Image.ALIGN_CENTER;
                                }
                                catch
                                {
                                    chemimg = null;
                                }                               
                            }
                            //pcImgCell = new PdfPCell(chemimg, true);
                            //pcImgCell.Border = PdfPCell.NO_BORDER;
                            //pcImgCell.FixedHeight = rowHeight;
                            ptPAR_Struct.AddCell(chemimg);
                                                        
                            ptPAR.AddCell(ptPAR_Struct);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return ptPAR;
        }
    }
}
