﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using System.Xml.Linq;
using System.Xml;
using System.Collections;
using IndxReactNarr.XmlValidation;
using System.IO;

namespace IndxReactNarr.OtherForms
{
    public partial class frmNarrExpProcXmlsFinalChecks : Form
    {
        public frmNarrExpProcXmlsFinalChecks()
        {
            InitializeComponent();
        }

        private void frmNarrExpProcXmlsFinalChecks_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void btnValidate_Click(object sender, EventArgs e)
        {
            try
            {
                StringBuilder sbError_Out = new StringBuilder();
                rtbErrors.Clear();

                _inttotalreactioncount = 0;
                string statusMsg = "";
                lblStatus.Text = "";

                _bothnaridanddatanotnull = 0;
                _naridnotnullanddataisnull = 0;
                _naridisnullanddatanotnull = 0;
                _bothnaridanddataisnull = 0;

                if (!string.IsNullOrEmpty(txtXmlFilesPath.Text))
                {
                    if (System.IO.Directory.Exists(txtXmlFilesPath.Text))
                    {
                        string[] strfilenames = System.IO.Directory.GetFiles(txtXmlFilesPath.Text, "*.xml");
                        if (strfilenames != null)
                        {                            
                            foreach (string strfile in strfilenames)
                            {
                                if (rbnAnalogousCheck.Checked)
                                {
                                    CheckAnalogousReactions(strfile, ref sbError_Out);

                                    statusMsg = rbnAnalogousCheck.Text;
                                }
                                else if (rbnFormulaChecking.Checked) //Formula checking validation
                                {
                                    dsformulas = TextToDataSet.Convert(AppDomain.CurrentDomain.BaseDirectory + "formulas.txt", "test", "\t");

                                    CheckandFormulaXMLS(strfile, ref sbError_Out);

                                    statusMsg = rbnFormulaChecking.Text;
                                }
                                else if (rbnPageNoPageLbl.Checked) //PageNo and Page Label validation
                                {
                                    CheckpagenumberandLabelXMLS(strfile, ref sbError_Out);

                                    statusMsg = rbnPageNoPageLbl.Text;
                                }
                                else if (rbnNarIdSeqCheck.Checked)
                                {
                                    CheckNarMissedSequences(strfile, ref sbError_Out);

                                    statusMsg = rbnNarIdSeqCheck.Text;
                                }
                                else if (rbnAnalogMultiParas.Checked)
                                {
                                    CheckAnalogousAndMultipleParaReactions(strfile, ref sbError_Out);

                                    statusMsg = rbnAnalogMultiParas.Text;
                                }
                                else if(rbnReactionCntCheck.Checked)
                                {
                                    CheckandReactionCountXMLS(strfile, ref sbError_Out);

                                    statusMsg = rbnReactionCntCheck.Text;
                                }
                                else if (rbnRxnsWithNarr_Data.Checked)
                                {
                                    if (GlobalVariables.ApplicationName == Enums.ApplicationName.NARRATIVES.ToString())
                                    {
                                        CheckNartiveAndDataNullCount_Narratives(strfile, ref sbError_Out);
                                    }
                                    else if (GlobalVariables.ApplicationName == Enums.ApplicationName.EXPPROCEDURES.ToString())
                                    {
                                        CheckNartiveAndDataNullCount_ExpProcedures(strfile, ref sbError_Out);
                                    }

                                    statusMsg = rbnRxnsWithNarr_Data.Text;
                                }
                            }
                        }

                        if (rbnReactionCntCheck.Checked)
                        {
                            sbError_Out.Append("\r\n Total Reactions count " + _inttotalreactioncount);
                        }

                        if (rbnRxnsWithNarr_Data.Checked)
                        {
                            if (GlobalVariables.ApplicationName == Enums.ApplicationName.NARRATIVES.ToString())
                            {
                                string strNarrCnts = "\r\nNarative id is null and data is not null count: " + _naridisnullanddatanotnull.ToString();
                                strNarrCnts += "\r\n Narative id is not null and data is null count : " + _naridnotnullanddataisnull.ToString();
                                strNarrCnts += "\r\n Both Narative id and data is null count: " + _bothnaridanddataisnull;
                                strNarrCnts += "\r\n Both Narative id and data is not null count : " + _bothnaridanddatanotnull.ToString();

                                sbError_Out.Append(strNarrCnts);
                            }
                            else if (GlobalVariables.ApplicationName == Enums.ApplicationName.EXPPROCEDURES.ToString())
                            {
                                string strNarrCnts = "\r\nReactions with Naratives : " + _withNarrCnt.ToString();
                                strNarrCnts += "\r\nReactions without Naratives : " + _withoutNarrCnt.ToString();                               

                                sbError_Out.Append(strNarrCnts);
                            }                            
                        }

                        rtbErrors.Text = sbError_Out.ToString();

                        lblStatus.Text = "Validation '" + statusMsg + "' completed";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnBrowseXmls_Click(object sender, EventArgs e)
        {
            try
            {
                using (FolderBrowserDialog flDlg = new FolderBrowserDialog())
                {
                    if (flDlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        txtXmlFilesPath.Text = flDlg.SelectedPath;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        StringBuilder strerror = new StringBuilder();
        bool Ispatent = false;

        private void CheckpagenumberandLabelXMLS(string strfilepath, ref StringBuilder stroutput)
        {
            XmlTextReader xmlreder = null;
            try
            {

                xmlreder = new XmlTextReader(strfilepath);
                string strfirstpagenumber = "";
                string strfirstpagelabel = "";
                #region MyRegion
                ArrayList alalpha = new ArrayList();
                ArrayList alroman = new ArrayList();
                alroman.Add("i");
                alroman.Add("ii");
                alroman.Add("iii");
                alroman.Add("iv");
                alroman.Add("v");
                alroman.Add("vi");
                alroman.Add("vii");
                alroman.Add("viii");
                alroman.Add("ix");
                alroman.Add("x");


                alalpha.Add("a");
                alalpha.Add("b");
                alalpha.Add("c");
                alalpha.Add("d");
                alalpha.Add("e");
                alalpha.Add("f");
                alalpha.Add("g");
                alalpha.Add("h");
                alalpha.Add("i");
                alalpha.Add("j");
                alalpha.Add("k");
                alalpha.Add("l");
                alalpha.Add("m");
                alalpha.Add("n");
                alalpha.Add("o");
                alalpha.Add("p");
                alalpha.Add("q");
                alalpha.Add("r");
                alalpha.Add("s");
                alalpha.Add("t");
                alalpha.Add("u");
                alalpha.Add("v");
                alalpha.Add("w");
                alalpha.Add("x");
                alalpha.Add("y");
                alalpha.Add("z");
                #endregion

                string strtan = "";
                string xmlFilePath = strfilepath;
                strtan = System.IO.Path.GetFileNameWithoutExtension(strfilepath);
                
                bool issuppdoc2found = false;
                
                XElement xElm = XElement.Load(strfilepath);
                if (!Ispatent)
                {

                    IEnumerable<XElement> supps = from c in xElm.Elements("documents").Descendants("supplemental")
                                                  select c;

                    IEnumerable<XAttribute> supid = supps.Attributes("id");


                    try
                    {
                        if (supid.ElementAt(0).Value.ToString() == "doc2")
                        {
                            issuppdoc2found = true;
                        }
                    }
                    catch (Exception ex)
                    { }
                }
                string strtype = "journalArticle";



                IEnumerable<XElement> qry = from c in xElm.Elements("reactions").Elements("reaction")
                                            select c;
                List<TaPageLabelANDNUMDiff> lstpg = new List<TaPageLabelANDNUMDiff>();


                string strmsg = "";
                ArrayList alrxn = new ArrayList();
                int counter = 0;
                int intfirstdocref = 0;
                try
                {
                    foreach (XElement _xe in qry)
                    {
                        TaPageLabelANDNUMDiff objpg = new TaPageLabelANDNUMDiff();
                        IEnumerable<XAttribute> _docref = _xe.Elements("procedure").Elements("location").Attributes("doc-ref");


                        //IEnumerable<XAttribute> _rxndocref = _xe.Attributes("doc-ref");
                        objpg.DocRef = _docref.ElementAt(0).Value.ToString();

                        IEnumerable<XAttribute> _rxnnumber = _xe.Attributes("num");
                       
                        IEnumerable<XAttribute> _rxnsequence = _xe.Attributes("seq");


                        IEnumerable<XElement> _rxnloc = from c in _xe.Elements("procedure").Elements("location")
                                                        select c;

                        IEnumerable<XElement> _rxnpage = from c in _rxnloc.Elements("page")
                                                         select c;

                        IEnumerable<XElement> _rxnnum = from c in _rxnpage.Elements("number")
                                                        select c;

                        IEnumerable<XElement> _rxnlabel = from c in _rxnpage.Elements("label")
                                                          select c;

                        IEnumerable<XElement> _filenar = from c in _xe.Elements("procedure").Elements("narrative")
                                                         select c;

                        int pagenumber = 0;
                        string pagelabel = "";
                        
                        if (_rxnnum.ElementAt(0).Value == null && _rxnnum.ElementAt(0).Value == "")
                        {
                            strmsg = "\r\nError: TAN : " + strtan + " Page Number is empty at (Num:" + _rxnnumber.ElementAt(0).Value + ",Seq:" + _rxnsequence.ElementAt(0).Value + ") ";
                        }
                        else
                            pagenumber = Convert.ToInt32(_rxnnum.ElementAt(0).Value);

                        try
                        {

                            if (_rxnlabel.ElementAt(0).Value == "")
                            {

                                strmsg += "\r\nWarning: TAN : " + strtan + " Page Label is empty at (Num:" + _rxnnumber.ElementAt(0).Value + ",Seq:" + _rxnsequence.ElementAt(0).Value + ")";
                                pagelabel = "";

                            }
                            else
                                pagelabel = _rxnlabel.ElementAt(0).Value;
                        }
                        catch (Exception ex)
                        {
                            if (Ispatent)
                                strmsg += "\r\nWarning at TAN : " + strtan + " Page Label is not a integer at (Num:" + _rxnnumber.ElementAt(0).Value + ",Seq:" + _rxnsequence.ElementAt(0).Value + " page label value" + _rxnlabel.ElementAt(0).Value.ToString() + " ";
                        }


                        objpg.NUM = Convert.ToInt32(_rxnnumber.ElementAt(0).Value);
                        objpg.SEQ = Convert.ToInt32(_rxnsequence.ElementAt(0).Value);

                        objpg.PAGENUM = pagenumber;
                        objpg.PAGELABEL = pagelabel;

                        if (intfirstdocref == 0)
                        {
                            if (objpg.DocRef == "doc2")
                            {
                                strfirstpagelabel = pagelabel.ToString();
                                strfirstpagenumber = pagenumber.ToString();
                                intfirstdocref = 1;
                            }
                        }
                        //objpg.diff = pagenumber - pagelabel;

                        objpg.TAN = strtan;

                        if (pagelabel.Contains("/"))
                        {
                            strmsg += "\r\nWarning: TAN : " + strtan + " Page Label value is ( '" + pagelabel + "' )  at (Num:" + _rxnnumber.ElementAt(0).Value + ",Seq:" + _rxnsequence.ElementAt(0).Value + ") ";
                        }



                        if (pagenumber.ToString() == pagelabel.ToString())
                        {
                            strmsg += "\r\nWarning: TAN : " + strtan + " Page Number and Page Label is equal at (Num:" + _rxnnumber.ElementAt(0).Value + ",Seq:" + _rxnsequence.ElementAt(0).Value + ") ";
                        }
                        if (Ispatent)
                        {
                            try
                            {
                                if (Convert.ToInt32(pagelabel) > pagenumber)
                                {
                                    strmsg += "\r\nError: TAN : " + strtan + " Pagelabel is greater then pangenumber  at (Num:" + _rxnnumber.ElementAt(0).Value + ",Seq:" + _rxnsequence.ElementAt(0).Value + ")  ";
                                }
                            }
                            catch (Exception ex)
                            {
                                //strmsg += "\r\nError: TAN : " + strtan + " Page label Value :[ '" +pagelabel+ "' ]at (Num:" + _rxnnumber.ElementAt(0).Value + ",Seq:" + _rxnsequence.ElementAt(0).Value + ")  ";
                            }

                        }
                        lstpg.Add(objpg);

                        counter++;

                    }
                }
                catch (Exception ex)
                {

                }
                Hashtable ht = new Hashtable();
                int i = 0;
                ArrayList aldiff = new ArrayList();
                //CheckPagelabel is alphanumeric or number


                bool isNumberic = false;
                bool IsAlphaNumeric = false;
                bool ischartype = false;
                int firstdiff = 0;
                Hashtable htDoc1pagenumseq = new Hashtable();
                try
                {
                    if (strfirstpagelabel != "")
                    {
                        if (IsNumrictype(strfirstpagelabel))
                        {
                            isNumberic = true;
                            firstdiff = Convert.ToInt32(strfirstpagenumber) - Convert.ToInt32(strfirstpagelabel);
                        }
                        else if (IsTexttype(strfirstpagelabel))
                        {
                            ischartype = true;

                        }
                        else
                        {
                            IsAlphaNumeric = true;
                            firstdiff = Convert.ToInt32(strfirstpagenumber) - Convert.ToInt32(GetNumberfromAlphanumericstring(strfirstpagelabel));
                        }
                    }

                }
                catch (Exception ex)
                {

                }
                if (lstpg.Count > 0)
                {
                    if (Ispatent)
                    {
                        try
                        {
                            foreach (TaPageLabelANDNUMDiff tn in lstpg)
                            {

                                if (!ht.ContainsKey(tn.diff))
                                {
                                    if (i > 0)
                                    {
                                        strmsg += "\r\nError: TAN : " + strtan + " Page number/label with Difference inconsistency, at (Num:" + tn.NUM.ToString("0000") + ",Seq:" + tn.SEQ.ToString("0000") + ")  ";
                                    }
                                    else
                                        ht.Add(tn.diff, tn.PAGENUM);
                                }
                                else
                                {
                                    if (i == 0)
                                    {
                                        ht.Add(tn.diff, tn.PAGENUM);
                                    }
                                }
                                i++;
                            }

                            foreach (TaPageLabelANDNUMDiff tn in lstpg)
                            {
                                if (tn.DocRef.ToUpper() == "DOC1")
                                {
                                    if (tn.PAGELABEL.ToString() != "")
                                    {
                                        string stroutmsg = "";
                                        if (!CheckDuplicatePagenumandLabels(lstpg, tn.PAGENUM.ToString(), tn.PAGELABEL.ToString(), "DOC1", out stroutmsg))
                                        {
                                            strmsg += "\r\nError: TAN : " + strtan + " Duplicate Page label|Num  docref='doc1', at (Num:" + tn.NUM.ToString("0000") + ",Seq:" + tn.SEQ.ToString("0000") + ") : and Page Num:  " + tn.PAGENUM.ToString() + " Page Label : " + tn.PAGELABEL + " " + stroutmsg;
                                        }
                                        stroutmsg = "";
                                        if (!CheckDuplicatePageLabels(lstpg, tn.PAGENUM.ToString(), tn.PAGELABEL.ToString(), "DOC1", out stroutmsg))
                                        {
                                            strmsg += "\r\nError: TAN : " + strtan + " Duplicate Page label|Num  docref='doc1', at (Num:" + tn.NUM.ToString("0000") + ",Seq:" + tn.SEQ.ToString("0000") + ") : and Page Num:  " + tn.PAGENUM.ToString() + " Page Label : " + tn.PAGELABEL + " " + stroutmsg;
                                        }
                                    }
                                }
                            }

                            foreach (TaPageLabelANDNUMDiff tn in lstpg)
                            {
                                if (tn.DocRef.ToUpper() == "DOC2")
                                {
                                    if (tn.PAGELABEL.ToString() != "")
                                    {
                                        string stroutmsg = "";
                                        if (!CheckDuplicatePagenumandLabels(lstpg, tn.PAGENUM.ToString(), tn.PAGELABEL.ToString(), "DOC2", out stroutmsg))
                                        {
                                            strmsg += "\r\nWarning: TAN : " + strtan + " Duplicate Page label|Num  docref='doc2', at (Num:" + tn.NUM.ToString("0000") + ",Seq:" + tn.SEQ.ToString("0000") + ") : and Page Num:  " + tn.PAGENUM.ToString() + " Page Label : " + tn.PAGELABEL + " " + stroutmsg;
                                        }
                                        stroutmsg = "";
                                        if (!CheckDuplicatePageLabels(lstpg, tn.PAGENUM.ToString(), tn.PAGELABEL.ToString(), "DOC2", out stroutmsg))
                                        {
                                            strmsg += "\r\nWarning: TAN : " + strtan + " Duplicate Page label|Num  docref='doc2', at (Num:" + tn.NUM.ToString("0000") + ",Seq:" + tn.SEQ.ToString("0000") + ") : and Page Num:  " + tn.PAGENUM.ToString() + " Page Label : " + tn.PAGELABEL + " " + stroutmsg;
                                        }
                                    }
                                }
                            }


                        }
                        catch (Exception ex)
                        {
                        }
                    }
                    else
                    {
                        try
                        {
                            foreach (TaPageLabelANDNUMDiff tn in lstpg)
                            {

                                try
                                {
                                    if (tn.DocRef.ToUpper() == "DOC2")
                                    {
                                        if (!tn.PAGELABEL.ToString().ToUpper().Contains("S"))
                                        {

                                            strmsg += "\r\nWarning: TAN : " + strtan + " Page label does not contains S with docref=doc2, at (Num:" + tn.NUM.ToString("0000") + ",Seq:" + tn.SEQ.ToString("0000") + ") :  ";

                                        }

                                        if (ischartype)
                                        {
                                            if (Convert.ToInt32(tn.PAGENUM) > Convert.ToInt32(strfirstpagenumber))
                                            {
                                                int diff = Convert.ToInt32(tn.PAGENUM) - Convert.ToInt32(strfirstpagenumber);
                                                int indexfirstpglabel = GetIndex(strfirstpagelabel);
                                                if (Convert.ToInt32(tn.PAGENUM) + diff == indexfirstpglabel + diff)
                                                {

                                                    int indexpagelabel = GetIndex(tn.PAGELABEL.ToString());
                                                    if (indexpagelabel == indexfirstpglabel + 1)
                                                    {

                                                    }
                                                    else
                                                    {
                                                        strmsg += "\r\nError: TAN : " + strtan + " Page label|Number incosistency docref=doc2, at (Num:" + tn.NUM.ToString("0000") + ",Seq:" + tn.SEQ.ToString("0000") + ") :  ";

                                                    }

                                                }
                                                else
                                                {
                                                    strmsg += "\r\nError: TAN : " + strtan + " Page label|Number incosistency docref=doc2, at (Num:" + tn.NUM.ToString("0000") + ",Seq:" + tn.SEQ.ToString("0000") + ") :  ";

                                                }
                                            }
                                            else
                                            {
                                                strmsg += "\r\nError: TAN : " + strtan + " Page label|Number incosistency docref=doc2, at (Num:" + tn.NUM.ToString("0000") + ",Seq:" + tn.SEQ.ToString("0000") + ") :  ";

                                            }
                                        }
                                        else if (isNumberic)
                                        {

                                            if (IsNumrictype(tn.PAGELABEL))
                                            {
                                                if (Convert.ToInt32(tn.PAGENUM) > Convert.ToInt32(strfirstpagenumber))
                                                {
                                                    int diff = Convert.ToInt32(tn.PAGENUM) - Convert.ToInt32(tn.PAGELABEL);
                                                    if (firstdiff == diff)
                                                    {
                                                        ///int indexfirstpglabel = GetNumberforchar(strfirstpagelabel, alalpha);

                                                    }
                                                    else
                                                    {
                                                        strmsg += "\r\nError: TAN : " + strtan + " Page label|Number incosistency docref=doc2, at (Num:" + tn.NUM.ToString("0000") + ",Seq:" + tn.SEQ.ToString("0000") + ") :  ";
                                                    }

                                                }

                                            }
                                            else
                                                strmsg += "\r\nError: TAN : " + strtan + " Page label|Number incosistency docref=doc2, at (Num:" + tn.NUM.ToString("0000") + ",Seq:" + tn.SEQ.ToString("0000") + ") :  ";

                                        }
                                        else if (IsAlphaNumeric)
                                        {

                                            if (IsValidAlphaNumeric(tn.PAGELABEL.ToString()))
                                            {
                                                if (Convert.ToInt32(tn.PAGENUM) > Convert.ToInt32(strfirstpagenumber))
                                                {
                                                    try
                                                    {
                                                        int _pagelabelintvalue = Convert.ToInt32(GetNumberfromAlphanumericstring(tn.PAGELABEL.ToString()));
                                                        int diff = Convert.ToInt32(tn.PAGENUM) - Convert.ToInt32(_pagelabelintvalue);
                                                        if (firstdiff == diff)
                                                        {
                                                            ///int indexfirstpglabel = GetNumberforchar(strfirstpagelabel, alalpha);

                                                        }
                                                        else
                                                        {
                                                            strmsg += "\r\nError: TAN : " + strtan + " Page label|Number incosistency docref=doc2, at (Num:" + tn.NUM.ToString("0000") + ",Seq:" + tn.SEQ.ToString("0000") + ") :  ";
                                                        }
                                                    }
                                                    catch (Exception ex)
                                                    {
                                                        strmsg += "\r\nError: TAN : " + strtan + " Page label is string for docref=doc2, at (Num:" + tn.NUM.ToString("0000") + ",Seq:" + tn.SEQ.ToString("0000") + ") :  ";
                                                    }
                                                }
                                            }
                                            else
                                                strmsg += "\r\nError: TAN : " + strtan + " Page label|Number incosistency docref=doc2, at (Num:" + tn.NUM.ToString("0000") + ",Seq:" + tn.SEQ.ToString("0000") + ") :  ";


                                        }
                                    }
                                    else if (tn.DocRef.ToUpper() == "DOC1")
                                    {
                                        if (tn.PAGELABEL.ToString() == "")
                                        {
                                            strmsg += "\r\nError: TAN : " + strtan + " Page label is empty at, at (Num:" + tn.NUM.ToString("0000") + ",Seq:" + tn.SEQ.ToString("0000") + ") :  ";
                                        }
                                        else
                                        {
                                            if (IsAlphaNumerictype(tn.PAGELABEL.ToString()))
                                            {
                                                strmsg += "\r\nError: TAN : " + strtan + " Page label can't be alphanumeric, docref='doc1', at (Num:" + tn.NUM.ToString("0000") + ",Seq:" + tn.SEQ.ToString("0000") + ") :  ";
                                            }

                                        }
                                        //if (tn.PAGENUM.ToString() != "" && tn.PAGELABEL.ToString() != "")
                                        //{
                                        //    if (!htDoc1pagenumseq.ContainsKey(tn.PAGENUM.ToString())) //|| (!htDoc1pagenumseq.ContainsValue(tn.PAGELABEL.ToString())))
                                        //    {
                                        //        htDoc1pagenumseq.Add(tn.PAGENUM.ToString(), tn.PAGELABEL.ToString());
                                        //    }
                                        //    else
                                        //        strmsg += "\r\nError: TAN : " + strtan + " Duplicate Page label|Num  docref='doc1', at (Num:" + tn.NUM.ToString("0000") + ",Seq:" + tn.SEQ.ToString("0000") + ") :  ";

                                        //}

                                    }


                                }
                                catch (Exception ex)
                                {

                                }

                            }

                            foreach (TaPageLabelANDNUMDiff tn in lstpg)
                            {
                                if (tn.DocRef.ToUpper() == "DOC1")
                                {
                                    if (tn.PAGELABEL.ToString() != "")
                                    {
                                        string stroutmsg = "";
                                        if (!CheckDuplicatePagenumandLabels(lstpg, tn.PAGENUM.ToString(), tn.PAGELABEL.ToString(), "DOC1", out stroutmsg))
                                        {
                                            strmsg += "\r\nError: TAN : " + strtan + " Duplicate Page label|Num  docref='doc1', at (Num:" + tn.NUM.ToString("0000") + ",Seq:" + tn.SEQ.ToString("0000") + ") : and Page Num:  " + tn.PAGENUM.ToString() + " Page Label : " + tn.PAGELABEL + " " + stroutmsg;
                                        }
                                        stroutmsg = "";
                                        if (!CheckDuplicatePageLabels(lstpg, tn.PAGENUM.ToString(), tn.PAGELABEL.ToString(), "DOC1", out stroutmsg))
                                        {
                                            strmsg += "\r\nError: TAN : " + strtan + " Duplicate Page label|Num  docref='doc1', at (Num:" + tn.NUM.ToString("0000") + ",Seq:" + tn.SEQ.ToString("0000") + ") : and Page Num:  " + tn.PAGENUM.ToString() + " Page Label : " + tn.PAGELABEL + " " + stroutmsg;
                                        }
                                    }
                                }
                            }

                            foreach (TaPageLabelANDNUMDiff tn in lstpg)
                            {
                                if (tn.DocRef.ToUpper() == "DOC2")
                                {
                                    if (tn.PAGELABEL.ToString() != "")
                                    {
                                        string stroutmsg = "";
                                        if (!CheckDuplicatePagenumandLabels(lstpg, tn.PAGENUM.ToString(), tn.PAGELABEL.ToString(), "DOC2", out stroutmsg))
                                        {
                                            strmsg += "\r\nWarning: TAN : " + strtan + " Duplicate Page label|Num  docref='doc2', at (Num:" + tn.NUM.ToString("0000") + ",Seq:" + tn.SEQ.ToString("0000") + ") : and Page Num:  " + tn.PAGENUM.ToString() + " Page Label : " + tn.PAGELABEL + " " + stroutmsg;
                                        }
                                        stroutmsg = "";
                                        if (!CheckDuplicatePageLabels(lstpg, tn.PAGENUM.ToString(), tn.PAGELABEL.ToString(), "DOC2", out stroutmsg))
                                        {
                                            strmsg += "\r\nWarning: TAN : " + strtan + " Duplicate Page label|Num  docref='doc2', at (Num:" + tn.NUM.ToString("0000") + ",Seq:" + tn.SEQ.ToString("0000") + ") : and Page Num:  " + tn.PAGENUM.ToString() + " Page Label : " + tn.PAGELABEL + " " + stroutmsg;
                                        }
                                    }
                                }
                            }


                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }

                    }
                }

                stroutput.Append(strmsg);

                XmlValidatorForExpProc.ErrorMessage = "";
                XmlValidatorForExpProc.ErrorsCount = 0;

                if (!XmlValidatorForExpProc.validate(xmlFilePath))
                {
                    strerror.Append("\r\n TAN " + strtan + ":" + " Data not in correct format:" + "\r\n" + "error at narrative id : " + XmlValidatorForExpProc.strid + " " + XmlValidatorForExpProc.ErrorMessage.ToString() + "\r\n");
                }
                stroutput.Append(strerror);

            }
            catch (Exception ex)
            {
                //MessageBox.Show(" TAN " + strtan + ":Error: " + ex.ToString());
            }
            finally
            {
                xmlreder.Close();
            }


        }

        public static bool IsAlphaNumerictype(string inputStr)
        {
            //make sure the user provided us with data to check
            //if not then return false
            if (string.IsNullOrEmpty(inputStr))
                return false;


            bool isnumber = false;
            bool ischar = false;
            for (int i = 0; i < inputStr.Length; i++)
            {
                if (char.IsNumber(inputStr[i]))
                {
                    isnumber = true;

                }
                else
                {

                    ischar = true;
                }
            }
            if (isnumber && ischar)
                return true;
            else if (isnumber && (!ischar))
                return false;
            else if ((!isnumber) && (ischar))
                return false;


            return true;
        }

        private int GetIndex(string strvalue)
        {
            ArrayList alalpha = new ArrayList();
            #region MyRegion
            alalpha.Add("a");
            alalpha.Add("b");
            alalpha.Add("c");
            alalpha.Add("d");
            alalpha.Add("e");
            alalpha.Add("f");
            alalpha.Add("g");
            alalpha.Add("h");
            alalpha.Add("i");
            alalpha.Add("j");
            alalpha.Add("k");
            alalpha.Add("l");
            alalpha.Add("m");
            alalpha.Add("n");
            alalpha.Add("o");
            alalpha.Add("p");
            alalpha.Add("q");
            alalpha.Add("r");
            alalpha.Add("s");
            alalpha.Add("t");
            alalpha.Add("u");
            alalpha.Add("v");
            alalpha.Add("w");
            alalpha.Add("x");
            alalpha.Add("y");
            alalpha.Add("z");
            #endregion
            for (int i = 0; i < alalpha.Count; i++)
            {
                if (alalpha[i].ToString().ToUpper().Trim() == strvalue.ToUpper().Trim())
                {
                    return i;
                }
            }
            return -1;
        }

        public bool IsNumrictype(string inputStr)
        {
            //make sure the user provided us with data to check
            //if not then return false
            if (string.IsNullOrEmpty(inputStr))
                return false;


            bool isnumber = false;
            bool ischar = false;
            for (int i = 0; i < inputStr.Length; i++)
            {
                if (char.IsNumber(inputStr[i]))
                {
                    isnumber = true;

                }
                else
                {
                    ischar = true;

                }
            }
            if (ischar == true && isnumber == true)
                return false;
            else if (ischar == false && isnumber == true)
                return true;
            else if (ischar = true && isnumber == false)
                return false;

            return false;
        }

        public bool IsTexttype(string inputStr)
        {
            //make sure the user provided us with data to check
            //if not then return false
            if (string.IsNullOrEmpty(inputStr))
                return false;


            bool isnumber = false;
            bool ischar = false;
            for (int i = 0; i < inputStr.Length; i++)
            {
                if (char.IsNumber(inputStr[i]))
                {
                    isnumber = true;
                    ischar = false;
                }
                else
                {
                    isnumber = false;
                    ischar = true;
                }
            }
            if (ischar)
                return true;
            else
                return false;

        }

        public bool IsValidAlphaNumeric(string inputStr)
        {
            //make sure the user provided us with data to check
            //if not then return false
            if (string.IsNullOrEmpty(inputStr))
                return false;


            bool isnumber = false;
            bool ischar = false;
            for (int i = 0; i < inputStr.Length; i++)
            {
                if (char.IsNumber(inputStr[i]))
                {
                    isnumber = true;
                }
                else
                {
                    isnumber = false;
                    ischar = true;
                }
            }
            if (isnumber && (!ischar))
                return false;
            else
                return true;
        }

        public string GetNumberfromAlphanumericstring(string inputStr)
        {
            //make sure the user provided us with data to check
            //if not then return false

            if (string.IsNullOrEmpty(inputStr))
                return "";

            string returnnumber = "";

            bool isnumber = false;
            bool ischar = false;
            string[] strspecialchars = new string[] { "-", "_", "+", "*", "&", "\\", "/", "?", "(", ")" };
            bool isspcfound = false;

            foreach (string c in strspecialchars)
            {
                if (inputStr.Contains(c))
                {
                    isspcfound = true;
                }

            }

            if (!isspcfound)
            {
                for (int i = 0; i < inputStr.Length; i++)
                {
                    if (char.IsNumber(inputStr[i]))
                    {
                        isnumber = true;
                        returnnumber += inputStr[i];
                    }
                    else
                    {
                        isnumber = false;
                        ischar = true;
                    }
                }
            }
            else
            {
                string[] strval = inputStr.Split(strspecialchars, StringSplitOptions.RemoveEmptyEntries);
                if (strval.Length > 0)
                {
                    for (int i = 0; i < strval[1].Length; i++)
                    {
                        if (char.IsNumber(strval[1][i]))
                        {
                            isnumber = true;
                            returnnumber += strval[1][i];
                        }
                        else
                        {
                            isnumber = false;
                            ischar = true;
                        }
                    }
                }

            }
            return returnnumber;

        }
        
        public static bool IsPageLabelCorrectFormat(string strpagenumber, string strpagelabel, string strdocref, out string _strmsg)
        {
            _strmsg = "";
            ArrayList alalpha = new ArrayList();
            #region MyRegion
            alalpha.Add("a");
            alalpha.Add("b");
            alalpha.Add("c");
            alalpha.Add("d");
            alalpha.Add("e");
            alalpha.Add("f");
            alalpha.Add("g");
            alalpha.Add("h");
            alalpha.Add("i");
            alalpha.Add("j");
            alalpha.Add("k");
            alalpha.Add("l");
            alalpha.Add("m");
            alalpha.Add("n");
            alalpha.Add("o");
            alalpha.Add("p");
            alalpha.Add("q");
            alalpha.Add("r");
            alalpha.Add("s");
            alalpha.Add("t");
            alalpha.Add("u");
            alalpha.Add("v");
            alalpha.Add("w");
            alalpha.Add("x");
            alalpha.Add("y");
            alalpha.Add("z");
            #endregion
            try
            {
                if (strpagelabel != null)
                {
                    if (strdocref.ToLower().Contains("doc1"))
                    {
                        Char[] carray = strpagelabel.ToCharArray();
                        if (carray != null)
                        {
                            if (carray.Length > 1)
                            {
                                foreach (char c in carray)
                                {
                                    if (c.ToString().ToLower() == "s")
                                    {
                                        _strmsg = "Contains S in PageLabel with docref=doc1";
                                        return false;
                                    }
                                }

                            }
                            else
                            {
                                char[] cpagenumber = strpagenumber.ToCharArray();
                                if (cpagenumber != null)
                                {
                                    if (cpagenumber.Length >= 1)
                                    {
                                        if (char.IsNumber(cpagenumber[0]))
                                        {
                                            if (strpagenumber.ToString() == GetNumberforchar(carray[0].ToString(), alalpha).ToString())
                                            {
                                                return true;
                                            }
                                            else
                                            {
                                                _strmsg = "Please enter correct page label";
                                                return false;
                                            }
                                        }
                                    }
                                }
                            }

                        }

                    }
                    else if (strdocref.ToLower().Contains("doc2"))
                    {
                        if (strpagelabel != "")
                        {
                            Char[] cplable = strpagelabel.Trim().ToCharArray();
                            if (cplable != null)
                            {
                                if (cplable.Length > 0)
                                {

                                    string strplabel = "";
                                    for (int j = 0; j < cplable.Length; j++)
                                    {
                                        if (char.IsNumber(cplable[j]))
                                        {
                                            strplabel += cplable[j].ToString();

                                        }
                                    }
                                    if (strplabel != "")
                                    {
                                        if (strplabel.ToString() == strpagenumber.ToString())
                                        {
                                            return true;
                                        }
                                        else
                                        {
                                            _strmsg = "PageNumber | Pagelabel Inconsistency";
                                            return false;
                                        }
                                    }


                                }

                            }
                        }

                        return true;
                        _strmsg = "";
                    }
                    else
                    {
                        return true;
                        _strmsg = "";
                    }
                    _strmsg = "Please enter correct page number";
                }
            }
            catch (Exception ex)
            {
                //Exceptions.CASExceptions.WriteErrorLog(ex.ToString());
            }
            return false;
        }
        
        private static int GetNumberforchar(string str, ArrayList alalpha)
        {
            if (str != null)
            {
                if (alalpha.Contains(str))
                {
                    for (int i = 1; i <= alalpha.Count; i++)
                    {
                        if (str.ToUpper() == alalpha[i - 1].ToString().ToUpper())
                        {
                            return i;
                        }
                    }
                }
            }
            return 0;

        }

        private bool CheckDuplicatePagenumandLabels(List<TaPageLabelANDNUMDiff> lstpagenumandseq, string strpagenum, string strpagelabel, string strDocRef, out string stroutmsg)
        {
            bool isvalid = true;
            stroutmsg = "";
            if (lstpagenumandseq.Count > 0)
            {

                List<TaPageLabelANDNUMDiff> myLocatedObject = lstpagenumandseq.FindAll(delegate(TaPageLabelANDNUMDiff pln) { return pln.PAGENUM.ToString() == strpagenum.ToString(); });
                foreach (TaPageLabelANDNUMDiff obj in myLocatedObject)
                {
                    if (obj.DocRef.ToUpper() == strDocRef.ToUpper())
                    {
                        if (obj.PAGENUM.ToString() == strpagenum)
                        {
                            if (obj.PAGELABEL.ToString().ToUpper() != strpagelabel)
                            {
                                isvalid = false;
                                stroutmsg = ",prior PageNum='" + obj.PAGENUM.ToString() + "' Pagelabel='" + obj.PAGELABEL + "'";
                            }
                            else
                                isvalid = true;
                        }
                    }
                    //else
                    //    isvalid= false;
                }
                return isvalid;
            }
            return isvalid;
        }

        private bool CheckDuplicatePageLabels(List<TaPageLabelANDNUMDiff> lstpagenumandseq, string strpagenum, string strpagelabel, string strDocref, out string stroutmessage)
        {
            bool isvalid = true;
            stroutmessage = "";
            if (lstpagenumandseq.Count > 0)
            {

                List<TaPageLabelANDNUMDiff> myLocatedObject = lstpagenumandseq.FindAll(delegate(TaPageLabelANDNUMDiff pln) { return pln.PAGELABEL.ToString().ToUpper() == strpagelabel.ToString().ToUpper(); });
                foreach (TaPageLabelANDNUMDiff obj in myLocatedObject)
                {
                    if (obj.DocRef.ToUpper() == strDocref.ToUpper())
                    {
                        if (obj.PAGELABEL.ToString() == strpagelabel)
                        {
                            if (obj.PAGENUM.ToString().ToUpper() != strpagenum)
                            {
                                isvalid = false;
                                stroutmessage = ",prior Pagenum='" + obj.PAGENUM.ToString() + "' Pagelabel='" + obj.PAGELABEL + "'";
                                //prior number='6' label='4570'
                            }
                            else
                            {
                                isvalid = true;
                            }
                        }
                    }
                    //else
                    //    isvalid= false;
                }
                return isvalid;
            }
            return isvalid;
        }
               
        DataSet dsformulas = null;
        string strtan = "";
        private void CheckandFormulaXMLS(string strfilepath, ref StringBuilder stroutput)
        {
            XmlTextReader xmlreder = null;
            try
            {
                xmlreder = new XmlTextReader(strfilepath);              
                
                string xmlFilePath = strfilepath;
                string fieldName = "";
                string paraData = "";

                while (xmlreder.Read())
                {
                    strtan = System.IO.Path.GetFileNameWithoutExtension(strfilepath);
                    fieldName = xmlreder.Name.ToString().ToLower();
                    if (fieldName == "para" || fieldName == "data" || fieldName == "description")
                    {
                        paraData = xmlreder.ReadInnerXml();
                        FindAndReplaceStrings(paraData, dsformulas, strtan, fieldName, ref stroutput);
                    }
                }

                //XmlValidatorForExpProc.ErrorMessage = "";
                //XmlValidatorForExpProc.ErrorsCount = 0;

                //if (!XmlValidatorForExpProc.validate(xmlFilePath))
                //{
                //    stroutput.Append("\r\n TAN " + strtan + ":" + " Data not in correct format:" + "\r\n" + "error at narrative id : " + XmlValidatorForExpProc.strid + " " + XmlValidatorForExpProc.ErrorMessage.ToString() + "\r\n");
                //}

               
                //rtbErrors.Text = strerror.ToString();

            }
            catch (Exception ex)
            {
               // MessageBox.Show("TAN: " + strtan + " Error At : " + ex.ToString());
            }
            finally
            {
                xmlreder.Close();
            }
        }

        public void FindAndReplaceStrings(string _strrichtextcontent, DataSet _dsFandR, String strTan,string foundin, ref StringBuilder stroutput)
        {
            string strText = _strrichtextcontent;
            strText = strText.Replace("\n", " ");
            strText = strText.Replace("\r\n", " ");
            strText = strText.Replace("  ", " ");

            try
            {
                if (_dsFandR != null)
                {
                    if (_dsFandR.Tables.Count > 0)
                    {
                        if (_dsFandR.Tables[0].Rows.Count > 0)
                        {
                            for (int i = 0; i < _dsFandR.Tables[0].Rows.Count; i++)
                            {
                                if (CheckandReplaceContent(strText, _dsFandR.Tables[0].Rows[i]["Key"].ToString(), _dsFandR.Tables[0].Rows[i]["VALUE"].ToString()))
                                {
                                    //if (richTextBox1.Text != null && richTextBox1.Text != "")
                                    //{
                                    stroutput.Append("\r\n" + "Formula Without conversion TAN : " + strTan + ", " + foundin + " - Formula Name : " + _dsFandR.Tables[0].Rows[i]["Key"].ToString() + " \r\n");
                                    //}
                                    //else
                                    //    richTextBox1.Text = "\r\n" + "Formula Found Without conversion TAN : " + strTan + " Formula Name : " + _dsFandR.Tables[0].Rows[i]["Key"].ToString() + " \r\n";
                                }
                            }
                        }

                        //rtbErrors.Text = strerror.ToString();
                    }
                }
            }
            catch (Exception ex)
            {


            }

        }
       
        private bool CheckandReplaceContent(string _richtxt, string strkey, string strvalue)
        {
            try
            {
                if (strkey == "")
                {
                    return false;
                }
                strkey = strkey.ToLower();
                _richtxt = _richtxt.ToLower();
                if (_richtxt.Contains(strkey))
                {
                    return true;
                    //_richtxt = _richtxt.Replace(strkey, strvalue);
                    //return _richtxt;
                }
                else
                    return false;
            }
            catch (Exception ex)
            {
                return false;
            }
            return false;
        }

        private void CheckNarMissedSequences(string strfilepath, ref StringBuilder stroutput)
        {
            try
            {        
                string xmlFilePath = strfilepath;
                strtan = System.IO.Path.GetFileNameWithoutExtension(strfilepath);
                string strmsg = "";

                XElement xElm = XElement.Load(strfilepath);
                IEnumerable<XElement> qryreaction = from c in xElm.Elements("reactions").Elements("reaction")
                                                    select c;

                ArrayList alnarid = new ArrayList();
                ArrayList almissednarid = new ArrayList();
                foreach (XElement _xe in qryreaction)
                {
                    try
                    {
                        IEnumerable<XElement> _rxnnarative = _xe.Elements("procedure").Elements("narrative");

                        IEnumerable<XAttribute> _rxnnarrativeid = _rxnnarative.Attributes("id");
                        alnarid.Add(_rxnnarrativeid.ElementAt(0).Value.ToString().Replace("nar", ""));
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(strtan + ex.ToString());
                    }
                }

                if (alnarid.Count > 0)
                {
                    try
                    {
                        for (int i = 1; i < alnarid.Count - 1; i++)
                        {
                            if (Convert.ToInt32(alnarid[i]) + 1 < Convert.ToInt32(alnarid[i + 1]))
                            {

                                for (int j = Convert.ToInt32(alnarid[i]) + 1; j < Convert.ToInt32(alnarid[i + 1]); j++)
                                {
                                    almissednarid.Add(j);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                }

                if (almissednarid.Count > 0)
                {
                    for (int i = 0; i < almissednarid.Count; i++)
                    {
                        strmsg += "\r\nError: TAN : " + strtan + " missed narative ids : nar" + almissednarid[i] + " ";
                    }
                }

                stroutput.Append(strmsg);

                //XmlValidatorForExpProc.ErrorMessage = "";
                //XmlValidatorForExpProc.ErrorsCount = 0;

                //if (!XmlValidatorForExpProc.validate(xmlFilePath))
                //{
                //    strerror.Append("\r\n TAN " + strtan + ":" + "error at narrative id : " + XmlValidatorForExpProc.ErrorMessage.ToString() + "\r\n"); //XmlValidatorForExpProc.strid + " "
                //}
                //stroutput.Append(strerror);

            }
            catch (Exception ex)
            {
                stroutput.Append("\r\n TAN " + strtan + " - Error in parsing the xml");
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void CheckAnalogousReactions(string strfilepath, ref StringBuilder stroutput)
        {
            try
            {
                List<Filenames> listfilenames = new List<Filenames>();
                string strtan = "";
                string xmlFilePath = strfilepath;
                strtan = System.IO.Path.GetFileNameWithoutExtension(strfilepath);                
                string strmsg = "";
                IEnumerable<XElement> qryreaction = null;

                try
                {
                    XElement xElm = XElement.Load(strfilepath); 
                    
                    qryreaction = from c in xElm.Elements("reactions").Elements("reaction")
                                  select c;

                    List<NARANALOGOUSCHECK> _lstnarcheck = new List<NARANALOGOUSCHECK>();
                    foreach (XElement _xe in qryreaction)
                    {
                        IEnumerable<XElement> _rxnnarative = _xe.Elements("procedure").Elements("narrative");
                        IEnumerable<XAttribute> _rxnnarrativeid = _rxnnarative.Attributes("id");
                        IEnumerable<XAttribute> _rxnnumber = _xe.Attributes("num");                   
                        IEnumerable<XAttribute> _rxnsequence = _xe.Attributes("seq");

                        //analogousTo
                        if (_rxnnarative.Attributes("analogous-to").Count() > 0)
                        {
                            //htana.Add(_rxnnarrativeid.ElementAt(0).Value.ToString(), _rxnnarative.Attributes("analogousTo").ElementAt(0).Value.ToString());
                            NARANALOGOUSCHECK objnarchk = new NARANALOGOUSCHECK();
                            objnarchk.NARID = _rxnnarrativeid.ElementAt(0).Value.ToString();
                            objnarchk.ANANARID = _rxnnarative.Attributes("analogous-to").ElementAt(0).Value.ToString();
                            objnarchk.NUM = _rxnnumber.ElementAt(0).Value.ToString();
                            objnarchk.SEQ = _rxnsequence.ElementAt(0).Value.ToString();
                            _lstnarcheck.Add(objnarchk);
                        }

                        try
                        {
                            if (_rxnnarative.Elements("para").Count() > 0)
                            {
                                IEnumerable<XElement> _rxnpara1 = _rxnnarative.Elements("para");
                                if (_rxnpara1.ElementAt(0).Value.ToString().Contains("analogous"))
                                {
                                    strmsg = "\r\nError: TAN : " + strtan + " Analogous keyword found in xml";
                                }
                            }
                        }
                        catch (Exception ex)
                        {

                        }

                        if (_rxnnarative.Elements("para").Count() > 0)
                        {
                            if (_rxnnarrativeid.ElementAt(0).Value.ToString().EndsWith(" ") && _rxnnarrativeid.ElementAt(0).Value.ToString().StartsWith(" "))
                            {
                                strmsg = "\r\nError: TAN : " + strtan + " Extra Space at narrative id attribute at " + _rxnnarrativeid.ElementAt(0).Value.ToString() + " ";
                            }
                        }
                    }

                    if (_lstnarcheck.Count > 0)
                    {
                        foreach (NARANALOGOUSCHECK obj in _lstnarcheck)
                        {

                            string stroutnarid = "";
                            if (!CheckAnalogousto(_lstnarcheck, obj.ANANARID.ToString(), out stroutnarid))
                            {
                                strmsg += "\r\nError: TAN : " + strtan + " Reaction (num:" + obj.NUM + " ,seq:" + obj.SEQ + ") A narrative must not be flagged analogous to another which has been flagged analogous.Reaction with id='" + obj.NARID + "' is analogous to reaction with id='" + obj.ANANARID + "', which is then analogous to reaction with id='" + stroutnarid + "'. ";
                            }


                            if (obj.NARID.ToString().ToUpper() == obj.ANANARID.ToUpper())
                            {
                                strmsg += "\r\nError: TAN : " + strtan + " Reaction (num:" + obj.NUM + " ,seq:" + obj.SEQ + ") both analogousto and narid were same at nar '" + obj.NARID.ToString() + "' ";
                            }
                        }
                    }

                    stroutput.Append(strmsg);

                    XmlValidatorForExpProc.ErrorMessage = "";
                    XmlValidatorForExpProc.ErrorsCount = 0;

                    if (!XmlValidatorForExpProc.validate(xmlFilePath))
                    {
                        strerror.Append("\r\n TAN " + strtan + ":" + " Data not in correct format:" + "\r\n" + "error at narrative id : " + XmlValidatorForExpProc.ErrorMessage.ToString() + "\r\n");
                    }
                    stroutput.Append(strerror);                    
                }
                catch
                {
                    stroutput.Append("\r\n TAN " + strtan + " - Error in parsing the xml");
                }               
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }            
        }

        private bool CheckAnalogousto(List<NARANALOGOUSCHECK> ht, string strvalue, out string stroutnarvalue)
        {
            stroutnarvalue = "";
            foreach (NARANALOGOUSCHECK strkey in ht)
            {
                if (strkey.NARID.ToUpper() == strvalue.ToUpper())
                {
                    stroutnarvalue = strkey.ANANARID;
                    return false;
                }
            }
            stroutnarvalue = "";
            return true;
        }
        
        private void CheckAnalogousAndMultipleParaReactions(string strfilepath, ref StringBuilder stroutput)
        {
            try
            {
                List<Filenames> listfilenames = new List<Filenames>();
                string strtan = "";
                string xmlFilePath = strfilepath;
                strtan = System.IO.Path.GetFileNameWithoutExtension(strfilepath);                               
                IEnumerable<XElement> qryreaction = null;

                try
                {
                    XElement xElm = XElement.Load(strfilepath);                                      
                    qryreaction = from c in xElm.Elements("reactions").Elements("reaction")
                                  select c;

                    string rxnNUm = "";
                    string rxnSeq = "";

                    foreach (XElement _xe in qryreaction)
                    {

                        IEnumerable<XElement> _rxnnarative = _xe.Elements("procedure").Elements("narrative");
                        IEnumerable<XAttribute> _rxnnarrativeid = _rxnnarative.Attributes("id");
                        IEnumerable<XAttribute> _rxnnumber = _xe.Attributes("num");
                        IEnumerable<XAttribute> _rxnsequence = _xe.Attributes("seq");

                        rxnNUm = _rxnnumber.ElementAt(0).Value;
                        rxnSeq = _rxnsequence.ElementAt(0).Value;

                        int intCntr = 0;
                        //analogousTo
                        if (_rxnnarative.Attributes("analogous-to").Count() > 0)
                        {
                            try
                            {
                                IEnumerable<XElement> _rxnparas = _rxnnarative.Elements("para");
                                foreach (XElement parae in _rxnparas)
                                {
                                    if (!string.IsNullOrEmpty(parae.Value.ToString()) && parae.Attributes().Count() == 0)
                                    {
                                        intCntr++;
                                    }
                                    else
                                    {

                                    }
                                }
                            }
                            catch 
                            {

                            }
                        }

                        if (intCntr >= 2)
                        {
                            stroutput.Append("\r\n TAN " + strtan + " - RxnNum:" + rxnNUm + " RxnSeq: " + rxnSeq + " contains " + intCntr + " paras.");
                        }
                    }
                }
                catch
                {
                    stroutput.Append("\r\n TAN " + strtan + " - Error in parsing the xml");
                }     
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }            
        }

        int _inttotalreactioncount = 0;
        private void CheckandReactionCountXMLS(string strfilepath, ref StringBuilder stroutput)
        {
            try
            {
                try
                {
                    XElement xElm = XElement.Load(strfilepath);
                    strtan = System.IO.Path.GetFileNameWithoutExtension(strfilepath);
                    IEnumerable<XElement> qryreaction = from c in xElm.Elements("reactions").Elements("reaction")
                                                        select c;

                    int rxnCnt = qryreaction.Count();
                    _inttotalreactioncount = _inttotalreactioncount + rxnCnt;

                    stroutput.Append("\r\n TAN " + strtan + " - Rxn Count:" + rxnCnt);
                }
                catch
                {
                    stroutput.Append("\r\n TAN " + strtan + " - Error in parsing the xml");
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }            
        }

        //Reactions with Narratives and without Narratives for Narratives
        int _bothnaridanddatanotnull = 0;
        int _naridnotnullanddataisnull = 0;
        int _naridisnullanddatanotnull = 0;
        int _bothnaridanddataisnull = 0;
        private void CheckNartiveAndDataNullCount_Narratives(string strfilepath, ref StringBuilder stroutput)
        {
            //XmlTextReader xmlreder = null;
            try
            {
                //xmlreder = new XmlTextReader(strfilepath);
                
                string strtan = "";
                string xmlFilePath = strfilepath;
                strtan = System.IO.Path.GetFileNameWithoutExtension(strfilepath);

                try
                {
                    XElement xElm = XElement.Load(strfilepath);
                    strtan = System.IO.Path.GetFileNameWithoutExtension(strfilepath);
                    IEnumerable<XElement> qryreaction = from c in xElm.Elements("reactions").Elements("reaction")
                                                        select c;

                    string strmsg = "";                  
                    foreach (XElement _xe in qryreaction)
                    {                       
                        IEnumerable<XAttribute> _rxnnumber = _xe.Attributes("num");
                        IEnumerable<XAttribute> _rxnsequence = _xe.Attributes("seq");

                        IEnumerable<XElement> _rxnloc = from c in _xe.Elements("procedure").Elements("location")
                                                        select c;

                        IEnumerable<XElement> _rxnpage = from c in _rxnloc.Elements("page")
                                                         select c;


                        IEnumerable<XElement> _rxnnum = from c in _rxnpage.Elements("number")
                                                        select c;

                        IEnumerable<XElement> _rxnlabel = from c in _rxnpage.Elements("label")
                                                          select c;

                        IEnumerable<XElement> _rxndoctext = _xe.Elements("procedure");
                        IEnumerable<XElement> _filenar = _rxndoctext.Elements("narrative");
                        IEnumerable<XAttribute> _rxnnarrativeid = _filenar.Attributes("id");
                        IEnumerable<XElement> _para = from c in _filenar.Elements("para")
                                                      select c;
                        
                        IEnumerable<XElement> _data = from c in _rxndoctext.Elements("data")
                                                      select c;
                        string strpara1 = _filenar.ElementAt(0).Value;

                        if (strpara1 == "" && _data.ElementAt(0).Value == "")
                        {
                            strmsg += "\r\nTAN : " + strtan + " both narativeid para and data is empty at(Num:" + _rxnnumber.ElementAt(0).Value + ",Seq:" + _rxnsequence.ElementAt(0).Value + ") ";
                            _bothnaridanddataisnull++;

                        }
                        else if (strpara1 != "" && _data.ElementAt(0).Value != "")
                        {
                            strmsg += "\r\nTAN : " + strtan + " both narativeid para and data not null at(Num:" + _rxnnumber.ElementAt(0).Value + ",Seq:" + _rxnsequence.ElementAt(0).Value + ") ";
                            _bothnaridanddatanotnull++;

                        }
                        else if (strpara1 != "" && _data.ElementAt(0).Value == "")
                        {

                            strmsg += "\r\nTAN : " + strtan + " narativeid para not null and  Data is empty at(Num:" + _rxnnumber.ElementAt(0).Value + ",Seq:" + _rxnsequence.ElementAt(0).Value + ") ";
                            _naridnotnullanddataisnull++;

                        }
                        else if (strpara1 == "" && _data.ElementAt(0).Value != "")
                        {

                            strmsg += "\r\nTAN : " + strtan + " narativeid para is null and data is not empty at(Num:" + _rxnnumber.ElementAt(0).Value + ",Seq:" + _rxnsequence.ElementAt(0).Value + ") ";
                            _naridisnullanddatanotnull++;
                        }
                    }

                    stroutput.Append(strmsg);
                }
                catch
                {
                    stroutput.Append("\r\nTAN " + strtan + " - Error in parsing the xml");
                } 
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }            
        }

        //Reactions with Narratives and without Narratives for Experimental Procedures
        int _withNarrCnt = 0;
        int _withoutNarrCnt = 0;       
        private void CheckNartiveAndDataNullCount_ExpProcedures(string strfilepath, ref StringBuilder stroutput)
        {           
            try
            {
                string strtan = "";
                string xmlFilePath = strfilepath;
                strtan = System.IO.Path.GetFileNameWithoutExtension(strfilepath);
                try
                {
                    XElement xElm = XElement.Load(strfilepath);
                    strtan = System.IO.Path.GetFileNameWithoutExtension(strfilepath);
                    IEnumerable<XElement> qryreaction = from c in xElm.Elements("reactions").Elements("reaction")
                                                        select c;

                    string strmsg = "";
                    foreach (XElement _xe in qryreaction)
                    {
                        IEnumerable<XAttribute> _rxnnumber = _xe.Attributes("num");
                        IEnumerable<XAttribute> _rxnsequence = _xe.Attributes("seq");

                        IEnumerable<XElement> _rxnloc = from c in _xe.Elements("procedure").Elements("location")
                                                        select c;

                        IEnumerable<XElement> _rxnpage = from c in _rxnloc.Elements("page")
                                                         select c;

                        IEnumerable<XElement> _rxnnum = from c in _rxnpage.Elements("number")
                                                        select c;

                        IEnumerable<XElement> _rxnlabel = from c in _rxnpage.Elements("label")
                                                          select c;

                        IEnumerable<XElement> _rxndoctext = _xe.Elements("procedure");
                        IEnumerable<XElement> _filenar = _rxndoctext.Elements("narrative");
                        IEnumerable<XAttribute> _rxnnarrativeid = _filenar.Attributes("id");
                        IEnumerable<XElement> _para = from c in _filenar.Elements("para")
                                                      select c;

                        IEnumerable<XElement> _data = from c in _rxndoctext.Elements("data")
                                                      select c;

                        //Procedure Steps
                        IEnumerable<XElement> _procSteps = _xe.Elements("template").Elements("protocol");
                        try
                        {
                            string strProcSteps = _procSteps.ElementAt(0).Value;
                            if (strProcSteps == "")
                            {
                                _withoutNarrCnt++;
                            }
                            else
                            {
                                _withNarrCnt++;
                            }
                        }
                        catch
                        {
                            _withoutNarrCnt++;
                        }
                        
                        string strpara1 = _filenar.ElementAt(0).Value;
                        if (strpara1 == "" && _data.ElementAt(0).Value == "")
                        {
                            strmsg += "\r\nTAN : " + strtan + " both narativeid para and data is empty at(Num:" + _rxnnumber.ElementAt(0).Value + ",Seq:" + _rxnsequence.ElementAt(0).Value + ") ";
                            _bothnaridanddataisnull++;
                        }
                        else if (strpara1 != "" && _data.ElementAt(0).Value != "")
                        {
                            strmsg += "\r\nTAN : " + strtan + " both narativeid para and data not null at(Num:" + _rxnnumber.ElementAt(0).Value + ",Seq:" + _rxnsequence.ElementAt(0).Value + ") ";
                            _bothnaridanddatanotnull++;
                        }
                        else if (strpara1 != "" && _data.ElementAt(0).Value == "")
                        {
                            strmsg += "\r\nTAN : " + strtan + " narativeid para not null and  Data is empty at(Num:" + _rxnnumber.ElementAt(0).Value + ",Seq:" + _rxnsequence.ElementAt(0).Value + ") ";
                            _naridnotnullanddataisnull++;
                        }
                        else if (strpara1 == "" && _data.ElementAt(0).Value != "")
                        {
                            strmsg += "\r\nTAN : " + strtan + " narativeid para is null and data is not empty at(Num:" + _rxnnumber.ElementAt(0).Value + ",Seq:" + _rxnsequence.ElementAt(0).Value + ") ";
                            _naridisnullanddatanotnull++;
                        }
                    }

                    stroutput.Append(strmsg);
                }
                catch
                {
                    stroutput.Append("\r\nTAN " + strtan + " - Error in parsing the xml");
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }

    public class Filenames
    {
        private string _rxnnum = "";
        private string _rxnseq = "";
        private string _strtan = "";
        private string _strfilename = "";
        private string _docref = "";
        private string _doc1 = "";
        private string _doc2 = "";
        private string _doc3 = "";
        private string _doc4 = "";
        private string _doc5 = "";
        private string _doc6 = "";
        private string _doc7 = "";
        private string _doc8 = "";
        private string _doc9 = "";
        private string _doc10 = "";

        public string RxnNum
        {
            get { return _rxnnum; }
            set { _rxnnum = value; }
        }
        public string RxnSeq
        {
            get { return _rxnseq; }
            set { _rxnseq = value; }
        }
        public string TAN
        {
            get { return _strtan; }
            set { _strtan = value; }
        }
        public string Filename
        {
            get { return _strfilename; }
            set { _strfilename = value; }
        }
        public string DocRef
        {
            get { return _docref; }
            set { _docref = value; }
        }
        public string Doc1
        {
            get { return _doc1; }
            set { _doc1 = value; }
        }
        public string Doc2
        {
            get { return _doc2; }
            set { _doc2 = value; }
        }
        public string Doc3
        {
            get { return _doc3; }
            set { _doc3 = value; }
        }
        public string Doc4
        {
            get { return _doc4; }
            set { _doc4 = value; }
        }
        public string Doc5
        {
            get { return _doc5; }
            set { _doc5 = value; }
        }
        public string Doc6
        {
            get { return _doc6; }
            set { _doc6 = value; }
        }
        public string Doc7
        {
            get { return _doc7; }
            set { _doc7 = value; }
        }
        public string Doc8
        {
            get { return _doc8; }
            set { _doc8 = value; }
        }
        public string Doc9
        {
            get { return _doc9; }
            set { _doc9 = value; }
        }
        public string Doc10
        {
            get { return _doc10; }
            set { _doc10 = value; }
        }
    }

    public class TanNumAndSeq
    {
        public string TAN
        {
            get;
            set;
        }

        public int NUM
        {
            get;
            set;
        }

        public int SEQ
        {
            get;
            set;
        }
    }

    public class TaPageLabelANDNUMDiff
    {
        public string TAN
        {
            get;
            set;
        }
        public string DocRef
        {
            get;
            set;
        }

        public int PAGENUM
        {
            get;
            set;
        }

        public string PAGELABEL
        {
            get;
            set;
        }

        public int NUM
        {
            get;
            set;
        }

        public int SEQ
        {
            get;
            set;
        }
        public int diff
        {
            get;
            set;
        }
    }

    public class NARANALOGOUSCHECK
    {
        public string NUM
        {
            get;
            set;
        }

        public string SEQ
        {
            get;
            set;
        }

        public string NARID
        {
            get;
            set;
        }

        public string ANANARID
        {
            get;
            set;
        }

    }

    public class TextToDataSet
    {

        public TextToDataSet()
        { }

        /// <summary>

        /// Converts a given delimited file into a dataset. 

        /// Assumes that the first line    

        /// of the text file contains the column names.

        /// </summary>

        /// <param name="File">The name of the file to open</param>    

        /// <param name="TableName">The name of the 

        /// Table to be made within the DataSet returned</param>

        /// <param name="delimiter">The string to delimit by</param>

        /// <returns></returns>  

        public static DataSet Convert(string File, string TableName, string delimiter)
        {
            //The DataSet to Return
            DataSet result = new DataSet();

            //Open the file in a stream reader.
            StreamReader s = new StreamReader(File);

            //Split the first line into the columns    
            string[] columns = s.ReadLine().Split(delimiter.ToCharArray());

            //Add the new DataTable to the RecordSet
            result.Tables.Add(TableName);

            //Cycle the colums, adding those that don't exist yet and sequencing the one that do.

            foreach (string col in columns)
            {
                bool added = false;
                string next = "";
                int i = 0;
                while (!added)
                {
                    //Build the column name and remove any unwanted characters.

                    string columnname = col + next;
                    columnname = columnname.Replace("#", "");
                    columnname = columnname.Replace("'", "");
                    columnname = columnname.Replace("&", "");

                    //See if the column already exists

                    if (!result.Tables[TableName].Columns.Contains(columnname))
                    {
                        //if it doesn't then we add it here and mark it as added

                        result.Tables[TableName].Columns.Add(columnname);
                        added = true;
                    }
                    else
                    {
                        //if it did exist then we increment the sequencer and try again.

                        i++;
                        next = "_" + i.ToString();
                    }
                }
            }

            //Read the rest of the data in the file.        

            string AllData = s.ReadToEnd();

            //Split off each row at the Carriage Return/Line Feed

            //Default line ending in most windows exports.  

            //You may have to edit this to match your particular file.

            //This will work for Excel, Access, etc. default exports.

            string[] rows = AllData.Split("\r\n".ToCharArray());

            //Now add each row to the DataSet        

            foreach (string r in rows)
            {
                //Split the row at the delimiter.

                string[] items = r.Split(delimiter.ToCharArray());

                //Add the item
                if (items.Length > 1)
                {
                    result.Tables[TableName].Rows.Add(items);
                }
            }

            //Return the imported data.        

            return result;
        }
    }
}
