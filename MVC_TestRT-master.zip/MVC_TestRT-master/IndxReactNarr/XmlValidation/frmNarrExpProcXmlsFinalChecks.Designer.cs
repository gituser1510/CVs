﻿namespace IndxReactNarr.OtherForms
{
    partial class frmNarrExpProcXmlsFinalChecks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMain = new System.Windows.Forms.Panel();
            this.rtbErrors = new System.Windows.Forms.RichTextBox();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.lblStatus = new System.Windows.Forms.Label();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.rbnAnalogMultiParas = new System.Windows.Forms.RadioButton();
            this.rbnNarIdSeqCheck = new System.Windows.Forms.RadioButton();
            this.rbnDocRefMisMatch = new System.Windows.Forms.RadioButton();
            this.rbnReactionCntCheck = new System.Windows.Forms.RadioButton();
            this.pnlValidateBtns = new System.Windows.Forms.Panel();
            this.chkIsJournals = new System.Windows.Forms.CheckBox();
            this.btnValidate = new System.Windows.Forms.Button();
            this.txtXmlFilesPath = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBrowseXmls = new System.Windows.Forms.Button();
            this.rbnAnalogousCheck = new System.Windows.Forms.RadioButton();
            this.rbnFileNameValidation = new System.Windows.Forms.RadioButton();
            this.rbnFormulaChecking = new System.Windows.Forms.RadioButton();
            this.rbnPageNoPageLbl = new System.Windows.Forms.RadioButton();
            this.rbnRxnsWithNarr_Data = new System.Windows.Forms.RadioButton();
            this.pnlMain.SuspendLayout();
            this.pnlBottom.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.pnlValidateBtns.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.rtbErrors);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1138, 478);
            this.pnlMain.TabIndex = 0;
            // 
            // rtbErrors
            // 
            this.rtbErrors.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbErrors.Location = new System.Drawing.Point(0, 120);
            this.rtbErrors.Name = "rtbErrors";
            this.rtbErrors.Size = new System.Drawing.Size(1138, 320);
            this.rtbErrors.TabIndex = 2;
            this.rtbErrors.Text = "";
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom.Controls.Add(this.lblStatus);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 440);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(1138, 38);
            this.pnlBottom.TabIndex = 1;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.ForeColor = System.Drawing.Color.Blue;
            this.lblStatus.Location = new System.Drawing.Point(4, 11);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(18, 17);
            this.lblStatus.TabIndex = 0;
            this.lblStatus.Text = "--";
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.rbnRxnsWithNarr_Data);
            this.pnlTop.Controls.Add(this.rbnAnalogMultiParas);
            this.pnlTop.Controls.Add(this.rbnNarIdSeqCheck);
            this.pnlTop.Controls.Add(this.rbnDocRefMisMatch);
            this.pnlTop.Controls.Add(this.rbnReactionCntCheck);
            this.pnlTop.Controls.Add(this.pnlValidateBtns);
            this.pnlTop.Controls.Add(this.rbnAnalogousCheck);
            this.pnlTop.Controls.Add(this.rbnFileNameValidation);
            this.pnlTop.Controls.Add(this.rbnFormulaChecking);
            this.pnlTop.Controls.Add(this.rbnPageNoPageLbl);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1138, 120);
            this.pnlTop.TabIndex = 0;
            // 
            // rbnAnalogMultiParas
            // 
            this.rbnAnalogMultiParas.AutoSize = true;
            this.rbnAnalogMultiParas.Location = new System.Drawing.Point(381, 64);
            this.rbnAnalogMultiParas.Name = "rbnAnalogMultiParas";
            this.rbnAnalogMultiParas.Size = new System.Drawing.Size(204, 21);
            this.rbnAnalogMultiParas.TabIndex = 11;
            this.rbnAnalogMultiParas.Text = "Analogous with multiple Paras";
            this.rbnAnalogMultiParas.UseVisualStyleBackColor = true;
            // 
            // rbnNarIdSeqCheck
            // 
            this.rbnNarIdSeqCheck.AutoSize = true;
            this.rbnNarIdSeqCheck.Location = new System.Drawing.Point(381, 37);
            this.rbnNarIdSeqCheck.Name = "rbnNarIdSeqCheck";
            this.rbnNarIdSeqCheck.Size = new System.Drawing.Size(169, 21);
            this.rbnNarIdSeqCheck.TabIndex = 10;
            this.rbnNarIdSeqCheck.Text = "Nar Sequence Checking";
            this.rbnNarIdSeqCheck.UseVisualStyleBackColor = true;
            // 
            // rbnDocRefMisMatch
            // 
            this.rbnDocRefMisMatch.AutoSize = true;
            this.rbnDocRefMisMatch.Location = new System.Drawing.Point(197, 91);
            this.rbnDocRefMisMatch.Name = "rbnDocRefMisMatch";
            this.rbnDocRefMisMatch.Size = new System.Drawing.Size(135, 21);
            this.rbnDocRefMisMatch.TabIndex = 9;
            this.rbnDocRefMisMatch.Text = "DocRef Mismatch";
            this.rbnDocRefMisMatch.UseVisualStyleBackColor = true;
            // 
            // rbnReactionCntCheck
            // 
            this.rbnReactionCntCheck.AutoSize = true;
            this.rbnReactionCntCheck.Location = new System.Drawing.Point(7, 91);
            this.rbnReactionCntCheck.Name = "rbnReactionCntCheck";
            this.rbnReactionCntCheck.Size = new System.Drawing.Size(143, 21);
            this.rbnReactionCntCheck.TabIndex = 8;
            this.rbnReactionCntCheck.Text = "Reactions Checking";
            this.rbnReactionCntCheck.UseVisualStyleBackColor = true;
            // 
            // pnlValidateBtns
            // 
            this.pnlValidateBtns.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlValidateBtns.Controls.Add(this.chkIsJournals);
            this.pnlValidateBtns.Controls.Add(this.btnValidate);
            this.pnlValidateBtns.Controls.Add(this.txtXmlFilesPath);
            this.pnlValidateBtns.Controls.Add(this.label1);
            this.pnlValidateBtns.Controls.Add(this.btnBrowseXmls);
            this.pnlValidateBtns.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlValidateBtns.Location = new System.Drawing.Point(0, 0);
            this.pnlValidateBtns.Name = "pnlValidateBtns";
            this.pnlValidateBtns.Size = new System.Drawing.Size(1136, 33);
            this.pnlValidateBtns.TabIndex = 7;
            // 
            // chkIsJournals
            // 
            this.chkIsJournals.AutoSize = true;
            this.chkIsJournals.Location = new System.Drawing.Point(835, 5);
            this.chkIsJournals.Name = "chkIsJournals";
            this.chkIsJournals.Size = new System.Drawing.Size(75, 21);
            this.chkIsJournals.TabIndex = 3;
            this.chkIsJournals.Text = "Journals";
            this.chkIsJournals.UseVisualStyleBackColor = true;
            // 
            // btnValidate
            // 
            this.btnValidate.Location = new System.Drawing.Point(1048, 2);
            this.btnValidate.Name = "btnValidate";
            this.btnValidate.Size = new System.Drawing.Size(75, 27);
            this.btnValidate.TabIndex = 0;
            this.btnValidate.Text = "Validate";
            this.btnValidate.UseVisualStyleBackColor = true;
            this.btnValidate.Click += new System.EventHandler(this.btnValidate_Click);
            // 
            // txtXmlFilesPath
            // 
            this.txtXmlFilesPath.BackColor = System.Drawing.Color.White;
            this.txtXmlFilesPath.Location = new System.Drawing.Point(137, 2);
            this.txtXmlFilesPath.Name = "txtXmlFilesPath";
            this.txtXmlFilesPath.ReadOnly = true;
            this.txtXmlFilesPath.Size = new System.Drawing.Size(643, 25);
            this.txtXmlFilesPath.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(2, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Shipment TANs path";
            // 
            // btnBrowseXmls
            // 
            this.btnBrowseXmls.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowseXmls.Location = new System.Drawing.Point(786, 3);
            this.btnBrowseXmls.Name = "btnBrowseXmls";
            this.btnBrowseXmls.Size = new System.Drawing.Size(36, 23);
            this.btnBrowseXmls.TabIndex = 2;
            this.btnBrowseXmls.Text = "...";
            this.btnBrowseXmls.UseVisualStyleBackColor = true;
            this.btnBrowseXmls.Click += new System.EventHandler(this.btnBrowseXmls_Click);
            // 
            // rbnAnalogousCheck
            // 
            this.rbnAnalogousCheck.AutoSize = true;
            this.rbnAnalogousCheck.Location = new System.Drawing.Point(197, 64);
            this.rbnAnalogousCheck.Name = "rbnAnalogousCheck";
            this.rbnAnalogousCheck.Size = new System.Drawing.Size(147, 21);
            this.rbnAnalogousCheck.TabIndex = 6;
            this.rbnAnalogousCheck.Text = "Analogous Checking";
            this.rbnAnalogousCheck.UseVisualStyleBackColor = true;
            // 
            // rbnFileNameValidation
            // 
            this.rbnFileNameValidation.AutoSize = true;
            this.rbnFileNameValidation.Location = new System.Drawing.Point(7, 64);
            this.rbnFileNameValidation.Name = "rbnFileNameValidation";
            this.rbnFileNameValidation.Size = new System.Drawing.Size(140, 21);
            this.rbnFileNameValidation.TabIndex = 5;
            this.rbnFileNameValidation.Text = "Filename Validation";
            this.rbnFileNameValidation.UseVisualStyleBackColor = true;
            // 
            // rbnFormulaChecking
            // 
            this.rbnFormulaChecking.AutoSize = true;
            this.rbnFormulaChecking.Location = new System.Drawing.Point(197, 37);
            this.rbnFormulaChecking.Name = "rbnFormulaChecking";
            this.rbnFormulaChecking.Size = new System.Drawing.Size(133, 21);
            this.rbnFormulaChecking.TabIndex = 4;
            this.rbnFormulaChecking.Text = "Formula Checking";
            this.rbnFormulaChecking.UseVisualStyleBackColor = true;
            // 
            // rbnPageNoPageLbl
            // 
            this.rbnPageNoPageLbl.AutoSize = true;
            this.rbnPageNoPageLbl.Checked = true;
            this.rbnPageNoPageLbl.Location = new System.Drawing.Point(7, 37);
            this.rbnPageNoPageLbl.Name = "rbnPageNoPageLbl";
            this.rbnPageNoPageLbl.Size = new System.Drawing.Size(162, 21);
            this.rbnPageNoPageLbl.TabIndex = 3;
            this.rbnPageNoPageLbl.TabStop = true;
            this.rbnPageNoPageLbl.Text = "Page No. - Page Label";
            this.rbnPageNoPageLbl.UseVisualStyleBackColor = true;
            // 
            // rbnRxnsWithNarr_Data
            // 
            this.rbnRxnsWithNarr_Data.AutoSize = true;
            this.rbnRxnsWithNarr_Data.Location = new System.Drawing.Point(381, 91);
            this.rbnRxnsWithNarr_Data.Name = "rbnRxnsWithNarr_Data";
            this.rbnRxnsWithNarr_Data.Size = new System.Drawing.Size(425, 21);
            this.rbnRxnsWithNarr_Data.TabIndex = 12;
            this.rbnRxnsWithNarr_Data.Text = "Number of reactions returned with narrative and/or data information";
            this.rbnRxnsWithNarr_Data.UseVisualStyleBackColor = true;
            // 
            // frmNarrExpProcXmlsFinalChecks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1138, 478);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmNarrExpProcXmlsFinalChecks";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Narratives and ExpProcedures Xmls Final Checks";
            this.Load += new System.EventHandler(this.frmNarrExpProcXmlsFinalChecks_Load);
            this.pnlMain.ResumeLayout(false);
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlValidateBtns.ResumeLayout(false);
            this.pnlValidateBtns.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.RichTextBox rtbErrors;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtXmlFilesPath;
        private System.Windows.Forms.Button btnBrowseXmls;
        private System.Windows.Forms.RadioButton rbnPageNoPageLbl;
        private System.Windows.Forms.Panel pnlValidateBtns;
        private System.Windows.Forms.Button btnValidate;
        private System.Windows.Forms.RadioButton rbnAnalogousCheck;
        private System.Windows.Forms.RadioButton rbnFileNameValidation;
        private System.Windows.Forms.RadioButton rbnFormulaChecking;
        private System.Windows.Forms.RadioButton rbnReactionCntCheck;
        private System.Windows.Forms.RadioButton rbnDocRefMisMatch;
        private System.Windows.Forms.CheckBox chkIsJournals;
        private System.Windows.Forms.RadioButton rbnNarIdSeqCheck;
        private System.Windows.Forms.RadioButton rbnAnalogMultiParas;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.RadioButton rbnRxnsWithNarr_Data;
    }
}