﻿namespace IndxReactNarr.XmlValidation
{
    partial class frmValidateExpProceXmls
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.tcXmls = new System.Windows.Forms.TabControl();
            this.tpValidXmls = new System.Windows.Forms.TabPage();
            this.dgvValidXmls = new System.Windows.Forms.DataGridView();
            this.tpInValidXmls = new System.Windows.Forms.TabPage();
            this.dgvInValidXmls = new System.Windows.Forms.DataGridView();
            this.pnlStatus = new System.Windows.Forms.Panel();
            this.lblInvalidXmlCnt = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblValidXmlCnt = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnValidate = new System.Windows.Forms.Button();
            this.txtXmlFilesPath = new System.Windows.Forms.TextBox();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTAN_Valid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStatus_Valid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTAN_Invalid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStatus_Invalid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colError_Invalid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain.SuspendLayout();
            this.tcXmls.SuspendLayout();
            this.tpValidXmls.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvValidXmls)).BeginInit();
            this.tpInValidXmls.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInValidXmls)).BeginInit();
            this.pnlStatus.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.tcXmls);
            this.pnlMain.Controls.Add(this.pnlStatus);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1095, 482);
            this.pnlMain.TabIndex = 0;
            // 
            // tcXmls
            // 
            this.tcXmls.Controls.Add(this.tpValidXmls);
            this.tcXmls.Controls.Add(this.tpInValidXmls);
            this.tcXmls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcXmls.Location = new System.Drawing.Point(0, 34);
            this.tcXmls.Name = "tcXmls";
            this.tcXmls.SelectedIndex = 0;
            this.tcXmls.Size = new System.Drawing.Size(1095, 415);
            this.tcXmls.TabIndex = 1;
            // 
            // tpValidXmls
            // 
            this.tpValidXmls.Controls.Add(this.dgvValidXmls);
            this.tpValidXmls.Location = new System.Drawing.Point(4, 26);
            this.tpValidXmls.Name = "tpValidXmls";
            this.tpValidXmls.Padding = new System.Windows.Forms.Padding(3);
            this.tpValidXmls.Size = new System.Drawing.Size(1087, 385);
            this.tpValidXmls.TabIndex = 0;
            this.tpValidXmls.Text = "Valid Xmls";
            this.tpValidXmls.UseVisualStyleBackColor = true;
            // 
            // dgvValidXmls
            // 
            this.dgvValidXmls.AllowUserToAddRows = false;
            this.dgvValidXmls.AllowUserToDeleteRows = false;
            this.dgvValidXmls.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvValidXmls.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvValidXmls.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTAN_Valid,
            this.colStatus_Valid});
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvValidXmls.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgvValidXmls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvValidXmls.Location = new System.Drawing.Point(3, 3);
            this.dgvValidXmls.Name = "dgvValidXmls";
            this.dgvValidXmls.ReadOnly = true;
            this.dgvValidXmls.Size = new System.Drawing.Size(1081, 379);
            this.dgvValidXmls.TabIndex = 0;
            this.dgvValidXmls.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvValidXmls_RowPostPaint);
            // 
            // tpInValidXmls
            // 
            this.tpInValidXmls.Controls.Add(this.dgvInValidXmls);
            this.tpInValidXmls.Location = new System.Drawing.Point(4, 26);
            this.tpInValidXmls.Name = "tpInValidXmls";
            this.tpInValidXmls.Padding = new System.Windows.Forms.Padding(3);
            this.tpInValidXmls.Size = new System.Drawing.Size(1087, 385);
            this.tpInValidXmls.TabIndex = 1;
            this.tpInValidXmls.Text = "Invalid Xmls";
            this.tpInValidXmls.UseVisualStyleBackColor = true;
            // 
            // dgvInValidXmls
            // 
            this.dgvInValidXmls.AllowUserToAddRows = false;
            this.dgvInValidXmls.AllowUserToDeleteRows = false;
            this.dgvInValidXmls.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvInValidXmls.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInValidXmls.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTAN_Invalid,
            this.colStatus_Invalid,
            this.colError_Invalid});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvInValidXmls.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvInValidXmls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvInValidXmls.Location = new System.Drawing.Point(3, 3);
            this.dgvInValidXmls.Name = "dgvInValidXmls";
            this.dgvInValidXmls.ReadOnly = true;
            this.dgvInValidXmls.Size = new System.Drawing.Size(1081, 379);
            this.dgvInValidXmls.TabIndex = 1;
            this.dgvInValidXmls.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvInValidXmls_RowPostPaint);
            // 
            // pnlStatus
            // 
            this.pnlStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlStatus.Controls.Add(this.lblInvalidXmlCnt);
            this.pnlStatus.Controls.Add(this.label4);
            this.pnlStatus.Controls.Add(this.lblValidXmlCnt);
            this.pnlStatus.Controls.Add(this.label2);
            this.pnlStatus.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlStatus.Location = new System.Drawing.Point(0, 449);
            this.pnlStatus.Name = "pnlStatus";
            this.pnlStatus.Size = new System.Drawing.Size(1095, 33);
            this.pnlStatus.TabIndex = 2;
            // 
            // lblInvalidXmlCnt
            // 
            this.lblInvalidXmlCnt.AutoSize = true;
            this.lblInvalidXmlCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblInvalidXmlCnt.Location = new System.Drawing.Point(337, 7);
            this.lblInvalidXmlCnt.Name = "lblInvalidXmlCnt";
            this.lblInvalidXmlCnt.Size = new System.Drawing.Size(15, 17);
            this.lblInvalidXmlCnt.TabIndex = 3;
            this.lblInvalidXmlCnt.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(204, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(131, 17);
            this.label4.TabIndex = 2;
            this.label4.Text = "In-Valid Xmls count: ";
            // 
            // lblValidXmlCnt
            // 
            this.lblValidXmlCnt.AutoSize = true;
            this.lblValidXmlCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblValidXmlCnt.Location = new System.Drawing.Point(125, 7);
            this.lblValidXmlCnt.Name = "lblValidXmlCnt";
            this.lblValidXmlCnt.Size = new System.Drawing.Size(15, 17);
            this.lblValidXmlCnt.TabIndex = 1;
            this.lblValidXmlCnt.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "Valid Xmls count: ";
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.btnBrowse);
            this.pnlTop.Controls.Add(this.label1);
            this.pnlTop.Controls.Add(this.btnValidate);
            this.pnlTop.Controls.Add(this.txtXmlFilesPath);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1095, 34);
            this.pnlTop.TabIndex = 0;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowse.Location = new System.Drawing.Point(827, 2);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(31, 28);
            this.btnBrowse.TabIndex = 3;
            this.btnBrowse.Text = "...";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Select Xml files folder";
            // 
            // btnValidate
            // 
            this.btnValidate.Location = new System.Drawing.Point(874, 2);
            this.btnValidate.Name = "btnValidate";
            this.btnValidate.Size = new System.Drawing.Size(75, 28);
            this.btnValidate.TabIndex = 1;
            this.btnValidate.Text = "Validate";
            this.btnValidate.UseVisualStyleBackColor = true;
            this.btnValidate.Click += new System.EventHandler(this.btnValidate_Click);
            // 
            // txtXmlFilesPath
            // 
            this.txtXmlFilesPath.BackColor = System.Drawing.Color.White;
            this.txtXmlFilesPath.Location = new System.Drawing.Point(146, 4);
            this.txtXmlFilesPath.Name = "txtXmlFilesPath";
            this.txtXmlFilesPath.ReadOnly = true;
            this.txtXmlFilesPath.Size = new System.Drawing.Size(675, 25);
            this.txtXmlFilesPath.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "TAN";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Status";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "TAN";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Status";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewTextBoxColumn5.HeaderText = "Error";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // colTAN_Valid
            // 
            this.colTAN_Valid.HeaderText = "TAN";
            this.colTAN_Valid.Name = "colTAN_Valid";
            this.colTAN_Valid.ReadOnly = true;
            // 
            // colStatus_Valid
            // 
            this.colStatus_Valid.HeaderText = "Status";
            this.colStatus_Valid.Name = "colStatus_Valid";
            this.colStatus_Valid.ReadOnly = true;
            // 
            // colTAN_Invalid
            // 
            this.colTAN_Invalid.HeaderText = "TAN";
            this.colTAN_Invalid.Name = "colTAN_Invalid";
            this.colTAN_Invalid.ReadOnly = true;
            // 
            // colStatus_Invalid
            // 
            this.colStatus_Invalid.HeaderText = "Status";
            this.colStatus_Invalid.Name = "colStatus_Invalid";
            this.colStatus_Invalid.ReadOnly = true;
            // 
            // colError_Invalid
            // 
            this.colError_Invalid.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            this.colError_Invalid.DefaultCellStyle = dataGridViewCellStyle2;
            this.colError_Invalid.HeaderText = "Error";
            this.colError_Invalid.Name = "colError_Invalid";
            this.colError_Invalid.ReadOnly = true;
            // 
            // frmValidateExpProceXmls
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1095, 482);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmValidateExpProceXmls";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Validate Experimental Procedures Xmls";
            this.Load += new System.EventHandler(this.frmValidateExpProceXmls_Load);
            this.pnlMain.ResumeLayout(false);
            this.tcXmls.ResumeLayout(false);
            this.tpValidXmls.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvValidXmls)).EndInit();
            this.tpInValidXmls.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvInValidXmls)).EndInit();
            this.pnlStatus.ResumeLayout(false);
            this.pnlStatus.PerformLayout();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.TabControl tcXmls;
        private System.Windows.Forms.TabPage tpValidXmls;
        private System.Windows.Forms.TabPage tpInValidXmls;
        private System.Windows.Forms.Button btnValidate;
        private System.Windows.Forms.TextBox txtXmlFilesPath;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.DataGridView dgvValidXmls;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTAN_Valid;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStatus_Valid;
        private System.Windows.Forms.DataGridView dgvInValidXmls;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTAN_Invalid;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStatus_Invalid;
        private System.Windows.Forms.DataGridViewTextBoxColumn colError_Invalid;
        private System.Windows.Forms.Panel pnlStatus;
        private System.Windows.Forms.Label lblInvalidXmlCnt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblValidXmlCnt;
        private System.Windows.Forms.Label label2;
    }
}