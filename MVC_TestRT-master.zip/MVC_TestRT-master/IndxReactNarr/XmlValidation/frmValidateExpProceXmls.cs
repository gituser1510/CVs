﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using System.Xml.Schema;
using System.Xml;
using System.IO;
using System.Xml.Linq;

namespace IndxReactNarr.XmlValidation
{
    public partial class frmValidateExpProceXmls : Form
    {
        public frmValidateExpProceXmls()
        {
            InitializeComponent();
        }

        private XmlSchemaSet schemas; // schemas to validate against
        private bool valid = true; // validation result
        XmlReaderSettings settings;
        string tanName = string.Empty;

        //http://stackoverflow.com/questions/854335/xml-exception-invalid-characters

        private void frmValidateExpProceXmls_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;

                colTAN_Valid.DataPropertyName = "TAN";
                colTAN_Invalid.DataPropertyName = "TAN";
                colStatus_Valid.DataPropertyName = "Status";
                colStatus_Invalid.DataPropertyName = "Status";
                colError_Invalid.DataPropertyName = "Error";

                if (GlobalVariables.ApplicationName == Enums.ApplicationName.EXPPROCEDURES.ToString())
                {
                    schemas = new XmlSchemaSet();
                    schemas.Add("", AppDomain.CurrentDomain.BaseDirectory + "experimental-procedure-0.6.xsd");
                }
                else if (GlobalVariables.ApplicationName == Enums.ApplicationName.NARRATIVES.ToString())
                {
                    schemas = new XmlSchemaSet();
                    schemas.Add("", AppDomain.CurrentDomain.BaseDirectory + "ReactionNarrative-1.8.xsd");

                    // AppDomain.CurrentDomain.BaseDirectory + "CAS_React_Schema.xsd";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnValidate_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtXmlFilesPath.Text.Trim()))
                {
                    string[] saXmlFiles = Directory.GetFiles(txtXmlFilesPath.Text.Trim(), "*.xml");
                    if (saXmlFiles != null && saXmlFiles.Length > 0)
                    {
                        ValidateXmlFiles(saXmlFiles);

                        //ValidateXmlStructure(saXmlFiles);

                        #region MyRegion
                        //schemas = new XmlSchemaSet(); // create the XmlSchemaSet class
                        //// add the schema to the collection
                        //schemas.Add("http://www.deitel.com/booklist", "D:\\Projects\\MyRND in WPF\\MyRND in WPF\\catalog.xsd");
                        //// set the validation settings                      
                        //XmlReaderSettings settings = new XmlReaderSettings();
                        //settings.ValidationType = ValidationType.Schema;
                        //settings.Schemas = schemas;
                        //settings.ValidationEventHandler += ValidationError;
                        //// create the XmlReader object
                        //XmlReader reader =
                        //XmlReader.Create(txtFileName.Text, settings);
                        //// parse the file
                        //while (reader.Read()) ; // empty body
                        //if (valid) // check validation result
                        //{
                        //    txtMessage.Text = "Document is valid";
                        //} // end if
                        //valid = true; // reset variable
                        //reader.Close(); // close reader stream  
                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void ValidateXmlFiles(string[] xmlFiles)
        {
            try
            {     
                DataTable dtValidXml = new DataTable();
                dtValidXml.Columns.Add("TAN");
                dtValidXml.Columns.Add("Status");

                DataTable dtInValidXml = new DataTable();
                dtInValidXml.Columns.Add("TAN");
                dtInValidXml.Columns.Add("Status");
                dtInValidXml.Columns.Add("Error");

                foreach (string xml in xmlFiles)
                {
                    tanName = "";
                    tanName = Path.GetFileNameWithoutExtension(xml);

                    try
                    {
                        XDocument doc = XDocument.Load(xml);
                        string msg = "";
                        doc.Validate(schemas, (o, e) =>
                        {
                            msg += e.Message + Environment.NewLine;
                        });

                        if (msg == "")
                        {
                            DataRow dr = dtValidXml.NewRow();
                            dr["TAN"] = tanName;
                            dr["Status"] = "Valid";
                            dtValidXml.Rows.Add(dr);
                        }
                        else
                        {
                            DataRow dr = dtInValidXml.NewRow();
                            dr["TAN"] = tanName;
                            dr["Status"] = "InValid";
                            dr["Error"] = msg;
                            dtInValidXml.Rows.Add(dr);
                        }
                    }
                    catch( Exception ex1)
                    {
                        DataRow dr = dtInValidXml.NewRow();
                        dr["TAN"] = tanName;
                        dr["Status"] = "InValid";
                        dr["Error"] = ex1.Message;
                        dtInValidXml.Rows.Add(dr);
                    }
                }

                dgvValidXmls.DataSource = dtValidXml;
                dgvInValidXmls.DataSource = dtInValidXml;

                lblValidXmlCnt.Text = dtValidXml.Rows.Count.ToString();
                lblInvalidXmlCnt.Text = dtInValidXml.Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                if (folderBrowserDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    txtXmlFilesPath.Text = folderBrowserDialog1.SelectedPath;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        #region Grid RowPostPaint Events

        private void dgvValidXmls_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvValidXmls.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvValidXmls.Font);

                if (dgvValidXmls.RowHeadersWidth < (int)(size.Width + 20)) dgvValidXmls.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvInValidXmls_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvInValidXmls.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvInValidXmls.Font);

                if (dgvInValidXmls.RowHeadersWidth < (int)(size.Width + 20)) dgvInValidXmls.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        private void ValidateXmlStructure(string[] xmlFiles)
        {
            try
            {
                XDocument xDocument = null;
                XmlReaderSettings xmlReaderSettings = new XmlReaderSettings { CheckCharacters = false  };

                foreach (string xmlfile in xmlFiles)
                {
                    System.Xml.Xsl.XslCompiledTransform xslt = new System.Xml.Xsl.XslCompiledTransform();

                    xslt.Load(xmlfile);

                    //using (XmlReader xmlReader = XmlReader.Create(xmlfile, xmlReaderSettings))
                    //{
                    //    xmlReader.MoveToContent();
                    //    xDocument = XDocument.Load(xmlReader);
                    //}
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        static bool IsValidXmlString(string text)
        {
            try
            {
                XmlConvert.VerifyXmlChars(text);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
