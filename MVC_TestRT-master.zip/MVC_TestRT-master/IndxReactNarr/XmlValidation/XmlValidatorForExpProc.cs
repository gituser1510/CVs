﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using System.IO;

namespace IndxReactNarr.XmlValidation
{
    public class XmlValidatorForExpProc
    {
        // Validation Error Count
        public static int ErrorsCount = 0;

        // Validation Error Message
        public static string ErrorMessage = "";

        public static void ValidationHandler(object sender,
                                             ValidationEventArgs args)
        {
            ErrorMessage = ErrorMessage + args.Message + "\r\n";
            ErrorsCount++;
        }

        public static void Validate(string strXMLDoc, string urlpath)
        {
            try
            {

                // Declare local objects
                XmlTextReader tr = null;
                XmlSchemaCollection xsc = null;
                XmlValidatingReader vr = null;

                // Text reader object
                tr = new XmlTextReader(urlpath);
                xsc = new XmlSchemaCollection();
                xsc.Add(null, tr);

                // XML validator object

                vr = new XmlValidatingReader(strXMLDoc,
                             XmlNodeType.Document, null);

                vr.Schemas.Add(xsc);

                // Add validation event handler

                vr.ValidationType = ValidationType.Schema;
                vr.ValidationEventHandler +=
                         new ValidationEventHandler(ValidationHandler);

                // Validate XML data

                while (vr.Read()) ;

                vr.Close();

                // Raise exception, if XML validation fails
                if (ErrorsCount > 0)
                {
                    throw new Exception(ErrorMessage);
                }

                // XML Validation succeeded
                Console.WriteLine("XML validation succeeded.\r\n");
            }
            catch (Exception error)
            {
                // XML Validation failed
                Console.WriteLine("XML validation failed." + "\r\n" +
                "Error Message: " + error.Message);
            }
        }
        public static string strid = "";
        public static string fieldname = "";
        public static bool validate(string strfilename)
        {
            // 
            // TODO: Add code to start application here.
            // 
            XmlValidatingReader reader = null;
            XmlSchemaCollection myschema = null;
            try
            {
                string xmlFrag = "";
                IXmlLineInfo lineInf = null;
                if (File.Exists(strfilename))
                {
                    myschema = new XmlSchemaCollection();

                    StreamReader sr = new StreamReader(strfilename);
                    xmlFrag = sr.ReadToEnd();
                    sr.Close();

                    XmlParserContext context = new XmlParserContext(null, null, "", XmlSpace.None);

                    reader = new XmlValidatingReader(xmlFrag, XmlNodeType.Element, context);
                    reader.ValidationEventHandler += new ValidationEventHandler(ValidationHandler);

                    //myschema.Add(null, AppDomain.CurrentDomain.BaseDirectory + "ReactionNarrative-1.8.xsd");// "ReactionNarrative-1.6.xsd");
                    myschema.Add(null, AppDomain.CurrentDomain.BaseDirectory + "experimental-procedure-0.4.xsd");
                    reader.ValidationType = ValidationType.Schema;
                    reader.Schemas.Add(myschema);

                    while (reader.Read())
                    {
                        if (reader.Reader.Name.ToString().Contains("narrative"))
                        {
                            if (reader.GetAttribute("id") != null)
                            {
                                strid = reader.GetAttribute("id");
                            }


                        }
                        //if (reader.Value != null && reader.Value.ToString() != "")
                        //{
                        //    fieldname = reader..ToString();
                        //}


                    }
                    if (ErrorsCount > 0)
                        return false;
                    else
                        return true;

                }
            }
            catch (XmlException ex)
            {
                ErrorMessage = ex.ToString();

            }
            finally
            {
                Console.Read();
            }
            return false;

        }

        public static bool validate(StringBuilder strfilecontent)
        {
            // 
            // TODO: Add code to start application here.
            // 
            XmlValidatingReader reader = null;
            XmlSchemaCollection myschema = null;
            try
            {
                string xmlFrag = strfilecontent.ToString();
                //if (File.Exists(strfilename))
                //{
                myschema = new XmlSchemaCollection();



                XmlParserContext context = new XmlParserContext(null, null, "", XmlSpace.None);

                reader = new XmlValidatingReader(xmlFrag, XmlNodeType.Element, context);
                reader.ValidationEventHandler +=
                       new ValidationEventHandler(ValidationHandler);
                myschema.Add(null, AppDomain.CurrentDomain.BaseDirectory + "experimental-procedure-0.4.xsd");
                reader.ValidationType = ValidationType.Schema;
                reader.Schemas.Add(myschema);

                while (reader.Read())
                {



                }

                if (ErrorsCount > 0)
                    return false;
                else
                    return true;

                // }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                Console.Read();
            }
            return false;

        }

        public static string ShowCompileErrors(object sender, ValidationEventArgs args)
        {
            ErrorsCount++;
            return args.Message.ToString();

        }
    }
}
