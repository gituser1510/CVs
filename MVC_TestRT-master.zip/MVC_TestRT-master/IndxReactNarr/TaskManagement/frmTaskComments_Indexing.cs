﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using System.IO;
using IndxReactNarr.Common;
using IndxReactNarrDAL;
using System.Text.RegularExpressions;
using System.Collections;

namespace IndxReactNarr.TaskManagement
{
    public partial class frmTaskComments_Indexing : Form
    {
        public frmTaskComments_Indexing()
        {
            InitializeComponent();
        }

        public int TAN_ID { get; set; }
        public string TAN_Name { get; set; }
        public DataTable TAN_Reactions { get; set; }

        public string TaskName { get; set; }

        private void frmTaskComments_Indexing_Load(object sender, EventArgs e)
        {
            try
            {             
                GetTanParsAndBindToGrid(TAN_ID);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetTanParsAndBindToGrid(int tanID)
        {
            try
            {
                if (tanID > 0)
                {
                    DataTable dtTANPARs = OrganicIndexingDB.GetIndexingNUMsOnTANID(tanID, "NUM_PAR");
                    if (dtTANPARs != null && dtTANPARs.Rows.Count > 0)
                    {
                        //For DPT RS NUMs are not markuped in PDF
                        DataView dvTemp = dtTANPARs.DefaultView;
                        dvTemp.RowFilter = "DPT_RS = 'N'";
                        dtTANPARs = dvTemp.ToTable();

                        dgvTANNUMs.AutoGenerateColumns = false;
                        colNUM_TN.DataPropertyName = "NUM";
                        colPAR_TN.DataPropertyName = "PAR";
                        dgvTANNUMs.DataSource = dtTANPARs;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                string errMsg = "";

                if (ValidateUserInputs(out errMsg))
                {
                    if (TaskName == "TASK COMPLETE")
                    {
                        string pdfName = Path.GetFileName(txtIndexingMarkUpPdfPath.Text);
                        string serverPath = System.Configuration.ConfigurationSettings.AppSettings["FileServerPath"].ToString() + "\\cas_app_files\\IRN";
                        string strFileServerPath = serverPath + "\\" + GlobalVariables.ApplicationName + "\\" + GlobalVariables.ShipmentName;

                        //Upload Pdf to Server
                        if (Download_UploadPdf.UploadFileToWindowsServer(txtIndexingMarkUpPdfPath.Text, strFileServerPath, pdfName, out errMsg))
                        {
                            DialogResult = System.Windows.Forms.DialogResult.OK;
                        }
                        else
                        {
                            MessageBox.Show(errMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else//Task Reject
                    {
                        DialogResult = System.Windows.Forms.DialogResult.OK;
                    }
                }
                else
                {
                    MessageBox.Show(errMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnBrowsePDF_Click(object sender, EventArgs e)
        {
            try
            {
                string errMsg = "";
                openFileDialog1.Filter = "PDF files (*.pdf)|*.pdf";
                if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    txtIndexingMarkUpPdfPath.Text = openFileDialog1.FileName;
                    if (CheckPdfNameandTanMatch(openFileDialog1.FileName, TAN_Name, out errMsg) && errMsg == "")
                    {
                        //Get Markup Reactions from Pdf
                        DataTable dtMarkupNUMs = GetUniqueMarkUpNUMs();
                        dgvMarkupNUMs.AutoGenerateColumns = false;

                        colNUM_MN.DataPropertyName = "NUM";
                        colRole_MN.DataPropertyName = "ROLE";
                        dgvMarkupNUMs.DataSource = dtMarkupNUMs;

                        lblMarkupNumsCnt.Text = dtMarkupNUMs.Rows.Count.ToString();
                    }
                    else
                    {
                        MessageBox.Show(errMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private DataTable GetUniqueMarkUpNUMs()
        {
            DataTable dtMarkupNUMS = null;

            try
            {
                DataTable tempNums = MarkUpsValidation_IText.GetMarkUpIndexingNUMs(txtIndexingMarkUpPdfPath.Text);

                //Split NUms like 2-RCT 3-PRO
                tempNums = SplitMarkUpNUMsData(tempNums);

                //DataTable dtDistinct = new DataTable();
                //dtDistinct.Columns.Add("NUM");
                //dtDistinct.Columns.Add("ROLE");

                //var DistinctRows = ((from DataRow dr in tempNums.Rows
                //                     select (string)dr["NUM"]).Distinct());

                //foreach (var Row in DistinctRows)
                //{
                //    dtDistinct.Rows.Add(Row);
                //}

                //DataView dvDistinct = dtDistinct.DefaultView;
                //dvDistinct.RowFilter = "NUM NOT IN('" + String.Empty + "')";

                //DataTable dtDistinctNew = dvDistinct.ToTable();

                //convert datatype of datatable from string to int32 

                dtMarkupNUMS = tempNums.Clone();
                dtMarkupNUMS.Columns[0].DataType = typeof(string);

                foreach (DataRow dr in tempNums.Rows)
                {
                    dtMarkupNUMS.ImportRow(dr);
                }
                DataView dvnew = dtMarkupNUMS.DefaultView;
                dvnew.Sort = "NUM";

                dtMarkupNUMS = dvnew.ToTable();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtMarkupNUMS;
        }

        private DataTable SplitMarkUpNUMsData(DataTable markUpNums)
        {
            DataTable dtSplitNums = null;
            try
            {
                if (markUpNums != null && markUpNums.Rows.Count > 0)
                {
                    dtSplitNums = new DataTable();
                    dtSplitNums.Columns.Add("NUM");
                    dtSplitNums.Columns.Add("ROLE");

                    foreach (DataRow dRow in markUpNums.Rows)
                    {
                        if (dRow["NUM"] != null)
                        {
                            //Split NUms like 2-RCT 3-PRO
                            string[] saNUMs = dRow["NUM"].ToString().Trim().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                            if (saNUMs != null && saNUMs.Length > 0)
                            {
                                foreach (string num in saNUMs)
                                {
                                    string[] saVals = num.Trim().Split(new string[] { "-" }, StringSplitOptions.RemoveEmptyEntries);
                                    if (saVals != null && saVals.Length > 0)
                                    {
                                        DataRow dr = dtSplitNums.NewRow();

                                        dr["NUM"] = saVals[0].Trim();
                                        dr["ROLE"] = saVals.Length == 2 ? saVals[1].Trim() : "";
                                        dtSplitNums.Rows.Add(dr);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtSplitNums;
        }

        private bool CheckPdfNameandTanMatch(string path, string tanName, out string errMsg)
        {
            bool blStatus = true;
            string strErrMsg = "";
            string Pdf_Filename = "";

            try
            {
                string pdfName = !string.IsNullOrEmpty(path) ? Path.GetFileNameWithoutExtension(path) : "";
                string[] saPdfNames = pdfName.Trim().Split(new string[] { ".", "_", "-" }, StringSplitOptions.RemoveEmptyEntries);
                if (saPdfNames != null && saPdfNames.Length > 0)
                {
                    Pdf_Filename = saPdfNames[0].Trim();
                }

                //string[] lines = Regex.Split(pdfName, "_");
                //Pdf_Filename = lines[0];

                if (string.IsNullOrEmpty(pdfName) && string.IsNullOrEmpty(Pdf_Filename))
                {
                    blStatus = false;
                    strErrMsg = "Markup Pdf is mandatory";
                }
                else if (Pdf_Filename.ToUpper() != tanName.ToUpper())
                {
                    blStatus = false;
                    strErrMsg = "Pdf name should match with TAN";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsg = strErrMsg.Trim();
            return blStatus;
        }

        private bool ValidateUserInputs(out string errMsg)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {

                if (string.IsNullOrEmpty(txtIndexingTaskComments.Text))
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + "\r\n" + "Task Comments are mandatory";
                }

                if (string.IsNullOrEmpty(txtIndexingMarkUpPdfPath.Text) && TaskName == "TASK COMPLETE")
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + "\r\n" + "Markup Pdf file is mandatory";
                }
                else
                {
                    if (GlobalVariables.ApplicationName == Enums.ApplicationName.ORGANIC.ToString() ||
                        GlobalVariables.ApplicationName == Enums.ApplicationName.MACRO.ToString())
                    {
                        string MissedAndExcessNUMS = GetMissedAndExcessNums();

                        if (!string.IsNullOrEmpty(MissedAndExcessNUMS))
                        {
                            blStatus = false;
                            strErrMsg = MissedAndExcessNUMS.Trim();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsg = strErrMsg.Trim();
            return blStatus;
        }

        private string GetMissedAndExcessNums()
        {
            string strMissed_ExcessNums = string.Empty;
            try
            {

                string ExcessNum = string.Empty;
                string MissedNum = string.Empty;

                DataTable IndexingNUMs = dgvTANNUMs.DataSource != null ? (DataTable)dgvTANNUMs.DataSource : null;
                DataTable MarkUpNUMs = dgvMarkupNUMs.DataSource != null ? (DataTable)dgvMarkupNUMs.DataSource : null;

                if (IndexingNUMs != null && IndexingNUMs.Rows.Count > 0)
                {
                    List<int> liIndexingNUMs = ConvertNUMsTableToList(IndexingNUMs);
                    List<int> liMarkUpNUMs = ConvertNUMsTableToList(MarkUpNUMs);

                    List<int> liExcessNums = (liIndexingNUMs.Except(liMarkUpNUMs)).ToList<int>();
                    List<int> liMissedNums = (liMarkUpNUMs.Except(liIndexingNUMs)).ToList<int>();

                    var MissedNums = liMissedNums.Select(i => i.ToString()).ToArray();
                    MissedNum = string.Join(",", MissedNums);
                    MissedNum = MissedNum.TrimEnd(new char[] { ',' });

                    var ExcessNums = liExcessNums.Select(i => i.ToString()).ToArray();
                    ExcessNum = string.Join(",", ExcessNums);
                    ExcessNum = ExcessNum.TrimEnd(new char[] { ',' });

                    if (!string.IsNullOrEmpty(ExcessNum))
                    {
                        strMissed_ExcessNums += " Excess NUMs in TAN when compared to NUMS in Markup pdf:" + ExcessNum + "\n";
                    }

                    if (!string.IsNullOrEmpty(MissedNum))
                    {
                        strMissed_ExcessNums += " Missed NUMs in TAN when compared to NUMS in Markup Pdf :" + MissedNum + "\n";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strMissed_ExcessNums.Trim();
        }

        private List<int> ConvertNUMsTableToList(DataTable dt)
        {
            List<int> li = new List<int>();
            try
            {
                if (dt != null && dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        if (!li.Contains(Convert.ToInt32(dt.Rows[i]["NUM"])))
                        {
                            li.Add(Convert.ToInt32(dt.Rows[i]["NUM"]));
                        }
                    }
                }               
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return li;
        }

        #region Grid RowPostPaint Events

        private void dgvMarkupNUMs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvMarkupNUMs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;
                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvMarkupNUMs.Font);
                if (dgvMarkupNUMs.RowHeadersWidth < (int)(size.Width + 20)) dgvMarkupNUMs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;

                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvTANNUMs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvTANNUMs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;
                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvTANNUMs.Font);
                if (dgvTANNUMs.RowHeadersWidth < (int)(size.Width + 20)) dgvTANNUMs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;

                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

    }
}
