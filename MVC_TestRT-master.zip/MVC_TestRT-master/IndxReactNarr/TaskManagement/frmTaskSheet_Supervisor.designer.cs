﻿namespace CASRxnTool.TaskManagement
{
    partial class frmTaskSheet_Supervisor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvAssignTANs = new System.Windows.Forms.DataGridView();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.pnlCntrls_Top = new System.Windows.Forms.Panel();
            this.txtBName_Qry = new System.Windows.Forms.TextBox();
            this.btnGet = new System.Windows.Forms.Button();
            this.txtBNo_Qry = new System.Windows.Forms.TextBox();
            this.lblBName_Qry = new System.Windows.Forms.Label();
            this.lblBNo_Qry = new System.Windows.Forms.Label();
            this.lblAssToRole = new System.Windows.Forms.Label();
            this.txtAssignToRole = new System.Windows.Forms.TextBox();
            this.lblAssTo = new System.Windows.Forms.Label();
            this.txtAssignTo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAssignbyRole = new System.Windows.Forms.TextBox();
            this.lblAssignBy = new System.Windows.Forms.Label();
            this.txtAssignBy = new System.Windows.Forms.TextBox();
            this.lblTanStatus = new System.Windows.Forms.Label();
            this.txtTanStatus = new System.Windows.Forms.TextBox();
            this.lblTAN = new System.Windows.Forms.Label();
            this.txtTANSrch = new System.Windows.Forms.TextBox();
            this.BT_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tan = new System.Windows.Forms.DataGridViewLinkColumn();
            this.colDocClass = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPriority = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDownLoad = new System.Windows.Forms.DataGridViewLinkColumn();
            this.colGetNUMs = new System.Windows.Forms.DataGridViewLinkColumn();
            this.BName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TAN_Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AssByUser = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AssByRole = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AssToUser = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AssToRole = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Manager = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Manager_Ur_Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Analyst_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAssignTANs)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.pnlCntrls_Top.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.dgvAssignTANs);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1161, 576);
            this.pnlMain.TabIndex = 0;
            // 
            // dgvAssignTANs
            // 
            this.dgvAssignTANs.AllowUserToAddRows = false;
            this.dgvAssignTANs.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.dgvAssignTANs.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvAssignTANs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAssignTANs.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvAssignTANs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAssignTANs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.BT_ID,
            this.tan,
            this.colDocClass,
            this.colPriority,
            this.colDownLoad,
            this.colGetNUMs,
            this.BName,
            this.BNo,
            this.TAN_Status,
            this.AssByUser,
            this.AssByRole,
            this.AssToUser,
            this.AssToRole,
            this.Manager,
            this.Manager_Ur_Id,
            this.Analyst_ID});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.GrayText;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvAssignTANs.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvAssignTANs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAssignTANs.Location = new System.Drawing.Point(0, 103);
            this.dgvAssignTANs.MultiSelect = false;
            this.dgvAssignTANs.Name = "dgvAssignTANs";
            this.dgvAssignTANs.ReadOnly = true;
            this.dgvAssignTANs.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dgvAssignTANs.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvAssignTANs.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvAssignTANs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAssignTANs.Size = new System.Drawing.Size(1161, 473);
            this.dgvAssignTANs.TabIndex = 13;
            this.dgvAssignTANs.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvAssignTANs_RowPostPaint);
            this.dgvAssignTANs.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAssignTANs_CellContentClick);
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.pnlCntrls_Top);
            this.pnlTop.Controls.Add(this.lblAssToRole);
            this.pnlTop.Controls.Add(this.txtAssignToRole);
            this.pnlTop.Controls.Add(this.lblAssTo);
            this.pnlTop.Controls.Add(this.txtAssignTo);
            this.pnlTop.Controls.Add(this.label1);
            this.pnlTop.Controls.Add(this.txtAssignbyRole);
            this.pnlTop.Controls.Add(this.lblAssignBy);
            this.pnlTop.Controls.Add(this.txtAssignBy);
            this.pnlTop.Controls.Add(this.lblTanStatus);
            this.pnlTop.Controls.Add(this.txtTanStatus);
            this.pnlTop.Controls.Add(this.lblTAN);
            this.pnlTop.Controls.Add(this.txtTANSrch);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1161, 103);
            this.pnlTop.TabIndex = 12;
            // 
            // pnlCntrls_Top
            // 
            this.pnlCntrls_Top.BackColor = System.Drawing.Color.White;
            this.pnlCntrls_Top.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlCntrls_Top.Controls.Add(this.txtBName_Qry);
            this.pnlCntrls_Top.Controls.Add(this.btnGet);
            this.pnlCntrls_Top.Controls.Add(this.txtBNo_Qry);
            this.pnlCntrls_Top.Controls.Add(this.lblBName_Qry);
            this.pnlCntrls_Top.Controls.Add(this.lblBNo_Qry);
            this.pnlCntrls_Top.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCntrls_Top.Location = new System.Drawing.Point(0, 0);
            this.pnlCntrls_Top.Name = "pnlCntrls_Top";
            this.pnlCntrls_Top.Size = new System.Drawing.Size(1159, 38);
            this.pnlCntrls_Top.TabIndex = 31;
            // 
            // txtBName_Qry
            // 
            this.txtBName_Qry.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBName_Qry.ForeColor = System.Drawing.Color.Blue;
            this.txtBName_Qry.Location = new System.Drawing.Point(87, 5);
            this.txtBName_Qry.Name = "txtBName_Qry";
            this.txtBName_Qry.Size = new System.Drawing.Size(131, 25);
            this.txtBName_Qry.TabIndex = 26;
            this.txtBName_Qry.Text = "rxnfile.8000";
            // 
            // btnGet
            // 
            this.btnGet.Location = new System.Drawing.Point(355, 5);
            this.btnGet.Name = "btnGet";
            this.btnGet.Size = new System.Drawing.Size(75, 26);
            this.btnGet.TabIndex = 30;
            this.btnGet.Text = "Get";
            this.btnGet.UseVisualStyleBackColor = true;
            this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
            // 
            // txtBNo_Qry
            // 
            this.txtBNo_Qry.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBNo_Qry.ForeColor = System.Drawing.Color.Blue;
            this.txtBNo_Qry.Location = new System.Drawing.Point(298, 5);
            this.txtBNo_Qry.Name = "txtBNo_Qry";
            this.txtBNo_Qry.Size = new System.Drawing.Size(38, 25);
            this.txtBNo_Qry.TabIndex = 28;
            this.txtBNo_Qry.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblBName_Qry
            // 
            this.lblBName_Qry.AutoSize = true;
            this.lblBName_Qry.Location = new System.Drawing.Point(2, 9);
            this.lblBName_Qry.Name = "lblBName_Qry";
            this.lblBName_Qry.Size = new System.Drawing.Size(83, 17);
            this.lblBName_Qry.TabIndex = 27;
            this.lblBName_Qry.Text = "Batch Name";
            // 
            // lblBNo_Qry
            // 
            this.lblBNo_Qry.AutoSize = true;
            this.lblBNo_Qry.Location = new System.Drawing.Point(226, 9);
            this.lblBNo_Qry.Name = "lblBNo_Qry";
            this.lblBNo_Qry.Size = new System.Drawing.Size(69, 17);
            this.lblBNo_Qry.TabIndex = 29;
            this.lblBNo_Qry.Text = "Batch No.";
            // 
            // lblAssToRole
            // 
            this.lblAssToRole.AutoSize = true;
            this.lblAssToRole.Location = new System.Drawing.Point(730, 75);
            this.lblAssToRole.Name = "lblAssToRole";
            this.lblAssToRole.Size = new System.Drawing.Size(113, 17);
            this.lblAssToRole.TabIndex = 25;
            this.lblAssToRole.Text = "Assigned To Role";
            // 
            // txtAssignToRole
            // 
            this.txtAssignToRole.Location = new System.Drawing.Point(846, 71);
            this.txtAssignToRole.Name = "txtAssignToRole";
            this.txtAssignToRole.Size = new System.Drawing.Size(124, 25);
            this.txtAssignToRole.TabIndex = 24;
            this.txtAssignToRole.TextChanged += new System.EventHandler(this.txtAssignToRole_TextChanged);
            // 
            // lblAssTo
            // 
            this.lblAssTo.AutoSize = true;
            this.lblAssTo.Location = new System.Drawing.Point(435, 76);
            this.lblAssTo.Name = "lblAssTo";
            this.lblAssTo.Size = new System.Drawing.Size(82, 17);
            this.lblAssTo.TabIndex = 23;
            this.lblAssTo.Text = "Assigned To";
            // 
            // txtAssignTo
            // 
            this.txtAssignTo.Location = new System.Drawing.Point(520, 71);
            this.txtAssignTo.Name = "txtAssignTo";
            this.txtAssignTo.Size = new System.Drawing.Size(204, 25);
            this.txtAssignTo.TabIndex = 22;
            this.txtAssignTo.TextChanged += new System.EventHandler(this.txtAssignTo_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(732, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 17);
            this.label1.TabIndex = 21;
            this.label1.Text = "Assigned by Role";
            // 
            // txtAssignbyRole
            // 
            this.txtAssignbyRole.Location = new System.Drawing.Point(846, 42);
            this.txtAssignbyRole.Name = "txtAssignbyRole";
            this.txtAssignbyRole.Size = new System.Drawing.Size(124, 25);
            this.txtAssignbyRole.TabIndex = 20;
            this.txtAssignbyRole.TextChanged += new System.EventHandler(this.txtAssignbyRole_TextChanged);
            // 
            // lblAssignBy
            // 
            this.lblAssignBy.AutoSize = true;
            this.lblAssignBy.Location = new System.Drawing.Point(434, 46);
            this.lblAssignBy.Name = "lblAssignBy";
            this.lblAssignBy.Size = new System.Drawing.Size(83, 17);
            this.lblAssignBy.TabIndex = 19;
            this.lblAssignBy.Text = "Assigned By";
            // 
            // txtAssignBy
            // 
            this.txtAssignBy.Location = new System.Drawing.Point(520, 42);
            this.txtAssignBy.Name = "txtAssignBy";
            this.txtAssignBy.Size = new System.Drawing.Size(204, 25);
            this.txtAssignBy.TabIndex = 18;
            this.txtAssignBy.TextChanged += new System.EventHandler(this.txtAssignBy_TextChanged);
            // 
            // lblTanStatus
            // 
            this.lblTanStatus.AutoSize = true;
            this.lblTanStatus.Location = new System.Drawing.Point(4, 75);
            this.lblTanStatus.Name = "lblTanStatus";
            this.lblTanStatus.Size = new System.Drawing.Size(44, 17);
            this.lblTanStatus.TabIndex = 17;
            this.lblTanStatus.Text = "Status";
            // 
            // txtTanStatus
            // 
            this.txtTanStatus.Location = new System.Drawing.Point(49, 71);
            this.txtTanStatus.Name = "txtTanStatus";
            this.txtTanStatus.Size = new System.Drawing.Size(379, 25);
            this.txtTanStatus.TabIndex = 16;
            this.txtTanStatus.TextChanged += new System.EventHandler(this.txtTanStatus_TextChanged);
            // 
            // lblTAN
            // 
            this.lblTAN.AutoSize = true;
            this.lblTAN.Location = new System.Drawing.Point(4, 45);
            this.lblTAN.Name = "lblTAN";
            this.lblTAN.Size = new System.Drawing.Size(39, 17);
            this.lblTAN.TabIndex = 11;
            this.lblTAN.Text = "TAN";
            // 
            // txtTANSrch
            // 
            this.txtTANSrch.Location = new System.Drawing.Point(49, 42);
            this.txtTANSrch.Name = "txtTANSrch";
            this.txtTANSrch.Size = new System.Drawing.Size(379, 25);
            this.txtTANSrch.TabIndex = 8;
            this.txtTANSrch.TextChanged += new System.EventHandler(this.txtTAN_TextChanged);
            // 
            // BT_ID
            // 
            this.BT_ID.HeaderText = "BTID";
            this.BT_ID.Name = "BT_ID";
            this.BT_ID.ReadOnly = true;
            this.BT_ID.Visible = false;
            // 
            // tan
            // 
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tan.DefaultCellStyle = dataGridViewCellStyle2;
            this.tan.FillWeight = 80F;
            this.tan.HeaderText = "TAN";
            this.tan.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.tan.Name = "tan";
            this.tan.ReadOnly = true;
            this.tan.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.tan.Text = "";
            this.tan.TrackVisitedState = false;
            // 
            // colDocClass
            // 
            this.colDocClass.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colDocClass.HeaderText = "Doc Class";
            this.colDocClass.Name = "colDocClass";
            this.colDocClass.ReadOnly = true;
            this.colDocClass.Width = 50;
            // 
            // colPriority
            // 
            this.colPriority.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colPriority.HeaderText = "Priority";
            this.colPriority.Name = "colPriority";
            this.colPriority.ReadOnly = true;
            this.colPriority.Width = 40;
            // 
            // colDownLoad
            // 
            this.colDownLoad.FillWeight = 50F;
            this.colDownLoad.HeaderText = "View";
            this.colDownLoad.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.colDownLoad.Name = "colDownLoad";
            this.colDownLoad.ReadOnly = true;
            this.colDownLoad.Text = "PDF";
            this.colDownLoad.TrackVisitedState = false;
            this.colDownLoad.UseColumnTextForLinkValue = true;
            // 
            // colGetNUMs
            // 
            this.colGetNUMs.FillWeight = 50F;
            this.colGetNUMs.HeaderText = "NUMs";
            this.colGetNUMs.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.colGetNUMs.Name = "colGetNUMs";
            this.colGetNUMs.ReadOnly = true;
            this.colGetNUMs.Text = "NUMs";
            this.colGetNUMs.UseColumnTextForLinkValue = true;
            // 
            // BName
            // 
            this.BName.HeaderText = "Batch Name";
            this.BName.Name = "BName";
            this.BName.ReadOnly = true;
            // 
            // BNo
            // 
            this.BNo.FillWeight = 30F;
            this.BNo.HeaderText = "B.No";
            this.BNo.Name = "BNo";
            this.BNo.ReadOnly = true;
            // 
            // TAN_Status
            // 
            this.TAN_Status.HeaderText = "TAN Status";
            this.TAN_Status.Name = "TAN_Status";
            this.TAN_Status.ReadOnly = true;
            // 
            // AssByUser
            // 
            this.AssByUser.HeaderText = "Assigned By User";
            this.AssByUser.Name = "AssByUser";
            this.AssByUser.ReadOnly = true;
            // 
            // AssByRole
            // 
            this.AssByRole.HeaderText = "Assigned By Role";
            this.AssByRole.Name = "AssByRole";
            this.AssByRole.ReadOnly = true;
            // 
            // AssToUser
            // 
            this.AssToUser.HeaderText = "Assigned To User";
            this.AssToUser.Name = "AssToUser";
            this.AssToUser.ReadOnly = true;
            // 
            // AssToRole
            // 
            this.AssToRole.HeaderText = "Assigned To Role";
            this.AssToRole.Name = "AssToRole";
            this.AssToRole.ReadOnly = true;
            // 
            // Manager
            // 
            this.Manager.HeaderText = "Manager";
            this.Manager.Name = "Manager";
            this.Manager.ReadOnly = true;
            this.Manager.Visible = false;
            // 
            // Manager_Ur_Id
            // 
            this.Manager_Ur_Id.HeaderText = "Manager_Ur_Id";
            this.Manager_Ur_Id.Name = "Manager_Ur_Id";
            this.Manager_Ur_Id.ReadOnly = true;
            this.Manager_Ur_Id.Visible = false;
            // 
            // Analyst_ID
            // 
            this.Analyst_ID.HeaderText = "Analyst_ID";
            this.Analyst_ID.Name = "Analyst_ID";
            this.Analyst_ID.ReadOnly = true;
            this.Analyst_ID.Visible = false;
            // 
            // frmTaskSheet_Supervisor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1161, 576);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmTaskSheet_Supervisor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Task Sheet";
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAssignTANs)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlCntrls_Top.ResumeLayout(false);
            this.pnlCntrls_Top.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Label lblAssToRole;
        private System.Windows.Forms.TextBox txtAssignToRole;
        private System.Windows.Forms.Label lblAssTo;
        private System.Windows.Forms.TextBox txtAssignTo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAssignbyRole;
        private System.Windows.Forms.Label lblAssignBy;
        private System.Windows.Forms.TextBox txtAssignBy;
        private System.Windows.Forms.Label lblTanStatus;
        private System.Windows.Forms.TextBox txtTanStatus;
        private System.Windows.Forms.Label lblTAN;
        private System.Windows.Forms.TextBox txtTANSrch;
        private System.Windows.Forms.DataGridView dgvAssignTANs;
        private System.Windows.Forms.Panel pnlCntrls_Top;
        private System.Windows.Forms.TextBox txtBName_Qry;
        private System.Windows.Forms.Button btnGet;
        private System.Windows.Forms.TextBox txtBNo_Qry;
        private System.Windows.Forms.Label lblBName_Qry;
        private System.Windows.Forms.Label lblBNo_Qry;
        private System.Windows.Forms.DataGridViewTextBoxColumn BT_ID;
        private System.Windows.Forms.DataGridViewLinkColumn tan;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDocClass;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPriority;
        private System.Windows.Forms.DataGridViewLinkColumn colDownLoad;
        private System.Windows.Forms.DataGridViewLinkColumn colGetNUMs;
        private System.Windows.Forms.DataGridViewTextBoxColumn BName;
        private System.Windows.Forms.DataGridViewTextBoxColumn BNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn TAN_Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn AssByUser;
        private System.Windows.Forms.DataGridViewTextBoxColumn AssByRole;
        private System.Windows.Forms.DataGridViewTextBoxColumn AssToUser;
        private System.Windows.Forms.DataGridViewTextBoxColumn AssToRole;
        private System.Windows.Forms.DataGridViewTextBoxColumn Manager;
        private System.Windows.Forms.DataGridViewTextBoxColumn Manager_Ur_Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn Analyst_ID;
    }
}