﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using IndxReactNarr.Common;
using System.IO;
using IndxReactNarrDAL;
using System.Text.RegularExpressions;
using IndxReactNarrBll;

namespace IndxReactNarr.TaskManagement
{
    public partial class frmTaskComments : Form
    {
        public frmTaskComments()
        {
            InitializeComponent();
        }

        public int TAN_ID { get; set; }
        public string TAN_Name { get; set; }
        public DataTable TAN_Reactions { get; set; }

        public string TaskName { get; set; }

        private void frmTaskComments_Load(object sender, EventArgs e)
        {
            try
            {
                if (GlobalVariables.ApplicationName == Enums.ApplicationName.NARRATIVES.ToString() ||
                    GlobalVariables.ApplicationName == Enums.ApplicationName.EXPPROCEDURES.ToString())
                {
                    txtMarkUpPdfPath.Enabled = false;
                    btnBrowsePdf.Enabled = false;
                }
                else//REACT/Macro/Organic Indexing
                {
                    if (TaskName == "TASK REJECT")
                    {
                        txtMarkUpPdfPath.Enabled = false;
                        btnBrowsePdf.Enabled = false;
                    }

                    //Get TAN Reactions from DB
                    dtTANRxns = ReactDB.GetRxnNumSeqOnTanID(TAN_ID);
                    BindTANReactionsToGrid(dtTANRxns);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                string errMsg = "";
                if (ValidateUserInputs(out errMsg))
                {
                    if (!string.IsNullOrEmpty(txtMarkUpPdfPath.Text.Trim()))
                    {
                        string pdfName = Path.GetFileName(txtMarkUpPdfPath.Text);
                        string serverPath = System.Configuration.ConfigurationSettings.AppSettings["FileServerPath"].ToString() + "\\cas_app_files\\IRN";
                        string strFileServerPath = serverPath + "\\" + GlobalVariables.ApplicationName + "\\" + GlobalVariables.ShipmentName;

                        //Upload Pdf to Server
                        if (Download_UploadPdf.UploadFileToWindowsServer(txtMarkUpPdfPath.Text, strFileServerPath, pdfName, out errMsg))
                        {
                            MessageBox.Show("Markup Pdf uploaded to server sucesssfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            DialogResult = System.Windows.Forms.DialogResult.OK;

                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show(errMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else //For Experimental Procedures & Narratives, Markup is not required. 
                    {
                        DialogResult = System.Windows.Forms.DialogResult.OK;
                    }
                }
                else
                {
                    MessageBox.Show(errMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        DataTable dtTANRxns = null;
        DataTable dtMarkupRxns = null;

        private void btnBrowsePdf_Click(object sender, EventArgs e)
        {
            try
            {
                openFileDialog1.Filter = "PDF files (*.pdf)|*.pdf";
                if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    txtMarkUpPdfPath.Text = openFileDialog1.FileName;
                    string errMsg = "";
                    if (CheckPdfNameandTanMatch(openFileDialog1.FileName, TAN_Name, out errMsg) && errMsg == "")
                    {
                        #region MyRegion
                        ////Get TAN Reactions from DB
                        //dtTANRxns = ReactDB.GetRxnNumSeqOnTanID(TAN_ID);

                        //if (dtTANRxns != null && dtTANRxns.Rows.Count > 0)
                        //{
                        //    DataView dvTemp = dtTANRxns.DefaultView;
                        //    dvTemp.Sort = "RXN_NUM , RXN_SEQ ASC";//"DISPLAY_ORDER ASC";//
                        //    dtMarkupRxns = dvTemp.ToTable();
                        //}


                        //dgvTAN.AutoGenerateColumns = false;
                        //dgvTAN.DataSource = dtTANRxns;
                        //dgvTAN.AutoGenerateColumns = false;
                        //colDisplayOrder.DataPropertyName = "DISPLAY_ORDER";
                        //colRxnNUM_TR.DataPropertyName = "RXN_NUM";
                        //colRxnSeq_TR.DataPropertyName = "RXN_SEQ";

                        //lblTANRxnsCnt.Text = dtTANRxns.Rows.Count.ToString(); 
                        #endregion

                        if (!string.IsNullOrEmpty(txtMarkUpPdfPath.Text.Trim()))
                        {
                            //Get Markup Reactions from Pdf
                            bool blPdfReadStatus = false;
                            string pdfAuthorName = "";

                            dtMarkupRxns = MarkUpsValidation_IText.GetMarkUpReactionsNumSeqs(txtMarkUpPdfPath.Text, out blPdfReadStatus, out pdfAuthorName);
                            if (blPdfReadStatus)
                            {
                                //Show pdf author name - 5th Apr 2016
                                lblAuthorName.Text = pdfAuthorName;

                                BindMarkUpReactionsToGrid(dtMarkupRxns);

                                //if (dtMarkupRxns != null && dtMarkupRxns.Rows.Count > 0)
                                //{
                                //    DataView dvTemp = dtMarkupRxns.DefaultView;
                                //    dvTemp.Sort = "RXN_NUM , RXN_SEQ ASC";
                                //    dtMarkupRxns = dvTemp.ToTable();

                                //    lblMarkupRxnsCnt.Text = dtMarkupRxns.Rows.Count.ToString();

                                //    dgvMarkup.AutoGenerateColumns = false;
                                //    dgvMarkup.DataSource = dtMarkupRxns;
                                //    dgvMarkup.AutoGenerateColumns = false;
                                //    colRxnNUM_MR.DataPropertyName = "RXN_NUM";
                                //    colRxnSeq_MR.DataPropertyName = "RXN_SEQ";
                                //}                               
                            }
                            else
                            {
                                MessageBox.Show("Error in reading the Pdf file.", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }                            
                        }
                    }
                    else
                    {
                        MessageBox.Show(errMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtMarkUpPdfPath.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindTANReactionsToGrid(DataTable tanReactions)
        {
            try
            {
                if (tanReactions != null && tanReactions.Rows.Count > 0)
                {
                    DataView dvTemp = tanReactions.DefaultView;
                    dvTemp.Sort = "RXN_NUM , RXN_SEQ ASC";//"DISPLAY_ORDER ASC";//
                    dtMarkupRxns = dvTemp.ToTable();
                    
                    dgvTAN.AutoGenerateColumns = false;
                    dgvTAN.DataSource = tanReactions;
                    dgvTAN.AutoGenerateColumns = false;
                    colDisplayOrder.DataPropertyName = "DISPLAY_ORDER";
                    colRxnNUM_TR.DataPropertyName = "RXN_NUM";
                    colRxnSeq_TR.DataPropertyName = "RXN_SEQ";

                    lblTANRxnsCnt.Text = tanReactions.Rows.Count.ToString();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindMarkUpReactionsToGrid(DataTable markupReactions)
        {
            try
            {
                if (markupReactions != null && markupReactions.Rows.Count > 0)
                {
                    DataView dvTemp = markupReactions.DefaultView;
                    dvTemp.Sort = "RXN_NUM , RXN_SEQ ASC";
                    dtMarkupRxns = dvTemp.ToTable();

                    lblMarkupRxnsCnt.Text = markupReactions.Rows.Count.ToString();

                    dgvMarkup.AutoGenerateColumns = false;
                    dgvMarkup.DataSource = markupReactions;
                    dgvMarkup.AutoGenerateColumns = false;
                    colRxnNUM_MR.DataPropertyName = "RXN_NUM";
                    colRxnSeq_MR.DataPropertyName = "RXN_SEQ";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private bool CheckPdfNameandTanMatch(string pdfPath, string tanName, out string errMsg)
        {
            bool blStatus = true;
            string strErrMsg = "";

            try
            {
                string strTANName = !string.IsNullOrEmpty(tanName.Trim()) ? tanName.Trim() : "";                
                string pdfName = !string.IsNullOrEmpty(pdfPath.Trim()) ? Path.GetFileNameWithoutExtension(pdfPath) : "";

                string[] lines = pdfName.Split(new string[] { "_", "." }, StringSplitOptions.RemoveEmptyEntries);

                if (lines != null && lines.Length > 0)
                {
                    string pdfFilename = lines[0];

                    if (string.IsNullOrEmpty(pdfName) && string.IsNullOrEmpty(pdfFilename))
                    {
                        blStatus = false;
                        strErrMsg = "Markup Pdf is mandatory";
                    }
                    else if (pdfFilename.Trim().ToUpper() != strTANName.Trim().ToUpper())
                    {
                        blStatus = false;
                        strErrMsg = "Pdf name should match with TAN name";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsg = strErrMsg.Trim();
            return blStatus;
        }

        private bool ValidateUserInputs(out string errMsg)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (string.IsNullOrEmpty(txtTaskComments.Text))
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + "\r\n" + "Task Comments are mandatory";
                }

                if ((GlobalVariables.ApplicationName == Enums.ApplicationName.REACT.ToString() ||
                    GlobalVariables.ApplicationName == Enums.ApplicationName.ORGANIC.ToString() ||
                    GlobalVariables.ApplicationName == Enums.ApplicationName.MACRO.ToString()) && TaskName == "TASK COMPLETE")
                {
                    string pdfName = !string.IsNullOrEmpty(txtMarkUpPdfPath.Text.Trim()) ? Path.GetFileNameWithoutExtension(txtMarkUpPdfPath.Text) : "";

                    if (string.IsNullOrEmpty(txtMarkUpPdfPath.Text))
                    {
                        blStatus = false;
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Markup Pdf is mandatory";
                    }
                    else if (!string.IsNullOrEmpty(pdfName) && !string.IsNullOrEmpty(TAN_Name) && pdfName.ToUpper() != TAN_Name.ToUpper())
                    {
                        blStatus = false;
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Pdf name should match with TAN";
                    }
                    else //Markup validation
                    {
                        if (GlobalVariables.ApplicationName == Enums.ApplicationName.ORGANIC.ToString() ||
                            GlobalVariables.ApplicationName == Enums.ApplicationName.MACRO.ToString())
                        {
                            //NUMs comparison
                            string strErrOut = "";
                            if (!CompareNUMsInMarkUpAndTool(out strErrOut))
                            {
                                blStatus = false;
                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + strErrOut.Trim();
                            }

                            //New validation on 16th Feb 2016
                            if (dgvTAN.Rows.Count > 0 && dgvMarkup.Rows.Count == 0)
                            {
                                blStatus = false;
                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Reactions markup in the pdf is not done";
                            }
                            else if (dgvTAN.Rows.Count == 0 && dgvMarkup.Rows.Count > 0)
                            {
                                blStatus = false;
                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Markup reactions are not available in the TAN reactions";
                            }

                            //Reactions comparison
                            string errmsg = "";
                            if (!CompareReactionsInMarkUpAndTool(out errmsg))
                            {
                                blStatus = false;
                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Markup reactions & TAN reactions are not matching" + Environment.NewLine + errmsg;
                            }
                        }
                        else if (GlobalVariables.ApplicationName == Enums.ApplicationName.REACT.ToString())
                        {
                            //New validation on 16th Feb 2016
                            if (dgvTAN.Rows.Count > 0 && dgvMarkup.Rows.Count == 0)
                            {
                                blStatus = false;
                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Reactions markup in the pdf is not done";
                            }
                            else if (dgvTAN.Rows.Count == 0 && dgvMarkup.Rows.Count > 0)
                            {
                                blStatus = false;
                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Markup reactions are not available in the TAN reactions";
                            }

                            //Reactions comparison
                            string errmsg = "";
                            if (!CompareReactionsInMarkUpAndTool(out errmsg))
                            {
                                blStatus = false;
                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Markup reactions & TAN reactions are not matching" + Environment.NewLine + errmsg;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsg = strErrMsg.Trim();
            return blStatus;
        }

        private bool CompareReactionsInMarkUpAndTool(out string errMsgOut)
        {
            bool blStatus = true;
            errMsgOut = string.Empty;           

            try
            {
                if (dtTANRxns != null && dtTANRxns.Rows.Count > 0 && dtMarkupRxns != null && dtMarkupRxns.Rows.Count > 0)
                {
                    DataTable dtTR_Filtered = dtTANRxns.Clone();
                    DataTable dtMR_Filtered = dtMarkupRxns.Clone();

                    List<int> lstToolRxnNUMs = ConvertDatatableToList(dtTANRxns, "TAN", GlobalVariables.ApplicationName);
                    List<int> lstMarkUpRxnNUMs = ConvertDatatableToList(dtMarkupRxns,"MARKUP", GlobalVariables.ApplicationName);
                    if (lstToolRxnNUMs.Any() && lstMarkUpRxnNUMs.Any())
                    {
                        List<int> lstMergedRxnNUMs = lstMarkUpRxnNUMs.Any() ? lstToolRxnNUMs.Concat(lstMarkUpRxnNUMs).Distinct().ToList() : null;

                        GetFilteredRxnNUmSeqs(ref dtTR_Filtered, ref dtMR_Filtered, dtTANRxns, dtMarkupRxns, lstMergedRxnNUMs);

                        if (CompareFilteredRxnNumsAndSeq(dtTR_Filtered, dtMR_Filtered, out errMsgOut))
                        {
                            blStatus = false;
                        }
                    }
                    else
                    {
                        errMsgOut = "No reactions in the TAN / Markup pdf";
                        blStatus = false;
                    }
                }
            }

            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CompareFilteredRxnNumsAndSeq(DataTable dtTR_Filtered, DataTable dtMR_Filtered, out string errMsgOut)
        {
            bool Valid = false;
            errMsgOut = string.Empty;
            try
            {

                string ExcessNum = string.Empty;
                string MissedNum = string.Empty;

                if (dtTR_Filtered != null && dtTR_Filtered.Rows.Count > 0 && dtMR_Filtered != null && dtMR_Filtered.Rows.Count > 0)
                {
                    List<NumSeq> liIndexingNUMs = ConvertToList(dtTR_Filtered,"TAN", GlobalVariables.ApplicationName);
                    List<NumSeq> liMarkUpNUMs = ConvertToList(dtMR_Filtered, "MARKUP", GlobalVariables.ApplicationName);

                    var ExcessNumsSeq = liIndexingNUMs.Where(a => !liMarkUpNUMs.Any(b => a.Num == b.Num && a.Seq == b.Seq));
                    var MissedNumsSeq = liMarkUpNUMs.Where(a => !liIndexingNUMs.Any(b => a.Num == b.Num && a.Seq == b.Seq));

                    foreach (var NumSeq in ExcessNumsSeq)
                    {
                        ExcessNum = ExcessNum.Trim() + " " + NumSeq.Num + " - " + NumSeq.Seq + " | ";
                    }

                    foreach (var NumSeq in MissedNumsSeq)
                    {
                        MissedNum = MissedNum.Trim() + " " + NumSeq.Num + " - " + NumSeq.Seq + " | ";
                    }


                    if (!string.IsNullOrEmpty(ExcessNum))
                    {
                        errMsgOut += " Excess Num-Seq in TAN compare to Num-Seq in pdf:" + Environment.NewLine + ExcessNum.TrimEnd(' ', '|') + Environment.NewLine;
                        Valid = true;
                    }

                    if (!string.IsNullOrEmpty(MissedNum))
                    {
                        errMsgOut += " Missed Num-Seq in TAN compare to Num-Seq in Pdf :" + Environment.NewLine + MissedNum.TrimEnd(' ', '|') + Environment.NewLine;
                        Valid = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return Valid;
        }

        private void GetFilteredRxnNUmSeqs(ref DataTable dtTR_Filtered, ref DataTable dtMR_Filtered, DataTable dtIndexingNUMs, DataTable dtMarkUpNUMs, List<int> mergedRxns)
        {
            try
            {
                if (mergedRxns.Count > 0)
                {
                    foreach (int rxnNum in mergedRxns)
                    {
                        DataRow[] drIndexingNums = dtIndexingNUMs.Select("RXN_NUM=" + rxnNum);

                        if (drIndexingNums != null && drIndexingNums.Count() > 0)
                        {
                            foreach (DataRow DR in drIndexingNums)
                            {
                                dtTR_Filtered.Rows.Add(DR.ItemArray);
                            }
                        }

                        DataRow[] drMarkUpNUMs = dtMarkUpNUMs.Select("RXN_NUM=" + rxnNum);

                        if (drMarkUpNUMs != null && drMarkUpNUMs.Count() > 0)
                        {
                            foreach (DataRow DR in drMarkUpNUMs)
                            {
                                dtMR_Filtered.Rows.Add(DR.ItemArray);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private List<int> ConvertDatatableToList(DataTable dtemp,string source, string sourceAppName)
        {
            List<int> liNums = null;

            try
            {
                if (dtemp != null && dtemp.Rows.Count > 0 && !string.IsNullOrEmpty(sourceAppName))
                {
                    if (sourceAppName.ToUpper() == "REACT")
                    {
                        liNums = (from dr in dtemp.AsEnumerable()
                                  select dr.Field<int>("RXN_NUM")).ToList<int>();

                        //int x1 = 0;
                        //liNums = (from dr in dtemp.AsEnumerable()
                        //               select dr.Field<string>("RXN_NUM")).ToList().Where(str => int.TryParse(str, out x1))
                        //                        .Select(str => x1)
                        //                        .ToList();                        

                    }
                    else if (sourceAppName == "MACRO" || sourceAppName == "ORGANIC")
                    {
                        if (source == "TAN")
                        {
                            liNums = (from dr in dtemp.AsEnumerable()
                                      select dr.Field<int>("DISPLAY_ORDER")).ToList();
                        }
                        else if (source == "MARKUP")
                        {
                            liNums = (from dr in dtemp.AsEnumerable()
                                      select dr.Field<int>("RXN_NUM")).ToList();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return liNums;
        }

        private List<NumSeq> ConvertToList(DataTable dtemp,string source, string sourceAppName)
        {
            List<NumSeq> liNum_Seq = null;

            try
            {
                if (dtemp != null && dtemp.Rows.Count > 0 && !string.IsNullOrEmpty(sourceAppName))
                {
                    if (sourceAppName.ToUpper() == "REACT")
                    {
                        liNum_Seq = (from dr in dtemp.AsEnumerable()
                                     select new NumSeq
                                     {
                                         Num = Convert.ToInt32(dr["RXN_NUM"]),
                                         Seq = Convert.ToInt32(dr["RXN_SEQ"]),
                                     }).ToList();
                    }
                    else if (sourceAppName == "MACRO" || sourceAppName == "ORGANIC")
                    {
                        if (source == "TAN")
                        {
                            liNum_Seq = (from dr in dtemp.AsEnumerable()
                                         select new NumSeq
                                         {
                                             Num = Convert.ToInt32(dr["DISPLAY_ORDER"]),
                                             Seq = 1,
                                         }).ToList();
                        }
                        else if (source == "MARKUP")
                        {
                            liNum_Seq = (from dr in dtemp.AsEnumerable()
                                         select new NumSeq
                                         {
                                             Num = Convert.ToInt32(dr["RXN_NUM"]),
                                             Seq = 1,
                                         }).ToList();
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return liNum_Seq;
        }

        private bool CompareNUMsInMarkUpAndTool(out string errMsgOut)
        {
            bool blStatus = true;
            string strErrMsg = "";

            try
            {
                if (!string.IsNullOrEmpty(txtMarkUpPdfPath.Text.Trim()))
                {                    
                    //Indexing Markup NUMs               
                    DataTable markUpNums = MarkUpsValidation_IText.GetMarkUpIndexingNUMs(txtMarkUpPdfPath.Text);
                    DataTable tanNums = ReactDB.GetRxnNUM_RegNoDetailsOnTANID(TAN_ID);

                    if (markUpNums != null && tanNums != null && tanNums.Rows.Count > 0 && markUpNums.Rows.Count > 0)
                    {
                        List<int> lstMarkupNums = markUpNums.AsEnumerable().Select(x => Convert.ToInt32(x.Field<string>("NUM"))).ToList();
                        
                        tanNums.DefaultView.RowFilter = "DPT_RS = 'N'";
                        tanNums = tanNums.DefaultView.ToTable();
                        if (tanNums.Rows.Count > 0)
                        {
                            List<int> lstIndexingNums = tanNums.AsEnumerable().Select(x => Convert.ToInt32(x.Field<Int16>("NUM"))).ToList();

                            lstMarkupNums.Sort();
                            lstIndexingNums.Sort();

                            List<int> excessNums = lstIndexingNums.Except(lstMarkupNums).ToList();
                            List<int> missedNums = lstMarkupNums.Except(lstIndexingNums).ToList();

                            string strExcessNUMs = "";
                            string strMissedNUMs = "";
                            if (excessNums.Any())
                            {
                                strExcessNUMs = string.Join(",", excessNums); 
                            }
                            if (missedNums.Any())
                            {
                                strMissedNUMs = string.Join(",", missedNums);
                            }                        
                            
                            if (!string.IsNullOrEmpty(strExcessNUMs))
                            {
                                strErrMsg += " Excess Nums in TAN compare to Nums in Markup pdf:" + Environment.NewLine + strExcessNUMs.Trim() + Environment.NewLine;
                                blStatus = false;
                            }

                            if (!string.IsNullOrEmpty(strMissedNUMs))
                            {
                                strErrMsg += " Missed Nums in TAN compare to Nums in Markup Pdf :" + Environment.NewLine + strMissedNUMs.Trim() + Environment.NewLine;
                                blStatus = false;
                            }
                        }
                    }

                    //if (markUpNums != null && tanNums != null && lstMarkupNums.Count > 0 && tanNums.Rows.Count > 0)
                    //{

                    //    if (lstMarkupNums.Count == tanNums.Rows.Count)
                    //    {
                    //        for (int i = 0; i < lstMarkupNums.Count; i++)
                    //        {
                    //            for (int j = i; j < tanNums.Rows.Count; j++)
                    //            {
                    //                if (lstMarkupNums[i] != Convert.ToInt32(tanNums.Rows[j]["NUM"]))
                    //                {
                    //                    blStatus = false;
                    //                }
                    //                break;
                    //            }
                    //        }
                    //    }
                    //    else
                    //    {
                    //        blStatus = false;
                    //    }
                    //}
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
                blStatus = false;
            }
            errMsgOut = strErrMsg;
            return blStatus;
        }

        #region Grid PostPaint Events

        private void dgvMarkup_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvMarkup.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;
                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvMarkup.Font);
                if (dgvMarkup.RowHeadersWidth < (int)(size.Width + 20)) dgvMarkup.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;

                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvTAN_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvTAN.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;
                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvTAN.Font);
                if (dgvTAN.RowHeadersWidth < (int)(size.Width + 20)) dgvTAN.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;

                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion
    }
}
