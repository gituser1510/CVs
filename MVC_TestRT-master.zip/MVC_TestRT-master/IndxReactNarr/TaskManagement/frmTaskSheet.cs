﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using IndxReactNarr.Generic;
using IndxReactNarrDAL;
using IndxReactNarr.Common;
using IndxReactNarrBll;
using IndxReactNarr.PdfExport;

namespace IndxReactNarr.TaskManagement
{
    public partial class frmTaskSheet : Form
    {
        #region Class Constructor

        public frmTaskSheet()
        {
            InitializeComponent();
        }

        #endregion

        #region Property Procedures

        public string SelectedTAN
        {
            get;
            set;
        }

        public string SelectedModule
        {
            get;
            set;
        }

        public string SelectedShipment
        {
            get;
            set;
        }

        public int ANALYST_ID
        { get; set; }

        public int TAN_ID
        { get; set; }

        public int Task_ID
        { get; set; }

        public int TaskAllocation_ID
        { get; set; }

        public DataTable AssignedTANs
        {
            get;
            set;
        }
           
        #endregion

        private void frmTaskSheet_Load(object sender, EventArgs e)
        {
            try
            {

                //GlobalVariables.ModuleName = "INDX";
              
                //Analyst
                //AssignedTANs = TaskManagementDB.GetUserAssignedTANs(GlobalVariables.UserRoleID, GlobalVariables.ApplicationName, GlobalVariables.ModuleName);

                //Review Analyst
                //  AssignedTANs = TaskManagementDB.GetUserAssignedTANs(79);

                //Qc
                //    AssignedTANs = TaskManagementDB.GetUserAssignedTANs(78);

                //Get Assigned TANs for this user and bind to grid here
                BindAssignedTANsToGrid(AssignedTANs);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindAssignedTANsToGrid(DataTable assignedTans)
        {
            try
            {
                if (assignedTans != null)
                {
                    //dgvAssignTANs.AutoGenerateColumns = true;
                    //dgvAssignTANs.DataSource = assignedTans;

                    colTaskID.DataPropertyName = "TASK_ID";
                    colTaskAllocationID.DataPropertyName = "TASK_ALLOC_ID";
                    colTanID.DataPropertyName = "TAN_ID";

                    colTanName.DataPropertyName = "TAN_NAME";
                    colModule.DataPropertyName = "MODULE";
                    colDocClass.DataPropertyName = "DOC_CLASS";
                    colPriority.DataPropertyName = "TAN_PRIORITY";
                    colShipmentName.DataPropertyName = "SHIPMENT_NAME";
                    colBNo.DataPropertyName = "BATCH_NO";
                    colManagerURId.DataPropertyName = "TOOL_MGR_UR_ID";

                    colTaskStatus.DataPropertyName = "TASK_STATUS";

                    colIsReAssigned.DataPropertyName = "IS_REASSIGNED";
                    colIsRejected.DataPropertyName = "IS_REJECTED";

                    colAnalystStatus.DataPropertyName = "ANA_STATUS";
                    colReviewStatus.DataPropertyName = "REV_ANA_STATUS";
                    colQCStatus.DataPropertyName = "QUA_ANA_STATUS";

                    colAnalystID.DataPropertyName = "ANALYST";
                    colReviewerID.DataPropertyName = "REV_ANALYST";
                    colRxnCount.DataPropertyName = "RXN_CNT";
                    colNUMsCount.DataPropertyName = "NUM_CNT";

                    if (GlobalVariables.RoleName.ToUpper() == RolesMaster.REV_ANALYST.ToUpper())
                    {
                        colAnalystID.Visible = true;
                    }
                    if (GlobalVariables.RoleName.ToUpper() == RolesMaster.QC_ANALYST.ToUpper())
                    {
                        colAnalystID.Visible = true;
                        colReviewerID.Visible = true;
                    }

                    if (GlobalVariables.ApplicationName == Enums.ApplicationName.REACT.ToString())
                    {
                        colDocClass.Visible = true;
                        colPriority.Visible = true;
                        colNums.Visible = true;
                    }
                    else
                    {
                        colDocClass.Visible = false;
                        colPriority.Visible = false;
                        colNums.Visible = false;
                    }

                    if (GlobalVariables.RoleName == RolesMaster.ANALYST)
                    {
                        colAnalystStatus.Visible = true;
                    }
                    else if (GlobalVariables.RoleName == RolesMaster.REV_ANALYST)
                    {
                        colReviewStatus.Visible = true;
                    }
                    else if (GlobalVariables.RoleName == RolesMaster.QC_ANALYST)
                    {
                        colQCStatus.Visible = true;
                    }

                    dgvAssignTANs.AutoGenerateColumns = false;
                    dgvAssignTANs.DataSource = assignedTans;   
                 
                    //Set label counts
                    lblTANCount.Text = assignedTans.Rows.Count.ToString();
                    lblRxnsCount.Text = assignedTans.Compute("sum([RXN_CNT])", "[RXN_CNT] is not null").ToString();
                    lblNUMsCount.Text = assignedTans.Compute("sum([NUM_CNT])", "[NUM_CNT] is not null").ToString();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvAssignTANs_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                {

                    string strColName = dgvAssignTANs.Columns[e.ColumnIndex].HeaderText;
                    if (strColName.ToUpper() == "TAN")
                    {
                        SelectedTAN = dgvAssignTANs.Rows[e.RowIndex].Cells[colTanName.Name].Value.ToString();
                        TAN_ID = Convert.ToInt32(dgvAssignTANs.Rows[e.RowIndex].Cells[colTanID.Name].Value.ToString());
                        SelectedModule = GlobalVariables.ModuleName;
                        GlobalVariables.ShipmentName = dgvAssignTANs.Rows[e.RowIndex].Cells[colShipmentName.Name].Value.ToString();

                        Task_ID = Convert.ToInt32(dgvAssignTANs.Rows[e.RowIndex].Cells[colTaskID.Name].Value.ToString());
                        TaskAllocation_ID = Convert.ToInt32(dgvAssignTANs.Rows[e.RowIndex].Cells[colTaskAllocationID.Name].Value.ToString());

                        int intAnalystId = 0;
                        if (dgvAssignTANs.Columns.Contains(colAnalystID.Name))
                        {
                            if (dgvAssignTANs.Rows[e.RowIndex].Cells[colAnalystID.Name].Value != null)
                            {
                                int.TryParse(dgvAssignTANs.Rows[e.RowIndex].Cells[colAnalystID.Name].Value.ToString(), out intAnalystId);
                            }
                            ANALYST_ID = intAnalystId;
                        }

                        //Set Task to PROGRESS, if status is ASSIGNED
                        UpdateUserAssignedTaskStatus(dgvAssignTANs.Rows[e.RowIndex]);

                        DialogResult = System.Windows.Forms.DialogResult.OK;
                    }
                    else if (strColName.ToUpper() == "DOWNLOAD")//View PDF 
                    {
                        Cursor = Cursors.WaitCursor;
                        string strTAN = dgvAssignTANs.Rows[e.RowIndex].Cells[colTanName.Name].Value.ToString();
                        string strShipment = dgvAssignTANs.Rows[e.RowIndex].Cells[colShipmentName.Name].Value.ToString();

                        //Check & Open TAN Pdf
                        OpenTANPdfFile(strTAN, strShipment);
                        Cursor = Cursors.Default;
                    }
                    else if (strColName.ToUpper() == "NUMS")//Get NUMs 
                    {
                        #region MyRegion
                        //Cursor = Cursors.WaitCursor;
                        //string strTAN = dgvAssignTANs.Rows[e.RowIndex].Cells[colTanName.Name].Value.ToString();
                        //string strShipment = dgvAssignTANs.Rows[e.RowIndex].Cells[colShipmentName.Name].Value.ToString();

                        //FormCollection frmColl = Application.OpenForms;
                        //frmNUMSearch objNumSrch = null;
                        //foreach (Form frm in frmColl)
                        //{
                        //    if (frm.Name.ToUpper() == "FRMNUMSEARCH")
                        //    {
                        //        objNumSrch = (frmNUMSearch)frm;
                        //        objNumSrch.Close();
                        //        break;
                        //    }
                        //}
                        //objNumSrch = new frmNUMSearch();
                        //objNumSrch.TAN = strTAN;                   
                        //objNumSrch.BatchName = strShipment;
                        //objNumSrch.Show();
                        //Cursor = Cursors.Default; 
                        #endregion

                        using (FolderBrowserDialog objFoldBrowse = new FolderBrowserDialog())
                        {
                            if (objFoldBrowse.ShowDialog() == DialogResult.OK)
                            {
                                Cursor = Cursors.WaitCursor;

                                NumsExportToPdf numsExport = new NumsExportToPdf();
                                int tanID = Convert.ToInt32(dgvAssignTANs.Rows[e.RowIndex].Cells[colTanID.Name].Value.ToString());
                                numsExport.TanNUMsData = ReactDB.GetNUM_RegNoDetailsOnTANID(tanID);
                                numsExport.TANDetails = ReactDB.GetTANDetailsOnTANID(tanID); ;
                                numsExport.PdfFilePath = objFoldBrowse.SelectedPath + "\\" + dgvAssignTANs.Rows[e.RowIndex].Cells[colTanName.Name].Value.ToString() + "_NUMs.pdf";
                                if (numsExport.ExportTanNUMsToPDF())
                                {
                                    Cursor = Cursors.Default;
                                    System.Diagnostics.Process.Start(numsExport.PdfFilePath);
                                }
                                else
                                {
                                    Cursor = Cursors.Default;
                                    MessageBox.Show("Error in NUMs export", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void UpdateUserAssignedTaskStatus(DataGridViewRow gridRow)
        {
            try
            {
                if (gridRow != null)
                {
                    string allocStatus = "";
                    if (GlobalVariables.RoleName == RolesMaster.ANALYST)
                    {
                        allocStatus = gridRow.Cells[colAnalystStatus.Name].Value.ToString();
                    }
                    else if (GlobalVariables.RoleName == RolesMaster.REV_ANALYST)
                    {
                        allocStatus = gridRow.Cells[colReviewStatus.Name].Value.ToString();
                    }
                    else if (GlobalVariables.RoleName == RolesMaster.QC_ANALYST)
                    {
                        allocStatus = gridRow.Cells[colQCStatus.Name].Value.ToString();
                    }

                    if (allocStatus == "ASSIGNED")
                    {
                        TaskStatus taskStatus = new TaskStatus();
                        taskStatus.Task_ID = Task_ID;
                        taskStatus.TaskAllocation_ID = TaskAllocation_ID;
                        taskStatus.TAN_ID = TAN_ID;
                        //taskStatus.Role_ID = GlobalVariables.RoleID;
                        taskStatus.UR_ID = GlobalVariables.URID;
                        taskStatus.TaskStatusName = "SET PROGRESS";

                        //Update User Task Status
                        TaskManagementDB.UpdateUserTaskStatus(taskStatus);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvAssignTANs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();
                while (strRowNumber.Length < dgvAssignTANs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvAssignTANs.Font);
                if (dgvAssignTANs.RowHeadersWidth < (int)(size.Width + 20)) dgvAssignTANs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
                                
        private void OpenTANPdfFile(string tan, string shipmentName)
        {
            try
            {
                if (!string.IsNullOrEmpty(tan) && !string.IsNullOrEmpty(shipmentName))
                {
                    string strPdfName = tan;
                    strPdfName = strPdfName + ".pdf";

                    string strShipment = shipmentName;
                    strShipment = strShipment.Trim().Replace("rxnfile.", "");

                    string strPdfDirPath = Application.StartupPath.ToString() + "\\TAN_PDFs";
                   
                    if (!Directory.Exists(strPdfDirPath))
                    {
                        Directory.CreateDirectory(strPdfDirPath);
                    }

                    string strPdfPath = strPdfDirPath + "\\" + strPdfName;

                    if (!File.Exists(strPdfPath))
                    {
                        #region Linux Server code commented on 26th March 2013
                        //string strAppBase = Application.StartupPath.ToString();
                        //string strServerpath = "/root/CASREACT_V2/TAN_Pdfs/" + strBatch.Trim() + "/";
                        //string strError_Out = "";

                        //if (CAS_Classes.DownloadPdf.CallPSCPAndDownLoadFile(strPdfName, strServerpath, strPdfDirPath, out strError_Out))
                        //{
                        //    System.Diagnostics.Process.Start(strPdfPath);
                        //}
                        //else
                        //{
                        //    MessageBox.Show(strError_Out, "View PDF", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        //} 
                        #endregion

                        //New Windows server code as on 26th March 2013        
                        string serverPath = System.Configuration.ConfigurationSettings.AppSettings["FileServerPath"].ToString() + "\\cas_app_files\\IRN";

                        string strFilepath = serverPath + "\\" + GlobalVariables.ApplicationName + "\\" + shipmentName + "\\" + strPdfName;
                                                
                        string strError_Out = "";                        
                        if (Common.Download_UploadPdf.DownloadFileFromWindowsServer(strFilepath, strPdfPath, out strError_Out))
                        {
                            System.Diagnostics.Process.Start(strPdfPath);
                        }
                        else
                        {
                            MessageBox.Show(strError_Out, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        System.Diagnostics.Process.Start(strPdfPath);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #region Filtering Methods & Events

        private void txtTAN_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilterDataAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtBName_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == 13)
                {
                    GetFilterDataAndBindToGrid();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetFilterCondition()
        {
            string strFCond = "";
            try
            {
                if (txtTAN.Text.Trim() != "")
                {
                    strFCond = "TAN_NAME like '" + txtTAN.Text.Trim() + "%'";
                }
                if (txtBName.Text.Trim() != "")
                {
                    if (strFCond.Trim() == "")
                    {
                        strFCond = "SHIPMENT_NAME = '" + txtBName.Text.Trim() + "'";
                    }
                    else
                    {
                        strFCond = strFCond + " and SHIPMENT_NAME = '" + txtBName.Text.Trim() + "'";
                    }
                }
                if (txtBNo.Text.Trim() != "")
                {
                    if (strFCond.Trim() == "")
                    {
                        strFCond = "BATCH_NO = " + txtBNo.Text.Trim() + "";
                    }
                    else
                    {
                        strFCond = strFCond + " and BATCH_NO = " + txtBNo.Text.Trim() + "";
                    }
                }
                if (txtTanStatus.Text.Trim() != "")
                {
                    if (strFCond.Trim() == "")
                    {
                        strFCond = "TASK_STATUS like '" + txtTanStatus.Text.Trim() + "%'";
                    }
                    else
                    {
                        strFCond = strFCond + " and TASK_STATUS like '" + txtTanStatus.Text.Trim() + "%'";
                    }
                }
                //if (txtAssignBy.Text.Trim() != "")
                //{
                //    if (strFCond.Trim() == "")
                //    {
                //        strFCond = "Assigned_By_User like '" + txtAssignBy.Text.Trim() + "%'";
                //    }
                //    else
                //    {
                //        strFCond = strFCond + " and Assigned_By_User like '" + txtAssignBy.Text.Trim() + "%'";
                //    }
                //}
                //if (txtAssignbyRole.Text.Trim() != "")
                //{
                //    if (strFCond.Trim() == "")
                //    {
                //        strFCond = "Assigned_by_Role like '" + txtAssignbyRole.Text.Trim() + "%'";
                //    }
                //    else
                //    {
                //        strFCond = strFCond + " and Assigned_by_Role like '" + txtAssignbyRole.Text.Trim() + "%'";
                //    }
                //}
                //if (txtAssignTo.Text.Trim() != "")
                //{
                //    if (strFCond.Trim() == "")
                //    {
                //        strFCond = "Assigned_To_User like '" + txtAssignTo.Text.Trim() + "%'";
                //    }
                //    else
                //    {
                //        strFCond = strFCond + " and Assigned_To_User like '" + txtAssignTo.Text.Trim() + "%'";
                //    }
                //}
                //if (txtAssignToRole.Text.Trim() != "")
                //{
                //    if (strFCond.Trim() == "")
                //    {
                //        strFCond = "Assigned_To_Role like '" + txtAssignToRole.Text.Trim() + "%'";
                //    }
                //    else
                //    {
                //        strFCond = strFCond + " and Assigned_To_Role like '" + txtAssignToRole.Text.Trim() + "%'";
                //    }
                //}
                return strFCond;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strFCond;
        }

        private void GetFilterDataAndBindToGrid()
        {
            try
            {
                if (AssignedTANs != null && AssignedTANs.Rows.Count > 0)
                {
                    string strFCond = GetFilterCondition();
                    if (strFCond.Trim() != "")
                    {
                        DataTable dtAllTANs = AssignedTANs.Copy();
                        DataView dv = dtAllTANs.DefaultView;
                        DataTable dtTemp = null;

                        dv.RowFilter = strFCond;
                        dtTemp = dv.ToTable();
                        BindAssignedTANsToGrid(dtTemp);
                    }
                    else
                    {
                        DataTable dtAllTANs = AssignedTANs.Copy();
                        BindAssignedTANsToGrid(dtAllTANs);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        private bool CheckForZeroPartpntsAndRSN_SpellCheck(string _tan, string _srcuser)
        {
            try
            {
                if (_tan.Trim() != "")
                {
                    DataTable dtZ_parpnts = null;// CASRxnDataAccess.GetZeroParticipantsOnTAN(_tan);
                    DataTable dtRSN = null; // CASRxnDataAccess.GetRSNDetailsOnTAN(_tan);

                    //frmFinalChecks objfinal_chks = new frmFinalChecks();
                    //objfinal_chks.ZeroPartpnts = dtZ_parpnts;
                    //objfinal_chks.RSNData = dtRSN;
                    //objfinal_chks.SourceUser = _srcuser;
                    //if (objfinal_chks.ShowDialog() == DialogResult.OK)
                    //{
                    //    return true;
                    //}
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return false;
        }

    }
}
