﻿namespace IndxReactNarr.TaskManagement
{
    partial class frmTaskComments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMain = new System.Windows.Forms.Panel();
            this.splContComp = new System.Windows.Forms.SplitContainer();
            this.dgvTAN = new System.Windows.Forms.DataGridView();
            this.colDisplayOrder = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnNUM_TR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnSeq_TR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlTANCnts = new System.Windows.Forms.Panel();
            this.lblTANRxnsCnt = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTANHeader = new System.Windows.Forms.Label();
            this.dgvMarkup = new System.Windows.Forms.DataGridView();
            this.colRxnNUM_MR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnSeq_MR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMarkupCnts = new System.Windows.Forms.Panel();
            this.lblMarkupRxnsCnt = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblMarkupHeader = new System.Windows.Forms.Label();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.txtTaskComments = new System.Windows.Forms.TextBox();
            this.txtMarkUpPdfPath = new System.Windows.Forms.TextBox();
            this.lblUserComments = new System.Windows.Forms.Label();
            this.btnBrowsePdf = new System.Windows.Forms.Button();
            this.lblPdfpath = new System.Windows.Forms.Label();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblAuthor = new System.Windows.Forms.Label();
            this.lblAuthorName = new System.Windows.Forms.Label();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splContComp)).BeginInit();
            this.splContComp.Panel1.SuspendLayout();
            this.splContComp.Panel2.SuspendLayout();
            this.splContComp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTAN)).BeginInit();
            this.pnlTANCnts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMarkup)).BeginInit();
            this.pnlMarkupCnts.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.pnlBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.splContComp);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(998, 417);
            this.pnlMain.TabIndex = 0;
            // 
            // splContComp
            // 
            this.splContComp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splContComp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContComp.Location = new System.Drawing.Point(0, 107);
            this.splContComp.Name = "splContComp";
            // 
            // splContComp.Panel1
            // 
            this.splContComp.Panel1.Controls.Add(this.dgvTAN);
            this.splContComp.Panel1.Controls.Add(this.pnlTANCnts);
            this.splContComp.Panel1.Controls.Add(this.lblTANHeader);
            // 
            // splContComp.Panel2
            // 
            this.splContComp.Panel2.Controls.Add(this.dgvMarkup);
            this.splContComp.Panel2.Controls.Add(this.pnlMarkupCnts);
            this.splContComp.Panel2.Controls.Add(this.lblMarkupHeader);
            this.splContComp.Size = new System.Drawing.Size(998, 280);
            this.splContComp.SplitterDistance = 489;
            this.splContComp.SplitterWidth = 3;
            this.splContComp.TabIndex = 6;
            // 
            // dgvTAN
            // 
            this.dgvTAN.AllowUserToAddRows = false;
            this.dgvTAN.AllowUserToDeleteRows = false;
            this.dgvTAN.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTAN.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvTAN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTAN.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colDisplayOrder,
            this.colRxnNUM_TR,
            this.colRxnSeq_TR});
            this.dgvTAN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTAN.Location = new System.Drawing.Point(0, 22);
            this.dgvTAN.Name = "dgvTAN";
            this.dgvTAN.ReadOnly = true;
            this.dgvTAN.Size = new System.Drawing.Size(485, 227);
            this.dgvTAN.TabIndex = 1;
            this.dgvTAN.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvTAN_RowPostPaint);
            // 
            // colDisplayOrder
            // 
            this.colDisplayOrder.HeaderText = "DisplayOrder";
            this.colDisplayOrder.Name = "colDisplayOrder";
            this.colDisplayOrder.ReadOnly = true;
            // 
            // colRxnNUM_TR
            // 
            this.colRxnNUM_TR.HeaderText = "NUM";
            this.colRxnNUM_TR.Name = "colRxnNUM_TR";
            this.colRxnNUM_TR.ReadOnly = true;
            // 
            // colRxnSeq_TR
            // 
            this.colRxnSeq_TR.HeaderText = "Seq";
            this.colRxnSeq_TR.Name = "colRxnSeq_TR";
            this.colRxnSeq_TR.ReadOnly = true;
            // 
            // pnlTANCnts
            // 
            this.pnlTANCnts.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTANCnts.Controls.Add(this.lblTANRxnsCnt);
            this.pnlTANCnts.Controls.Add(this.label1);
            this.pnlTANCnts.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlTANCnts.Location = new System.Drawing.Point(0, 249);
            this.pnlTANCnts.Name = "pnlTANCnts";
            this.pnlTANCnts.Size = new System.Drawing.Size(485, 27);
            this.pnlTANCnts.TabIndex = 4;
            // 
            // lblTANRxnsCnt
            // 
            this.lblTANRxnsCnt.AutoSize = true;
            this.lblTANRxnsCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTANRxnsCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblTANRxnsCnt.Location = new System.Drawing.Point(126, 4);
            this.lblTANRxnsCnt.Name = "lblTANRxnsCnt";
            this.lblTANRxnsCnt.Size = new System.Drawing.Size(18, 17);
            this.lblTANRxnsCnt.TabIndex = 7;
            this.lblTANRxnsCnt.Text = "--";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "TAN RXNs count: ";
            // 
            // lblTANHeader
            // 
            this.lblTANHeader.BackColor = System.Drawing.Color.Bisque;
            this.lblTANHeader.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTANHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTANHeader.Location = new System.Drawing.Point(0, 0);
            this.lblTANHeader.Name = "lblTANHeader";
            this.lblTANHeader.Size = new System.Drawing.Size(485, 22);
            this.lblTANHeader.TabIndex = 0;
            this.lblTANHeader.Text = "TAN Reactions";
            this.lblTANHeader.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dgvMarkup
            // 
            this.dgvMarkup.AllowUserToAddRows = false;
            this.dgvMarkup.AllowUserToDeleteRows = false;
            this.dgvMarkup.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvMarkup.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvMarkup.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMarkup.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colRxnNUM_MR,
            this.colRxnSeq_MR});
            this.dgvMarkup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvMarkup.Location = new System.Drawing.Point(0, 22);
            this.dgvMarkup.Name = "dgvMarkup";
            this.dgvMarkup.ReadOnly = true;
            this.dgvMarkup.Size = new System.Drawing.Size(502, 227);
            this.dgvMarkup.TabIndex = 2;
            this.dgvMarkup.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvMarkup_RowPostPaint);
            // 
            // colRxnNUM_MR
            // 
            this.colRxnNUM_MR.HeaderText = "NUM";
            this.colRxnNUM_MR.Name = "colRxnNUM_MR";
            this.colRxnNUM_MR.ReadOnly = true;
            // 
            // colRxnSeq_MR
            // 
            this.colRxnSeq_MR.HeaderText = "Seq";
            this.colRxnSeq_MR.Name = "colRxnSeq_MR";
            this.colRxnSeq_MR.ReadOnly = true;
            // 
            // pnlMarkupCnts
            // 
            this.pnlMarkupCnts.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlMarkupCnts.Controls.Add(this.lblMarkupRxnsCnt);
            this.pnlMarkupCnts.Controls.Add(this.label3);
            this.pnlMarkupCnts.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlMarkupCnts.Location = new System.Drawing.Point(0, 249);
            this.pnlMarkupCnts.Name = "pnlMarkupCnts";
            this.pnlMarkupCnts.Size = new System.Drawing.Size(502, 27);
            this.pnlMarkupCnts.TabIndex = 5;
            // 
            // lblMarkupRxnsCnt
            // 
            this.lblMarkupRxnsCnt.AutoSize = true;
            this.lblMarkupRxnsCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMarkupRxnsCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblMarkupRxnsCnt.Location = new System.Drawing.Point(142, 4);
            this.lblMarkupRxnsCnt.Name = "lblMarkupRxnsCnt";
            this.lblMarkupRxnsCnt.Size = new System.Drawing.Size(18, 17);
            this.lblMarkupRxnsCnt.TabIndex = 7;
            this.lblMarkupRxnsCnt.Text = "--";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 17);
            this.label3.TabIndex = 0;
            this.label3.Text = "Markup RXNs count: ";
            // 
            // lblMarkupHeader
            // 
            this.lblMarkupHeader.BackColor = System.Drawing.Color.Bisque;
            this.lblMarkupHeader.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMarkupHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblMarkupHeader.Location = new System.Drawing.Point(0, 0);
            this.lblMarkupHeader.Name = "lblMarkupHeader";
            this.lblMarkupHeader.Size = new System.Drawing.Size(502, 22);
            this.lblMarkupHeader.TabIndex = 1;
            this.lblMarkupHeader.Text = "Markup Reactions";
            this.lblMarkupHeader.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pnlTop
            // 
            this.pnlTop.Controls.Add(this.txtTaskComments);
            this.pnlTop.Controls.Add(this.txtMarkUpPdfPath);
            this.pnlTop.Controls.Add(this.lblUserComments);
            this.pnlTop.Controls.Add(this.btnBrowsePdf);
            this.pnlTop.Controls.Add(this.lblPdfpath);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(998, 107);
            this.pnlTop.TabIndex = 7;
            // 
            // txtTaskComments
            // 
            this.txtTaskComments.Location = new System.Drawing.Point(114, 3);
            this.txtTaskComments.Multiline = true;
            this.txtTaskComments.Name = "txtTaskComments";
            this.txtTaskComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtTaskComments.Size = new System.Drawing.Size(878, 71);
            this.txtTaskComments.TabIndex = 1;
            // 
            // txtMarkUpPdfPath
            // 
            this.txtMarkUpPdfPath.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.txtMarkUpPdfPath.Location = new System.Drawing.Point(114, 78);
            this.txtMarkUpPdfPath.Name = "txtMarkUpPdfPath";
            this.txtMarkUpPdfPath.ReadOnly = true;
            this.txtMarkUpPdfPath.Size = new System.Drawing.Size(840, 25);
            this.txtMarkUpPdfPath.TabIndex = 0;
            // 
            // lblUserComments
            // 
            this.lblUserComments.AutoSize = true;
            this.lblUserComments.Location = new System.Drawing.Point(7, 6);
            this.lblUserComments.Name = "lblUserComments";
            this.lblUserComments.Size = new System.Drawing.Size(104, 17);
            this.lblUserComments.TabIndex = 2;
            this.lblUserComments.Text = "User Comments";
            // 
            // btnBrowsePdf
            // 
            this.btnBrowsePdf.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBrowsePdf.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowsePdf.Location = new System.Drawing.Point(961, 79);
            this.btnBrowsePdf.Name = "btnBrowsePdf";
            this.btnBrowsePdf.Size = new System.Drawing.Size(31, 23);
            this.btnBrowsePdf.TabIndex = 4;
            this.btnBrowsePdf.Text = "...";
            this.btnBrowsePdf.UseVisualStyleBackColor = true;
            this.btnBrowsePdf.Click += new System.EventHandler(this.btnBrowsePdf_Click);
            // 
            // lblPdfpath
            // 
            this.lblPdfpath.AutoSize = true;
            this.lblPdfpath.Location = new System.Drawing.Point(3, 82);
            this.lblPdfpath.Name = "lblPdfpath";
            this.lblPdfpath.Size = new System.Drawing.Size(108, 17);
            this.lblPdfpath.TabIndex = 3;
            this.lblPdfpath.Text = "Markup Pdf path";
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom.Controls.Add(this.lblAuthorName);
            this.pnlBottom.Controls.Add(this.lblAuthor);
            this.pnlBottom.Controls.Add(this.btnSubmit);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 387);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(998, 30);
            this.pnlBottom.TabIndex = 5;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSubmit.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.Location = new System.Drawing.Point(917, 0);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(74, 27);
            this.btnSubmit.TabIndex = 6;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "NUM";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 221;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Seq";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 221;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "NUM";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 230;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Seq";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 229;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Seq";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 229;
            // 
            // lblAuthor
            // 
            this.lblAuthor.AutoSize = true;
            this.lblAuthor.Location = new System.Drawing.Point(3, 5);
            this.lblAuthor.Name = "lblAuthor";
            this.lblAuthor.Size = new System.Drawing.Size(116, 17);
            this.lblAuthor.TabIndex = 7;
            this.lblAuthor.Text = "Pdf Author Name:";
            // 
            // lblAuthorName
            // 
            this.lblAuthorName.AutoSize = true;
            this.lblAuthorName.ForeColor = System.Drawing.Color.Red;
            this.lblAuthorName.Location = new System.Drawing.Point(128, 5);
            this.lblAuthorName.Name = "lblAuthorName";
            this.lblAuthorName.Size = new System.Drawing.Size(18, 17);
            this.lblAuthorName.TabIndex = 8;
            this.lblAuthorName.Text = "--";
            // 
            // frmTaskComments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(998, 417);
            this.Controls.Add(this.pnlMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmTaskComments";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Task Comments";
            this.Load += new System.EventHandler(this.frmTaskComments_Load);
            this.pnlMain.ResumeLayout(false);
            this.splContComp.Panel1.ResumeLayout(false);
            this.splContComp.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splContComp)).EndInit();
            this.splContComp.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTAN)).EndInit();
            this.pnlTANCnts.ResumeLayout(false);
            this.pnlTANCnts.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMarkup)).EndInit();
            this.pnlMarkupCnts.ResumeLayout(false);
            this.pnlMarkupCnts.PerformLayout();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Label lblUserComments;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnBrowsePdf;
        private System.Windows.Forms.Label lblPdfpath;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Button btnSubmit;
        public System.Windows.Forms.TextBox txtTaskComments;
        public System.Windows.Forms.TextBox txtMarkUpPdfPath;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.SplitContainer splContComp;
        private System.Windows.Forms.Label lblTANHeader;
        private System.Windows.Forms.Label lblMarkupHeader;
        private System.Windows.Forms.DataGridView dgvTAN;
        private System.Windows.Forms.DataGridView dgvMarkup;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnNUM_MR;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnSeq_MR;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDisplayOrder;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnNUM_TR;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnSeq_TR;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.Panel pnlTANCnts;
        private System.Windows.Forms.Label lblTANRxnsCnt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlMarkupCnts;
        private System.Windows.Forms.Label lblMarkupRxnsCnt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblAuthorName;
        private System.Windows.Forms.Label lblAuthor;
    }
}