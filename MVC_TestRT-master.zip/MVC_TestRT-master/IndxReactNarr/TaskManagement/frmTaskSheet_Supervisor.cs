﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CASRxnTool.Generic;
using DAL;
using System.IO;

namespace CASRxnTool.TaskManagement
{
    public partial class frmTaskSheet_Supervisor : Form
    {
        public frmTaskSheet_Supervisor()
        {
            InitializeComponent();
        }

        #region Property Procedures

        public string SelectedTAN
        {
            get;
            set;
        }

        public int TAN_BT_ID
        { get; set; }

        public int ANALYST_ID
        { get; set; }

        public DataTable SelTANDetails
        {
            get;
            set;
        }

        public DataTable AssignedTANs
        {
            get;
            set;
        }              

        public bool IsNewTan
        {
            get;
            set;
        }

        public string BatchName
        {
            get;
            set;
        }

        public string BatchNo
        {
            get;
            set;
        }

        #endregion

        private void dgvAssignTANs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();
                while (strRowNumber.Length < dgvAssignTANs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvAssignTANs.Font);
                if (dgvAssignTANs.RowHeadersWidth < (int)(size.Width + 20)) dgvAssignTANs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtBName_Qry.Text.Trim() != "")
                {
                    int intBNo = 0;
                    int.TryParse(txtBNo_Qry.Text.Trim(), out intBNo);

                    Cursor = Cursors.WaitCursor;

                    //Retrieve assigned TANs for the user based on userid,role
                    DataTable dtAssignedTans = CASRxnDataAccess.GetSupervisorAssignedTANs(Generic.GlobalVariables.URID, Generic.GlobalVariables.UserRoleID, txtBName_Qry.Text.Trim(), intBNo);
                    if (dtAssignedTans != null)
                    {
                        AssignedTANs = dtAssignedTans;
                        BindAssignedTANsToGrid(dtAssignedTans);
                    }

                    Cursor = Cursors.Default;
                }
                else
                {
                    MessageBox.Show("Enter Batch Name", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }        
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
                Cursor = Cursors.Default;
            }
        }

        private void BindAssignedTANsToGrid(DataTable _dtassignedtans)
        {
            try
            {
                if (_dtassignedtans != null)
                {                   
                    dgvAssignTANs.AutoGenerateColumns = false;
                    dgvAssignTANs.DataSource = _dtassignedtans;

                    dgvAssignTANs.Columns["tan"].DataPropertyName = "tan";
                    dgvAssignTANs.Columns["bname"].DataPropertyName = "batchname";
                    dgvAssignTANs.Columns["bno"].DataPropertyName = "batchno";
                    dgvAssignTANs.Columns["tan_status"].DataPropertyName = "tan_status";
                    dgvAssignTANs.Columns["assbyuser"].DataPropertyName = "assigned_by_user";
                    dgvAssignTANs.Columns["assbyrole"].DataPropertyName = "assigned_by_role";
                    dgvAssignTANs.Columns["asstouser"].DataPropertyName = "assigned_to_user";
                    dgvAssignTANs.Columns["asstorole"].DataPropertyName = "assigned_to_role";
                    dgvAssignTANs.Columns["bt_id"].DataPropertyName ="bt_id";

                    //dtGrid_Assign_TANs.Columns["tan"].Visible = false;                  
                    //dtGrid_Assign_TANs.Columns["bt_id"].Visible = false;

                    if (_dtassignedtans.Columns.Contains("manager"))
                    {
                        dgvAssignTANs.Columns["manager"].DataPropertyName = "manager";
                    }
                    if (_dtassignedtans.Columns.Contains("manager_ur_id"))
                    {
                        dgvAssignTANs.Columns["manager_ur_id"].DataPropertyName = "manager_ur_id";
                    }
                    if (_dtassignedtans.Columns.Contains("analyst_id"))
                    {
                        dgvAssignTANs.Columns["analyst_id"].DataPropertyName = "analyst_id";
                    }
                    dgvAssignTANs.Refresh();
                    this.pnlMain.Refresh();
                    this.Refresh();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetFilterCondition()
        {
            string strFCond = "";
            try
            {
                if (txtTANSrch.Text.Trim() != "")
                {
                    if (txtTANSrch.Text.Trim().Contains(";"))
                    {
                        string[] splitter = { ";" };
                        string[] strArrTans = txtTANSrch.Text.Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);

                        if (strArrTans != null)
                        {
                            if (strArrTans.Length > 0)
                            {
                                for (int i = 0; i < strArrTans.Length; i++)
                                {
                                    if (i == 0)
                                    {
                                        strFCond = "TAN Like '" + strArrTans[i] + "%' ";
                                    }
                                    else
                                    {
                                        strFCond += " OR " + "TAN Like '" + strArrTans[i] + "%'";
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        strFCond = "TAN Like '" + txtTANSrch.Text.Trim() + "%'";
                    }       
                }
                
                if (txtTanStatus.Text.Trim() != "")
                {
                    if (strFCond.Trim() == "")
                    {
                        strFCond = "tan_status like '" + txtTanStatus.Text.Trim() + "%'";
                    }
                    else
                    {
                        strFCond = strFCond + " and tan_status like '" + txtTanStatus.Text.Trim() + "%'";
                    }
                }

                if (txtAssignBy.Text.Trim() != "")
                {
                    if (strFCond.Trim() == "")
                    {
                        strFCond = "Assigned_By_User like '" + txtAssignBy.Text.Trim() + "%'";
                    }
                    else
                    {
                        strFCond = strFCond + " and Assigned_By_User like '" + txtAssignBy.Text.Trim() + "%'";
                    }
                }

                if (txtAssignbyRole.Text.Trim() != "")
                {
                    if (strFCond.Trim() == "")
                    {
                        strFCond = "Assigned_by_Role like '" + txtAssignbyRole.Text.Trim() + "%'";
                    }
                    else
                    {
                        strFCond = strFCond + " and Assigned_by_Role like '" + txtAssignbyRole.Text.Trim() + "%'";
                    }
                }

                if (txtAssignTo.Text.Trim() != "")
                {
                    if (strFCond.Trim() == "")
                    {
                        strFCond = "Assigned_To_User like '" + txtAssignTo.Text.Trim() + "%'";
                    }
                    else
                    {
                        strFCond = strFCond + " and Assigned_To_User like '" + txtAssignTo.Text.Trim() + "%'";
                    }
                }

                if (txtAssignToRole.Text.Trim() != "")
                {
                    if (strFCond.Trim() == "")
                    {
                        strFCond = "Assigned_To_Role like '" + txtAssignToRole.Text.Trim() + "%'";
                    }
                    else
                    {
                        strFCond = strFCond + " and Assigned_To_Role like '" + txtAssignToRole.Text.Trim() + "%'";
                    }
                }
                return strFCond;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strFCond;
        }

        private void GetFilterDataAndBindToGrid()
        {
            try
            {
                if (AssignedTANs != null)
                {
                    string strFCond = GetFilterCondition();
                    if (strFCond.Trim() != "")
                    {
                        DataTable dtAllTANs = AssignedTANs.Copy();
                        DataView dv = dtAllTANs.DefaultView;
                        DataTable dtTemp = null;

                        dv.RowFilter = strFCond;
                        dtTemp = dv.ToTable();
                        BindAssignedTANsToGrid(dtTemp);
                    }
                    else
                    {
                        DataTable dtAllTANs = AssignedTANs.Copy();
                        BindAssignedTANsToGrid(dtAllTANs);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvAssignTANs_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex < 0 || e.ColumnIndex < 0)
                    return;

                string strColName = dgvAssignTANs.Columns[e.ColumnIndex].HeaderText;
                if (strColName.ToUpper() == "TAN")
                {
                    SelectedTAN = dgvAssignTANs.Rows[e.RowIndex].Cells["tan"].Value.ToString();
                    TAN_BT_ID = Convert.ToInt32(dgvAssignTANs.Rows[e.RowIndex].Cells["bt_id"].Value.ToString());
                    int intAnalystId = 0;
                    if (dgvAssignTANs.Columns.Contains("analyst_id"))
                    {
                        if (dgvAssignTANs.Rows[e.RowIndex].Cells["analyst_id"].Value != null)
                        {
                            int.TryParse(dgvAssignTANs.Rows[e.RowIndex].Cells["analyst_id"].Value.ToString(), out intAnalystId);
                        }
                        ANALYST_ID = intAnalystId;
                    }
                    //GlobalVariables.PM_Name = dtGrid_Assign_TANs.Rows[e.RowIndex].Cells["manager"].Value.ToString();
                    //GlobalVariables.PM_URID = Convert.ToInt32(dtGrid_Assign_TANs.Rows[e.RowIndex].Cells["manager_ur_id"].Value.ToString());

                    if (dgvAssignTANs.Columns.Contains("supervisor_ur_id"))
                    {
                        GlobalVariables.Supvisr_URID = Convert.ToInt32(dgvAssignTANs.Rows[e.RowIndex].Cells["supervisor_ur_id"].Value.ToString());
                    }

                    DataTable dtPatentDtls = CASRxnDataAccess.GetPatentDetailsOnTAN(SelectedTAN);

                    if (dtPatentDtls != null)
                    {
                        if (dtPatentDtls.Rows.Count > 0)
                        {
                            SelTANDetails = dtPatentDtls;
                            DialogResult = DialogResult.OK;
                            this.Close();
                        }
                        else
                        {
                            if (MessageBox.Show("No data found for the selected TAN \r\n Do you want to load it as new TAN?", "No data", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                            {
                                IsNewTan = true;
                                BatchName = dgvAssignTANs.Rows[e.RowIndex].Cells["bname"].Value.ToString();
                                BatchNo = dgvAssignTANs.Rows[e.RowIndex].Cells["bno"].Value.ToString();

                                DialogResult = DialogResult.OK;
                                this.Close();
                            }
                        }
                    }
                    else
                    {
                        if (MessageBox.Show("No data found for the selected TAN \r\n Do you want to load it as new TAN?", "No data", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            IsNewTan = true;
                            BatchName = dgvAssignTANs.Rows[e.RowIndex].Cells["batchname"].Value.ToString();
                            BatchNo = dgvAssignTANs.Rows[e.RowIndex].Cells["batchno"].Value.ToString();

                            DialogResult = DialogResult.OK;
                            this.Close();
                        }
                    }
                }
                else if (strColName.ToUpper() == "VIEW")//View PDF 
                {
                    Cursor = Cursors.WaitCursor;

                    string strTAN_Pdf = dgvAssignTANs.Rows[e.RowIndex].Cells["tan"].Value.ToString();
                    strTAN_Pdf = strTAN_Pdf + ".pdf";
                    string strBatch = dgvAssignTANs.Rows[e.RowIndex].Cells["BName"].Value.ToString();

                    if (strBatch.Trim() != "")
                    {
                        strBatch = strBatch.Replace("rxnfile.", "");
                    }                  

                    FolderBrowserDialog objFDialog = new FolderBrowserDialog();
                    if (objFDialog.ShowDialog() == DialogResult.OK)
                    {
                        string strFilePath = objFDialog.SelectedPath;
                        string strPdfPath = strFilePath + "\\" + strTAN_Pdf;
                        if (!File.Exists(strPdfPath))
                        {
                            #region Linux code commented on 26th March 2013
                            //string strServerpath = "/root/CASREACT_V2/TAN_Pdfs/" + strBatch.Trim() + "/";
                            //string strError_Out = "";

                            //if (CAS_Classes.DownloadPdf.CallPSCPAndDownLoadFile(strTAN_Pdf, strServerpath, strFilePath, out strError_Out))
                            //{
                            //    System.Diagnostics.Process.Start(strPdfPath);
                            //}
                            //else
                            //{
                            //    MessageBox.Show(strError_Out, "View PDF", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            //} 
                            #endregion

                            //New Windows server code as on 26th March 2013
                            string strAppBase = Application.StartupPath.ToString();
                            string strServerpath = @"\TAN_Pdfs\" + strBatch.Trim() + "\\" + strTAN_Pdf;
                            string strError_Out = "";
                            if (CAS_Classes.DownloadPdf.DownloadFileFromWindowsServer(strServerpath, strPdfPath, out strError_Out))
                            {
                                System.Diagnostics.Process.Start(strPdfPath);
                            }
                            else
                            {
                                MessageBox.Show(strError_Out, "View PDF", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            System.Diagnostics.Process.Start(strPdfPath);
                        }
                    }
                }
                else if (strColName.ToUpper() == "NUMS")//Get NUMs 
                {
                    Cursor = Cursors.WaitCursor;

                    string strTAN = dgvAssignTANs.Rows[e.RowIndex].Cells["tan"].Value.ToString();
                    string strBatchName = dgvAssignTANs.Rows[e.RowIndex].Cells["BName"].Value.ToString();
                    string strCgmPath = AppDomain.CurrentDomain.BaseDirectory + strBatchName + ".cgm";
                    if (File.Exists(strCgmPath))
                    {
                        FormCollection frmColl = Application.OpenForms;
                        frmNUMSearch objNumSrch = null;
                        foreach (Form frm in frmColl)
                        {
                            if (frm.Name.ToUpper() == "FRMNUMSEARCH")
                            {
                                objNumSrch = (frmNUMSearch)frm;
                                objNumSrch.Close();
                                break;
                            }
                        }
                        objNumSrch = new frmNUMSearch();
                        objNumSrch.TAN = strTAN;
                        //objNumSrch.CAN = "";// txtCAN.Text.Trim();
                        objNumSrch.BatchName = strBatchName;
                        objNumSrch.Show();
                    }
                    else
                    {
                        MessageBox.Show(strBatchName + ".cgm file not found in the setup folder", "CGM not found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    Cursor = Cursors.Default;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
                
        private void txtTAN_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilterDataAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtTanStatus_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilterDataAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtAssignBy_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilterDataAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtAssignbyRole_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilterDataAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtAssignTo_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilterDataAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtAssignToRole_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilterDataAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
