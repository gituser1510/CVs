﻿namespace IndxReactNarr.TaskManagement
{
    partial class frmTaskComments_Indexing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtIndexingTaskComments = new System.Windows.Forms.TextBox();
            this.txtIndexingMarkUpPdfPath = new System.Windows.Forms.TextBox();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.splContComp = new System.Windows.Forms.SplitContainer();
            this.dgvTANNUMs = new System.Windows.Forms.DataGridView();
            this.lblTANHeader = new System.Windows.Forms.Label();
            this.dgvMarkupNUMs = new System.Windows.Forms.DataGridView();
            this.lblMarkupHeader = new System.Windows.Forms.Label();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.lblUserComments = new System.Windows.Forms.Label();
            this.btnBrowsePDF = new System.Windows.Forms.Button();
            this.lblPdfpath = new System.Windows.Forms.Label();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.pnlTANCnts = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTANNumsCnt = new System.Windows.Forms.Label();
            this.pnlMarkupCnts = new System.Windows.Forms.Panel();
            this.lblMarkupNumsCnt = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNUM_TN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPAR_TN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNUM_MN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRole_MN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splContComp)).BeginInit();
            this.splContComp.Panel1.SuspendLayout();
            this.splContComp.Panel2.SuspendLayout();
            this.splContComp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTANNUMs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMarkupNUMs)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.pnlBottom.SuspendLayout();
            this.pnlTANCnts.SuspendLayout();
            this.pnlMarkupCnts.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtIndexingTaskComments
            // 
            this.txtIndexingTaskComments.Location = new System.Drawing.Point(114, 3);
            this.txtIndexingTaskComments.Multiline = true;
            this.txtIndexingTaskComments.Name = "txtIndexingTaskComments";
            this.txtIndexingTaskComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtIndexingTaskComments.Size = new System.Drawing.Size(896, 71);
            this.txtIndexingTaskComments.TabIndex = 1;
            // 
            // txtIndexingMarkUpPdfPath
            // 
            this.txtIndexingMarkUpPdfPath.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.txtIndexingMarkUpPdfPath.Location = new System.Drawing.Point(114, 78);
            this.txtIndexingMarkUpPdfPath.Name = "txtIndexingMarkUpPdfPath";
            this.txtIndexingMarkUpPdfPath.ReadOnly = true;
            this.txtIndexingMarkUpPdfPath.Size = new System.Drawing.Size(859, 25);
            this.txtIndexingMarkUpPdfPath.TabIndex = 0;
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.splContComp);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1013, 462);
            this.pnlMain.TabIndex = 1;
            // 
            // splContComp
            // 
            this.splContComp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splContComp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContComp.Location = new System.Drawing.Point(0, 107);
            this.splContComp.Name = "splContComp";
            // 
            // splContComp.Panel1
            // 
            this.splContComp.Panel1.Controls.Add(this.dgvTANNUMs);
            this.splContComp.Panel1.Controls.Add(this.pnlTANCnts);
            this.splContComp.Panel1.Controls.Add(this.lblTANHeader);
            // 
            // splContComp.Panel2
            // 
            this.splContComp.Panel2.Controls.Add(this.dgvMarkupNUMs);
            this.splContComp.Panel2.Controls.Add(this.pnlMarkupCnts);
            this.splContComp.Panel2.Controls.Add(this.lblMarkupHeader);
            this.splContComp.Size = new System.Drawing.Size(1013, 325);
            this.splContComp.SplitterDistance = 495;
            this.splContComp.SplitterWidth = 3;
            this.splContComp.TabIndex = 6;
            // 
            // dgvTANNUMs
            // 
            this.dgvTANNUMs.AllowUserToAddRows = false;
            this.dgvTANNUMs.AllowUserToDeleteRows = false;
            this.dgvTANNUMs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTANNUMs.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvTANNUMs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTANNUMs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colNUM_TN,
            this.colPAR_TN});
            this.dgvTANNUMs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTANNUMs.Location = new System.Drawing.Point(0, 22);
            this.dgvTANNUMs.Name = "dgvTANNUMs";
            this.dgvTANNUMs.ReadOnly = true;
            this.dgvTANNUMs.Size = new System.Drawing.Size(491, 272);
            this.dgvTANNUMs.TabIndex = 2;
            this.dgvTANNUMs.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvTANNUMs_RowPostPaint);
            // 
            // lblTANHeader
            // 
            this.lblTANHeader.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTANHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTANHeader.Location = new System.Drawing.Point(0, 0);
            this.lblTANHeader.Name = "lblTANHeader";
            this.lblTANHeader.Size = new System.Drawing.Size(491, 22);
            this.lblTANHeader.TabIndex = 0;
            this.lblTANHeader.Text = "TAN NUMs";
            this.lblTANHeader.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dgvMarkupNUMs
            // 
            this.dgvMarkupNUMs.AllowUserToAddRows = false;
            this.dgvMarkupNUMs.AllowUserToDeleteRows = false;
            this.dgvMarkupNUMs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvMarkupNUMs.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvMarkupNUMs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMarkupNUMs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colNUM_MN,
            this.colRole_MN});
            this.dgvMarkupNUMs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvMarkupNUMs.Location = new System.Drawing.Point(0, 22);
            this.dgvMarkupNUMs.Name = "dgvMarkupNUMs";
            this.dgvMarkupNUMs.ReadOnly = true;
            this.dgvMarkupNUMs.Size = new System.Drawing.Size(511, 272);
            this.dgvMarkupNUMs.TabIndex = 3;
            this.dgvMarkupNUMs.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvMarkupNUMs_RowPostPaint);
            // 
            // lblMarkupHeader
            // 
            this.lblMarkupHeader.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMarkupHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblMarkupHeader.Location = new System.Drawing.Point(0, 0);
            this.lblMarkupHeader.Name = "lblMarkupHeader";
            this.lblMarkupHeader.Size = new System.Drawing.Size(511, 22);
            this.lblMarkupHeader.TabIndex = 1;
            this.lblMarkupHeader.Text = "Markup NUMs";
            this.lblMarkupHeader.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pnlTop
            // 
            this.pnlTop.Controls.Add(this.txtIndexingTaskComments);
            this.pnlTop.Controls.Add(this.txtIndexingMarkUpPdfPath);
            this.pnlTop.Controls.Add(this.lblUserComments);
            this.pnlTop.Controls.Add(this.btnBrowsePDF);
            this.pnlTop.Controls.Add(this.lblPdfpath);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1013, 107);
            this.pnlTop.TabIndex = 7;
            // 
            // lblUserComments
            // 
            this.lblUserComments.AutoSize = true;
            this.lblUserComments.Location = new System.Drawing.Point(6, 6);
            this.lblUserComments.Name = "lblUserComments";
            this.lblUserComments.Size = new System.Drawing.Size(104, 17);
            this.lblUserComments.TabIndex = 2;
            this.lblUserComments.Text = "User Comments";
            // 
            // btnBrowsePDF
            // 
            this.btnBrowsePDF.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBrowsePDF.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowsePDF.Location = new System.Drawing.Point(978, 79);
            this.btnBrowsePDF.Name = "btnBrowsePDF";
            this.btnBrowsePDF.Size = new System.Drawing.Size(31, 23);
            this.btnBrowsePDF.TabIndex = 4;
            this.btnBrowsePDF.Text = "...";
            this.btnBrowsePDF.UseVisualStyleBackColor = true;
            this.btnBrowsePDF.Click += new System.EventHandler(this.btnBrowsePDF_Click);
            // 
            // lblPdfpath
            // 
            this.lblPdfpath.AutoSize = true;
            this.lblPdfpath.Location = new System.Drawing.Point(3, 82);
            this.lblPdfpath.Name = "lblPdfpath";
            this.lblPdfpath.Size = new System.Drawing.Size(108, 17);
            this.lblPdfpath.TabIndex = 3;
            this.lblPdfpath.Text = "Markup Pdf path";
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom.Controls.Add(this.btnSubmit);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 432);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(1013, 30);
            this.pnlBottom.TabIndex = 5;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSubmit.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.Location = new System.Drawing.Point(936, 0);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(74, 27);
            this.btnSubmit.TabIndex = 6;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // pnlTANCnts
            // 
            this.pnlTANCnts.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTANCnts.Controls.Add(this.lblTANNumsCnt);
            this.pnlTANCnts.Controls.Add(this.label1);
            this.pnlTANCnts.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlTANCnts.Location = new System.Drawing.Point(0, 294);
            this.pnlTANCnts.Name = "pnlTANCnts";
            this.pnlTANCnts.Size = new System.Drawing.Size(491, 27);
            this.pnlTANCnts.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "TAN NUMs count: ";
            // 
            // lblTANNumsCnt
            // 
            this.lblTANNumsCnt.AutoSize = true;
            this.lblTANNumsCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTANNumsCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblTANNumsCnt.Location = new System.Drawing.Point(134, 4);
            this.lblTANNumsCnt.Name = "lblTANNumsCnt";
            this.lblTANNumsCnt.Size = new System.Drawing.Size(18, 17);
            this.lblTANNumsCnt.TabIndex = 7;
            this.lblTANNumsCnt.Text = "--";
            // 
            // pnlMarkupCnts
            // 
            this.pnlMarkupCnts.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlMarkupCnts.Controls.Add(this.lblMarkupNumsCnt);
            this.pnlMarkupCnts.Controls.Add(this.label3);
            this.pnlMarkupCnts.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlMarkupCnts.Location = new System.Drawing.Point(0, 294);
            this.pnlMarkupCnts.Name = "pnlMarkupCnts";
            this.pnlMarkupCnts.Size = new System.Drawing.Size(511, 27);
            this.pnlMarkupCnts.TabIndex = 4;
            // 
            // lblMarkupNumsCnt
            // 
            this.lblMarkupNumsCnt.AutoSize = true;
            this.lblMarkupNumsCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMarkupNumsCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblMarkupNumsCnt.Location = new System.Drawing.Point(134, 4);
            this.lblMarkupNumsCnt.Name = "lblMarkupNumsCnt";
            this.lblMarkupNumsCnt.Size = new System.Drawing.Size(18, 17);
            this.lblMarkupNumsCnt.TabIndex = 7;
            this.lblMarkupNumsCnt.Text = "--";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 17);
            this.label3.TabIndex = 0;
            this.label3.Text = "TAN NUMs count: ";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.FillWeight = 25.38071F;
            this.dataGridViewTextBoxColumn1.HeaderText = "NUM";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 225;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.FillWeight = 174.6193F;
            this.dataGridViewTextBoxColumn2.HeaderText = "PAR";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 224;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "NUM";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 467;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Seq";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 233;
            // 
            // colNUM_TN
            // 
            this.colNUM_TN.FillWeight = 25.38071F;
            this.colNUM_TN.HeaderText = "NUM";
            this.colNUM_TN.Name = "colNUM_TN";
            this.colNUM_TN.ReadOnly = true;
            // 
            // colPAR_TN
            // 
            this.colPAR_TN.FillWeight = 174.6193F;
            this.colPAR_TN.HeaderText = "PAR";
            this.colPAR_TN.Name = "colPAR_TN";
            this.colPAR_TN.ReadOnly = true;
            // 
            // colNUM_MN
            // 
            this.colNUM_MN.HeaderText = "NUM";
            this.colNUM_MN.Name = "colNUM_MN";
            this.colNUM_MN.ReadOnly = true;
            // 
            // colRole_MN
            // 
            this.colRole_MN.HeaderText = "Role";
            this.colRole_MN.Name = "colRole_MN";
            this.colRole_MN.ReadOnly = true;
            // 
            // frmTaskComments_Indexing
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1013, 462);
            this.Controls.Add(this.pnlMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmTaskComments_Indexing";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Indexing Task Comments";
            this.Load += new System.EventHandler(this.frmTaskComments_Indexing_Load);
            this.pnlMain.ResumeLayout(false);
            this.splContComp.Panel1.ResumeLayout(false);
            this.splContComp.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splContComp)).EndInit();
            this.splContComp.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTANNUMs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMarkupNUMs)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlBottom.ResumeLayout(false);
            this.pnlTANCnts.ResumeLayout(false);
            this.pnlTANCnts.PerformLayout();
            this.pnlMarkupCnts.ResumeLayout(false);
            this.pnlMarkupCnts.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.TextBox txtIndexingTaskComments;
        public System.Windows.Forms.TextBox txtIndexingMarkUpPdfPath;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.SplitContainer splContComp;
        private System.Windows.Forms.Label lblTANHeader;
        private System.Windows.Forms.Label lblMarkupHeader;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Label lblUserComments;
        private System.Windows.Forms.Button btnBrowsePDF;
        private System.Windows.Forms.Label lblPdfpath;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridView dgvTANNUMs;
        private System.Windows.Forms.DataGridView dgvMarkupNUMs;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNUM_TN;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPAR_TN;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNUM_MN;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRole_MN;
        private System.Windows.Forms.Panel pnlTANCnts;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTANNumsCnt;
        private System.Windows.Forms.Panel pnlMarkupCnts;
        private System.Windows.Forms.Label lblMarkupNumsCnt;
        private System.Windows.Forms.Label label3;
    }
}