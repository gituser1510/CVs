﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarrDAL;
using System.Collections;
using IndxReactNarr.Generic;
using IndxReactNarr.Common;

namespace IndxReactNarr.TaskManagement
{
    public partial class frmTaskAssignment : Form
    {
        public frmTaskAssignment()
        {
            InitializeComponent();
        }

        #region Public variables
               
        public DataTable AvailableTANsTbl
        {
            get;
            set;
        }
             
        public DataTable AppModuleUsers
        {
            get;
            set;
        }
                       
        Int64 teamUserID = 0;

        #endregion

        #region Private Methods
        
        private void SetApplicationModulesToComboBox()
        {
            try
            {
                //Set Module on Application
                if (!string.IsNullOrEmpty(GlobalVariables.ApplicationName))
                {
                    List<string> lstAppModules = new List<string>();

                    string strAppName = GlobalVariables.ApplicationName.ToUpper();

                    if (GlobalVariables.ApplicationName.ToUpper() == Enums.ApplicationName.NARRATIVES.ToString() || GlobalVariables.ApplicationName.ToUpper() == Enums.ApplicationName.EXPPROCEDURES.ToString())
                    {
                        lstAppModules.Add(Enums.ModuleName.NAR.ToString());
                    }
                    else if (GlobalVariables.ApplicationName.ToUpper() == Enums.ApplicationName.REACT.ToString())
                    {
                        lstAppModules.Add(Enums.ModuleName.RXN.ToString());
                    }
                    else if (GlobalVariables.ApplicationName.ToUpper() == Enums.ApplicationName.ORGANIC.ToString() || GlobalVariables.ApplicationName.ToUpper() == Enums.ApplicationName.MACRO.ToString())
                    {
                        lstAppModules.Add(Enums.ModuleName.INDX.ToString());
                        lstAppModules.Add(Enums.ModuleName.RXN.ToString());
                    }                    

                    if (lstAppModules.Count > 0)
                    {
                        cmbModule.DataSource = lstAppModules;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void SetApplicationShipmentsToComboBox()
        {
            try
            {
                if (!string.IsNullOrEmpty(GlobalVariables.ApplicationName))
                {
                    DataTable dtTanTypes = null;
                    DataTable dtShipments = null;
                    dtShipments = ReactDB.GetShipmentDetailsByAppName(GlobalVariables.ApplicationName, out dtTanTypes);
                    if (dtShipments != null)
                    {
                        cmbShipment.DataSource = dtShipments;
                        cmbShipment.ValueMember = "SHIPMENT_ID";
                        cmbShipment.DisplayMember = "SHIPMENT_NAME";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void SetApplicationModuleUsersToComboBox()
        {
            try
            {
                if (!string.IsNullOrEmpty(GlobalVariables.ApplicationName))
                {
                    string strModule = cmbModule.SelectedValue.ToString();

                    DataTable dtModuleUsers = null;
                    dtModuleUsers = ReactDB.GetUsersByApplicationModule(GlobalVariables.ApplicationName, strModule);
                    if (dtModuleUsers != null)
                    {
                        AppModuleUsers = dtModuleUsers;

                        cmbCurator.DataSource = dtModuleUsers;
                        cmbCurator.ValueMember = "ANLST_UR_ID";
                        cmbCurator.DisplayMember = "ANLST_NAME";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetUsersTaskCountAndBindToGrid()
        {
            try
            {
                if (!string.IsNullOrEmpty(GlobalVariables.ApplicationName))
                {
                    string strModule = cmbModule.SelectedValue.ToString();

                    DataTable dtTaskCounts = ReactDB.GetUserTaskCountsOnApplicationModule(GlobalVariables.ApplicationName, strModule);
                    if (dtTaskCounts != null)
                    {
                        dgvTaskCounts.AutoGenerateColumns = false;
                        dgvTaskCounts.DataSource = dtTaskCounts;

                        colUserName_TC.DataPropertyName = "USER_NAME";
                        colRoleName_TC.DataPropertyName = "ROLE_NAME";                        
                        colAssignedCnt_TC.DataPropertyName = "ASSIGNED_CNT";
                        colInPrgressCnt_TC.DataPropertyName = "PROGRESS_CNT";                       
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetAssignedTANsAndBindToGrid()
        {
            try
            {
                string strApplication = GlobalVariables.ApplicationName;
                string strModule = cmbModule.SelectedValue.ToString();
                int shipmentID = Convert.ToInt32(cmbShipment.SelectedValue);
                int batchNo = Convert.ToInt32(cmbBatchNo.SelectedItem.ToString());

                DataTable dtAssignedTANs = TaskManagementDB.GetAssignedTANsOnShipment(strApplication, strModule, shipmentID, batchNo);
                dgvAssignedTANs.DataSource = dtAssignedTANs;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetUnAssignedTANsAndBindToControl()
        {
            try
            {
                //TANs on Phase,Shipment,userid and roleid
                if (cmbShipment.SelectedItem != null && cmbBatchNo.SelectedItem != null)
                {
                    Cursor = Cursors.WaitCursor;

                    int shipmentID = Convert.ToInt32(cmbShipment.SelectedValue);
                    int batchNo = Convert.ToInt32(cmbBatchNo.SelectedItem.ToString());
                    string moduleName = cmbModule.Text;

                    DataTable dtTANs = ReactDB.GetUnAssignedTANSOnShipment(GlobalVariables.ApplicationName, moduleName, shipmentID, batchNo);
                    if (dtTANs != null)
                    {
                        if (dtTANs.Rows.Count > 0)
                        {
                            AvailableTANsTbl = dtTANs;
                            BindDataToUnAssignedTANsGrid(dtTANs);
                        }
                        else
                        {
                            AvailableTANsTbl = null;
                            BindDataToUnAssignedTANsGrid(dtTANs);
                        }
                    }
                    else
                    {
                        AvailableTANsTbl = null;
                        BindDataToUnAssignedTANsGrid(dtTANs);
                    }

                    ////Get already assigned TANs
                    //DataTable dtAssTANDetails = CASRxnDataAccess.GetPM_SupervisorTANs(cmbShipment.SelectedItem.ToString(), Convert.ToInt32(cmbBatchNo.SelectedItem.ToString()), GlobalVariables.UserRoleID, GlobalVariables.URID);
                    //if (dtAssTANDetails != null)
                    //{
                    //    dgAssignedTANS.DataSource = dtAssTANDetails;

                    //}

                    Cursor = Cursors.Default;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindDataToUnAssignedTANsGrid(DataTable unassignedTANs)
        {
            try
            {
                if (unassignedTANs != null)
                {
                    dgvUnAssignedTANs.AutoGenerateColumns = false;
                    dgvUnAssignedTANs.DataSource = unassignedTANs;

                    colAvl_BT_ID.DataPropertyName = "TAN_ID";
                    colAvl_TAN.DataPropertyName = "TAN_NAME";
                    colAvl_TAN_Type.DataPropertyName = "TAN_TYPE";
                    colDocClass_Avl.DataPropertyName = "DOC_CLASS";
                    colTANPriority_Avl.DataPropertyName = "TAN_PRIORITY";

                   
                }
                else
                {
                    dgvUnAssignedTANs.DataSource = unassignedTANs;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private List<int> GetSelectedTAN_IDsFromGrid()
        {
            List<int> selTANsList = null;
            try
            {
                if (dgvUnAssignedTANs.Rows.Count > 0)
                {
                    if (dgvUnAssignedTANs.SelectedRows.Count > 0)
                    {
                        selTANsList = new List<int>();
                        DataGridViewSelectedRowCollection selRowColl = dgvUnAssignedTANs.SelectedRows;
                        if (selRowColl != null)
                        {
                            if (selRowColl.Count > 0)
                            {
                                for (int i = 0; i < selRowColl.Count; i++)
                                {
                                    selTANsList.Add(Convert.ToInt32(selRowColl[i].Cells[0].Value));
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return selTANsList;
        }

        private string GetFilterCondition(string _query_tan)
        {
            string strFCond = "";
            try
            {
                if (_query_tan.Trim().Contains(";"))
                {
                    string[] splitter = { ";" };
                    string[] strArrTans = _query_tan.Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);

                    if (strArrTans != null)
                    {
                        if (strArrTans.Length > 0)
                        {
                            for (int i = 0; i < strArrTans.Length; i++)
                            {
                                if (i == 0)
                                {
                                    strFCond = "TAN_NAME Like '" + strArrTans[i] + "%' ";
                                }
                                else
                                {
                                    strFCond += " OR" + " TAN_NAME Like '" + strArrTans[i] + "%'";
                                }
                            }
                        }
                    }
                }
                else
                {
                    strFCond = "TAN_NAME Like '" + _query_tan.Trim() + "%'";
                }
                return strFCond;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strFCond;
        }         
        
        #endregion

        #region Events

        private void btnAssign_Click(object sender, EventArgs e)
        {
            try
            {
                List<int> selTANIDs = GetSelectedTAN_IDsFromGrid();

                if (selTANIDs != null)
                {
                    if (selTANIDs.Count > 0)
                    {
                        string strApplication = GlobalVariables.ApplicationName;
                        string strModule = cmbModule.SelectedValue.ToString();
                        int shipmentID = Convert.ToInt32(cmbShipment.SelectedValue);
                        int batchNo = Convert.ToInt32(cmbBatchNo.SelectedItem.ToString());
                        if (TaskManagementDB.UpdateTaskAssignmentDetails(strApplication, strModule, shipmentID, teamUserID, selTANIDs))
                        {
                            MessageBox.Show("Task assigned successfully");

                            //Get UnAssigned TANs
                            GetUnAssignedTANsAndBindToControl();

                            //Get User Task Counts in the Module
                            GetUsersTaskCountAndBindToGrid();

                            //Get Assigned TANs
                            GetAssignedTANsAndBindToGrid();
                        }
                        else
                        {
                            MessageBox.Show("Error");
                        }
                    }
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void frmTaskAssignment_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;

                cmbBatchNo.SelectedIndex = 0;

                int userID = IndxReactNarr.Generic.GlobalVariables.UserID;
                int userRoleID = IndxReactNarr.Generic.GlobalVariables.RoleID;
                int urID = IndxReactNarr.Generic.GlobalVariables.URID;
                string userRole = IndxReactNarr.Generic.GlobalVariables.RoleName;

                //GlobalVariables.ApplicationName = "ORGANIC";

                //Set applicaton modules to combobox
                SetApplicationModulesToComboBox();

                //Get Application Shipments and bind to combobox
                SetApplicationShipmentsToComboBox();

                //Get Application Module Users
                //SetApplicationModuleUsersToComboBox();

                //Get User Task counts
                //GetUsersTaskCountAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void cancelAssignmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvAssignedTANs.SelectedRows.Count == 1)
                {
                    DialogResult diaRes = MessageBox.Show("Do you want to cancel the task assignment?", "Cancel Task", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (diaRes == DialogResult.Yes)
                    {
                        int Ass_By_URID = GlobalVariables.URID;
                        string strTan = dgvAssignedTANs.Rows[dgvAssignedTANs.CurrentCell.RowIndex].Cells["tan"].Value.ToString();
                        string Ass_to_User = dgvAssignedTANs.Rows[dgvAssignedTANs.CurrentCell.RowIndex].Cells["assigned to user"].Value.ToString();
                        string Ass_to_URole = dgvAssignedTANs.Rows[dgvAssignedTANs.CurrentCell.RowIndex].Cells["role"].Value.ToString();
                        string tanStatus = dgvAssignedTANs.Rows[dgvAssignedTANs.CurrentCell.RowIndex].Cells["tan status"].Value.ToString();

                        //if (ReactDB.DeleteTaskAssignmentDetails(strTan, Ass_By_URID, Ass_to_User, Ass_to_URole, tanStatus))
                        //{
                        //    #region Code Commented
                        //    ////Refresh Assigned TANs grid to refrect changes
                        //    //DataTable dtAssTANDetails = CASRxnDataAccess.GetPM_SupvisorTANs_BName_BNo_UID_RoleID(cmbBatch.SelectedItem.ToString(), Convert.ToInt32(cmbBatchNo.SelectedItem.ToString()), Generic.GlobalVariables.UserRoleID, Generic.GlobalVariables.URID);
                        //    //if (dtAssTANDetails != null)
                        //    //{
                        //    //    dtGridAssigedTANs.DataSource = dtAssTANDetails;
                        //    //} 
                        //    #endregion

                        //    GetUnAssignedTANsAndBindToControl();

                        //    MessageBox.Show("Task assignment cancelled successfully", "Cancel Assignment", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //}
                        //else
                        //{
                        //    MessageBox.Show("Error in Task assignment cancellation", "Cancel Assignment", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //}
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtTANSrch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (AvailableTANsTbl != null)
                {
                    if (txtTANSrch.Text.Trim() != "")
                    {
                        string strFCond = GetFilterCondition(txtTANSrch.Text.Trim());

                        DataTable dtAllTANs = AvailableTANsTbl.Copy();
                        DataView dvTemp = dtAllTANs.DefaultView;
                        dvTemp.RowFilter = strFCond;
                        DataTable dtTANs = dvTemp.ToTable();
                        dgvUnAssignedTANs.DataSource = dtTANs;
                    }
                    else
                    {
                        DataTable dtAllTANs = AvailableTANsTbl.Copy();
                        dgvUnAssignedTANs.DataSource = dtAllTANs;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnGetTANs_Click(object sender, EventArgs e)
        {
            try
            {
                //Get UnAssigned TANs
                GetUnAssignedTANsAndBindToControl();

                //Get Assigned TANs
                GetAssignedTANsAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void cmbCurator_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbCurator.SelectedItem != null && AppModuleUsers != null)
                {

                    if (!string.IsNullOrEmpty(cmbCurator.Text.ToString()))
                    {
                        var rows = from r in AppModuleUsers.AsEnumerable()
                                   where r.Field<string>("ANLST_NAME") == cmbCurator.Text.ToString()
                                   select new
                                   {
                                       Reviewer = r.Field<string>("REV_ANLST_NAME"),
                                       QC = r.Field<string>("QUAL_ANLST_NAME"),
                                       TeamUserID = r.Field<Int64>("TEAM_USER_ID")
                                   };
                        if (rows != null)
                        {
                            foreach (var r in rows)
                            {
                                txtReviewer.Text = r.Reviewer;
                                txtQC.Text = r.QC;
                                teamUserID = r.TeamUserID;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        #region Grid RowPostPaint Events

        private void dtGridAssigedTANs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {                
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvAssignedTANs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvAssignedTANs.Font);

                if (dgvAssignedTANs.RowHeadersWidth < (int)(size.Width + 20)) dgvAssignedTANs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void dtGrid_TANs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {             
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvAssignedTANs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvAssignedTANs.Font);

                if (dgvAssignedTANs.RowHeadersWidth < (int)(size.Width + 20)) dgvAssignedTANs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;

                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dtGridSelTANs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {                
                string strRowNumber = (e.RowIndex + 1).ToString();
             
                while (strRowNumber.Length < dgvAssignedTANs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;
                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvAssignedTANs.Font);
                if (dgvAssignedTANs.RowHeadersWidth < (int)(size.Width + 20)) dgvAssignedTANs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;

                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       

        private void dgvTaskCounts_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvTaskCounts.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;
                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvTaskCounts.Font);
                if (dgvTaskCounts.RowHeadersWidth < (int)(size.Width + 20)) dgvTaskCounts.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;

                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        private void cmbModule_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //Ger User Task Count on Module
                GetUsersTaskCountAndBindToGrid();

                //Set Module Users
                SetApplicationModuleUsersToComboBox();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

    }
}
