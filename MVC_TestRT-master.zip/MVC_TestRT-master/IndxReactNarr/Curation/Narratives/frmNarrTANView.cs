﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr;
using System.IO;
using System.Collections;
using IndxReactNarrDAL;
using IndxReactNarrBll;
using mshtml;
using System.Diagnostics;
using IndxReactNarrDAL;
using IndxReactNarr.CAS_Classes;
using HtmlRichText;
using IndxReactNarrBLL;
using IndxReactNarr.Generic;
using CAS_Narrative.ErrorList;

namespace IndxReactNarr
{
    public partial class frmNarrTANView : Form
    {
        public frmNarrTANView()
        {
            InitializeComponent();
        }       
       
        private IndxReactNarrBLL.clsCASChild _tandetails = null;
        private IndxReactNarrBLL.clsCASChild TanDetails
        {
            get { return _tandetails; }
            set { _tandetails = value; }
        }
        private IndxReactNarrBll.clsMaster _tanMaster = null;
        public IndxReactNarrBll.clsMaster TanMaster
        {
            get { return _tanMaster; }
            set { _tanMaster = value; }
        }
        private int _AssignedUserRoleID = 0;
        private int _AssignedRoleID = 0;

        public int AssignedRoleID
        {
            get { return _AssignedRoleID; }
            set { _AssignedRoleID = value; }
        }
        public int AssignedUserRoleID
        {
            get { return _AssignedUserRoleID; }
            set { _AssignedUserRoleID = value; }
        }

        #region public variables declarations
        AutoCompleteStringCollection _autocompleSupplementID = new AutoCompleteStringCollection();
        //AutoCompleteStringCollection _autocompledocrefs = new AutoCompleteStringCollection();
        //AutoCompleteStringCollection _autoCompleRxnNum = new AutoCompleteStringCollection();
        //AutoCompleteStringCollection _autoCompleRxnSEQ = new AutoCompleteStringCollection();
        //AutoCompleteStringCollection _autocompleNarrative = new AutoCompleteStringCollection();
        List<clsMaster> LstDocument = new List<clsMaster>();
        clsMaster objmaster = new clsMaster();
        List<clsCASChild> LstDocumentDetails = new List<clsCASChild>();
        //OCRImageToText ImageToText_OCR = new OCRImageToText();
        private int _Document_ID = 0;
        public int Document_ID
        {
            get { return _Document_ID; }
            set { _Document_ID = value; }
        }
        private int _Rxn_ID = 0;
        public int Rxn_ID
        {
            get { return _Rxn_ID; }
            set { _Rxn_ID = value; }
        }
        private bool _ISEditMode = false;
        public bool ISEditMode
        {
            get { return _ISEditMode; }
            set { _ISEditMode = value; }
        }
        private bool _ISViewMode = false;
        public bool ISVIewMode
        {
            get { return _ISViewMode; }
            set { _ISViewMode = value; }
        }
        int recordcount = 0;
        int documentid = 0;
        int reactionID = 0;
        DataSet dsFandR = new DataSet();

        #endregion

        
        public static DataTable dtDocumet_ids = null;

        DataSet dsreportview = null;
        DataSet dsTanFileNames = null;
        public static List<clsCASChild> _lsttanchild = null;

        #region New Properties by Sairam on 20th June 2014

        public int TAN_ID { get; set; }
        public string TAN_Name { get; set; }
        public string TAN_Type { get; set; }
        public DataTable TANDetails { get; set; }
        public DataTable TAN_Documents { get; set; }
        public DataTable TAN_Reactions { get; set; }

        #endregion

        private void frmNarrTANView_Load(object sender, EventArgs e)
        {
            try
            {
                TAN_ID = 2427;//Testing

                this.WindowState = FormWindowState.Maximized;
                dgviewer.MouseMode = GdViewerPro4.ViewerMouseMode.MouseModeAreaSelection;

                if (TAN_ID > 0)
                {
                    //TAN Details
                    if (TANDetails != null)
                    {
                        if (TANDetails.Rows.Count > 0)
                        {
                            txtTAN.Text = TANDetails.Rows[0]["TAN_NAME"].ToString();
                            txtCAN.Text = TANDetails.Rows[0]["CAN"].ToString();
                            txtDOI.Text = TANDetails.Rows[0]["DOI"].ToString();
                            txtTANType.Text = TANDetails.Rows[0]["TAN_TYPE"].ToString();

                            TAN_Name = TANDetails.Rows[0]["TAN_NAME"].ToString();
                            TAN_Type = TANDetails.Rows[0]["TAN_TYPE"].ToString();
                        }
                    }

                    //Get TAN Documents and bind to grid
                    GetTanDocumentsAndBindToGrid();

                    //Get TAN Reactions and bind to TreeView
                    TAN_Reactions = IndxReactNarrDAL.NarrativesDataAccess.GetTANReactionsOnTANID(TAN_ID);
                    UpdateReactionsTreeView_New();
                }
                



                if (Generic.GlobalVariables.UserRole.ToUpper() == "QUALITY CHECK")
                {
                    chkIsRxnComplete.Enabled = false;

                }
                else if (Generic.GlobalVariables.UserRole.ToUpper() == "REVIEWER" || Generic.GlobalVariables.UserRole.ToUpper() == "REVIEWER2")
                {
                    chkIsRxnComplete.Enabled = false;
                }

                // Retreiving list of strings to heighlight.
                //Generic.GlobalVariables.NarrHighlightData = DataOperations.GetSpecialCharsHighlightList(TAN_Type);
                                   
                                                 
                try
                {
                    dsFandR = null;// CASNarrativeDataAccess.GetFindAndReplaceWords(Generic.GlobalVariables.IsPatent);
                    Generic.GlobalVariables.DsFindAndReplace = dsFandR;
                    LoadSymbols();

                    int irow = 0;
                    ///Edit mode
                    if (ISEditMode == true)
                    {
                        if (TAN_Name != null)
                        {

                            LoadNumSeqToList();
                                                     
                            this.Cursor = Cursors.WaitCursor;
                            LoadMasterAndReactionsData();
                        }
                    }

                    UpdateReactionsTreeView();
                    

                }
                catch (Exception ex)
                {
                    ErrorHandling.WriteErrorLog(ex.ToString());
                }
                finally
                {
                    this.Cursor = Cursors.Default;                   
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        /// <summary>
        /// Get TAN documents and bind to grid
        /// </summary>
        private void GetTanDocumentsAndBindToGrid()
        {
            try
            {
                TAN_Documents = NarrativesDataAccess.GetTANDocumentsOnTANID(TAN_ID);                               
               
                dgvTANDocuments.AutoGenerateColumns = false;
                dgvTANDocuments.DataSource = TAN_Documents;
                colDocID.DataPropertyName = "TAN_DOC_ID";
                colDocName.DataPropertyName = "FILE_NAME";
                
                //Code commented by Sairam on 2nd July 2014
                //uccasnartool_new1.FillDocrefs();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void LoadMasterAndReactionsData()
        {

            dsreportview = IndxReactNarrDAL.NarrativesDataAccess.GetTANReportView(TAN_Name, "TAN");

            if (dsreportview != null)
            {
                if (dsreportview.Tables.Count > 0)
                {
                    if (dsreportview.Tables[0].Rows.Count > 0)
                    {
                        _lsttanchild = new List<IndxReactNarrBll.clsCASChild>();
                        IndxReactNarrBll.clsMaster _tanmaster = new IndxReactNarrBll.clsMaster();

                        IndxReactNarrDAL.CASNarrativeDataAccess.GetDocumentDetailsDataSet(dsreportview, out  _lsttanchild, out _tanmaster);
                        if (Generic.globalVariables.HtNumAndSeq != null)
                            lblreccountvalue.Text = _lsttanchild.Count.ToString() + "/" + Generic.GlobalVariables.HtNumAndSeq.Count.ToString();

                        txtCAN.Text = _tanmaster.CAN;
                        txtDOI.Text = _tanmaster.DOI;
                        //txtjournalid.Text = _tanmaster.JournalArticalID;
                        //txtsupplid.Text = _tanmaster.SupplementID;
                        txtTAN.Text = _tanmaster.TAN;
                        Hashtable _htusercontrolsymbols = FillSymbolsfromControls();

                    }
                    else
                    {
                        GenerateNarIdsIfNotExists();                      
                    }
                }               
            }            
        }

        private void LoadNumSeqToList()
        {
            try
            {
                if (Generic.GlobalVariables.UserRole.ToUpper() != "CURATOR")
                    this.Text = cas_narrative_schemaDataAccess.DAL.DataOperations.GetTANHistoryAgainstTanID(TAN_Name, Generic.GlobalVariables.UserRole);

                List<Generic.TanNumAndSeq> lstTANNumAndSeq = new List<IndxReactNarr.Generic.TanNumAndSeq>();
                int shipment_id = Generic.GlobalVariables.Shipment_ID;
                dsTabNumandSeq = IndxReactNarrDAL.CASNarrativeDataAccess.GetTANNumandsequece(TAN_Name, shipment_id);
                if (dsTabNumandSeq != null)
                {
                    if (dsTabNumandSeq.Tables.Count > 0)
                    {
                        for (int i = 0; i < dsTabNumandSeq.Tables[0].Rows.Count; i++)
                        {
                            if (dsTabNumandSeq.Tables[0].Rows[i]["num_seq"] != null)
                            {
                                string strnumandseq = dsTabNumandSeq.Tables[0].Rows[i]["num_seq"].ToString();
                                char[] c = new char[1] { ';' };
                                char[] s = new char[1] { ' ' };
                                string[] strvalues = strnumandseq.Split(c, StringSplitOptions.None);
                                if (strvalues != null)
                                {
                                    if (strvalues.Length > 0)
                                    {
                                        for (int j = 0; j < strvalues.Length; j++)
                                        {
                                            Generic.TanNumAndSeq tns = new IndxReactNarr.Generic.TanNumAndSeq();
                                            tns.TAN = txtTAN.Text;
                                            string[] strnumsandseqs = strvalues[j].Split(s);
                                            if (strnumsandseqs != null)
                                            {
                                                if (strnumsandseqs.Length == 4)
                                                {
                                                    tns.NUM = Convert.ToInt32(strnumsandseqs[1]);
                                                    tns.SEQ = Convert.ToInt32(strnumsandseqs[3]);
                                                }
                                            }
                                            lstTANNumAndSeq.Add(tns);
                                        }
                                    }
                                }


                            }
                        }
                        Generic.GlobalVariables.HtNumAndSeq = lstTANNumAndSeq;


                    }

                }
            }

            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }      

        private void UpdateReactionsTreeView()
        {
            try
            {
                dtDocumet_ids = IndxReactNarr.DAL.CASNarrativeDataAccess.CheckAndGenerateReactionIds(TAN_Name, Generic.GlobalVariables.HtNumAndSeq.Count);

                tvRxns.Nodes.Clear();
                tvRxns.Nodes.Add(TAN_Name);

                if (_lsttanchild != null)
                {
                    // DataTable dt = dsreportview.Tables[0];
                    if (_lsttanchild.Count == Generic.GlobalVariables.HtNumAndSeq.Count)
                    {
                        //for (int i = 0; i < Generic.globalVariables.HtNumAndSeq.Count; i++)
                        for (int i = 0; i < dtDocumet_ids.Rows.Count; i++)
                        {
                            string narId = System.DBNull.Value.Equals(dtDocumet_ids.Rows[i]["narativeid"]) || (dtDocumet_ids.Rows[i]["narativeid"] == null) ? "" : (string)dtDocumet_ids.Rows[i]["narativeid"];

                            if ((bool)dtDocumet_ids.Rows[i]["is_analogous"])
                            {
                                // analogousTo = System.DBNull.Value.Equals(dtDocumet_ids.Rows[i]["analogous_to_nar"]) || (dtDocumet_ids.Rows[i]["analogous_to_nar"] == null) ? "" : (string)dtDocumet_ids.Rows[i]["analogous_to_nar"];
                                if (!System.DBNull.Value.Equals(dtDocumet_ids.Rows[i]["analogous_to_nar"]))
                                {
                                    int temp = Convert.ToInt32(dtDocumet_ids.Rows[i]["analogous_to_nar"]);
                                    var a = ((from row in dtDocumet_ids.AsEnumerable().Where(r => r.Field<int>("id") == temp) select row.Field<string>("narativeid")).First());
                                    narId += " analogousTo=" + a;
                                }
                            }

                            TreeNode completedNode = new TreeNode();
                            completedNode.Text = Generic.GlobalVariables.HtNumAndSeq[i].NUM + "_" + Generic.GlobalVariables.HtNumAndSeq[i].SEQ + "-" + narId;// dtDocumet_ids.Rows[i]["narativeid"]; //_lsttanchild[i].NarrativeID;
                            completedNode.Tag = dtDocumet_ids.Rows[i]["id"];
                            if (dtDocumet_ids.Rows[i]["curation_complete_status"].ToString().ToUpper() == "FALSE")
                            {
                                completedNode.ForeColor = Color.Red;
                            }
                            else
                            {
                                completedNode.ForeColor = Color.Green;
                            }
                            tvRxns.Nodes[0].Nodes.Add(completedNode);
                            // treeView1.Nodes[0].Nodes.Add(_lsttanchild[i].NarrativeID);
                        }
                    }
                    else
                    {
                        dsreportview = IndxReactNarr.DAL.CASNarrativeDataAccess.GetTANReportView(TAN_Name, "TAN");
                        IndxReactNarrBll.clsMaster _tanmaster = new IndxReactNarrBll.clsMaster();
                        IndxReactNarrDAL.CASNarrativeDataAccess.GetDocumentDetailsDataSet(dsreportview, out  _lsttanchild, out _tanmaster);
                        if (_lsttanchild.Count == Generic.GlobalVariables.HtNumAndSeq.Count)
                        {
                            UpdateReactionsTreeView();
                        }
                    }                   
                }
               
                tvRxns.ExpandAll();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        /// <summary>
        /// Add Reactions to TreeView
        /// </summary>
        private void UpdateReactionsTreeView_New()
        {
            try
            {
                if (TAN_Reactions != null)
                {
                    //Clear Nodes, if any
                    tvRxns.Nodes.Clear();

                    if (TAN_Reactions.Rows.Count > 0)
                    {                       
                        tvRxns.Nodes.Add(TAN_Name);

                        for (int i = 0; i < TAN_Reactions.Rows.Count; i++)
                        {
                            TreeNode tnRxn = new TreeNode();
                            tnRxn.Tag = TAN_Reactions.Rows[i]["RXN_ID"].ToString();
                                                       
                            string narID = (TAN_Reactions.Rows[i]["DISPLAY_ORDER"] == null) ? "Nar1" : "Nar" + (string)TAN_Reactions.Rows[i]["DISPLAY_ORDER"];

                            if ((bool)dtDocumet_ids.Rows[i]["IS_ANALOGOUS"])
                            {                                
                                if (!System.DBNull.Value.Equals(dtDocumet_ids.Rows[i]["ANALOGOUS_RXN_ID"]))
                                {
                                    int temp = Convert.ToInt32(dtDocumet_ids.Rows[i]["ANALOGOUS_RXN_ID"]);
                                    var a = ((from row in dtDocumet_ids.AsEnumerable().Where(r => r.Field<int>("RXN_ID") == temp) select row.Field<string>("DISPLAY_ORDER")).First());
                                    narID += " analogousTo=" + a;
                                }
                            }

                            tnRxn.ToolTipText = TAN_Reactions.Rows[i]["RXN_NUM"].ToString() + "-" + TAN_Reactions.Rows[i]["RXN_SEQ"].ToString();
                            tnRxn.Text = narID;

                            if (TAN_Reactions.Rows[i]["CURATION_COMPLETE_STATUS"].ToString().ToUpper() == "FALSE")
                            {
                                tnRxn.ForeColor = Color.Red;
                            }
                            else
                            {
                                tnRxn.ForeColor = Color.Green;
                            }
                            tvRxns.Nodes[0].Nodes.Add(tnRxn);
                        }
                    }
                }   

                tvRxns.ExpandAll();

                tvRxns.SelectedNode = tvRxns.Nodes[0].Nodes[0];
                tvRxns.Select();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GenerateNarIdsIfNotExists()
        {
            try
            {
                dtDocumet_ids = IndxReactNarr.DAL.CASNarrativeDataAccess.CheckAndGenerateReactionIds(TAN, Generic.globalVariables.HtNumAndSeq.Count);
                _lsttanchild = new List<IndxReactNarrBll.clsCASChild>();
                IndxReactNarrBll.clsMaster _tanmaster = new IndxReactNarrBll.clsMaster();
                dsreportview = IndxReactNarr.DAL.CASNarrativeDataAccess.GetTANReportView(TAN, "TAN");
                IndxReactNarrDAL.CASNarrativeDataAccess.GetDocumentDetailsDataSet(dsreportview, out  _lsttanchild, out _tanmaster);
            }
            catch (Exception)
            {
                throw;
            }
        }

        HtmlRichTextBox htmlrichtextbox = new HtmlRichTextBox();
        DataTable dtReaction = null;
        private void tvRxns_AfterSelect(object sender, TreeViewEventArgs e)
        {
            try
            {
                TreeNode node;
                node = e.Node;
                if (node != null)
                {
                    #region oldcode
                    // string[] treeviewtext = node.Text.Split('-').ToArray<string>();
                    // if (treeviewtext.Length > 1)
                    // {
                    //string Narid = treeviewtext[1].Split(' ')[0];
                    //string RxnId = treeviewtext[0].Split('_')[0];
                    //string SeqNum = treeviewtext[0].Split('_')[1];

                    //if (Narid.Contains("nar"))
                    //{
                    //    bool isRxnExist = false;
                    //    if (_lsttanchild != null)
                    //    {
                    //        for (int i = 0; i < _lsttanchild.Count; i++)
                    //        {
                    //            if (_lsttanchild[i].NarrativeID == Narid)
                    //            {
                    //                if (dsreportview != null)
                    //                {
                    //                    if (dsreportview.Tables.Count > 0)
                    //                    {
                    //                        if (dsreportview.Tables[0].Rows.Count > 0)
                    //                        {
                    //                            uccasnartool_new1.ResetFields();
                    //                            int _documentid = CASNarrativeDataAccess.GetDocumentID(txttan.Text.Trim(), txtcan.Text.Trim());
                    //                            Hashtable _htusercontrolsymbols = FillSymbolsfromControls();
                    //                            //  uccasnartool_new uc = new uccasnartool_new();

                    //                            //pnlUserControl.Controls.Clear();
                    //                            //pnlUserControl.Controls.Add(uc);
                    //                            uccasnartool_new1.Rxn_ID = Convert.ToInt32(_lsttanchild[i].ReactionID.ToString());
                    //                            uccasnartool_new1.TanDetails = (CAS_Nar_Bll.clsCASChild)_lsttanchild[i];
                    //                            uccasnartool_new1.HtSymbols = _htusercontrolsymbols;
                    //                            uccasnartool_new1.loadFields();

                    //                            uccasnartool_new1.reactionID = Convert.ToInt32(_lsttanchild[i].ReactionID);
                    //                            uccasnartool_new1.documentid = Convert.ToInt32(_lsttanchild[i].DocumentID);
                    //                            uccasnartool_new1.Dock = DockStyle.Fill;
                    //                            uccasnartool_new1.transferToTextEditorToolStripMenuItem.Click += new EventHandler(transferToTextEditorToolStripMenuItem_Click);
                    //                            // uc.txtnarrativeid.Leave += new EventHandler(txtnarrativeid_Leave);
                    //                            //uc.txtCASReactnumber.Leave += new EventHandler(txtrxnseq_Leave);
                    //                            //   uc.txtrxnseq.Leave += new EventHandler(txtrxnseq_Leave);
                    //                            uccasnartool_new1.TAN = txttan.Text;
                    //                            uccasnartool_new1.rtxtparapreview.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
                    //                            uccasnartool_new1.rtxttextlinepreview.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
                    //                            uccasnartool_new1.txtpara1.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
                    //                            uccasnartool_new1.rtxtdatapreview.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
                    //                            uccasnartool_new1.rtxtdata1.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
                    //                            uccasnartool_new1.txtdocref.Leave += new EventHandler(txtdocref_Leave);
                    //                            //uc.btnDelete.Click += new EventHandler(btnDelete_Click);
                    //                            //tableLayoutPanel1.Controls.Clear();
                    //                            //tableLayoutPanel1.Controls.Add(uc, 0, 0);
                    //                            //tableLayoutPanel1.ScrollControlIntoView((Control)uc);

                    //                            isRxnExist = true;
                    //                        }
                    //                    }
                    //                }
                    //            }
                    //        }
                    //        if (!isRxnExist)
                    //        {
                    //            uccasnartool_new1.ResetFields();
                    //            FillTANCANDOIDetails(TAN);
                    //            clsCASChild obj = new clsCASChild();
                    //            obj.ReactionCasReactantNumber = Convert.ToInt32(RxnId);
                    //            obj.Rxnseq = Convert.ToInt32(SeqNum);
                    //            obj.NarrativeID = Narid;
                    //            _lsttanchild.Add(obj);

                    //            Hashtable _htusercontrolsymbols = FillSymbolsfromControls();
                    //            int ir = 0;
                    //            int _documentid = CASNarrativeDataAccess.GetDocumentID(txttan.Text.Trim(), txtcan.Text.Trim());
                    //            CAS_Nar_Bll.clsCASChild _tandetails = new clsCASChild();
                    //            documentid = _documentid;
                    //            //   uccasnartool_new uc = new uccasnartool_new();
                    //            //  pnlUserControl.Controls.Clear();
                    //            // pnlUserControl.Controls.Add(uc);

                    //            //    uc.TanDetails = _tandetails;
                    //            uccasnartool_new1.TanDetails = (CAS_Nar_Bll.clsCASChild)_lsttanchild[_lsttanchild.Count - 1];
                    //            uccasnartool_new1.HtSymbols = _htusercontrolsymbols;
                    //            uccasnartool_new1.loadFields();


                    //            //     uc.Name = "ucnew" + System.DateTime.Now.Millisecond.ToString();
                    //            uccasnartool_new1.Dock = DockStyle.Fill;
                    //            // uc.txtnarrativeid.Leave += new EventHandler(txtnarrativeid_Leave);
                    //            //  uc.txtCASReactnumber.Leave += new EventHandler(txtrxnseq_Leave);
                    //            //  uc.txtrxnseq.Leave += new EventHandler(txtrxnseq_Leave);
                    //            uccasnartool_new1.HtSymbols = FillSymbolsfromControls();
                    //            uccasnartool_new1.documentid = _documentid;
                    //            //if (CheckReactionIDexist(DAL.CASNarrativeDataAccess.GetReactionid(_documentid)))
                    //            //{
                    //            uccasnartool_new1.reactionID = DAL.CASNarrativeDataAccess.GetReactionid_New(_documentid);
                    //            //}
                    //            //else
                    //            //    uc.reactionID = DAL.CASNarrativeDataAccess.GetReactionid(_documentid) +100;

                    //            //uc.btnDelete.Click += new EventHandler(btnDelete_Click);
                    //            uccasnartool_new1.TAN = txttan.Text;
                    //            uccasnartool_new1.rtxtparapreview.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
                    //            uccasnartool_new1.rtxttextlinepreview.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
                    //            uccasnartool_new1.txtpara1.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
                    //            uccasnartool_new1.rtxtdatapreview.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
                    //            uccasnartool_new1.rtxtdata1.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
                    //            uccasnartool_new1.txtdocref.Leave += new EventHandler(txtdocref_Leave);
                    //            // uc.txtCASReactnumber.Focus();

                    //            //uc.txtCASReactnumber = _lsttanchild[i].ReactionCasReactantNumber.ToString();
                    //            //uc.txtrxnseq = _lsttanchild[i].Rxnseq.ToString();
                    //            //uc.txtnarrativeid = _lsttanchild[i].NarrativeID.ToString();

                    //            //tableLayoutPanel1.Controls.Clear();
                    //            //tableLayoutPanel1.Controls.Add(uc, 0, 0);
                    //            //tableLayoutPanel1.ScrollControlIntoView((Control)uc);
                    //            //uc.FillFilename();
                    //            isRxnExist = true;
                    //        }
                    //    }
                    //}  
                    #endregion
                    if (node.Tag != null)
                    {
                        LoadReaction(Convert.ToInt32(node.Tag));
                    }
                    //}
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void LoadReaction(int reactionId)
        {
            try
            {
                dtReaction = IndxReactNarr.DAL.CASNarrativeDataAccess.GetReactionById(reactionId);
                uccasnartool_new1.ResetFields();
                chkIsRxnComplete.Checked = false;
               

                #region oldcode
                // clsCASChild obj = new clsCASChild();
                //obj.ReactionCasReactantNumber = Convert.ToInt32(dtReaction.Rows[0]["casreactnum"].ToString());
                //obj.Rxnseq = Convert.ToInt32(dtReaction.Rows[0]["reactionseq"].ToString());
                //if (Narid.Contains("analogousTo="))
                //{
                //    obj.NarrativeID = Narid.Split(' ')[0];
                //}
                //else
                //{
                //    obj.NarrativeID = Narid;
                //}
                // obj.NarrativeID = System.DBNull.Value.Equals(dtReaction.Rows[0]["narativeid"]) || (dtReaction.Rows[0]["narativeid"] == null) ? "" : (string)dtReaction.Rows[0]["narativeid"];
                // _lsttanchild.Add(obj); 
                #endregion

                Hashtable _htusercontrolsymbols = FillSymbolsfromControls();
                int ir = 0;
                int _documentid = CASNarrativeDataAccess.GetDocumentID(txtTAN.Text.Trim(), txtCAN.Text.Trim());
                IndxReactNarrBll.clsCASChild _tandetails = new clsCASChild();
                documentid = _documentid;
                //   uccasnartool_new uc = new uccasnartool_new();
                //  pnlUserControl.Controls.Clear();
                // pnlUserControl.Controls.Add(uc);

                //    uc.TanDetails = _tandetails;
                uccasnartool_new1.TanDetails = (IndxReactNarrBll.clsCASChild)_lsttanchild[_lsttanchild.Count - 1];
                uccasnartool_new1.HtSymbols = _htusercontrolsymbols;
                //uccasnartool_new1.loadFields();

                uccasnartool_new1.txtrxnseq.Text = dtReaction.Rows[0]["reactionseq"].ToString();
                uccasnartool_new1.txtCASReactnumber.Text = (string)dtReaction.Rows[0]["casreactnum"].ToString();
                uccasnartool_new1.txtdocref.Text = System.DBNull.Value.Equals(dtReaction.Rows[0]["docref"]) || (dtReaction.Rows[0]["docref"] == null) ? "" : (string)dtReaction.Rows[0]["docref"];
                uccasnartool_new1.txtpagenumber.Text = System.DBNull.Value.Equals(dtReaction.Rows[0]["pagenumber"]) || (dtReaction.Rows[0]["pagenumber"] == null) ? "" : dtReaction.Rows[0]["pagenumber"].ToString();
                uccasnartool_new1.txtpagelabel.Text = System.DBNull.Value.Equals(dtReaction.Rows[0]["pagelabel"]) || (dtReaction.Rows[0]["pagelabel"] == null) ? "" : dtReaction.Rows[0]["pagelabel"].ToString();
                uccasnartool_new1.txtfilename.Text = System.DBNull.Value.Equals(dtReaction.Rows[0]["xresunit"]) || (dtReaction.Rows[0]["xresunit"] == null) ? "" : dtReaction.Rows[0]["filename"].ToString();
                //uccasnartool_new1.txtxpageunit.Text = System.DBNull.Value.Equals(dtReactions.Rows[0]["xresunit"]) ? "" : (string)dtReactions.Rows[0]["xresunit"];
                uccasnartool_new1.txtxoffset.Text = System.DBNull.Value.Equals(dtReaction.Rows[0]["xoffset"]) || (dtReaction.Rows[0]["xoffset"] == null) ? "" : dtReaction.Rows[0]["xoffset"].ToString();
                uccasnartool_new1.txtxpagesize.Text = System.DBNull.Value.Equals(dtReaction.Rows[0]["xpagesize"]) || (dtReaction.Rows[0]["xpagesize"] == null) ? "" : dtReaction.Rows[0]["xpagesize"].ToString();
                uccasnartool_new1.txtyoffset.Text = System.DBNull.Value.Equals(dtReaction.Rows[0]["yoffset"]) || (dtReaction.Rows[0]["yoffset"] == null) ? "" : dtReaction.Rows[0]["yoffset"].ToString();
                uccasnartool_new1.txtypagesize.Text = System.DBNull.Value.Equals(dtReaction.Rows[0]["ypagesize"]) || (dtReaction.Rows[0]["ypagesize"] == null) ? "" : dtReaction.Rows[0]["ypagesize"].ToString();
                uccasnartool_new1.chkisGeneralTypical.Checked = System.DBNull.Value.Equals(dtReaction.Rows[0]["isgeneraltypical"]) || (dtReaction.Rows[0]["isgeneraltypical"] == null) ? false : (bool)dtReaction.Rows[0]["isgeneraltypical"];
                uccasnartool_new1.chkisgeneralprocempty.Checked = System.DBNull.Value.Equals(dtReaction.Rows[0]["noexperimentaldetails"]) || (dtReaction.Rows[0]["noexperimentaldetails"] == null) ? false : (bool)dtReaction.Rows[0]["noexperimentaldetails"];
                string Nar = System.DBNull.Value.Equals(dtReaction.Rows[0]["narativeid"]) || (dtReaction.Rows[0]["narativeid"] == null) ? "" : dtReaction.Rows[0]["narativeid"].ToString();
                if (Nar != "")
                {
                    uccasnartool_new1.SetNarId(Nar);
                }
                uccasnartool_new1.chkIsMissingRxn.Checked = System.DBNull.Value.Equals(dtReaction.Rows[0]["is_missing_reaction"]) || (dtReaction.Rows[0]["is_missing_reaction"] == null) ? false : (bool)dtReaction.Rows[0]["is_missing_reaction"];
                uccasnartool_new1.chkIsAnalogous.Checked = System.DBNull.Value.Equals(dtReaction.Rows[0]["is_analogous"]) || (dtReaction.Rows[0]["is_analogous"] == null) ? false : (bool)dtReaction.Rows[0]["is_analogous"];
                if (uccasnartool_new1.chkIsAnalogous.Checked)
                {
                    string AnalogousTo = System.DBNull.Value.Equals(dtReaction.Rows[0]["analogous_to_nar"]) || (dtReaction.Rows[0]["analogous_to_nar"] == null) ? "" : dtReaction.Rows[0]["analogous_to_nar"].ToString();
                    uccasnartool_new1.FillNarIdToComboBox();
                    //var a = from row in dtDocumet_ids.AsEnumerable().Where(r => r.Field<string>("analogous_to_nar") == AnalogousTo) select row;
                    var a = ((from row in dtDocumet_ids.AsEnumerable().Where(r => r.Field<int>("id") == Convert.ToInt32(AnalogousTo)) select row.Field<string>("narativeid")).First());


                    uccasnartool_new1.cmbAnalogousTo.SelectedIndex = uccasnartool_new1.cmbAnalogousTo.FindStringExact(a.ToString());
                }

                ConvertHtmlToRtf(dtReaction.Rows[0]["textline"].ToString(), htmlrichtextbox);
                uccasnartool_new1.rtxttextlinepreview.Rtf = htmlrichtextbox.Rtf;
                ConvertHtmlToRtf(dtReaction.Rows[0]["para"].ToString(), htmlrichtextbox);
                uccasnartool_new1.rtxtparapreview.Rtf = htmlrichtextbox.Rtf;
                ConvertHtmlToRtf(dtReaction.Rows[0]["para1"].ToString(), htmlrichtextbox);
                uccasnartool_new1.txtpara1.Rtf = htmlrichtextbox.Rtf;
                ConvertHtmlToRtf(dtReaction.Rows[0]["data"].ToString(), htmlrichtextbox);
                uccasnartool_new1.rtxtdatapreview.Rtf = htmlrichtextbox.Rtf;
                ConvertHtmlToRtf(dtReaction.Rows[0]["data1"].ToString(), htmlrichtextbox);
                uccasnartool_new1.rtxtdata1.Rtf = htmlrichtextbox.Rtf;

                uccasnartool_new1.rtxttextlinepreview.Tag = System.DBNull.Value.Equals(dtReaction.Rows[0]["textline"]) || (dtReaction.Rows[0]["textline"] == null) ? "" : dtReaction.Rows[0]["textline"].ToString();
                uccasnartool_new1.rtxtdatapreview.Tag = System.DBNull.Value.Equals(dtReaction.Rows[0]["data"]) || (dtReaction.Rows[0]["data"] == null) ? "" : dtReaction.Rows[0]["data"].ToString();
                uccasnartool_new1.rtxtparapreview.Tag = System.DBNull.Value.Equals(dtReaction.Rows[0]["para"]) || (dtReaction.Rows[0]["para"] == null) ? "" : dtReaction.Rows[0]["para"].ToString();
                uccasnartool_new1.txtpara1.Tag = System.DBNull.Value.Equals(dtReaction.Rows[0]["para1"]) || (dtReaction.Rows[0]["para1"] == null) ? "" : dtReaction.Rows[0]["para1"].ToString();
                uccasnartool_new1.rtxtdata1.Tag = System.DBNull.Value.Equals(dtReaction.Rows[0]["data1"]) || (dtReaction.Rows[0]["data1"] == null) ? "" : dtReaction.Rows[0]["data1"].ToString();

                //     uc.Name = "ucnew" + System.DateTime.Now.Millisecond.ToString();
                // uccasnartool_new1.Dock = DockStyle.Fill;
                // uc.txtnarrativeid.Leave += new EventHandler(txtnarrativeid_Leave);
                //  uc.txtCASReactnumber.Leave += new EventHandler(txtrxnseq_Leave);
                //  uc.txtrxnseq.Leave += new EventHandler(txtrxnseq_Leave);
                uccasnartool_new1.HtSymbols = FillSymbolsfromControls();
                uccasnartool_new1.documentid = _documentid;
                //if (CheckReactionIDexist(DAL.CASNarrativeDataAccess.GetReactionid(_documentid)))
                //{
                uccasnartool_new1.reactionID = reactionId; //DAL.CASNarrativeDataAccess.GetReactionid_New(_documentid);
                //}
                //else
                //    uc.reactionID = DAL.CASNarrativeDataAccess.GetReactionid(_documentid) +100;

                //uc.btnDelete.Click += new EventHandler(btnDelete_Click);
                uccasnartool_new1.TAN = txtTAN.Text;
                uccasnartool_new1.rtxtparapreview.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
                uccasnartool_new1.rtxttextlinepreview.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
                uccasnartool_new1.txtpara1.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
                uccasnartool_new1.rtxtdatapreview.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
                uccasnartool_new1.rtxtdata1.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
                //uccasnartool_new1.txtdocref.Leave += new EventHandler(txtdocref_Leave);

                chkIsRxnComplete.Checked = System.DBNull.Value.Equals(dtReaction.Rows[0]["curation_complete_status"]) || (dtReaction.Rows[0]["curation_complete_status"] == null) ? false : (bool)dtReaction.Rows[0]["curation_complete_status"];

                if (chkIsRxnComplete.Checked)
                {
                    chkIsRxnComplete.Enabled = false;
                }
                else
                {
                    chkIsRxnComplete.Enabled = true;
                }

                if (uccasnartool_new1.chkIsAnalogous.Checked)
                {
                    uccasnartool_new1.HighlightAnalogous();
                }

                //Highlight special charaters based on Journal/Patent
                uccasnartool_new1.HeighlightSplChrPatentJournal();

                // uc.txtCASReactnumber.Focus();

                //uc.txtCASReactnumber = _lsttanchild[i].ReactionCasReactantNumber.ToString();
                //uc.txtrxnseq = _lsttanchild[i].Rxnseq.ToString();
                //uc.txtnarrativeid = _lsttanchild[i].NarrativeID.ToString();

                //tableLayoutPanel1.Controls.Clear();
                //tableLayoutPanel1.Controls.Add(uc, 0, 0);
                //tableLayoutPanel1.ScrollControlIntoView((Control)uc);
                //uc.FillFilename();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        

        //private int GetPageNumberFromList(int _reactionid)
        //{
        //    int recnumber = 0;
        //    try
        //    {
        //        if (_lsttanchild.Count > 0)
        //        {
        //            for (int i = 0; i < _lsttanchild.Count; i++)
        //            {
        //                if (_lsttanchild[i].ReactionID == _reactionid)
        //                {
        //                    recnumber = i;
        //                    break;
        //                }
        //            }

        //            if (recnumber <= pagecount)
        //            {
        //                return 1;
        //            }
        //            else if (recnumber > pagecount)
        //            {
        //                int intmaxRec = _lsttanchild.Count;
        //                Double intcurrentpage = Convert.ToDouble(recnumber) / Convert.ToDouble(pagecount);
        //                intcurrentpage = Math.Ceiling(intcurrentpage);
        //                //_currentPage = _PageCount;
        //                _recNo = _pageSize * (Convert.ToInt32(intcurrentpage) - 1);

        //                return Convert.ToInt32(intcurrentpage);
        //            }
        //        }
        //        return 1;
        //    }
        //    catch (Exception ex)
        //    {
        //        return 1;
        //    }
        //}

        public void FillFilename(string _strtan)
        {
            try
            {
                if (Generic.globalVariables.DsTanFilenames != null)
                {

                    if (Generic.globalVariables.DsTanFilenames.Tables.Count > 0)
                    {
                        if (Generic.globalVariables.DsTanFilenames.Tables[0].Rows.Count > 0)
                        {
                            DataRow[] dr = Generic.globalVariables.DsTanFilenames.Tables[0].Select("TAN='" + _strtan + "'");

                            if (dr != null)
                            {
                                if (dr.Length > 0)
                                {
                                    if (dr[0]["doc1"] != null)
                                    {
                                        txtdocfilename.Text = dr[0]["doc1"].ToString();
                                    }
                                    else
                                        txtdocfilename.Text = "";

                                }
                            }



                        }

                    }

                }

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        //private void DisplayPageInfo()
        //{
        //    try
        //    {
        //        //txtpagenumber.Text = "Page " + _currentPage.ToString() + "/ " + _PageCount.ToString();
        //        txtpagenumber.TextChanged -= new EventHandler(txtpagenumber_TextChanged);
        //        txtpagenumber.Text = _currentPage.ToString();
        //        txtpagenumber.TextChanged += new EventHandler(txtpagenumber_TextChanged);
        //        lbltotalpagecountvalue.Text = _PageCount.ToString();
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.ToString());
        //    }
        //}

        //private void AddrecordstoTable()
        //{
        //    try
        //    {
        //        //int irows = 0;
        //        //if (count > 25)
        //        //    count = 25;
        //        //for (int i = 0; i < count; i++)
        //        //{
        //        uccasnartool_new uc = new uccasnartool_new();
        //        uc.Anchor = ((System.Windows.Forms.AnchorStyles)(((AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Right))));
        //        //uc.Name = i.ToString();
        //        uc.Dock = DockStyle.Fill;
        //        //irows = AddTableRow();
        //        //uc.rowindex = irows;
        //        pnlUserControl.Controls.Clear();
        //        pnlUserControl.Controls.Add(uc);
        //        //tableLayoutPanel1.Controls.Add(uc, 0, irows);
        //        // }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }

        //}

        //private void UpdateControlNamesInTable()
        //{
        //    //  if (tableLayoutPanel1.Controls.Count > 0)
        //    if (pnlUserControl.Controls.Count > 0)
        //    {
        //        int i = 0;
        //        foreach (Control c in pnlUserControl.Controls)
        //        {
        //            if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
        //            {
        //                uccasnartool_new uc = (uccasnartool_new)c;
        //                uc.Name = i.ToString();
        //                i++;
        //            }
        //        }
        //    }
        //}

        //private void LoadPage()
        //{
        //    int i;
        //    int startRec;
        //    int endRec;
        //    //DataTable dtTemp;
        //    int irow;
        //    ////Clone the source table to create a temporary table.

        //    try
        //    {
        //        this.Cursor = Cursors.WaitCursor;
        //        //if (_currentPage == _PageCount)
        //        //{

        //        //    endRec = _maxRec;
        //        //}
        //        //else
        //        //{
        //        //    endRec = _pageSize * _currentPage;
        //        //}
        //        //startRec = _recNo;

        //        Hashtable _htusercontrolsymbols = FillSymbolsfromControls();


        //        // _recNo = endRec;
        //        if (_lsttanchild != null)
        //        {
        //            int ir = 0;

        //            ////Copy rows from the source table to fill the temporary table.
        //            for (i = 0; i < 1; i++)
        //            {
        //                try
        //                {
        //                    if (_lsttanchild.Count == i)
        //                        break;

        //                    //  uccasnartool_new uc = GetUserCOntrolByName(ir.ToString());
        //                    if (uccasnartool_new1 != null)
        //                    {

        //                        uccasnartool_new1.Rxn_ID = Convert.ToInt32(_lsttanchild[i].ReactionID.ToString());
        //                        uccasnartool_new1.TanDetails = (CAS_Nar_Bll.clsCASChild)_lsttanchild[i];
        //                        uccasnartool_new1.HtSymbols = _htusercontrolsymbols;
        //                        uccasnartool_new1.loadFields();

        //                        uccasnartool_new1.reactionID = Convert.ToInt32(_lsttanchild[i].ReactionID);
        //                        uccasnartool_new1.documentid = Convert.ToInt32(_lsttanchild[i].DocumentID);
        //                        uccasnartool_new1.Dock = DockStyle.Fill;
        //                        uccasnartool_new1.transferToTextEditorToolStripMenuItem.Click += new EventHandler(transferToTextEditorToolStripMenuItem_Click);
        //                        // uc.txtnarrativeid.Leave += new EventHandler(txtnarrativeid_Leave);
        //                        //uc.txtCASReactnumber.Leave += new EventHandler(txtrxnseq_Leave);
        //                        //uc.txtrxnseq.Leave += new EventHandler(txtrxnseq_Leave);
        //                        uccasnartool_new1.TAN = txttan.Text;
        //                        uccasnartool_new1.rtxtparapreview.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
        //                        uccasnartool_new1.rtxttextlinepreview.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
        //                        uccasnartool_new1.txtpara1.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
        //                        uccasnartool_new1.rtxtdatapreview.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
        //                        uccasnartool_new1.rtxtdata1.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
        //                        uccasnartool_new1.txtdocref.Leave += new EventHandler(txtdocref_Leave);
        //                        //uc.btnDelete.Click += new EventHandler(btnDelete_Click);
        //                        ir++;
        //                    }
        //                }
        //                catch (Exception ex)
        //                {
        //                    ErrorHandling.WriteErrorLog(ex.ToString());
        //                }
        //            }

        //            //if (pagecount > 25)
        //            //    pagecount = 25;

        //            //if (ir < pagecount)
        //            //{
        //            //    int tbrcount = tableLayoutPanel1.RowStyles.Count;
        //            //    int c = tbrcount;
        //            //    do
        //            //    {

        //            //        tableLayoutPanel1.Controls.RemoveAt(c - 1);
        //            //        tableLayoutPanel1.RowStyles.RemoveAt(c - 1);
        //            //        c--;

        //            //    }
        //            //    while (c > ir);


        //            //    tableLayoutPanel1.AutoScroll = false;
        //            //    tableLayoutPanel1.AutoScroll = true;

        //            //}
        //        }


        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    finally
        //    {
        //        //DisplayPageInfo();
        //        this.Cursor = Cursors.Default;

        //    }
        //}

        void rtxtparapreview_KeyDown(object sender, KeyEventArgs e)
        {
            if (sender != null)
            {
                HtmlRichText.HtmlRichTextBox textbox = (HtmlRichText.HtmlRichTextBox)sender;
                if (textbox != null)
                {

                    if (e.KeyCode == Keys.F2)
                    {
                        //sub


                        //if (!textbox.IsSubScript())
                        //{
                        //    textbox.SetSuperScript(false);
                        //    textbox.SetSubScript(true);
                        //}
                        //else
                        //    textbox.SetSubScript(false);



                    }
                    else if (e.KeyCode == Keys.F3)
                    {
                        //sup
                        //if (!textbox.IsSuperScript())
                        //{
                        //    textbox.SetSuperScript(true);
                        //    textbox.SetSubScript(false);
                        //}
                        //else
                        //    textbox.SetSuperScript(false);
                    }
                    else if (e.KeyCode == Keys.F4)
                    {
                        //Italic

                        //if (textbox.SelectedText != null)
                        //{
                        //    if (textbox.SelectionFont == null)
                        //        textbox.SelectionFont = new Font(textbox.Font, textbox.Font.Style ^ FontStyle.Italic);
                        //    else
                        //        textbox.SelectionFont = new Font(textbox.SelectionFont, textbox.SelectionFont.Style ^ FontStyle.Italic);
                        //}


                    }
                    //else if (e.KeyCode == Keys.F5)
                    //{
                    //    //Bold

                    //    if (textbox.SelectedText != null)
                    //    {
                    //        if (textbox.SelectionFont == null)
                    //            textbox.SelectionFont = new Font(textbox.Font, textbox.Font.Style ^ FontStyle.Bold);
                    //        else
                    //            textbox.SelectionFont = new Font(textbox.SelectionFont, textbox.SelectionFont.Style ^ FontStyle.Bold);
                    //    }

                    //}
                    else if (e.KeyCode == Keys.F6)
                    {
                        //Convert

                        toolStripButton12_Click(null, null);


                    }
                }
            }



        }

        //private uccasnartool_new ShowSelectedRecord(int _reactionID)
        //{
        //    try
        //    {
        //        //    foreach (Control c in tableLayoutPanel1.Controls)
        //        foreach (Control c in pnlUserControl.Controls)
        //        {
        //            if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
        //            {
        //                uccasnartool_new uc = (uccasnartool_new)c;
        //                if (uc.Rxn_ID.ToString() == _reactionID.ToString())
        //                {

        //                    return uc;

        //                }
        //            }
        //        }
        //        return null;
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return null;
        //}

        //void txtrxnseq_Leave(object sender, EventArgs e)
        //{
        //    if (btnUpdate.Focused)
        //    {
        //        return;
        //    }


        //    try
        //    {
        //        TextBox t = (TextBox)sender;

        //        if (t.Text != null)
        //        {
        //            Int32 inti = 0;
        //            uccasnartool_new uc = GetUserCOntrolByName(t.Tag.ToString());
        //            if (t.Name.ToUpper() == "TXTRXNSEQ")
        //            {
        //                inti = Convert.ToInt32(t.Text);
        //            }
        //            else
        //                inti = Convert.ToInt32(uc.txtrxnseq.Text);



        //            if (!CheckAlreadyNumberAndSequenceExist(uc.txtCASReactnumber.Text, inti.ToString("0000"), t.Tag.ToString(), uc.reactionID))
        //            {
        //                MessageBox.Show("Reaction number and sequence already exists, please give different Sequence number", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //                uc.txtCASReactnumber.Focus();
        //            }


        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}

        //private bool CheckNumAndSequeceAgainstTan(string strNum, string strSeq)
        //{

        //    if (Generic.globalVariables.HtNumAndSeq != null)
        //    {
        //        if (Generic.globalVariables.HtNumAndSeq.Count > 0)
        //        {
        //            foreach (Generic.TanNumAndSeq tn in Generic.globalVariables.HtNumAndSeq)
        //            {
        //                if (tn.NUM.ToString("0000") == strNum.ToString() && tn.SEQ.ToString("0000") == strSeq.ToString())
        //                {
        //                    return true;
        //                }
        //            }
        //        }
        //    }
        //    return false;
        //}

        //void txtnarrativeid_Leave(object sender, EventArgs e)
        //{
        //    if (btnUpdate.Focused)
        //    {
        //        return;
        //    }

        //    try
        //    {
        //        if (sender != null)
        //        {
        //            TextBox txtnarrativeid = (TextBox)sender;
        //            if (txtnarrativeid.Text != null)
        //            {
        //                if (validations.Validatations.ValidateNarrativeID(txtnarrativeid.Text))
        //                {
        //                    if (!validations.Validatations.ValidateNArIDFormat(txtnarrativeid.Text))
        //                    {
        //                        if (MessageBox.Show("narid analogousTo narid's  can not be same", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information) == DialogResult.Cancel)
        //                        {
        //                        }
        //                        else
        //                            txtnarrativeid.Focus();
        //                        //return;
        //                    }

        //                }
        //                else
        //                {
        //                    if (MessageBox.Show("narid not in correct format, please check ", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information) == DialogResult.Cancel)
        //                    {

        //                    }
        //                    else
        //                        txtnarrativeid.Focus();

        //                }
        //            }


        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }


        //    #region MyRegion
        //    try
        //    {
        //        if (sender != null)
        //        {
        //            TextBox t = (TextBox)sender;
        //            if (t.Text != null)
        //            {
        //                string strnarid = "";
        //                if (t.Text.Contains("analogousTo="))
        //                {
        //                    string[] strsplit = new string[1] { "analogousTo=" };
        //                    string[] strtexts = t.Text.Split(strsplit, StringSplitOptions.RemoveEmptyEntries);

        //                    if (strtexts != null)
        //                    {
        //                        if (strtexts.Length > 0 && strtexts.Length == 2)
        //                        {
        //                            strnarid = strtexts[1];
        //                            if (CheckNaridAnalogoustoAnotherNarativeID(strnarid) == false)
        //                            {
        //                                MessageBox.Show("Nar ID : " + strnarid + " already analogousTo to some other nar id, Can't give analogousTo", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //                                t.Focus();
        //                                //return;
        //                            }

        //                        }
        //                    }

        //                }



        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    #endregion

        //}

        //private bool CheckNaridAnalogoustoAnotherNarativeID(string strnarid)
        //{
        //    try
        //    {
        //        if (_lsttanchild != null)
        //        {
        //            if (_lsttanchild.Count > 0)
        //            {
        //                for (int i = 0; i < _lsttanchild.Count; i++)
        //                {
        //                    if (_lsttanchild[i].NarrativeID.ToUpper().Trim() != strnarid.ToUpper() && _lsttanchild[i].NarrativeID.EndsWith(strnarid) == false)
        //                    {

        //                        if (_lsttanchild[i].NarrativeID.Contains("analogousTo="))
        //                        {
        //                            string[] strsplit = new string[1] { "analogousTo=" };
        //                            string[] strnars = _lsttanchild[i].NarrativeID.Split(strsplit, StringSplitOptions.None);
        //                            if (strnars != null)
        //                            {
        //                                if (strnars.Length > 0)
        //                                {
        //                                    if (strnars[0].Trim() == strnarid)
        //                                    {
        //                                        return false;
        //                                    }
        //                                }
        //                            }


        //                        }

        //                    }

        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return true;
        //    }
        //    return true;
        //}

        private bool CheckNarIDAnalogoustoNarIDparaFieldEmptry(string strucname)
        {
            try
            {
                //   foreach (Control c in tableLayoutPanel1.Controls)
                //foreach (Control c in pnlUserControl.Controls)
                //{
                //    if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
                //    {
                //        uccasnartool_new uc = (uccasnartool_new)c;
                //        if (uc.Name.ToUpper() == strucname.ToString().ToUpper())
                //        {
                if (IsRichTextboxIsEmptry(uccasnartool_new1.rtxtparapreview))
                {
                    return false;
                }
                else

                    return true;
                //        }
                //    }
                //}

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return false;
        }

        //private bool ValidateNarrativeID(TextBox t, string strucname, int rxnid)
        //{
        //    try
        //    {

        //        try
        //        {

        //            if (t.Text != null)
        //            {

        //                if (validations.Validatations.ValidateNarrativeID(t.Text))
        //                {
        //                    if (!validations.Validatations.ValidateNArIDFormat(t.Text))
        //                    {
        //                        MessageBox.Show("narid analogousTo narid's  can not be same", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //                        t.Focus();
        //                        return false;
        //                    }
        //                }
        //                else
        //                {
        //                    MessageBox.Show("narid not in correct format, please check ", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //                    t.Focus();
        //                    return false;
        //                }



        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            ErrorHandling.WriteErrorLog(ex.ToString());
        //        }



        //        if (t.Text != null)
        //        {
        //            string strnarid = "";
        //            if (t.Text.Contains("analogousTo="))
        //            {
        //                string[] strsplit = new string[1] { "analogousTo=" };
        //                string[] strtexts = t.Text.Split(strsplit, StringSplitOptions.RemoveEmptyEntries);

        //                if (strtexts != null)
        //                {
        //                    if (strtexts.Length > 0 && strtexts.Length == 2)
        //                    {
        //                        strnarid = strtexts[0];
        //                    }
        //                }


        //            }
        //            else
        //                strnarid = t.Text;

        //            if (DAL.CASNarrativeDataAccess.CheckNarrativeIDExists_new(documentid, strnarid, rxnid))
        //            {
        //                MessageBox.Show("Nar id already exists, please give different nar id", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //                uccasnartool_new uc = GetUserCOntrolByName(strucname);
        //                uc.txtnarrativeid.Focus();
        //                return false;

        //            }

        //            if (t.Text.Contains("analogousTo"))
        //            {
        //                string[] strsplit = new string[1] { "analogousTo=" };
        //                string[] strtexts = t.Text.Split(strsplit, StringSplitOptions.RemoveEmptyEntries);
        //                if (strtexts != null)
        //                {
        //                    if (strtexts.Length > 0 && strtexts.Length == 2)
        //                    {
        //                        if (DAL.CASNarrativeDataAccess.CheckParaExistsForNarativeID(documentid, strtexts[1]))
        //                        //if (!CheckParaExistfornar(strtexts[1], strucname, rxnid))
        //                        {
        //                            MessageBox.Show("Para1 field is empty, Can't give analogousTo " + strtexts[1], "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //                            uccasnartool_new uc = GetUserCOntrolByName(strucname);
        //                            uc.txtnarrativeid.Focus();
        //                            return false;

        //                        }
        //                    }
        //                    else
        //                        return true;
        //                }
        //            }

        //            return true;

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return false;
        //}

        //private bool CheckParaExistfornar(string strnarid, string strucname, int _reactionid)
        //{
        //    try
        //    {
        //        if (_lsttanchild != null)
        //        {
        //            for (int i = 0; i < _lsttanchild.Count; i++)
        //            {
        //                if (_lsttanchild[i].ReactionID != _reactionid)
        //                {
        //                    if (_lsttanchild[i].NarrativeID.ToUpper().Trim() == strnarid.ToUpper().Trim())
        //                    {
        //                        if (_lsttanchild[i].Para == "" || _lsttanchild[i].Para == null)
        //                        {
        //                            return true;
        //                        }
        //                        else
        //                        {
        //                            return false;
        //                        }

        //                    }

        //                }
        //            }
        //        }



        //        //foreach (Control c in tableLayoutPanel1.Controls)
        //        //{
        //        //    if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
        //        //    {
        //        //        uccasnartool uc = (uccasnartool)c;
        //        //        if (uc.Name != strucname)
        //        //        {
        //        //            if (uc.txtnarrativeid.Text.ToUpper().Trim() == strnarid.ToUpper().Trim())
        //        //            {
        //        //                if (IsRichTextboxIsEmptry(uc.rtxtparapreview))
        //        //                {
        //        //                    return true;
        //        //                }
        //        //                else
        //        //                {
        //        //                    return false;
        //        //                }

        //        //            }
        //        //        }
        //        //    }
        //        //}
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return false;
        //}

        //private bool CheckRichTextBoxEmpty(HtmlRichText.HtmlRichTextBox c)
        //{
        //    try
        //    {
        //        RTFtoHTML.Form1 objfrm = new RTFtoHTML.Form1();
        //        string strhtml = objfrm.ConvertToHTML(c);
        //        strhtml = validations.richtextvalidations.FindAndReplaceStrings(strhtml, dsFandR);
        //        strhtml = strhtml.Replace("\r\n", " ");
        //        strhtml = strhtml.Replace("\n", " ");
        //        strhtml = strhtml.Replace("  ", " ");

        //        strhtml = strhtml.Replace("<bold></bold>", "");
        //        strhtml = strhtml.Replace("<ital><bold></bold></ital>", "");
        //        strhtml = strhtml.Replace("<ital> </ital>", " ");
        //        strhtml = strhtml.Replace("<bold> </bold>", " ");
        //        strhtml = strhtml.Trim();
        //        if (strhtml.Length == 0)
        //        {
        //            return false;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return true;
        //}

        //private bool CheckAlreadyNarExist(string strnarid, string strucnmame)
        //{
        //    try
        //    {
        //        // foreach (Control c in tableLayoutPanel1.Controls)
        //        foreach (Control c in pnlUserControl.Controls)
        //        {
        //            if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
        //            {
        //                uccasnartool_new uc = (uccasnartool_new)c;
        //                if (uc.Name != strucnmame)
        //                {
        //                    if (uc.txtnarrativeid.Text.Trim().ToUpper() == strnarid.ToUpper().Trim())
        //                    {
        //                        return false;
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return true;
        //}

        //private bool CheckAlreadyNumberAndSequenceExist(string _strnum, string _strseq, string strucnmame)
        //{
        //    try
        //    {
        //        //foreach (Control c in tableLayoutPanel1.Controls)
        //        foreach (Control c in pnlUserControl.Controls)
        //        {
        //            if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
        //            {
        //                uccasnartool_new uc = (uccasnartool_new)c;
        //                if (uc.Name != strucnmame)
        //                {
        //                    if (uc.txtCASReactnumber.Text.Trim().ToUpper() == _strnum.ToUpper().Trim() && uc.txtrxnseq.Text.Trim().ToUpper() == _strseq.ToUpper())
        //                    {
        //                        return false;
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return true;
        //}

        //private bool CheckAlreadyNumberAndSequenceExist(string _strnum, string _strseq, string strucnmame, int reactionid)
        //{
        //    try
        //    {
        //        if (_lsttanchild != null)
        //        {
        //            if (_lsttanchild.Count > 0)
        //            {
        //                for (int i = 0; i < _lsttanchild.Count; i++)
        //                {
        //                    if (_lsttanchild[i].ReactionID != reactionid)
        //                    {

        //                        if (_lsttanchild[i].ReactionCasReactantNumber.ToString("0000").Trim() == _strnum.ToUpper().Trim() && _lsttanchild[i].Rxnseq.ToString("0000").ToUpper() == _strseq.ToUpper())
        //                        {
        //                            return false;
        //                        }

        //                    }
        //                }
        //            }
        //        }



        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return true;
        //}
       
        //private bool FillBackupFields()
        //{

        //    string strfile = AppDomain.CurrentDomain.BaseDirectory + "ToolBackup.txt";
        //    List<backupdetails_new> htbackup = new List<backupdetails_new>();
        //    try
        //    {
        //        if (File.Exists(strfile))
        //        {
        //            Hashtable htusercontrolnames = new Hashtable();
        //            Hashtable httandetails = new Hashtable();
        //            using (StreamReader sr = new StreamReader(strfile))
        //            {
        //                string strkeyandvalue;
        //                while ((strkeyandvalue = sr.ReadLine()) != null)
        //                {

        //                    if (strkeyandvalue.Contains("≡"))
        //                    {
        //                        if (!htusercontrolnames.ContainsKey(strkeyandvalue))
        //                            htusercontrolnames.Add(strkeyandvalue, strkeyandvalue);

        //                    }
        //                    if (strkeyandvalue.Contains("≈"))
        //                    {
        //                        string[] c = new string[1];
        //                        c[0] = "≈";
        //                        string[] strkeys = strkeyandvalue.Split(c, StringSplitOptions.None);
        //                        if (strkeys != null)
        //                        {
        //                            if (strkeys.Length > 0)
        //                            {
        //                                if (!httandetails.ContainsKey(strkeys[0]))
        //                                    httandetails.Add(strkeys[0], strkeys[1]);
        //                            }
        //                        }

        //                    }

        //                    if (strkeyandvalue.Contains("¬"))
        //                    {
        //                        char[] c = new char[1];
        //                        c[0] = '¬';
        //                        string[] strkeys = strkeyandvalue.Split(c);
        //                        if (strkeys != null)
        //                        {
        //                            if (strkeys.Length > 0)
        //                            {
        //                                backupdetails_new bc = new backupdetails_new();
        //                                bc.UCName = strkeys[0];
        //                                bc.ControlName = strkeys[1];
        //                                bc.ControlValue = strkeys[2];
        //                                htbackup.Add(bc);
        //                            }
        //                        }
        //                    }
        //                }
        //            }


        //            if (htusercontrolnames.Count > 0)
        //            {
        //                foreach (string strkey in htusercontrolnames.Keys)
        //                {
        //                    uccasnartool_new uc = new uccasnartool_new();
        //                    pnlUserControl.Controls.Clear();
        //                    pnlUserControl.Controls.Add(uc);
        //                    uc.Name = strkey;
        //                    uc.Dock = DockStyle.Fill;
        //                    uc.transferToTextEditorToolStripMenuItem.Click += new EventHandler(transferToTextEditorToolStripMenuItem_Click);
        //                    // uc.txtnarrativeid.Leave += new EventHandler(txtnarrativeid_Leave);
        //                    //uc.txtCASReactnumber.Leave += new EventHandler(txtrxnseq_Leave);
        //                    // uc.txtrxnseq.Leave += new EventHandler(txtrxnseq_Leave);
        //                    uc.DsFindAndReplace = dsFandR;
        //                    //uc.btnDelete.Click += new EventHandler(btnDelete_Click);
        //                    //int irow = AddTableRow();
        //                    //uc.rowindex = irow;
        //                    //tableLayoutPanel1.Controls.Add(uc, 0, irow);

        //                }

        //            }
        //            if (httandetails.Count > 0)
        //            {
        //                foreach (string strkey in httandetails.Keys)
        //                {
        //                    Control[] c = grpDocuments.Controls.Find(strkey, true);
        //                    if (c.Length > 0)
        //                    {
        //                        TextBox t = (TextBox)c[0];
        //                        if (httandetails[strkey] != null)
        //                            t.Text = httandetails[strkey].ToString();
        //                    }

        //                }

        //            }

        //            if (htbackup.Count > 0)
        //            {
        //                foreach (backupdetails_new bc in htbackup)
        //                {
        //                    uccasnartool_new uc = GetUserCOntrolByName(bc.UCName);

        //                    if (uc != null)
        //                    {
        //                        if (bc.ControlName == "txtCASReactnumber")
        //                        {
        //                            uc.txtCASReactnumber.Text = bc.ControlValue;
        //                        }
        //                        else if (bc.ControlName == "txtrxnseq")
        //                        {
        //                            uc.txtrxnseq.Text = bc.ControlValue;
        //                        }
        //                        else if (bc.ControlName == "txtdocref")
        //                        {
        //                            uc.txtdocref.Text = bc.ControlValue;
        //                        }
        //                        else if (bc.ControlName == "txtfilename")
        //                        {
        //                            uc.txtfilename.Text = bc.ControlValue;
        //                        }
        //                        else if (bc.ControlName == "txtpagenumber")
        //                        {
        //                            uc.txtpagenumber.Text = bc.ControlValue;
        //                        }
        //                        else if (bc.ControlName == "txtxpagesize")
        //                        {
        //                            uc.txtxpagesize.Text = bc.ControlValue;
        //                        }
        //                        else if (bc.ControlName == "txtxoffset")
        //                        {
        //                            uc.txtxoffset.Text = bc.ControlValue;
        //                        }
        //                        else if (bc.ControlName == "txtpagelabel")
        //                        {
        //                            uc.txtpagelabel.Text = bc.ControlValue;
        //                        }
        //                        else if (bc.ControlName == "txtypagesize")
        //                        {
        //                            uc.txtypagesize.Text = bc.ControlValue;
        //                        }
        //                        else if (bc.ControlName == "txtyoffset")
        //                        {
        //                            uc.txtyoffset.Text = bc.ControlValue;

        //                        }
        //                        else if (bc.ControlName == "rtxttextlinepreview")
        //                        {
        //                            uc.rtxttextlinepreview.Rtf = "";
        //                            uc.rtxttextlinepreview.Rtf = bc.ControlValue;
        //                            //ConvertHtmlToRtf(bc.ControlValue, uc.rtxttextlinepreview);
        //                        }
        //                        else if (bc.ControlName == "txtnarrativeid")
        //                        {
        //                            //  uc.txtnarrativeid.Text = bc.ControlValue;
        //                            uc.SetNarId(bc.ControlValue);
        //                        }
        //                        else if (bc.ControlName == "rtxtparapreview")
        //                        {
        //                            uc.rtxtparapreview.Rtf = "";
        //                            uc.rtxtparapreview.Rtf = bc.ControlValue;
        //                            //ConvertHtmlToRtf(bc.ControlValue, uc.rtxtparapreview);
        //                        }
        //                        else if (bc.ControlName == "txtpara1")
        //                        {
        //                            uc.txtpara1.Rtf = "";
        //                            uc.txtpara1.Rtf = bc.ControlValue;
        //                            //ConvertHtmlToRtf(bc.ControlValue, uc.txtpara1);
        //                        }
        //                        else if (bc.ControlName == "rtxtdatapreview")
        //                        {
        //                            uc.rtxtdatapreview.Rtf = "";
        //                            uc.rtxtdatapreview.Rtf = bc.ControlValue;

        //                            //ConvertHtmlToRtf(bc.ControlValue, uc.rtxtdatapreview);
        //                        }
        //                    }

        //                }
        //                //GetUserCOntrolByName


        //            }
        //            return true;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //        return false;
        //    }
        //    return false;
        //}

        private void ConvertHtmlToRtf(string strtext, HtmlRichText.HtmlRichTextBox rtfxcontrol)
        {
            strtext = strtext.Replace("<bold>", "<b>");
            strtext = strtext.Replace("</bold>", "</b>");
            strtext = strtext.Replace("<ital>", "<I>");
            strtext = strtext.Replace("</ital>", "</I>");
            strtext = strtext.Replace("<sup>", "<SUP>");
            strtext = strtext.Replace("</sup>", "</SUP>");
            strtext = strtext.Replace("<sub>", "<SUB>");
            strtext = strtext.Replace("</sub>", "</SUB>");
            try
            {

                SautinSoft.HtmlToRtf h = new SautinSoft.HtmlToRtf();


                //specify some options
                h.OutputFormat = SautinSoft.HtmlToRtf.eOutputFormat.Rtf;
                h.Encoding = SautinSoft.HtmlToRtf.eEncoding.AutoSelect;
                h.PageStyle.PageSize.Letter();
                h.FontFace = SautinSoft.HtmlToRtf.eFontFace.f_Calibri;

                string htmlstring = strtext;
                string rtf = h.ConvertString(htmlstring);

                rtfxcontrol.Rtf = rtf;

                string strremovetext = rtfxcontrol.Rtf;
                rtfxcontrol.Rtf = strremovetext;// RemoveTrialVersionstring(strremovetext).Trim();

                RemoveTrialVersionstring("", rtfxcontrol);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void RemoveTrialVersionstring(string strrtfstring, HtmlRichText.HtmlRichTextBox rtbox)
        {
            string str1 = "________________________________________________________";
            string str2 = "Trial version converts only first 100000 characters. Evaluation only.";
            string str3 = "Converted by HTML-to-RTF Pro DLL .Net 3.5.4.21.";
            string str4 = "(Licensed version doesn't display this notice!)";
            string str5 = "- Get license for the HTML-to-RTF Pro DLL .Net <http://www.sautinsoft.com/products/html-to-rtf/order.php>";
            string str6 = "\n\n\n\n\n\n";

            string[] strvalues = new string[6] { str1, str2, str3, str4, str5, str6 };
            try
            {

                foreach (string str in strvalues)
                {
                    if (rtbox.Text.Contains(str))
                    {
                        bool blnloop = false;
                        int startindex = 0;

                        indexOfSearchText = 0;
                        start = 0;
                        while (blnloop == false)
                        {

                            if (str.Length > 0)
                            {
                                startindex = FindMyText(str.Trim(), start, rtbox.Text.Length, rtbox);
                                if (startindex == -1)
                                {
                                    blnloop = true;
                                }
                            }

                            if (startindex >= 0)
                            {
                                // Set the highlight color as red
                                int endindex = str.Length;
                                // Highlight the search string
                                rtbox.Select(startindex, endindex);
                                rtbox.SelectedRtf = "";
                                blnloop = true;
                                rtbox.SelectAll();
                                //start = startindex + endindex;
                                // continue;

                            }
                        }
                        continue;

                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            finally
            {
                if (rtbox.Text != null)
                {


                }
            }

        }

        #region Supplement Ids
        /// <summary>
        /// Auto complete of supplement Ids
        /// </summary>
        public void FillSupplementIDs()
        {

            string strdoc = "";
            for (int i = 2; i < 18; i++)
            {
                if (i == 2)
                {
                    strdoc += "doc" + i.ToString();
                }
                else
                {
                    strdoc += "," + "doc" + i.ToString();
                }
                _autocompleSupplementID.Add(strdoc);
            }

            txtsupplid.AutoCompleteMode = AutoCompleteMode.Suggest;
            txtsupplid.AutoCompleteSource = AutoCompleteSource.CustomSource;
            txtsupplid.AutoCompleteCustomSource = _autocompleSupplementID;
        }

        #endregion

        //void btnDelete_Click(object sender, EventArgs e)
        //{
        //    try
        //    {

        //        foreach (Control c in tableLayoutPanel1.Controls)
        //        {
        //            if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
        //            {
        //                uccasnartool_new uc = (uccasnartool_new)c;
        //                if (uc.Clicked)
        //                {
        //                    if (ISEditMode)
        //                    {
        //                        try
        //                        {

        //                            if ((uc.documentid > 0) && (uc.reactionID > 0))
        //                            {
        //                                if (MessageBox.Show("Do you want to delete nar id " + uc.txtnarrativeid.Text + " ? ", "CAS Narrative", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
        //                                {

        //                                    if (DAL.CASNarrativeDataAccess.DeleteReactions(uc.documentid, Convert.ToInt32(uc.txtCASReactnumber.Text), uc.reactionID))
        //                                    {
        //                                        MessageBox.Show("Reaction deleted succefully", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);

        //                                        tableLayoutPanel1.Controls.RemoveByKey(uc.Name);
        //                                        tableLayoutPanel1.RowStyles.RemoveAt(uc.rowindex);
        //                                        if (Generic.globalVariables.HtNumAndSeq != null)
        //                                            lblreccountvalue.Text = tableLayoutPanel1.Controls.Count.ToString() + " / " + Generic.globalVariables.HtNumAndSeq.Count.ToString();
        //                                        return;
        //                                    }
        //                                }
        //                            }
        //                        }
        //                        catch (Exception ex)
        //                        {
        //                            tableLayoutPanel1.Controls.RemoveByKey(uc.Name);
        //                            if (Generic.globalVariables.HtNumAndSeq != null)
        //                                lblreccountvalue.Text = tableLayoutPanel1.Controls.Count.ToString() + " / " + Generic.globalVariables.HtNumAndSeq.Count.ToString();
        //                            //lblreccountvalue.Text = tableLayoutPanel1.Controls.Count.ToString();
        //                            ErrorHandling.WriteErrorLog(ex.ToString());
        //                            return;
        //                        }

        //                    }
        //                    if (MessageBox.Show("Do you want to delete record ? ", "CAS Narrative", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
        //                    {
        //                        tableLayoutPanel1.Controls.RemoveByKey(uc.Name);
        //                        tableLayoutPanel1.RowStyles.RemoveAt(uc.rowindex);

        //                        if (Generic.globalVariables.HtNumAndSeq != null)
        //                            lblreccountvalue.Text = tableLayoutPanel1.Controls.Count.ToString() + " / " + Generic.globalVariables.HtNumAndSeq.Count.ToString();
        //                        //                                lblreccountvalue.Text = tableLayoutPanel1.Controls.Count.ToString();
        //                        return;
        //                    }

        //                }
        //            }
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    finally
        //    {
        //        tableLayoutPanel1.AutoScroll = false;
        //        tableLayoutPanel1.AutoScroll = true;


        //        dsreportview = CAS_Narrative.DAL.CASNarrativeDataAccess.GetTANReportView(txttan.Text, "TAN");

        //        if (dsreportview != null)
        //        {
        //            if (dsreportview.Tables.Count > 0)
        //            {
        //                _lsttanchild = new List<CAS_Nar_Bll.clsCASChild>();
        //                CAS_Nar_Bll.clsMaster _tanmaster = new CAS_Nar_Bll.clsMaster();
        //                DAL.CASNarrativeDataAccess.GetDocumentDetailsDataSet(dsreportview, out  _lsttanchild, out _tanmaster);
        //            }
        //        }
        //    }


        //}

        /// <summary>
        /// Load Symbols
        /// </summary>
        private void LoadSymbols()
        {
            try
            {              
                Hashtable hts = new Hashtable();

                hts.Add("171", "&#8596;");
                hts.Add("175", "&#8595;");
                hts.Add("174", "&#8594;");
                hts.Add("173", "&#8593;");
                hts.Add("172", "&#8592;");
                hts.Add("222", "&#8658;");
                hts.Add("219", "&#8660;");
                hts.Add("187", "&#8776;");
                hts.Add("204", "&#8834;");
                hts.Add("201", "&#8835;");
                hts.Add("186", "&#8801;");
                //hts.Add("928", "&#960;"); //Pi
                //hts.Add("110", "&#957;");
               
                foreach (string strkey in hts.Keys)
                {
                    try
                    {
                        ToolStripButton ts = new ToolStripButton();
                        ts.Name = "tsstrip1" + hts[strkey].ToString();
                        ts.DisplayStyle = ToolStripItemDisplayStyle.Text;
                        ts.Tag = hts[strkey].ToString();
                        ts.Text = ((char)Convert.ToInt32(strkey)).ToString();
                        ts.Font = new Font("Symbol", 8);
                        if (strkey == "928")
                        {
                            ts.ToolTipText = "Lowercase Pi";
                        }
                        tsGreekChrs.Items.Add(ts);
                    }
                    catch (Exception ex)
                    {
                        ErrorHandling.WriteErrorLog(ex.ToString());
                    }
                }
                ToolStripItem[] tsietms = new System.Windows.Forms.ToolStripItem[tsGreekChrs.Items.Count];
                for (int i = 0; i < tsGreekChrs.Items.Count; i++)
                {
                    try
                    {
                        ToolStripButton tsitem = new ToolStripButton();
                        //tsitem =(ToolStripButton) toolStrip3.Items[i];
                        tsitem.Name = tsGreekChrs.Items[i].Name;
                        tsitem.Text = tsGreekChrs.Items[i].Text;
                        tsitem.Tag = tsGreekChrs.Items[i].Tag;
                        //tsitem.Font = new Font("Symbol", 8);
                        tsietms[i] = tsitem;
                    }
                    catch (Exception ex)
                    {
                        ErrorHandling.WriteErrorLog(ex.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }    
        }

        //private void showSymbolinToolStrip(string strkey)
        //{
        //    //foreach (ToolStripItem ts in tssymbols.Items)
        //    //{
        //    //    if (ts.Text == ((char)Convert.ToInt32(strkey)).ToString())
        //    //    {
        //    //        ts.Font = new Font("Symbol", 8);
        //    //    }
        //    //}
        //}

        //private void CheckEmptyReactions(uccasnartool_new uc)
        //{
        //    try
        //    {
        //        if (uc != null)
        //        {
        //            if (uc.txtnarrativeid.Text == "")
        //            {
        //                //uc.reactionID
        //                DAL.CASNarrativeDataAccess.DeleteReactions(uc.documentid, uc.reactionID);

        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}

        //private void button1_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        ofd.Reset();
        //        ofd.Filter = "pdf files (*.pdf)|*.pdf|All files (*.*)|*.*";
        //        if (ofd.ShowDialog() != DialogResult.Cancel)
        //        {
        //            string strfileextension = "";
        //            strfileextension = Path.GetExtension(ofd.FileName);
        //            if (strfileextension.ToUpper() == ".PDF")
        //            {
        //                try
        //                {
        //                    this.WindowState = FormWindowState.Normal;
        //                    txttb1filepathdoc1.Text = ofd.FileName;

        //                    pdfdoc1.Refresh();
        //                    //pdfdoc1.setShowToolbar(true);
        //                    //pdfdoc1.UseWaitCursor = true;
        //                    //pdfdoc1.IsAccessible = true;
        //                    pdfdoc1.LoadFile(ofd.FileName);
        //                    pdfdoc1.Visible = true;
        //                    pdfdoc1.Refresh();
        //                    this.WindowState = FormWindowState.Maximized;

        //                }
        //                catch (Exception ex)
        //                {
        //                    MessageBox.Show("Unable to open file", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //                    ErrorHandling.WriteErrorLog(ex.ToString());
        //                    txttb1filepathpdf1.Text = "";
        //                    return;

        //                }
        //            }




        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}

        //private void btndoc3_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        ofd.Reset();
        //        ofd.Filter = "pdf files (*.pdf)|*.pdf|All files (*.*)|*.*";
        //        if (ofd.ShowDialog() != DialogResult.Cancel)
        //        {
        //            string strfileextension = "";
        //            strfileextension = Path.GetExtension(ofd.FileName);
        //            if (strfileextension.ToUpper() == ".PDF")
        //            {
        //                try
        //                {
        //                    this.WindowState = FormWindowState.Normal;
        //                    txttb1filepathdoc3.Text = ofd.FileName;
        //                    pdfdoc3.LoadFile(ofd.FileName);
        //                    pdfdoc3.Visible = true;
        //                    pdfdoc3.Refresh();
        //                    this.WindowState = FormWindowState.Maximized;

        //                }
        //                catch (Exception ex)
        //                {
        //                    MessageBox.Show("Unable to open file", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //                    ErrorHandling.WriteErrorLog(ex.ToString());
        //                    txttb1filepathpdf2.Text = "";
        //                    return;

        //                }
        //            }




        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}

        //private void btndoc2_Click(object sender, EventArgs e)
        //{

        //    try
        //    {
        //        ofd.Reset();
        //        ofd.Filter = "pdf files (*.pdf)|*.pdf|All files (*.*)|*.*";
        //        if (ofd.ShowDialog() != DialogResult.Cancel)
        //        {
        //            string strfileextension = "";
        //            strfileextension = Path.GetExtension(ofd.FileName);
        //            if (strfileextension.ToUpper() == ".PDF")
        //            {
        //                try
        //                {
        //                    this.WindowState = FormWindowState.Normal;
        //                    txttb1filepathdoc2.Text = ofd.FileName;

        //                    pdfdoc2.Refresh();
        //                    //pdfdoc2.setShowToolbar(true);
        //                    //pdfdoc2.UseWaitCursor = true;
        //                    //pdfdoc2.IsAccessible = true;
        //                    pdfdoc2.LoadFile(ofd.FileName);
        //                    pdfdoc2.Visible = true;
        //                    pdfdoc2.Refresh();
        //                    this.WindowState = FormWindowState.Maximized;

        //                }
        //                catch (Exception ex)
        //                {
        //                    MessageBox.Show("Unable to open file", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //                    ErrorHandling.WriteErrorLog(ex.ToString());
        //                    txttb1filepathpdf2.Text = "";
        //                    return;

        //                }
        //            }




        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }




        //}

        //private void btndoc4_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        ofd.Reset();
        //        ofd.Filter = "pdf files (*.pdf)|*.pdf|All files (*.*)|*.*";
        //        if (ofd.ShowDialog() != DialogResult.Cancel)
        //        {
        //            string strfileextension = "";
        //            strfileextension = Path.GetExtension(ofd.FileName);
        //            if (strfileextension.ToUpper() == ".PDF")
        //            {
        //                try
        //                {
        //                    this.WindowState = FormWindowState.Normal;
        //                    txttb1filepathdoc4.Text = ofd.FileName;

        //                    pdfdoc4.Refresh();
        //                    //pdfdoc4.setShowToolbar(true);
        //                    //pdfdoc4.UseWaitCursor = true;
        //                    //pdfdoc4.IsAccessible = true;
        //                    pdfdoc4.LoadFile(ofd.FileName);
        //                    pdfdoc4.Visible = true;
        //                    pdfdoc4.Refresh();
        //                    this.WindowState = FormWindowState.Maximized;

        //                }
        //                catch (Exception ex)
        //                {
        //                    MessageBox.Show("Unable to open file", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //                    ErrorHandling.WriteErrorLog(ex.ToString());
        //                    txttb1filepathdoc4.Text = "";
        //                    return;

        //                }
        //            }

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}

        //private void btntb1filepathpdf3_Click(object sender, EventArgs e)
        //{


        //    try
        //    {
        //        ofd.Reset();
        //        ofd.Filter = "pdf files (*.pdf)|*.pdf|All files (*.*)|*.*";
        //        if (ofd.ShowDialog() != DialogResult.Cancel)
        //        {
        //            string strfileextension = "";
        //            strfileextension = Path.GetExtension(ofd.FileName);
        //            if (strfileextension.ToUpper() == ".PDF")
        //            {
        //                try
        //                {
        //                    this.WindowState = FormWindowState.Normal;
        //                    txttb1filepathrxnfile.Text = ofd.FileName;

        //                    pdfrxnfile.Refresh();

        //                    pdfrxnfile.LoadFile(ofd.FileName);
        //                    pdfrxnfile.Visible = true;
        //                    pdfrxnfile.Refresh();
        //                    this.WindowState = FormWindowState.Maximized;

        //                }
        //                catch (Exception ex)
        //                {
        //                    MessageBox.Show("Unable to open file", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //                    ErrorHandling.WriteErrorLog(ex.ToString());
        //                    txttb1filepathrxnfile.Text = "";
        //                    return;

        //                }
        //            }

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }

        //}

        #region Find And Replace

        frmfindandreplace frmreplace = null;
        private void ts1findandreplace_Click(object sender, EventArgs e)
        {

            string strfindwhat = "";
            string strreplacertf = "";
            frmreplace = new frmfindandreplace();
            bool isfound = false;
            try
            {
                HtmlRichText.HtmlRichTextBox htrtfbox = GetFocusedControl();

                if (frmreplace.ShowDialog() != DialogResult.OK)
                {

                    btnok_Click(null, null);

                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }

        }

        //frmFind and replace
        void btnok_Click(object sender, EventArgs e)
        {
            bool isfound = false;

            if (frmreplace.IsFound)
            {

                if (!frmreplace.ReplaceChecked)
                {
                    //foreach (Control c in tableLayoutPanel1.Controls)
                    foreach (Control c in pnlUserControl.Controls)
                    {
                        if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
                        {
                            uccasnartool_new uc = (uccasnartool_new)c;
                            foreach (Control t in uc.pnlMain.Controls)
                            {
                                if (t.GetType().BaseType.Name.ToUpper() == "TEXTBOXBASE")
                                {
                                    if (t.Text.Contains(frmreplace.findwith))
                                    {
                                        isfound = true;
                                        t.Focus();
                                    }
                                }
                            }

                        }
                    }

                    //if (_currentPage < _PageCount)
                    //{
                    //    if (MessageBox.Show("Do you want to search in next page", "CAS Narrative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    //    {
                    //        for (int i = _currentPage; i < _PageCount; i++)
                    //        {
                    //            _currentPage++;
                    //            LoadPage();
                    //        }

                    //        foreach (Control c in tableLayoutPanel1.Controls)
                    //        {
                    //            if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
                    //            {
                    //                uccasnartool uc = (uccasnartool)c;
                    //                foreach (Control t in uc.panel1.Controls)
                    //                {
                    //                    if (t.GetType().BaseType.Name.ToUpper() == "TEXTBOXBASE")
                    //                    {
                    //                        if (t.Text.Contains(frmreplace.findwith))
                    //                        {
                    //                            isfound = true;
                    //                            t.Focus();
                    //                        }
                    //                    }
                    //                }

                    //            }
                    //        }
                    //    }
                    //}



                }
                // foreach (Control c in tableLayoutPanel1.Controls)
                //foreach (Control c in pnlUserControl.Controls)
                //{
                //    if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
                //    {
                //        uccasnartool_new uc = (uccasnartool_new)c;

                FindStringINRichTextbox(frmreplace.findwith, uccasnartool_new1.rtxttextlinepreview);

                FindStringINRichTextbox(frmreplace.findwith, uccasnartool_new1.rtxtdatapreview);

                FindStringINRichTextbox(frmreplace.findwith, uccasnartool_new1.rtxtparapreview);

                FindStringINRichTextbox(frmreplace.findwith, uccasnartool_new1.txtpara1);

                FindStringINRichTextbox(frmreplace.findwith, uccasnartool_new1.rtxtdata1);



                //    }
                //}
                //if (_currentPage < _PageCount)
                //{

                //        for (int i = _currentPage; i < _PageCount; i++)
                //        {
                //            if (MessageBox.Show("Do you want to replace in next page", "CAS Narrative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                //            {
                //            _currentPage++;

                //            LoadPage();

                //            foreach (Control c in tableLayoutPanel1.Controls)
                //            {
                //                if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
                //                {
                //                    uccasnartool uc = (uccasnartool)c;

                //                    FindStringINRichTextbox(frmreplace.findwith, uc.rtxttextlinepreview);

                //                    FindStringINRichTextbox(frmreplace.findwith, uc.rtxtdatapreview);

                //                    FindStringINRichTextbox(frmreplace.findwith, uc.rtxtparapreview);

                //                    FindStringINRichTextbox(frmreplace.findwith, uc.txtpara1);



                //                }
                //            }
                //        }
                //    }
                //}

                if (!frmreplace.ReplaceChecked && !isfound)
                {
                    MessageBox.Show("No results found", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
        }

        int indexOfSearchText = 0;
        int start = 0;
        private void FindStringINRichTextbox(string str, HtmlRichText.HtmlRichTextBox rtbox)
        {
            try
            {
                HtmlRichText.HtmlRichTextBox htfw = new HtmlRichText.HtmlRichTextBox();
                if (rtbox.Text.Contains(str))
                {
                    bool blnloop = false;
                    int startindex = 0;

                    indexOfSearchText = 0;
                    start = 0;
                    while (blnloop == false)
                    {

                        if (str.Length > 0)
                        {
                            startindex = FindMyText(str.Trim(), start, rtbox.Text.Length, rtbox);
                            if (startindex == -1)
                            {
                                blnloop = true;
                            }
                        }

                        if (startindex >= 0)
                        {
                            // Set the highlight color as red
                            int endindex = str.Length;
                            // Highlight the search string
                            rtbox.Select(startindex, endindex);
                            rtbox.SelectionBackColor = Color.LightBlue;
                            //blnloop = false;
                            start = startindex + endindex;
                            // continue;
                            if (frmreplace.ReplaceChecked)
                            {
                                try
                                {

                                    if (rtbox.SelectedText != null)
                                    {

                                        rtfformula.Text = "";
                                        rtfformula.Text = frmreplace.Replacestring;
                                        int startposition = rtbox.SelectionStart;
                                        int endpostion = rtbox.SelectionLength;
                                        string strtext = rtbox.SelectedText;
                                        string a = frmreplace.Replacestring;
                                        string b = frmreplace.findwith;
                                        string a1 = "";
                                        bool iscontinue = true;
                                        htfw.Clear();
                                        htfw.Text = frmreplace.findwith;
                                        //if (frmreplace.ListFR.Count == frmreplace.Replacestring.Length)
                                        //{
                                        //    for (int i = 0; i < b.Length; i++)
                                        //    {
                                        //        findandreplaceChartype fr = frmreplace.ListFW[i];
                                        //        string x = a.Substring(i, 1);

                                        //        if (Convert.ToChar(x) == fr.eachcharvalue)
                                        //        {
                                        //            htfw.Select(i, 1);
                                        //            if (fr.IsSub)
                                        //            {
                                        //                htfw.SetSubScript(true);
                                        //            }
                                        //            if (fr.ISsuper)
                                        //            {
                                        //                htfw.SetSuperScript(true);
                                        //            }
                                        //            if (fr.ISBold)
                                        //            {
                                        //                if (htfw.SelectionFont != null)
                                        //                {
                                        //                    htfw.SelectionFont = new Font(htfw.SelectionFont, htfw.SelectionFont.Style ^ FontStyle.Bold);
                                        //                }
                                        //            }
                                        //            if (fr.ISItalic)
                                        //            {
                                        //                if (htfw.SelectionFont != null)
                                        //                {
                                        //                    htfw.SelectionFont = new Font(htfw.SelectionFont, htfw.SelectionFont.Style ^ FontStyle.Italic);
                                        //                }

                                        //            }
                                        //        }
                                        //    }
                                        //    if (rtbox.SelectedRtf == htfw.Rtf)
                                        //    {
                                        //        iscontinue = true;
                                        //    }
                                        //}


                                        if (iscontinue)
                                        {

                                            if (frmreplace.ListFR.Count == frmreplace.Replacestring.Length)
                                            {

                                                for (int i = 0; i < a.Length; i++)
                                                {
                                                    findandreplaceChartype fr = frmreplace.ListFR[i];
                                                    string x = a.Substring(i, 1);

                                                    if (Convert.ToChar(x) == fr.eachcharvalue)
                                                    {
                                                        rtfformula.Select(i, 1);
                                                        if (fr.IsSub)
                                                        {
                                                            rtfformula.SetSubScript(true);
                                                        }
                                                        if (fr.ISsuper)
                                                        {
                                                            rtfformula.SetSuperScript(true);
                                                        }
                                                        if (fr.ISBold)
                                                        {
                                                            if (rtfformula.SelectionFont != null)
                                                            {
                                                                rtfformula.SelectionFont = new Font(rtfformula.SelectionFont, rtfformula.SelectionFont.Style ^ FontStyle.Bold);
                                                            }
                                                        }
                                                        if (fr.ISItalic)
                                                        {
                                                            if (rtfformula.SelectionFont != null)
                                                            {
                                                                rtfformula.SelectionFont = new Font(rtfformula.SelectionFont, rtfformula.SelectionFont.Style ^ FontStyle.Italic);
                                                            }

                                                        }
                                                    }

                                                }

                                                rtfformula.SelectAll();
                                                rtbox.SelectedRtf = rtfformula.SelectedRtf;
                                                rtbox.SelectionBackColor = Color.LightGray;
                                                rtbox.Refresh();
                                            }
                                        }


                                    }


                                }
                                catch (Exception ex)
                                {
                                    ErrorHandling.WriteErrorLog(ex.ToString());
                                }
                            }





                        }
                    }


                }


            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        /// <summary>
        /// Find Text
        /// </summary>
        /// <param name="txtToSearch"></param>
        /// <param name="searchStart"></param>
        /// <param name="searchEnd"></param>
        /// <param name="rtb"></param>
        /// <returns></returns>
        public int FindMyText(string txtToSearch, int searchStart, int searchEnd, HtmlRichText.HtmlRichTextBox rtb)
        {

            // Set the return value to -1 by default.
            int retVal = -1;

            // A valid starting index should be specified.
            // if indexOfSearchText = -1, the end of search
            if (searchStart >= 0 && indexOfSearchText >= 0)
            {
                // A valid ending index
                if (searchEnd > searchStart || searchEnd == -1)
                {
                    rtb.Refresh();
                    // Find the position of search string in RichTextBox
                    indexOfSearchText = rtb.Find(txtToSearch, searchStart, searchEnd, RichTextBoxFinds.MatchCase);

                    retVal = indexOfSearchText;

                }
            }
            return retVal;
        }

        #endregion

        #region Export

        private void btnexport_Click(object sender, EventArgs e)
        {
            StreamWriter sw = null;
            try
            {

                sfd.Filter = "text files (*.txt)|*.txt|Excel files (*.xls)|*.xls|All files (*.*)|*.*";
                if (sfd.ShowDialog() != DialogResult.Cancel)
                {

                    if (sfd.FilterIndex == 1)
                    {
                        sw = new StreamWriter(sfd.FileName);
                        if (dsreportview != null)
                        {

                            List<IndxReactNarrBll.clsCASChild> _lsttanchild = new List<IndxReactNarrBll.clsCASChild>();
                            IndxReactNarrBll.clsMaster _tanmaster = new IndxReactNarrBll.clsMaster();
                            IndxReactNarrDAL.CASNarrativeDataAccess.GetDocumentDetailsDataSet(dsreportview, out  _lsttanchild, out _tanmaster);
                            sw.WriteLine("JournalArticleID :" + _tanmaster.JournalArticalID.ToString());
                            sw.WriteLine("CAN :" + _tanmaster.CAN.ToString());
                            sw.WriteLine("TAN :" + _tanmaster.TAN.ToString());

                            //sw.WriteLine("DOI :" + _tanmaster.DOI.ToString());
                            //sw.WriteLine("Supplement_id :" + _tanmaster.SupplementID.ToString());
                            for (int i = 0; i < _lsttanchild.Count; i++)
                            {

                                string strreactioncasreactnum = _lsttanchild[i].ReactionCasReactantNumber.ToString("0000");
                                string strrxnseq = _lsttanchild[i].Rxnseq.ToString("0000");
                                string strdocref = _lsttanchild[i].DocRef;
                                string strfilename = _lsttanchild[i].filename.ToString();
                                string strpagenumber = _lsttanchild[i].PageNumber.ToString();
                                string strpagelabel = _lsttanchild[i].PageLabel.ToString();
                                string xresunit = _lsttanchild[i].XResUnit.ToString();
                                string xresvalue = _lsttanchild[i].XResValue.ToString();
                                string xpagesize = _lsttanchild[i].XPageSize.ToString();
                                string xoffset = _lsttanchild[i].XOffset.ToString();

                                string yresunit = _lsttanchild[i].YResUnit.ToString();
                                string yresvalue = _lsttanchild[i].YResValue.ToString();
                                string ypagesize = _lsttanchild[i].YPageSize.ToString();
                                string yoffset = _lsttanchild[i].YOffset.ToString();
                                string noexpdetails = _lsttanchild[i].noexperimentaldetails.ToString();



                                sw.WriteLine(strreactioncasreactnum + "    " + strrxnseq + "    " + strdocref + "    " + strfilename + "    " + strpagenumber + "    " + strpagelabel + "    " + xresunit + "    " + xresvalue + "    " + xpagesize + "    " + xoffset + "    " + yresunit + "    " + yresvalue + "    " + ypagesize + "    " + yoffset + " " + noexpdetails + "");

                                sw.WriteLine("Textline : " + _lsttanchild[i].TextLine.ToString().Replace("\r\n", "").TrimEnd());
                                sw.WriteLine("Narrative ID : " + _lsttanchild[i].NarrativeID.ToString() + " " + "Para1 : " + _lsttanchild[i].Para.ToString().Replace("\r\n", "").TrimEnd());
                                sw.WriteLine("Para2: " + _lsttanchild[i].Para1.ToString().Replace("\r\n", "").TrimEnd());
                                sw.WriteLine("Data1 : " + _lsttanchild[i].Data.ToString().Replace("\r\n", "").TrimEnd());
                                sw.WriteLine("Data1 : " + _lsttanchild[i].Data1.ToString().Replace("\r\n", "").TrimEnd());


                            }

                            sw.Flush();
                            sw.Close();
                            MessageBox.Show("File created successfully", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else if (sfd.FilterIndex == 2)
                    {
                        StringBuilder swexcel = new StringBuilder();
                        sw = new StreamWriter(sfd.FileName);
                        if (dsreportview != null)
                        {

                            List<IndxReactNarrBll.clsCASChild> _lsttanchild = new List<IndxReactNarrBll.clsCASChild>();
                            IndxReactNarrBll.clsMaster _tanmaster = new IndxReactNarrBll.clsMaster();
                            IndxReactNarrDAL.CASNarrativeDataAccess.GetDocumentDetailsDataSet(dsreportview, out  _lsttanchild, out _tanmaster);
                            //sw.WriteLine("JournalArticleID :" + _tanmaster.JournalArticalID.ToString());
                            //sw.WriteLine("CAN :" + _tanmaster.CAN.ToString());
                            //sw.WriteLine("TAN :" + _tanmaster.TAN.ToString());
                            swexcel.Append("JournalArticleID\tCAN\tTAN\tRXNNO\tRXNSEQ\tDOCREF\tFilename\tPagenumber\tPageLabel\tXUnit\tXresValue\tXPagesize\tXoffset\tYUnit\tYResValue\tYPageSize\tYOffset\tTextLine\tNarID\tPara1\tPara2\tData\tIsGeneralTypical\tNoExperimentalDetails");
                            sw.WriteLine(swexcel);
                            for (int i = 0; i < _lsttanchild.Count; i++)
                            {

                                string strreactioncasreactnum = _lsttanchild[i].ReactionCasReactantNumber.ToString("0000");
                                string strrxnseq = _lsttanchild[i].Rxnseq.ToString("0000");
                                string strdocref = _lsttanchild[i].DocRef;
                                string strfilename = _lsttanchild[i].filename.ToString();
                                string strpagenumber = _lsttanchild[i].PageNumber.ToString();
                                string strpagelabel = _lsttanchild[i].PageLabel.ToString();
                                string xresunit = _lsttanchild[i].XResUnit.ToString();
                                string xresvalue = _lsttanchild[i].XResValue.ToString();
                                string xpagesize = _lsttanchild[i].XPageSize.ToString();
                                string xoffset = _lsttanchild[i].XOffset.ToString();

                                string yresunit = _lsttanchild[i].YResUnit.ToString();
                                string yresvalue = _lsttanchild[i].YResValue.ToString();
                                string ypagesize = _lsttanchild[i].YPageSize.ToString();
                                string yoffset = _lsttanchild[i].YOffset.ToString();


                                string strtextline = _lsttanchild[i].TextLine.ToString().Replace("\r\n", "").TrimEnd();
                                string strnarid = _lsttanchild[i].NarrativeID.ToString().Replace("\r\n", "").TrimEnd();
                                string strpara1 = _lsttanchild[i].Para.ToString().Replace("\r\n", "").TrimEnd();
                                string strpara2 = _lsttanchild[i].Para1.ToString().Replace("\r\n", "").TrimEnd();
                                string strData = _lsttanchild[i].Data.ToString().Replace("\r\n", "").TrimEnd();
                                string strGeneralTypical = _lsttanchild[i].isGeneralTypical.ToString();
                                string strnoExperimetalDetails = _lsttanchild[i].noexperimentaldetails.ToString();

                                sw.WriteLine(_tanmaster.JournalArticalID + "\t" + _tanmaster.CAN + "\t" + _tanmaster.TAN + "\t" + strreactioncasreactnum + "\t" + strrxnseq + "\t" + strdocref + "\t" + strfilename + "\t" + strpagenumber + "\t" + strpagelabel + "\t" + xresunit + "\t" + xresvalue + "\t" + xpagesize + "\t" + xoffset + "\t" + yresunit + "\t" + yresvalue + "\t" + ypagesize + "\t" + yoffset + "\t" + strtextline + "\t" + strnarid + "\t" + strpara1 + "\t" + strpara2 + "\t" + strData + "\t" + strGeneralTypical + "\t" + strnoExperimetalDetails);




                            }

                            sw.Flush();
                            sw.Close();
                            MessageBox.Show("File created successfully", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            finally
            {
                if (sw != null)
                    sw.Close();
            }

        }

        #endregion

        public Hashtable FillSymbolsfromControls()
        {
            Hashtable hts = new Hashtable();
            try
            {
                foreach (ToolStripItem i in tsGreekChrs.Items)
                {
                    if (!string.IsNullOrEmpty(i.Text))//Code by Sairam on 25Sep 2013
                    {
                        if (!hts.ContainsKey(i.Text))
                        {
                            hts.Add(i.Text, i.Tag);
                        }
                    }
                }
                if (!hts.ContainsKey("≡"))
                {
                    hts.Add("≡", "&#8801;");
                }
                if (!hts.ContainsKey("&#8801;"))
                {
                    hts.Add("&#8801;", "≡");
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return hts;
        }

        //private void btnAddReaction_Click(object sender, EventArgs e)
        //{

        //    clsMaster _objdocument = new clsMaster();

        //    if (txttan.Text != null && txttan.Text != "")
        //    {
        //        if (validations.Validatations.ValidateTANFormat(txttan.Text))
        //            _objdocument.TAN = txttan.Text;
        //        else
        //        {
        //            MessageBox.Show("TAN format is not correct", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //            txttan.Focus();
        //            return;
        //        }
        //    }
        //    else
        //    {
        //        MessageBox.Show("Please enter TAN", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //        txttan.Focus();
        //        return;

        //    }

        //    if (txtcan.Text != null && txtcan.Text != "")
        //    {
        //        if (validations.Validatations.ValidateCANFormat(txtcan.Text))
        //            _objdocument.CAN = txtcan.Text;
        //        else
        //        {
        //            MessageBox.Show("CAN format is not correct", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //            txtcan.Focus();
        //            return;
        //        }
        //    }
        //    else
        //    {
        //        MessageBox.Show("Please enter CAN", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //        txtcan.Focus();
        //        return;
        //    }

        //    int _documentid = CASNarrativeDataAccess.GetDocumentID(txttan.Text.Trim(), txtcan.Text.Trim());


        //    try
        //    {

        //        if (MessageBox.Show("Do you want to add new reaction?", "CAS Narrative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
        //        {

        //            if (_currentPage != _PageCount)
        //            {

        //                dsreportview = CAS_Narrative.DAL.CASNarrativeDataAccess.GetTANReportView(TAN, "TAN");

        //                if (dsreportview != null)
        //                {
        //                    if (dsreportview.Tables.Count > 0)
        //                    {

        //                        _lsttanchild = new List<CAS_Nar_Bll.clsCASChild>();
        //                        CAS_Nar_Bll.clsMaster _tanmaster = new CAS_Nar_Bll.clsMaster();

        //                        DAL.CASNarrativeDataAccess.GetDocumentDetailsDataSet(dsreportview, out  _lsttanchild, out _tanmaster);

        //                        _maxRec = _lsttanchild.Count + 1;
        //                        _PageCount = _maxRec / _pageSize;

        //                        //Adjust the page number if the last page contains a partial page.

        //                        if ((_maxRec % _pageSize) > 0)
        //                        {
        //                            _PageCount += 1;

        //                        }
        //                        _currentPage = _PageCount;
        //                        _recNo = _pageSize * (_currentPage - 1);
        //                        //_recNo = _recNo - 1;
        //                        DisplayPageInfo();
        //                        LoadPage();

        //                    }

        //                }
        //            }
        //            else if (pagecount == tableLayoutPanel1.Controls.Count)
        //            {

        //                dsreportview = CAS_Narrative.DAL.CASNarrativeDataAccess.GetTANReportView(txttan.Text.Trim(), "TAN");

        //                if (dsreportview != null)
        //                {
        //                    if (dsreportview.Tables.Count > 0)
        //                    {

        //                        _lsttanchild = new List<CAS_Nar_Bll.clsCASChild>();
        //                        CAS_Nar_Bll.clsMaster _tanmaster = new CAS_Nar_Bll.clsMaster();

        //                        DAL.CASNarrativeDataAccess.GetDocumentDetailsDataSet(dsreportview, out  _lsttanchild, out _tanmaster);

        //                        _maxRec = _lsttanchild.Count + 1;
        //                        _PageCount = _maxRec / _pageSize;

        //                        //Adjust the page number if the last page contains a partial page.
        //                        if ((_maxRec % _pageSize) > 0)
        //                        {
        //                            _PageCount += 1;

        //                        }
        //                        _currentPage = _PageCount;
        //                        _recNo = _pageSize * (_currentPage - 1);
        //                        //_recNo = _recNo - 1;
        //                        DisplayPageInfo();
        //                        LoadPage();
        //                        //AddrecordstoTable();

        //                    }

        //                };

        //            }
        //            else if (tableLayoutPanel1.Controls.Count == 0)
        //            {
        //                _currentPage = 1;
        //                _PageCount = 1;

        //            }

        //            #region Add Reaction

        //            CAS_Nar_Bll.clsCASChild _tandetails = new clsCASChild();
        //            documentid = _documentid;
        //            uccasnartool uc = new uccasnartool();
        //            uc.TanDetails = _tandetails;
        //            uc.Name = "ucnew" + System.DateTime.Now.Millisecond.ToString();
        //            uc.Dock = DockStyle.Fill;
        //            uc.txtnarrativeid.Leave += new EventHandler(txtnarrativeid_Leave);
        //            uc.txtCASReactnumber.Leave += new EventHandler(txtrxnseq_Leave);
        //            uc.txtrxnseq.Leave += new EventHandler(txtrxnseq_Leave);
        //            uc.HtSymbols = FillSymbolsfromControls();
        //            uc.documentid = _documentid;
        //            //if (CheckReactionIDexist(DAL.CASNarrativeDataAccess.GetReactionid(_documentid)))
        //            //{
        //            uc.reactionID = DAL.CASNarrativeDataAccess.GetReactionid_New(_documentid);
        //            //}
        //            //else
        //            //    uc.reactionID = DAL.CASNarrativeDataAccess.GetReactionid(_documentid) +100;

        //            uc.btnDelete.Click += new EventHandler(btnDelete_Click);
        //            uc.TAN = txttan.Text;
        //            uc.rtxtparapreview.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
        //            uc.rtxttextlinepreview.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
        //            uc.txtpara1.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
        //            uc.rtxtdatapreview.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
        //            uc.rtxtdata1.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
        //            uc.txtdocref.Leave += new EventHandler(txtdocref_Leave);
        //            uc.txtCASReactnumber.Focus();
        //            int irow = AddTableRow();
        //            uc.rowindex = irow;
        //            tableLayoutPanel1.Controls.Add(uc, 0, irow);
        //            tableLayoutPanel1.ScrollControlIntoView((Control)uc);
        //            uc.FillFilename();
        //            #endregion

        //        }
        //        int count = 0;
        //        if (_lsttanchild != null && _lsttanchild.Count > 0)
        //            count = Convert.ToInt32(_lsttanchild.Count);

        //        if (Generic.globalVariables.HtNumAndSeq != null)
        //            lblreccountvalue.Text = Convert.ToString(count + 1) + "/" + Generic.globalVariables.HtNumAndSeq.Count.ToString();

        //        tableLayoutPanel1.AutoScroll = true;
        //        //tableLayoutPanel1.HorizontalScroll.Visible = false;
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}

        //private bool CheckReactionIDexist(int _intrxnid)
        //{
        //    try
        //    {
        //        if (_lsttanchild != null)
        //        {
        //            if (_lsttanchild.Count > 0)
        //            {
        //                int count = _lsttanchild.Where(clsCASChild => clsCASChild.ReactionID == _intrxnid).Count();
        //                if (count == 0)
        //                    return true;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return false;
        //}

        //void txtdocref_Leave(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        TextBox t = (TextBox)sender;
        //        string xpagesize = "";
        //        string ypagesize = "";
        //        //if (t.Text != null && t.Text != "")
        //        //{
        //        //    string x = "";
        //        //    string y = "";
        //        //    if (GetPageXY(out x, out y, t.Text))
        //        //    {
        //        //        // foreach (Control c in tableLayoutPanel1.Controls)
        //        //        //foreach (Control c in pnlUserControl.Controls)
        //        //        //{
        //        //        //    if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
        //        //        //    {
        //        //        //        uccasnartool_new uc = (uccasnartool_new)c;
        //        //        if (uccasnartool_new1.Name.ToUpper() == t.Tag.ToString().ToUpper())
        //        //        {
        //        //            uccasnartool_new1.txtxpagesize.Text = x;
        //        //            uccasnartool_new1.txtypagesize.Text = y;
        //        //        }
        //        //        //        }
        //        //        //    }
        //        //    }
        //        //}
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}

        #region Page Size and Page offset

        public static bool GetPageXY(out string _xaxis, out string _yaxis, string strdocname)
        {
            try
            {
                if (_lsttanchild != null)
                {
                    if (_lsttanchild.Count > 0)
                    {
                        if (strdocname != "")
                        {
                            clsCASChild rxn = _lsttanchild.Find(delegate(clsCASChild p) { return p.DocRef.ToUpper() == strdocname.Trim().ToUpper(); });

                            if (rxn != null)
                            {
                                if (rxn.XPageSize != null)
                                    _xaxis = rxn.XPageSize.ToString();
                                else
                                    _xaxis = "";
                                if (rxn.YPageSize != null)
                                    _yaxis = rxn.YPageSize.ToString();
                                else
                                    _yaxis = "";


                                return true;
                            }
                            else
                            {
                                _xaxis = "";
                                _yaxis = "";
                                return false;
                            }
                        }
                        else
                        {

                            _xaxis = "";
                            _yaxis = "";
                            return false;
                        }
                        ;

                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _xaxis = "";
            _yaxis = "";
            return false;
        }

        public static bool GetPageXY(out string _xaxis, out string _yaxis, out string _xOffset, out string _Yoffset, string strdocname)
        {
            try
            {
                if (_lsttanchild != null)
                {
                    if (_lsttanchild.Count > 0)
                    {
                        if (strdocname != "")
                        {
                            clsCASChild rxn = _lsttanchild.Find(delegate(clsCASChild p) { return p.DocRef.ToUpper() == strdocname.Trim().ToUpper(); });

                            if (rxn != null)
                            {
                                if (rxn.XPageSize != null)
                                    _xaxis = rxn.XPageSize.ToString();
                                else
                                    _xaxis = "";
                                if (rxn.YPageSize != null)
                                    _yaxis = rxn.YPageSize.ToString();
                                else
                                    _yaxis = "";
                                if (rxn.XOffset != null)
                                    _xOffset = "0"; //rxn.XOffset.ToString();
                                else
                                    _xOffset = "";
                                if (rxn.YOffset != null)
                                    _Yoffset = "0";// rxn.YOffset.ToString();
                                else
                                    _Yoffset = "";

                                return true;
                            }
                            else
                            {
                                _xaxis = "";
                                _yaxis = "";
                                _xOffset = "";
                                _Yoffset = "";
                                return false;
                            }
                        }
                        else
                        {

                            _xaxis = "";
                            _yaxis = "";
                            _xOffset = "";
                            _Yoffset = "";
                            return false;
                        }


                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _xaxis = "";
            _yaxis = "";
            _xOffset = "";
            _Yoffset = "";
            return false;
        }

        #endregion

        //private int AddTableRow()
        //{
        //    int index = tableLayoutPanel1.RowCount++;
        //    RowStyle style = new RowStyle(SizeType.AutoSize);
        //    tableLayoutPanel1.RowStyles.Add(style);
        //    return index;
        //}

        //private int AddTableRow_new()
        //{
        //    int index = tableLayoutPanel1.RowCount + 1;
        //    RowStyle style = new RowStyle(SizeType.AutoSize);
        //    tableLayoutPanel1.RowStyles.Add(style);
        //    return index;
        //}

        #region Coordinate capture

        private void btFirstpage_Click(object sender, EventArgs e)
        {
            dgviewer.DisplayFirstFrame();
            txtcpage.Text = dgviewer.CurrentPage.ToString();
        }

        private void btPreviousPage_Click(object sender, EventArgs e)
        {
            dgviewer.DisplayPreviousFrame();
            txtcpage.Text = dgviewer.CurrentPage.ToString();
        }

        private void btNextPage_Click(object sender, EventArgs e)
        {
            dgviewer.DisplayNextFrame();
            txtcpage.Text = dgviewer.CurrentPage.ToString();
        }

        private void btlastpage_Click(object sender, EventArgs e)
        {
            dgviewer.DisplayLastFrame();
            txtcpage.Text = dgviewer.CurrentPage.ToString();
        }

        private void btZoomIn_Click(object sender, EventArgs e)
        {
            dgviewer.ZoomIN();
        }

        private void btZoomOut_Click(object sender, EventArgs e)
        {
            dgviewer.ZoomOUT();
        }


        double x = 0;
        double y = 0;

        private void dgviewer_ClickControl_1(object sender, EventArgs e)
        {
            try
            {

                if (dgviewer.MouseMode == GdViewerPro4.ViewerMouseMode.MouseModeAreaSelection)
                {
                    if (MessageBox.Show("X offset value '" + x.ToString("0.00") + "',Y Offset value '" + y.ToString("0.00") + "', Do you want to save these values in clipboard?", "CAS Narrative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {

                        Clipboard.Clear();
                        //MessageBox.Show("XY Coordinates saved into clipboard","CAS_Narrative-Tool",MessageBoxButtons.OK,MessageBoxIcon.Information);
                        Clipboard.SetData(DataFormats.Text, "XYOFFSETS : " + x.ToString("0.00") + ":" + y.ToString("0.00"));
                    }
                }

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgviewer_MouseMoveControl(object sender, AxGdViewerPro4.__GdViewer_MouseMoveControlEvent e)
        {
            try
            {
                x = Convert.ToDouble(dgviewer.GetMouseX()) / 199;
                y = Convert.ToDouble(dgviewer.GetMouseY()) / 199;

                lbPos.Text = "(" + x.ToString("0.00") + "," + y.ToString("0.00") + ")";
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }

        }

        private void dgviewer_ZoomChange_1(object sender, EventArgs e)
        {
            txtZoom.Text = Convert.ToString(dgviewer.ZOOM * 100);
        }

        private void btnZoomFit_Click(object sender, EventArgs e)
        {
            dgviewer.SetZoomFitControl();
        }

        private void btnZoomWidth_Click(object sender, EventArgs e)
        {
            dgviewer.SetZoomWidthControl();
        }

        private void btnZoomOnArea_Click(object sender, EventArgs e)
        {
            dgviewer.MouseMode = GdViewerPro4.ViewerMouseMode.MouseModeAutoZoom;//gviewer.convertWindowToPDFCoords(
        }

        private void btnZoom100_Click(object sender, EventArgs e)
        {
            dgviewer.SetZoom100();
        }

        //private void rddoc1_CheckedChanged(object sender, EventArgs e)
        //{
        //    if (rddoc1.Checked)
        //    {
        //        dgviewer.MouseMode = GdViewerPro4.ViewerMouseMode.MouseModeAreaSelection;
        //        dgviewer.SetZoomFitControl();
        //        dgviewer.DisplayFromPdfFile(txttb1filepathdoc1.Text);
        //    }

        //}

        //private void rddoc2_CheckedChanged(object sender, EventArgs e)
        //{
        //    if (rddoc2.Checked)
        //    {
        //        dgviewer.SetZoomFitControl();
        //        dgviewer.MouseMode = GdViewerPro4.ViewerMouseMode.MouseModeAreaSelection;
        //        dgviewer.DisplayFromPdfFile(txttb1filepathdoc2.Text);
        //    }

        //}

        //private void rddoc3_CheckedChanged(object sender, EventArgs e)
        //{
        //    if (rddoc3.Checked)
        //    {
        //        dgviewer.SetZoomFitControl();
        //        dgviewer.MouseMode = GdViewerPro4.ViewerMouseMode.MouseModeAreaSelection;
        //        dgviewer.DisplayFromPdfFile(txttb1filepathdoc3.Text);
        //    }


        //}

        //private void rddoc4_CheckedChanged(object sender, EventArgs e)
        //{
        //    if (rddoc4.Checked)
        //    {
        //        dgviewer.SetZoomFitControl();
        //        dgviewer.MouseMode = GdViewerPro4.ViewerMouseMode.MouseModeAreaSelection;
        //        dgviewer.DisplayFromPdfFile(txttb1filepathdoc4.Text);
        //    }

        //}

        #endregion

        #region Update

        List<clsCASChild> _Reactions = null;
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string _strmsg = "";
            ArrayList alnartive = new ArrayList();
            try
            {
                if (IndxReactNarrDAL.Connection.isConnectionAvailable())
                {

                    try
                    {
                        _Reactions = new List<clsCASChild>();

                        //if (tableLayoutPanel1.Controls.Count > 0)
                        if (Generic.globalVariables.HtNumAndSeq.Count > 0)
                        {
                            string strmsg = "Do you want to save TAN?";
                            if (ISEditMode)
                            {
                                strmsg = "Do you want to update TAN?";
                            }
                            //     bool isyield = true;
                            if (!chkIsRxnComplete.Checked)
                            {
                                #region Temporary saving.

                                if (MessageBox.Show("Do you want to store data temporarily ? ", "CAS Narrative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                                {
                                    clsMaster _objmater = new clsMaster();
                                    if (validateMasterDetails(out _objmater))
                                    {
                                        documentid = CASNarrativeDataAccess.PopulateDocumentData_new(_objmater, Generic.globalVariables.UserName);// ConfigurationSettings.AppSettings["CASUSERNAME"].ToString());
                                    }
                                    if ((uccasnartool_new1.chkIsMissingRxn.Checked != (bool)dtReaction.Rows[0]["is_missing_reaction"]) && uccasnartool_new1.txtnarrativeid.Text == "")
                                    {
                                        MissingNarId();
                                        return;
                                    }
                                    string stroutmsg = null;
                                    clsMaster objdocument = new clsMaster();
                                    clsCASChild objdocreactions = new clsCASChild();
                                    WithOutValidations(uccasnartool_new1, out objdocument, out objdocreactions);
                                    //  _Reactions.Add(objdocreactions);
                                    if (IndxReactNarrDAL.CASNarrativeDataAccess.PopulateDocumentDetailsDataid_Patent_final_IsCurationComplete(documentid, _Reactions.Count, objdocreactions, uccasnartool_new1.reactionID, Generic.globalVariables.UserRoleID, Generic.globalVariables.UserID, alnartive, chkIsRxnComplete.Checked, out stroutmsg))
                                    {
                                        MessageBox.Show("stored temporarily.");
                                        dsreportview = IndxReactNarr.DAL.CASNarrativeDataAccess.GetTANReportView(txtTAN.Text, "TAN");

                                        if (dsreportview != null)
                                        {
                                            if (dsreportview.Tables.Count > 0)
                                            {

                                                _lsttanchild = new List<IndxReactNarrBll.clsCASChild>();
                                                IndxReactNarrBll.clsMaster _tanmaster = new IndxReactNarrBll.clsMaster();
                                                IndxReactNarrDAL.CASNarrativeDataAccess.GetDocumentDetailsDataSet(dsreportview, out  _lsttanchild, out _tanmaster);
                                            }
                                        }
                                        UpdateReactionsTreeView();
                                        return;
                                    }

                                }
                                #endregion
                            }
                            else
                            {
                                // if (MessageBox.Show(strmsg, "CAS Narrative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                                {
                                    #region MyRegion
                                    //for (int i = 0; i < tableLayoutPanel1.Controls.Count; i++)
                                    //{
                                    //    Control c = tableLayoutPanel1.Controls[i];
                                    //    if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
                                    //    {
                                    //        uccasnartool uc = (uccasnartool)c;
                                    //        if (!CheckYeildInPara(uc))
                                    //        {
                                    //            MessageBox.Show("Yeild can't be allowed in both the (Para1 & Para2)");
                                    //            uc.Focus();
                                    //            isyield = false;
                                    //            return;
                                    //        }
                                    //    }
                                    //} 
                                    #endregion

                                    #region Identify Unicode Char

                                    FindErrorUnicodes();

                                    if (Generic.globalVariables.LstUniChar != null)
                                    {
                                        FrmFindUniChar obj = null;
                                        bool blFrmOpen = false;

                                        for (int j = 0; j < Application.OpenForms.Count; j++)
                                        {
                                            if (Application.OpenForms[j].Name == "FrmFindUniChar")
                                            {
                                                obj = (FrmFindUniChar)Application.OpenForms[j];
                                                obj.BindUnicodesToGrid();
                                                blFrmOpen = true;
                                            }
                                        }

                                        if (!blFrmOpen)
                                        {
                                            obj = new FrmFindUniChar();
                                        }
                                        obj.BringToFront();
                                        obj.Show();
                                        return;
                                    }

                                    #endregion

                                    //         if (isyield)
                                    {
                                        bool isvalidated = false;
                                        //new code
                                        clsMaster _objmater = new clsMaster();
                                        if (validateMasterDetails(out _objmater))
                                        {
                                            documentid = CASNarrativeDataAccess.PopulateDocumentData_new(_objmater, Generic.GlobalVariables.UserName);// ConfigurationSettings.AppSettings["CASUSERNAME"].ToString());
                                        }
                                        //upto here
                                        _strmsg = "\r\n Validation Start time " + DateTime.Now.ToString();

                                        #region Missing Nar Id (If Modified)

                                        if ((uccasnartool_new1.chkIsMissingRxn.Checked != (bool)dtReaction.Rows[0]["is_missing_reaction"]) && uccasnartool_new1.txtnarrativeid.Text == "")
                                        {
                                            MissingNarId();
                                            return;
                                        }
                                        #endregion

                                        #region update all Doc ref x page size, y page size.(If Modified)

                                        if (_lsttanchild != null)
                                        {
                                            if (_lsttanchild.Count > 0)
                                            {
                                                clsCASChild rxn = _lsttanchild.Find(delegate(clsCASChild p) { return p.DocRef != "" && p.DocRef == uccasnartool_new1.txtdocref.Text.Trim() && p.XPageSize.ToString() != uccasnartool_new1.txtxpagesize.Text.Trim(); });

                                                if (rxn != null)
                                                {
                                                    double xPageSize = 0;
                                                    double yPageSize = 0;
                                                    double.TryParse(uccasnartool_new1.txtxpagesize.Text.Trim(), out xPageSize);
                                                    double.TryParse(uccasnartool_new1.txtypagesize.Text.Trim(), out yPageSize);
                                                    CASNarrativeDataAccess.ModifyDocRefXYpageSizes(uccasnartool_new1.documentid, uccasnartool_new1.txtdocref.Text.Trim(), xPageSize, yPageSize);
                                                }
                                            }
                                        }
                                        #endregion

                                        #region Old code
                                        //for (int i = 0; i < tableLayoutPanel1.Controls.Count; i++)
                                        //  for (int i = 0; i < pnlUserControl.Controls.Count; i++)
                                        //{
                                        //Control c = tableLayoutPanel1.Controls[i];
                                        // Control c = pnlUserControl.Controls[i];

                                        // if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
                                        //{
                                        // uccasnartool_new uc = (uccasnartool_new)c;
                                        //string stranalog = uc.rtxtparapreview.Text.ToLower();

                                        //New Conditions

                                        //if (!CheckAlreadyNumberAndSequenceExist(uc.txtCASReactnumber.Text, uc.txtrxnseq.Text, "", uc.reactionID))
                                        //{
                                        //    MessageBox.Show("Reaction number('" + uc.txtCASReactnumber.Text + "') and sequence('" + uc.txtrxnseq.Text + "') already exists, please give different Sequence number", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        //    return;
                                        //}

                                        //if (!ValidateReactionNumandSeq(uc))
                                        //{
                                        //    return;
                                        //}

                                        //       if (ValidateNarrativeID(uc.txtnarrativeid, uc.Name, uc.reactionID, out strnartiveid)) 
                                        #endregion

                                        string strnartiveid = "";
                                        if (IsNarIdValid(uccasnartool_new1.txtnarrativeid.Text, uccasnartool_new1.chkIsAnalogous.Checked, uccasnartool_new1.cmbAnalogousTo.SelectedItem))
                                        {
                                            alnartive.Add(strnartiveid);
                                            //if (uc.txtnarrativeid.Text.Contains("analogousTo="))
                                            if (uccasnartool_new1.chkIsAnalogous.Checked || uccasnartool_new1.chkIsMissingRxn.Checked)
                                            {
                                                if (CheckNarIDAnalogoustoNarIDparaFieldEmptry(uccasnartool_new1.Name) || uccasnartool_new1.chkIsMissingRxn.Checked)
                                                {
                                                    isvalidated = true;
                                                    //new code
                                                    // if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
                                                    //{

                                                    clsMaster objdocument = new clsMaster();
                                                    clsCASChild objdocreactions = new clsCASChild();
                                                    if (!ValidateUserControls(uccasnartool_new1, out objdocument, out objdocreactions))
                                                    {
                                                        // tableLayoutPanel1.ScrollControlIntoView(c);
                                                        this.Cursor = Cursors.Default;
                                                        //  MessageBox.Show("Unable to save TAN into db", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                        return;
                                                    }
                                                    else
                                                    {

                                                        _Reactions.Add(objdocreactions);

                                                    }
                                                    //}
                                                    //upto here
                                                }
                                                else
                                                {
                                                    MessageBox.Show("Nar ID is mapped for this reaction, Para field should be empty", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                    uccasnartool_new1.rtxtparapreview.Focus();
                                                    return;
                                                }
                                            }
                                            else
                                            {
                                                if (uccasnartool_new1.chkisgeneralprocempty.Checked == false && uccasnartool_new1.chkIsMissingRxn.Checked)
                                                {
                                                    if (uccasnartool_new1.rtxtparapreview.Text.Trim() == "" && uccasnartool_new1.chkIsMissingRxn.Checked)
                                                    {
                                                        //  MessageBox.Show("Para field Can't be empty. for narative id " + uccasnartool_new1.GetNarId() + " ", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                        MessageBox.Show("Para field Can't be empty.", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                        this.Cursor = Cursors.Default;
                                                        return;
                                                    }
                                                }

                                                isvalidated = true;
                                                //   if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
                                                //{

                                                clsMaster objdocument = new clsMaster();
                                                clsCASChild objdocreactions = new clsCASChild();
                                                if (!ValidateUserControls(uccasnartool_new1, out objdocument, out objdocreactions))
                                                {
                                                    //tableLayoutPanel1.ScrollControlIntoView(c);
                                                    // MessageBox.Show("Unable to save TAN into db", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                    this.Cursor = Cursors.Default;
                                                    return;
                                                }
                                                else
                                                {
                                                    _Reactions.Add(objdocreactions);

                                                }
                                                //}

                                            }
                                        }
                                        else
                                            return;  //code commented
                                        //}


                                        // }
                                        _strmsg += "\r\nValidation end time " + DateTime.Now.ToString();
                                        //Get Only Updated reaction
                                        _strmsg += "\r\nCheck Error Track start time " + DateTime.Now.ToString();


                                        //new code 
                                        _strmsg += "\r\n Update  start time " + DateTime.Now.ToString();
                                        string stroutmsg = "";
                                        string strtypeerror = "";
                                        if (CheckDuplicateNaridExists(_Reactions, out stroutmsg, out strtypeerror) || uccasnartool_new1.chkIsMissingRxn.Checked)
                                        {
                                            //if (DAL.CASNarrativeDataAccess.PopulateDocumentDetailsDataid_Patent(documentid, _rxnupdates.Count, _rxnupdates, 0)) //changed
                                            //if (DAL.CASNarrativeDataAccess.PopulateDocumentDetailsDataid_Patent(documentid, _Reactions.Count, _Reactions, 0))
                                            if (IndxReactNarrDAL.NarrativesDataAccess.PopulateDocumentDetailsDataid_Patent_final_IsCurationComplete(documentid, _Reactions.Count, _Reactions.ElementAt(0), uccasnartool_new1.reactionID, Generic.globalVariables.UserRoleID, Generic.globalVariables.UserID, alnartive, chkIsRxnComplete.Checked, out stroutmsg))
                                            {
                                                _strmsg += "\r\n Update  end time " + DateTime.Now.ToString();
                                                //MessageBox.Show(_strmsg);
                                                if (ISEditMode)
                                                {
                                                    List<clserrortrack> _lsterrorcheck = null;


                                                    //check reassigned for curations tan and populate errors
                                                    if (4 == DataOperations.GetTANCurrentStatus(txtTAN.Text))
                                                    {
                                                        _lsterrorcheck = CheckErrorTrack(dsreportview, _Reactions, _objmater);
                                                        DataOperations.PopulateErrorTrack(_lsterrorcheck, Generic.GlobalVariables.UserID, Generic.GlobalVariables.UserRoleID, txtTAN.Text.Trim());

                                                    }



                                                    if (Generic.GlobalVariables.UserRoleID == (Int32)Generic.Enums.Roles.Reviewer)
                                                    {
                                                        _lsterrorcheck = CheckErrorTrack(dsreportview, _Reactions, _objmater);
                                                        DataOperations.PopulateErrorTrack(_lsterrorcheck, Generic.GlobalVariables.UserID, Generic.GlobalVariables.UserRoleID, txtTAN.Text.Trim());

                                                    }
                                                    else if (Generic.GlobalVariables.UserRoleID == (Int32)Generic.Enums.Roles.Reviewer2)
                                                    {
                                                        _lsterrorcheck = CheckErrorTrack(dsreportview, _Reactions, _objmater);
                                                        DataOperations.PopulateErrorTrack(_lsterrorcheck, Generic.GlobalVariables.UserID, Generic.GlobalVariables.UserRoleID, txtTAN.Text.Trim());

                                                    }
                                                    else if (Generic.GlobalVariables.UserRoleID == (Int32)Generic.Enums.Roles.Administrator)
                                                    {
                                                        _lsterrorcheck = CheckErrorTrack(dsreportview, _Reactions, _objmater);
                                                        DataOperations.PopulateErrorTrack(_lsterrorcheck, Generic.GlobalVariables.UserID, Generic.GlobalVariables.UserRoleID, txtTAN.Text.Trim());

                                                    }
                                                    else if (Generic.GlobalVariables.UserRoleID == (Int32)Generic.Enums.Roles.QualityCheck)
                                                    {
                                                        _lsterrorcheck = CheckErrorTrack(dsreportview, _Reactions, _objmater);
                                                        DataOperations.PopulateErrorTrack(_lsterrorcheck, Generic.GlobalVariables.UserID, Generic.GlobalVariables.UserRoleID, txtTAN.Text.Trim());

                                                    }
                                                    else if (Generic.GlobalVariables.UserRoleID == (Int32)Generic.Enums.Roles.ProjectManager)
                                                    {
                                                        _lsterrorcheck = CheckErrorTrack(dsreportview, _Reactions, _objmater);
                                                        DataOperations.PopulateErrorTrack(_lsterrorcheck, Generic.GlobalVariables.UserID, Generic.GlobalVariables.UserRoleID, txtTAN.Text.Trim());
                                                    }
                                                    else if (Generic.GlobalVariables.UserRoleID == (Int32)Generic.Enums.Roles.TeamLead)
                                                    {
                                                        _lsterrorcheck = CheckErrorTrack(dsreportview, _Reactions, _objmater);
                                                        DataOperations.PopulateErrorTrack(_lsterrorcheck, Generic.globalVariables.UserID, Generic.globalVariables.UserRoleID, txtTAN.Text.Trim());
                                                    }


                                                    dsreportview = IndxReactNarr.DAL.CASNarrativeDataAccess.GetTANReportView(txtTAN.Text, "TAN");

                                                    if (dsreportview != null)
                                                    {
                                                        if (dsreportview.Tables.Count > 0)
                                                        {

                                                            _lsttanchild = new List<IndxReactNarrBll.clsCASChild>();
                                                            IndxReactNarrBll.clsMaster _tanmaster = new IndxReactNarrBll.clsMaster();
                                                            IndxReactNarrDAL.CASNarrativeDataAccess.GetDocumentDetailsDataSet(dsreportview, out  _lsttanchild, out _tanmaster);
                                                        }
                                                    }
                                                    MessageBox.Show("TAN Updated successfully", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                    UpdateReactionsTreeView();
                                                    this.BringToFront();

                                                    //   if (_uclseelctedcontrol != null)
                                                    //tableLayoutPanel1.ScrollControlIntoView(_uclseelctedcontrol);


                                                    if (Generic.globalVariables.HtNumAndSeq != null)
                                                        lblreccountvalue.Text = _lsttanchild.Count.ToString() + "/" + Generic.globalVariables.HtNumAndSeq.Count.ToString();
                                                    return;

                                                }
                                                else
                                                {

                                                    dsreportview = IndxReactNarr.DAL.CASNarrativeDataAccess.GetTANReportView(txtTAN.Text, "TAN");

                                                    if (dsreportview != null)
                                                    {
                                                        if (dsreportview.Tables.Count > 0)
                                                        {

                                                            _lsttanchild = new List<IndxReactNarrBll.clsCASChild>();
                                                            IndxReactNarrBll.clsMaster _tanmaster = new IndxReactNarrBll.clsMaster();

                                                            IndxReactNarrDAL.CASNarrativeDataAccess.GetDocumentDetailsDataSet(dsreportview, out  _lsttanchild, out _tanmaster);
                                                        }
                                                    }
                                                    MessageBox.Show("TAN Saved successfully", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                    UpdateReactionsTreeView();
                                                    this.BringToFront();

                                                    //    if (_uclseelctedcontrol != null)
                                                    // tableLayoutPanel1.ScrollControlIntoView(_uclseelctedcontrol);

                                                    if (Generic.globalVariables.HtNumAndSeq != null)
                                                        lblreccountvalue.Text = _lsttanchild.Count.ToString() + "/" + Generic.globalVariables.HtNumAndSeq.Count.ToString();
                                                    return;
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show(stroutmsg, "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                return;
                                            }
                                        }
                                        else
                                        {
                                            if (strtypeerror.StartsWith("DUP"))
                                            {
                                                MessageBox.Show("Nar id already exists, please give different nar id " + stroutmsg, "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                return;
                                            }
                                            else
                                            {
                                                MessageBox.Show("Para1 field is empty, Can not give analogousTo 'nar id " + stroutmsg, "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                return;
                                            }
                                        }

                                    }
                                }
                            }
                        }
                        //else if (tableLayoutPanel1.Controls.Count == 0)
                        else
                        {
                            if (MessageBox.Show("Do you want continue saving with 0 reactions?", "CAS Narrative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                            {
                                clsMaster _objmater = new clsMaster();
                                if (validateMasterDetails(out _objmater))
                                {
                                    documentid = CASNarrativeDataAccess.PopulateDocumentData_new(_objmater, Generic.globalVariables.UserName);
                                    MessageBox.Show("TAN Saved sucessfully", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    UpdateReactionsTreeView();
                                    this.BringToFront();
                                    return;
                                }
                            }

                        }
                    }
                    catch (Exception ex)
                    {
                        ErrorHandling.WriteErrorLog(ex.ToString());
                    }
                    finally
                    {
                        this.Cursor = Cursors.Default;
                    }
                }

                else
                {
                    MessageBox.Show("There doest seem to be a network/internet connection.Please contact your system administrator");
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            finally
            {
                this.Cursor = Cursors.Default;
                this.BringToFront();
            }

        }

        private void MissingNarId()
        {
            try
            {


                if (uccasnartool_new1.txtnarrativeid.Text == "" && uccasnartool_new1.chkIsMissingRxn.Checked)
                {
                    var results = (from m in frmNarrTANView.dtDocumet_ids.AsEnumerable()
                                   where (m.IsNull("analogous_to_nar") == false && m.Field<int>("analogous_to_nar") == uccasnartool_new1.reactionID)
                                   select m).Count();

                    if (results.ToString() == "0")
                    {
                        CASNarrativeDataAccess.SetNarAsMissing(uccasnartool_new1.reactionID, documentid);
                        MessageBox.Show("Reaction updated as Missing Reaction.", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Reaction already analogous to another reaction.Cannot update as missing reacion.", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                }
                else if (uccasnartool_new1.txtnarrativeid.Text == "" && !uccasnartool_new1.chkIsMissingRxn.Checked)
                {
                    if (tvRxns.SelectedNode != null)
                    {
                        CASNarrativeDataAccess.UpdateMissingNarAsFound(uccasnartool_new1.reactionID, documentid, NarIdTobeGenerated(1));
                        MessageBox.Show("Reaction updated as not Missing Reaction.", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Please select rection from treeview to update.", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

                UpdateReactionsTreeView();
                LoadReaction(uccasnartool_new1.reactionID);
            }
            catch (Exception)
            {
                throw;
            }
        }

        private string NarIdTobeGenerated(int count)
        {
            try
            {
                string NarId = null;
                NarId = tvRxns.Nodes[0].Nodes[tvRxns.SelectedNode.Index - count] == null ? "" : tvRxns.Nodes[0].Nodes[tvRxns.SelectedNode.Index - count].ToString();
                string[] treeviewtext = NarId.Split('-').ToArray<string>();
                if (treeviewtext.Length > 1)
                {
                    if ((treeviewtext[1].Split(' ')[0]) != null)
                    {
                        NarId = treeviewtext[1].Split(' ')[0];
                        int nar = Convert.ToInt32(NarId.Substring(3));
                        return ("nar" + ++nar);
                    }
                    else
                    {
                        NarIdTobeGenerated(count++);
                    }
                }

                return NarId;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private string GetSelectedReactionNarIdFromTreeview()
        {
            string NarId = null;
            try
            {

                if (tvRxns.SelectedNode != null)
                {

                    NarId = tvRxns.Nodes[0].Nodes[tvRxns.SelectedNode.Index].ToString();
                    string[] treeviewtext = NarId.Split('-').ToArray<string>();
                    if (treeviewtext.Length > 1)
                    {
                        NarId = treeviewtext[1].Split(' ')[0];
                    }
                }
                return NarId;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
                return NarId;
            }
        }

        private bool MissingReactionValidate(uccasnartool_new uc, out clsMaster objdocument, out clsCASChild objdocreactions)
        {
            try
            {
                clsMaster _objdocument = new clsMaster();
                clsCASChild _objdocdetails = new clsCASChild();
                objdocument = null;
                objdocreactions = null;

                this.Cursor = Cursors.WaitCursor;


                _objdocdetails.ReactionID = uc.reactionID;

                if (uc.txtCASReactnumber.Text != null && uc.txtCASReactnumber.Text != "" && uc.txtCASReactnumber.Text != "0000" && uc.txtCASReactnumber.Text != "0")
                {
                    // if (validations.Validatations.ValidateCASReactantNumberFormat(uc.txtCASReactnumber.Text))
                    {

                        _objdocdetails.ReactionCasReactantNumber = Convert.ToInt32(uc.txtCASReactnumber.Text.Trim());

                    }
                    //else
                    //{
                    //    MessageBox.Show("CAS Reactant Format is not valid", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //    uc.txtCASReactnumber.Focus();
                    //    return false;
                    //}
                }
                else
                {
                    MessageBox.Show("Reaction Number can't be zero", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    uc.txtCASReactnumber.Focus();
                    return false;
                }

                if (uc.txtrxnseq.Text != null && uc.txtrxnseq.Text != "" && uc.txtrxnseq.Text != "0000" && uc.txtrxnseq.Text != "0")
                {
                    //  if (validations.Validatations.ValidateCASReactantNumberFormat(uc.txtrxnseq.Text))
                    {

                        _objdocdetails.Rxnseq = Convert.ToInt32(uc.txtrxnseq.Text.Trim());

                    }
                    //else
                    //{
                    //    MessageBox.Show("CAS Reactant Seq format is not valid", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //    uc.txtrxnseq.Focus();
                    //    return false;
                    //}
                }
                else
                {
                    MessageBox.Show("Reaction sequence can't be zero", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    uc.txtCASReactnumber.Focus();
                    return false;
                }
                objdocument = _objdocument;
                objdocreactions = _objdocdetails;
                return true;

            }
            catch (Exception ex)
            {
                throw;
            }

        }

        #region Form Close

        /// <summary>
        /// Auto Save - Code by Sairam on 25Sep2013
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmTANView_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (MessageBox.Show("Do you want to update TAN ?", "CAS Narrative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    //Auto Save when closing
                    btnUpdate_Click(null, null);
                }

                #region FindUniChars

                FrmFindUniChar frmFindUniChar = null;
                List<String> texts = new List<String>();
                for (int i = 0; i < Application.OpenForms.Count; i++)
                {
                    if (Application.OpenForms[i].Name == "FrmFindUniChar")
                    {
                        if (Generic.globalVariables.LstUniChar != null)
                        {
                            if (Generic.globalVariables.LstUniChar.Count > 0)
                            {
                                Application.OpenForms[i].BringToFront();
                                e.Cancel = true;
                                return;
                            }
                        }
                        else
                        {
                            Application.OpenForms[i].Close();
                        }
                    }
                }
                #endregion


            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        #endregion

        #region Find Uni Code Chars.

        private void FindErrorUnicodes()
        {
            try
            {
                Generic.globalVariables.LstUniChar = null;
                //  for (int i = 0; i < tableLayoutPanel1.Controls.Count; i++)
                //for (int i = 0; i < pnlUserControl.Controls.Count; i++)
                //{
                //    Control c = pnlUserControl.Controls[i];
                //    if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
                //    {
                //        uccasnartool_new uc = (uccasnartool_new)c;
                List<UniCodeChar> lstUniChar = new List<UniCodeChar>();
                lstUniChar = uccasnartool_new1.CheckUniChars();
                if (lstUniChar.Count > 0)
                {
                    if (Generic.globalVariables.LstUniChar == null)
                    {
                        Generic.globalVariables.LstUniChar = lstUniChar;
                    }
                    else
                    {
                        foreach (UniCodeChar item in lstUniChar)
                        {
                            Generic.globalVariables.LstUniChar.Add(item);
                        }
                    }
                }

            }
            catch (Exception ex)
            {

                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        ////new method while updating the reaction
        //private bool ValidateReactionNumandSeq(uccasnartool_new uc)
        //{
        //    if (uc != null)
        //    {
        //        if (uc.txtCASReactnumber.Text != null && uc.txtCASReactnumber.Text != "" && uc.txtrxnseq.Text != null && uc.txtrxnseq.Text != "")
        //        {
        //            if (!CheckNumAndSequeceAgainstTan(uc.txtCASReactnumber.Text, uc.txtrxnseq.Text))
        //            {
        //                MessageBox.Show("Reaction number|sequence are not matching, please check", "CAS Narrative Tool", MessageBoxButtons.OK);
        //                uc.txtCASReactnumber.Focus();

        //            }
        //            else
        //            {
        //                return true;
        //            }
        //        }
        //        else
        //        {
        //            MessageBox.Show("Reaction number|sequence can't be empty", "CAS Narrative Tool", MessageBoxButtons.OK);
        //            uc.txtCASReactnumber.Focus();
        //        }

        //    }
        //    return false;
        //}

        //new method while updating the reaction
        //private bool CheckYeildInPara(uccasnartool_new uc)
        //{
        //    if (uc != null)
        //    {
        //        bool ispara1 = false;
        //        bool ispara2 = false;
        //        if (uc.txtpara1.Text != null)
        //        {
        //            if (uc.txtpara1.Text.Contains("yield"))
        //            {
        //                ispara1 = true;
        //            }
        //        }
        //        if (uc.rtxtparapreview.Text != null)
        //        {
        //            if (uc.txtpara1.Text.Contains("yield"))
        //            {
        //                ispara2 = true;
        //            }
        //        }
        //        if (ispara1 && ispara2)
        //        {
        //            return false;
        //        }

        //    }
        //    return true;
        //}

        #region NarId and Analogous Validations

        private bool CheckDuplicateNaridExists(List<clsCASChild> _lstReactions, out string stroutnarid, out string strtype)
        {
            stroutnarid = "";
            strtype = "";
            try
            {
                List<clsCASChild> _lsttotalreactions = new List<clsCASChild>();
                IndxReactNarrBll.clsMaster _tanmaster = new IndxReactNarrBll.clsMaster();
                IndxReactNarrDAL.CASNarrativeDataAccess.GetDocumentDetailsDataSet(dsreportview, out  _lsttotalreactions, out _tanmaster);
                if (_lstReactions.Count > 0)
                {
                    for (int i = 0; i < _lstReactions.Count; i++)
                    {
                        string strnarid = _lstReactions[i].NarrativeID;
                        int intreacitonid = _lstReactions[i].ReactionID;
                        if (!CheckDuplicateNaridinList(_lsttotalreactions, intreacitonid, strnarid))
                        {
                            stroutnarid = strnarid;
                            strtype = "DUPLICATE";
                            return false;
                        }

                        string _strnaranaid = "";
                        string[] strsplit = new string[1] { "analogousTo=" };
                        string[] strnaridwithana = null;
                        if (_lstReactions[i].NarrativeID.Contains("analogousTo="))
                        {
                            strnaridwithana = _lstReactions[i].NarrativeID.Split(strsplit, StringSplitOptions.RemoveEmptyEntries);
                            if (strnaridwithana.Length > 0)
                            {
                                _strnaranaid = strnaridwithana[1];
                            }
                            if (!CheckParaEmptyforAnlogous(_lsttotalreactions, intreacitonid, _strnaranaid))
                            {
                                stroutnarid = _strnaranaid;
                                strtype = "PARA";
                                return false;
                            }
                        }


                    }
                    return true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return false;

        }

        private bool CheckDuplicateNaridinList(List<clsCASChild> _lstReactions, int rexid, string _strnarid)
        {
            try
            {
                if (_lstReactions.Count > 0)
                {
                    for (int i = 0; i < _lstReactions.Count; i++)
                    {
                        if (_lstReactions[i].ReactionID != rexid)
                        {
                            string strnarid = "";
                            string[] strsplit = new string[1] { "analogousTo=" };
                            string[] strnaridwithana = null;
                            if (_lstReactions[i].NarrativeID.Contains("analogousTo="))
                            {
                                strnaridwithana = _lstReactions[i].NarrativeID.Split(strsplit, StringSplitOptions.RemoveEmptyEntries);
                                if (strnaridwithana.Length > 0)
                                {
                                    strnarid = strnaridwithana[0];
                                }
                            }
                            else
                            {
                                strnarid = _lstReactions[i].NarrativeID;
                            }

                            if (_strnarid.Contains("analogousTo="))
                            {
                                strnaridwithana = null;
                                strnaridwithana = _strnarid.Split(strsplit, StringSplitOptions.RemoveEmptyEntries);
                                if (strnaridwithana.Length > 0)
                                {
                                    _strnarid = strnaridwithana[0].Trim();
                                }
                            }
                            if (strnarid.ToUpper().Trim() == _strnarid.ToUpper().Trim())
                            {
                                return false;
                            }

                        }

                    }
                    return true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return true;

        }

        private bool CheckParaEmptyforAnlogous(List<clsCASChild> _lstReactions, int rexid, string _strnarid)
        {
            try
            {
                if (_lstReactions.Count > 0)
                {
                    for (int i = 0; i < _lstReactions.Count; i++)
                    {

                        if (_lstReactions[i].NarrativeID.ToUpper().Trim() == _strnarid.ToUpper().Trim())
                        {
                            if (_lstReactions[i].Para != null)
                            {
                                if (_lstReactions[i].Para.Length > 0)
                                {
                                    return true;
                                }
                                else
                                    return false;
                            }
                            else
                                return true;
                        }


                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return false;

        }

        #endregion

        //private bool ValidateNarrativeID(TextBox t, string strucname, int rxnid, out string stroutananarid)
        //{
        //    stroutananarid = "";
        //    try
        //    {

        //        try
        //        {

        //            if (t.Text != null)
        //            {

        //                if (validations.Validatations.ValidateNarrativeID(t.Text))
        //                {
        //                    if (!validations.Validatations.ValidateNArIDFormat(t.Text))
        //                    {
        //                        MessageBox.Show("narid analogousTo narid's  can not be same", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //                        t.Focus();
        //                        return false;
        //                    }
        //                }
        //                else
        //                {
        //                    MessageBox.Show("narid not in correct format, please check ", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //                    t.Focus();
        //                    return false;
        //                }



        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            ErrorHandling.WriteErrorLog(ex.ToString());
        //        }



        //        if (t.Text != null)
        //        {
        //            string strnarid = "";
        //            if (t.Text.Contains("analogousTo="))
        //            {
        //                string[] strsplit = new string[1] { "analogousTo=" };
        //                string[] strtexts = t.Text.Split(strsplit, StringSplitOptions.RemoveEmptyEntries);

        //                if (strtexts != null)
        //                {
        //                    if (strtexts.Length > 0 && strtexts.Length == 2)
        //                    {
        //                        strnarid = strtexts[0];
        //                    }
        //                }


        //            }
        //            else
        //                strnarid = t.Text;

        //            if (t.Text.Contains("analogousTo"))
        //            {
        //                string[] strsplit = new string[1] { "analogousTo=" };
        //                string[] strtexts = t.Text.Split(strsplit, StringSplitOptions.RemoveEmptyEntries);
        //                if (strtexts != null)
        //                {
        //                    if (strtexts.Length > 0 && strtexts.Length == 2)
        //                    {
        //                        stroutananarid = strtexts[1];
        //                    }
        //                    else
        //                    {
        //                        return true;
        //                        stroutananarid = "";
        //                    }
        //                }
        //            }
        //            return true;

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }

        //    return false;
        //}

        #region Validate Master Details

        private bool validateMasterDetails(out clsMaster _objmaster_details)
        {

            clsMaster _objmaster = new clsMaster();

            _objmaster_details = null;
            try
            {
                if (txtjournalid.Text != null && txtjournalid.Text != "")
                {
                    _objmaster.JournalArticalID = txtjournalid.Text;
                }
                else
                {
                    MessageBox.Show("Journal Id can't be blank", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtjournalid.Focus();
                }

                if (txtTAN.Text != null && txtTAN.Text != "")
                {
                    if (validations.Validatations.ValidateTANFormat(txtTAN.Text))
                        _objmaster.TAN = txtTAN.Text;
                    else
                    {
                        MessageBox.Show("TAN format is not correct", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtTAN.Focus();
                        return false;

                    }
                }
                else
                {
                    MessageBox.Show("TAN  can't be blank", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtTAN.Focus();
                    return false;
                }



                if (txtCAN.Text != null && txtCAN.Text != "")
                {
                    if (validations.Validatations.ValidateCANFormat(txtCAN.Text))
                        _objmaster.CAN = txtCAN.Text;
                    else
                    {
                        MessageBox.Show("CAN format is not correct", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtCAN.Focus();
                        return false;
                    }
                }
                else
                {
                    MessageBox.Show("CAN  can't be blank", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCAN.Focus();
                    return false;
                }


                if (txtDOI.Text != null && txtDOI.Text != "")
                {
                    //if (validations.Validatations.ValidateDOIFormat(txtdoi.Text))
                    _objmaster.DOI = txtDOI.Text;
                    //else
                    //{
                    //    MessageBox.Show("DOI format is not correct", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //    txtdoi.Focus();
                    //    return false;
                    //}
                }
                else
                {
                    _objmaster.DOI = "";
                    if (!Generic.globalVariables.IsPatent)
                    {
                        MessageBox.Show("DOI  can't be blank", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtDOI.Focus();
                        return true;
                    }
                }
                if (!Generic.globalVariables.IsPatent)
                {
                    if (txtsupplid.Text == null && txtsupplid.Text == "")
                    {
                        MessageBox.Show("Supplement ids can't blank", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txtsupplid.Focus();
                        return false;
                    }

                }


                _objmaster.SupplementID = txtsupplid.Text;
                _objmaster_details = _objmaster;

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            return false;

        }

        #endregion

        #region Validate User Controls

        private bool ValidateUserControls(uccasnartool_new uc, out clsMaster objdocument, out clsCASChild objdocdetails)
        {


            try
            {
                clsMaster _objdocument = new clsMaster();
                clsCASChild _objdocdetails = new clsCASChild();
                objdocument = null;
                objdocdetails = null;

                this.Cursor = Cursors.WaitCursor;


                _objdocdetails.ReactionID = uc.reactionID;

                if (uc.txtCASReactnumber.Text != null && uc.txtCASReactnumber.Text != "" && uc.txtCASReactnumber.Text != "0000" && uc.txtCASReactnumber.Text != "0")
                {
                    // if (validations.Validatations.ValidateCASReactantNumberFormat(uc.txtCASReactnumber.Text))
                    {

                        _objdocdetails.ReactionCasReactantNumber = Convert.ToInt32(uc.txtCASReactnumber.Text.Trim());

                    }
                    //else
                    //{
                    //    MessageBox.Show("CAS Reactant Format is not valid", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //    uc.txtCASReactnumber.Focus();
                    //    return false;
                    //}
                }
                else
                {
                    MessageBox.Show("Reaction Number can't be zero", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    uc.txtCASReactnumber.Focus();
                    return false;
                }

                if (uc.txtrxnseq.Text != null && uc.txtrxnseq.Text != "" && uc.txtrxnseq.Text != "0000" && uc.txtrxnseq.Text != "0")
                {
                    //  if (validations.Validatations.ValidateCASReactantNumberFormat(uc.txtrxnseq.Text))
                    {

                        _objdocdetails.Rxnseq = Convert.ToInt32(uc.txtrxnseq.Text.Trim());

                    }
                    //else
                    //{
                    //    MessageBox.Show("CAS Reactant Seq format is not valid", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //    uc.txtrxnseq.Focus();
                    //    return false;
                    //}
                }
                else
                {
                    MessageBox.Show("Reaction sequence can't be zero", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    uc.txtCASReactnumber.Focus();
                    return false;
                }
                if (!uc.chkIsMissingRxn.Checked)
                {
                    if (!uc.IsFinalProductExistsInPara2())
                    {
                        return false;
                    }
                    #region Added by kranthi April 7th 2014	Experimental procedure is true, Para2 should not be blank

                    if (IsRichTextboxIsEmptry(uc.rtxtparapreview))
                    {
                        //if (uc.txtpara1.Text == null || uc.txtpara1.Text == "")
                        if (!IsRichTextboxIsEmptry(uc.txtpara1))
                        {
                            MessageBox.Show("Experimental procedure is true, Para2 should not be blank", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return false;
                        }

                    }
                    #endregion

                    if (uc.txtdocref.Text != null && uc.txtdocref.Text != "")
                    {

                        _objdocdetails.DocRef = uc.txtdocref.Text;


                    }
                    else
                    {
                        MessageBox.Show("docRef  can't be blank", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        uc.txtdocref.Focus();
                        return false;
                    }


                    if (uc.txtpagenumber.Text != null && uc.txtpagenumber.Text != "")
                        _objdocdetails.PageNumber = Convert.ToInt32(uc.txtpagenumber.Text);
                    else
                    {
                        MessageBox.Show("PageNumber  can't be blank", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        uc.txtpagenumber.Focus();
                        return false;
                    }


                    if (Generic.globalVariables.IsPatent)
                    {

                        if (uc.txtpagelabel.Text != null && uc.txtpagelabel.Text != "")
                            _objdocdetails.PageLabel = uc.txtpagelabel.Text;
                        else
                        {
                            MessageBox.Show("PageLabel  can't be blank", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            uc.txtpagelabel.Focus();
                            return false;
                        }
                    }
                    else
                    {
                        if (uc.txtpagelabel.Text != null && uc.txtpagelabel.Text != "")
                            _objdocdetails.PageLabel = uc.txtpagelabel.Text;
                        else
                        {
                            _objdocdetails.PageLabel = "";
                        }

                    }
                    string PageLabelError = null;
                    if (!Validations.ValidatePageLabel(uc.txtpagelabel.Text, ref PageLabelError))
                    {
                        MessageBox.Show(PageLabelError, "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        uc.txtpagelabel.Focus();
                        return false;
                    }



                    #region Added by kranthi April 7th 2014	Incorporate Page Number and Label validation at Curation level.

                    if (Generic.globalVariables.IsPatent)
                    {
                        if (_lsttanchild != null)
                        {
                            if (_lsttanchild.Count > 0)
                            {
                                clsCASChild rxn = _lsttanchild.Find(delegate(clsCASChild p) { return p.PageNumber != 0 && p.PageLabel != null && p.PageNumber.ToString() == uc.txtpagenumber.Text.Trim() && p.PageLabel.ToString() != uc.txtpagelabel.Text.Trim(); });

                                if (rxn != null)
                                {
                                    if (MessageBox.Show("In Nar" + rxn.NarrativeID + " PageNumber " + rxn.PageNumber + " is specified for Pagelabel " + rxn.PageLabel + "\n Do you want to continue ?", "CAS Narrative", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.No)
                                    {
                                        return false;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        if (_lsttanchild != null)
                        {
                            if (_lsttanchild.Count > 0)
                            {
                                clsCASChild rxn = _lsttanchild.Find(delegate(clsCASChild p) { return p.PageNumber != 0 && p.PageLabel != null && p.PageNumber.ToString() == uc.txtpagenumber.Text.Trim() && p.PageLabel.ToString() != uc.txtpagelabel.Text.Trim(); });

                                if (rxn != null)
                                {
                                    MessageBox.Show("In Nar" + rxn.NarrativeID + " PageNumber " + rxn.PageNumber + " is specified for Pagelabel " + rxn.PageLabel, "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    return false;
                                }
                            }
                        }
                    }
                    #endregion



                    if (uc.txtfilename.Text != null && uc.txtfilename.Text != "")
                        _objdocdetails.filename = uc.txtfilename.Text;
                    else
                    {
                        MessageBox.Show("FileName  can't be blank", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        uc.txtfilename.Focus();
                        return false;
                    }

                    bool ischeckprocempty = uc.chkisgeneralprocempty.Checked;
                                        

                    if (uc.txtxpagesize.Text != null && uc.txtxpagesize.Text != "" && uc.txtxpagesize.Text != "0")
                        _objdocdetails.XPageSize = Convert.ToDouble(uc.txtxpagesize.Text);
                    else
                    {
                        if (!ischeckprocempty)
                        {
                            MessageBox.Show("X Page Size  can't be 0", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            uc.txtxpagesize.Focus();
                            return false;
                        }
                    }


                    if (uc.txtxoffset.Text != null && uc.txtxoffset.Text != "" && uc.txtxoffset.Text != "0")
                        _objdocdetails.XOffset = Convert.ToDouble(uc.txtxoffset.Text);
                    else
                    {
                        if (!ischeckprocempty)
                        {
                            MessageBox.Show("X Off Set  can't be 0", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            uc.txtxoffset.Focus();
                            return false;
                        }
                    }


                    //if (uc.txtyresunit.Text != null && uc.txtyresunit.Text != "")
                    //    _objdocdetails.YResUnit = uc.txtyresunit.Text;
                    //else
                    //{
                    //    if (!ischeckprocempty)
                    //    {
                    //        MessageBox.Show("Y Length Unit  can't be blank", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //        uc.txtyresunit.Focus();
                    //        return false;
                    //    }
                    //}





                    if (uc.txtypagesize.Text != null && uc.txtypagesize.Text != "" && uc.txtypagesize.Text != "0")
                        _objdocdetails.YPageSize = Convert.ToDouble(uc.txtypagesize.Text);
                    else
                    {
                        if (!ischeckprocempty)
                        {
                            MessageBox.Show("Y Page Size  can't be 0", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            uc.txtypagesize.Focus();
                            return false;
                        }
                    }


                    if (uc.txtyoffset.Text != null && uc.txtyoffset.Text != "")
                        _objdocdetails.YOffset = Convert.ToDouble(uc.txtyoffset.Text);
                    else
                    {
                        if (!ischeckprocempty)
                        {
                            MessageBox.Show("Y Off Set  can't be 0", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            uc.txtyoffset.Focus();
                            return false;
                        }
                    }


                    if (IsRichTextboxIsEmptry(uc.rtxttextlinepreview))
                        _objdocdetails.TextLine = uc.TanDetails.TextLine;
                    else
                    {
                        if (!ischeckprocempty)
                        {
                            MessageBox.Show("TextLine  can't be blank", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            uc.rtxttextlinepreview.Focus();
                            return false;
                        }

                    }


                    if (uc.txtnarrativeid.Text != null && uc.txtnarrativeid.Text != "")
                    {
                        //string[] strnars = null;
                        //if (uc.txtnarrativeid.Text.ToUpper().Contains("ANALOGOUSTO=NAR"))
                        //{
                        //    strnars = uc.txtnarrativeid.Text.Split("analogousTo=");
                        //    if(strnars
                        //}
                        //else

                        _objdocdetails.NarrativeID = uc.txtnarrativeid.Text; //uc.GetNarId();

                    }

                    else
                    {

                        MessageBox.Show("Narrative ID  can't be blank", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return false;
                        //return;
                    }
                    if (uc.chkIsAnalogous.Checked)
                    {
                        if (uc.cmbAnalogousTo.SelectedValue != null || uc.cmbAnalogousTo.SelectedIndex == -1)
                        {
                            _objdocdetails.IsAnalogous = true;
                            _objdocdetails.AnalogousTo = Convert.ToInt32(uc.cmbAnalogousTo.SelectedValue); //uc.cmbAnalogousTo.Text;
                        }
                        else
                        {
                            MessageBox.Show("Is analogous checked, select analogous to Narid.", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            uc.chkIsAnalogous.Focus();
                            return false;
                            //return;
                        }
                    }


                    if (uc.rtxtparapreview.Tag != null)
                    {
                        _objdocdetails.Para = uc.TanDetails.Para;
                    }
                    else
                        _objdocdetails.Para = "";

                    //uc.txtpara1.Focus();

                    if (uc.txtpara1.Tag != null)
                    {
                        _objdocdetails.Para1 = uc.TanDetails.Para1; //uc.txtpara1.Tag.ToString();
                    }
                    else
                        _objdocdetails.Para1 = "";


                    if (uc.rtxtdatapreview.Tag != null)
                    {
                        _objdocdetails.Data = uc.TanDetails.Data; //uc.rtxtdatapreview.Tag.ToString();
                    }
                    else
                        _objdocdetails.Data = "";





                    _objdocdetails.isGeneralTypical = uc.chkisGeneralTypical.Checked;
                    _objdocdetails.noexperimentaldetails = uc.chkisgeneralprocempty.Checked;


                    _objdocdetails.IsAnalogous = uc.chkIsAnalogous.Checked;

                    //if (uc.chkIsAnalogous.Checked)
                    //{
                    //    if (uc.cmbAnalogousTo.Text != null || uc.cmbAnalogousTo.Text != "")
                    //    {
                    //        _objdocdetails.AnalogousTo = uc.cmbAnalogousTo.Text;
                    //    }
                    //    else
                    //    {
                    //        MessageBox.Show("Is Analogous checked,select Analogous to nar id.", "CAS Narrative", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    //        return false;
                    //    }
                    //}
                }
                else
                {
                    if (ValidateIsMissingReacion(uc))
                    {
                        uc.ResetFieldsforMissingRxn();
                    }
                    else
                    {
                        uc.chkIsMissingRxn.Checked = false;
                        return false;
                    }
                }
                _objdocdetails.IsMissingReaction = uc.chkIsMissingRxn.Checked;
                _objdocdetails.IsCurationComplete = chkIsRxnComplete.Checked;


                //_objdocdetails.Data1 = uc.TanDetails.Data1;

                objdocument = _objdocument;
                objdocdetails = _objdocdetails;
                return true;



            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
                objdocdetails = null;
                objdocument = null;
                return false;
            }
            //return false;

        }

        private bool ValidateIsMissingReacion(uccasnartool_new uc)
        {
            bool Status = false;
            bool IsValid = true;
            try
            {
                if (uc.txtdocref.Text != "")
                {
                    // // MessageBox.Show("docRef should be blank when reaction is missing.", "CAS Narrative", // MessageBoxButtons.OK, // MessageBoxIcon.Information);
                    IsValid = false;
                }


                if (uc.txtpagenumber.Text != "" || uc.txtpagenumber.Text != "0")
                {
                    //  // MessageBox.Show("PageNumber  should be blank when reaction is missing.", "CAS Narrative", // MessageBoxButtons.OK, // MessageBoxIcon.Information);

                    IsValid = false;
                }


                if (Generic.globalVariables.IsPatent)
                {

                    if (uc.txtpagelabel.Text != "")
                    {
                        // MessageBox.Show("PageLabel  should be blank when reaction is missing.", "CAS Narrative", // MessageBoxButtons.OK, // MessageBoxIcon.Information);

                        IsValid = false;
                    }
                }
                else
                {
                    if (uc.txtpagelabel.Text != "")
                    {
                        //  _objdocdetails.PageLabel = "";
                    }

                }



                if (uc.txtfilename.Text != "")
                {
                    // MessageBox.Show("FileName  should be blank when reaction is missing.", "CAS Narrative", // MessageBoxButtons.OK, // MessageBoxIcon.Information);

                    IsValid = false;
                }

                bool ischeckprocempty = uc.chkisgeneralprocempty.Checked;

                //if (uc.txtxpageunit.Text != "")
                //{
                //    if (!ischeckprocempty)
                //    {
                //        // MessageBox.Show("X Length Unit should be blank when reaction is missing.", "CAS Narrative", // MessageBoxButtons.OK, // MessageBoxIcon.Information);

                //        IsValid = false;
                //    }
                //}



                if (uc.txtxpagesize.Text != "" || uc.txtxpagesize.Text != "0")
                {
                    if (!ischeckprocempty)
                    {
                        // MessageBox.Show("X Page Size should be blank when reaction is missing.", "CAS Narrative", // MessageBoxButtons.OK, // MessageBoxIcon.Information);

                        IsValid = false;
                    }
                }


                if (uc.txtxoffset.Text != "" || uc.txtxoffset.Text != "0")
                {
                    if (!ischeckprocempty)
                    {
                        // MessageBox.Show("X Off Set should be blank when reaction is missing.", "CAS Narrative", // MessageBoxButtons.OK, // MessageBoxIcon.Information);

                        IsValid = false;
                    }
                }


                if (uc.txtyresunit.Text != "")
                {
                    if (!ischeckprocempty)
                    {
                        // MessageBox.Show("Y Length Unit  should be blank when reaction is missing.", "CAS Narrative", // MessageBoxButtons.OK, // MessageBoxIcon.Information);

                        IsValid = false;
                    }
                }





                if (uc.txtypagesize.Text != "" || uc.txtypagesize.Text != "0")
                {
                    if (!ischeckprocempty)
                    {
                        // MessageBox.Show("Y Page Size should be blank when reaction is missing.", "CAS Narrative", // MessageBoxButtons.OK, // MessageBoxIcon.Information);

                        IsValid = false;
                    }
                }


                if (uc.txtyoffset.Text != "" || uc.txtyoffset.Text != "0")
                {
                    if (!ischeckprocempty)
                    {
                        // MessageBox.Show("Y Off Set should be blank when reaction is missing.", "CAS Narrative", // MessageBoxButtons.OK, // MessageBoxIcon.Information);

                        IsValid = false;
                    }
                }


                if (IsRichTextboxIsEmptry(uc.rtxttextlinepreview))
                {
                    if (!ischeckprocempty)
                    {
                        // MessageBox.Show("TextLine should be blank when reaction is missing.", "CAS Narrative", // MessageBoxButtons.OK, // MessageBoxIcon.Information);

                        IsValid = false;
                    }

                }


                if (uc.txtnarrativeid.Text != "")
                {
                    //string[] strnars = null;
                    //if (uc.txtnarrativeid.Text.ToUpper().Contains("ANALOGOUSTO=NAR"))
                    //{
                    //    strnars = uc.txtnarrativeid.Text.Split("analogousTo=");
                    //    if(strnars
                    //}
                    //else

                    // MessageBox.Show("Narrative ID should be blank when reaction is missing.", "CAS Narrative", // MessageBoxButtons.OK, // MessageBoxIcon.Information);
                    IsValid = false;
                    //return;
                }

                if (uc.rtxtparapreview.Tag != null)
                {
                    // _objdocdetails.Para = uc.TanDetails.Para;
                }
                // else
                // _objdocdetails.Para = "";

                //uc.txtpara1.Focus();

                if (uc.txtpara1.Tag != null)
                {
                    // _objdocdetails.Para1 = uc.TanDetails.Para1; //uc.txtpara1.Tag.ToString();
                }
                //    else
                // _objdocdetails.Para1 = "";


                if (uc.rtxtdatapreview.Tag != null)
                {
                    // _objdocdetails.Data = uc.TanDetails.Data; //uc.rtxtdatapreview.Tag.ToString();
                }
                //    else
                // _objdocdetails.Data = "";
                //




                //_objdocdetails.isGeneralTypical = uc.chkisGeneralTypical.Checked;
                //_objdocdetails.noexperimentaldetails = uc.chkisgeneralprocempty.Checked;


                //_objdocdetails.IsAnalogous = uc.chkIsAnalogous.Checked;

                uc.chkIsAnalogous.Checked = false;
                //if (uc.chkIsAnalogous.Checked)
                //{
                //    if (uc.cmbAnalogousTo.SelectedText != null || uc.cmbAnalogousTo.SelectedText != "")
                //    {
                //       // _objdocdetails.AnalogousTo = uc.cmbAnalogousTo.SelectedText;
                //    }
                //    else
                //    {
                //        // MessageBox.Show("Is Analogous checked,select Analogous to nar id.", "CAS Narrative", // MessageBoxButtons.OK, // MessageBoxIcon.Information);
                //        uc.cmbAnalogousTo.Focus();
                //        return false;
                //    }
                //}

                if (!IsValid)
                {
                    if (MessageBox.Show("Do you want to make this reaction as missing reaction ? ", "CAS Narrative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        uccasnartool_new1.ResetFieldsforMissingRxn();
                        Status = true;
                    }
                }
                return Status;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
                return Status;
            }
        }

        #endregion

        private bool IsRichTextboxIsEmptry(HtmlRichText.HtmlRichTextBox _rtf)
        {
            try
            {
                if (_rtf.Text == null)
                {
                    return false;
                }
                else
                {
                    string strtext = _rtf.Text;
                    strtext = strtext.Replace("\r\n", "");
                    strtext = strtext.Replace("\n", "");
                    strtext = strtext.Replace(" ", "");
                    if (strtext.Length == 0)
                    {
                        return false;
                    }
                    else
                        return true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return false;
        }

        //private void tsAddreaction_Click(object sender, EventArgs e)
        //{
        //    //sairam
        //    if (DAL.Connection.isConnectionAvailable())
        //    {
        //        btnAddReaction_Click(sender, e);
        //    }
        //    else
        //    {
        //        MessageBox.Show("There doest seem to be a network/internet connection.Please contact your system administrator");
        //    }
        //}

        private void chkwordwrap_CheckedChanged(object sender, EventArgs e)
        {
            if (chkwordwrap.Checked)
                tb1rtftextbox.WordWrap = true;
            else
                tb1rtftextbox.WordWrap = false;
        }

        #region Preview Text

        frmpreviewtext frmpre = null;
        private void tb1btnpreview_Click(object sender, EventArgs e)
        {

            try
            {

                SautinSoft.RtfToHtml r = new SautinSoft.RtfToHtml();

                r.OutputFormat = SautinSoft.eOutputFormat.HTML_401;
                r.Encoding = SautinSoft.eEncoding.UTF_8;


                string rtfFile = tb1rtftextbox.Rtf.ToString();
                string rtfString = tb1rtftextbox.Rtf.ToString();
                string htmlString = "";


                //htmlString = tb1rtftextbox.GetHTML(true, true);
                htmlString = r.ConvertString(rtfString);


                Hashtable htsymbols = FillSymbolsfromControls();

                if (htsymbols != null)
                {
                    foreach (string strkey in htsymbols.Keys)
                    {
                        if (htmlString.Contains(strkey))
                        {
                            htmlString = htmlString.Replace(strkey, htsymbols[strkey].ToString());
                        }
                    }
                }
                //tb1rtftextbox.GetHTML(true,true)

                tb1rtxteditor.Document.body.innerHTML = htmlString;
                if (validations.Validatations.CheckFormIsOpenedORnot("frmpreviewtext", frmpre))
                {
                    frmpre.Close();

                }

                frmpre = new frmpreviewtext();

                htmlString = "";

                string strremovestr1 = "Trial version can convert no more than 30000 symbols.";
                string strremovestr2 = "Get the full \r\nfeatured version!</A>";
                string strremovestr3 = "";



                //htmlString = r.ConvertString(rtfString);
                tb1rtxteditor.SelectAll();

                IHTMLSelectionObject objselection = tb1rtxteditor.Document.selection;
                IHTMLTxtRange objrange = (IHTMLTxtRange)objselection.createRange();


                string strtempfilepath = AppDomain.CurrentDomain.BaseDirectory + "temp.txt";
                //htmlString = element.innerHTML;
                htmlString = objrange.htmlText;
                StreamReader sr = new StreamReader(strtempfilepath);
                strremovestr3 = sr.ReadToEnd();
                if (htmlString.Contains(strremovestr1))
                {
                    htmlString = htmlString.Replace(strremovestr1, "");
                }
                if (htmlString.Contains(strremovestr2))
                {
                    htmlString = htmlString.Replace(strremovestr2, "");
                }
                if (htmlString.Contains(strremovestr3))
                {
                    htmlString = htmlString.Replace(strremovestr3, "");
                }


                string strpreview = validations.richtextvalidations.stripHTMLTags(htmlString);
                strpreview = strpreview.Replace("&lt;", "<");
                strpreview = strpreview.Replace("&gt;", ">");
                strpreview = strpreview.Replace("&amp;", "&");
                strpreview = validations.richtextvalidations.FindAndReplaceStrings(strpreview, dsFandR);
                strpreview = strpreview.Replace("&nbsp;", " ").TrimEnd();
                strpreview = strpreview.Replace("<bold></bold>", "");
                strpreview = strpreview.Replace("<ital><bold></bold></ital>", "");
                strpreview = strpreview.Replace("<ital></ital>", "");
                strpreview = strpreview.Replace("<bold> </bold>", "");
                strpreview = strpreview.Replace("<sup><bold></bold></sup>", "");
                strpreview = strpreview.Replace("<sup><bold> </bold></sup>", "");
                strpreview = strpreview.Replace("<bold><sup> </sup></bold>", "");

                strpreview = strpreview.Replace("<sub><bold></bold></sub>", "");
                strpreview = strpreview.Replace("<sub><bold> </bold></sub>", "");
                strpreview = strpreview.Replace("<bold><sub> </sub></bold>", "");


                frmpre.PreviewString = strpreview.Trim();

                frmpre.Show();


            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }

        }

        #endregion

        //private string GetHtmlstringfromRichTextbox(HtmlRichText.HtmlRichTextBox rtf)
        //{
        //    if (rtf.Text != null)
        //    {

        //        try
        //        {
        //            try
        //            {

        //                SautinSoft.RtfToHtml r = new SautinSoft.RtfToHtml();

        //                r.OutputFormat = SautinSoft.eOutputFormat.HTML_401;
        //                r.Encoding = SautinSoft.eEncoding.UTF_8;


        //                string rtfFile = rtf.Rtf.ToString();
        //                string rtfString = rtf.Rtf.ToString();
        //                string htmlString = "";


        //                //htmlString = tb1rtftextbox.GetHTML(true, true);
        //                htmlString = r.ConvertString(rtfString);


        //                Hashtable htsymbols = FillSymbolsfromControls();

        //                if (htsymbols != null)
        //                {
        //                    foreach (string strkey in htsymbols.Keys)
        //                    {
        //                        if (htmlString.Contains(strkey))
        //                        {
        //                            htmlString = htmlString.Replace(strkey, htsymbols[strkey].ToString());
        //                        }
        //                    }
        //                }

        //                _htmlstring = htmlString;


        //                string strremovestr1 = "Trial version can convert no more than 30000 symbols.";
        //                string strremovestr2 = "Get the full \r\nfeatured version!</A>";
        //                string strremovestr3 = "";



        //                string strtempfilepath = AppDomain.CurrentDomain.BaseDirectory + "temp.txt";

        //                htmlString = _objrange.htmlText;
        //                StreamReader sr = new StreamReader(strtempfilepath);
        //                strremovestr3 = sr.ReadToEnd();
        //                if (htmlString.Contains(strremovestr1))
        //                {
        //                    htmlString = htmlString.Replace(strremovestr1, "");
        //                }
        //                if (htmlString.Contains(strremovestr2))
        //                {
        //                    htmlString = htmlString.Replace(strremovestr2, "");
        //                }
        //                if (htmlString.Contains(strremovestr3))
        //                {
        //                    htmlString = htmlString.Replace(strremovestr3, "");
        //                }


        //                string strpreview = validations.richtextvalidations.stripHTMLTags(htmlString);
        //                strpreview = strpreview.Replace("&lt;", "<");
        //                strpreview = strpreview.Replace("&gt;", ">");
        //                strpreview = strpreview.Replace("&amp;", "&");
        //                strpreview = validations.richtextvalidations.FindAndReplaceStrings(strpreview, dsFandR);
        //                strpreview = strpreview.Replace("&nbsp;", " ").TrimEnd();
        //                strpreview = strpreview.Replace("<bold></bold>", "");
        //                strpreview = strpreview.Replace("<ital><bold></bold></ital>", "");
        //                strpreview = strpreview.Replace("<ital></ital>", "");
        //                strpreview = strpreview.Replace("<bold> </bold>", "");
        //                return strpreview.Trim();




        //            }
        //            catch (Exception ex)
        //            {
        //                ErrorHandling.WriteErrorLog(ex.ToString());
        //            }


        //        }
        //        catch (Exception ex)
        //        {
        //            ErrorHandling.WriteErrorLog(ex.ToString());
        //        }
        //    }
        //    return "";
        //}

        #region Tool Strip

        //bold
        private void toolStripButton2_Click(object sender, EventArgs e)
        {


            try
            {
                if (tb1rtftextbox.Focused)
                {
                    if (tb1rtftextbox.SelectedText != null)
                    {
                        if (tb1rtftextbox.SelectionFont == null)
                            tb1rtftextbox.SelectionFont = new Font(tb1rtftextbox.Font, tb1rtftextbox.Font.Style ^ FontStyle.Bold);
                        else
                            tb1rtftextbox.SelectionFont = new Font(tb1rtftextbox.SelectionFont, tb1rtftextbox.SelectionFont.Style ^ FontStyle.Bold);
                    }
                }
                else
                {
                    HtmlRichText.HtmlRichTextBox htrtfbox = GetFocusedControl();

                    if (htrtfbox != null)
                    {

                        if (htrtfbox.SelectedText != null)
                        {
                            if (htrtfbox.SelectionFont == null)
                                htrtfbox.SelectionFont = new Font(htrtfbox.Font, htrtfbox.Font.Style ^ FontStyle.Bold);
                            else
                                htrtfbox.SelectionFont = new Font(htrtfbox.SelectionFont, htrtfbox.SelectionFont.Style ^ FontStyle.Bold);
                        }

                    }

                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }

        }

        //underline
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            try
            {
                if (tb1rtftextbox.Focused)
                {
                    if (tb1rtftextbox.SelectedText != null)
                    {
                        if (tb1rtftextbox.SelectionFont == null)
                            tb1rtftextbox.SelectionFont = new Font(tb1rtftextbox.Font, tb1rtftextbox.Font.Style ^ FontStyle.Underline);
                        else
                            tb1rtftextbox.SelectionFont = new Font(tb1rtftextbox.SelectionFont, tb1rtftextbox.SelectionFont.Style ^ FontStyle.Underline);
                    }
                }
                else
                {
                    HtmlRichText.HtmlRichTextBox htrtfbox = GetFocusedControl();

                    if (htrtfbox != null)
                    {

                        if (htrtfbox.SelectedText != null)
                        {
                            if (htrtfbox.SelectionFont == null)
                                htrtfbox.SelectionFont = new Font(htrtfbox.Font, htrtfbox.Font.Style ^ FontStyle.Underline);
                            else
                                htrtfbox.SelectionFont = new Font(htrtfbox.SelectionFont, htrtfbox.SelectionFont.Style ^ FontStyle.Underline);
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        //italic
        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            try
            {
                if (tb1rtftextbox.Focused)
                {
                    if (tb1rtftextbox.SelectedText != null)
                    {
                        if (tb1rtftextbox.SelectionFont == null)
                            tb1rtftextbox.SelectionFont = new Font(tb1rtftextbox.Font, tb1rtftextbox.Font.Style ^ FontStyle.Italic);
                        else
                            tb1rtftextbox.SelectionFont = new Font(tb1rtftextbox.SelectionFont, tb1rtftextbox.SelectionFont.Style ^ FontStyle.Italic);
                    }
                }
                else
                {
                    HtmlRichText.HtmlRichTextBox htrtfbox = GetFocusedControl();

                    if (htrtfbox != null)
                    {

                        if (htrtfbox.SelectedText != null)
                        {
                            if (htrtfbox.SelectionFont == null)
                                htrtfbox.SelectionFont = new Font(htrtfbox.Font, htrtfbox.Font.Style ^ FontStyle.Italic);
                            else
                                htrtfbox.SelectionFont = new Font(htrtfbox.SelectionFont, htrtfbox.SelectionFont.Style ^ FontStyle.Italic);
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }

        }
        //Regulrar
        private void toolStripButton6_Click(object sender, EventArgs e)
        {

            try
            {
                if (tb1rtftextbox.Focused)
                {
                    if (tb1rtftextbox.SelectedText != null)
                    {
                        if (tb1rtftextbox.SelectionFont == null)
                            tb1rtftextbox.SelectionFont = new Font(tb1rtftextbox.Font, tb1rtftextbox.Font.Style ^ FontStyle.Regular);
                        else
                            tb1rtftextbox.SelectionFont = new Font(tb1rtftextbox.SelectionFont, tb1rtftextbox.SelectionFont.Style ^ FontStyle.Regular);
                    }
                }
                else
                {
                    HtmlRichText.HtmlRichTextBox htrtfbox = GetFocusedControl();

                    if (htrtfbox != null)
                    {

                        if (htrtfbox.SelectedText != null)
                        {
                            if (htrtfbox.SelectionFont == null)
                                htrtfbox.SelectionFont = new Font(htrtfbox.Font, htrtfbox.Font.Style ^ FontStyle.Regular);
                            else
                                htrtfbox.SelectionFont = new Font(htrtfbox.SelectionFont, htrtfbox.SelectionFont.Style ^ FontStyle.Regular);
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        //Superscript
        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            if (tb1rtftextbox.Focused)
            {
                if (!tb1rtftextbox.IsSuperScript())
                {
                    tb1rtftextbox.SetSuperScript(true);
                    tb1rtftextbox.SetSubScript(false);
                }
                else
                    tb1rtftextbox.SetSuperScript(false);
            }
            else
            {

                HtmlRichText.HtmlRichTextBox htrtfbox = GetFocusedControl();

                if (htrtfbox != null)
                {
                    if (!htrtfbox.IsSuperScript())
                    {
                        htrtfbox.SetSuperScript(true);
                        htrtfbox.SetSubScript(false);
                    }
                    else
                        htrtfbox.SetSuperScript(false);

                }

            }
        }
        //Subscript
        private void toolStripButton8_Click(object sender, EventArgs e)
        {
            if (tb1rtftextbox.Focused)
            {
                if (!tb1rtftextbox.IsSubScript())
                {
                    tb1rtftextbox.SetSubScript(true);
                    tb1rtftextbox.SetSuperScript(false);
                }
                else
                    tb1rtftextbox.SetSubScript(false);
            }
            else
            {


                HtmlRichText.HtmlRichTextBox htrtfbox = GetFocusedControl();

                if (htrtfbox != null)
                {
                    if (!htrtfbox.IsSubScript())
                    {
                        htrtfbox.SetSubScript(true);
                        htrtfbox.SetSuperScript(false);
                    }
                    else
                        htrtfbox.SetSubScript(false);
                }

            }

        }
        //Font
        private void toolStripButton9_Click(object sender, EventArgs e)
        {
            if (tb1rtftextbox.Focused)
            {
                if (tb1rtftextbox.SelectionFont != null)
                    fontDialog1.Font = tb1rtftextbox.SelectionFont;
                else
                    fontDialog1.Font = tb1rtftextbox.Font;

                if (fontDialog1.ShowDialog() == DialogResult.OK)
                {
                    if (tb1rtftextbox.SelectionFont != null)
                        tb1rtftextbox.SelectionFont = fontDialog1.Font;
                    else
                        if (tb1rtftextbox.SelectedText != null)
                        {
                            tb1rtftextbox.SelectionFont = fontDialog1.Font;
                        }

                }
            }
            else
            {

                HtmlRichText.HtmlRichTextBox htrtfbox = GetFocusedControl();

                if (htrtfbox != null)
                {

                    if (htrtfbox.SelectionFont != null)
                        fontDialog1.Font = htrtfbox.SelectionFont;
                    else
                        fontDialog1.Font = htrtfbox.Font;

                    if (fontDialog1.ShowDialog() == DialogResult.OK)
                    {
                        if (htrtfbox.SelectionFont != null)
                            htrtfbox.SelectionFont = fontDialog1.Font;
                        else
                            if (htrtfbox.SelectedText != null)
                            {
                                htrtfbox.SelectionFont = fontDialog1.Font;
                            }

                    }
                }

            }


        }

        private void tsUndo_Click(object sender, EventArgs e)
        {

            if (tb1rtftextbox.Focused)
                tb1rtftextbox.Undo();
            else
            {
                HtmlRichText.HtmlRichTextBox htrtfbox = GetFocusedControl();
                if (htrtfbox != null)
                {
                    htrtfbox.Undo();
                }

            }
        }

        private void tsredo_Click(object sender, EventArgs e)
        {

            if (tb1rtftextbox.Focused)
                tb1rtftextbox.Redo();
            else
            {
                HtmlRichText.HtmlRichTextBox htrtfbox = GetFocusedControl();
                if (htrtfbox != null)
                {
                    htrtfbox.Redo();
                }

            }
        }

        private void tsconvformula_Click(object sender, EventArgs e)
        {
            toolStripButton12_Click(sender, e);
        }


        private void btnPageSize_Click(object sender, EventArgs e)
        {
            try
            {
                //uccasnartool uc = GetSelectedUserControl();
                //if (uc != null)
                //{
                try
                {

                    double height = Convert.ToDouble(dgviewer.ImageHeight) / 199;
                    double Width = Convert.ToDouble(dgviewer.ImageWidth) / 199;
                    height = height - 0.06;
                    Width = Width - 0.04;
                    if (height > 0 && Width > 0)
                    {
                        if (MessageBox.Show("Page height '" + height.ToString("0.00") + "',Page width '" + Width.ToString("0.00") + "', Do you want to save these values in clipboard?", "CAS Narrative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                        {
                            //uc.txtxpagesize.Text = Width.ToString("0.00");
                            //uc.txtypagesize.Text = height.ToString("0.00");

                            Clipboard.Clear();
                            //MessageBox.Show("XY Coordinates saved into clipboard","CAS_Narrative-Tool",MessageBoxButtons.OK,MessageBoxIcon.Information);
                            Clipboard.SetData(DataFormats.Text, "PAGESIZES : " + height.ToString("0.00") + ":" + Width.ToString("0.00"));
                        }
                    }
                }
                catch (Exception ex)
                {
                    ErrorHandling.WriteErrorLog(ex.ToString());
                }
                //}

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        //undo
        private void toolStripButton10_Click(object sender, EventArgs e)
        {
            if (tb1rtftextbox.Focused)
                tb1rtftextbox.Undo();
            else
            {
                HtmlRichText.HtmlRichTextBox htrtfbox = GetFocusedControl();
                if (htrtfbox != null)
                {
                    htrtfbox.Undo();
                }

            }
        }
        //redo
        private void toolStripButton11_Click(object sender, EventArgs e)
        {
            if (tb1rtftextbox.Focused)
                tb1rtftextbox.Redo();
            else
            {
                HtmlRichText.HtmlRichTextBox htrtfbox = GetFocusedControl();
                if (htrtfbox != null)
                {
                    htrtfbox.Redo();
                }

            }
        }
        //convformula
        private void toolStripButton12_Click(object sender, EventArgs e)
        {
            try
            {
                if (tb1rtftextbox.Focused)
                {
                    if (tb1rtftextbox.SelectedText != null)
                    {

                        rtfformula.Text = "";
                        rtfformula.Text = tb1rtftextbox.SelectedText;
                        int startposition = tb1rtftextbox.SelectionStart;
                        int endpostion = tb1rtftextbox.SelectionLength;
                        string a = tb1rtftextbox.SelectedText;
                        for (int i = 0; i < a.Length; i++)
                        {

                            string x = a.Substring(i, 1);

                            if (char.IsNumber(Convert.ToChar(x)))
                            {
                                rtfformula.Select(i, 1);
                                rtfformula.SetSubScript(true);
                                rtfformula.SetSuperScript(false);
                            }
                        }
                        rtfformula.SelectAll();
                        tb1rtftextbox.SelectedRtf = rtfformula.SelectedRtf;


                    }
                }
                else
                {

                    HtmlRichText.HtmlRichTextBox htrtfbox = GetFocusedControl();
                    if (htrtfbox != null)
                    {
                        if (htrtfbox.SelectedText != null)
                        {

                            rtfformula.Text = "";
                            rtfformula.Rtf = htrtfbox.SelectedRtf;
                            int startposition = htrtfbox.SelectionStart;
                            int endpostion = htrtfbox.SelectionLength;
                            string a = htrtfbox.SelectedText;
                            for (int i = 0; i < a.Length; i++)
                            {

                                string x = a.Substring(i, 1);

                                if (char.IsNumber(Convert.ToChar(x)))
                                {
                                    rtfformula.Select(i, 1);
                                    rtfformula.SetSubScript(true);
                                    rtfformula.SetSuperScript(false);
                                }
                            }
                            //Zero First Test
                            for (int i = 0; i < a.Length; i++)
                            {
                                string x = a.Substring(i, 1);
                                bool iszerofirst = false;
                                int zerofirstindex = 0;
                                bool isafterzeronumber = false;
                                if (char.IsNumber(Convert.ToChar(x)))
                                {
                                    if (Convert.ToInt32(x) == 0)
                                    {
                                        iszerofirst = true;
                                        zerofirstindex = i;
                                        Char[] ca = a.ToCharArray();
                                        if (ca != null && ca.Length > 0)
                                        {
                                            if (ca.Length > zerofirstindex + 1)
                                            {
                                                string _strvalue = ca[zerofirstindex].ToString() + ca[zerofirstindex + 1].ToString();
                                                if (char.IsNumber(ca[zerofirstindex + 1]))
                                                {
                                                    if (MessageBox.Show("Zero exists before numeric value in formula, value is " + _strvalue + " . Is it correct?", "CAS Narrative", MessageBoxButtons.YesNo, MessageBoxIcon.Information) != DialogResult.Yes)
                                                    {
                                                        return;
                                                    }
                                                    else
                                                        break;

                                                }
                                            }
                                        }
                                    }
                                }

                            }

                            //If c repeates in formula more than one times
                            int ccount = 0;
                            bool isnumber = false;
                            for (int i = 0; i < a.Length; i++)
                            {

                                string x = a.Substring(i, 1);
                                if (x.ToString().ToUpper() == "C")
                                {
                                    if (a.Length > i + 1)
                                    {
                                        string y = a.Substring(i + 1, 1);
                                        if (char.IsNumber(Convert.ToChar(y)))
                                        {
                                            ccount++;
                                        }
                                    }
                                }
                            }
                            if (ccount > 1)
                            {
                                if (MessageBox.Show("C repeates " + ccount + " times in formula, is it correct formula?", "CAS Narrative", MessageBoxButtons.YesNo, MessageBoxIcon.Information) != DialogResult.Yes)
                                {
                                    return;
                                }

                            }




                            if (rtfformula.SelectedText != null)
                            {
                                for (int i = 0; i < rtfformula.Text.Length; i++)
                                {
                                    if (rtfformula.Text.Substring(i, 1) == "0")
                                    {
                                        rtfformula.Select(i, 1);
                                        rtfformula.SelectionBackColor = Color.Red;

                                    }
                                }
                            }
                            rtfformula.SelectAll();
                            htrtfbox.SelectedRtf = rtfformula.SelectedRtf.Replace("\r\n", "");




                        }
                    }

                }


            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }


        }

        private HtmlRichText.HtmlRichTextBox GetFocusedControl()
        {
            try
            {

                // uccasnartool_new uc = GetSelectedUserControl();
                if (uccasnartool_new1 != null)
                {

                    Control[] ctxtline = uccasnartool_new1.pnlMain.Controls.Find("rtxttextlinepreview", false);
                    if (ctxtline != null)
                    {
                        HtmlRichText.HtmlRichTextBox tr = (HtmlRichText.HtmlRichTextBox)ctxtline[0];
                        if (tr.Focused)
                        {
                            return tr;
                        }
                    }
                    //Control[] c1 = uc.splitContainer2.Panel2.Controls.Find("rtxtparapreview", false);
                    //if (c1 != null)
                    //{
                    //    HtmlRichText.HtmlRichTextBox tr = (HtmlRichText.HtmlRichTextBox)c1[0];
                    //    if (tr.Focused)
                    //    {
                    //        return tr;
                    //    }
                    //}
                    Control[] c2 = uccasnartool_new1.splCntParaPara1.Panel1.Controls.Find("rtxtparapreview", false);
                    if (c2 != null)
                    {
                        HtmlRichText.HtmlRichTextBox tr = (HtmlRichText.HtmlRichTextBox)c2[0];
                        if (tr.Focused)
                        {
                            return tr;
                        }
                    }
                    //txtpara1
                    Control[] c3 = uccasnartool_new1.splCntParaPara1.Panel2.Controls.Find("txtpara1", false);
                    if (c3 != null)
                    {
                        HtmlRichText.HtmlRichTextBox tr = (HtmlRichText.HtmlRichTextBox)c3[0];
                        if (tr.Focused)
                        {
                            return tr;
                        }
                    }
                    //rtxtdatapreview
                    Control[] c4 = uccasnartool_new1.splDataData2.Panel1.Controls.Find("rtxtdatapreview", false);
                    if (c4 != null)
                    {
                        HtmlRichText.HtmlRichTextBox tr = (HtmlRichText.HtmlRichTextBox)c4[0];
                        if (tr.Focused)
                        {
                            return tr;
                        }
                    }

                    Control[] c5 = uccasnartool_new1.splDataData2.Panel2.Controls.Find("rtxtdata1", false);
                    if (c5 != null)
                    {
                        HtmlRichText.HtmlRichTextBox tr = (HtmlRichText.HtmlRichTextBox)c5[0];
                        if (tr.Focused)
                        {
                            return tr;
                        }
                    }


                }

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return null;
        }

        #endregion

        #region Tool strip special char

        private void toolStrip3_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            #region Code

            try
            {
                if (e != null)
                {


                    if (tb1rtftextbox.Focused)
                    {

                        #region MyRegion
                        Hashtable hts = new Hashtable();
                        hts.Add("171", "&#8596;");
                        hts.Add("175", "&#8595;");
                        hts.Add("174", "&#8594;");
                        hts.Add("173", "&#8593;");
                        hts.Add("172", "&#8592;");
                        hts.Add("222", "&#8658;");
                        hts.Add("219", "&#8660;");
                        hts.Add("187", "&#8776;");
                        hts.Add("204", "&#8834;");
                        hts.Add("201", "&#8835;");
                        #endregion


                        if (!hts.ContainsValue(e.ClickedItem.Tag))
                        {
                            if (e.ClickedItem.Name.ToUpper() != "TS1TRIPLEBOND" && e.ClickedItem.Name.ToUpper() != "TOOLSTRIPBUTTON61")
                            {
                                string strtext = tb1rtftextbox.Text;
                                int start = tb1rtftextbox.SelectionStart;
                                tb1rtftextbox.SelectionFont = new Font(tb1rtftextbox.Font.Name, tb1rtftextbox.Font.Size);
                                tb1rtftextbox.Select(start, 1);
                                tb1rtftextbox.SelectedText = e.ClickedItem.Text;
                            }

                        }
                        if (e.ClickedItem.Tag.ToString() == "&#8801;")
                        {

                            int start = tb1rtftextbox.SelectionStart;
                            tb1rtftextbox.Select(start, 0);
                            tb1rtftextbox.SelectedRtf = @"{\rtf1\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil\fcharset128 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\cf1\f0\fs17\'81\'df\f1\fs20\cf0\fs17\par}";
                            tb1rtftextbox.SelectionFont = new Font("Symbol", tb1rtftextbox.Font.Size);
                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8596;")
                        {
                            int start = tb1rtftextbox.SelectionStart;
                            tb1rtftextbox.Select(start, 0);
                            tb1rtftextbox.SelectionFont = new Font("Symbol", tb1rtftextbox.Font.Size);
                            tb1rtftextbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8596?\cf0\f1\fs17\par}";
                            tb1rtftextbox.SelectionFont = new Font("Symbol", tb1rtftextbox.Font.Size);

                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8595;")
                        {
                            int start = tb1rtftextbox.SelectionStart;
                            tb1rtftextbox.Select(start, 0);
                            tb1rtftextbox.SelectionFont = new Font("Symbol", tb1rtftextbox.Font.Size);
                            tb1rtftextbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fswiss\fprq2\fcharset0 Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8595?\cf0\f1\fs17\par}";
                            tb1rtftextbox.SelectionFont = new Font("Symbol", tb1rtftextbox.Font.Size);

                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8594;")
                        {
                            int start = tb1rtftextbox.SelectionStart;
                            tb1rtftextbox.Select(start, 0);
                            tb1rtftextbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8594?\cf0\f1\fs17\par}";
                            tb1rtftextbox.SelectionFont = new Font("Symbol", tb1rtftextbox.Font.Size);

                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8593;")
                        {
                            int start = tb1rtftextbox.SelectionStart;
                            tb1rtftextbox.Select(start, 0);
                            tb1rtftextbox.SelectionFont = new Font("Symbol", tb1rtftextbox.Font.Size);
                            tb1rtftextbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8593?\cf0\f1\fs17\par}";
                            tb1rtftextbox.SelectionFont = new Font("Symbol", tb1rtftextbox.Font.Size);

                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8592;")
                        {
                            int start = tb1rtftextbox.SelectionStart;
                            tb1rtftextbox.Select(start, 0);
                            tb1rtftextbox.SelectionFont = new Font("Symbol", tb1rtftextbox.Font.Size);
                            tb1rtftextbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8592?\cf0\f1\fs17\par}";
                            tb1rtftextbox.SelectionFont = new Font("Symbol", tb1rtftextbox.Font.Size);

                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8658;")
                        {
                            int start = tb1rtftextbox.SelectionStart;
                            tb1rtftextbox.Select(start, 0);
                            tb1rtftextbox.SelectionFont = new Font("Symbol", tb1rtftextbox.Font.Size);
                            tb1rtftextbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset2 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\ltrpar\f0\fs22\'de\f1\fs17\par}";
                            tb1rtftextbox.SelectionFont = new Font("Symbol", tb1rtftextbox.Font.Size);

                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8660;")
                        {
                            int start = tb1rtftextbox.SelectionStart;
                            tb1rtftextbox.Select(start, 0);

                            tb1rtftextbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset0 Cambria Math;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8660?\cf0\f1\fs17\par}";
                            tb1rtftextbox.SelectionFont = new Font("Symbol", tb1rtftextbox.Font.Size);

                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8776;")
                        {
                            int start = tb1rtftextbox.SelectionStart;
                            tb1rtftextbox.Select(start, 0);

                            tb1rtftextbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset2 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\ltrpar\sa200\sl276\slmult1\sub\b\f0\fs32\'bb\nosupersub\b0\f1\fs17\par}";
                            tb1rtftextbox.SelectionFont = new Font("Symbol", tb1rtftextbox.Font.Size);

                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8834;")
                        {
                            int start = tb1rtftextbox.SelectionStart;
                            tb1rtftextbox.Select(start, 0);

                            tb1rtftextbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset2 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\ltrpar\sa200\sl276\slmult1\f0\fs22\'cc\f1\fs17\par}";
                            tb1rtftextbox.SelectionFont = new Font("Symbol", tb1rtftextbox.Font.Size);



                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8835;")
                        {
                            int start = tb1rtftextbox.SelectionStart;
                            tb1rtftextbox.Select(start, 0);

                            tb1rtftextbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset2 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\ltrpar\sa200\sl276\slmult1\f0\fs22\'c9\f1\fs17\par}";
                            tb1rtftextbox.SelectionFont = new Font("Symbol", tb1rtftextbox.Font.Size);



                        }

                        else if (e.ClickedItem.Tag.ToString() == "&#957;")
                        {
                            int start = tb1rtftextbox.SelectionStart;
                            tb1rtftextbox.Select(start, 0);

                            tb1rtftextbox.SelectedRtf = @"{\rtf1\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil\fcharset161 Microsoft Sans Serif;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\f0\fs17\'ed\f1\par}";
                            tb1rtftextbox.SelectionFont = new Font("Symbol", tb1rtftextbox.Font.Size);



                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8745;")
                        {
                            int start = tb1rtftextbox.SelectionStart;
                            tb1rtftextbox.Select(start, 0);

                            tb1rtftextbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fswiss\fprq2\fcharset0 Arial;}}{\colortbl ;\red0\green0\blue0;}\uc1\pard\ltrpar\cf1\f0\fs22\u8745?}";
                            tb1rtftextbox.SelectionFont = new Font("Symbol", tb1rtftextbox.Font.Size);



                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8869;")
                        {
                            int start = tb1rtftextbox.SelectionStart;
                            tb1rtftextbox.Select(start, 0);

                            tb1rtftextbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset0 Cambria Math;}}{\colortbl ;\red0\green0\blue0;}\uc1\pard\ltrpar\cf1\f0\fs22\u8869?}";
                            tb1rtftextbox.SelectionFont = new Font("Symbol", tb1rtftextbox.Font.Size);



                        }

                    }
                    else
                    {


                        HtmlRichText.HtmlRichTextBox htrtfbox = GetFocusedControl();

                        if (htrtfbox != null)
                        {


                            Hashtable hts = new Hashtable();
                            hts.Add("171", "&#8596;");
                            hts.Add("175", "&#8595;");
                            hts.Add("174", "&#8594;");
                            hts.Add("173", "&#8593;");
                            hts.Add("172", "&#8592;");
                            hts.Add("222", "&#8658;");
                            hts.Add("219", "&#8660;");
                            hts.Add("187", "&#8776;");
                            hts.Add("204", "&#8834;");
                            hts.Add("201", "&#8835;");
                            //hts.Add("110", "&#957;");

                            if (!hts.ContainsValue(e.ClickedItem.Tag))
                            {
                                if (e.ClickedItem.Name.ToUpper() != "TS1TRIPLEBOND" && e.ClickedItem.Name.ToUpper() != "TOOLSTRIPBUTTON61")
                                {
                                    string strtext = htrtfbox.Text;
                                    int start = htrtfbox.SelectionStart;
                                    htrtfbox.SelectionFont = new Font(htrtfbox.Font.Name, htrtfbox.Font.Size);
                                    htrtfbox.Select(start, 0);
                                    htrtfbox.SelectedText = e.ClickedItem.Text;
                                }

                            }
                            if (e.ClickedItem.Tag.ToString() == "&#8801;")
                            {

                                int start = htrtfbox.SelectionStart;
                                htrtfbox.Select(start, 0);
                                htrtfbox.SelectedRtf = @"{\rtf1\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil\fcharset128 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\cf1\f0\fs17\'81\'df\f1\fs20\cf0\fs17\par}";
                                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                            }
                            else if (e.ClickedItem.Tag.ToString() == "&#8596;")
                            {
                                int start = htrtfbox.SelectionStart;
                                htrtfbox.Select(start, 0);
                                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8596?\cf0\f1\fs17\par}";
                                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);

                            }
                            else if (e.ClickedItem.Tag.ToString() == "&#8595;")
                            {
                                int start = htrtfbox.SelectionStart;
                                htrtfbox.Select(start, 0);
                                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fswiss\fprq2\fcharset0 Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8595?\cf0\f1\fs17\par}";
                                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);

                            }
                            else if (e.ClickedItem.Tag.ToString() == "&#8594;")
                            {
                                int start = htrtfbox.SelectionStart;
                                htrtfbox.Select(start, 0);
                                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8594?\cf0\f1\fs17\par}";
                                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);

                            }
                            else if (e.ClickedItem.Tag.ToString() == "&#8593;")
                            {
                                int start = htrtfbox.SelectionStart;
                                htrtfbox.Select(start, 0);
                                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8593?\cf0\f1\fs17\par}";
                                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);

                            }
                            else if (e.ClickedItem.Tag.ToString() == "&#8592;")
                            {
                                int start = htrtfbox.SelectionStart;
                                htrtfbox.Select(start, 0);
                                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8592?\cf0\f1\fs17\par}";
                                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);

                            }
                            else if (e.ClickedItem.Tag.ToString() == "&#8658;")
                            {
                                int start = htrtfbox.SelectionStart;
                                htrtfbox.Select(start, 0);
                                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset2 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\ltrpar\f0\fs22\'de\f1\fs17\par}";
                                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);

                            }
                            else if (e.ClickedItem.Tag.ToString() == "&#8660;")
                            {
                                int start = htrtfbox.SelectionStart;
                                htrtfbox.Select(start, 0);

                                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset0 Cambria Math;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8660?\cf0\f1\fs17\par}";
                                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);

                            }
                            else if (e.ClickedItem.Tag.ToString() == "&#8776;")
                            {
                                int start = htrtfbox.SelectionStart;
                                htrtfbox.Select(start, 0);

                                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset2 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\ltrpar\sa200\sl276\slmult1\sub\b\f0\fs32\'bb\nosupersub\b0\f1\fs17\par}";
                                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);

                            }
                            else if (e.ClickedItem.Tag.ToString() == "&#8834;")
                            {
                                int start = htrtfbox.SelectionStart;
                                htrtfbox.Select(start, 0);

                                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset2 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\ltrpar\sa200\sl276\slmult1\f0\fs22\'cc\f1\fs17\par}";
                                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);



                            }
                            else if (e.ClickedItem.Tag.ToString() == "&#8835;")
                            {
                                int start = htrtfbox.SelectionStart;
                                htrtfbox.Select(start, 0);

                                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset2 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\ltrpar\sa200\sl276\slmult1\f0\fs22\'c9\f1\fs17\par}";
                                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);



                            }

                            else if (e.ClickedItem.Tag.ToString() == "&#957;")
                            {
                                int start = htrtfbox.SelectionStart;
                                htrtfbox.Select(start, 0);

                                htrtfbox.SelectedRtf = @"{\rtf1\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil\fcharset161 Microsoft Sans Serif;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\f0\fs17\'ed\f1\par}";
                                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);



                            }
                            else if (e.ClickedItem.Tag.ToString() == "&#8745;")
                            {
                                int start = htrtfbox.SelectionStart;
                                htrtfbox.Select(start, 0);

                                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fswiss\fprq2\fcharset0 Arial;}}{\colortbl ;\red0\green0\blue0;}\uc1\pard\ltrpar\cf1\f0\fs22\u8745?}";
                                htrtfbox.SelectionFont = new Font("Arial", htrtfbox.Font.Size);



                            }
                            else if (e.ClickedItem.Tag.ToString() == "&#8869;")
                            {
                                int start = htrtfbox.SelectionStart;
                                htrtfbox.Select(start, 0);

                                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset0 Cambria Math;}}{\colortbl ;\red0\green0\blue0;}\uc1\pard\ltrpar\cf1\f0\fs22\u8869?}";
                                htrtfbox.SelectionFont = new Font("Cambria Math", htrtfbox.Font.Size);

                            }
                            //else if (e.ClickedItem.Tag.ToString() == "&#x03BD;&#x0303;")
                            //{
                            //    int start = htrtfbox.SelectionStart;
                            //    htrtfbox.Select(start, 0);

                            //    htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fscript\fprq2\fcharset161 Comic Sans MS Greek;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue153;}\uc1\pard\ltrpar\cf1\f0\fs18\'ed\f1\u771?}";
                            //    htrtfbox.SelectionFont = new Font("Comic Sans MS Greek", htrtfbox.Font.Size);

                            //}
                            else if (e.ClickedItem.Tag.ToString() == "&#x2245;")
                            {
                                int start = htrtfbox.SelectionStart;
                                htrtfbox.Select(start, 0);

                                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset2 Symbol;}}{\colortbl ;\red0\green0\blue0;}\uc1\pard\ltrpar\cf1\f0\fs22 @}";
                                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);

                            }
                            //else if (e.ClickedItem.Tag.ToString() == "&#xFFFD;")
                            //{
                            //    int start = htrtfbox.SelectionStart;
                            //    htrtfbox.Select(start, 0);

                            //    htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset0 Times New Roman;}}{\colortbl ;\red0\green0\blue0;}\uc1\pard\ltrpar\sa200\sl276\slmult1\cf1\b\f0\fs18\u4093?}";
                            //    htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);

                            //}
                            //else if (e.ClickedItem.Tag.ToString() == "&#x2248;")
                            //{
                            //    int start = htrtfbox.SelectionStart;
                            //    htrtfbox.Select(start, 0);

                            //    htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil\fprq2\fcharset0 OpenSymbol;}}\uc1\pard\ltrpar\b\f0\fs22\u8776?}";
                            //    htrtfbox.SelectionFont = new Font("OpenSymbol", htrtfbox.Font.Size);

                            //}






                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            #endregion


        }

        #endregion

        //private uccasnartool GetUserCOntrolByName(string rownum)
        //{
        //    try
        //    {
        //        //strname = strname.Replace("≡", "");
        //        foreach (Control c in tableLayoutPanel1.Controls)
        //        {
        //            if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
        //            {
        //                uccasnartool uc = (uccasnartool)c;
        //                string strucname = uc.Name;
        //                if (strucname.ToUpper() == strname.ToUpper())
        //                {
        //                    return uc;
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return null;

        //}

        //private uccasnartool_new GetUserCOntrolByName(string strname)
        //{
        //    try
        //    {
        //        //strname = strname.Replace("≡", "");
        //        //foreach (Control c in tableLayoutPanel1.Controls)
        //        //foreach (Control c in pnlUserControl.Controls)
        //        //{
        //        //    if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
        //        //    {
        //        //        uccasnartool_new uc = (uccasnartool_new)c;
        //                string strucname = uccasnartool_new1.Name.Replace("≡", "");
        //                if (strucname.ToUpper() == strname.ToUpper())
        //                {
        //                    return uccasnartool_new1;
        //                }
        //        //    }
        //        //}
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return null;

        //}

        //private Control GetSelectedControl(Control c)
        //{
        //    foreach (Control cc in c.Controls)
        //    {
        //        if (c.Focused)
        //        {
        //            return c;
        //        }
        //    }
        //    return null;
        //}

        //private void tssymbols_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        //{
        //    #region Code

        //    try
        //    {
        //        if (e != null)
        //        {

        //            Hashtable hts = new Hashtable();
        //            hts.Add("171", "&#8596;");
        //            hts.Add("175", "&#8595;");
        //            hts.Add("174", "&#8594;");
        //            hts.Add("173", "&#8593;");
        //            hts.Add("172", "&#8592;");
        //            hts.Add("222", "&#8658;");
        //            hts.Add("219", "&#8660;");
        //            hts.Add("187", "&#8776;");
        //            hts.Add("204", "&#8834;");
        //            hts.Add("201", "&#8835;");
        //            hts.Add("110", "&#957;");
        //            HtmlRichText.HtmlRichTextBox htrtfbox = GetFocusedControl();
        //            if (htrtfbox == null)
        //            {
        //                return;
        //            }

        //            if (!hts.ContainsValue(e.ClickedItem.Tag))
        //            {
        //                if (e.ClickedItem.Name.ToUpper() != "TS1TRIPLEBOND")
        //                {
        //                    string strtext = htrtfbox.Text;
        //                    int start = htrtfbox.SelectionStart;
        //                    htrtfbox.SelectionFont = new Font(tb1rtftextbox.Font.Name, htrtfbox.Font.Size);
        //                    htrtfbox.Select(start, 0);


        //                    htrtfbox.SelectedText = e.ClickedItem.Text;
        //                    htrtfbox.Refresh();
        //                }
        //            }
        //            if (e.ClickedItem.Tag.ToString() == "&#8801;")
        //            {

        //                int start = htrtfbox.SelectionStart;
        //                htrtfbox.Select(start, 0);
        //                htrtfbox.SelectedRtf = @"{\rtf1\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil\fcharset128 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\cf1\f0\fs17\'81\'df\f1\fs20\cf0\fs17\par}";
        //                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
        //            }
        //            else if (e.ClickedItem.Tag.ToString() == "&#8596;")
        //            {
        //                int start = htrtfbox.SelectionStart;
        //                htrtfbox.Select(start, 0);
        //                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
        //                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8596?\cf0\f1\fs17\par}";
        //                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);

        //            }
        //            else if (e.ClickedItem.Tag.ToString() == "&#8595;")
        //            {
        //                int start = htrtfbox.SelectionStart;
        //                htrtfbox.Select(start, 0);
        //                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
        //                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fswiss\fprq2\fcharset0 Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8595?\cf0\f1\fs17\par}";
        //                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);

        //            }
        //            else if (e.ClickedItem.Tag.ToString() == "&#8594;")
        //            {
        //                int start = htrtfbox.SelectionStart;
        //                htrtfbox.Select(start, 0);
        //                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8594?\cf0\f1\fs17\par}";
        //                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);

        //            }
        //            else if (e.ClickedItem.Tag.ToString() == "&#8593;")
        //            {
        //                int start = htrtfbox.SelectionStart;
        //                htrtfbox.Select(start, 0);
        //                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
        //                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8593?\cf0\f1\fs17\par}";
        //                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);

        //            }
        //            else if (e.ClickedItem.Tag.ToString() == "&#8592;")
        //            {
        //                int start = htrtfbox.SelectionStart;
        //                htrtfbox.Select(start, 0);
        //                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
        //                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8592?\cf0\f1\fs17\par}";
        //                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);

        //            }
        //            else if (e.ClickedItem.Tag.ToString() == "&#8658;")
        //            {
        //                int start = htrtfbox.SelectionStart;
        //                htrtfbox.Select(start, 0);
        //                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
        //                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset2 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\ltrpar\f0\fs22\'de\f1\fs17\par}";
        //                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);

        //            }
        //            else if (e.ClickedItem.Tag.ToString() == "&#8660;")
        //            {
        //                int start = htrtfbox.SelectionStart;
        //                htrtfbox.Select(start, 0);

        //                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset0 Cambria Math;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8660?\cf0\f1\fs17\par}";
        //                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);

        //            }
        //            else if (e.ClickedItem.Tag.ToString() == "&#8776;")
        //            {
        //                int start = htrtfbox.SelectionStart;
        //                htrtfbox.Select(start, 0);

        //                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset2 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\ltrpar\sa200\sl276\slmult1\sub\b\f0\fs32\'bb\nosupersub\b0\f1\fs17\par}";
        //                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);

        //            }
        //            else if (e.ClickedItem.Tag.ToString() == "&#8834;")
        //            {
        //                int start = htrtfbox.SelectionStart;
        //                htrtfbox.Select(start, 0);

        //                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset2 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\ltrpar\sa200\sl276\slmult1\f0\fs22\'cc\f1\fs17\par}";
        //                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);



        //            }
        //            else if (e.ClickedItem.Tag.ToString() == "&#8835;")
        //            {
        //                int start = htrtfbox.SelectionStart;
        //                htrtfbox.Select(start, 0);

        //                htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset2 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\ltrpar\sa200\sl276\slmult1\f0\fs22\'c9\f1\fs17\par}";
        //                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);



        //            }
        //            else if (e.ClickedItem.Tag.ToString() == "&#957;")
        //            {
        //                int start = htrtfbox.SelectionStart;
        //                htrtfbox.Select(start, 0);

        //                htrtfbox.SelectedRtf = @"{\rtf1\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil\fcharset161 Microsoft Sans Serif;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\f0\fs17\'ed\f1\par}";
        //                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);



        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    #endregion
        //}

        //page size

        #region Load rxnnum and Seq to GlobalVariables

        DataSet dsTanDetails = new DataSet();
        DataSet dsTabNumandSeq = new DataSet();
        bool istandone = false;
        private void txttan_Leave(object sender, EventArgs e)
        {
            try
            {
                if (istandone)
                {
                    txtsupplid.Focus();
                    return;
                }

                if (ISEditMode == false)
                {
                    if (dsTanDetails != null)
                    {

                        if (dsTanDetails.Tables.Count > 0)
                        {
                            if (txtTAN.Text != null && txtTAN.Text != "")
                            {

                                try
                                {
                                    List<Generic.TanNumAndSeq> lstTANNumAndSeq = new List<IndxReactNarr.Generic.TanNumAndSeq>();
                                    int ship_id = Generic.globalVariables.Shipment_ID;
                                    dsTabNumandSeq = IndxReactNarrDAL.CASNarrativeDataAccess.GetTANNumandsequece(txtTAN.Text, ship_id);
                                    if (dsTabNumandSeq != null)
                                    {
                                        if (dsTabNumandSeq.Tables.Count > 0)
                                        {
                                            for (int i = 0; i < dsTabNumandSeq.Tables[0].Rows.Count; i++)
                                            {
                                                if (dsTabNumandSeq.Tables[0].Rows[i]["num_seq"] != null)
                                                {
                                                    string strnumandseq = dsTabNumandSeq.Tables[0].Rows[i]["num_seq"].ToString();
                                                    char[] c = new char[1] { ';' };
                                                    char[] s = new char[1] { ' ' };
                                                    string[] strvalues = strnumandseq.Split(c, StringSplitOptions.None);
                                                    if (strvalues != null)
                                                    {
                                                        if (strvalues.Length > 0)
                                                        {
                                                            for (int j = 0; j < strvalues.Length; j++)
                                                            {
                                                                Generic.TanNumAndSeq tns = new IndxReactNarr.Generic.TanNumAndSeq();
                                                                tns.TAN = txtTAN.Text;
                                                                string[] strnumsandseqs = strvalues[j].Split(s);
                                                                if (strnumsandseqs != null)
                                                                {
                                                                    if (strnumsandseqs.Length == 4)
                                                                    {
                                                                        tns.NUM = Convert.ToInt32(strnumsandseqs[1]);
                                                                        tns.SEQ = Convert.ToInt32(strnumsandseqs[3]);
                                                                    }
                                                                }
                                                                lstTANNumAndSeq.Add(tns);
                                                            }
                                                        }
                                                    }


                                                }
                                            }
                                            Generic.globalVariables.HtNumAndSeq = lstTANNumAndSeq;

                                        }

                                    }
                                }
                                catch (Exception ex)
                                {
                                    ErrorHandling.WriteErrorLog(ex.ToString());
                                }

                                dsTanFileNames = IndxReactNarr.DAL.CASNarrativeDataAccess.GetTANFilenames(txtTAN.Text);

                                Generic.globalVariables.DsTanFilenames = dsTanFileNames;

                                if (validations.Validatations.ValidateTANFormat(txtTAN.Text))
                                {
                                    int _documentid = 0;
                                    DataRow[] dr = dsTanDetails.Tables[0].Select("tan= '" + txtTAN.Text + "'");
                                    if (dr != null)
                                    {
                                        if (dr.Length > 0)
                                        {
                                            txtCAN.Text = dr[0]["can"].ToString();
                                            txtDOI.Text = dr[0]["doi"].ToString();
                                            txtsupplid.Text = dr[0]["supplementid"].ToString();
                                            documentid = Convert.ToInt32(dr[0]["id"]);
                                        }
                                    }

                                    try
                                    {



                                        dsreportview = IndxReactNarr.DAL.CASNarrativeDataAccess.GetTANReportView(txtTAN.Text, "TAN");
                                        if (dsreportview != null)
                                        {
                                            if (dsreportview.Tables.Count > 0)
                                            {
                                                if (dsreportview.Tables[0].Rows.Count > 0)
                                                {
                                                    ISEditMode = true;
                                                    TAN = txtTAN.Text;
                                                    istandone = true;
                                                    _lsttanchild = new List<IndxReactNarrBll.clsCASChild>();
                                                    IndxReactNarrBll.clsMaster _tanmaster = new IndxReactNarrBll.clsMaster();


                                                    IndxReactNarrDAL.CASNarrativeDataAccess.GetDocumentDetailsDataSet(dsreportview, out  _lsttanchild, out _tanmaster);



                                                    if (Generic.globalVariables.HtNumAndSeq != null)
                                                        lblreccountvalue.Text = _lsttanchild.Count.ToString() + "/" + Generic.globalVariables.HtNumAndSeq.Count.ToString();

                                                    txtCAN.Text = _tanmaster.CAN;
                                                    txtDOI.Text = _tanmaster.DOI;
                                                    txtjournalid.Text = _tanmaster.JournalArticalID;
                                                    txtsupplid.Text = _tanmaster.SupplementID;
                                                    txtTAN.Text = _tanmaster.TAN;
                                                    Hashtable _htsymboles = FillSymbolsfromControls();


                                                    //new code
                                                    if (_lsttanchild != null)
                                                    {
                                                        //_maxRec = _lsttanchild.Count;
                                                        //_PageCount = _maxRec / _pageSize;

                                                        ////Adjust the page number if the last page contains a partial page.
                                                        //if ((_maxRec % _pageSize) > 0)
                                                        //{
                                                        //    _PageCount += 1;
                                                        //}
                                                        //_currentPage = 1;
                                                        //_recNo = 0;

                                                        //if (ISEditMode)
                                                        //   AddrecordstoTable();




                                                        //tableLayoutPanel1.ControlAdded -= new ControlEventHandler(tableLayoutPanel1_ControlAdded);
                                                        // LoadPage();
                                                        // tableLayoutPanel1.ControlAdded += new ControlEventHandler(tableLayoutPanel1_ControlAdded);
                                                    }


                                                    //  tableLayoutPanel1.AutoSize = true;
                                                    btnExportToExcel.Visible = true;
                                                    btnUpdate.Text = "Update";

                                                }
                                                else
                                                {
                                                    //_PageCount = 1;
                                                    //_currentPage = 1;
                                                    //_recNo = _pageSize * (_currentPage - 1);
                                                    //DisplayPageInfo();
                                                }
                                            }
                                            else
                                            {
                                                documentid = IndxReactNarrDAL.CASNarrativeDataAccess.GetDocumentID(txtTAN.Text);
                                            }
                                        }



                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorHandling.WriteErrorLog(ex.ToString());
                                    }

                                }
                                else
                                {
                                    MessageBox.Show("Given TAN Format is not correct", "CAS-Narrative-Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    return;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());

            }
            finally
            {
                txtsupplid.Focus();
                FillFilename(txtTAN.Text);
            }
        }
        #endregion

        private void splitContainer1_SplitterMoved(object sender, SplitterEventArgs e)
        {
            try
            {
                foreach (TabPage tp in tbCoOrdTextEditor.TabPages)
                {
                    tp.Refresh();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }

        }

        //private void tableLayoutPanel1_Layout(object sender, LayoutEventArgs e)
        //{
        //    if (sender == typeof(TableLayoutPanel))
        //    {
        //        try
        //        {
        //            tableLayoutPanel1.Controls[0].Dock = DockStyle.Fill;
        //        }
        //        catch (Exception ex)
        //        {
        //            ErrorHandling.WriteErrorLog(ex.ToString());
        //        }
        //    }


        //}

        #region Code COmemnted here
        //private void timer1_Tick(object sender, EventArgs e)
        //{


        //    string strfile = AppDomain.CurrentDomain.BaseDirectory + "ToolBackup.txt";

        //    try
        //    {
        //        if (File.Exists(strfile))
        //        {
        //            Hashtable htbackup = new Hashtable();
        //            Hashtable httandetails = new Hashtable();
        //            Hashtable htusercontrols = new Hashtable();
        //            foreach (Control c in tableLayoutPanel1.Controls)
        //            {
        //                if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
        //                {
        //                    uccasnartool uc = (uccasnartool)c;
        //                    htusercontrols.Add(uc.Name, uc.Name);
        //                }

        //            }


        //            //htbackup.Add("txtusername", txtusername.Text);
        //            httandetails.Add("txtjournalid", txtjournalid.Text);
        //            httandetails.Add("txttan", txttan.Text);
        //            httandetails.Add("txtcan", txtcan.Text);
        //            httandetails.Add("txtdoi", txtdoi.Text);
        //            httandetails.Add("txtsupplid", txtsupplid.Text);

        //            foreach (Control c in tableLayoutPanel1.Controls)
        //            {
        //                if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
        //                {
        //                    uccasnartool uc = (uccasnartool)c;


        //                    htbackup.Add(uc.Name + "¬" + "txtCASReactnumber", uc.txtCASReactnumber.Text);
        //                    htbackup.Add(uc.Name + "¬" + "txtrxnseq", uc.txtrxnseq.Text);
        //                    htbackup.Add(uc.Name + "¬" + "txtdocref", uc.txtdocref.Text);
        //                    htbackup.Add(uc.Name + "¬" + "txtfilename", uc.txtfilename.Text);
        //                    htbackup.Add(uc.Name + "¬" + "txtpagenumber", uc.txtpagenumber.Text);
        //                    htbackup.Add(uc.Name + "¬" + "txtxpagesize", uc.txtxpagesize.Text);
        //                    htbackup.Add(uc.Name + "¬" + "txtxoffset", uc.txtxoffset.Text);
        //                    htbackup.Add(uc.Name + "¬" + "txtpagelabel", uc.txtpagelabel.Text);
        //                    htbackup.Add(uc.Name + "¬" + "txtypagesize", uc.txtypagesize.Text);
        //                    htbackup.Add(uc.Name + "¬" + "txtyoffset", uc.txtyoffset.Text);
        //                    htbackup.Add(uc.Name + "¬" + "rtxttextlinepreview", uc.rtxttextlinepreview.Rtf);
        //                    htbackup.Add(uc.Name + "¬" + "txtnarrativeid", uc.txtnarrativeid.Text);
        //                    htbackup.Add(uc.Name + "¬" + "rtxtparapreview", uc.rtxtparapreview.Rtf);
        //                    htbackup.Add(uc.Name + "¬" + "txtpara1", uc.txtpara1.Rtf);
        //                    htbackup.Add(uc.Name + "¬" + "rtxtdatapreview", uc.rtxtdatapreview.Rtf);

        //                }
        //            }

        //            if (htbackup.Count > 0)
        //            {
        //                using (StreamWriter sw = new StreamWriter(strfile))
        //                {
        //                    sw.Write("");


        //                    foreach (string strkey in htusercontrols.Keys)
        //                    {
        //                        if (htusercontrols[strkey] != null)
        //                        {
        //                            sw.WriteLine(htusercontrols[strkey].ToString() + "≡");
        //                        }
        //                    }




        //                    foreach (string strkey in httandetails.Keys)
        //                    {
        //                        if (httandetails[strkey] != null)
        //                        {
        //                            sw.WriteLine(strkey + "≈" + httandetails[strkey].ToString());
        //                        }
        //                    }


        //                    foreach (string strkey in htbackup.Keys)
        //                    {
        //                        if (htbackup[strkey] != null)
        //                        {
        //                            sw.WriteLine(strkey + "¬" + htbackup[strkey].ToString());
        //                        }
        //                    }
        //                    sw.Flush();
        //                    sw.Close();
        //                }

        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }

        //} 
        #endregion

        private void cmb1scrollbars_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (cmb1scrollbars.SelectedItem.ToString() == RichTextBoxScrollBars.Both.ToString())
            {
                tb1rtftextbox.ScrollBars = RichTextBoxScrollBars.Both;
            }
            else if (cmb1scrollbars.SelectedItem.ToString() == RichTextBoxScrollBars.ForcedBoth.ToString())
            {
                tb1rtftextbox.ScrollBars = RichTextBoxScrollBars.ForcedBoth;
            }
            else if (cmb1scrollbars.SelectedItem.ToString() == RichTextBoxScrollBars.ForcedHorizontal.ToString())
            {
                tb1rtftextbox.ScrollBars = RichTextBoxScrollBars.ForcedHorizontal;
            }
            else if (cmb1scrollbars.SelectedItem.ToString() == RichTextBoxScrollBars.ForcedVertical.ToString())
            {
                tb1rtftextbox.ScrollBars = RichTextBoxScrollBars.ForcedVertical;
            }
            else if (cmb1scrollbars.SelectedItem.ToString() == RichTextBoxScrollBars.Horizontal.ToString())
            {
                tb1rtftextbox.ScrollBars = RichTextBoxScrollBars.Horizontal;
            }
            else if (cmb1scrollbars.SelectedItem.ToString() == RichTextBoxScrollBars.None.ToString())
            {
                tb1rtftextbox.ScrollBars = RichTextBoxScrollBars.None;
            }
            else if (cmb1scrollbars.SelectedItem.ToString() == RichTextBoxScrollBars.Vertical.ToString())
            {
                tb1rtftextbox.ScrollBars = RichTextBoxScrollBars.Vertical;
            }

        }

        //  public string _htmlstring = "";
        //IHTMLTxtRange _objrange;

        #region Pdf Tabs Close commented

        //private void btndoc1close_Click(object sender, EventArgs e)
        //{
        //    if (txttb1filepathdoc1.Text != "")
        //    {
        //        txttb1filepathdoc1.Text = "";
        //        pdfdoc1.LoadFile("");
        //        pdfdoc1.Controls.Clear();

        //    }
        //}

        //private void button1_Click_1(object sender, EventArgs e)
        //{

        //    if (txttb1filepathdoc2.Text != "")
        //    {
        //        txttb1filepathdoc2.Text = "";
        //        pdfdoc2.LoadFile("");
        //    }
        //}

        //private void btndoc3close_Click(object sender, EventArgs e)
        //{
        //    if (txttb1filepathdoc3.Text != "")
        //    {
        //        txttb1filepathdoc3.Text = "";
        //        pdfdoc3.LoadFile("");
        //    }

        //}

        //private void btnpdfdoc4close_Click(object sender, EventArgs e)
        //{

        //    if (txttb1filepathdoc4.Text != "")
        //    {
        //        txttb1filepathdoc4.Text = "";
        //        pdfdoc4.LoadFile("");
        //    }
        //}

        //private void button2_Click_1(object sender, EventArgs e)
        //{

        //    if (txttb1filepathrxnfile.Text != "")
        //    {
        //        txttb1filepathrxnfile.Text = "";
        //        pdfrxnfile.LoadFile("");
        //    }
        //}

        #endregion

        #region Tab selected

        private void tb1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (tbCoOrdTextEditor.SelectedTab == tpCoOrdinateCapture)
                {
                    dgviewer.MouseMode = GdViewerPro4.ViewerMouseMode.MouseModeAreaSelection;
                    if (!string.IsNullOrEmpty(txttb1filepathdoc1.Text))
                    {
                        // rddoc1.Checked = true;
                        dgviewer.DisplayFromPdfFile(txttb1filepathdoc1.Text);
                    }

                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        #region Pdf Open Tabs commentd

        //private void btntb2doc1_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        ofd.Reset();
        //        ofd.Filter = "pdf files (*.pdf)|*.pdf|All files (*.*)|*.*";
        //        if (ofd.ShowDialog() != DialogResult.Cancel)
        //        {
        //            string strfileextension = "";
        //            strfileextension = Path.GetExtension(ofd.FileName);
        //            if (strfileextension.ToUpper() == ".PDF")
        //            {
        //                try
        //                {
        //                    this.WindowState = FormWindowState.Normal;
        //                    txttb2doc1path.Text = ofd.FileName;

        //                    tb2pdfdoc1.Refresh();
        //                    tb2pdfdoc1.LoadFile(ofd.FileName);
        //                    tb2pdfdoc1.Visible = true;
        //                    tb2pdfdoc1.Refresh();
        //                    this.WindowState = FormWindowState.Maximized;

        //                }
        //                catch (Exception ex)
        //                {
        //                    MessageBox.Show("Unable to open file", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //                    ErrorHandling.WriteErrorLog(ex.ToString());
        //                    txttb2doc1path.Text = "";
        //                    return;

        //                }
        //            }




        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}

        //private void btntb2doc2_Click(object sender, EventArgs e)
        //{


        //    try
        //    {
        //        ofd.Reset();
        //        ofd.Filter = "pdf files (*.pdf)|*.pdf|All files (*.*)|*.*";
        //        if (ofd.ShowDialog() != DialogResult.Cancel)
        //        {
        //            string strfileextension = "";
        //            strfileextension = Path.GetExtension(ofd.FileName);
        //            if (strfileextension.ToUpper() == ".PDF")
        //            {
        //                try
        //                {
        //                    this.WindowState = FormWindowState.Normal;
        //                    txttb2doc2path.Text = ofd.FileName;

        //                    tb2pdfdoc2.Refresh();

        //                    tb2pdfdoc2.LoadFile(ofd.FileName);
        //                    tb2pdfdoc2.Visible = true;
        //                    tb2pdfdoc2.Refresh();
        //                    this.WindowState = FormWindowState.Maximized;

        //                }
        //                catch (Exception ex)
        //                {
        //                    MessageBox.Show("Unable to open file", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //                    ErrorHandling.WriteErrorLog(ex.ToString());
        //                    txttb2doc2path.Text = "";
        //                    return;

        //                }
        //            }




        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}


        #endregion

        //private void btnnext_Click(object sender, EventArgs e)
        //{


        //    //new code

        //    try
        //    {

        //        //Check if the user clicks the "Fill Grid" button.
        //        if (_pageSize == 0)
        //        {
        //            MessageBox.Show("Set the Page Size, and then click the Fill Grid button!");
        //            return;
        //        }


        //        _currentPage += 1;
        //        if (_currentPage > _PageCount)
        //        {
        //            _currentPage = _PageCount;
        //            //Check if you are already at the last page.
        //            if (_recNo == _maxRec)
        //            {
        //                MessageBox.Show("You are at the Last Page!");
        //                return;
        //            }
        //        }
        //        CheckTableRowCount();
        //        UpdateControlNamesInTable();
        //        LoadPage();


        //        #region MyRegion
        //        // this.Cursor = Cursors.WaitCursor;
        //        //if (_lsttanchild != null)
        //        //{
        //        //    if (_lsttanchild.Count > pagecount)
        //        //    {

        //        //            int rowcount = 0;
        //        //            int nextcount = count + pagecount;
        //        //            if (_lsttanchild.Count > nextcount)
        //        //            {
        //        //                rowcount = nextcount;
        //        //            }
        //        //            else
        //        //            {
        //        //                rowcount = _lsttanchild.Count;
        //        //                btnnext.Enabled = false;
        //        //            }
        //        //            int irow = 0;
        //        //            if (rowcount > _lsttanchild.Count)
        //        //            {
        //        //                return;
        //        //            }

        //        //            Hashtable _htusercontrolsymbols = FillSymbolsfromControls();
        //        //            tableLayoutPanel1.RowStyles.Clear();
        //        //            tableLayoutPanel1.RowCount = 2;
        //        //            tableLayoutPanel1.Controls.Clear();

        //        //            txtpagenumber.Text = count.ToString() + " of " + rowcount.ToString();
        //        //            for (int i = count; i < rowcount; i++)
        //        //            {

        //        //                try
        //        //                {

        //        //                    uccasnartool_new uc = new uccasnartool_new();
        //        //                    uc.Name = _lsttanchild[i].NarrativeID.ToString();
        //        //                    uc.Rxn_ID = Convert.ToInt32(_lsttanchild[i].ReactionID.ToString());
        //        //                    uc.TanDetails = (CAS_Nar_Bll.clsCASChild)_lsttanchild[i];
        //        //                    uc.HtSymbols = _htusercontrolsymbols;
        //        //                    uc.loadFields();
        //        //                    uc.Anchor = ((System.Windows.Forms.AnchorStyles)(((AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.None))));
        //        //                    uc.reactionID = Convert.ToInt32(_lsttanchild[i].ReactionID);
        //        //                    uc.documentid = Convert.ToInt32(_lsttanchild[i].DocumentID);

        //        //                    uc.Dock = DockStyle.Fill;
        //        //                    uc.transferToTextEditorToolStripMenuItem.Click += new EventHandler(transferToTextEditorToolStripMenuItem_Click);
        //        //                    uc.txtnarrativeid.Leave += new EventHandler(txtnarrativeid_Leave);
        //        //                    uc.txtrxnseq.Leave += new EventHandler(txtrxnseq_Leave);
        //        //                    uc.TAN = txttan.Text;

        //        //                    uc.rtxtparapreview.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
        //        //                    uc.rtxttextlinepreview.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
        //        //                    uc.txtpara1.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);
        //        //                    uc.rtxtdatapreview.KeyDown += new KeyEventHandler(rtxtparapreview_KeyDown);

        //        //                    uc.txtdocref.Leave += new EventHandler(txtdocref_Leave);
        //        //                    //uc.DsTanFilenames = dsTanFileNames;
        //        //                    //uc.DsFindAndReplace = dsFandR;
        //        //                    uc.btnDelete.Click += new EventHandler(btnDelete_Click);

        //        //                    irow = AddTableRow();
        //        //                    uc.rowindex = irow;
        //        //                    tableLayoutPanel1.Controls.Add(uc, 0, irow);

        //        //                }
        //        //                catch (Exception ex)
        //        //                {
        //        //                    ErrorHandling.WriteErrorLog(ex.ToString());

        //        //                }


        //        //            }
        //        //            tableLayoutPanel1.Refresh();
        //        //            count = rowcount;

        //        //        }

        //        //    }
        //        //} 
        //        #endregion
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    finally
        //    {
        //        this.Cursor = Cursors.Default;
        //    }

        //}

        //private void SavePage()
        //{

        //    try
        //    {
        //        bool isvalidated = false;
        //        //new code
        //        clsMaster _objmater = new clsMaster();
        //        if (validateMasterDetails(out _objmater))
        //        {
        //            documentid = CASNarrativeDataAccess.PopulateDocumentData_new(_objmater, Generic.globalVariables.UserName);
        //        }
        //        //upto here

        //        //for (int i = 0; i < pnlUserControl.Controls.Count; i++)
        //        //{
        //        //    Control c = pnlUserControl.Controls[i];
        //        //    if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
        //        //    {
        //        //        uccasnartool_new uc = (uccasnartool_new)c;

        //        string stranalog = uccasnartool_new1.rtxtparapreview.Text.ToLower();


        //        // if (ValidateNarrativeID(uc.txtnarrativeid, uc.Name, uc.reactionID))
        //        {
        //            //  if (uc.txtnarrativeid.Text.Contains("analogousTo="))
        //            if (uccasnartool_new1.chkIsAnalogous.Checked)
        //            {
        //                if (CheckNarIDAnalogoustoNarIDparaFieldEmptry(uccasnartool_new1.Name))
        //                {
        //                    isvalidated = true;
        //                    //new code
        //                    //Control c = tableLayoutPanel1.Controls[i];
        //                    // if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
        //                    {
        //                        //uccasnartool uc = (uccasnartool)c;
        //                        clsMaster objdocument = new clsMaster();
        //                        clsCASChild objdocreactions = new clsCASChild();
        //                        if (!ValidateUserControls(uccasnartool_new1, out objdocument, out objdocreactions))
        //                        {
        //                            // tableLayoutPanel1.ScrollControlIntoView(c);
        //                            this.Cursor = Cursors.Default;
        //                            return;
        //                        }
        //                        else
        //                        {
        //                            //objdocument.ID = documentid;
        //                            if (CASNarrativeDataAccess.PopulateDocumentDetailsDataid_Patent(objdocreactions, documentid, ""))
        //                            {
        //                                objdocreactions.DocumentID = documentid;
        //                            }
        //                        }
        //                    }
        //                    //upto here
        //                }
        //                else
        //                {
        //                    MessageBox.Show("Nar ID is mapped for this reaction, Para field should be empty", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //                    uccasnartool_new1.rtxtparapreview.Focus();
        //                    return;
        //                }
        //            }
        //            else
        //            {
        //                isvalidated = true;
        //                //new code

        //                //     if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
        //                {

        //                    clsMaster objdocument = new clsMaster();
        //                    clsCASChild objdocreactions = new clsCASChild();
        //                    if (!ValidateUserControls(uccasnartool_new1, out objdocument, out objdocreactions))
        //                    {
        //                        // tableLayoutPanel1.ScrollControlIntoView(c);
        //                        this.Cursor = Cursors.Default;
        //                        return;
        //                    }
        //                    else
        //                    {
        //                        if (CASNarrativeDataAccess.PopulateDocumentDetailsDataid_Patent(objdocreactions, documentid, ""))
        //                        {
        //                            objdocreactions.DocumentID = documentid;
        //                        }
        //                    }
        //                }
        //                //upto here
        //            }
        //        }
        //        //else
        //        //    return;
        //        //    }


        //        //}
        //        if (ISEditMode)
        //        {

        //            dsreportview = CAS_Narrative.DAL.CASNarrativeDataAccess.GetTANReportView(TAN, "TAN");

        //            if (dsreportview != null)
        //            {
        //                if (dsreportview.Tables.Count > 0)
        //                {

        //                    _lsttanchild = new List<CAS_Nar_Bll.clsCASChild>();
        //                    CAS_Nar_Bll.clsMaster _tanmaster = new CAS_Nar_Bll.clsMaster();
        //                    DAL.CASNarrativeDataAccess.GetDocumentDetailsDataSet(dsreportview, out  _lsttanchild, out _tanmaster);
        //                }
        //            }

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }



        //}

        //private void btnprevious_Click(object sender, EventArgs e)
        //{


        //    //New Code

        //    try
        //    {

        //        if (_currentPage == _PageCount)
        //        {
        //            _recNo = _pageSize * (_currentPage - 2);
        //        }

        //        _currentPage -= 1;
        //        //Check if you are already at the first page.
        //        if (_currentPage < 1)
        //        {
        //            MessageBox.Show("You are at the First Page!");
        //            _currentPage = 1;
        //            return;
        //        }
        //        else
        //        {
        //            _recNo = _pageSize * (_currentPage - 1);
        //        }
        //        CheckTableRowCount();
        //        UpdateControlNamesInTable();
        //        LoadPage();




        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    finally
        //    {
        //        this.Cursor = Cursors.Default;
        //    }



        //}

        //private void btnfirst_Click(object sender, EventArgs e)
        //{
        //    //if (ISEditMode)
        //    //{
        //    //    SavePage();
        //    //}
        //    //Check if you are already at the first page.
        //    if (_currentPage == 1)
        //    {
        //        MessageBox.Show("You are at the First Page!");
        //        return;
        //    }

        //    _currentPage = 1;
        //    _recNo = 0;


        //    CheckTableRowCount();
        //    UpdateControlNamesInTable();
        //    LoadPage();


        //}

        //private void CheckTableRowCount()
        //{
        //    try
        //    {
        //        if (tableLayoutPanel1.RowStyles.Count < pagecount)
        //        {
        //            int count = tableLayoutPanel1.RowStyles.Count;
        //            int irows = 0;
        //            for (int i = count; i < pagecount; i++)
        //            {
        //                uccasnartool_new uc = new uccasnartool_new();
        //                uc.Anchor = ((System.Windows.Forms.AnchorStyles)(((AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Right))));
        //                uc.Name = i.ToString();
        //                irows = AddTableRow();
        //                uc.rowindex = irows;
        //                try
        //                {
        //                    tableLayoutPanel1.Controls.Add(uc, 0, irows);
        //                }
        //                catch (Exception ex)
        //                {
        //                    MessageBox.Show(ex.ToString());
        //                }
        //            }
        //        }
        //        else if (tableLayoutPanel1.RowStyles.Count > pagecount)
        //        {

        //            int tbrcount = tableLayoutPanel1.RowStyles.Count;
        //            int c = tbrcount;
        //            do
        //            {

        //                tableLayoutPanel1.Controls.RemoveAt(c - 1);
        //                tableLayoutPanel1.RowStyles.RemoveAt(c - 1);
        //                c--;

        //            }
        //            while (c > pagecount);


        //            tableLayoutPanel1.AutoScroll = false;
        //            tableLayoutPanel1.AutoScroll = true;



        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}

        //private void btnlast_Click(object sender, EventArgs e)
        //{
        //    //if (ISEditMode)
        //    //{
        //    //    SavePage();
        //    //}
        //    //Check if you are already at the last page.
        //    if (_recNo == _maxRec)
        //    {
        //        MessageBox.Show("You are at the Last Page!");
        //        return;
        //    }

        //    _currentPage = _PageCount;
        //    _recNo = _pageSize * (_currentPage - 1);
        //    CheckTableRowCount();
        //    UpdateControlNamesInTable();
        //    LoadPage();

        //}

        #region offsets capture pdf tab

        private void btnbrowsecood_Click(object sender, EventArgs e)
        {
            try
            {
                ofd.Reset();
                ofd.Filter = "pdf files (*.pdf)|*.pdf|All files (*.*)|*.*";
                if (ofd.ShowDialog() != DialogResult.Cancel)
                {
                    string strfileextension = "";
                    strfileextension = Path.GetExtension(ofd.FileName);
                    if (strfileextension.ToUpper() == ".PDF")
                    {
                        try
                        {


                            txtbrowsecoordinates.Text = ofd.FileName;

                            dgviewer.DisplayFromFile(ofd.FileName);
                            dgviewer.SetZoomWidthControl();
                            //txttb1filepathdoc1.Text = ofd.FileName;

                            //pdfdoc1.Refresh();

                            //pdfdoc1.LoadFile(ofd.FileName);
                            //pdfdoc1.Visible = true;
                            //pdfdoc1.Refresh();


                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Unable to open file", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            ErrorHandling.WriteErrorLog(ex.ToString());
                            //txttb1filepathpdf1.Text = "";
                            return;

                        }
                    }




                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtcpage_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txtcpage.Text != null && txtcpage.Text != "")
                {
                    if (Convert.ToInt32(txtcpage.Text) > 0)
                    {
                        if (Convert.ToInt32(txtcpage.Text) <= dgviewer.PageCount)
                        {

                            dgviewer.DisplayFrame(Convert.ToInt32(txtcpage.Text));

                        }
                        else
                        {
                            MessageBox.Show("Given page number not found");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Given page number not found");
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        //#region Selected User control

        ////uccasnartool_new _uclseelctedcontrol = null;
        ////private void toolStripButton13_Click(object sender, EventArgs e)
        ////{
        ////    uccasnartool_new uc = GetSelectedUserControl();
        ////    _uclseelctedcontrol = uc;
        ////}

        ////private void label19_Click(object sender, EventArgs e)
        ////{
        ////    uccasnartool_new uc = GetSelectedUserControl();
        ////    _uclseelctedcontrol = uc;
        ////}

        ////private uccasnartool_new GetSelectedUserControl()
        ////{
        ////    try
        ////    {


        ////        //  foreach (Control c in tableLayoutPanel1.Controls)
        ////        foreach (Control c in pnlUserControl.Controls)
        ////        {


        ////            if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
        ////            {
        ////                uccasnartool_new uc = (uccasnartool_new)c;

        ////                foreach (Control ctextbox in uc.pnlMain.Controls)
        ////                {
        ////                    if (ctextbox.GetType().BaseType.Name.ToUpper() == "TEXTBOXBASE")
        ////                    {
        ////                        if (c.Focused)
        ////                        {

        ////                            return uc;
        ////                        }
        ////                    }
        ////                }


        ////                Control[] ct = uc.pnlMain.Controls.Find("rtxttextlinepreview", false);
        ////                if (ct != null)
        ////                {
        ////                    HtmlRichText.HtmlRichTextBox tr = (HtmlRichText.HtmlRichTextBox)ct[0];
        ////                    if (tr.Focused)
        ////                    {
        ////                        return uc;
        ////                    }
        ////                }

        ////                Control[] c2 = uc.splitContainer2.Panel1.Controls.Find("rtxtparapreview", false);
        ////                if (c2 != null)
        ////                {
        ////                    HtmlRichText.HtmlRichTextBox tr = (HtmlRichText.HtmlRichTextBox)c2[0];
        ////                    if (tr.Focused)
        ////                    {
        ////                        return uc;
        ////                    }
        ////                }
        ////                //txtpara1
        ////                Control[] c3 = uc.splitContainer2.Panel2.Controls.Find("txtpara1", false);
        ////                if (c3 != null)
        ////                {
        ////                    HtmlRichText.HtmlRichTextBox tr = (HtmlRichText.HtmlRichTextBox)c3[0];
        ////                    if (tr.Focused)
        ////                    {
        ////                        return uc;
        ////                    }
        ////                }
        ////                //rtxtdatapreview
        ////                Control[] c4 = uc.splitContainer3.Panel1.Controls.Find("rtxtdatapreview", false);
        ////                if (c4 != null)
        ////                {
        ////                    HtmlRichText.HtmlRichTextBox tr = (HtmlRichText.HtmlRichTextBox)c4[0];
        ////                    if (tr.Focused)
        ////                    {
        ////                        return uc;
        ////                    }
        ////                }

        ////                Control[] c5 = uc.splitContainer3.Panel2.Controls.Find("rtxtdata1", false);
        ////                if (c5 != null)
        ////                {
        ////                    HtmlRichText.HtmlRichTextBox tr = (HtmlRichText.HtmlRichTextBox)c5[0];
        ////                    if (tr.Focused)
        ////                    {
        ////                        return uc;
        ////                    }
        ////                }

        ////            }
        ////        }
        ////        return null;
        ////    }
        ////    catch (Exception ex)
        ////    {
        ////        ErrorHandling.WriteErrorLog(ex.ToString());
        ////    }
        ////    return null;
        ////}

        //#endregion

        //private void btngetstructure_Click(object sender, EventArgs e)
        //{
        //    //try
        //    //{
        //    //    this.Cursor = Cursors.WaitCursor;
        //    //    if (txtnametostructure.Text != null && txtnametostructure.Text != "")
        //    //    {
        //    //        string strmolstring = "";
        //    //        string strerrmess = "";
        //    //        if (!GetStructureFromCompoundName(txtnametostructure.Text, out strmolstring, out strerrmess))
        //    //        {
        //    //            MessageBox.Show(strerrmess);
        //    //        }
        //    //        else
        //    //        {
        //    //            //Molecule mmol = MolImporter.importMol(strmolstring);
        //    //            //marvinEditorControl.Molecule = mmol.toFormat("mrv"); ;
        //    //            //renderercntrl.Molecule = ;
        //    //        }

        //    //    }
        //    //    else
        //    //        MessageBox.Show("Please enter Compound Name");
        //    //}
        //    //catch (Exception ex)
        //    //{
        //    //    ErrorHandling.WriteErrorLog(ex.ToString());
        //    //}
        //    //finally
        //    //{
        //    //    this.Cursor = Cursors.Default;
        //    //}
        //}

        //public static bool GetStructureFromCompoundName(string strCompName, out string molstring_out, out string errmessage_out)
        //{
        //    bool blStatus = false;
        //    string strMolString = "";
        //    string strErrMessage = "";
        //    bool blIsChiral = false;
        //    try
        //    {
        //        string strDirPath = AppDomain.CurrentDomain.BaseDirectory.ToString();
        //        string strExePath = strDirPath + "nam2mol.exe";

        //        string strInputFileName = "CompName.txt";
        //        string strOutputFileName = "CompStructure.mol";

        //        if (System.IO.File.Exists(strDirPath + strInputFileName))
        //        {
        //            System.IO.File.Delete(strDirPath + strInputFileName);
        //        }
        //        System.IO.StreamWriter sWriter = new System.IO.StreamWriter(strDirPath + strInputFileName);
        //        sWriter.WriteLine(strCompName.Trim());
        //        sWriter.Close();
        //        sWriter.Dispose();

        //        if (System.IO.File.Exists(strDirPath + strOutputFileName))
        //        {
        //            System.IO.File.Delete(strDirPath + strOutputFileName);
        //        }

        //        //ProcessStartInfo class
        //        ProcessStartInfo startInfo = new ProcessStartInfo();
        //        startInfo.CreateNoWindow = true;
        //        startInfo.UseShellExecute = false;
        //        startInfo.RedirectStandardError = true;
        //        startInfo.FileName = @"" + strExePath + "";
        //        startInfo.WindowStyle = ProcessWindowStyle.Hidden;
        //        startInfo.Arguments = @"-in """ + strDirPath + strInputFileName + @"""  -out """ + strDirPath + strOutputFileName + @""" -depict true";
        //        //startInfo.Arguments = @"-in """ + strDirPath + strInputFileName + @""" -depict true";

        //        string strErrMsg = "";
        //        try
        //        {
        //            using (Process exeProcess = Process.Start(startInfo))
        //            {
        //                strErrMsg = exeProcess.StandardError.ReadToEnd();
        //                exeProcess.WaitForExit();
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            CAS_Narrative.ErrorHandling.WriteErrorLog(ex.ToString());
        //        }

        //        //Read Output molecule from outputfile
        //        StreamReader sReader = new StreamReader(strDirPath + strOutputFileName);
        //        string newMolfileString;
        //        newMolfileString = sReader.ReadToEnd();


        //        sReader.Close();
        //        sReader.Dispose();

        //        if (newMolfileString != "")
        //        {

        //            molstring_out = newMolfileString;
        //            errmessage_out = "";

        //            blStatus = true;
        //            return blStatus;
        //        }
        //        else
        //        {
        //            strErrMessage = strErrMsg;
        //            molstring_out = "";
        //            errmessage_out = strErrMessage;
        //            blStatus = false;
        //            return blStatus;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        CAS_Narrative.ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    molstring_out = "";

        //    errmessage_out = strErrMessage;
        //    return blStatus;
        //}

        //  OCR.OCRImageToText obj = new CAS_Narrative.OCR.OCRImageToText();
        //private void txtnametostructure_MouseClick(object sender, MouseEventArgs e)
        //{
        //    try
        //    {

        //        //IDataObject clipData = Clipboard.GetDataObject();
        //        //if (clipData.GetDataPresent(DataFormats.Text))
        //        //{
        //        //    txtnametostructure.Text = Clipboard.GetText();

        //        //}
        //        //else if (clipData.GetDataPresent(DataFormats.Bitmap))
        //        //{
        //        //    Image img = Clipboard.GetImage();

        //        //    if (img != null)
        //        //    {
        //        //        string strText = obj.GetOCRDataFromBMP((Bitmap)img);

        //        //        txtnametostructure.Text = strText;

        //        //    }
        //        //}
        //        //Clipboard.Clear();
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }

        //}

        //private void btnnametostructpdf_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        ofd.Reset();
        //        ofd.Filter = "pdf files (*.pdf)|*.pdf|All files (*.*)|*.*";
        //        if (ofd.ShowDialog() != DialogResult.Cancel)
        //        {
        //            string strfileextension = "";
        //            strfileextension = Path.GetExtension(ofd.FileName);
        //            if (strfileextension.ToUpper() == ".PDF")
        //            {
        //                try
        //                {
        //                    this.WindowState = FormWindowState.Normal;
        //                    this.WindowState = FormWindowState.Maximized;

        //                }
        //                catch (Exception ex)
        //                {
        //                    MessageBox.Show("Unable to open file", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //                    ErrorHandling.WriteErrorLog(ex.ToString());
        //                    //txtnametostructpath.Text = "";
        //                    return;

        //                }
        //            }




        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}

        #region Error Tracking

        //new code 
        //Error Tracking, Reviewers,QualityCheck,TeamLeads and Project Managers
        private List<clserrortrack> CheckErrorTrack(DataSet dsTandata, List<clsCASChild> _lstreactions, clsMaster _objtan)
        {
            List<clserrortrack> _lsterrortrack = new List<clserrortrack>();

            try
            {
                if (dsTandata != null)
                {
                    if (dsTandata.Tables.Count > 0)
                    {
                        if (dsTandata.Tables[0].Rows.Count > 0 && _lstreactions.Count > 0)
                        {
                            int irow = 0;
                            foreach (clsCASChild cr in _lstreactions)
                            {

                                foreach (var info in typeof(clsCASChild).GetProperties())
                                {
                                    clserrortrack objerror = new clserrortrack();
                                    ArrayList alexcludecols = new ArrayList();
                                    #region MyRegion
                                    alexcludecols.Add("SerialNumber");
                                    alexcludecols.Add("ReactionID");
                                    alexcludecols.Add("DocumentID");
                                    alexcludecols.Add("Data1");
                                    alexcludecols.Add("IsReviewCompleted");
                                    alexcludecols.Add("ReviewedByURID");
                                    #endregion

                                    //bool isreviewcomplted = cr.IsReviewCompleted;

                                    //if (Generic.globalVariables.UserRoleID != (Int32)Generic.Enums.Roles.Reviewer)
                                    //{
                                    //    isreviewcomplted = true;
                                    //}
                                    //if (isreviewcomplted)
                                    //{
                                    if (!alexcludecols.Contains(info.Name))
                                    {
                                        object objNewValue = GetValuefromList(info.Name, cr);
                                        object objOldValue = Getoldvaluefromds(info.Name, dsTandata, cr.ReactionID);

                                        if (!CheckOldAndNewValue(dsTandata, info.Name, objOldValue, null, objNewValue, null, cr.ReactionID, info.PropertyType.Name))
                                        {
                                            objerror.columnname = info.Name;
                                            if (objNewValue != null)
                                                objerror.newvalue = objNewValue.ToString();
                                            else
                                                objerror.newvalue = "";

                                            if (objOldValue != null)
                                                objerror.oldvalue = objOldValue.ToString();
                                            else
                                                objerror.oldvalue = "";

                                            objerror.documentID = documentid;
                                            objerror.reactionID = cr.ReactionID;
                                            objerror.tablename = "documentreactions";
                                            objerror.reported_by_ur_id = AssignedUserRoleID;
                                            objerror.reported_to_ur_id = Generic.globalVariables.UserID;
                                            _lsterrortrack.Add(objerror);

                                        }
                                    }
                                    //}
                                }
                                irow++;
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return _lsterrortrack;
        }

        private object GetValuefromList(string strColumnName, clsCASChild cr)
        {
            foreach (var info in typeof(clsCASChild).GetProperties())
            {
                if (info.Name.ToUpper() == strColumnName.ToUpper())
                {
                    return info.GetValue(cr, null);

                }
            }
            return null;
        }

        private object Getoldvaluefromds(string strColumnName, DataSet ds, int _reactionid)
        {
            object objvalue = null;
            if (ds != null)
            {
                if (ds.Tables.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        DataRow[] foundrows = ds.Tables[0].Select("reaction_id=" + _reactionid);
                        if (foundrows.Length > 0)
                        {
                            return foundrows[0][strColumnName];
                        }
                    }
                }
            }
            return objvalue;
        }

        //private bool CheckOldAndNewValue(DataSet ds, string strColumnName, object StroldValue, object StrNewValue, int _reactionid, string strType)
        //{

        //    try
        //    {


        //        if (StroldValue != null && StrNewValue != null)
        //        {
        //            if (strType.ToLower() == "int32")
        //            {
        //                if (Convert.ToInt32(StroldValue.ToString().Trim()) == Convert.ToInt32(StrNewValue.ToString().Trim()))
        //                {
        //                    return true;
        //                }
        //            }
        //            else if (strType.ToLower() == "double")
        //            {
        //                if (Convert.ToDouble(StroldValue.ToString().Trim()) == Convert.ToDouble(StrNewValue.ToString().Trim()))
        //                {
        //                    return true;
        //                }

        //            }
        //            else
        //            {
        //                #region html strings comparing
        //                if (strColumnName.ToUpper() == "TEXTLINE")
        //                {
        //                    ConvertHtmlToRtf(StroldValue.ToString(), hiddenrtf2);
        //                    StroldValue = hiddenrtf2.Text;

        //                    ConvertHtmlToRtf(StrNewValue.ToString(), hiddenrtf2);
        //                    StrNewValue = hiddenrtf2.Text;

        //                }
        //                else if (strColumnName.ToUpper() == "PARA")
        //                {
        //                    ConvertHtmlToRtf(StroldValue.ToString(), hiddenrtf2);
        //                    StroldValue = hiddenrtf2.Text;

        //                    ConvertHtmlToRtf(StrNewValue.ToString(), hiddenrtf2);
        //                    StrNewValue = hiddenrtf2.Text;

        //                }
        //                else if (strColumnName.ToUpper() == "PARA1")
        //                {
        //                    ConvertHtmlToRtf(StroldValue.ToString(), hiddenrtf2);
        //                    StroldValue = hiddenrtf2.Text;

        //                    ConvertHtmlToRtf(StrNewValue.ToString(), hiddenrtf2);
        //                    StrNewValue = hiddenrtf2.Text;

        //                }
        //                else if (strColumnName.ToUpper() == "DATA")
        //                {
        //                    ConvertHtmlToRtf(StroldValue.ToString(), hiddenrtf2);
        //                    StroldValue = hiddenrtf2.Text;

        //                    ConvertHtmlToRtf(StrNewValue.ToString(), hiddenrtf2);
        //                    StrNewValue = hiddenrtf2.Text;
        //                }
        //                #endregion

        //                if (StroldValue.ToString().ToUpper().Trim() == StrNewValue.ToString().ToUpper().Trim())
        //                {
        //                    return true;
        //                }

        //            }
        //        }


        //    }
        //    catch (Exception ex)
        //    {
        //        return false;
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return false;
        //}

        private bool CheckOldAndNewValue(DataSet ds, string strColumnName, object StroldValue, object objOldValueRTF, object StrNewValue, object objNewValueRTF, int _reactionid, string strType)
        {

            try
            {


                if (StroldValue != null && StrNewValue != null)
                {
                    if (strType.ToLower() == "int32")
                    {
                        if (Convert.ToInt32(StroldValue.ToString().Trim()) == Convert.ToInt32(StrNewValue.ToString().Trim()))
                        {
                            return true;
                        }
                    }
                    else if (strType.ToLower() == "double")
                    {
                        if (Convert.ToDouble(StroldValue.ToString().Trim()) == Convert.ToDouble(StrNewValue.ToString().Trim()))
                        {
                            return true;
                        }

                    }
                    else if (strType.ToLower() == "boolean" || strType.ToLower() == "bool")
                    {
                        if (Convert.ToBoolean(StroldValue.ToString()) == Convert.ToBoolean(StrNewValue.ToString()))
                        {
                            return true;
                        }

                    }
                    else if (strType.ToLower() == "string" && strColumnName.ToUpper() != "TEXTLINE" && strColumnName.ToUpper() != "PARA" &&
                            strColumnName.ToUpper() != "PARA1" && strColumnName.ToUpper() != "DATA")
                    {
                        string strold = "";
                        string strnew = "";
                        if (StroldValue != null)
                            strold = StroldValue.ToString();


                        if (StrNewValue != null)
                            strnew = StrNewValue.ToString();

                        if (strold.ToLower().Trim() == strnew.ToLower().Trim())
                        {
                            return true;
                        }

                    }
                    else
                    {
                        #region html strings comparing
                        if (strColumnName.ToUpper() == "TEXTLINE" || strColumnName.ToUpper() == "PARA" ||
                            strColumnName.ToUpper() == "PARA1" || strColumnName.ToUpper() == "DATA")
                        {
                            ConvertHtmlToRtf(StroldValue.ToString(), hiddenrtf2);
                            StroldValue = hiddenrtf2.Text;
                            objOldValueRTF = hiddenrtf2.Rtf;

                            ConvertHtmlToRtf(StrNewValue.ToString(), hiddenrtf2);
                            StrNewValue = hiddenrtf2.Text;
                            objNewValueRTF = hiddenrtf2.Rtf;

                        }

                        #endregion

                        int result = 0;
                        string strold = "";
                        string strnew = "";
                        if (objOldValueRTF != null)
                            strold = objOldValueRTF.ToString().ToUpper().Trim();

                        if (objNewValueRTF != null)
                            strnew = objNewValueRTF.ToString().ToUpper().Trim();

                        result = string.Compare(strold, strnew);


                        if (result == 0)
                        {
                            return true;
                        }

                    }
                }


            }
            catch (Exception ex)
            {
                return false;
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return false;
        }

        frmusererrorlist objusererror = null;
        private void lnlerrors_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            try
            {
                if (validations.Validatations.CheckFormIsOpenedORnot("frmusererrorlist", objusererror))
                {
                    objusererror.Close();

                }

                objusererror = new ErrorList.frmusererrorlist();

                objusererror.ShowDialog();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        #endregion

        //private void txtpagenumber_TextChanged(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        if (txtpagenumber.Text != null && txtpagenumber.Text != "")
        //        {
        //            if (Convert.ToInt32(txtpagenumber.Text) > 0)
        //            {

        //                if (Convert.ToInt32(txtpagenumber.Text) > _PageCount)
        //                {
        //                    MessageBox.Show("Please enter valid page number", "CAS Narrative tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //                    return;
        //                }
        //                else
        //                {
        //                    if (_pageSize == 0)
        //                    {
        //                        MessageBox.Show("Set the Page Size, and then click the Fill Grid button!");
        //                        return;
        //                    }
        //                    if (Convert.ToInt32(txtpagenumber.Text) > _currentPage)
        //                    {

        //                        _currentPage = Convert.ToInt32(txtpagenumber.Text);
        //                        if (_currentPage > _PageCount)
        //                        {
        //                            _currentPage = _PageCount;
        //                            //Check if you are already at the last page.
        //                            if (_recNo == _maxRec)
        //                            {
        //                                MessageBox.Show("You are at the Last Page!");
        //                                return;
        //                            }


        //                        }

        //                        _recNo = _pageSize * (_currentPage - 1);
        //                        CheckTableRowCount();
        //                        UpdateControlNamesInTable();
        //                        LoadPage();
        //                    }
        //                    else
        //                    {
        //                        if (_currentPage == _PageCount)
        //                        {
        //                            _recNo = _pageSize * (_currentPage - 2);
        //                        }

        //                        _currentPage = Convert.ToInt32(txtpagenumber.Text);
        //                        //Check if you are already at the first page.
        //                        if (_currentPage < 1)
        //                        {
        //                            MessageBox.Show("You are at the First Page!");
        //                            _currentPage = 1;
        //                            return;
        //                        }
        //                        else
        //                        {
        //                            _recNo = _pageSize * (_currentPage - 1);
        //                        }
        //                        CheckTableRowCount();
        //                        UpdateControlNamesInTable();
        //                        LoadPage();
        //                    }
        //                }
        //            }
        //            else
        //            {
        //                MessageBox.Show("Please enter valid page number", "CAS Narrative tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //                return;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Please enter valid page number", "CAS Narrative tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //    }
        //}

        //private void txtpagenumber_KeyPress(object sender, KeyPressEventArgs e)
        //{
        //    try
        //    {
        //        if (((e.KeyChar >= 48 && e.KeyChar <= 57) || e.KeyChar == 8 || e.KeyChar == 46 || e.KeyChar == 45) != true)
        //        {
        //            e.Handled = true;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message.ToString());
        //    }
        //}

        #region Export Pdf

        private void btnExportToPdf_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(TAN))
                {
                    using (FolderBrowserDialog objFolDlg = new FolderBrowserDialog())
                    {
                        if (objFolDlg.ShowDialog() == DialogResult.OK)
                        {
                            Cursor = Cursors.WaitCursor;

                            string strPdfName = objFolDlg.SelectedPath + "\\" + TAN + "_Reactions.pdf";

                            DataSet dsTANData = IndxReactNarr.DAL.CASNarrativeDataAccess.GetTANReportView(TAN, "TAN");
                            if (dsTANData != null)
                            {
                                if (dsTANData.Tables.Count > 0)
                                {
                                    DataTable dtReactions = dsreportview.Tables[0];
                                    ExportToPdf objExport = new ExportToPdf();
                                    if (objExport.ExportTANData(TAN, dsreportview.Tables[0], strPdfName))
                                    {
                                        Process.Start(strPdfName);
                                    }
                                }
                            }
                            Cursor = Cursors.Default;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        #endregion

        #region IsAnalagous , Analogous to combobox validation added by kranthi on 28-March-2014

        private bool IsNarIdValid(string NarId, bool isAnalogous, object analogousTo)
        {
            bool blStatus = true;
            try
            {
                {
                    if (NarId != null)
                    {
                        if (isAnalogous)
                        {
                            if (analogousTo == null)
                            {
                                MessageBox.Show("Is Analogous is checked, So analogousTo NarId cann't be blank.", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                blStatus = false;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Nar Id cann't be blank", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        blStatus = false;
                    }
                }
                return blStatus;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
                return blStatus;
            }

        }

        #endregion

        private bool WithOutValidations(uccasnartool_new uc, out clsMaster objdocument, out clsCASChild objdocdetails)
        {


            try
            {
                clsMaster _objdocument = new clsMaster();
                clsCASChild _objdocdetails = new clsCASChild();
                objdocument = null;
                objdocdetails = null;

                this.Cursor = Cursors.WaitCursor;


                _objdocdetails.ReactionID = uc.reactionID;


                if (uc.txtCASReactnumber.Text != "")
                {
                    _objdocdetails.ReactionCasReactantNumber = Convert.ToInt32(uc.txtCASReactnumber.Text.Trim());
                }


                if (uc.txtrxnseq.Text != "")
                {
                    _objdocdetails.Rxnseq = Convert.ToInt32(uc.txtrxnseq.Text.Trim());
                }

                _objdocdetails.DocRef = uc.txtdocref.Text;



                if (uc.txtpagenumber.Text != "")
                {
                    _objdocdetails.PageNumber = Convert.ToInt32(uc.txtpagenumber.Text);
                }


                _objdocdetails.PageLabel = uc.txtpagelabel.Text;

                _objdocdetails.PageLabel = uc.txtpagelabel.Text;





                _objdocdetails.filename = uc.txtfilename.Text;


                _objdocdetails.XResUnit = uc.txtxpageunit.Text;



                if (uc.txtxpagesize.Text != "")
                {
                    _objdocdetails.XPageSize = Convert.ToDouble(uc.txtxpagesize.Text);
                }

                if (uc.txtxoffset.Text != "")
                {
                    _objdocdetails.XOffset = Convert.ToDouble(uc.txtxoffset.Text);
                }

                _objdocdetails.YResUnit = uc.txtyresunit.Text;

                if (uc.txtypagesize.Text != "")
                {
                    _objdocdetails.YPageSize = Convert.ToDouble(uc.txtypagesize.Text);
                }

                if (uc.txtyoffset.Text != "")
                {
                    _objdocdetails.YOffset = Convert.ToDouble(uc.txtyoffset.Text);
                }


                _objdocdetails.TextLine = uc.TanDetails.TextLine;


                _objdocdetails.NarrativeID = uc.GetNarId();



                _objdocdetails.Para = uc.TanDetails.Para;


                _objdocdetails.Para1 = uc.TanDetails.Para1; //uc.txtpara1.Tag.ToString();



                _objdocdetails.Data = uc.TanDetails.Data; //uc.rtxtdatapreview.Tag.ToString();


                _objdocdetails.isGeneralTypical = uc.chkisGeneralTypical.Checked;
                _objdocdetails.noexperimentaldetails = uc.chkisgeneralprocempty.Checked;

                _objdocdetails.IsAnalogous = uc.chkIsAnalogous.Checked;

                if (uc.chkIsAnalogous.Checked)
                {
                    if (uc.cmbAnalogousTo.SelectedValue != null || uc.cmbAnalogousTo.SelectedValue != "")
                    {
                        _objdocdetails.AnalogousTo = Convert.ToInt32(uc.cmbAnalogousTo.SelectedValue);
                    }
                }

                _objdocdetails.IsCurationComplete = chkIsRxnComplete.Checked;
                _objdocdetails.IsMissingReaction = uc.chkIsMissingRxn.Checked;
                //_objdocdetails.Data1 = uc.TanDetails.Data1;

                objdocument = _objdocument;
                objdocdetails = _objdocdetails;
                return true;



            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
                objdocdetails = null;
                objdocument = null;
                return false;
            }
            //return false;

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want cancel changes and reload reaction ? ", "CAS Narrative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
            {
                LoadReaction(uccasnartool_new1.reactionID);
            }
        }

        private void dgvDocuments_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvTANDocuments.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvTANDocuments.Font);

                if (dgvTANDocuments.RowHeadersWidth < (int)(size.Width + 20)) dgvTANDocuments.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
