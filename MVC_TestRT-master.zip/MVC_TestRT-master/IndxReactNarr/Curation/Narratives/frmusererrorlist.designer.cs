﻿namespace CAS_Narrative.ErrorList
{
    partial class frmusererrorlist
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgusererror = new System.Windows.Forms.DataGridView();
            this.phase_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shipment_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.old_value = new DataGridViewRichTextBox.DataGridViewRichTextBoxColumn();
            this.new_value = new DataGridViewRichTextBox.DataGridViewRichTextBoxColumn();
            this.data_err_cnt = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.map_err_cnt = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.commented_by_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnall = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbtans = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbshipment = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbphase = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtmappcount = new System.Windows.Forms.TextBox();
            this.txtdpcount = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtcomments = new System.Windows.Forms.TextBox();
            this.dataGridViewRichTextBoxColumn1 = new DataGridViewRichTextBox.DataGridViewRichTextBoxColumn();
            this.dataGridViewRichTextBoxColumn2 = new DataGridViewRichTextBox.DataGridViewRichTextBoxColumn();
            this.hiddenctrl = new HtmlRichText.HtmlRichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgusererror)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgusererror
            // 
            this.dgusererror.AllowUserToAddRows = false;
            this.dgusererror.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgusererror.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgusererror.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgusererror.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.phase_name,
            this.shipment_id,
            this.tan,
            this.old_value,
            this.new_value,
            this.data_err_cnt,
            this.map_err_cnt,
            this.commented_by_name});
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HotTrack;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgusererror.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgusererror.Location = new System.Drawing.Point(0, 57);
            this.dgusererror.Name = "dgusererror";
            this.dgusererror.ReadOnly = true;
            this.dgusererror.RowHeadersVisible = false;
            this.dgusererror.RowTemplate.Height = 50;
            this.dgusererror.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgusererror.Size = new System.Drawing.Size(916, 431);
            this.dgusererror.TabIndex = 0;
            // 
            // phase_name
            // 
            this.phase_name.DataPropertyName = "phase_name";
            this.phase_name.FillWeight = 41.90845F;
            this.phase_name.HeaderText = "Phase";
            this.phase_name.Name = "phase_name";
            this.phase_name.ReadOnly = true;
            // 
            // shipment_id
            // 
            this.shipment_id.DataPropertyName = "shipment_id";
            this.shipment_id.FillWeight = 31.37885F;
            this.shipment_id.HeaderText = "Ship";
            this.shipment_id.Name = "shipment_id";
            this.shipment_id.ReadOnly = true;
            // 
            // tan
            // 
            this.tan.DataPropertyName = "tan";
            this.tan.FillWeight = 65.68064F;
            this.tan.HeaderText = "TAN";
            this.tan.Name = "tan";
            this.tan.ReadOnly = true;
            // 
            // old_value
            // 
            this.old_value.DataPropertyName = "old_value";
            this.old_value.FillWeight = 176.9246F;
            this.old_value.HeaderText = "Old Value";
            this.old_value.Name = "old_value";
            this.old_value.ReadOnly = true;
            this.old_value.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.old_value.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // new_value
            // 
            this.new_value.DataPropertyName = "new_value";
            this.new_value.FillWeight = 176.9246F;
            this.new_value.HeaderText = "New Value";
            this.new_value.Name = "new_value";
            this.new_value.ReadOnly = true;
            this.new_value.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.new_value.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // data_err_cnt
            // 
            this.data_err_cnt.DataPropertyName = "data_err_cnt";
            this.data_err_cnt.FalseValue = "F";
            this.data_err_cnt.FillWeight = 30.21679F;
            this.data_err_cnt.HeaderText = "Data Err";
            this.data_err_cnt.IndeterminateValue = "F";
            this.data_err_cnt.Name = "data_err_cnt";
            this.data_err_cnt.ReadOnly = true;
            this.data_err_cnt.TrueValue = "T";
            // 
            // map_err_cnt
            // 
            this.map_err_cnt.DataPropertyName = "map_err_cnt";
            this.map_err_cnt.FalseValue = "F";
            this.map_err_cnt.FillWeight = 26.39627F;
            this.map_err_cnt.HeaderText = "Mapping";
            this.map_err_cnt.IndeterminateValue = "F";
            this.map_err_cnt.Name = "map_err_cnt";
            this.map_err_cnt.ReadOnly = true;
            this.map_err_cnt.TrueValue = "T";
            // 
            // commented_by_name
            // 
            this.commented_by_name.DataPropertyName = "commented_by_name";
            this.commented_by_name.FillWeight = 97.52412F;
            this.commented_by_name.HeaderText = "Commented By";
            this.commented_by_name.Name = "commented_by_name";
            this.commented_by_name.ReadOnly = true;
            this.commented_by_name.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.commented_by_name.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnall);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.cmbtans);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.cmbshipment);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.cmbphase);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(916, 51);
            this.panel1.TabIndex = 1;
            // 
            // btnall
            // 
            this.btnall.Location = new System.Drawing.Point(393, 21);
            this.btnall.Name = "btnall";
            this.btnall.Size = new System.Drawing.Size(75, 23);
            this.btnall.TabIndex = 6;
            this.btnall.Text = "All";
            this.btnall.UseVisualStyleBackColor = true;
            this.btnall.Click += new System.EventHandler(this.btnall_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(267, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "TAN";
            // 
            // cmbtans
            // 
            this.cmbtans.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbtans.FormattingEnabled = true;
            this.cmbtans.Location = new System.Drawing.Point(266, 23);
            this.cmbtans.Name = "cmbtans";
            this.cmbtans.Size = new System.Drawing.Size(121, 21);
            this.cmbtans.TabIndex = 4;
            this.cmbtans.SelectedIndexChanged += new System.EventHandler(this.cmbtans_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(140, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Shipment";
            // 
            // cmbshipment
            // 
            this.cmbshipment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbshipment.FormattingEnabled = true;
            this.cmbshipment.Location = new System.Drawing.Point(139, 24);
            this.cmbshipment.Name = "cmbshipment";
            this.cmbshipment.Size = new System.Drawing.Size(121, 21);
            this.cmbshipment.TabIndex = 2;
            this.cmbshipment.SelectedIndexChanged += new System.EventHandler(this.cmbshipment_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Phase";
            // 
            // cmbphase
            // 
            this.cmbphase.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbphase.FormattingEnabled = true;
            this.cmbphase.Location = new System.Drawing.Point(12, 24);
            this.cmbphase.Name = "cmbphase";
            this.cmbphase.Size = new System.Drawing.Size(121, 21);
            this.cmbphase.TabIndex = 0;
            this.cmbphase.SelectedIndexChanged += new System.EventHandler(this.cmbphase_SelectedIndexChanged);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.txtmappcount);
            this.panel2.Controls.Add(this.txtdpcount);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.txtcomments);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 494);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(916, 70);
            this.panel2.TabIndex = 2;
            // 
            // txtmappcount
            // 
            this.txtmappcount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.txtmappcount.BackColor = System.Drawing.SystemColors.Info;
            this.txtmappcount.Location = new System.Drawing.Point(799, 37);
            this.txtmappcount.Name = "txtmappcount";
            this.txtmappcount.ReadOnly = true;
            this.txtmappcount.Size = new System.Drawing.Size(94, 21);
            this.txtmappcount.TabIndex = 5;
            // 
            // txtdpcount
            // 
            this.txtdpcount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.txtdpcount.BackColor = System.Drawing.SystemColors.Info;
            this.txtdpcount.Location = new System.Drawing.Point(693, 37);
            this.txtdpcount.Name = "txtdpcount";
            this.txtdpcount.ReadOnly = true;
            this.txtdpcount.Size = new System.Drawing.Size(94, 21);
            this.txtdpcount.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(796, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "MappingErrorCount";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(690, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "DataErrorCount";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Comments:";
            // 
            // txtcomments
            // 
            this.txtcomments.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtcomments.BackColor = System.Drawing.SystemColors.Info;
            this.txtcomments.Location = new System.Drawing.Point(2, 20);
            this.txtcomments.Multiline = true;
            this.txtcomments.Name = "txtcomments";
            this.txtcomments.ReadOnly = true;
            this.txtcomments.Size = new System.Drawing.Size(681, 45);
            this.txtcomments.TabIndex = 0;
            // 
            // dataGridViewRichTextBoxColumn1
            // 
            this.dataGridViewRichTextBoxColumn1.DataPropertyName = "old_value";
            this.dataGridViewRichTextBoxColumn1.HeaderText = "Old Value";
            this.dataGridViewRichTextBoxColumn1.Name = "dataGridViewRichTextBoxColumn1";
            this.dataGridViewRichTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewRichTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewRichTextBoxColumn1.Width = 115;
            // 
            // dataGridViewRichTextBoxColumn2
            // 
            this.dataGridViewRichTextBoxColumn2.DataPropertyName = "new_value";
            this.dataGridViewRichTextBoxColumn2.HeaderText = "New Value";
            this.dataGridViewRichTextBoxColumn2.Name = "dataGridViewRichTextBoxColumn2";
            this.dataGridViewRichTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewRichTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewRichTextBoxColumn2.Width = 114;
            // 
            // hiddenctrl
            // 
            this.hiddenctrl.Location = new System.Drawing.Point(428, 252);
            this.hiddenctrl.Name = "hiddenctrl";
            this.hiddenctrl.Size = new System.Drawing.Size(61, 61);
            this.hiddenctrl.TabIndex = 4;
            this.hiddenctrl.Text = "";
            // 
            // frmusererrorlist
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(916, 564);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dgusererror);
            this.Controls.Add(this.hiddenctrl);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmusererrorlist";
            this.Text = "User Error List";
            this.Load += new System.EventHandler(this.frmusererrorlist_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgusererror)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgusererror;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbshipment;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbphase;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbtans;
        private System.Windows.Forms.TextBox txtcomments;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtmappcount;
        private System.Windows.Forms.TextBox txtdpcount;
        private System.Windows.Forms.Button btnall;
        private DataGridViewRichTextBox.DataGridViewRichTextBoxColumn dataGridViewRichTextBoxColumn1;
        private DataGridViewRichTextBox.DataGridViewRichTextBoxColumn dataGridViewRichTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn phase_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn shipment_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn tan;
        private DataGridViewRichTextBox.DataGridViewRichTextBoxColumn old_value;
        private DataGridViewRichTextBox.DataGridViewRichTextBoxColumn new_value;
        private System.Windows.Forms.DataGridViewCheckBoxColumn data_err_cnt;
        private System.Windows.Forms.DataGridViewCheckBoxColumn map_err_cnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn commented_by_name;
        private HtmlRichText.HtmlRichTextBox hiddenctrl;
    }
}