﻿namespace IndxReactNarr.Curation.Narratives
{
    partial class frmFindAndReplace
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvSrchResults = new System.Windows.Forms.DataGridView();
            this.colSelect = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colRxnID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnSNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colField = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFieldValue = new DataGridViewRichTextBox.DataGridViewRichTextBoxColumn();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.chkSelectAll = new System.Windows.Forms.CheckBox();
            this.lblStatusValue = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.pnlControls = new System.Windows.Forms.Panel();
            this.btnReplace = new System.Windows.Forms.Button();
            this.lblReplace = new System.Windows.Forms.Label();
            this.ucHrtbReplace = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.btnFind = new System.Windows.Forms.Button();
            this.lblFind = new System.Windows.Forms.Label();
            this.ucHrtbFind = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.ucSplCharsToolStrip_Indexing1 = new IndxReactNarr.UserControls.ucSplCharsToolStrip_Indexing();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSrchResults)).BeginInit();
            this.pnlBottom.SuspendLayout();
            this.pnlControls.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.dgvSrchResults);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Controls.Add(this.pnlControls);
            this.pnlMain.Controls.Add(this.ucSplCharsToolStrip_Indexing1);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(933, 440);
            this.pnlMain.TabIndex = 0;
            // 
            // dgvSrchResults
            // 
            this.dgvSrchResults.AllowUserToAddRows = false;
            this.dgvSrchResults.AllowUserToDeleteRows = false;
            this.dgvSrchResults.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvSrchResults.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSrchResults.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSelect,
            this.colRxnID,
            this.colRxnSNo,
            this.colField,
            this.colFieldValue});
            this.dgvSrchResults.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSrchResults.Location = new System.Drawing.Point(0, 163);
            this.dgvSrchResults.Name = "dgvSrchResults";
            this.dgvSrchResults.Size = new System.Drawing.Size(933, 249);
            this.dgvSrchResults.TabIndex = 2;
            this.dgvSrchResults.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgvSrchResults_DataBindingComplete);
            this.dgvSrchResults.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvSrchResults_RowPostPaint);
            // 
            // colSelect
            // 
            this.colSelect.FalseValue = "FALSE";
            this.colSelect.HeaderText = "Select";
            this.colSelect.Name = "colSelect";
            this.colSelect.TrueValue = "TRUE";
            // 
            // colRxnID
            // 
            this.colRxnID.HeaderText = "RxnID";
            this.colRxnID.Name = "colRxnID";
            this.colRxnID.ReadOnly = true;
            this.colRxnID.Visible = false;
            // 
            // colRxnSNo
            // 
            this.colRxnSNo.HeaderText = "RxnNo";
            this.colRxnSNo.Name = "colRxnSNo";
            this.colRxnSNo.ReadOnly = true;
            this.colRxnSNo.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colRxnSNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colField
            // 
            this.colField.HeaderText = "Field";
            this.colField.Name = "colField";
            this.colField.ReadOnly = true;
            this.colField.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colField.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colFieldValue
            // 
            this.colFieldValue.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.colFieldValue.DefaultCellStyle = dataGridViewCellStyle1;
            this.colFieldValue.HeaderText = "FieldValue";
            this.colFieldValue.Name = "colFieldValue";
            this.colFieldValue.ReadOnly = true;
            this.colFieldValue.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom.Controls.Add(this.chkSelectAll);
            this.pnlBottom.Controls.Add(this.lblStatusValue);
            this.pnlBottom.Controls.Add(this.lblStatus);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 412);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(933, 28);
            this.pnlBottom.TabIndex = 3;
            // 
            // chkSelectAll
            // 
            this.chkSelectAll.AutoSize = true;
            this.chkSelectAll.Location = new System.Drawing.Point(4, 3);
            this.chkSelectAll.Name = "chkSelectAll";
            this.chkSelectAll.Size = new System.Drawing.Size(83, 21);
            this.chkSelectAll.TabIndex = 2;
            this.chkSelectAll.Text = "Select All";
            this.chkSelectAll.UseVisualStyleBackColor = true;
            this.chkSelectAll.CheckStateChanged += new System.EventHandler(this.chkSelectAll_CheckStateChanged);
            // 
            // lblStatusValue
            // 
            this.lblStatusValue.AutoSize = true;
            this.lblStatusValue.Location = new System.Drawing.Point(189, 5);
            this.lblStatusValue.Name = "lblStatusValue";
            this.lblStatusValue.Size = new System.Drawing.Size(18, 17);
            this.lblStatusValue.TabIndex = 1;
            this.lblStatusValue.Text = "--";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(134, 5);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(51, 17);
            this.lblStatus.TabIndex = 0;
            this.lblStatus.Text = "Status: ";
            // 
            // pnlControls
            // 
            this.pnlControls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlControls.Controls.Add(this.btnReplace);
            this.pnlControls.Controls.Add(this.lblReplace);
            this.pnlControls.Controls.Add(this.ucHrtbReplace);
            this.pnlControls.Controls.Add(this.btnFind);
            this.pnlControls.Controls.Add(this.lblFind);
            this.pnlControls.Controls.Add(this.ucHrtbFind);
            this.pnlControls.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlControls.Location = new System.Drawing.Point(0, 74);
            this.pnlControls.Name = "pnlControls";
            this.pnlControls.Size = new System.Drawing.Size(933, 89);
            this.pnlControls.TabIndex = 1;
            // 
            // btnReplace
            // 
            this.btnReplace.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReplace.Location = new System.Drawing.Point(846, 51);
            this.btnReplace.Name = "btnReplace";
            this.btnReplace.Size = new System.Drawing.Size(75, 27);
            this.btnReplace.TabIndex = 5;
            this.btnReplace.Text = "Replace";
            this.btnReplace.UseVisualStyleBackColor = true;
            this.btnReplace.Click += new System.EventHandler(this.btnReplace_Click);
            // 
            // lblReplace
            // 
            this.lblReplace.AutoSize = true;
            this.lblReplace.Location = new System.Drawing.Point(4, 51);
            this.lblReplace.Name = "lblReplace";
            this.lblReplace.Size = new System.Drawing.Size(56, 17);
            this.lblReplace.TabIndex = 4;
            this.lblReplace.Text = "Replace";
            // 
            // ucHrtbReplace
            // 
            this.ucHrtbReplace.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ucHrtbReplace.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ucHrtbReplace.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ucHrtbReplace.Location = new System.Drawing.Point(66, 46);
            this.ucHrtbReplace.Name = "ucHrtbReplace";
            this.ucHrtbReplace.PreserveMultiLines = false;
            this.ucHrtbReplace.Size = new System.Drawing.Size(774, 39);
            this.ucHrtbReplace.TabIndex = 1;
            // 
            // btnFind
            // 
            this.btnFind.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFind.Location = new System.Drawing.Point(846, 9);
            this.btnFind.Name = "btnFind";
            this.btnFind.Size = new System.Drawing.Size(75, 27);
            this.btnFind.TabIndex = 2;
            this.btnFind.Text = "Find";
            this.btnFind.UseVisualStyleBackColor = true;
            this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
            // 
            // lblFind
            // 
            this.lblFind.AutoSize = true;
            this.lblFind.Location = new System.Drawing.Point(27, 8);
            this.lblFind.Name = "lblFind";
            this.lblFind.Size = new System.Drawing.Size(33, 17);
            this.lblFind.TabIndex = 1;
            this.lblFind.Text = "Find";
            // 
            // ucHrtbFind
            // 
            this.ucHrtbFind.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ucHrtbFind.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ucHrtbFind.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ucHrtbFind.Location = new System.Drawing.Point(67, 4);
            this.ucHrtbFind.Name = "ucHrtbFind";
            this.ucHrtbFind.PreserveMultiLines = false;
            this.ucHrtbFind.Size = new System.Drawing.Size(773, 39);
            this.ucHrtbFind.TabIndex = 0;
            // 
            // ucSplCharsToolStrip_Indexing1
            // 
            this.ucSplCharsToolStrip_Indexing1.BackColor = System.Drawing.Color.White;
            this.ucSplCharsToolStrip_Indexing1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ucSplCharsToolStrip_Indexing1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ucSplCharsToolStrip_Indexing1.Location = new System.Drawing.Point(0, 0);
            this.ucSplCharsToolStrip_Indexing1.Name = "ucSplCharsToolStrip_Indexing1";
            this.ucSplCharsToolStrip_Indexing1.Size = new System.Drawing.Size(933, 74);
            this.ucSplCharsToolStrip_Indexing1.TabIndex = 0;
            // 
            // frmFindAndReplace
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(933, 440);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmFindAndReplace";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Find and Replace";
            //this.Load += new System.EventHandler(this.frmFindAndReplace_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSrchResults)).EndInit();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.pnlControls.ResumeLayout(false);
            this.pnlControls.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private UserControls.ucSplCharsToolStrip_Indexing ucSplCharsToolStrip_Indexing1;
        private System.Windows.Forms.Panel pnlControls;
        private System.Windows.Forms.Button btnFind;
        private System.Windows.Forms.Label lblFind;
        private System.Windows.Forms.Label lblReplace;
        private System.Windows.Forms.Button btnReplace;
        private System.Windows.Forms.DataGridView dgvSrchResults;
        public UserControls.ucHtmlRichText ucHrtbFind;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Label lblStatusValue;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colSelect;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnSNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colField;
        private DataGridViewRichTextBox.DataGridViewRichTextBoxColumn colFieldValue;
        public UserControls.ucHtmlRichText ucHrtbReplace;
        private System.Windows.Forms.CheckBox chkSelectAll;
    }
}