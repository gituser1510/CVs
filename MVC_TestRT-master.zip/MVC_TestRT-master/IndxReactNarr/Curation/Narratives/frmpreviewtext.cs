﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//using mshtml;
using System.Collections;
using IndxReactNarr.Generic;

namespace IndxReactNarr
{
    public partial class frmpreviewtext : Form
    {
        public frmpreviewtext()
        {
            InitializeComponent();
        }
        private string _strPreview = "";
        public string PreviewString
        {
            get { return _strPreview; }
            set { _strPreview = value; }
        }

        private string _txtname = "";
        public string textboxname
        {
            get { return _txtname; }
            set { _txtname = value; }
        }

        private onlyconnect.HtmlEditor _html = null;
        public onlyconnect.HtmlEditor HtmControl
        {
            get { return _html; }
            set {_html=value; }
        }
        private bool _status = false;
        public bool Status
        {
            get { return _status; }
            set { _status = value; }
        }
        private void frmpreviewtext_Load(object sender, EventArgs e)
        {   
            try
            {
                if (textboxname.Length > 0)
                {
                    if (textboxname == "TEXTLINE")
                    {
                        transferToTeiToolStripMenuItem.Visible = true;
                        transferToPara1ToolStripMenuItem.Visible = false;
                        transferToPara2ToolStripMenuItem.Visible = false;
                        transferToDataToolStripMenuItem.Visible = false;
                    }
                }
              
                richTextBox1.Text = PreviewString;
            //  FillColors();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to show text","",MessageBoxButtons.OK,MessageBoxIcon.Error);
                ErrorHandling.WriteErrorLog(ex.ToString());

            }

        }
        public void FillColors()
        {
            if (richTextBox1.Text != null)
            {
                ArrayList allist = new ArrayList();
                allist.Add("sup");
                allist.Add("sub");
                allist.Add("bold");
                allist.Add("ital");

                for (int i = 0; i < allist.Count; i++)
                {
                    if(richTextBox1.Text.Contains(allist[i].ToString()))
                    {

                      
                            bool blnloop = false;
                            int startindex = 0;
                            indexOfSearchText = 0;
                            int start = 0;
                            while (blnloop == false)
                            {

                                if (allist[i].ToString().Length > 0)
                                {
                                    startindex = FindMyText(allist[i].ToString(), start, richTextBox1.Text.Length, richTextBox1);
                                    if (startindex == -1)
                                    {
                                        blnloop = true;
                                    }
                                }

                                if (startindex >= 0)
                                {
                                    // Set the highlight color as red
                                    int endindex = allist[i].ToString().Length;
                                    // Highlight the search string
                                    richTextBox1.Select(startindex, endindex);
                                    if (allist[i].ToString() == "sub")
                                    {
                                        richTextBox1.SelectionColor = Color.LightSkyBlue;
                                    }
                                    else if (allist[i].ToString() == "sup")
                                    {
                                        richTextBox1.SelectionColor = Color.LightGreen;
                                    }
                                    else if (allist[i].ToString() == "bold")
                                    {
                                        richTextBox1.SelectionColor = Color.LightSteelBlue;
                                    }
                                    else if (allist[i].ToString() == "ital")
                                    {
                                        richTextBox1.SelectionColor = Color.LightPink;
                                    }
                                    start = startindex + endindex;


                                }
                          

                        }


                    }
                }





            }
        }
        public void filltextbox(onlyconnect.HtmlEditor _html)
        {
            _html.Dock = DockStyle.Fill;
            this.Controls.Add(_html);
            HtmControl = _html;
            //htmlEditor1.Document.body.innerText = str;
        }

        private void frmpreviewtext_KeyDown(object sender, KeyEventArgs e)
        {
            if((e.Control)&&(e.KeyCode.ToString().ToUpper()=="F"))
            {
                //if (richTextBox1.SelectedText != null)
                //{
                //    frmfind frm = new frmfind();
                //    frm.strfindwhat = richTextBox1.SelectedText;
                //    if (frm.ShowDialog() != DialogResult.OK)
                //    {
                //      richTextBox1.SelectedText= frm.strfindwhat;
                //    }
                //}
            }
        }
        int indexOfSearchText = 0;
        private void richTextBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.Control) && (e.KeyCode.ToString().ToUpper() == "F"))
            {
                if (richTextBox1.SelectedText != null)
                {
                    //frmfind frm = new frmfind();
                    //frm.strfindwhat = richTextBox1.SelectedText;
                    //if (frm.ShowDialog() != DialogResult.OK)
                    //{
                    //    string strtextsearch = frm.strfindwhat;

                    //    if (richTextBox1.Text.Contains(strtextsearch))
                    //    {
                    //        bool blnloop = false;
                    //        int startindex = 0;
                    //        indexOfSearchText = 0;
                    //       int start = 0;
                    //        while (blnloop == false)
                    //        {

                    //            if (strtextsearch.Length > 0)
                    //            {
                    //                startindex = FindMyText(strtextsearch.Trim(), start, richTextBox1.Text.Length, richTextBox1);
                    //                if (startindex == -1)
                    //                {
                    //                    blnloop = true;
                    //                }
                    //            }

                    //            if (startindex >= 0)
                    //            {
                    //                // Set the highlight color as red
                    //                int endindex = strtextsearch.Length;
                    //                // Highlight the search string
                    //                richTextBox1.Select(startindex, endindex);
                    //                richTextBox1.SelectionBackColor = Color.LightBlue;
                    //                start = startindex + endindex;
                                   

                    //            }
                    //        }
                           
                    //    }




                        
                    //}
                }
            }

        }

        



        /// <summary>
        /// Find Text
        /// </summary>
        /// <param name="txtToSearch"></param>
        /// <param name="searchStart"></param>
        /// <param name="searchEnd"></param>
        /// <param name="rtb"></param>
        /// <returns></returns>
        public int FindMyText(string txtToSearch, int searchStart, int searchEnd, System.Windows.Forms.RichTextBox rtb)
        {
            // Unselect the previously searched string
            //if (searchStart > 0 && searchEnd > 0 && indexOfSearchText >= 0)
            //{
            //    return -1;
            //   // rtb.Undo();
            //}

            // Set the return value to -1 by default.
            int retVal = -1;

            // A valid starting index should be specified.
            // if indexOfSearchText = -1, the end of search
            if (searchStart >= 0 && indexOfSearchText >= 0)
            {
                // A valid ending index
                if (searchEnd > searchStart || searchEnd == -1)
                {
                    rtb.Refresh();
                    // Find the position of search string in RichTextBox
                    indexOfSearchText = rtb.Find(txtToSearch, searchStart, searchEnd, RichTextBoxFinds.None);
                  
                    retVal = indexOfSearchText;
                    //}
                    //else
                    //{
                    //    return -1;
                    //}
                }
            }
            return retVal;
        }

        private string _strText = "";
        public string SelectedData
        {
            get { return _strText; }
            set { _strText = value; }
        }
        private string _strsendto = "";
        public string SendTO
        {
            get { return _strsendto; }
            set { _strsendto = value; }
        }
        public void transferToTeiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Status = true;
            SelectedData = richTextBox1.Text;
            SendTO = "TEXTLINE";
            //this.Close();
            

        }

        public void transferToPara1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Status = true;
            SelectedData = richTextBox1.Text;
            SendTO = "PARA1";
            //this.Close();
        }

        public void transferToPara2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Status = true;
            SelectedData = richTextBox1.Text;
            SendTO = "PARA2";
            //this.Close();
        }

        public void transferToDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Status = true;
            SelectedData = richTextBox1.Text;
            SendTO = "DATA";
            //this.Close();
        }

        public void hiToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void contextMenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void richTextBox1_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                if (richTextBox1.SelectedText != null)
                {
                    string strtextsearch = richTextBox1.SelectedText;
                    richTextBox1.SelectAll();
                    richTextBox1.SelectionBackColor = Color.White;
                    if (richTextBox1.Text.Contains(strtextsearch))
                    {
                        bool blnloop = false;
                        int startindex = 0;
                        indexOfSearchText = 0;
                        int start = 0;
                        while (blnloop == false)
                        {

                            if (strtextsearch.Length > 0)
                            {
                                startindex = FindMyText(strtextsearch.Trim(), start, richTextBox1.Text.Length, richTextBox1);
                                if (startindex == -1)
                                {
                                    blnloop = true;
                                }
                            }

                            if (startindex >= 0)
                            {
                                // Set the highlight color as red
                                int endindex = strtextsearch.Length;
                                // Highlight the search string
                                richTextBox1.Select(startindex, endindex);
                                richTextBox1.SelectionBackColor = Color.LightBlue;
                                start = startindex + endindex;


                            }
                        }

                    }


                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

      
    }
}
