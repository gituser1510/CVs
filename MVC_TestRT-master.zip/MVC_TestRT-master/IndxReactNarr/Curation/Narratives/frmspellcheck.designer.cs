﻿namespace IndxReactNarr
{
    partial class frmspellcheck
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btncancel = new System.Windows.Forms.Button();
            this.btnok = new System.Windows.Forms.Button();
            this.Spelled = new Keyoti.RapidSpell.AYTRichTextBox();
            this.rapidSpellAsYouType1 = new Keyoti.RapidSpell.RapidSpellAsYouType(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.Spelled);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(616, 414);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btncancel);
            this.panel2.Controls.Add(this.btnok);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 414);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(616, 49);
            this.panel2.TabIndex = 1;
            // 
            // btncancel
            // 
            this.btncancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btncancel.Location = new System.Drawing.Point(538, 14);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(75, 23);
            this.btncancel.TabIndex = 1;
            this.btncancel.Text = "Cancel";
            this.btncancel.UseVisualStyleBackColor = true;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // btnok
            // 
            this.btnok.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnok.Location = new System.Drawing.Point(457, 14);
            this.btnok.Name = "btnok";
            this.btnok.Size = new System.Drawing.Size(75, 23);
            this.btnok.TabIndex = 0;
            this.btnok.Text = "Ok";
            this.btnok.UseVisualStyleBackColor = true;
            this.btnok.Click += new System.EventHandler(this.btnok_Click);
            // 
            // Spelled
            // 
            this.Spelled.ContextMenuDefault = null;
            this.Spelled.ContextMenuStripDefault = null;
            this.Spelled.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Spelled.Location = new System.Drawing.Point(0, 0);
            this.Spelled.Name = "Spelled";
            this.Spelled.ShowCutCopyPasteContextMenu = false;
            this.Spelled.ShowCutCopyPasteContextMenuStrip = false;
            this.Spelled.Size = new System.Drawing.Size(614, 412);
            this.Spelled.TabIndex = 0;
            this.Spelled.Text = "";
            this.Spelled.UnderlineYOffset = 0;
            this.Spelled.UseUndoCompatibleTextAccess = false;
            this.Spelled.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Spelled_MouseDown);
            // 
            // rapidSpellAsYouType1
            // 
            this.rapidSpellAsYouType1.AddMenuText = "Ignore";
            this.rapidSpellAsYouType1.AllowAnyCase = true;
            this.rapidSpellAsYouType1.AllowMixedCase = true;
            this.rapidSpellAsYouType1.CheckAsYouType = true;
            this.rapidSpellAsYouType1.CheckCompoundWords = false;
            this.rapidSpellAsYouType1.ConsiderationRange = 500;
            this.rapidSpellAsYouType1.ContextMenuStripEnabled = true;
            this.rapidSpellAsYouType1.DictFilePath = null;
            this.rapidSpellAsYouType1.FindCapitalizedSuggestions = false;
            this.rapidSpellAsYouType1.GUILanguage = Keyoti.RapidSpell.LanguageType.ENGLISH;
            this.rapidSpellAsYouType1.IgnoreAllMenuText = "Ignore All";
            this.rapidSpellAsYouType1.IgnoreCapitalizedWords = false;
            this.rapidSpellAsYouType1.IgnoreURLsAndEmailAddresses = true;
            this.rapidSpellAsYouType1.IgnoreWordsWithDigits = false;
            this.rapidSpellAsYouType1.IgnoreXML = false;
            this.rapidSpellAsYouType1.IncludeUserDictionaryInSuggestions = false;
            this.rapidSpellAsYouType1.LanguageParser = Keyoti.RapidSpell.LanguageType.ENGLISH;
            this.rapidSpellAsYouType1.LookIntoHyphenatedText = true;
            this.rapidSpellAsYouType1.SeparateHyphenWords = true;
            this.rapidSpellAsYouType1.ShowAddMenuOption = false;
            this.rapidSpellAsYouType1.ShowSuggestionsContextMenu = false;
            this.rapidSpellAsYouType1.ShowSuggestionsWhenTextIsSelected = false;
            this.rapidSpellAsYouType1.SuggestionsMethod = Keyoti.RapidSpell.SuggestionsMethodType.HashingSuggestions;
            this.rapidSpellAsYouType1.SuggestSplitWords = true;
            this.rapidSpellAsYouType1.TextComponent = this.Spelled;
            this.rapidSpellAsYouType1.UnderlineColor = System.Drawing.Color.Red;
            this.rapidSpellAsYouType1.UnderlineStyle = Keyoti.RapidSpell.UnderlineStyle.Wavy;
            this.rapidSpellAsYouType1.UpdateAllTextBoxes = true;
            this.rapidSpellAsYouType1.UserDictionaryFile = null;
            this.rapidSpellAsYouType1.V2Parser = true;
            //this.rapidSpellAsYouType1.WordIgnored += new Keyoti.RapidSpell.RapidSpellAsYouType.WordIgnoredEventHandler(this.rapidSpellAsYouType1_WordIgnored);
            // 
            // frmspellcheck
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(616, 463);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "frmspellcheck";
            this.Text = "Spellcheck ";
            this.Load += new System.EventHandler(this.frmspellcheck_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.Button btnok;
        private Keyoti.RapidSpell.AYTRichTextBox Spelled;
        private Keyoti.RapidSpell.RapidSpellAsYouType rapidSpellAsYouType1;
    }
}