﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;

namespace IndxReactNarr.Curation.Narratives
{
    public partial class frmTANReportView : Form
    {
        public frmTANReportView()
        {
            InitializeComponent();
        }

        public int TAN_ID { get; set; }
        public string TAN_Name { get; set; }
        public DataTable TAN_Reactions { get; set; }
       
        private void frmTANReportView_Load(object sender, EventArgs e)
        {
            try
            {
                if (TAN_ID > 0)
                {
                    this.Text = TAN_Name + "- Report";
                    //DataTable dtReactions = IndxReactNarrDAL.NarrativesDB.GetTANReactionsOnTANID(TAN_ID);
                    DataTable dtReactions = IndxReactNarrDAL.NarrativesDB.GetTANReactionsForExportOnTANID(TAN_ID);
                    if (dtReactions != null)
                    {
                        dtReactions = GetFomattedReactionsData(dtReactions);

                        TAN_Reactions = dtReactions;
                                                
                        //Bind reactions to Grid
                        BindReactionsToGrid(TAN_Reactions);

                        //Bind reactions to listbox
                        BindReactionsToCheckedListBox(TAN_Reactions);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private DataTable GetFomattedReactionsData(DataTable tanReactions)
        {
            DataTable dtTANRxns = null;
            try
            {
                if (tanReactions != null)
                {                    
                    dtTANRxns = new DataTable();
                    dtTANRxns.Columns.Add("RXN_ID",typeof(Int64));
                    dtTANRxns.Columns.Add("RXN_NAR_ID");
                    dtTANRxns.Columns.Add("ANALOGOUS_TO");
                    dtTANRxns.Columns.Add("RXN_NUM");
                    dtTANRxns.Columns.Add("RXN_SEQ");
                    dtTANRxns.Columns.Add("DOC_REF");
                    dtTANRxns.Columns.Add("IS_GENERAL_TYPICAL");
                    dtTANRxns.Columns.Add("NO_EXP_DETAILS");

                    dtTANRxns.Columns.Add("PAGE_NO");
                    dtTANRxns.Columns.Add("PAGE_LABEL");
                    dtTANRxns.Columns.Add("OFFSET_X");
                    dtTANRxns.Columns.Add("OFFSET_Y");
                    dtTANRxns.Columns.Add("PAGE_SIZE_X");
                    dtTANRxns.Columns.Add("PAGE_SIZE_Y");

                    dtTANRxns.Columns.Add("TEXT_LINE");
                    dtTANRxns.Columns.Add("YIELD_TEXT");
                    dtTANRxns.Columns.Add("PARA1");
                    dtTANRxns.Columns.Add("PARA2");
                    dtTANRxns.Columns.Add("DATA_TEXT");
                    dtTANRxns.Columns.Add("PROCEDURE_TEXT");

                    string strpara1 = "";
                    string strpara2 = "";
                    string strAnalogous = "";
                    foreach (DataRow dr in tanReactions.Rows)
                    {
                        strpara1 = "";
                        strpara2 = "";
                        strAnalogous = "";

                        DataRow dRow = dtTANRxns.NewRow();
                        dRow["RXN_ID"] = Convert.ToInt64(dr["RXN_ID"]);
                        dRow["RXN_NAR_ID"] = dr["RXN_NAR_ID"];
                        if (dr["IS_ANALOGOUS"].ToString() == "Y")
                        {
                            if (!System.DBNull.Value.Equals(dr["ANALOGOUS_RXN_ID"]))
                            {
                                int analogRxnID = 0;
                                int.TryParse(dr["ANALOGOUS_RXN_ID"].ToString(), out analogRxnID);
                                if (analogRxnID > 0)
                                {
                                    var a = ((from row in tanReactions.AsEnumerable().Where(r => r.Field<Int64>("RXN_ID") == analogRxnID)
                                              select row.Field<string>("RXN_NAR_ID")).First());
                                    strAnalogous = a;
                                }
                            }
                        }

                        dRow["ANALOGOUS_TO"] = strAnalogous;
                        dRow["RXN_NUM"] = dr["RXN_NUM"];
                        dRow["RXN_SEQ"] = dr["RXN_SEQ"];

                        dRow["DOC_REF"] = dr["DOC_REF"];

                        dRow["IS_GENERAL_TYPICAL"] = dr["IS_GENERAL_TYPICAL"];
                        dRow["NO_EXP_DETAILS"] = dr["NO_EXP_DETAILS"];

                        dRow["PAGE_NO"] = dr["PAGE_NO"];
                        dRow["PAGE_LABEL"] = dr["PAGE_LABEL"];

                        dRow["OFFSET_X"] = dr["OFFSET_X"];
                        dRow["OFFSET_Y"] = dr["OFFSET_Y"];

                        dRow["PAGE_SIZE_X"] = dr["PAGE_SIZE_X"];
                        dRow["PAGE_SIZE_Y"] = dr["PAGE_SIZE_Y"];

                        dRow["TEXT_LINE"] = Html_RtfConversions.Instance.GetRTFfromHTMLString(dr["TEXT_LINE"].ToString(), false);
                        dRow["DATA_TEXT"] = Html_RtfConversions.Instance.GetRTFfromHTMLString(dr["DATA_TEXT"].ToString(), false);
                        dRow["YIELD_TEXT"] = Html_RtfConversions.Instance.GetRTFfromHTMLString(dr["YIELD_TEXT"].ToString(), false);
                        dRow["PROCEDURE_TEXT"] = Html_RtfConversions.Instance.GetRTFfromHTMLString(dr["PROCEDURE_TEXT"].ToString().Replace("\r\n", "").Trim(), false);

                        string[] saParas = dr["PARA_TEXT"].ToString().Split(new string[] { "``PARA``" }, StringSplitOptions.RemoveEmptyEntries);
                        if (saParas != null)
                        {
                            if (saParas.Length > 0)
                            {
                                //First paras should be in Para1
                                for (int i = 0; i < saParas.Length - 1; i++)
                                {
                                    if (saParas.Length > 0)
                                    {
                                        strpara1 = string.IsNullOrEmpty(strpara1.Trim()) ? Html_RtfConversions.Instance.GetRTFfromHTMLString(saParas[i].Trim().Replace("\r\n", "").Trim(), false) : strpara1.Trim() + "<PARA>" + Html_RtfConversions.Instance.GetRTFfromHTMLString(saParas[i].Trim().Replace("\r\n", "").Trim(), false);
                                    }
                                }

                                //Last para should be in Para2
                                if (saParas.Length > 1)
                                {
                                    strpara2 = Html_RtfConversions.Instance.GetRTFfromHTMLString(saParas[saParas.Length - 1].Trim().Replace("\r\n", "").TrimEnd(), false);
                                }
                                else
                                {
                                    strpara1 = Html_RtfConversions.Instance.GetRTFfromHTMLString(saParas[0].Trim().Replace("\r\n", "").TrimEnd(), false);
                                }
                            }
                        }

                        dRow["PARA1"] = strpara1;
                        dRow["PARA2"] = strpara2;
                        dtTANRxns.Rows.Add(dRow);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtTANRxns;
        }

        private void BindReactionsToCheckedListBox(DataTable tanReactions)
        {
            try
            {                
                if (tanReactions != null)
                {
                    if (tanReactions.Rows.Count > 0)
                    {
                        chklstReactions.DataSource = tanReactions;
                        chklstReactions.DisplayMember = "RXN_NAR_ID";
                        chklstReactions.ValueMember = "RXN_ID";
                        chklstReactions.SelectedIndex = 0;
                    }
                } 
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindReactionsToGrid(DataTable tanReactions)
        {
            try
            {
                if (tanReactions != null)
                {      
                    dgvReactions.AutoGenerateColumns = false;
                    dgvReactions.DataSource = tanReactions;

                    colRxnID.DataPropertyName = "RXN_ID";
                    colNarID.DataPropertyName = "RXN_NAR_ID";
                    colRxnNUM.DataPropertyName = "RXN_NUM";
                    colRxnSeq.DataPropertyName = "RXN_SEQ";
                    colPageNo.DataPropertyName = "PAGE_NO";
                    colDocRef.DataPropertyName = "DOC_REF"; 
                    colAnalogousTo.DataPropertyName = "ANALOGOUS_TO";
                    colNoExpDetails.DataPropertyName = "NO_EXP_DETAILS";
                    colIsGenTypical.DataPropertyName = "IS_GENERAL_TYPICAL";
                    colPageLabel.DataPropertyName = "PAGE_LABEL";
                    colXOffSet.DataPropertyName = "OFFSET_X";
                    colYOffSet.DataPropertyName = "OFFSET_Y";
                    colXPageSize.DataPropertyName = "PAGE_SIZE_X";
                    colYPageSize.DataPropertyName = "PAGE_SIZE_Y";
                    colTextLine.DataPropertyName = "TEXT_LINE";
                    colPara1.DataPropertyName = "PARA1";
                    colPara2.DataPropertyName = "PARA2";
                    colData.DataPropertyName = "DATA_TEXT";

                    colYieldText.DataPropertyName = "YIELD_TEXT";
                    colProcedureText.DataPropertyName = "PROCEDURE_TEXT";

                    if (GlobalVariables.ApplicationName == Enums.ApplicationName.NARRATIVES.ToString())
                    {
                        colYieldText.Visible = false;
                        colProcedureText.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private List<Int64> GetSelectedReactions()
        {
            List<Int64> selRxnIDs = null;
            try
            {
                if (chklstReactions.CheckedItems.Count > 0)
                {
                    selRxnIDs = new List<Int64>();
                    DataRowView drView = null;
                    for (int i = 0; i < chklstReactions.CheckedItems.Count; i++)
                    {
                        drView = chklstReactions.CheckedItems[i] as DataRowView;
                        selRxnIDs.Add(Convert.ToInt64(drView["RXN_ID"]));
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return selRxnIDs;
        }

        private DataTable GetFilteredReactions(List<Int64> selRxnIDs)
        {
            DataTable selRxns = null;
            try
            {
                if (selRxnIDs != null)
                {
                    var x = from d in TAN_Reactions.Copy().AsEnumerable()
                            join r in selRxnIDs on d.Field<Int64>("RXN_ID") equals r
                            select d;
                    selRxns = TAN_Reactions.Clone();

                    foreach (DataRow dr in x)
                    {
                        selRxns.ImportRow(dr);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return selRxns;
        }

        private void chklstReactions_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (chklstReactions.CheckedItems.Count > 0)
                {
                    List<Int64> lstSelRxns = GetSelectedReactions();
                    DataTable dtFilterRxns = GetFilteredReactions(lstSelRxns);
                    BindReactionsToGrid(dtFilterRxns);
                }
                else
                {
                    BindReactionsToGrid(TAN_Reactions);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvReactions_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvReactions.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvReactions.Font);

                if (dgvReactions.RowHeadersWidth < (int)(size.Width + 20)) dgvReactions.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnResetSelection_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (int i in chklstReactions.CheckedIndices)
                {
                    chklstReactions.SetItemCheckState(i, CheckState.Unchecked);
                }

                BindReactionsToGrid(TAN_Reactions);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
