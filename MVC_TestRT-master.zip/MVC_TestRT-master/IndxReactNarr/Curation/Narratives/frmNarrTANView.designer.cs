﻿namespace IndxReactNarr
{
    partial class frmNarrTANView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNarrTANView));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.chkIsRxnComplete = new System.Windows.Forms.CheckBox();
            this.btnExportToPdf = new System.Windows.Forms.Button();
            this.lnlerrors = new System.Windows.Forms.LinkLabel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnExportToExcel = new System.Windows.Forms.Button();
            this.lblreccountvalue = new System.Windows.Forms.Label();
            this.lblRxnCount = new System.Windows.Forms.Label();
            this.pnlreactions = new System.Windows.Forms.Panel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splCntTreeViewAndTool = new System.Windows.Forms.SplitContainer();
            this.splCntTreeviewDocs = new System.Windows.Forms.SplitContainer();
            this.tvRxns = new System.Windows.Forms.TreeView();
            this.dgvTANDocuments = new System.Windows.Forms.DataGridView();
            this.colDocID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDocNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDocName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblTANDocs = new System.Windows.Forms.Label();
            this.rtfformula = new HtmlRichText.HtmlRichTextBox();
            this.tcTool = new System.Windows.Forms.TabControl();
            this.tpCuration = new System.Windows.Forms.TabPage();
            this.pnlUserControl = new System.Windows.Forms.Panel();
            this.pnlMasterDetails = new System.Windows.Forms.Panel();
            this.tsGreekChrs = new System.Windows.Forms.ToolStrip();
            this.tsalpha = new System.Windows.Forms.ToolStripButton();
            this.tsbBeta = new System.Windows.Forms.ToolStripButton();
            this.tsgamma = new System.Windows.Forms.ToolStripButton();
            this.tsbDelta = new System.Windows.Forms.ToolStripButton();
            this.tsepsilon = new System.Windows.Forms.ToolStripButton();
            this.tszeta = new System.Windows.Forms.ToolStripButton();
            this.tsbLatinEta = new System.Windows.Forms.ToolStripButton();
            this.tsbTheta = new System.Windows.Forms.ToolStripButton();
            this.tsbIota = new System.Windows.Forms.ToolStripButton();
            this.tsbKappa = new System.Windows.Forms.ToolStripButton();
            this.tslamda = new System.Windows.Forms.ToolStripButton();
            this.tsbMu = new System.Windows.Forms.ToolStripButton();
            this.tsbNu = new System.Windows.Forms.ToolStripButton();
            this.tsxsi = new System.Windows.Forms.ToolStripButton();
            this.tsomricon = new System.Windows.Forms.ToolStripButton();
            this.tsbSmallLetterPi = new System.Windows.Forms.ToolStripButton();
            this.tsbSmallLetterRho = new System.Windows.Forms.ToolStripButton();
            this.tssigmaf = new System.Windows.Forms.ToolStripButton();
            this.tsbSigma = new System.Windows.Forms.ToolStripButton();
            this.tsbTau = new System.Windows.Forms.ToolStripButton();
            this.tsupsilon = new System.Windows.Forms.ToolStripButton();
            this.tsbPhi = new System.Windows.Forms.ToolStripButton();
            this.tsbChi = new System.Windows.Forms.ToolStripButton();
            this.tsbPsi = new System.Windows.Forms.ToolStripButton();
            this.tsomega = new System.Windows.Forms.ToolStripButton();
            this.tsbVeritcalLine = new System.Windows.Forms.ToolStripButton();
            this.ts1degree = new System.Windows.Forms.ToolStripButton();
            this.tsbTilde = new System.Windows.Forms.ToolStripButton();
            this.tsbYen = new System.Windows.Forms.ToolStripButton();
            this.tsbDoubleS = new System.Windows.Forms.ToolStripButton();
            this.tsbCopyRight = new System.Windows.Forms.ToolStripButton();
            this.tsbLeftDoubleAngleQuotes = new System.Windows.Forms.ToolStripButton();
            this.tsbRegisteredTradeMark = new System.Windows.Forms.ToolStripButton();
            this.tsbParagraphSign = new System.Windows.Forms.ToolStripButton();
            this.tsbPlusOrMinus = new System.Windows.Forms.ToolStripButton();
            this.tsbLatinLetterO = new System.Windows.Forms.ToolStripButton();
            this.tsbLatinLetterF = new System.Windows.Forms.ToolStripButton();
            this.tsbDagger = new System.Windows.Forms.ToolStripButton();
            this.tsbDoubleDagger = new System.Windows.Forms.ToolStripButton();
            this.tsbBullet = new System.Windows.Forms.ToolStripButton();
            this.tsbCaretCircumflex = new System.Windows.Forms.ToolStripButton();
            this.tsbLessThanEqual = new System.Windows.Forms.ToolStripButton();
            this.tsbGreaterThanEqual = new System.Windows.Forms.ToolStripButton();
            this.tsbIntegral = new System.Windows.Forms.ToolStripButton();
            this.tsbNaryProduct = new System.Windows.Forms.ToolStripButton();
            this.tsbSummation = new System.Windows.Forms.ToolStripButton();
            this.tsbLatinSmallf = new System.Windows.Forms.ToolStripButton();
            this.tsbIncrement = new System.Windows.Forms.ToolStripButton();
            this.tsbAwithRing = new System.Windows.Forms.ToolStripButton();
            this.tsbOwithStoke = new System.Windows.Forms.ToolStripButton();
            this.ts1triplebond = new System.Windows.Forms.ToolStripButton();
            this.tsbAwithCircumflex = new System.Windows.Forms.ToolStripButton();
            this.tsbOmega = new System.Windows.Forms.ToolStripButton();
            this.tsbDiaeresis = new System.Windows.Forms.ToolStripButton();
            this.tsbUwithDiaeresis = new System.Windows.Forms.ToolStripButton();
            this.tsbPi = new System.Windows.Forms.ToolStripButton();
            this.tsbGreekV = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton20 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton21 = new System.Windows.Forms.ToolStripButton();
            this.tsbAlmostEqualTo = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton23 = new System.Windows.Forms.ToolStripButton();
            this.tsFontStyleCntrls = new System.Windows.Forms.ToolStrip();
            this.ts1findandreplace = new System.Windows.Forms.ToolStripButton();
            this.tspFndReplaceBold = new System.Windows.Forms.ToolStripSeparator();
            this.tsbold = new System.Windows.Forms.ToolStripButton();
            this.tsundeline = new System.Windows.Forms.ToolStripButton();
            this.tsitalic = new System.Windows.Forms.ToolStripButton();
            this.tsstrikeout = new System.Windows.Forms.ToolStripButton();
            this.tsRegular = new System.Windows.Forms.ToolStripButton();
            this.tspRegularSuperScript = new System.Windows.Forms.ToolStripSeparator();
            this.tssuperscript = new System.Windows.Forms.ToolStripButton();
            this.tsfont = new System.Windows.Forms.ToolStripButton();
            this.tssubscript = new System.Windows.Forms.ToolStripButton();
            this.tspSubScriptUndo = new System.Windows.Forms.ToolStripSeparator();
            this.tsUndo = new System.Windows.Forms.ToolStripButton();
            this.tsredo = new System.Windows.Forms.ToolStripButton();
            this.tspRedoAddRxn = new System.Windows.Forms.ToolStripSeparator();
            this.tsAddreaction = new System.Windows.Forms.ToolStripButton();
            this.tsconvformula = new System.Windows.Forms.ToolStripButton();
            this.tspFormulaHidden = new System.Windows.Forms.ToolStripSeparator();
            this.tsbhidden = new System.Windows.Forms.ToolStripButton();
            this.tpCoOrdinates = new System.Windows.Forms.TabPage();
            this.pnlCoOrdinateCntls = new System.Windows.Forms.Panel();
            this.btnbrowsecood = new System.Windows.Forms.Button();
            this.txtbrowsecoordinates = new System.Windows.Forms.TextBox();
            this.txtcpage = new System.Windows.Forms.TextBox();
            this.btnPageSize = new System.Windows.Forms.Button();
            this.btnZoomOnArea = new System.Windows.Forms.Button();
            this.btnZoomFit = new System.Windows.Forms.Button();
            this.btnZoom100 = new System.Windows.Forms.Button();
            this.btZoomOut = new System.Windows.Forms.Button();
            this.btZoomIn = new System.Windows.Forms.Button();
            this.txtZoom = new System.Windows.Forms.TextBox();
            this.btNextPage = new System.Windows.Forms.Button();
            this.btlastpage = new System.Windows.Forms.Button();
            this.btPreviousPage = new System.Windows.Forms.Button();
            this.btFirstpage = new System.Windows.Forms.Button();
            this.lbPos = new System.Windows.Forms.Label();
            this.lblxy = new System.Windows.Forms.Label();
            this.lbPage = new System.Windows.Forms.Label();
            this.lblPdfPath = new System.Windows.Forms.Label();
            this.btnZoomWidth = new System.Windows.Forms.Button();
            this.dgviewer = new AxGdViewerPro4.AxGdViewer();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.pnlTANDtls = new System.Windows.Forms.Panel();
            this.txtTANType = new System.Windows.Forms.TextBox();
            this.lblTANType = new System.Windows.Forms.Label();
            this.txtDOI = new System.Windows.Forms.TextBox();
            this.txtCAN = new System.Windows.Forms.TextBox();
            this.lblTan = new System.Windows.Forms.Label();
            this.txtTAN = new System.Windows.Forms.TextBox();
            this.lblCan = new System.Windows.Forms.Label();
            this.lblDOI = new System.Windows.Forms.Label();
            this.ofd = new System.Windows.Forms.OpenFileDialog();
            this.sfd = new System.Windows.Forms.SaveFileDialog();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.miniToolStrip = new System.Windows.Forms.ToolStrip();
            this.chkwordwrap = new System.Windows.Forms.CheckBox();
            this.lblScrollbars = new System.Windows.Forms.Label();
            this.cmb1scrollbars = new System.Windows.Forms.ComboBox();
            this.btntb1filepathpdf3 = new System.Windows.Forms.Button();
            this.txttb1filepathdoc1 = new System.Windows.Forms.TextBox();
            this.tsbIncFontSize = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton83 = new System.Windows.Forms.ToolStripButton();
            this.tsbSuperScript = new System.Windows.Forms.ToolStripButton();
            this.tsbSubScript = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.tsa = new System.Windows.Forms.ToolStripButton();
            this.tsbeta = new System.Windows.Forms.ToolStripButton();
            this.tsgama = new System.Windows.Forms.ToolStripButton();
            this.tsdelta = new System.Windows.Forms.ToolStripButton();
            this.txtepsilon = new System.Windows.Forms.ToolStripButton();
            this.txtzeta = new System.Windows.Forms.ToolStripButton();
            this.tseta = new System.Windows.Forms.ToolStripButton();
            this.ts1symbol = new System.Windows.Forms.ToolStripButton();
            this.tb1btnpreview = new System.Windows.Forms.Button();
            this.pnlBottom.SuspendLayout();
            this.pnlreactions.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.splCntTreeViewAndTool.Panel1.SuspendLayout();
            this.splCntTreeViewAndTool.Panel2.SuspendLayout();
            this.splCntTreeViewAndTool.SuspendLayout();
            this.splCntTreeviewDocs.Panel1.SuspendLayout();
            this.splCntTreeviewDocs.Panel2.SuspendLayout();
            this.splCntTreeviewDocs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTANDocuments)).BeginInit();
            this.tcTool.SuspendLayout();
            this.tpCuration.SuspendLayout();
            this.pnlMasterDetails.SuspendLayout();
            this.tsGreekChrs.SuspendLayout();
            this.tsFontStyleCntrls.SuspendLayout();
            this.tpCoOrdinates.SuspendLayout();
            this.pnlCoOrdinateCntls.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgviewer)).BeginInit();
            this.pnlTANDtls.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlBottom
            // 
            this.pnlBottom.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom.Controls.Add(this.chkIsRxnComplete);
            this.pnlBottom.Controls.Add(this.btnExportToPdf);
            this.pnlBottom.Controls.Add(this.lnlerrors);
            this.pnlBottom.Controls.Add(this.btnCancel);
            this.pnlBottom.Controls.Add(this.btnUpdate);
            this.pnlBottom.Controls.Add(this.btnExportToExcel);
            this.pnlBottom.Controls.Add(this.lblreccountvalue);
            this.pnlBottom.Controls.Add(this.lblRxnCount);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 709);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(1360, 33);
            this.pnlBottom.TabIndex = 1;
            // 
            // chkIsRxnComplete
            // 
            this.chkIsRxnComplete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.chkIsRxnComplete.AutoSize = true;
            this.chkIsRxnComplete.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIsRxnComplete.Location = new System.Drawing.Point(887, 5);
            this.chkIsRxnComplete.Name = "chkIsRxnComplete";
            this.chkIsRxnComplete.Size = new System.Drawing.Size(145, 19);
            this.chkIsRxnComplete.TabIndex = 19;
            this.chkIsRxnComplete.Text = "Is Reaction Complete";
            this.chkIsRxnComplete.UseVisualStyleBackColor = true;
            // 
            // btnExportToPdf
            // 
            this.btnExportToPdf.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExportToPdf.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportToPdf.Image = ((System.Drawing.Image)(resources.GetObject("btnExportToPdf.Image")));
            this.btnExportToPdf.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExportToPdf.Location = new System.Drawing.Point(1038, 3);
            this.btnExportToPdf.Name = "btnExportToPdf";
            this.btnExportToPdf.Size = new System.Drawing.Size(68, 23);
            this.btnExportToPdf.TabIndex = 18;
            this.btnExportToPdf.Text = "Export";
            this.btnExportToPdf.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExportToPdf.UseVisualStyleBackColor = true;
            this.btnExportToPdf.Click += new System.EventHandler(this.btnExportToPdf_Click);
            // 
            // lnlerrors
            // 
            this.lnlerrors.AutoSize = true;
            this.lnlerrors.LinkColor = System.Drawing.Color.Red;
            this.lnlerrors.Location = new System.Drawing.Point(9, 10);
            this.lnlerrors.Name = "lnlerrors";
            this.lnlerrors.Size = new System.Drawing.Size(34, 13);
            this.lnlerrors.TabIndex = 15;
            this.lnlerrors.TabStop = true;
            this.lnlerrors.Text = "Errors";
            this.lnlerrors.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnlerrors_LinkClicked);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(1275, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 13;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdate.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.Location = new System.Drawing.Point(1194, 3);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 13;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnExportToExcel
            // 
            this.btnExportToExcel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExportToExcel.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportToExcel.Image = ((System.Drawing.Image)(resources.GetObject("btnExportToExcel.Image")));
            this.btnExportToExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExportToExcel.Location = new System.Drawing.Point(1113, 3);
            this.btnExportToExcel.Name = "btnExportToExcel";
            this.btnExportToExcel.Size = new System.Drawing.Size(75, 23);
            this.btnExportToExcel.TabIndex = 4;
            this.btnExportToExcel.Text = "Export";
            this.btnExportToExcel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExportToExcel.UseVisualStyleBackColor = true;
            this.btnExportToExcel.Click += new System.EventHandler(this.btnexport_Click);
            // 
            // lblreccountvalue
            // 
            this.lblreccountvalue.AutoSize = true;
            this.lblreccountvalue.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblreccountvalue.Location = new System.Drawing.Point(171, 10);
            this.lblreccountvalue.Name = "lblreccountvalue";
            this.lblreccountvalue.Size = new System.Drawing.Size(14, 15);
            this.lblreccountvalue.TabIndex = 3;
            this.lblreccountvalue.Text = "0";
            // 
            // lblRxnCount
            // 
            this.lblRxnCount.AutoSize = true;
            this.lblRxnCount.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnCount.Location = new System.Drawing.Point(77, 10);
            this.lblRxnCount.Name = "lblRxnCount";
            this.lblRxnCount.Size = new System.Drawing.Size(101, 15);
            this.lblRxnCount.TabIndex = 2;
            this.lblRxnCount.Text = "Reaction Count : ";
            // 
            // pnlreactions
            // 
            this.pnlreactions.AutoScroll = true;
            this.pnlreactions.Controls.Add(this.splitContainer1);
            this.pnlreactions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlreactions.Location = new System.Drawing.Point(0, 0);
            this.pnlreactions.Name = "pnlreactions";
            this.pnlreactions.Size = new System.Drawing.Size(1360, 709);
            this.pnlreactions.TabIndex = 2;
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Panel1Collapsed = true;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splCntTreeViewAndTool);
            this.splitContainer1.Size = new System.Drawing.Size(1360, 709);
            this.splitContainer1.SplitterDistance = 680;
            this.splitContainer1.TabIndex = 0;
            this.splitContainer1.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.splitContainer1_SplitterMoved);
            // 
            // splCntTreeViewAndTool
            // 
            this.splCntTreeViewAndTool.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splCntTreeViewAndTool.Location = new System.Drawing.Point(0, 0);
            this.splCntTreeViewAndTool.Name = "splCntTreeViewAndTool";
            // 
            // splCntTreeViewAndTool.Panel1
            // 
            this.splCntTreeViewAndTool.Panel1.Controls.Add(this.splCntTreeviewDocs);
            // 
            // splCntTreeViewAndTool.Panel2
            // 
            this.splCntTreeViewAndTool.Panel2.Controls.Add(this.tcTool);
            this.splCntTreeViewAndTool.Panel2.Controls.Add(this.pnlTANDtls);
            this.splCntTreeViewAndTool.Size = new System.Drawing.Size(1358, 707);
            this.splCntTreeViewAndTool.SplitterDistance = 218;
            this.splCntTreeViewAndTool.TabIndex = 1;
            // 
            // splCntTreeviewDocs
            // 
            this.splCntTreeviewDocs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splCntTreeviewDocs.Location = new System.Drawing.Point(0, 0);
            this.splCntTreeviewDocs.Name = "splCntTreeviewDocs";
            this.splCntTreeviewDocs.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splCntTreeviewDocs.Panel1
            // 
            this.splCntTreeviewDocs.Panel1.Controls.Add(this.tvRxns);
            // 
            // splCntTreeviewDocs.Panel2
            // 
            this.splCntTreeviewDocs.Panel2.Controls.Add(this.dgvTANDocuments);
            this.splCntTreeviewDocs.Panel2.Controls.Add(this.lblTANDocs);
            this.splCntTreeviewDocs.Panel2.Controls.Add(this.rtfformula);
            this.splCntTreeviewDocs.Size = new System.Drawing.Size(218, 707);
            this.splCntTreeviewDocs.SplitterDistance = 541;
            this.splCntTreeviewDocs.TabIndex = 1;
            // 
            // tvRxns
            // 
            this.tvRxns.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvRxns.Location = new System.Drawing.Point(0, 0);
            this.tvRxns.Name = "tvRxns";
            this.tvRxns.Size = new System.Drawing.Size(218, 541);
            this.tvRxns.TabIndex = 1;
            this.tvRxns.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvRxns_AfterSelect);
            // 
            // dgvTANDocuments
            // 
            this.dgvTANDocuments.AllowUserToAddRows = false;
            this.dgvTANDocuments.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTANDocuments.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvTANDocuments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTANDocuments.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colDocID,
            this.colDocNo,
            this.colDocName});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTANDocuments.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvTANDocuments.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTANDocuments.Location = new System.Drawing.Point(0, 20);
            this.dgvTANDocuments.Name = "dgvTANDocuments";
            this.dgvTANDocuments.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTANDocuments.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvTANDocuments.Size = new System.Drawing.Size(218, 142);
            this.dgvTANDocuments.TabIndex = 3;
            this.dgvTANDocuments.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvDocuments_RowPostPaint);
            // 
            // colDocID
            // 
            this.colDocID.HeaderText = "DocID";
            this.colDocID.Name = "colDocID";
            this.colDocID.ReadOnly = true;
            this.colDocID.Visible = false;
            // 
            // colDocNo
            // 
            this.colDocNo.HeaderText = "DocNo";
            this.colDocNo.Name = "colDocNo";
            this.colDocNo.ReadOnly = true;
            this.colDocNo.Width = 50;
            // 
            // colDocName
            // 
            this.colDocName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colDocName.HeaderText = "DocName";
            this.colDocName.Name = "colDocName";
            this.colDocName.ReadOnly = true;
            // 
            // lblTANDocs
            // 
            this.lblTANDocs.BackColor = System.Drawing.Color.FloralWhite;
            this.lblTANDocs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTANDocs.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTANDocs.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTANDocs.Location = new System.Drawing.Point(0, 0);
            this.lblTANDocs.Name = "lblTANDocs";
            this.lblTANDocs.Size = new System.Drawing.Size(218, 20);
            this.lblTANDocs.TabIndex = 4;
            this.lblTANDocs.Text = "TAN File Names";
            this.lblTANDocs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rtfformula
            // 
            this.rtfformula.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.rtfformula.Location = new System.Drawing.Point(11, 140);
            this.rtfformula.Name = "rtfformula";
            this.rtfformula.Size = new System.Drawing.Size(230, 13);
            this.rtfformula.TabIndex = 0;
            this.rtfformula.Text = "";
            this.rtfformula.Visible = false;
            // 
            // tcTool
            // 
            this.tcTool.Controls.Add(this.tpCuration);
            this.tcTool.Controls.Add(this.tpCoOrdinates);
            this.tcTool.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcTool.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tcTool.ImageList = this.imageList1;
            this.tcTool.Location = new System.Drawing.Point(0, 32);
            this.tcTool.Name = "tcTool";
            this.tcTool.SelectedIndex = 0;
            this.tcTool.Size = new System.Drawing.Size(1136, 675);
            this.tcTool.TabIndex = 0;
            // 
            // tpCuration
            // 
            this.tpCuration.Controls.Add(this.pnlUserControl);
            this.tpCuration.Controls.Add(this.pnlMasterDetails);
            this.tpCuration.ImageIndex = 3;
            this.tpCuration.Location = new System.Drawing.Point(4, 24);
            this.tpCuration.Name = "tpCuration";
            this.tpCuration.Padding = new System.Windows.Forms.Padding(3);
            this.tpCuration.Size = new System.Drawing.Size(1128, 647);
            this.tpCuration.TabIndex = 0;
            this.tpCuration.Text = "Curation";
            this.tpCuration.UseVisualStyleBackColor = true;
            // 
            // pnlUserControl
            // 
            this.pnlUserControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlUserControl.Location = new System.Drawing.Point(3, 56);
            this.pnlUserControl.Name = "pnlUserControl";
            this.pnlUserControl.Size = new System.Drawing.Size(1122, 588);
            this.pnlUserControl.TabIndex = 0;
            // 
            // pnlMasterDetails
            // 
            this.pnlMasterDetails.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlMasterDetails.Controls.Add(this.tsGreekChrs);
            this.pnlMasterDetails.Controls.Add(this.tsFontStyleCntrls);
            this.pnlMasterDetails.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlMasterDetails.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMasterDetails.Location = new System.Drawing.Point(3, 3);
            this.pnlMasterDetails.Name = "pnlMasterDetails";
            this.pnlMasterDetails.Size = new System.Drawing.Size(1122, 53);
            this.pnlMasterDetails.TabIndex = 0;
            // 
            // tsGreekChrs
            // 
            this.tsGreekChrs.BackColor = System.Drawing.Color.White;
            this.tsGreekChrs.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsalpha,
            this.tsbBeta,
            this.tsgamma,
            this.tsbDelta,
            this.tsepsilon,
            this.tszeta,
            this.tsbLatinEta,
            this.tsbTheta,
            this.tsbIota,
            this.tsbKappa,
            this.tslamda,
            this.tsbMu,
            this.tsbNu,
            this.tsxsi,
            this.tsomricon,
            this.tsbSmallLetterPi,
            this.tsbSmallLetterRho,
            this.tssigmaf,
            this.tsbSigma,
            this.tsbTau,
            this.tsupsilon,
            this.tsbPhi,
            this.tsbChi,
            this.tsbPsi,
            this.tsomega,
            this.tsbVeritcalLine,
            this.ts1degree,
            this.tsbTilde,
            this.tsbYen,
            this.tsbDoubleS,
            this.tsbCopyRight,
            this.tsbLeftDoubleAngleQuotes,
            this.tsbRegisteredTradeMark,
            this.tsbParagraphSign,
            this.tsbPlusOrMinus,
            this.tsbLatinLetterO,
            this.tsbLatinLetterF,
            this.tsbDagger,
            this.tsbDoubleDagger,
            this.tsbBullet,
            this.tsbCaretCircumflex,
            this.tsbLessThanEqual,
            this.tsbGreaterThanEqual,
            this.tsbIntegral,
            this.tsbNaryProduct,
            this.tsbSummation,
            this.tsbLatinSmallf,
            this.tsbIncrement,
            this.tsbAwithRing,
            this.tsbOwithStoke,
            this.ts1triplebond,
            this.tsbAwithCircumflex,
            this.tsbOmega,
            this.tsbDiaeresis,
            this.tsbUwithDiaeresis,
            this.tsbPi,
            this.tsbGreekV,
            this.toolStripButton20,
            this.toolStripButton21,
            this.tsbAlmostEqualTo,
            this.toolStripButton23});
            this.tsGreekChrs.Location = new System.Drawing.Point(0, 25);
            this.tsGreekChrs.Name = "tsGreekChrs";
            this.tsGreekChrs.Size = new System.Drawing.Size(1120, 25);
            this.tsGreekChrs.TabIndex = 44;
            this.tsGreekChrs.Tag = "XC";
            this.tsGreekChrs.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip3_ItemClicked);
            // 
            // tsalpha
            // 
            this.tsalpha.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsalpha.Image = ((System.Drawing.Image)(resources.GetObject("tsalpha.Image")));
            this.tsalpha.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsalpha.Name = "tsalpha";
            this.tsalpha.Size = new System.Drawing.Size(23, 22);
            this.tsalpha.Tag = "&#945;";
            this.tsalpha.Text = "α";
            // 
            // tsbBeta
            // 
            this.tsbBeta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbBeta.Image = ((System.Drawing.Image)(resources.GetObject("tsbBeta.Image")));
            this.tsbBeta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbBeta.Name = "tsbBeta";
            this.tsbBeta.Size = new System.Drawing.Size(23, 22);
            this.tsbBeta.Tag = "&beta;";
            this.tsbBeta.Text = "β";
            // 
            // tsgamma
            // 
            this.tsgamma.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsgamma.Image = ((System.Drawing.Image)(resources.GetObject("tsgamma.Image")));
            this.tsgamma.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsgamma.Name = "tsgamma";
            this.tsgamma.Size = new System.Drawing.Size(23, 22);
            this.tsgamma.Tag = "&#947; ";
            this.tsgamma.Text = "γ";
            // 
            // tsbDelta
            // 
            this.tsbDelta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbDelta.Image = ((System.Drawing.Image)(resources.GetObject("tsbDelta.Image")));
            this.tsbDelta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDelta.Name = "tsbDelta";
            this.tsbDelta.Size = new System.Drawing.Size(23, 22);
            this.tsbDelta.Tag = "&#948;";
            this.tsbDelta.Text = "δ";
            // 
            // tsepsilon
            // 
            this.tsepsilon.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsepsilon.Image = ((System.Drawing.Image)(resources.GetObject("tsepsilon.Image")));
            this.tsepsilon.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsepsilon.Name = "tsepsilon";
            this.tsepsilon.Size = new System.Drawing.Size(23, 22);
            this.tsepsilon.Tag = "&#949;";
            this.tsepsilon.Text = "ε";
            // 
            // tszeta
            // 
            this.tszeta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tszeta.Image = ((System.Drawing.Image)(resources.GetObject("tszeta.Image")));
            this.tszeta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tszeta.Name = "tszeta";
            this.tszeta.Size = new System.Drawing.Size(23, 22);
            this.tszeta.Tag = "&#950";
            this.tszeta.Text = "ζ";
            // 
            // tsbLatinEta
            // 
            this.tsbLatinEta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbLatinEta.Image = ((System.Drawing.Image)(resources.GetObject("tsbLatinEta.Image")));
            this.tsbLatinEta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLatinEta.Name = "tsbLatinEta";
            this.tsbLatinEta.Size = new System.Drawing.Size(23, 22);
            this.tsbLatinEta.Tag = "&#951;";
            this.tsbLatinEta.Text = "η";
            // 
            // tsbTheta
            // 
            this.tsbTheta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbTheta.Image = ((System.Drawing.Image)(resources.GetObject("tsbTheta.Image")));
            this.tsbTheta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbTheta.Name = "tsbTheta";
            this.tsbTheta.Size = new System.Drawing.Size(23, 22);
            this.tsbTheta.Tag = "&#952;";
            this.tsbTheta.Text = "θ";
            // 
            // tsbIota
            // 
            this.tsbIota.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbIota.Image = ((System.Drawing.Image)(resources.GetObject("tsbIota.Image")));
            this.tsbIota.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbIota.Name = "tsbIota";
            this.tsbIota.Size = new System.Drawing.Size(23, 22);
            this.tsbIota.Tag = "&#953;";
            this.tsbIota.Text = "ι";
            // 
            // tsbKappa
            // 
            this.tsbKappa.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbKappa.Image = ((System.Drawing.Image)(resources.GetObject("tsbKappa.Image")));
            this.tsbKappa.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbKappa.Name = "tsbKappa";
            this.tsbKappa.Size = new System.Drawing.Size(23, 22);
            this.tsbKappa.Tag = "&#954;";
            this.tsbKappa.Text = "κ";
            // 
            // tslamda
            // 
            this.tslamda.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tslamda.Image = ((System.Drawing.Image)(resources.GetObject("tslamda.Image")));
            this.tslamda.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tslamda.Name = "tslamda";
            this.tslamda.Size = new System.Drawing.Size(23, 22);
            this.tslamda.Tag = "&#955;";
            this.tslamda.Text = "λ";
            // 
            // tsbMu
            // 
            this.tsbMu.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbMu.Image = ((System.Drawing.Image)(resources.GetObject("tsbMu.Image")));
            this.tsbMu.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbMu.Name = "tsbMu";
            this.tsbMu.Size = new System.Drawing.Size(23, 22);
            this.tsbMu.Tag = "&#956;";
            this.tsbMu.Text = "μ";
            // 
            // tsbNu
            // 
            this.tsbNu.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbNu.Image = ((System.Drawing.Image)(resources.GetObject("tsbNu.Image")));
            this.tsbNu.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbNu.Name = "tsbNu";
            this.tsbNu.Size = new System.Drawing.Size(23, 22);
            this.tsbNu.Tag = "&#957;";
            this.tsbNu.Text = "ν";
            // 
            // tsxsi
            // 
            this.tsxsi.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsxsi.Image = ((System.Drawing.Image)(resources.GetObject("tsxsi.Image")));
            this.tsxsi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsxsi.Name = "tsxsi";
            this.tsxsi.Size = new System.Drawing.Size(23, 22);
            this.tsxsi.Tag = "&#958;";
            this.tsxsi.Text = "ξ";
            // 
            // tsomricon
            // 
            this.tsomricon.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsomricon.Image = ((System.Drawing.Image)(resources.GetObject("tsomricon.Image")));
            this.tsomricon.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsomricon.Name = "tsomricon";
            this.tsomricon.Size = new System.Drawing.Size(23, 22);
            this.tsomricon.Tag = "&#959;";
            this.tsomricon.Text = "ο";
            // 
            // tsbSmallLetterPi
            // 
            this.tsbSmallLetterPi.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbSmallLetterPi.Image = ((System.Drawing.Image)(resources.GetObject("tsbSmallLetterPi.Image")));
            this.tsbSmallLetterPi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSmallLetterPi.Name = "tsbSmallLetterPi";
            this.tsbSmallLetterPi.Size = new System.Drawing.Size(23, 22);
            this.tsbSmallLetterPi.Tag = "&#960;";
            this.tsbSmallLetterPi.Text = "π";
            this.tsbSmallLetterPi.Visible = false;
            // 
            // tsbSmallLetterRho
            // 
            this.tsbSmallLetterRho.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbSmallLetterRho.Image = ((System.Drawing.Image)(resources.GetObject("tsbSmallLetterRho.Image")));
            this.tsbSmallLetterRho.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSmallLetterRho.Name = "tsbSmallLetterRho";
            this.tsbSmallLetterRho.Size = new System.Drawing.Size(23, 22);
            this.tsbSmallLetterRho.Tag = "&#961;";
            this.tsbSmallLetterRho.Text = "ρ";
            // 
            // tssigmaf
            // 
            this.tssigmaf.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tssigmaf.Image = ((System.Drawing.Image)(resources.GetObject("tssigmaf.Image")));
            this.tssigmaf.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tssigmaf.Name = "tssigmaf";
            this.tssigmaf.Size = new System.Drawing.Size(23, 22);
            this.tssigmaf.Tag = "&#962;";
            this.tssigmaf.Text = "ς";
            // 
            // tsbSigma
            // 
            this.tsbSigma.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbSigma.Image = ((System.Drawing.Image)(resources.GetObject("tsbSigma.Image")));
            this.tsbSigma.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSigma.Name = "tsbSigma";
            this.tsbSigma.Size = new System.Drawing.Size(23, 22);
            this.tsbSigma.Tag = "&#963;";
            this.tsbSigma.Text = "σ";
            // 
            // tsbTau
            // 
            this.tsbTau.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbTau.Image = ((System.Drawing.Image)(resources.GetObject("tsbTau.Image")));
            this.tsbTau.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbTau.Name = "tsbTau";
            this.tsbTau.Size = new System.Drawing.Size(23, 22);
            this.tsbTau.Tag = "&#964;";
            this.tsbTau.Text = "τ";
            // 
            // tsupsilon
            // 
            this.tsupsilon.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsupsilon.Image = ((System.Drawing.Image)(resources.GetObject("tsupsilon.Image")));
            this.tsupsilon.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsupsilon.Name = "tsupsilon";
            this.tsupsilon.Size = new System.Drawing.Size(23, 22);
            this.tsupsilon.Tag = "&#965;";
            this.tsupsilon.Text = "υ";
            // 
            // tsbPhi
            // 
            this.tsbPhi.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPhi.Image = ((System.Drawing.Image)(resources.GetObject("tsbPhi.Image")));
            this.tsbPhi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPhi.Name = "tsbPhi";
            this.tsbPhi.Size = new System.Drawing.Size(23, 22);
            this.tsbPhi.Tag = "&#966;";
            this.tsbPhi.Text = "φ";
            // 
            // tsbChi
            // 
            this.tsbChi.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbChi.Image = ((System.Drawing.Image)(resources.GetObject("tsbChi.Image")));
            this.tsbChi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbChi.Name = "tsbChi";
            this.tsbChi.Size = new System.Drawing.Size(23, 22);
            this.tsbChi.Tag = "&#967;";
            this.tsbChi.Text = "χ";
            // 
            // tsbPsi
            // 
            this.tsbPsi.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPsi.Image = ((System.Drawing.Image)(resources.GetObject("tsbPsi.Image")));
            this.tsbPsi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPsi.Name = "tsbPsi";
            this.tsbPsi.Size = new System.Drawing.Size(23, 22);
            this.tsbPsi.Tag = "&#936;";
            this.tsbPsi.Text = "ψ";
            // 
            // tsomega
            // 
            this.tsomega.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsomega.Image = ((System.Drawing.Image)(resources.GetObject("tsomega.Image")));
            this.tsomega.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsomega.Name = "tsomega";
            this.tsomega.Size = new System.Drawing.Size(23, 22);
            this.tsomega.Tag = "&#969;";
            this.tsomega.Text = "ω";
            // 
            // tsbVeritcalLine
            // 
            this.tsbVeritcalLine.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbVeritcalLine.Image = ((System.Drawing.Image)(resources.GetObject("tsbVeritcalLine.Image")));
            this.tsbVeritcalLine.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbVeritcalLine.Name = "tsbVeritcalLine";
            this.tsbVeritcalLine.Size = new System.Drawing.Size(23, 22);
            this.tsbVeritcalLine.Tag = "&#124;";
            this.tsbVeritcalLine.Text = "|";
            // 
            // ts1degree
            // 
            this.ts1degree.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ts1degree.Image = ((System.Drawing.Image)(resources.GetObject("ts1degree.Image")));
            this.ts1degree.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ts1degree.Name = "ts1degree";
            this.ts1degree.Size = new System.Drawing.Size(23, 22);
            this.ts1degree.Tag = "&#176;";
            this.ts1degree.Text = "°";
            this.ts1degree.ToolTipText = "degree";
            // 
            // tsbTilde
            // 
            this.tsbTilde.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbTilde.Image = ((System.Drawing.Image)(resources.GetObject("tsbTilde.Image")));
            this.tsbTilde.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbTilde.Name = "tsbTilde";
            this.tsbTilde.Size = new System.Drawing.Size(23, 22);
            this.tsbTilde.Tag = "&#126;";
            this.tsbTilde.Text = "~";
            // 
            // tsbYen
            // 
            this.tsbYen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbYen.Image = ((System.Drawing.Image)(resources.GetObject("tsbYen.Image")));
            this.tsbYen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbYen.Name = "tsbYen";
            this.tsbYen.Size = new System.Drawing.Size(23, 22);
            this.tsbYen.Tag = "&#165;";
            this.tsbYen.Text = "¥";
            // 
            // tsbDoubleS
            // 
            this.tsbDoubleS.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbDoubleS.Image = ((System.Drawing.Image)(resources.GetObject("tsbDoubleS.Image")));
            this.tsbDoubleS.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDoubleS.Name = "tsbDoubleS";
            this.tsbDoubleS.Size = new System.Drawing.Size(23, 22);
            this.tsbDoubleS.Tag = "&#167;";
            this.tsbDoubleS.Text = "§";
            // 
            // tsbCopyRight
            // 
            this.tsbCopyRight.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbCopyRight.Image = ((System.Drawing.Image)(resources.GetObject("tsbCopyRight.Image")));
            this.tsbCopyRight.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCopyRight.Name = "tsbCopyRight";
            this.tsbCopyRight.Size = new System.Drawing.Size(23, 22);
            this.tsbCopyRight.Tag = "&#169;";
            this.tsbCopyRight.Text = "©";
            // 
            // tsbLeftDoubleAngleQuotes
            // 
            this.tsbLeftDoubleAngleQuotes.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbLeftDoubleAngleQuotes.Image = ((System.Drawing.Image)(resources.GetObject("tsbLeftDoubleAngleQuotes.Image")));
            this.tsbLeftDoubleAngleQuotes.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLeftDoubleAngleQuotes.Name = "tsbLeftDoubleAngleQuotes";
            this.tsbLeftDoubleAngleQuotes.Size = new System.Drawing.Size(23, 22);
            this.tsbLeftDoubleAngleQuotes.Tag = "&#171;";
            this.tsbLeftDoubleAngleQuotes.Text = "«";
            // 
            // tsbRegisteredTradeMark
            // 
            this.tsbRegisteredTradeMark.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbRegisteredTradeMark.Image = ((System.Drawing.Image)(resources.GetObject("tsbRegisteredTradeMark.Image")));
            this.tsbRegisteredTradeMark.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRegisteredTradeMark.Name = "tsbRegisteredTradeMark";
            this.tsbRegisteredTradeMark.Size = new System.Drawing.Size(23, 22);
            this.tsbRegisteredTradeMark.Tag = "&#174;";
            this.tsbRegisteredTradeMark.Text = "®";
            // 
            // tsbParagraphSign
            // 
            this.tsbParagraphSign.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbParagraphSign.Image = ((System.Drawing.Image)(resources.GetObject("tsbParagraphSign.Image")));
            this.tsbParagraphSign.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbParagraphSign.Name = "tsbParagraphSign";
            this.tsbParagraphSign.Size = new System.Drawing.Size(23, 22);
            this.tsbParagraphSign.Tag = "&#182;";
            this.tsbParagraphSign.Text = "¶";
            // 
            // tsbPlusOrMinus
            // 
            this.tsbPlusOrMinus.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPlusOrMinus.Image = ((System.Drawing.Image)(resources.GetObject("tsbPlusOrMinus.Image")));
            this.tsbPlusOrMinus.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPlusOrMinus.Name = "tsbPlusOrMinus";
            this.tsbPlusOrMinus.Size = new System.Drawing.Size(23, 22);
            this.tsbPlusOrMinus.Tag = "&#177;";
            this.tsbPlusOrMinus.Text = "±";
            // 
            // tsbLatinLetterO
            // 
            this.tsbLatinLetterO.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbLatinLetterO.Image = ((System.Drawing.Image)(resources.GetObject("tsbLatinLetterO.Image")));
            this.tsbLatinLetterO.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLatinLetterO.Name = "tsbLatinLetterO";
            this.tsbLatinLetterO.Size = new System.Drawing.Size(23, 22);
            this.tsbLatinLetterO.Tag = "&#216;";
            this.tsbLatinLetterO.Text = "Ø";
            // 
            // tsbLatinLetterF
            // 
            this.tsbLatinLetterF.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbLatinLetterF.Image = ((System.Drawing.Image)(resources.GetObject("tsbLatinLetterF.Image")));
            this.tsbLatinLetterF.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLatinLetterF.Name = "tsbLatinLetterF";
            this.tsbLatinLetterF.Size = new System.Drawing.Size(23, 22);
            this.tsbLatinLetterF.Tag = "&#402;";
            this.tsbLatinLetterF.Text = "ƒ";
            // 
            // tsbDagger
            // 
            this.tsbDagger.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbDagger.Image = ((System.Drawing.Image)(resources.GetObject("tsbDagger.Image")));
            this.tsbDagger.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDagger.Name = "tsbDagger";
            this.tsbDagger.Size = new System.Drawing.Size(23, 22);
            this.tsbDagger.Tag = "&#8224;";
            this.tsbDagger.Text = "†";
            // 
            // tsbDoubleDagger
            // 
            this.tsbDoubleDagger.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbDoubleDagger.Image = ((System.Drawing.Image)(resources.GetObject("tsbDoubleDagger.Image")));
            this.tsbDoubleDagger.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDoubleDagger.Name = "tsbDoubleDagger";
            this.tsbDoubleDagger.Size = new System.Drawing.Size(23, 22);
            this.tsbDoubleDagger.Tag = "&#8225;";
            this.tsbDoubleDagger.Text = "‡";
            // 
            // tsbBullet
            // 
            this.tsbBullet.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbBullet.Image = ((System.Drawing.Image)(resources.GetObject("tsbBullet.Image")));
            this.tsbBullet.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbBullet.Name = "tsbBullet";
            this.tsbBullet.Size = new System.Drawing.Size(23, 22);
            this.tsbBullet.Tag = "&#149;";
            this.tsbBullet.Text = "•";
            // 
            // tsbCaretCircumflex
            // 
            this.tsbCaretCircumflex.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbCaretCircumflex.Image = ((System.Drawing.Image)(resources.GetObject("tsbCaretCircumflex.Image")));
            this.tsbCaretCircumflex.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCaretCircumflex.Name = "tsbCaretCircumflex";
            this.tsbCaretCircumflex.Size = new System.Drawing.Size(23, 22);
            this.tsbCaretCircumflex.Tag = "&#94;";
            this.tsbCaretCircumflex.Text = "^";
            // 
            // tsbLessThanEqual
            // 
            this.tsbLessThanEqual.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbLessThanEqual.Image = ((System.Drawing.Image)(resources.GetObject("tsbLessThanEqual.Image")));
            this.tsbLessThanEqual.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLessThanEqual.Name = "tsbLessThanEqual";
            this.tsbLessThanEqual.Size = new System.Drawing.Size(23, 22);
            this.tsbLessThanEqual.Tag = "&#8804;";
            this.tsbLessThanEqual.Text = "≤";
            // 
            // tsbGreaterThanEqual
            // 
            this.tsbGreaterThanEqual.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbGreaterThanEqual.Image = ((System.Drawing.Image)(resources.GetObject("tsbGreaterThanEqual.Image")));
            this.tsbGreaterThanEqual.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbGreaterThanEqual.Name = "tsbGreaterThanEqual";
            this.tsbGreaterThanEqual.Size = new System.Drawing.Size(23, 22);
            this.tsbGreaterThanEqual.Tag = "&#8805;";
            this.tsbGreaterThanEqual.Text = "≥";
            // 
            // tsbIntegral
            // 
            this.tsbIntegral.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbIntegral.Image = ((System.Drawing.Image)(resources.GetObject("tsbIntegral.Image")));
            this.tsbIntegral.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbIntegral.Name = "tsbIntegral";
            this.tsbIntegral.Size = new System.Drawing.Size(23, 22);
            this.tsbIntegral.Tag = "&#8747;";
            this.tsbIntegral.Text = "∫";
            // 
            // tsbNaryProduct
            // 
            this.tsbNaryProduct.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbNaryProduct.Image = ((System.Drawing.Image)(resources.GetObject("tsbNaryProduct.Image")));
            this.tsbNaryProduct.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbNaryProduct.Name = "tsbNaryProduct";
            this.tsbNaryProduct.Size = new System.Drawing.Size(23, 22);
            this.tsbNaryProduct.Tag = "&#8719;";
            this.tsbNaryProduct.Text = "∏";
            // 
            // tsbSummation
            // 
            this.tsbSummation.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbSummation.Image = ((System.Drawing.Image)(resources.GetObject("tsbSummation.Image")));
            this.tsbSummation.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSummation.Name = "tsbSummation";
            this.tsbSummation.Size = new System.Drawing.Size(23, 22);
            this.tsbSummation.Tag = "&#8721;";
            this.tsbSummation.Text = "∑";
            // 
            // tsbLatinSmallf
            // 
            this.tsbLatinSmallf.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbLatinSmallf.Image = ((System.Drawing.Image)(resources.GetObject("tsbLatinSmallf.Image")));
            this.tsbLatinSmallf.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLatinSmallf.Name = "tsbLatinSmallf";
            this.tsbLatinSmallf.Size = new System.Drawing.Size(23, 22);
            this.tsbLatinSmallf.Tag = "&#131;";
            this.tsbLatinSmallf.Text = "ƒ";
            // 
            // tsbIncrement
            // 
            this.tsbIncrement.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbIncrement.Image = ((System.Drawing.Image)(resources.GetObject("tsbIncrement.Image")));
            this.tsbIncrement.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbIncrement.Name = "tsbIncrement";
            this.tsbIncrement.Size = new System.Drawing.Size(23, 22);
            this.tsbIncrement.Tag = "&#8710;";
            this.tsbIncrement.Text = "∆";
            // 
            // tsbAwithRing
            // 
            this.tsbAwithRing.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbAwithRing.Image = ((System.Drawing.Image)(resources.GetObject("tsbAwithRing.Image")));
            this.tsbAwithRing.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAwithRing.Name = "tsbAwithRing";
            this.tsbAwithRing.Size = new System.Drawing.Size(23, 19);
            this.tsbAwithRing.Tag = "&#197; ";
            this.tsbAwithRing.Text = "Å";
            // 
            // tsbOwithStoke
            // 
            this.tsbOwithStoke.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbOwithStoke.Image = ((System.Drawing.Image)(resources.GetObject("tsbOwithStoke.Image")));
            this.tsbOwithStoke.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbOwithStoke.Name = "tsbOwithStoke";
            this.tsbOwithStoke.Size = new System.Drawing.Size(23, 19);
            this.tsbOwithStoke.Tag = "&#248;";
            this.tsbOwithStoke.Text = "ø";
            // 
            // ts1triplebond
            // 
            this.ts1triplebond.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ts1triplebond.Font = new System.Drawing.Font("Symbol", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.ts1triplebond.Image = ((System.Drawing.Image)(resources.GetObject("ts1triplebond.Image")));
            this.ts1triplebond.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ts1triplebond.Name = "ts1triplebond";
            this.ts1triplebond.Size = new System.Drawing.Size(23, 4);
            this.ts1triplebond.Tag = "&#8801;";
            this.ts1triplebond.ToolTipText = "Triple Bond";
            // 
            // tsbAwithCircumflex
            // 
            this.tsbAwithCircumflex.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbAwithCircumflex.Image = ((System.Drawing.Image)(resources.GetObject("tsbAwithCircumflex.Image")));
            this.tsbAwithCircumflex.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAwithCircumflex.Name = "tsbAwithCircumflex";
            this.tsbAwithCircumflex.Size = new System.Drawing.Size(23, 19);
            this.tsbAwithCircumflex.Tag = "&#226;";
            this.tsbAwithCircumflex.Text = "â";
            // 
            // tsbOmega
            // 
            this.tsbOmega.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbOmega.Image = ((System.Drawing.Image)(resources.GetObject("tsbOmega.Image")));
            this.tsbOmega.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbOmega.Name = "tsbOmega";
            this.tsbOmega.Size = new System.Drawing.Size(23, 19);
            this.tsbOmega.Tag = "&#937;";
            this.tsbOmega.Text = "Ω";
            // 
            // tsbDiaeresis
            // 
            this.tsbDiaeresis.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbDiaeresis.Image = ((System.Drawing.Image)(resources.GetObject("tsbDiaeresis.Image")));
            this.tsbDiaeresis.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDiaeresis.Name = "tsbDiaeresis";
            this.tsbDiaeresis.Size = new System.Drawing.Size(23, 19);
            this.tsbDiaeresis.Tag = "&#228;";
            this.tsbDiaeresis.Text = "ä";
            // 
            // tsbUwithDiaeresis
            // 
            this.tsbUwithDiaeresis.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbUwithDiaeresis.Image = ((System.Drawing.Image)(resources.GetObject("tsbUwithDiaeresis.Image")));
            this.tsbUwithDiaeresis.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbUwithDiaeresis.Name = "tsbUwithDiaeresis";
            this.tsbUwithDiaeresis.Size = new System.Drawing.Size(23, 19);
            this.tsbUwithDiaeresis.Tag = "&#252;";
            this.tsbUwithDiaeresis.Text = "ü";
            // 
            // tsbPi
            // 
            this.tsbPi.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPi.Image = ((System.Drawing.Image)(resources.GetObject("tsbPi.Image")));
            this.tsbPi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPi.Name = "tsbPi";
            this.tsbPi.Size = new System.Drawing.Size(23, 19);
            this.tsbPi.Text = "π";
            this.tsbPi.ToolTipText = "Lowercase Pi";
            // 
            // tsbGreekV
            // 
            this.tsbGreekV.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbGreekV.Image = ((System.Drawing.Image)(resources.GetObject("tsbGreekV.Image")));
            this.tsbGreekV.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbGreekV.Name = "tsbGreekV";
            this.tsbGreekV.Size = new System.Drawing.Size(23, 20);
            this.tsbGreekV.Tag = "&#x03BD;&#x0303;";
            this.tsbGreekV.Text = "ν̃";
            // 
            // toolStripButton20
            // 
            this.toolStripButton20.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton20.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton20.Image")));
            this.toolStripButton20.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton20.Name = "toolStripButton20";
            this.toolStripButton20.Size = new System.Drawing.Size(23, 20);
            this.toolStripButton20.Tag = "&#x2245;";
            // 
            // toolStripButton21
            // 
            this.toolStripButton21.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton21.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton21.Image")));
            this.toolStripButton21.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton21.Name = "toolStripButton21";
            this.toolStripButton21.Size = new System.Drawing.Size(23, 4);
            this.toolStripButton21.Tag = "&#xFFFD;";
            // 
            // tsbAlmostEqualTo
            // 
            this.tsbAlmostEqualTo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbAlmostEqualTo.Image = ((System.Drawing.Image)(resources.GetObject("tsbAlmostEqualTo.Image")));
            this.tsbAlmostEqualTo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAlmostEqualTo.Name = "tsbAlmostEqualTo";
            this.tsbAlmostEqualTo.Size = new System.Drawing.Size(23, 19);
            this.tsbAlmostEqualTo.Tag = "&#x2248;";
            this.tsbAlmostEqualTo.Text = "≈";
            // 
            // toolStripButton23
            // 
            this.toolStripButton23.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton23.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton23.Image")));
            this.toolStripButton23.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton23.Name = "toolStripButton23";
            this.toolStripButton23.Size = new System.Drawing.Size(23, 4);
            this.toolStripButton23.Tag = "&#xFFFD;";
            // 
            // tsFontStyleCntrls
            // 
            this.tsFontStyleCntrls.BackColor = System.Drawing.Color.White;
            this.tsFontStyleCntrls.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ts1findandreplace,
            this.tspFndReplaceBold,
            this.tsbold,
            this.tsundeline,
            this.tsitalic,
            this.tsstrikeout,
            this.tsRegular,
            this.tspRegularSuperScript,
            this.tssuperscript,
            this.tsfont,
            this.tssubscript,
            this.tspSubScriptUndo,
            this.tsUndo,
            this.tsredo,
            this.tspRedoAddRxn,
            this.tsAddreaction,
            this.tsconvformula,
            this.tspFormulaHidden,
            this.tsbhidden});
            this.tsFontStyleCntrls.Location = new System.Drawing.Point(0, 0);
            this.tsFontStyleCntrls.Name = "tsFontStyleCntrls";
            this.tsFontStyleCntrls.Size = new System.Drawing.Size(1120, 25);
            this.tsFontStyleCntrls.TabIndex = 40;
            this.tsFontStyleCntrls.Tag = "XC";
            // 
            // ts1findandreplace
            // 
            this.ts1findandreplace.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ts1findandreplace.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ts1findandreplace.Image = ((System.Drawing.Image)(resources.GetObject("ts1findandreplace.Image")));
            this.ts1findandreplace.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ts1findandreplace.Name = "ts1findandreplace";
            this.ts1findandreplace.Size = new System.Drawing.Size(89, 22);
            this.ts1findandreplace.Text = "Find and &Replace";
            this.ts1findandreplace.Click += new System.EventHandler(this.ts1findandreplace_Click);
            // 
            // tspFndReplaceBold
            // 
            this.tspFndReplaceBold.Name = "tspFndReplaceBold";
            this.tspFndReplaceBold.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbold
            // 
            this.tsbold.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbold.Image = ((System.Drawing.Image)(resources.GetObject("tsbold.Image")));
            this.tsbold.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbold.Name = "tsbold";
            this.tsbold.Size = new System.Drawing.Size(23, 22);
            this.tsbold.Text = "Bold";
            this.tsbold.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // tsundeline
            // 
            this.tsundeline.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsundeline.Image = ((System.Drawing.Image)(resources.GetObject("tsundeline.Image")));
            this.tsundeline.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsundeline.Name = "tsundeline";
            this.tsundeline.Size = new System.Drawing.Size(23, 22);
            this.tsundeline.Text = "Underline";
            this.tsundeline.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // tsitalic
            // 
            this.tsitalic.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsitalic.Image = ((System.Drawing.Image)(resources.GetObject("tsitalic.Image")));
            this.tsitalic.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsitalic.Name = "tsitalic";
            this.tsitalic.Size = new System.Drawing.Size(23, 22);
            this.tsitalic.Text = "italic";
            this.tsitalic.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // tsstrikeout
            // 
            this.tsstrikeout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsstrikeout.Image = ((System.Drawing.Image)(resources.GetObject("tsstrikeout.Image")));
            this.tsstrikeout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsstrikeout.Name = "tsstrikeout";
            this.tsstrikeout.Size = new System.Drawing.Size(23, 22);
            this.tsstrikeout.Text = "StrikeOut";
            this.tsstrikeout.Visible = false;
            // 
            // tsRegular
            // 
            this.tsRegular.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsRegular.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsRegular.Image = ((System.Drawing.Image)(resources.GetObject("tsRegular.Image")));
            this.tsRegular.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsRegular.Name = "tsRegular";
            this.tsRegular.Size = new System.Drawing.Size(23, 22);
            this.tsRegular.Text = "R";
            this.tsRegular.ToolTipText = "Regular";
            this.tsRegular.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // tspRegularSuperScript
            // 
            this.tspRegularSuperScript.Name = "tspRegularSuperScript";
            this.tspRegularSuperScript.Size = new System.Drawing.Size(6, 25);
            this.tspRegularSuperScript.Visible = false;
            // 
            // tssuperscript
            // 
            this.tssuperscript.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tssuperscript.Image = ((System.Drawing.Image)(resources.GetObject("tssuperscript.Image")));
            this.tssuperscript.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tssuperscript.Name = "tssuperscript";
            this.tssuperscript.Size = new System.Drawing.Size(23, 22);
            this.tssuperscript.Text = "Superscript";
            this.tssuperscript.Click += new System.EventHandler(this.toolStripButton7_Click);
            // 
            // tsfont
            // 
            this.tsfont.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsfont.Image = ((System.Drawing.Image)(resources.GetObject("tsfont.Image")));
            this.tsfont.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsfont.Name = "tsfont";
            this.tsfont.Size = new System.Drawing.Size(23, 22);
            this.tsfont.Text = "toolStripButton1";
            this.tsfont.Click += new System.EventHandler(this.toolStripButton9_Click);
            // 
            // tssubscript
            // 
            this.tssubscript.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tssubscript.Image = ((System.Drawing.Image)(resources.GetObject("tssubscript.Image")));
            this.tssubscript.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tssubscript.Name = "tssubscript";
            this.tssubscript.Size = new System.Drawing.Size(23, 22);
            this.tssubscript.Text = "Subscript";
            this.tssubscript.Click += new System.EventHandler(this.toolStripButton8_Click);
            // 
            // tspSubScriptUndo
            // 
            this.tspSubScriptUndo.Name = "tspSubScriptUndo";
            this.tspSubScriptUndo.Size = new System.Drawing.Size(6, 25);
            this.tspSubScriptUndo.Visible = false;
            // 
            // tsUndo
            // 
            this.tsUndo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsUndo.Image = ((System.Drawing.Image)(resources.GetObject("tsUndo.Image")));
            this.tsUndo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsUndo.Name = "tsUndo";
            this.tsUndo.Size = new System.Drawing.Size(23, 22);
            this.tsUndo.Text = "Undo";
            this.tsUndo.Click += new System.EventHandler(this.tsUndo_Click);
            // 
            // tsredo
            // 
            this.tsredo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsredo.Image = ((System.Drawing.Image)(resources.GetObject("tsredo.Image")));
            this.tsredo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsredo.Name = "tsredo";
            this.tsredo.Size = new System.Drawing.Size(23, 22);
            this.tsredo.Text = "Redo";
            this.tsredo.Click += new System.EventHandler(this.tsredo_Click);
            // 
            // tspRedoAddRxn
            // 
            this.tspRedoAddRxn.Name = "tspRedoAddRxn";
            this.tspRedoAddRxn.Size = new System.Drawing.Size(6, 25);
            // 
            // tsAddreaction
            // 
            this.tsAddreaction.Enabled = false;
            this.tsAddreaction.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsAddreaction.Image = ((System.Drawing.Image)(resources.GetObject("tsAddreaction.Image")));
            this.tsAddreaction.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsAddreaction.Name = "tsAddreaction";
            this.tsAddreaction.Size = new System.Drawing.Size(88, 22);
            this.tsAddreaction.Text = "Add Reaction";
            // 
            // tsconvformula
            // 
            this.tsconvformula.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsconvformula.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsconvformula.Image = ((System.Drawing.Image)(resources.GetObject("tsconvformula.Image")));
            this.tsconvformula.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsconvformula.Name = "tsconvformula";
            this.tsconvformula.Size = new System.Drawing.Size(73, 22);
            this.tsconvformula.Text = "ConvFormula";
            this.tsconvformula.Click += new System.EventHandler(this.tsconvformula_Click);
            // 
            // tspFormulaHidden
            // 
            this.tspFormulaHidden.Name = "tspFormulaHidden";
            this.tspFormulaHidden.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbhidden
            // 
            this.tsbhidden.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbhidden.Image = ((System.Drawing.Image)(resources.GetObject("tsbhidden.Image")));
            this.tsbhidden.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbhidden.Name = "tsbhidden";
            this.tsbhidden.Size = new System.Drawing.Size(23, 22);
            this.tsbhidden.Text = "btnhidden";
            this.tsbhidden.Visible = false;
            // 
            // tpCoOrdinates
            // 
            this.tpCoOrdinates.Controls.Add(this.pnlCoOrdinateCntls);
            this.tpCoOrdinates.Controls.Add(this.dgviewer);
            this.tpCoOrdinates.Location = new System.Drawing.Point(4, 24);
            this.tpCoOrdinates.Name = "tpCoOrdinates";
            this.tpCoOrdinates.Size = new System.Drawing.Size(1128, 647);
            this.tpCoOrdinates.TabIndex = 1;
            this.tpCoOrdinates.Text = "PDF Co-ordinates";
            this.tpCoOrdinates.UseVisualStyleBackColor = true;
            // 
            // pnlCoOrdinateCntls
            // 
            this.pnlCoOrdinateCntls.BackColor = System.Drawing.Color.LightGray;
            this.pnlCoOrdinateCntls.Controls.Add(this.btnbrowsecood);
            this.pnlCoOrdinateCntls.Controls.Add(this.txtbrowsecoordinates);
            this.pnlCoOrdinateCntls.Controls.Add(this.txtcpage);
            this.pnlCoOrdinateCntls.Controls.Add(this.btnPageSize);
            this.pnlCoOrdinateCntls.Controls.Add(this.btnZoomOnArea);
            this.pnlCoOrdinateCntls.Controls.Add(this.btnZoomFit);
            this.pnlCoOrdinateCntls.Controls.Add(this.btnZoom100);
            this.pnlCoOrdinateCntls.Controls.Add(this.btZoomOut);
            this.pnlCoOrdinateCntls.Controls.Add(this.btZoomIn);
            this.pnlCoOrdinateCntls.Controls.Add(this.txtZoom);
            this.pnlCoOrdinateCntls.Controls.Add(this.btNextPage);
            this.pnlCoOrdinateCntls.Controls.Add(this.btlastpage);
            this.pnlCoOrdinateCntls.Controls.Add(this.btPreviousPage);
            this.pnlCoOrdinateCntls.Controls.Add(this.btFirstpage);
            this.pnlCoOrdinateCntls.Controls.Add(this.lbPos);
            this.pnlCoOrdinateCntls.Controls.Add(this.lblxy);
            this.pnlCoOrdinateCntls.Controls.Add(this.lbPage);
            this.pnlCoOrdinateCntls.Controls.Add(this.lblPdfPath);
            this.pnlCoOrdinateCntls.Controls.Add(this.btnZoomWidth);
            this.pnlCoOrdinateCntls.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlCoOrdinateCntls.Location = new System.Drawing.Point(0, 557);
            this.pnlCoOrdinateCntls.Name = "pnlCoOrdinateCntls";
            this.pnlCoOrdinateCntls.Size = new System.Drawing.Size(1128, 90);
            this.pnlCoOrdinateCntls.TabIndex = 35;
            // 
            // btnbrowsecood
            // 
            this.btnbrowsecood.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnbrowsecood.BackColor = System.Drawing.SystemColors.Control;
            this.btnbrowsecood.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnbrowsecood.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbrowsecood.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnbrowsecood.Location = new System.Drawing.Point(1064, 33);
            this.btnbrowsecood.Name = "btnbrowsecood";
            this.btnbrowsecood.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnbrowsecood.Size = new System.Drawing.Size(58, 21);
            this.btnbrowsecood.TabIndex = 40;
            this.btnbrowsecood.Text = "...";
            this.btnbrowsecood.UseVisualStyleBackColor = false;
            // 
            // txtbrowsecoordinates
            // 
            this.txtbrowsecoordinates.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbrowsecoordinates.Location = new System.Drawing.Point(463, 34);
            this.txtbrowsecoordinates.Name = "txtbrowsecoordinates";
            this.txtbrowsecoordinates.Size = new System.Drawing.Size(599, 21);
            this.txtbrowsecoordinates.TabIndex = 39;
            // 
            // txtcpage
            // 
            this.txtcpage.Location = new System.Drawing.Point(63, 4);
            this.txtcpage.Name = "txtcpage";
            this.txtcpage.Size = new System.Drawing.Size(40, 21);
            this.txtcpage.TabIndex = 36;
            // 
            // btnPageSize
            // 
            this.btnPageSize.BackColor = System.Drawing.SystemColors.Control;
            this.btnPageSize.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnPageSize.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnPageSize.Location = new System.Drawing.Point(256, 54);
            this.btnPageSize.Name = "btnPageSize";
            this.btnPageSize.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnPageSize.Size = new System.Drawing.Size(88, 21);
            this.btnPageSize.TabIndex = 35;
            this.btnPageSize.Text = "Page Size";
            this.btnPageSize.UseVisualStyleBackColor = false;
            // 
            // btnZoomOnArea
            // 
            this.btnZoomOnArea.BackColor = System.Drawing.SystemColors.Control;
            this.btnZoomOnArea.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnZoomOnArea.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnZoomOnArea.Location = new System.Drawing.Point(220, 30);
            this.btnZoomOnArea.Name = "btnZoomOnArea";
            this.btnZoomOnArea.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnZoomOnArea.Size = new System.Drawing.Size(82, 22);
            this.btnZoomOnArea.TabIndex = 32;
            this.btnZoomOnArea.Text = "Zoom on Area";
            this.btnZoomOnArea.UseVisualStyleBackColor = false;
            // 
            // btnZoomFit
            // 
            this.btnZoomFit.BackColor = System.Drawing.SystemColors.Control;
            this.btnZoomFit.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnZoomFit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnZoomFit.Location = new System.Drawing.Point(220, 7);
            this.btnZoomFit.Name = "btnZoomFit";
            this.btnZoomFit.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnZoomFit.Size = new System.Drawing.Size(82, 22);
            this.btnZoomFit.TabIndex = 31;
            this.btnZoomFit.Text = "Zoom Fit";
            this.btnZoomFit.UseVisualStyleBackColor = false;
            // 
            // btnZoom100
            // 
            this.btnZoom100.BackColor = System.Drawing.SystemColors.Control;
            this.btnZoom100.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnZoom100.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnZoom100.Location = new System.Drawing.Point(302, 30);
            this.btnZoom100.Name = "btnZoom100";
            this.btnZoom100.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnZoom100.Size = new System.Drawing.Size(88, 23);
            this.btnZoom100.TabIndex = 30;
            this.btnZoom100.Text = "Zoom 100%";
            this.btnZoom100.UseVisualStyleBackColor = false;
            // 
            // btZoomOut
            // 
            this.btZoomOut.BackColor = System.Drawing.SystemColors.Control;
            this.btZoomOut.Cursor = System.Windows.Forms.Cursors.Default;
            this.btZoomOut.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btZoomOut.Location = new System.Drawing.Point(40, 27);
            this.btZoomOut.Name = "btZoomOut";
            this.btZoomOut.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btZoomOut.Size = new System.Drawing.Size(20, 19);
            this.btZoomOut.TabIndex = 25;
            this.btZoomOut.Text = "-";
            this.btZoomOut.UseVisualStyleBackColor = false;
            // 
            // btZoomIn
            // 
            this.btZoomIn.BackColor = System.Drawing.SystemColors.Control;
            this.btZoomIn.Cursor = System.Windows.Forms.Cursors.Default;
            this.btZoomIn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btZoomIn.Location = new System.Drawing.Point(106, 27);
            this.btZoomIn.Name = "btZoomIn";
            this.btZoomIn.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btZoomIn.Size = new System.Drawing.Size(20, 19);
            this.btZoomIn.TabIndex = 24;
            this.btZoomIn.Text = "+";
            this.btZoomIn.UseVisualStyleBackColor = false;
            // 
            // txtZoom
            // 
            this.txtZoom.AcceptsReturn = true;
            this.txtZoom.BackColor = System.Drawing.SystemColors.Window;
            this.txtZoom.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtZoom.Enabled = false;
            this.txtZoom.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtZoom.Location = new System.Drawing.Point(62, 27);
            this.txtZoom.MaxLength = 0;
            this.txtZoom.Name = "txtZoom";
            this.txtZoom.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtZoom.Size = new System.Drawing.Size(40, 21);
            this.txtZoom.TabIndex = 23;
            this.txtZoom.Text = "100";
            // 
            // btNextPage
            // 
            this.btNextPage.BackColor = System.Drawing.SystemColors.Control;
            this.btNextPage.Cursor = System.Windows.Forms.Cursors.Default;
            this.btNextPage.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btNextPage.Location = new System.Drawing.Point(102, 2);
            this.btNextPage.Name = "btNextPage";
            this.btNextPage.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btNextPage.Size = new System.Drawing.Size(29, 24);
            this.btNextPage.TabIndex = 21;
            this.btNextPage.Text = ">";
            this.btNextPage.UseVisualStyleBackColor = false;
            // 
            // btlastpage
            // 
            this.btlastpage.BackColor = System.Drawing.SystemColors.Control;
            this.btlastpage.Cursor = System.Windows.Forms.Cursors.Default;
            this.btlastpage.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btlastpage.Location = new System.Drawing.Point(130, 2);
            this.btlastpage.Name = "btlastpage";
            this.btlastpage.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btlastpage.Size = new System.Drawing.Size(29, 24);
            this.btlastpage.TabIndex = 19;
            this.btlastpage.Text = ">>";
            this.btlastpage.UseVisualStyleBackColor = false;
            // 
            // btPreviousPage
            // 
            this.btPreviousPage.BackColor = System.Drawing.SystemColors.Control;
            this.btPreviousPage.Cursor = System.Windows.Forms.Cursors.Default;
            this.btPreviousPage.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btPreviousPage.Location = new System.Drawing.Point(34, 1);
            this.btPreviousPage.Name = "btPreviousPage";
            this.btPreviousPage.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btPreviousPage.Size = new System.Drawing.Size(29, 24);
            this.btPreviousPage.TabIndex = 22;
            this.btPreviousPage.Text = "<";
            this.btPreviousPage.UseVisualStyleBackColor = false;
            // 
            // btFirstpage
            // 
            this.btFirstpage.BackColor = System.Drawing.SystemColors.Control;
            this.btFirstpage.Cursor = System.Windows.Forms.Cursors.Default;
            this.btFirstpage.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btFirstpage.Location = new System.Drawing.Point(5, 1);
            this.btFirstpage.Name = "btFirstpage";
            this.btFirstpage.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btFirstpage.Size = new System.Drawing.Size(29, 24);
            this.btFirstpage.TabIndex = 20;
            this.btFirstpage.Text = "<<";
            this.btFirstpage.UseVisualStyleBackColor = false;
            // 
            // lbPos
            // 
            this.lbPos.AutoSize = true;
            this.lbPos.BackColor = System.Drawing.Color.Transparent;
            this.lbPos.Cursor = System.Windows.Forms.Cursors.Default;
            this.lbPos.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbPos.Location = new System.Drawing.Point(37, 56);
            this.lbPos.Name = "lbPos";
            this.lbPos.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbPos.Size = new System.Drawing.Size(32, 15);
            this.lbPos.TabIndex = 28;
            this.lbPos.Text = "(0,0)";
            this.lbPos.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblxy
            // 
            this.lblxy.AutoSize = true;
            this.lblxy.BackColor = System.Drawing.Color.Transparent;
            this.lblxy.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblxy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblxy.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblxy.Location = new System.Drawing.Point(7, 56);
            this.lblxy.Name = "lblxy";
            this.lblxy.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblxy.Size = new System.Drawing.Size(27, 13);
            this.lblxy.TabIndex = 27;
            this.lblxy.Text = "X,Y";
            // 
            // lbPage
            // 
            this.lbPage.AutoSize = true;
            this.lbPage.BackColor = System.Drawing.Color.Transparent;
            this.lbPage.Cursor = System.Windows.Forms.Cursors.Default;
            this.lbPage.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbPage.Location = new System.Drawing.Point(73, 57);
            this.lbPage.Name = "lbPage";
            this.lbPage.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbPage.Size = new System.Drawing.Size(24, 15);
            this.lbPage.TabIndex = 26;
            this.lbPage.Text = "0/0";
            this.lbPage.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lbPage.Visible = false;
            // 
            // lblPdfPath
            // 
            this.lblPdfPath.AutoSize = true;
            this.lblPdfPath.Location = new System.Drawing.Point(416, 37);
            this.lblPdfPath.Name = "lblPdfPath";
            this.lblPdfPath.Size = new System.Drawing.Size(38, 15);
            this.lblPdfPath.TabIndex = 41;
            this.lblPdfPath.Text = "Path :";
            // 
            // btnZoomWidth
            // 
            this.btnZoomWidth.BackColor = System.Drawing.SystemColors.Control;
            this.btnZoomWidth.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnZoomWidth.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnZoomWidth.Location = new System.Drawing.Point(302, 5);
            this.btnZoomWidth.Name = "btnZoomWidth";
            this.btnZoomWidth.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnZoomWidth.Size = new System.Drawing.Size(88, 22);
            this.btnZoomWidth.TabIndex = 29;
            this.btnZoomWidth.Text = "Zoom Width";
            this.btnZoomWidth.UseVisualStyleBackColor = false;
            // 
            // dgviewer
            // 
            this.dgviewer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgviewer.Enabled = true;
            this.dgviewer.Location = new System.Drawing.Point(0, 0);
            this.dgviewer.Name = "dgviewer";
            this.dgviewer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("dgviewer.OcxState")));
            this.dgviewer.Size = new System.Drawing.Size(1128, 647);
            this.dgviewer.TabIndex = 36;
            this.dgviewer.Tag = "XC";
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "texteditor.png");
            this.imageList1.Images.SetKeyName(1, "html.png");
            this.imageList1.Images.SetKeyName(2, "pdf.png");
            this.imageList1.Images.SetKeyName(3, "");
            // 
            // pnlTANDtls
            // 
            this.pnlTANDtls.BackColor = System.Drawing.Color.White;
            this.pnlTANDtls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTANDtls.Controls.Add(this.txtTANType);
            this.pnlTANDtls.Controls.Add(this.lblTANType);
            this.pnlTANDtls.Controls.Add(this.txtDOI);
            this.pnlTANDtls.Controls.Add(this.txtCAN);
            this.pnlTANDtls.Controls.Add(this.lblTan);
            this.pnlTANDtls.Controls.Add(this.txtTAN);
            this.pnlTANDtls.Controls.Add(this.lblCan);
            this.pnlTANDtls.Controls.Add(this.lblDOI);
            this.pnlTANDtls.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTANDtls.Location = new System.Drawing.Point(0, 0);
            this.pnlTANDtls.Name = "pnlTANDtls";
            this.pnlTANDtls.Size = new System.Drawing.Size(1136, 32);
            this.pnlTANDtls.TabIndex = 44;
            // 
            // txtTANType
            // 
            this.txtTANType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.txtTANType.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTANType.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtTANType.Location = new System.Drawing.Point(411, 4);
            this.txtTANType.Name = "txtTANType";
            this.txtTANType.ReadOnly = true;
            this.txtTANType.Size = new System.Drawing.Size(131, 22);
            this.txtTANType.TabIndex = 5;
            // 
            // lblTANType
            // 
            this.lblTANType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTANType.AutoSize = true;
            this.lblTANType.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTANType.ForeColor = System.Drawing.Color.Blue;
            this.lblTANType.Location = new System.Drawing.Point(351, 7);
            this.lblTANType.Name = "lblTANType";
            this.lblTANType.Size = new System.Drawing.Size(58, 15);
            this.lblTANType.TabIndex = 4;
            this.lblTANType.Text = "TAN Type";
            // 
            // txtDOI
            // 
            this.txtDOI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.txtDOI.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDOI.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtDOI.Location = new System.Drawing.Point(584, 4);
            this.txtDOI.Name = "txtDOI";
            this.txtDOI.Size = new System.Drawing.Size(231, 22);
            this.txtDOI.TabIndex = 3;
            this.txtDOI.Visible = false;
            // 
            // txtCAN
            // 
            this.txtCAN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.txtCAN.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCAN.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtCAN.Location = new System.Drawing.Point(210, 4);
            this.txtCAN.Name = "txtCAN";
            this.txtCAN.ReadOnly = true;
            this.txtCAN.Size = new System.Drawing.Size(131, 22);
            this.txtCAN.TabIndex = 2;
            // 
            // lblTan
            // 
            this.lblTan.AutoSize = true;
            this.lblTan.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTan.ForeColor = System.Drawing.Color.Blue;
            this.lblTan.Location = new System.Drawing.Point(7, 8);
            this.lblTan.Name = "lblTan";
            this.lblTan.Size = new System.Drawing.Size(29, 15);
            this.lblTan.TabIndex = 1;
            this.lblTan.Text = "TAN";
            // 
            // txtTAN
            // 
            this.txtTAN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.txtTAN.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTAN.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtTAN.Location = new System.Drawing.Point(42, 4);
            this.txtTAN.Name = "txtTAN";
            this.txtTAN.ReadOnly = true;
            this.txtTAN.Size = new System.Drawing.Size(125, 22);
            this.txtTAN.TabIndex = 1;
            this.txtTAN.Leave += new System.EventHandler(this.txttan_Leave);
            // 
            // lblCan
            // 
            this.lblCan.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCan.AutoSize = true;
            this.lblCan.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCan.ForeColor = System.Drawing.Color.Blue;
            this.lblCan.Location = new System.Drawing.Point(175, 7);
            this.lblCan.Name = "lblCan";
            this.lblCan.Size = new System.Drawing.Size(31, 15);
            this.lblCan.TabIndex = 2;
            this.lblCan.Text = "CAN";
            // 
            // lblDOI
            // 
            this.lblDOI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDOI.AutoSize = true;
            this.lblDOI.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDOI.ForeColor = System.Drawing.Color.Blue;
            this.lblDOI.Location = new System.Drawing.Point(553, 7);
            this.lblDOI.Name = "lblDOI";
            this.lblDOI.Size = new System.Drawing.Size(27, 15);
            this.lblDOI.TabIndex = 3;
            this.lblDOI.Text = "DOI";
            // 
            // ofd
            // 
            this.ofd.FileName = "openFileDialog1";
            // 
            // miniToolStrip
            // 
            this.miniToolStrip.AutoSize = false;
            this.miniToolStrip.BackColor = System.Drawing.SystemColors.Control;
            this.miniToolStrip.CanOverflow = false;
            this.miniToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.miniToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.miniToolStrip.Location = new System.Drawing.Point(548, 3);
            this.miniToolStrip.Name = "miniToolStrip";
            this.miniToolStrip.Size = new System.Drawing.Size(800, 25);
            this.miniToolStrip.TabIndex = 40;
            this.miniToolStrip.Tag = "XC";
            // 
            // chkwordwrap
            // 
            this.chkwordwrap.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.chkwordwrap.AutoSize = true;
            this.chkwordwrap.Location = new System.Drawing.Point(73, 8);
            this.chkwordwrap.Name = "chkwordwrap";
            this.chkwordwrap.Size = new System.Drawing.Size(75, 17);
            this.chkwordwrap.TabIndex = 5;
            this.chkwordwrap.Text = "Wordwrap";
            this.chkwordwrap.UseVisualStyleBackColor = true;
            this.chkwordwrap.CheckedChanged += new System.EventHandler(this.chkwordwrap_CheckedChanged);
            // 
            // lblScrollbars
            // 
            this.lblScrollbars.AutoSize = true;
            this.lblScrollbars.Location = new System.Drawing.Point(153, 9);
            this.lblScrollbars.Name = "lblScrollbars";
            this.lblScrollbars.Size = new System.Drawing.Size(54, 13);
            this.lblScrollbars.TabIndex = 6;
            // 
            // cmb1scrollbars
            // 
            this.cmb1scrollbars.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb1scrollbars.FormattingEnabled = true;
            this.cmb1scrollbars.Location = new System.Drawing.Point(213, 5);
            this.cmb1scrollbars.Name = "cmb1scrollbars";
            this.cmb1scrollbars.Size = new System.Drawing.Size(121, 21);
            this.cmb1scrollbars.TabIndex = 7;
            this.cmb1scrollbars.SelectedIndexChanged += new System.EventHandler(this.cmb1scrollbars_SelectedIndexChanged);
            // 
            // btntb1filepathpdf3
            // 
            this.btntb1filepathpdf3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btntb1filepathpdf3.Location = new System.Drawing.Point(615, 9);
            this.btntb1filepathpdf3.Name = "btntb1filepathpdf3";
            this.btntb1filepathpdf3.Size = new System.Drawing.Size(50, 23);
            this.btntb1filepathpdf3.TabIndex = 6;
            this.btntb1filepathpdf3.Text = "...";
            this.btntb1filepathpdf3.UseVisualStyleBackColor = true;
            // 
            // txttb1filepathdoc1
            // 
            this.txttb1filepathdoc1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txttb1filepathdoc1.Location = new System.Drawing.Point(44, 11);
            this.txttb1filepathdoc1.Name = "txttb1filepathdoc1";
            this.txttb1filepathdoc1.Size = new System.Drawing.Size(535, 20);
            this.txttb1filepathdoc1.TabIndex = 4;
            // 
            // tsbIncFontSize
            // 
            this.tsbIncFontSize.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbIncFontSize.Image = ((System.Drawing.Image)(resources.GetObject("tsbIncFontSize.Image")));
            this.tsbIncFontSize.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbIncFontSize.Name = "tsbIncFontSize";
            this.tsbIncFontSize.Size = new System.Drawing.Size(23, 22);
            this.tsbIncFontSize.Text = "Increase Font Size";
            this.tsbIncFontSize.Visible = false;
            // 
            // toolStripButton83
            // 
            this.toolStripButton83.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton83.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton83.Image")));
            this.toolStripButton83.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton83.Name = "toolStripButton83";
            this.toolStripButton83.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton83.Text = "toolStripButton83";
            this.toolStripButton83.Visible = false;
            // 
            // tsbSuperScript
            // 
            this.tsbSuperScript.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSuperScript.Image = ((System.Drawing.Image)(resources.GetObject("tsbSuperScript.Image")));
            this.tsbSuperScript.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSuperScript.Name = "tsbSuperScript";
            this.tsbSuperScript.Size = new System.Drawing.Size(23, 22);
            this.tsbSuperScript.Text = "Superscript";
            this.tsbSuperScript.Click += new System.EventHandler(this.toolStripButton7_Click);
            // 
            // tsbSubScript
            // 
            this.tsbSubScript.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSubScript.Image = ((System.Drawing.Image)(resources.GetObject("tsbSubScript.Image")));
            this.tsbSubScript.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSubScript.Name = "tsbSubScript";
            this.tsbSubScript.Size = new System.Drawing.Size(23, 22);
            this.tsbSubScript.Text = "Subscript";
            this.tsbSubScript.Click += new System.EventHandler(this.toolStripButton8_Click);
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton9.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton9.Image")));
            this.toolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton9.Text = "toolStripButton1";
            this.toolStripButton9.Click += new System.EventHandler(this.toolStripButton9_Click);
            // 
            // tsa
            // 
            this.tsa.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsa.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsa.Image = ((System.Drawing.Image)(resources.GetObject("tsa.Image")));
            this.tsa.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsa.Name = "tsa";
            this.tsa.Size = new System.Drawing.Size(23, 22);
            this.tsa.Text = "a";
            this.tsa.ToolTipText = "Alpha";
            this.tsa.Visible = false;
            // 
            // tsbeta
            // 
            this.tsbeta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbeta.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsbeta.Image = ((System.Drawing.Image)(resources.GetObject("tsbeta.Image")));
            this.tsbeta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbeta.Name = "tsbeta";
            this.tsbeta.Size = new System.Drawing.Size(23, 22);
            this.tsbeta.Text = "b";
            this.tsbeta.ToolTipText = "Beta";
            this.tsbeta.Visible = false;
            // 
            // tsgama
            // 
            this.tsgama.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsgama.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsgama.Image = ((System.Drawing.Image)(resources.GetObject("tsgama.Image")));
            this.tsgama.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsgama.Name = "tsgama";
            this.tsgama.Size = new System.Drawing.Size(23, 22);
            this.tsgama.Text = "g";
            this.tsgama.ToolTipText = "Gamma";
            this.tsgama.Visible = false;
            // 
            // tsdelta
            // 
            this.tsdelta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsdelta.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsdelta.Image = ((System.Drawing.Image)(resources.GetObject("tsdelta.Image")));
            this.tsdelta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsdelta.Name = "tsdelta";
            this.tsdelta.Size = new System.Drawing.Size(23, 22);
            this.tsdelta.Text = "d";
            this.tsdelta.ToolTipText = "Delta";
            this.tsdelta.Visible = false;
            // 
            // txtepsilon
            // 
            this.txtepsilon.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.txtepsilon.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtepsilon.Image = ((System.Drawing.Image)(resources.GetObject("txtepsilon.Image")));
            this.txtepsilon.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txtepsilon.Name = "txtepsilon";
            this.txtepsilon.Size = new System.Drawing.Size(23, 22);
            this.txtepsilon.Text = "e";
            this.txtepsilon.ToolTipText = "Epsilon";
            this.txtepsilon.Visible = false;
            // 
            // txtzeta
            // 
            this.txtzeta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.txtzeta.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtzeta.Image = ((System.Drawing.Image)(resources.GetObject("txtzeta.Image")));
            this.txtzeta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.txtzeta.Name = "txtzeta";
            this.txtzeta.Size = new System.Drawing.Size(23, 22);
            this.txtzeta.Text = "z";
            this.txtzeta.ToolTipText = "Zeta";
            this.txtzeta.Visible = false;
            // 
            // tseta
            // 
            this.tseta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tseta.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tseta.Image = ((System.Drawing.Image)(resources.GetObject("tseta.Image")));
            this.tseta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tseta.Name = "tseta";
            this.tseta.Size = new System.Drawing.Size(27, 22);
            this.tseta.Text = "eta";
            this.tseta.ToolTipText = "Eta";
            this.tseta.Visible = false;
            // 
            // ts1symbol
            // 
            this.ts1symbol.Checked = true;
            this.ts1symbol.CheckOnClick = true;
            this.ts1symbol.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ts1symbol.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ts1symbol.Image = ((System.Drawing.Image)(resources.GetObject("ts1symbol.Image")));
            this.ts1symbol.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ts1symbol.Name = "ts1symbol";
            this.ts1symbol.Size = new System.Drawing.Size(51, 22);
            this.ts1symbol.Text = "Symbol";
            this.ts1symbol.Visible = false;
            // 
            // tb1btnpreview
            // 
            this.tb1btnpreview.Image = ((System.Drawing.Image)(resources.GetObject("tb1btnpreview.Image")));
            this.tb1btnpreview.Location = new System.Drawing.Point(3, 4);
            this.tb1btnpreview.Name = "tb1btnpreview";
            this.tb1btnpreview.Size = new System.Drawing.Size(46, 23);
            this.tb1btnpreview.TabIndex = 4;
            this.tb1btnpreview.UseVisualStyleBackColor = true;
            this.tb1btnpreview.Click += new System.EventHandler(this.tb1btnpreview_Click);
            // 
            // frmNarrTANView
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(1360, 742);
            this.Controls.Add(this.pnlreactions);
            this.Controls.Add(this.pnlBottom);
            this.Name = "frmNarrTANView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Narratives Reactions View";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmTANView_FormClosing);
            this.Load += new System.EventHandler(this.frmNarrTANView_Load);
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.pnlreactions.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.splCntTreeViewAndTool.Panel1.ResumeLayout(false);
            this.splCntTreeViewAndTool.Panel2.ResumeLayout(false);
            this.splCntTreeViewAndTool.ResumeLayout(false);
            this.splCntTreeviewDocs.Panel1.ResumeLayout(false);
            this.splCntTreeviewDocs.Panel2.ResumeLayout(false);
            this.splCntTreeviewDocs.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTANDocuments)).EndInit();
            this.tcTool.ResumeLayout(false);
            this.tpCuration.ResumeLayout(false);
            this.pnlMasterDetails.ResumeLayout(false);
            this.pnlMasterDetails.PerformLayout();
            this.tsGreekChrs.ResumeLayout(false);
            this.tsGreekChrs.PerformLayout();
            this.tsFontStyleCntrls.ResumeLayout(false);
            this.tsFontStyleCntrls.PerformLayout();
            this.tpCoOrdinates.ResumeLayout(false);
            this.pnlCoOrdinateCntls.ResumeLayout(false);
            this.pnlCoOrdinateCntls.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgviewer)).EndInit();
            this.pnlTANDtls.ResumeLayout(false);
            this.pnlTANDtls.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Panel pnlreactions;
        private System.Windows.Forms.Label lblRxnCount;
        private System.Windows.Forms.Label lblreccountvalue;
        private System.Windows.Forms.OpenFileDialog ofd;
        private System.Windows.Forms.Button btnExportToExcel;
        private System.Windows.Forms.SaveFileDialog sfd;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.LinkLabel lnlerrors;
        private System.Windows.Forms.Button btnExportToPdf;
        private System.Windows.Forms.CheckBox chkIsRxnComplete;
        private System.Windows.Forms.ToolStrip miniToolStrip;
        private System.Windows.Forms.ToolStripButton tsbIncFontSize;
        private System.Windows.Forms.ToolStripButton toolStripButton83;
        private System.Windows.Forms.ToolStripButton tsbSuperScript;
        private System.Windows.Forms.ToolStripButton tsbSubScript;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
        private System.Windows.Forms.ToolStripButton tsa;
        private System.Windows.Forms.ToolStripButton tsbeta;
        private System.Windows.Forms.ToolStripButton tsgama;
        private System.Windows.Forms.ToolStripButton tsdelta;
        private System.Windows.Forms.ToolStripButton txtepsilon;
        private System.Windows.Forms.ToolStripButton txtzeta;
        private System.Windows.Forms.ToolStripButton tseta;
        private System.Windows.Forms.ToolStripButton ts1symbol;
        private System.Windows.Forms.Button tb1btnpreview;
        private System.Windows.Forms.CheckBox chkwordwrap;
        private System.Windows.Forms.Label lblScrollbars;
        private System.Windows.Forms.ComboBox cmb1scrollbars;
        private System.Windows.Forms.Button btntb1filepathpdf3;
        private System.Windows.Forms.TextBox txttb1filepathdoc1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private HtmlRichText.HtmlRichTextBox rtfformula;
        private System.Windows.Forms.SplitContainer splCntTreeViewAndTool;
        private System.Windows.Forms.SplitContainer splCntTreeviewDocs;
        private System.Windows.Forms.TreeView tvRxns;
        private System.Windows.Forms.DataGridView dgvTANDocuments;
        private System.Windows.Forms.TabControl tcTool;
        private System.Windows.Forms.TabPage tpCuration;
        private System.Windows.Forms.Panel pnlUserControl;
        private System.Windows.Forms.Panel pnlMasterDetails;
        public System.Windows.Forms.ToolStrip tsGreekChrs;
        private System.Windows.Forms.ToolStripButton tsalpha;
        private System.Windows.Forms.ToolStripButton tsbBeta;
        private System.Windows.Forms.ToolStripButton tsgamma;
        private System.Windows.Forms.ToolStripButton tsbDelta;
        private System.Windows.Forms.ToolStripButton tsepsilon;
        private System.Windows.Forms.ToolStripButton tszeta;
        private System.Windows.Forms.ToolStripButton tsbLatinEta;
        private System.Windows.Forms.ToolStripButton tsbTheta;
        private System.Windows.Forms.ToolStripButton tsbIota;
        private System.Windows.Forms.ToolStripButton tsbKappa;
        private System.Windows.Forms.ToolStripButton tslamda;
        private System.Windows.Forms.ToolStripButton tsbMu;
        private System.Windows.Forms.ToolStripButton tsbNu;
        private System.Windows.Forms.ToolStripButton tsxsi;
        private System.Windows.Forms.ToolStripButton tsomricon;
        private System.Windows.Forms.ToolStripButton tsbSmallLetterPi;
        private System.Windows.Forms.ToolStripButton tsbSmallLetterRho;
        private System.Windows.Forms.ToolStripButton tssigmaf;
        private System.Windows.Forms.ToolStripButton tsbSigma;
        private System.Windows.Forms.ToolStripButton tsbTau;
        private System.Windows.Forms.ToolStripButton tsupsilon;
        private System.Windows.Forms.ToolStripButton tsbPhi;
        private System.Windows.Forms.ToolStripButton tsbChi;
        private System.Windows.Forms.ToolStripButton tsbPsi;
        private System.Windows.Forms.ToolStripButton tsomega;
        private System.Windows.Forms.ToolStripButton ts1degree;
        private System.Windows.Forms.ToolStripButton tsbVeritcalLine;
        private System.Windows.Forms.ToolStripButton tsbTilde;
        private System.Windows.Forms.ToolStripButton tsbYen;
        private System.Windows.Forms.ToolStripButton tsbDoubleS;
        private System.Windows.Forms.ToolStripButton tsbCopyRight;
        private System.Windows.Forms.ToolStripButton tsbLeftDoubleAngleQuotes;
        private System.Windows.Forms.ToolStripButton tsbRegisteredTradeMark;
        private System.Windows.Forms.ToolStripButton tsbParagraphSign;
        private System.Windows.Forms.ToolStripButton tsbPlusOrMinus;
        private System.Windows.Forms.ToolStripButton tsbLatinLetterO;
        private System.Windows.Forms.ToolStripButton tsbLatinLetterF;
        private System.Windows.Forms.ToolStripButton tsbDagger;
        private System.Windows.Forms.ToolStripButton tsbDoubleDagger;
        private System.Windows.Forms.ToolStripButton tsbBullet;
        private System.Windows.Forms.ToolStripButton tsbCaretCircumflex;
        private System.Windows.Forms.ToolStripButton tsbLessThanEqual;
        private System.Windows.Forms.ToolStripButton tsbGreaterThanEqual;
        private System.Windows.Forms.ToolStripButton tsbIntegral;
        private System.Windows.Forms.ToolStripButton tsbNaryProduct;
        private System.Windows.Forms.ToolStripButton tsbSummation;
        private System.Windows.Forms.ToolStripButton tsbLatinSmallf;
        private System.Windows.Forms.ToolStripButton tsbIncrement;
        private System.Windows.Forms.ToolStripButton tsbAwithRing;
        private System.Windows.Forms.ToolStripButton tsbOwithStoke;
        private System.Windows.Forms.ToolStripButton ts1triplebond;
        private System.Windows.Forms.ToolStripButton tsbAwithCircumflex;
        private System.Windows.Forms.ToolStripButton tsbOmega;
        private System.Windows.Forms.ToolStripButton tsbDiaeresis;
        private System.Windows.Forms.ToolStripButton tsbUwithDiaeresis;
        private System.Windows.Forms.ToolStripButton tsbPi;
        private System.Windows.Forms.ToolStripButton tsbGreekV;
        private System.Windows.Forms.ToolStripButton toolStripButton20;
        private System.Windows.Forms.ToolStripButton toolStripButton21;
        private System.Windows.Forms.ToolStripButton tsbAlmostEqualTo;
        private System.Windows.Forms.ToolStripButton toolStripButton23;
        private System.Windows.Forms.TextBox txtDOI;
        private System.Windows.Forms.TextBox txtCAN;
        private System.Windows.Forms.TextBox txtTAN;
        private System.Windows.Forms.Label lblDOI;
        private System.Windows.Forms.Label lblCan;
        private System.Windows.Forms.Label lblTan;
        private System.Windows.Forms.ToolStrip tsFontStyleCntrls;
        private System.Windows.Forms.ToolStripButton ts1findandreplace;
        private System.Windows.Forms.ToolStripSeparator tspFndReplaceBold;
        private System.Windows.Forms.ToolStripButton tsbold;
        private System.Windows.Forms.ToolStripButton tsundeline;
        private System.Windows.Forms.ToolStripButton tsitalic;
        private System.Windows.Forms.ToolStripButton tsstrikeout;
        private System.Windows.Forms.ToolStripButton tsRegular;
        private System.Windows.Forms.ToolStripSeparator tspRegularSuperScript;
        private System.Windows.Forms.ToolStripButton tssuperscript;
        private System.Windows.Forms.ToolStripButton tsfont;
        private System.Windows.Forms.ToolStripButton tssubscript;
        private System.Windows.Forms.ToolStripSeparator tspSubScriptUndo;
        private System.Windows.Forms.ToolStripButton tsUndo;
        private System.Windows.Forms.ToolStripButton tsredo;
        private System.Windows.Forms.ToolStripSeparator tspRedoAddRxn;
        private System.Windows.Forms.ToolStripButton tsAddreaction;
        private System.Windows.Forms.ToolStripButton tsconvformula;
        private System.Windows.Forms.ToolStripSeparator tspFormulaHidden;
        private System.Windows.Forms.ToolStripButton tsbhidden;
        public uccasnartool_new uccasnartool_new1;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblTANDocs;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDocID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDocNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDocName;
        private System.Windows.Forms.Panel pnlTANDtls;
        private System.Windows.Forms.TabPage tpCoOrdinates;
        private System.Windows.Forms.Panel pnlCoOrdinateCntls;
        public System.Windows.Forms.Button btnbrowsecood;
        private System.Windows.Forms.TextBox txtbrowsecoordinates;
        private System.Windows.Forms.TextBox txtcpage;
        public System.Windows.Forms.Button btnPageSize;
        public System.Windows.Forms.Button btnZoomOnArea;
        public System.Windows.Forms.Button btnZoomFit;
        public System.Windows.Forms.Button btnZoom100;
        public System.Windows.Forms.Button btZoomOut;
        public System.Windows.Forms.Button btZoomIn;
        public System.Windows.Forms.TextBox txtZoom;
        public System.Windows.Forms.Button btNextPage;
        public System.Windows.Forms.Button btlastpage;
        public System.Windows.Forms.Button btPreviousPage;
        public System.Windows.Forms.Button btFirstpage;
        public System.Windows.Forms.Label lbPos;
        public System.Windows.Forms.Label lblxy;
        public System.Windows.Forms.Label lbPage;
        private System.Windows.Forms.Label lblPdfPath;
        public System.Windows.Forms.Button btnZoomWidth;
        internal AxGdViewerPro4.AxGdViewer dgviewer;
        private System.Windows.Forms.TextBox txtTANType;
        private System.Windows.Forms.Label lblTANType;

    }
}