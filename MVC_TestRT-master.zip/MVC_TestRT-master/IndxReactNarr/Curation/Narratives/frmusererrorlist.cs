﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using IndxReactNarrDAL;
using IndxReactNarr.Generic;

namespace CAS_Narrative.ErrorList
{
    public partial class frmusererrorlist : Form
    {
        public frmusererrorlist()
        {
            InitializeComponent();
        }
        DataSet dsUserErrors = null;
        DataTable dtPhase = null;
        private void frmusererrorlist_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;
                this.Cursor = Cursors.WaitCursor;
                int shipid = 0;// GlobalVariables.Shipment_ID;
                dgusererror.AutoGenerateColumns = false;
                //dsUserErrors = cas_narrative_schemaDataAccess.DAL.DataOperations.GetUserError(shipid, GlobalVariables.UserRoleID, GlobalVariables.UserID);
                if (dsUserErrors != null)
                {
                    if (dsUserErrors.Tables.Count > 0)
                    {
                        dgusererror.DataSource = dsUserErrors.Tables[0];
                        //Reported_To_UR_ID
                        if (dgusererror.Columns.Contains("Reported_To_UR_ID"))
                        {
                            dgusererror.Columns["Reported_To_UR_ID"].Visible = false;
                        }
                        if (dgusererror.Columns.Contains("comments"))
                        {
                            dgusererror.Columns["comments"].Visible = false;
                        }

                        for (int i = 0; i < dgusererror.Columns.Count; i++)
                            dgusererror.Columns[i].HeaderText = dgusererror.Columns[i].HeaderText.ToUpper();
                    }
                }
                if (dsUserErrors != null)
                {
                    if (dsUserErrors.Tables.Count > 0)
                    {
                        //pHase
                        dtPhase = dsUserErrors.Tables[0];
                        DataView dvPhase = new DataView(dtPhase);
                        dtPhase = dvPhase.ToTable(true, new string[3] { "phase_name", "shipment_id","tan" });
                        if (dtPhase != null)
                        {
                            DataView dv = new DataView(dtPhase);
                            DataTable dt = dv.ToTable(true, "Phase_name");
                            cmbphase.DataSource = dt;
                            cmbphase.DisplayMember = "phase_name";
                            cmbphase.ValueMember = "phase_name";
                        }


                    }

                }

            }
            catch (Exception ex)
            {
               ErrorHandling.WriteErrorLog(ex.ToString());
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        private void cmbphase_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbphase.Text != null && cmbphase.Text != "")
                {
                    if (cmbphase.Text != "System.Data.DataRowView")
                    {

                        if (dtPhase != null)
                        {
                            DataView dv = new DataView(dtPhase);
                            dv.RowFilter = "phase_name='" + cmbphase.Text + "'";
                            cmbshipment.DataSource = dv.ToTable(true, "shipment_id");
                            cmbshipment.DisplayMember = "Shipment_ID";
                            cmbshipment.ValueMember = "Shipment_ID";

                        }

                        if (dtPhase != null)
                        {
                            DataView dv = new DataView(dtPhase);
                            dv.RowFilter = "phase_name='" + cmbphase.Text + "' and shipment_id='"+cmbshipment.Text+"'";
                            cmbtans.DataSource = dv;
                            cmbtans.DisplayMember = "tan";
                            cmbtans.ValueMember = "tan";
                          

                        }


                        if (dsUserErrors != null)
                        {
                            DataView dv = dsUserErrors.Tables[0].DefaultView;
                            if (cmbshipment.Text != "" && cmbtans.Text!="" )
                                dv.RowFilter = "phase_name='" + cmbphase.Text + "' and shipment_id='" + cmbshipment.Text + "'and tan='"+cmbtans.Text+"' ";
                            else
                                dv.RowFilter = "phase_name='" + cmbphase.Text + "' ";

                            DataTable dt = dv.ToTable();
                            if (dt != null)
                            {
                                ConvertHtmltoRtf(ref dt);
                                dgusererror.DataSource = dt;
                                PopulateErrorCounts(dt);
                                if (dt.Rows.Count > 0)
                                {
                                    txtcomments.Text = dt.Rows[0]["comments"].ToString();
                                }
                                Hidecolumns();
                            }
                        }





                    }
                }
            }
            catch (Exception ex)
            {
               ErrorHandling.WriteErrorLog(ex.ToString());
            }

        }

        private void Hidecolumns()
        {
            dgusererror.AutoGenerateColumns = false;
            if (dgusererror.Columns.Contains("Reported_To_UR_ID"))
            {
                dgusererror.Columns["Reported_To_UR_ID"].Visible = false;
            }
            if (dgusererror.Columns.Contains("comments"))
            {
                dgusererror.Columns["comments"].Visible = false;
            }
        }

        private void ConvertHtmltoRtf(ref DataTable dt)
        {
            try
            {
                //uccasnartool uc = new uccasnartool();
                //if (dt != null)
                //{
                //    foreach (DataRow dr in dt.Rows)
                //    {

                //        hiddenctrl.Text = "";
                //        if (dr["OLD_VALUE"] != null)
                //            uc.ConvertHtmlToRtf(dr["OLD_VALUE"].ToString(), hiddenctrl);

                //        dr["OLD_VALUE"] = hiddenctrl.Rtf.ToString();

                //        hiddenctrl.Text = "";
                //        if (dr["NEW_VALUE"] != null)
                //            uc.ConvertHtmlToRtf(dr["NEW_VALUE"].ToString(), hiddenctrl);

                //        dr["NEW_VALUE"] = hiddenctrl.Rtf.ToString();


                //    }
                //}
            }
            catch (Exception ex)
            {
               ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void cmbshipment_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (dsUserErrors != null)
                {
                   

                    if (dtPhase != null)
                    {
                        DataView dv = new DataView(dtPhase);
                        dv.RowFilter = "phase_name='" + cmbphase.Text + "' and shipment_id='" + cmbshipment.Text + "'";
                        cmbtans.DataSource = dv;
                        cmbtans.DisplayMember = "tan";
                        cmbtans.ValueMember = "tan";


                    }


                    if (cmbshipment.Text != "System.Data.DataRowView")
                    {
                        if (cmbshipment.Text != null && cmbshipment.Text != "")
                        {

                            DataView dv = dsUserErrors.Tables[0].DefaultView;
                            dv.RowFilter = "shipment_id=" + cmbshipment.Text + " and phase_name='" + cmbphase.Text + "' and tan='"+cmbtans.Text+"'";
                            DataTable dt = dv.ToTable();
                            if (dt != null)
                            {
                                ConvertHtmltoRtf(ref dt);
                                PopulateErrorCounts(dt);
                                dgusererror.DataSource = dt;
                                if (dt.Rows.Count > 0)
                                {
                                    txtcomments.Text = dt.Rows[0]["comments"].ToString();
                                }
                                Hidecolumns();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
               ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void cmbtans_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (dsUserErrors != null)
                {
                    if (cmbtans.Text != "System.Data.DataRowView")
                    {
                        if (cmbtans.Text != null && cmbtans.Text != "")
                        {

                            DataView dv = dsUserErrors.Tables[0].DefaultView;
                            dv.RowFilter = "phase_name='"+cmbphase.Text+"' and shipment_id='"+cmbshipment.Text+"' and tan='" + cmbtans.Text + "'";
                            DataTable dt = dv.ToTable();
                            if (dt != null)
                            {
                                ConvertHtmltoRtf(ref dt);
                                PopulateErrorCounts(dt);
                                dgusererror.DataSource = dt;
                                Hidecolumns();
                                if (dt.Rows.Count > 0)
                                {
                                    txtcomments.Text = dt.Rows[0]["comments"].ToString();

                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
               ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnall_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            try
            {
                dgusererror.AutoGenerateColumns = false;
                DataTable dt = dsUserErrors.Tables[0];
                //                ConvertHtmltoRtf(ref dt);
                dgusererror.DataSource = dt;
                txtcomments.Text = "";
                PopulateErrorCounts(dt);
            }
            catch (Exception ex)
            {
               ErrorHandling.WriteErrorLog(ex.ToString());
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }
        private void PopulateErrorCounts(DataTable dt)
        {
            try
            {
                DataRow[] dperror = dt.Select("data_err_cnt='T'");
                if (dperror.Length > 0)
                {
                    txtdpcount.Text = dperror.Length.ToString();
                }

                DataRow[] dmaperror = dt.Select("map_err_cnt='T'");
                if (dmaperror.Length > 0)
                {
                    txtmappcount.Text = dmaperror.Length.ToString();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
