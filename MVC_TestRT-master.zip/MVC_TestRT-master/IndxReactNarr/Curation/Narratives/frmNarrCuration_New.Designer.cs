﻿namespace IndxReactNarr.Curation.Narratives
{
    partial class frmNarrCuration_New
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNarrCuration_New));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.btnTANReport = new System.Windows.Forms.Button();
            this.btnHideSplChars = new System.Windows.Forms.Button();
            this.btnFindReplace = new System.Windows.Forms.Button();
            this.btnExportToText = new System.Windows.Forms.Button();
            this.btnRejectTAN = new System.Windows.Forms.Button();
            this.btnTANComplete = new System.Windows.Forms.Button();
            this.lblSaveStatus = new System.Windows.Forms.Label();
            this.chkRxnComplete = new System.Windows.Forms.CheckBox();
            this.btnExportToPdf = new System.Windows.Forms.Button();
            this.lnlerrors = new System.Windows.Forms.LinkLabel();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnExportToExcel = new System.Windows.Forms.Button();
            this.lblRxnCountValue = new System.Windows.Forms.Label();
            this.lblRxnCount = new System.Windows.Forms.Label();
            this.splCntTreeViewAndTool = new System.Windows.Forms.SplitContainer();
            this.splCntTreeviewDocs = new System.Windows.Forms.SplitContainer();
            this.tvReactions = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.pnlNavigCntrls = new System.Windows.Forms.Panel();
            this.numGotoRecord = new System.Windows.Forms.NumericUpDown();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnFirst = new System.Windows.Forms.Button();
            this.pnlSearchRxn = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSrchProduct = new System.Windows.Forms.TextBox();
            this.dgvTANDocuments = new System.Windows.Forms.DataGridView();
            this.colDocID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDocPageSizeX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDocPageSizeY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDocNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDocName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblTANDocs = new System.Windows.Forms.Label();
            this.rtfformula = new HtmlRichText.HtmlRichTextBox();
            this.tcTool_CoOrdinates = new System.Windows.Forms.TabControl();
            this.tpCuration = new System.Windows.Forms.TabPage();
            this.pnlUserControl = new System.Windows.Forms.Panel();
            this.ucNarCuration1 = new IndxReactNarr.ucNarCuration();
            this.pnlSplChars = new System.Windows.Forms.Panel();
            this.ucSplCharsToolStrip_Indexing1 = new IndxReactNarr.UserControls.ucSplCharsToolStrip_Indexing();
            this.tpCoOrdinates = new System.Windows.Forms.TabPage();
            this.gdViewer = new AxGdViewerPro4.AxGdViewer();
            this.pnlCoOrdinateCntls = new System.Windows.Forms.Panel();
            this.btnBrowseCood = new System.Windows.Forms.Button();
            this.txtbrowsecoordinates = new System.Windows.Forms.TextBox();
            this.txtGoToPdfPage = new System.Windows.Forms.TextBox();
            this.btnPageSize = new System.Windows.Forms.Button();
            this.btnZoomOnArea = new System.Windows.Forms.Button();
            this.btnZoomFit = new System.Windows.Forms.Button();
            this.btnZoom100 = new System.Windows.Forms.Button();
            this.btZoomOut = new System.Windows.Forms.Button();
            this.btZoomIn = new System.Windows.Forms.Button();
            this.txtZoom = new System.Windows.Forms.TextBox();
            this.btNextPage = new System.Windows.Forms.Button();
            this.btlastpage = new System.Windows.Forms.Button();
            this.btPreviousPage = new System.Windows.Forms.Button();
            this.btFirstpage = new System.Windows.Forms.Button();
            this.lbPos = new System.Windows.Forms.Label();
            this.lblxy = new System.Windows.Forms.Label();
            this.lbPage = new System.Windows.Forms.Label();
            this.lblPdfPath = new System.Windows.Forms.Label();
            this.btnZoomWidth = new System.Windows.Forms.Button();
            this.pnlTANDtls = new System.Windows.Forms.Panel();
            this.txtDOI = new System.Windows.Forms.TextBox();
            this.txtTANType = new System.Windows.Forms.TextBox();
            this.lblTANType = new System.Windows.Forms.Label();
            this.txtCAN = new System.Windows.Forms.TextBox();
            this.lblTan = new System.Windows.Forms.Label();
            this.txtTAN = new System.Windows.Forms.TextBox();
            this.lblCan = new System.Windows.Forms.Label();
            this.lblDOI = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splCntTreeViewAndTool)).BeginInit();
            this.splCntTreeViewAndTool.Panel1.SuspendLayout();
            this.splCntTreeViewAndTool.Panel2.SuspendLayout();
            this.splCntTreeViewAndTool.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splCntTreeviewDocs)).BeginInit();
            this.splCntTreeviewDocs.Panel1.SuspendLayout();
            this.splCntTreeviewDocs.Panel2.SuspendLayout();
            this.splCntTreeviewDocs.SuspendLayout();
            this.pnlNavigCntrls.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numGotoRecord)).BeginInit();
            this.pnlSearchRxn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTANDocuments)).BeginInit();
            this.tcTool_CoOrdinates.SuspendLayout();
            this.tpCuration.SuspendLayout();
            this.pnlUserControl.SuspendLayout();
            this.pnlSplChars.SuspendLayout();
            this.tpCoOrdinates.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gdViewer)).BeginInit();
            this.pnlCoOrdinateCntls.SuspendLayout();
            this.pnlTANDtls.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlBottom
            // 
            this.pnlBottom.BackColor = System.Drawing.Color.White;
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom.Controls.Add(this.btnTANReport);
            this.pnlBottom.Controls.Add(this.btnHideSplChars);
            this.pnlBottom.Controls.Add(this.btnFindReplace);
            this.pnlBottom.Controls.Add(this.btnExportToText);
            this.pnlBottom.Controls.Add(this.btnRejectTAN);
            this.pnlBottom.Controls.Add(this.btnTANComplete);
            this.pnlBottom.Controls.Add(this.lblSaveStatus);
            this.pnlBottom.Controls.Add(this.chkRxnComplete);
            this.pnlBottom.Controls.Add(this.btnExportToPdf);
            this.pnlBottom.Controls.Add(this.lnlerrors);
            this.pnlBottom.Controls.Add(this.btnSave);
            this.pnlBottom.Controls.Add(this.btnExportToExcel);
            this.pnlBottom.Controls.Add(this.lblRxnCountValue);
            this.pnlBottom.Controls.Add(this.lblRxnCount);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 535);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(1244, 29);
            this.pnlBottom.TabIndex = 3;
            // 
            // btnTANReport
            // 
            this.btnTANReport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnTANReport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTANReport.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTANReport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTANReport.Location = new System.Drawing.Point(562, 2);
            this.btnTANReport.Name = "btnTANReport";
            this.btnTANReport.Size = new System.Drawing.Size(79, 24);
            this.btnTANReport.TabIndex = 61;
            this.btnTANReport.TabStop = false;
            this.btnTANReport.Text = "TAN Report";
            this.btnTANReport.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTANReport.UseVisualStyleBackColor = true;
            this.btnTANReport.Click += new System.EventHandler(this.btnTANReport_Click);
            // 
            // btnHideSplChars
            // 
            this.btnHideSplChars.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHideSplChars.Image = global::IndxReactNarr.Properties.Resources.control_panel;
            this.btnHideSplChars.Location = new System.Drawing.Point(527, 2);
            this.btnHideSplChars.Name = "btnHideSplChars";
            this.btnHideSplChars.Size = new System.Drawing.Size(30, 24);
            this.btnHideSplChars.TabIndex = 60;
            this.btnHideSplChars.TabStop = false;
            this.toolTip1.SetToolTip(this.btnHideSplChars, "Show/Hide Special Chars");
            this.btnHideSplChars.UseVisualStyleBackColor = true;
            this.btnHideSplChars.Click += new System.EventHandler(this.btnHideSplChars_Click);
            // 
            // btnFindReplace
            // 
            this.btnFindReplace.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnFindReplace.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFindReplace.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFindReplace.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFindReplace.Location = new System.Drawing.Point(423, 2);
            this.btnFindReplace.Name = "btnFindReplace";
            this.btnFindReplace.Size = new System.Drawing.Size(99, 24);
            this.btnFindReplace.TabIndex = 59;
            this.btnFindReplace.TabStop = false;
            this.btnFindReplace.Text = "Find / Replace";
            this.btnFindReplace.UseVisualStyleBackColor = true;
            this.btnFindReplace.Click += new System.EventHandler(this.btnFindReplace_Click);
            // 
            // btnExportToText
            // 
            this.btnExportToText.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnExportToText.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExportToText.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportToText.Image = ((System.Drawing.Image)(resources.GetObject("btnExportToText.Image")));
            this.btnExportToText.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExportToText.Location = new System.Drawing.Point(350, 2);
            this.btnExportToText.Name = "btnExportToText";
            this.btnExportToText.Size = new System.Drawing.Size(67, 24);
            this.btnExportToText.TabIndex = 58;
            this.btnExportToText.TabStop = false;
            this.btnExportToText.Text = "Export";
            this.btnExportToText.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.toolTip1.SetToolTip(this.btnExportToText, "Xml Export");
            this.btnExportToText.UseVisualStyleBackColor = true;
            this.btnExportToText.Click += new System.EventHandler(this.btnExportToText_Click);
            // 
            // btnRejectTAN
            // 
            this.btnRejectTAN.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRejectTAN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRejectTAN.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRejectTAN.ForeColor = System.Drawing.Color.Black;
            this.btnRejectTAN.Location = new System.Drawing.Point(929, 1);
            this.btnRejectTAN.Name = "btnRejectTAN";
            this.btnRejectTAN.Size = new System.Drawing.Size(93, 24);
            this.btnRejectTAN.TabIndex = 57;
            this.btnRejectTAN.TabStop = false;
            this.btnRejectTAN.Text = "TAN Reject";
            this.btnRejectTAN.UseVisualStyleBackColor = true;
            this.btnRejectTAN.Click += new System.EventHandler(this.btnRejectTAN_Click);
            // 
            // btnTANComplete
            // 
            this.btnTANComplete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTANComplete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTANComplete.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTANComplete.ForeColor = System.Drawing.Color.Black;
            this.btnTANComplete.Location = new System.Drawing.Point(830, 1);
            this.btnTANComplete.Name = "btnTANComplete";
            this.btnTANComplete.Size = new System.Drawing.Size(96, 24);
            this.btnTANComplete.TabIndex = 55;
            this.btnTANComplete.TabStop = false;
            this.btnTANComplete.Text = "TAN Complete";
            this.btnTANComplete.UseVisualStyleBackColor = true;
            this.btnTANComplete.Click += new System.EventHandler(this.btnTANComplete_Click);
            // 
            // lblSaveStatus
            // 
            this.lblSaveStatus.AutoSize = true;
            this.lblSaveStatus.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaveStatus.ForeColor = System.Drawing.Color.Blue;
            this.lblSaveStatus.Location = new System.Drawing.Point(648, 6);
            this.lblSaveStatus.Name = "lblSaveStatus";
            this.lblSaveStatus.Size = new System.Drawing.Size(23, 15);
            this.lblSaveStatus.TabIndex = 20;
            this.lblSaveStatus.Text = "----";
            // 
            // chkRxnComplete
            // 
            this.chkRxnComplete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chkRxnComplete.AutoSize = true;
            this.chkRxnComplete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkRxnComplete.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkRxnComplete.Location = new System.Drawing.Point(1028, 4);
            this.chkRxnComplete.Name = "chkRxnComplete";
            this.chkRxnComplete.Size = new System.Drawing.Size(132, 19);
            this.chkRxnComplete.TabIndex = 19;
            this.chkRxnComplete.Text = "Reaction Complete";
            this.chkRxnComplete.UseVisualStyleBackColor = true;
            // 
            // btnExportToPdf
            // 
            this.btnExportToPdf.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnExportToPdf.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExportToPdf.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportToPdf.Image = ((System.Drawing.Image)(resources.GetObject("btnExportToPdf.Image")));
            this.btnExportToPdf.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExportToPdf.Location = new System.Drawing.Point(201, 2);
            this.btnExportToPdf.Name = "btnExportToPdf";
            this.btnExportToPdf.Size = new System.Drawing.Size(68, 24);
            this.btnExportToPdf.TabIndex = 18;
            this.btnExportToPdf.TabStop = false;
            this.btnExportToPdf.Text = "Export";
            this.btnExportToPdf.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExportToPdf.UseVisualStyleBackColor = true;
            this.btnExportToPdf.Click += new System.EventHandler(this.btnExportToPdf_Click);
            // 
            // lnlerrors
            // 
            this.lnlerrors.AutoSize = true;
            this.lnlerrors.LinkColor = System.Drawing.Color.Red;
            this.lnlerrors.Location = new System.Drawing.Point(161, 4);
            this.lnlerrors.Name = "lnlerrors";
            this.lnlerrors.Size = new System.Drawing.Size(34, 13);
            this.lnlerrors.TabIndex = 15;
            this.lnlerrors.TabStop = true;
            this.lnlerrors.Text = "Errors";
            this.lnlerrors.Visible = false;
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Image = global::IndxReactNarr.Properties.Resources.save_1;
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(1163, 1);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 24);
            this.btnSave.TabIndex = 13;
            this.btnSave.TabStop = false;
            this.btnSave.Text = "Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnExportToExcel
            // 
            this.btnExportToExcel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnExportToExcel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExportToExcel.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportToExcel.Image = ((System.Drawing.Image)(resources.GetObject("btnExportToExcel.Image")));
            this.btnExportToExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExportToExcel.Location = new System.Drawing.Point(276, 2);
            this.btnExportToExcel.Name = "btnExportToExcel";
            this.btnExportToExcel.Size = new System.Drawing.Size(67, 24);
            this.btnExportToExcel.TabIndex = 4;
            this.btnExportToExcel.TabStop = false;
            this.btnExportToExcel.Text = "Export";
            this.btnExportToExcel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExportToExcel.UseVisualStyleBackColor = true;
            this.btnExportToExcel.Click += new System.EventHandler(this.btnExportToExcel_Click);
            // 
            // lblRxnCountValue
            // 
            this.lblRxnCountValue.AutoSize = true;
            this.lblRxnCountValue.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnCountValue.ForeColor = System.Drawing.Color.Blue;
            this.lblRxnCountValue.Location = new System.Drawing.Point(137, 7);
            this.lblRxnCountValue.Name = "lblRxnCountValue";
            this.lblRxnCountValue.Size = new System.Drawing.Size(14, 15);
            this.lblRxnCountValue.TabIndex = 3;
            this.lblRxnCountValue.Text = "0";
            // 
            // lblRxnCount
            // 
            this.lblRxnCount.AutoSize = true;
            this.lblRxnCount.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnCount.Location = new System.Drawing.Point(4, 7);
            this.lblRxnCount.Name = "lblRxnCount";
            this.lblRxnCount.Size = new System.Drawing.Size(136, 15);
            this.lblRxnCount.TabIndex = 2;
            this.lblRxnCount.Text = "Completed Reactions : ";
            // 
            // splCntTreeViewAndTool
            // 
            this.splCntTreeViewAndTool.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splCntTreeViewAndTool.Location = new System.Drawing.Point(0, 0);
            this.splCntTreeViewAndTool.Name = "splCntTreeViewAndTool";
            // 
            // splCntTreeViewAndTool.Panel1
            // 
            this.splCntTreeViewAndTool.Panel1.Controls.Add(this.splCntTreeviewDocs);
            // 
            // splCntTreeViewAndTool.Panel2
            // 
            this.splCntTreeViewAndTool.Panel2.Controls.Add(this.tcTool_CoOrdinates);
            this.splCntTreeViewAndTool.Panel2.Controls.Add(this.pnlTANDtls);
            this.splCntTreeViewAndTool.Size = new System.Drawing.Size(1244, 535);
            this.splCntTreeViewAndTool.SplitterDistance = 193;
            this.splCntTreeViewAndTool.TabIndex = 2;
            // 
            // splCntTreeviewDocs
            // 
            this.splCntTreeviewDocs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splCntTreeviewDocs.Location = new System.Drawing.Point(0, 0);
            this.splCntTreeviewDocs.Name = "splCntTreeviewDocs";
            this.splCntTreeviewDocs.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splCntTreeviewDocs.Panel1
            // 
            this.splCntTreeviewDocs.Panel1.Controls.Add(this.tvReactions);
            this.splCntTreeviewDocs.Panel1.Controls.Add(this.pnlNavigCntrls);
            this.splCntTreeviewDocs.Panel1.Controls.Add(this.pnlSearchRxn);
            // 
            // splCntTreeviewDocs.Panel2
            // 
            this.splCntTreeviewDocs.Panel2.Controls.Add(this.dgvTANDocuments);
            this.splCntTreeviewDocs.Panel2.Controls.Add(this.lblTANDocs);
            this.splCntTreeviewDocs.Panel2.Controls.Add(this.rtfformula);
            this.splCntTreeviewDocs.Size = new System.Drawing.Size(193, 535);
            this.splCntTreeviewDocs.SplitterDistance = 409;
            this.splCntTreeviewDocs.TabIndex = 1;
            // 
            // tvReactions
            // 
            this.tvReactions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvReactions.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tvReactions.ForeColor = System.Drawing.Color.Blue;
            this.tvReactions.ImageIndex = 2;
            this.tvReactions.ImageList = this.imageList1;
            this.tvReactions.Location = new System.Drawing.Point(0, 25);
            this.tvReactions.Name = "tvReactions";
            this.tvReactions.SelectedImageIndex = 2;
            this.tvReactions.Size = new System.Drawing.Size(193, 358);
            this.tvReactions.TabIndex = 1;
            this.tvReactions.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvRxns_NodeMouseDoubleClick);
            this.tvReactions.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tvReactions_KeyPress);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "RxnComplete.png");
            this.imageList1.Images.SetKeyName(1, "RxnNotComplete.jpg");
            this.imageList1.Images.SetKeyName(2, "SelectedRxn.png");
            // 
            // pnlNavigCntrls
            // 
            this.pnlNavigCntrls.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.pnlNavigCntrls.Controls.Add(this.numGotoRecord);
            this.pnlNavigCntrls.Controls.Add(this.btnLast);
            this.pnlNavigCntrls.Controls.Add(this.btnNext);
            this.pnlNavigCntrls.Controls.Add(this.btnPrevious);
            this.pnlNavigCntrls.Controls.Add(this.btnFirst);
            this.pnlNavigCntrls.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlNavigCntrls.Location = new System.Drawing.Point(0, 383);
            this.pnlNavigCntrls.Name = "pnlNavigCntrls";
            this.pnlNavigCntrls.Size = new System.Drawing.Size(193, 26);
            this.pnlNavigCntrls.TabIndex = 46;
            // 
            // numGotoRecord
            // 
            this.numGotoRecord.InterceptArrowKeys = false;
            this.numGotoRecord.Location = new System.Drawing.Point(76, 3);
            this.numGotoRecord.Name = "numGotoRecord";
            this.numGotoRecord.Size = new System.Drawing.Size(42, 20);
            this.numGotoRecord.TabIndex = 43;
            this.numGotoRecord.ValueChanged += new System.EventHandler(this.numGotoRecord_ValueChanged);
            this.numGotoRecord.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.numGotoRecord_KeyPress);
            // 
            // btnLast
            // 
            this.btnLast.BackgroundImage = global::IndxReactNarr.Properties.Resources.resultset_last;
            this.btnLast.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnLast.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLast.Location = new System.Drawing.Point(158, 0);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(35, 27);
            this.btnLast.TabIndex = 38;
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnNext
            // 
            this.btnNext.BackgroundImage = global::IndxReactNarr.Properties.Resources.resultset_next;
            this.btnNext.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnNext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNext.Location = new System.Drawing.Point(121, 0);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(35, 27);
            this.btnNext.TabIndex = 37;
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.BackgroundImage = global::IndxReactNarr.Properties.Resources.resultset_previous;
            this.btnPrevious.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnPrevious.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPrevious.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrevious.Location = new System.Drawing.Point(38, 0);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(35, 27);
            this.btnPrevious.TabIndex = 36;
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnFirst
            // 
            this.btnFirst.BackgroundImage = global::IndxReactNarr.Properties.Resources.resultset_first;
            this.btnFirst.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnFirst.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFirst.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFirst.Location = new System.Drawing.Point(1, 0);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(35, 27);
            this.btnFirst.TabIndex = 35;
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // pnlSearchRxn
            // 
            this.pnlSearchRxn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pnlSearchRxn.Controls.Add(this.label2);
            this.pnlSearchRxn.Controls.Add(this.txtSrchProduct);
            this.pnlSearchRxn.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSearchRxn.Location = new System.Drawing.Point(0, 0);
            this.pnlSearchRxn.Name = "pnlSearchRxn";
            this.pnlSearchRxn.Size = new System.Drawing.Size(193, 25);
            this.pnlSearchRxn.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(1, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 16);
            this.label2.TabIndex = 203;
            this.label2.Text = "Search Rxn";
            // 
            // txtSrchProduct
            // 
            this.txtSrchProduct.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSrchProduct.BackColor = System.Drawing.Color.FloralWhite;
            this.txtSrchProduct.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSrchProduct.Location = new System.Drawing.Point(78, 2);
            this.txtSrchProduct.Name = "txtSrchProduct";
            this.txtSrchProduct.Size = new System.Drawing.Size(112, 21);
            this.txtSrchProduct.TabIndex = 1;
            this.txtSrchProduct.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSrchProduct_KeyPress);
            // 
            // dgvTANDocuments
            // 
            this.dgvTANDocuments.AllowUserToAddRows = false;
            this.dgvTANDocuments.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTANDocuments.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvTANDocuments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTANDocuments.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colDocID,
            this.colDocPageSizeX,
            this.colDocPageSizeY,
            this.colDocNo,
            this.colDocName});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTANDocuments.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvTANDocuments.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTANDocuments.Location = new System.Drawing.Point(0, 20);
            this.dgvTANDocuments.Name = "dgvTANDocuments";
            this.dgvTANDocuments.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTANDocuments.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvTANDocuments.RowHeadersVisible = false;
            this.dgvTANDocuments.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTANDocuments.Size = new System.Drawing.Size(193, 102);
            this.dgvTANDocuments.TabIndex = 3;
            this.dgvTANDocuments.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTANDocuments_CellDoubleClick);
            // 
            // colDocID
            // 
            this.colDocID.HeaderText = "DocID";
            this.colDocID.Name = "colDocID";
            this.colDocID.ReadOnly = true;
            this.colDocID.Visible = false;
            // 
            // colDocPageSizeX
            // 
            this.colDocPageSizeX.DataPropertyName = "PAGE_SIZE_X";
            this.colDocPageSizeX.HeaderText = "Page Size X";
            this.colDocPageSizeX.Name = "colDocPageSizeX";
            this.colDocPageSizeX.ReadOnly = true;
            this.colDocPageSizeX.Visible = false;
            // 
            // colDocPageSizeY
            // 
            this.colDocPageSizeY.DataPropertyName = "PAGE_SIZE_Y";
            this.colDocPageSizeY.HeaderText = "Page Size Y";
            this.colDocPageSizeY.Name = "colDocPageSizeY";
            this.colDocPageSizeY.ReadOnly = true;
            this.colDocPageSizeY.Visible = false;
            // 
            // colDocNo
            // 
            this.colDocNo.HeaderText = "DocNo";
            this.colDocNo.Name = "colDocNo";
            this.colDocNo.ReadOnly = true;
            this.colDocNo.Width = 50;
            // 
            // colDocName
            // 
            this.colDocName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colDocName.HeaderText = "DocName";
            this.colDocName.Name = "colDocName";
            this.colDocName.ReadOnly = true;
            // 
            // lblTANDocs
            // 
            this.lblTANDocs.BackColor = System.Drawing.Color.FloralWhite;
            this.lblTANDocs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTANDocs.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTANDocs.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTANDocs.Location = new System.Drawing.Point(0, 0);
            this.lblTANDocs.Name = "lblTANDocs";
            this.lblTANDocs.Size = new System.Drawing.Size(193, 20);
            this.lblTANDocs.TabIndex = 4;
            this.lblTANDocs.Text = "TAN File Names";
            this.lblTANDocs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rtfformula
            // 
            this.rtfformula.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.rtfformula.Location = new System.Drawing.Point(11, 140);
            this.rtfformula.Name = "rtfformula";
            this.rtfformula.Size = new System.Drawing.Size(230, 13);
            this.rtfformula.TabIndex = 0;
            this.rtfformula.Text = "";
            this.rtfformula.Visible = false;
            // 
            // tcTool_CoOrdinates
            // 
            this.tcTool_CoOrdinates.Controls.Add(this.tpCuration);
            this.tcTool_CoOrdinates.Controls.Add(this.tpCoOrdinates);
            this.tcTool_CoOrdinates.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcTool_CoOrdinates.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tcTool_CoOrdinates.Location = new System.Drawing.Point(0, 28);
            this.tcTool_CoOrdinates.Name = "tcTool_CoOrdinates";
            this.tcTool_CoOrdinates.SelectedIndex = 0;
            this.tcTool_CoOrdinates.Size = new System.Drawing.Size(1047, 507);
            this.tcTool_CoOrdinates.TabIndex = 0;
            // 
            // tpCuration
            // 
            this.tpCuration.Controls.Add(this.pnlUserControl);
            this.tpCuration.Controls.Add(this.pnlSplChars);
            this.tpCuration.ImageIndex = 3;
            this.tpCuration.Location = new System.Drawing.Point(4, 24);
            this.tpCuration.Name = "tpCuration";
            this.tpCuration.Padding = new System.Windows.Forms.Padding(1);
            this.tpCuration.Size = new System.Drawing.Size(1039, 479);
            this.tpCuration.TabIndex = 0;
            this.tpCuration.Text = "Curation";
            this.tpCuration.UseVisualStyleBackColor = true;
            // 
            // pnlUserControl
            // 
            this.pnlUserControl.Controls.Add(this.ucNarCuration1);
            this.pnlUserControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlUserControl.Location = new System.Drawing.Point(1, 73);
            this.pnlUserControl.Name = "pnlUserControl";
            this.pnlUserControl.Size = new System.Drawing.Size(1037, 405);
            this.pnlUserControl.TabIndex = 0;
            // 
            // ucNarCuration1
            // 
            this.ucNarCuration1.AnalogousRxns = null;
            this.ucNarCuration1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ucNarCuration1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucNarCuration1.DsFindAndReplace = null;
            this.ucNarCuration1.Location = new System.Drawing.Point(0, 0);
            this.ucNarCuration1.Name = "ucNarCuration1";
            this.ucNarCuration1.Rxn_ID = 0;
            this.ucNarCuration1.Size = new System.Drawing.Size(1037, 405);
            this.ucNarCuration1.TabIndex = 0;
            this.ucNarCuration1.TAN_Documents = null;
            this.ucNarCuration1.TAN_Reactions = null;
            this.ucNarCuration1.TANType = null;
            // 
            // pnlSplChars
            // 
            this.pnlSplChars.Controls.Add(this.ucSplCharsToolStrip_Indexing1);
            this.pnlSplChars.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSplChars.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlSplChars.Location = new System.Drawing.Point(1, 1);
            this.pnlSplChars.Name = "pnlSplChars";
            this.pnlSplChars.Size = new System.Drawing.Size(1037, 72);
            this.pnlSplChars.TabIndex = 0;
            // 
            // ucSplCharsToolStrip_Indexing1
            // 
            this.ucSplCharsToolStrip_Indexing1.BackColor = System.Drawing.Color.White;
            this.ucSplCharsToolStrip_Indexing1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ucSplCharsToolStrip_Indexing1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucSplCharsToolStrip_Indexing1.Location = new System.Drawing.Point(0, 0);
            this.ucSplCharsToolStrip_Indexing1.Name = "ucSplCharsToolStrip_Indexing1";
            this.ucSplCharsToolStrip_Indexing1.Size = new System.Drawing.Size(1037, 72);
            this.ucSplCharsToolStrip_Indexing1.TabIndex = 0;
            // 
            // tpCoOrdinates
            // 
            this.tpCoOrdinates.Controls.Add(this.gdViewer);
            this.tpCoOrdinates.Controls.Add(this.pnlCoOrdinateCntls);
            this.tpCoOrdinates.Location = new System.Drawing.Point(4, 24);
            this.tpCoOrdinates.Name = "tpCoOrdinates";
            this.tpCoOrdinates.Size = new System.Drawing.Size(1039, 479);
            this.tpCoOrdinates.TabIndex = 1;
            this.tpCoOrdinates.Text = "PDF Co-ordinates";
            this.tpCoOrdinates.UseVisualStyleBackColor = true;
            // 
            // gdViewer
            // 
            this.gdViewer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gdViewer.Enabled = true;
            this.gdViewer.Location = new System.Drawing.Point(0, 59);
            this.gdViewer.Name = "gdViewer";
            this.gdViewer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("gdViewer.OcxState")));
            this.gdViewer.Size = new System.Drawing.Size(1039, 420);
            this.gdViewer.TabIndex = 36;
            this.gdViewer.Tag = "XC";
            this.gdViewer.ZoomChange += new System.EventHandler(this.gdViewer_ZoomChange);
            this.gdViewer.MouseMoveControl += new AxGdViewerPro4.@__GdViewer_MouseMoveControlEventHandler(this.gdViewer_MouseMoveControl);
            this.gdViewer.ClickControl += new System.EventHandler(this.gdViewer_ClickControl);
            // 
            // pnlCoOrdinateCntls
            // 
            this.pnlCoOrdinateCntls.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlCoOrdinateCntls.Controls.Add(this.btnBrowseCood);
            this.pnlCoOrdinateCntls.Controls.Add(this.txtbrowsecoordinates);
            this.pnlCoOrdinateCntls.Controls.Add(this.txtGoToPdfPage);
            this.pnlCoOrdinateCntls.Controls.Add(this.btnPageSize);
            this.pnlCoOrdinateCntls.Controls.Add(this.btnZoomOnArea);
            this.pnlCoOrdinateCntls.Controls.Add(this.btnZoomFit);
            this.pnlCoOrdinateCntls.Controls.Add(this.btnZoom100);
            this.pnlCoOrdinateCntls.Controls.Add(this.btZoomOut);
            this.pnlCoOrdinateCntls.Controls.Add(this.btZoomIn);
            this.pnlCoOrdinateCntls.Controls.Add(this.txtZoom);
            this.pnlCoOrdinateCntls.Controls.Add(this.btNextPage);
            this.pnlCoOrdinateCntls.Controls.Add(this.btlastpage);
            this.pnlCoOrdinateCntls.Controls.Add(this.btPreviousPage);
            this.pnlCoOrdinateCntls.Controls.Add(this.btFirstpage);
            this.pnlCoOrdinateCntls.Controls.Add(this.lbPos);
            this.pnlCoOrdinateCntls.Controls.Add(this.lblxy);
            this.pnlCoOrdinateCntls.Controls.Add(this.lbPage);
            this.pnlCoOrdinateCntls.Controls.Add(this.lblPdfPath);
            this.pnlCoOrdinateCntls.Controls.Add(this.btnZoomWidth);
            this.pnlCoOrdinateCntls.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCoOrdinateCntls.Location = new System.Drawing.Point(0, 0);
            this.pnlCoOrdinateCntls.Name = "pnlCoOrdinateCntls";
            this.pnlCoOrdinateCntls.Size = new System.Drawing.Size(1039, 59);
            this.pnlCoOrdinateCntls.TabIndex = 35;
            // 
            // btnBrowseCood
            // 
            this.btnBrowseCood.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBrowseCood.BackColor = System.Drawing.SystemColors.Control;
            this.btnBrowseCood.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnBrowseCood.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowseCood.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnBrowseCood.Location = new System.Drawing.Point(943, 5);
            this.btnBrowseCood.Name = "btnBrowseCood";
            this.btnBrowseCood.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnBrowseCood.Size = new System.Drawing.Size(48, 21);
            this.btnBrowseCood.TabIndex = 40;
            this.btnBrowseCood.Text = "...";
            this.btnBrowseCood.UseVisualStyleBackColor = false;
            this.btnBrowseCood.Click += new System.EventHandler(this.btnBrowseCood_Click);
            // 
            // txtbrowsecoordinates
            // 
            this.txtbrowsecoordinates.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbrowsecoordinates.Location = new System.Drawing.Point(65, 5);
            this.txtbrowsecoordinates.Name = "txtbrowsecoordinates";
            this.txtbrowsecoordinates.Size = new System.Drawing.Size(872, 21);
            this.txtbrowsecoordinates.TabIndex = 39;
            // 
            // txtGoToPdfPage
            // 
            this.txtGoToPdfPage.Location = new System.Drawing.Point(125, 33);
            this.txtGoToPdfPage.Name = "txtGoToPdfPage";
            this.txtGoToPdfPage.Size = new System.Drawing.Size(40, 21);
            this.txtGoToPdfPage.TabIndex = 36;
            this.txtGoToPdfPage.TextChanged += new System.EventHandler(this.txtGoToPdfPage_TextChanged);
            // 
            // btnPageSize
            // 
            this.btnPageSize.BackColor = System.Drawing.SystemColors.Control;
            this.btnPageSize.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnPageSize.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnPageSize.Location = new System.Drawing.Point(902, 32);
            this.btnPageSize.Name = "btnPageSize";
            this.btnPageSize.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnPageSize.Size = new System.Drawing.Size(83, 23);
            this.btnPageSize.TabIndex = 35;
            this.btnPageSize.Text = "Page Size";
            this.btnPageSize.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnPageSize.UseVisualStyleBackColor = false;
            this.btnPageSize.Click += new System.EventHandler(this.btnPageSize_Click);
            // 
            // btnZoomOnArea
            // 
            this.btnZoomOnArea.BackColor = System.Drawing.SystemColors.Control;
            this.btnZoomOnArea.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnZoomOnArea.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnZoomOnArea.Location = new System.Drawing.Point(720, 32);
            this.btnZoomOnArea.Name = "btnZoomOnArea";
            this.btnZoomOnArea.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnZoomOnArea.Size = new System.Drawing.Size(82, 22);
            this.btnZoomOnArea.TabIndex = 32;
            this.btnZoomOnArea.Text = "Zoom on Area";
            this.btnZoomOnArea.UseVisualStyleBackColor = false;
            this.btnZoomOnArea.Click += new System.EventHandler(this.btnZoomOnArea_Click);
            // 
            // btnZoomFit
            // 
            this.btnZoomFit.BackColor = System.Drawing.SystemColors.Control;
            this.btnZoomFit.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnZoomFit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnZoomFit.Location = new System.Drawing.Point(538, 32);
            this.btnZoomFit.Name = "btnZoomFit";
            this.btnZoomFit.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnZoomFit.Size = new System.Drawing.Size(82, 22);
            this.btnZoomFit.TabIndex = 31;
            this.btnZoomFit.Text = "Zoom Fit";
            this.btnZoomFit.UseVisualStyleBackColor = false;
            this.btnZoomFit.Click += new System.EventHandler(this.btnZoomFit_Click);
            // 
            // btnZoom100
            // 
            this.btnZoom100.BackColor = System.Drawing.SystemColors.Control;
            this.btnZoom100.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnZoom100.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnZoom100.Location = new System.Drawing.Point(808, 32);
            this.btnZoom100.Name = "btnZoom100";
            this.btnZoom100.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnZoom100.Size = new System.Drawing.Size(88, 23);
            this.btnZoom100.TabIndex = 30;
            this.btnZoom100.Text = "Zoom 100%";
            this.btnZoom100.UseVisualStyleBackColor = false;
            this.btnZoom100.Click += new System.EventHandler(this.btnZoom100_Click);
            // 
            // btZoomOut
            // 
            this.btZoomOut.BackColor = System.Drawing.SystemColors.Control;
            this.btZoomOut.Cursor = System.Windows.Forms.Cursors.Default;
            this.btZoomOut.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btZoomOut.Location = new System.Drawing.Point(242, 35);
            this.btZoomOut.Name = "btZoomOut";
            this.btZoomOut.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btZoomOut.Size = new System.Drawing.Size(20, 19);
            this.btZoomOut.TabIndex = 25;
            this.btZoomOut.Text = "-";
            this.btZoomOut.UseVisualStyleBackColor = false;
            this.btZoomOut.Click += new System.EventHandler(this.btZoomOut_Click);
            // 
            // btZoomIn
            // 
            this.btZoomIn.BackColor = System.Drawing.SystemColors.Control;
            this.btZoomIn.Cursor = System.Windows.Forms.Cursors.Default;
            this.btZoomIn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btZoomIn.Location = new System.Drawing.Point(308, 35);
            this.btZoomIn.Name = "btZoomIn";
            this.btZoomIn.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btZoomIn.Size = new System.Drawing.Size(20, 19);
            this.btZoomIn.TabIndex = 24;
            this.btZoomIn.Text = "+";
            this.btZoomIn.UseVisualStyleBackColor = false;
            this.btZoomIn.Click += new System.EventHandler(this.btZoomIn_Click);
            // 
            // txtZoom
            // 
            this.txtZoom.AcceptsReturn = true;
            this.txtZoom.BackColor = System.Drawing.SystemColors.Window;
            this.txtZoom.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtZoom.Enabled = false;
            this.txtZoom.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtZoom.Location = new System.Drawing.Point(264, 34);
            this.txtZoom.MaxLength = 0;
            this.txtZoom.Name = "txtZoom";
            this.txtZoom.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtZoom.Size = new System.Drawing.Size(40, 21);
            this.txtZoom.TabIndex = 23;
            this.txtZoom.Text = "100";
            // 
            // btNextPage
            // 
            this.btNextPage.BackColor = System.Drawing.SystemColors.Control;
            this.btNextPage.Cursor = System.Windows.Forms.Cursors.Default;
            this.btNextPage.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btNextPage.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btNextPage.Location = new System.Drawing.Point(164, 32);
            this.btNextPage.Name = "btNextPage";
            this.btNextPage.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btNextPage.Size = new System.Drawing.Size(29, 24);
            this.btNextPage.TabIndex = 21;
            this.btNextPage.Text = ">";
            this.btNextPage.UseVisualStyleBackColor = false;
            this.btNextPage.Click += new System.EventHandler(this.btNextPage_Click);
            // 
            // btlastpage
            // 
            this.btlastpage.BackColor = System.Drawing.SystemColors.Control;
            this.btlastpage.Cursor = System.Windows.Forms.Cursors.Default;
            this.btlastpage.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btlastpage.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btlastpage.Location = new System.Drawing.Point(192, 32);
            this.btlastpage.Name = "btlastpage";
            this.btlastpage.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btlastpage.Size = new System.Drawing.Size(29, 24);
            this.btlastpage.TabIndex = 19;
            this.btlastpage.Text = ">>";
            this.btlastpage.UseVisualStyleBackColor = false;
            this.btlastpage.Click += new System.EventHandler(this.btnLastpage_Click);
            // 
            // btPreviousPage
            // 
            this.btPreviousPage.BackColor = System.Drawing.SystemColors.Control;
            this.btPreviousPage.Cursor = System.Windows.Forms.Cursors.Default;
            this.btPreviousPage.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btPreviousPage.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btPreviousPage.Location = new System.Drawing.Point(96, 31);
            this.btPreviousPage.Name = "btPreviousPage";
            this.btPreviousPage.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btPreviousPage.Size = new System.Drawing.Size(29, 24);
            this.btPreviousPage.TabIndex = 22;
            this.btPreviousPage.Text = "<";
            this.btPreviousPage.UseVisualStyleBackColor = false;
            this.btPreviousPage.Click += new System.EventHandler(this.btnPreviousPage_Click);
            // 
            // btFirstpage
            // 
            this.btFirstpage.BackColor = System.Drawing.SystemColors.Control;
            this.btFirstpage.Cursor = System.Windows.Forms.Cursors.Default;
            this.btFirstpage.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btFirstpage.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btFirstpage.Location = new System.Drawing.Point(67, 31);
            this.btFirstpage.Name = "btFirstpage";
            this.btFirstpage.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btFirstpage.Size = new System.Drawing.Size(29, 24);
            this.btFirstpage.TabIndex = 20;
            this.btFirstpage.Text = "<<";
            this.btFirstpage.UseVisualStyleBackColor = false;
            this.btFirstpage.Click += new System.EventHandler(this.btFirstpage_Click);
            // 
            // lbPos
            // 
            this.lbPos.AutoSize = true;
            this.lbPos.BackColor = System.Drawing.Color.Transparent;
            this.lbPos.Cursor = System.Windows.Forms.Cursors.Default;
            this.lbPos.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbPos.Location = new System.Drawing.Point(385, 38);
            this.lbPos.Name = "lbPos";
            this.lbPos.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbPos.Size = new System.Drawing.Size(32, 15);
            this.lbPos.TabIndex = 28;
            this.lbPos.Text = "(0,0)";
            this.lbPos.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblxy
            // 
            this.lblxy.AutoSize = true;
            this.lblxy.BackColor = System.Drawing.Color.Transparent;
            this.lblxy.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblxy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblxy.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblxy.Location = new System.Drawing.Point(355, 39);
            this.lblxy.Name = "lblxy";
            this.lblxy.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblxy.Size = new System.Drawing.Size(27, 13);
            this.lblxy.TabIndex = 27;
            this.lblxy.Text = "X,Y";
            // 
            // lbPage
            // 
            this.lbPage.AutoSize = true;
            this.lbPage.BackColor = System.Drawing.Color.Transparent;
            this.lbPage.Cursor = System.Windows.Forms.Cursors.Default;
            this.lbPage.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbPage.Location = new System.Drawing.Point(421, 38);
            this.lbPage.Name = "lbPage";
            this.lbPage.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbPage.Size = new System.Drawing.Size(24, 15);
            this.lbPage.TabIndex = 26;
            this.lbPage.Text = "0/0";
            this.lbPage.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lbPage.Visible = false;
            // 
            // lblPdfPath
            // 
            this.lblPdfPath.AutoSize = true;
            this.lblPdfPath.Location = new System.Drawing.Point(6, 8);
            this.lblPdfPath.Name = "lblPdfPath";
            this.lblPdfPath.Size = new System.Drawing.Size(53, 15);
            this.lblPdfPath.TabIndex = 41;
            this.lblPdfPath.Text = "Pdf Path";
            // 
            // btnZoomWidth
            // 
            this.btnZoomWidth.BackColor = System.Drawing.SystemColors.Control;
            this.btnZoomWidth.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnZoomWidth.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnZoomWidth.Location = new System.Drawing.Point(626, 32);
            this.btnZoomWidth.Name = "btnZoomWidth";
            this.btnZoomWidth.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnZoomWidth.Size = new System.Drawing.Size(88, 22);
            this.btnZoomWidth.TabIndex = 29;
            this.btnZoomWidth.Text = "Zoom Width";
            this.btnZoomWidth.UseVisualStyleBackColor = false;
            this.btnZoomWidth.Click += new System.EventHandler(this.btnZoomWidth_Click);
            // 
            // pnlTANDtls
            // 
            this.pnlTANDtls.BackColor = System.Drawing.Color.FloralWhite;
            this.pnlTANDtls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTANDtls.Controls.Add(this.txtDOI);
            this.pnlTANDtls.Controls.Add(this.txtTANType);
            this.pnlTANDtls.Controls.Add(this.lblTANType);
            this.pnlTANDtls.Controls.Add(this.txtCAN);
            this.pnlTANDtls.Controls.Add(this.lblTan);
            this.pnlTANDtls.Controls.Add(this.txtTAN);
            this.pnlTANDtls.Controls.Add(this.lblCan);
            this.pnlTANDtls.Controls.Add(this.lblDOI);
            this.pnlTANDtls.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTANDtls.Location = new System.Drawing.Point(0, 0);
            this.pnlTANDtls.Name = "pnlTANDtls";
            this.pnlTANDtls.Size = new System.Drawing.Size(1047, 28);
            this.pnlTANDtls.TabIndex = 44;
            // 
            // txtDOI
            // 
            this.txtDOI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.txtDOI.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDOI.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtDOI.Location = new System.Drawing.Point(490, 2);
            this.txtDOI.Name = "txtDOI";
            this.txtDOI.ReadOnly = true;
            this.txtDOI.Size = new System.Drawing.Size(249, 22);
            this.txtDOI.TabIndex = 6;
            this.txtDOI.TabStop = false;
            // 
            // txtTANType
            // 
            this.txtTANType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.txtTANType.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTANType.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtTANType.Location = new System.Drawing.Point(358, 2);
            this.txtTANType.Name = "txtTANType";
            this.txtTANType.ReadOnly = true;
            this.txtTANType.Size = new System.Drawing.Size(99, 22);
            this.txtTANType.TabIndex = 5;
            this.txtTANType.TabStop = false;
            // 
            // lblTANType
            // 
            this.lblTANType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTANType.AutoSize = true;
            this.lblTANType.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTANType.ForeColor = System.Drawing.Color.Blue;
            this.lblTANType.Location = new System.Drawing.Point(322, 5);
            this.lblTANType.Name = "lblTANType";
            this.lblTANType.Size = new System.Drawing.Size(33, 15);
            this.lblTANType.TabIndex = 4;
            this.lblTANType.Text = "Type";
            // 
            // txtCAN
            // 
            this.txtCAN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.txtCAN.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCAN.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtCAN.Location = new System.Drawing.Point(184, 2);
            this.txtCAN.Name = "txtCAN";
            this.txtCAN.ReadOnly = true;
            this.txtCAN.Size = new System.Drawing.Size(111, 22);
            this.txtCAN.TabIndex = 2;
            this.txtCAN.TabStop = false;
            // 
            // lblTan
            // 
            this.lblTan.AutoSize = true;
            this.lblTan.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTan.ForeColor = System.Drawing.Color.Blue;
            this.lblTan.Location = new System.Drawing.Point(5, 6);
            this.lblTan.Name = "lblTan";
            this.lblTan.Size = new System.Drawing.Size(29, 15);
            this.lblTan.TabIndex = 1;
            this.lblTan.Text = "TAN";
            // 
            // txtTAN
            // 
            this.txtTAN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.txtTAN.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTAN.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtTAN.Location = new System.Drawing.Point(40, 2);
            this.txtTAN.Name = "txtTAN";
            this.txtTAN.ReadOnly = true;
            this.txtTAN.Size = new System.Drawing.Size(106, 22);
            this.txtTAN.TabIndex = 1;
            this.txtTAN.TabStop = false;
            // 
            // lblCan
            // 
            this.lblCan.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCan.AutoSize = true;
            this.lblCan.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCan.ForeColor = System.Drawing.Color.Blue;
            this.lblCan.Location = new System.Drawing.Point(149, 5);
            this.lblCan.Name = "lblCan";
            this.lblCan.Size = new System.Drawing.Size(31, 15);
            this.lblCan.TabIndex = 2;
            this.lblCan.Text = "CAN";
            // 
            // lblDOI
            // 
            this.lblDOI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDOI.AutoSize = true;
            this.lblDOI.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDOI.ForeColor = System.Drawing.Color.Blue;
            this.lblDOI.Location = new System.Drawing.Point(461, 5);
            this.lblDOI.Name = "lblDOI";
            this.lblDOI.Size = new System.Drawing.Size(27, 15);
            this.lblDOI.TabIndex = 3;
            this.lblDOI.Text = "DOI";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "DocID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "PAGE_SIZE_X";
            this.dataGridViewTextBoxColumn2.HeaderText = "DocNo";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Visible = false;
            this.dataGridViewTextBoxColumn2.Width = 50;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn3.DataPropertyName = "PAGE_SIZE_Y";
            this.dataGridViewTextBoxColumn3.HeaderText = "DocName";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Visible = false;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "DocNo";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 50;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn5.HeaderText = "DocName";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // frmNarrCuration_New
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1244, 564);
            this.Controls.Add(this.splCntTreeViewAndTool);
            this.Controls.Add(this.pnlBottom);
            this.KeyPreview = true;
            this.Name = "frmNarrCuration_New";
            this.ShowIcon = false;
            this.Text = "Narratives Curation";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmNarrCuration_New_FormClosing);
            this.Load += new System.EventHandler(this.frmNarrCuration_New_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmNarrCuration_New_KeyDown);
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.splCntTreeViewAndTool.Panel1.ResumeLayout(false);
            this.splCntTreeViewAndTool.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splCntTreeViewAndTool)).EndInit();
            this.splCntTreeViewAndTool.ResumeLayout(false);
            this.splCntTreeviewDocs.Panel1.ResumeLayout(false);
            this.splCntTreeviewDocs.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splCntTreeviewDocs)).EndInit();
            this.splCntTreeviewDocs.ResumeLayout(false);
            this.pnlNavigCntrls.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numGotoRecord)).EndInit();
            this.pnlSearchRxn.ResumeLayout(false);
            this.pnlSearchRxn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTANDocuments)).EndInit();
            this.tcTool_CoOrdinates.ResumeLayout(false);
            this.tpCuration.ResumeLayout(false);
            this.pnlUserControl.ResumeLayout(false);
            this.pnlSplChars.ResumeLayout(false);
            this.tpCoOrdinates.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gdViewer)).EndInit();
            this.pnlCoOrdinateCntls.ResumeLayout(false);
            this.pnlCoOrdinateCntls.PerformLayout();
            this.pnlTANDtls.ResumeLayout(false);
            this.pnlTANDtls.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.CheckBox chkRxnComplete;
        private System.Windows.Forms.Button btnExportToPdf;
        private System.Windows.Forms.LinkLabel lnlerrors;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnExportToExcel;
        private System.Windows.Forms.Label lblRxnCountValue;
        private System.Windows.Forms.Label lblRxnCount;
        private System.Windows.Forms.SplitContainer splCntTreeViewAndTool;
        private System.Windows.Forms.SplitContainer splCntTreeviewDocs;
        private System.Windows.Forms.TreeView tvReactions;
        private System.Windows.Forms.DataGridView dgvTANDocuments;
        private System.Windows.Forms.Label lblTANDocs;
        private HtmlRichText.HtmlRichTextBox rtfformula;
        private System.Windows.Forms.TabControl tcTool_CoOrdinates;
        private System.Windows.Forms.TabPage tpCuration;
        private System.Windows.Forms.Panel pnlUserControl;
        private System.Windows.Forms.Panel pnlSplChars;
        private System.Windows.Forms.TabPage tpCoOrdinates;
        private System.Windows.Forms.Panel pnlCoOrdinateCntls;
        public System.Windows.Forms.Button btnBrowseCood;
        private System.Windows.Forms.TextBox txtbrowsecoordinates;
        private System.Windows.Forms.TextBox txtGoToPdfPage;
        public System.Windows.Forms.Button btnPageSize;
        public System.Windows.Forms.Button btnZoomOnArea;
        public System.Windows.Forms.Button btnZoomFit;
        public System.Windows.Forms.Button btnZoom100;
        public System.Windows.Forms.Button btZoomOut;
        public System.Windows.Forms.Button btZoomIn;
        public System.Windows.Forms.TextBox txtZoom;
        public System.Windows.Forms.Button btNextPage;
        public System.Windows.Forms.Button btlastpage;
        public System.Windows.Forms.Button btPreviousPage;
        public System.Windows.Forms.Button btFirstpage;
        public System.Windows.Forms.Label lbPos;
        public System.Windows.Forms.Label lblxy;
        public System.Windows.Forms.Label lbPage;
        private System.Windows.Forms.Label lblPdfPath;
        public System.Windows.Forms.Button btnZoomWidth;
        internal AxGdViewerPro4.AxGdViewer gdViewer;
        private System.Windows.Forms.Panel pnlTANDtls;
        private System.Windows.Forms.TextBox txtTANType;
        private System.Windows.Forms.Label lblTANType;
        private System.Windows.Forms.TextBox txtCAN;
        private System.Windows.Forms.Label lblTan;
        private System.Windows.Forms.TextBox txtTAN;
        private System.Windows.Forms.Label lblCan;
        private System.Windows.Forms.Label lblDOI;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.Panel pnlSearchRxn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSrchProduct;
        private System.Windows.Forms.TextBox txtDOI;
        private System.Windows.Forms.Label lblSaveStatus;
        public ucNarCuration ucNarCuration1;
        private System.Windows.Forms.Button btnTANComplete;
        private System.Windows.Forms.Button btnRejectTAN;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDocID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDocPageSizeX;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDocPageSizeY;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDocNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDocName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.ImageList imageList1;
        private UserControls.ucSplCharsToolStrip_Indexing ucSplCharsToolStrip_Indexing1;
        private System.Windows.Forms.Button btnExportToText;
        private System.Windows.Forms.Button btnFindReplace;
        private System.Windows.Forms.Button btnHideSplChars;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Panel pnlNavigCntrls;
        public System.Windows.Forms.NumericUpDown numGotoRecord;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.Button btnTANReport;
    }
}