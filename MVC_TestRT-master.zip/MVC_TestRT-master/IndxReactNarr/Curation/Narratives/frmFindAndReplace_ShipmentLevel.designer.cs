﻿namespace IndxReactNarr.Curation.Narratives
{
    partial class frmFindAndReplace_ShipmentLevel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.splContMain = new System.Windows.Forms.SplitContainer();
            this.pnlchcklst = new System.Windows.Forms.Panel();
            this.chklstTANs = new System.Windows.Forms.CheckedListBox();
            this.pnlsrch = new System.Windows.Forms.Panel();
            this.lblTAN = new System.Windows.Forms.Label();
            this.txtTANSrch = new System.Windows.Forms.TextBox();
            this.pnlTxtGridCntrls = new System.Windows.Forms.Panel();
            this.dgvSrchResults = new System.Windows.Forms.DataGridView();
            this.colSelect = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colTAN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnSNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colField = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFieldValue = new DataGridViewRichTextBox.DataGridViewRichTextBoxColumn();
            this.pnlControls = new System.Windows.Forms.Panel();
            this.btnReplace = new System.Windows.Forms.Button();
            this.lblReplace = new System.Windows.Forms.Label();
            this.ucHrtbReplace = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.btnFind = new System.Windows.Forms.Button();
            this.lblFind = new System.Windows.Forms.Label();
            this.ucHrtbFind = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.ucSplCharsToolStrip_Indexing1 = new IndxReactNarr.UserControls.ucSplCharsToolStrip_Indexing();
            this.pnlShipmentName = new System.Windows.Forms.Panel();
            this.btnHideSplChars = new System.Windows.Forms.Button();
            this.btnGetList = new System.Windows.Forms.Button();
            this.lblBNo = new System.Windows.Forms.Label();
            this.txtBNo = new System.Windows.Forms.TextBox();
            this.lblBatch = new System.Windows.Forms.Label();
            this.txtShipmentName = new System.Windows.Forms.TextBox();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.chkSelectAll = new System.Windows.Forms.CheckBox();
            this.lblStatusValue = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewAutoFilterTextBoxColumn1 = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewRichTextBoxColumn1 = new DataGridViewRichTextBox.DataGridViewRichTextBoxColumn();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splContMain)).BeginInit();
            this.splContMain.Panel1.SuspendLayout();
            this.splContMain.Panel2.SuspendLayout();
            this.splContMain.SuspendLayout();
            this.pnlchcklst.SuspendLayout();
            this.pnlsrch.SuspendLayout();
            this.pnlTxtGridCntrls.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSrchResults)).BeginInit();
            this.pnlControls.SuspendLayout();
            this.pnlShipmentName.SuspendLayout();
            this.pnlBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.splContMain);
            this.pnlMain.Controls.Add(this.pnlShipmentName);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(933, 490);
            this.pnlMain.TabIndex = 0;
            // 
            // splContMain
            // 
            this.splContMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splContMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContMain.Location = new System.Drawing.Point(0, 33);
            this.splContMain.Name = "splContMain";
            this.splContMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splContMain.Panel1
            // 
            this.splContMain.Panel1.Controls.Add(this.pnlchcklst);
            this.splContMain.Panel1.Controls.Add(this.pnlsrch);
            // 
            // splContMain.Panel2
            // 
            this.splContMain.Panel2.Controls.Add(this.pnlTxtGridCntrls);
            this.splContMain.Panel2.Controls.Add(this.ucSplCharsToolStrip_Indexing1);
            this.splContMain.Size = new System.Drawing.Size(933, 429);
            this.splContMain.SplitterDistance = 121;
            this.splContMain.SplitterWidth = 3;
            this.splContMain.TabIndex = 5;
            // 
            // pnlchcklst
            // 
            this.pnlchcklst.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlchcklst.Controls.Add(this.chklstTANs);
            this.pnlchcklst.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlchcklst.Location = new System.Drawing.Point(0, 30);
            this.pnlchcklst.Name = "pnlchcklst";
            this.pnlchcklst.Size = new System.Drawing.Size(931, 89);
            this.pnlchcklst.TabIndex = 2;
            // 
            // chklstTANs
            // 
            this.chklstTANs.CheckOnClick = true;
            this.chklstTANs.ColumnWidth = 110;
            this.chklstTANs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chklstTANs.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chklstTANs.FormattingEnabled = true;
            this.chklstTANs.Location = new System.Drawing.Point(0, 0);
            this.chklstTANs.MultiColumn = true;
            this.chklstTANs.Name = "chklstTANs";
            this.chklstTANs.ScrollAlwaysVisible = true;
            this.chklstTANs.Size = new System.Drawing.Size(929, 87);
            this.chklstTANs.TabIndex = 66;
            this.chklstTANs.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chklstTANs_ItemCheck);
            // 
            // pnlsrch
            // 
            this.pnlsrch.Controls.Add(this.lblTAN);
            this.pnlsrch.Controls.Add(this.txtTANSrch);
            this.pnlsrch.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlsrch.Location = new System.Drawing.Point(0, 0);
            this.pnlsrch.Name = "pnlsrch";
            this.pnlsrch.Size = new System.Drawing.Size(931, 30);
            this.pnlsrch.TabIndex = 1;
            // 
            // lblTAN
            // 
            this.lblTAN.AutoSize = true;
            this.lblTAN.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTAN.Location = new System.Drawing.Point(5, 6);
            this.lblTAN.Name = "lblTAN";
            this.lblTAN.Size = new System.Drawing.Size(83, 17);
            this.lblTAN.TabIndex = 12;
            this.lblTAN.Text = "TAN Search";
            // 
            // txtTANSrch
            // 
            this.txtTANSrch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTANSrch.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.txtTANSrch.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTANSrch.ForeColor = System.Drawing.Color.Blue;
            this.txtTANSrch.Location = new System.Drawing.Point(88, 2);
            this.txtTANSrch.Name = "txtTANSrch";
            this.txtTANSrch.Size = new System.Drawing.Size(840, 25);
            this.txtTANSrch.TabIndex = 11;
            // 
            // pnlTxtGridCntrls
            // 
            this.pnlTxtGridCntrls.Controls.Add(this.dgvSrchResults);
            this.pnlTxtGridCntrls.Controls.Add(this.pnlControls);
            this.pnlTxtGridCntrls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTxtGridCntrls.Location = new System.Drawing.Point(0, 74);
            this.pnlTxtGridCntrls.Name = "pnlTxtGridCntrls";
            this.pnlTxtGridCntrls.Size = new System.Drawing.Size(931, 229);
            this.pnlTxtGridCntrls.TabIndex = 3;
            // 
            // dgvSrchResults
            // 
            this.dgvSrchResults.AllowUserToAddRows = false;
            this.dgvSrchResults.AllowUserToDeleteRows = false;
            this.dgvSrchResults.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvSrchResults.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSrchResults.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSelect,
            this.colTAN,
            this.colRxnID,
            this.colRxnSNo,
            this.colField,
            this.colFieldValue});
            this.dgvSrchResults.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSrchResults.Location = new System.Drawing.Point(0, 86);
            this.dgvSrchResults.Name = "dgvSrchResults";
            this.dgvSrchResults.RowTemplate.Height = 60;
            this.dgvSrchResults.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSrchResults.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSrchResults.Size = new System.Drawing.Size(931, 143);
            this.dgvSrchResults.TabIndex = 2;
            this.dgvSrchResults.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgvSrchResults_DataBindingComplete);
            this.dgvSrchResults.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvSrchResults_RowPostPaint);
            // 
            // colSelect
            // 
            this.colSelect.FalseValue = "FALSE";
            this.colSelect.HeaderText = "";
            this.colSelect.Name = "colSelect";
            this.colSelect.ToolTipText = "Select";
            this.colSelect.TrueValue = "TRUE";
            this.colSelect.Width = 40;
            // 
            // colTAN
            // 
            this.colTAN.HeaderText = "TAN";
            this.colTAN.Name = "colTAN";
            this.colTAN.ReadOnly = true;
            this.colTAN.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colTAN.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // colRxnID
            // 
            this.colRxnID.HeaderText = "RxnID";
            this.colRxnID.Name = "colRxnID";
            this.colRxnID.ReadOnly = true;
            this.colRxnID.Visible = false;
            // 
            // colRxnSNo
            // 
            this.colRxnSNo.HeaderText = "RxnNo";
            this.colRxnSNo.Name = "colRxnSNo";
            this.colRxnSNo.ReadOnly = true;
            this.colRxnSNo.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colRxnSNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colRxnSNo.Width = 60;
            // 
            // colField
            // 
            this.colField.HeaderText = "Field";
            this.colField.Name = "colField";
            this.colField.ReadOnly = true;
            this.colField.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colField.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colFieldValue
            // 
            this.colFieldValue.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colFieldValue.DefaultCellStyle = dataGridViewCellStyle1;
            this.colFieldValue.HeaderText = "FieldValue";
            this.colFieldValue.Name = "colFieldValue";
            this.colFieldValue.ReadOnly = true;
            this.colFieldValue.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // pnlControls
            // 
            this.pnlControls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlControls.Controls.Add(this.btnReplace);
            this.pnlControls.Controls.Add(this.lblReplace);
            this.pnlControls.Controls.Add(this.ucHrtbReplace);
            this.pnlControls.Controls.Add(this.btnFind);
            this.pnlControls.Controls.Add(this.lblFind);
            this.pnlControls.Controls.Add(this.ucHrtbFind);
            this.pnlControls.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlControls.Location = new System.Drawing.Point(0, 0);
            this.pnlControls.Name = "pnlControls";
            this.pnlControls.Size = new System.Drawing.Size(931, 86);
            this.pnlControls.TabIndex = 1;
            // 
            // btnReplace
            // 
            this.btnReplace.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReplace.Location = new System.Drawing.Point(851, 51);
            this.btnReplace.Name = "btnReplace";
            this.btnReplace.Size = new System.Drawing.Size(75, 27);
            this.btnReplace.TabIndex = 5;
            this.btnReplace.Text = "Replace";
            this.btnReplace.UseVisualStyleBackColor = true;
            this.btnReplace.Click += new System.EventHandler(this.btnReplace_Click);
            // 
            // lblReplace
            // 
            this.lblReplace.AutoSize = true;
            this.lblReplace.Location = new System.Drawing.Point(1, 47);
            this.lblReplace.Name = "lblReplace";
            this.lblReplace.Size = new System.Drawing.Size(56, 17);
            this.lblReplace.TabIndex = 4;
            this.lblReplace.Text = "Replace";
            // 
            // ucHrtbReplace
            // 
            this.ucHrtbReplace.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ucHrtbReplace.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ucHrtbReplace.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ucHrtbReplace.HighlightMaterials = false;
            this.ucHrtbReplace.Location = new System.Drawing.Point(59, 43);
            this.ucHrtbReplace.Name = "ucHrtbReplace";
            this.ucHrtbReplace.PreserveMultiLines = false;
            this.ucHrtbReplace.Size = new System.Drawing.Size(786, 39);
            this.ucHrtbReplace.TabIndex = 1;
            // 
            // btnFind
            // 
            this.btnFind.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFind.Location = new System.Drawing.Point(851, 9);
            this.btnFind.Name = "btnFind";
            this.btnFind.Size = new System.Drawing.Size(75, 27);
            this.btnFind.TabIndex = 2;
            this.btnFind.Text = "Find";
            this.btnFind.UseVisualStyleBackColor = true;
            this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
            // 
            // lblFind
            // 
            this.lblFind.AutoSize = true;
            this.lblFind.Location = new System.Drawing.Point(24, 5);
            this.lblFind.Name = "lblFind";
            this.lblFind.Size = new System.Drawing.Size(33, 17);
            this.lblFind.TabIndex = 1;
            this.lblFind.Text = "Find";
            // 
            // ucHrtbFind
            // 
            this.ucHrtbFind.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ucHrtbFind.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ucHrtbFind.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ucHrtbFind.HighlightMaterials = false;
            this.ucHrtbFind.Location = new System.Drawing.Point(59, 2);
            this.ucHrtbFind.Name = "ucHrtbFind";
            this.ucHrtbFind.PreserveMultiLines = false;
            this.ucHrtbFind.Size = new System.Drawing.Size(786, 39);
            this.ucHrtbFind.TabIndex = 0;
            // 
            // ucSplCharsToolStrip_Indexing1
            // 
            this.ucSplCharsToolStrip_Indexing1.BackColor = System.Drawing.Color.White;
            this.ucSplCharsToolStrip_Indexing1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ucSplCharsToolStrip_Indexing1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ucSplCharsToolStrip_Indexing1.Location = new System.Drawing.Point(0, 0);
            this.ucSplCharsToolStrip_Indexing1.Name = "ucSplCharsToolStrip_Indexing1";
            this.ucSplCharsToolStrip_Indexing1.Size = new System.Drawing.Size(931, 74);
            this.ucSplCharsToolStrip_Indexing1.TabIndex = 0;
            this.ucSplCharsToolStrip_Indexing1.Visible = false;
            // 
            // pnlShipmentName
            // 
            this.pnlShipmentName.BackColor = System.Drawing.Color.White;
            this.pnlShipmentName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlShipmentName.Controls.Add(this.btnHideSplChars);
            this.pnlShipmentName.Controls.Add(this.btnGetList);
            this.pnlShipmentName.Controls.Add(this.lblBNo);
            this.pnlShipmentName.Controls.Add(this.txtBNo);
            this.pnlShipmentName.Controls.Add(this.lblBatch);
            this.pnlShipmentName.Controls.Add(this.txtShipmentName);
            this.pnlShipmentName.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlShipmentName.Location = new System.Drawing.Point(0, 0);
            this.pnlShipmentName.Name = "pnlShipmentName";
            this.pnlShipmentName.Size = new System.Drawing.Size(933, 33);
            this.pnlShipmentName.TabIndex = 4;
            // 
            // btnHideSplChars
            // 
            this.btnHideSplChars.Image = global::IndxReactNarr.Properties.Resources.control_panel;
            this.btnHideSplChars.Location = new System.Drawing.Point(563, 3);
            this.btnHideSplChars.Name = "btnHideSplChars";
            this.btnHideSplChars.Size = new System.Drawing.Size(30, 24);
            this.btnHideSplChars.TabIndex = 61;
            this.btnHideSplChars.TabStop = false;
            this.btnHideSplChars.UseVisualStyleBackColor = true;
            this.btnHideSplChars.Click += new System.EventHandler(this.btnHideSplChars_Click);
            // 
            // btnGetList
            // 
            this.btnGetList.AutoSize = true;
            this.btnGetList.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGetList.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnGetList.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGetList.Location = new System.Drawing.Point(448, 2);
            this.btnGetList.Name = "btnGetList";
            this.btnGetList.Size = new System.Drawing.Size(94, 25);
            this.btnGetList.TabIndex = 13;
            this.btnGetList.Text = "Get List";
            this.btnGetList.UseVisualStyleBackColor = true;
            this.btnGetList.Click += new System.EventHandler(this.btnGetList_Click);
            // 
            // lblBNo
            // 
            this.lblBNo.AutoSize = true;
            this.lblBNo.Location = new System.Drawing.Point(324, 7);
            this.lblBNo.Name = "lblBNo";
            this.lblBNo.Size = new System.Drawing.Size(69, 17);
            this.lblBNo.TabIndex = 14;
            this.lblBNo.Text = "Batch No.";
            // 
            // txtBNo
            // 
            this.txtBNo.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBNo.ForeColor = System.Drawing.Color.Blue;
            this.txtBNo.Location = new System.Drawing.Point(394, 3);
            this.txtBNo.Name = "txtBNo";
            this.txtBNo.Size = new System.Drawing.Size(36, 25);
            this.txtBNo.TabIndex = 12;
            this.txtBNo.Text = "1";
            this.txtBNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblBatch
            // 
            this.lblBatch.AutoSize = true;
            this.lblBatch.Location = new System.Drawing.Point(5, 6);
            this.lblBatch.Name = "lblBatch";
            this.lblBatch.Size = new System.Drawing.Size(62, 17);
            this.lblBatch.TabIndex = 11;
            this.lblBatch.Text = "Shipment";
            // 
            // txtShipmentName
            // 
            this.txtShipmentName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShipmentName.ForeColor = System.Drawing.Color.Blue;
            this.txtShipmentName.Location = new System.Drawing.Point(87, 2);
            this.txtShipmentName.Name = "txtShipmentName";
            this.txtShipmentName.Size = new System.Drawing.Size(231, 25);
            this.txtShipmentName.TabIndex = 9;
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom.Controls.Add(this.chkSelectAll);
            this.pnlBottom.Controls.Add(this.lblStatusValue);
            this.pnlBottom.Controls.Add(this.lblStatus);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 462);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(933, 28);
            this.pnlBottom.TabIndex = 3;
            // 
            // chkSelectAll
            // 
            this.chkSelectAll.AutoSize = true;
            this.chkSelectAll.Location = new System.Drawing.Point(4, 3);
            this.chkSelectAll.Name = "chkSelectAll";
            this.chkSelectAll.Size = new System.Drawing.Size(83, 21);
            this.chkSelectAll.TabIndex = 2;
            this.chkSelectAll.Text = "Select All";
            this.chkSelectAll.UseVisualStyleBackColor = true;
            this.chkSelectAll.CheckStateChanged += new System.EventHandler(this.chkSelectAll_CheckStateChanged);
            // 
            // lblStatusValue
            // 
            this.lblStatusValue.AutoSize = true;
            this.lblStatusValue.ForeColor = System.Drawing.Color.Blue;
            this.lblStatusValue.Location = new System.Drawing.Point(189, 5);
            this.lblStatusValue.Name = "lblStatusValue";
            this.lblStatusValue.Size = new System.Drawing.Size(18, 17);
            this.lblStatusValue.TabIndex = 1;
            this.lblStatusValue.Text = "--";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(134, 5);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(51, 17);
            this.lblStatus.TabIndex = 0;
            this.lblStatus.Text = "Status: ";
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.FalseValue = "FALSE";
            this.dataGridViewCheckBoxColumn1.HeaderText = "Select";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            this.dataGridViewCheckBoxColumn1.TrueValue = "TRUE";
            this.dataGridViewCheckBoxColumn1.Width = 40;
            // 
            // dataGridViewAutoFilterTextBoxColumn1
            // 
            this.dataGridViewAutoFilterTextBoxColumn1.HeaderText = "TAN";
            this.dataGridViewAutoFilterTextBoxColumn1.Name = "dataGridViewAutoFilterTextBoxColumn1";
            this.dataGridViewAutoFilterTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "RxnID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "RxnNo";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Field";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewRichTextBoxColumn1
            // 
            this.dataGridViewRichTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewRichTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewRichTextBoxColumn1.HeaderText = "FieldValue";
            this.dataGridViewRichTextBoxColumn1.Name = "dataGridViewRichTextBoxColumn1";
            this.dataGridViewRichTextBoxColumn1.ReadOnly = true;
            this.dataGridViewRichTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // frmFindAndReplace_ShipmentLevel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(933, 490);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmFindAndReplace_ShipmentLevel";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Shipment level Find and Replace";
            this.Load += new System.EventHandler(this.frmFindAndReplace_ShipmentLevel_Load);
            this.pnlMain.ResumeLayout(false);
            this.splContMain.Panel1.ResumeLayout(false);
            this.splContMain.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splContMain)).EndInit();
            this.splContMain.ResumeLayout(false);
            this.pnlchcklst.ResumeLayout(false);
            this.pnlsrch.ResumeLayout(false);
            this.pnlsrch.PerformLayout();
            this.pnlTxtGridCntrls.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSrchResults)).EndInit();
            this.pnlControls.ResumeLayout(false);
            this.pnlControls.PerformLayout();
            this.pnlShipmentName.ResumeLayout(false);
            this.pnlShipmentName.PerformLayout();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private UserControls.ucSplCharsToolStrip_Indexing ucSplCharsToolStrip_Indexing1;
        private System.Windows.Forms.Panel pnlControls;
        private System.Windows.Forms.Button btnFind;
        private System.Windows.Forms.Label lblFind;
        private System.Windows.Forms.Label lblReplace;
        private System.Windows.Forms.Button btnReplace;
        private System.Windows.Forms.DataGridView dgvSrchResults;
        public UserControls.ucHtmlRichText ucHrtbFind;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Label lblStatusValue;
        private System.Windows.Forms.Label lblStatus;
        public UserControls.ucHtmlRichText ucHrtbReplace;
        private System.Windows.Forms.CheckBox chkSelectAll;
        private System.Windows.Forms.Panel pnlShipmentName;
        private System.Windows.Forms.Button btnGetList;
        private System.Windows.Forms.Label lblBNo;
        private System.Windows.Forms.TextBox txtBNo;
        private System.Windows.Forms.Label lblBatch;
        private System.Windows.Forms.TextBox txtShipmentName;
        private System.Windows.Forms.SplitContainer splContMain;
        private System.Windows.Forms.Panel pnlsrch;
        private System.Windows.Forms.Label lblTAN;
        private System.Windows.Forms.TextBox txtTANSrch;
        private System.Windows.Forms.Panel pnlchcklst;
        private System.Windows.Forms.CheckedListBox chklstTANs;
        private System.Windows.Forms.Panel pnlTxtGridCntrls;
        private System.Windows.Forms.Button btnHideSplChars;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn dataGridViewAutoFilterTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private DataGridViewRichTextBox.DataGridViewRichTextBoxColumn dataGridViewRichTextBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colSelect;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTAN;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnSNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colField;
        private DataGridViewRichTextBox.DataGridViewRichTextBoxColumn colFieldValue;
    }
}