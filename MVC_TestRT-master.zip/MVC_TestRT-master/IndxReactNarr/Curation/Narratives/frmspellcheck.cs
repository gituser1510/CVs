﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace IndxReactNarr
{
    public partial class frmspellcheck : Form
    {
        public frmspellcheck()
        {
            InitializeComponent();
        }
        private string _rtfdata = "";
        public string RtfData
        {
            get { return _rtfdata; }
            set { _rtfdata = value; }
        }
        private bool _status = false;
        public bool Status
        {
            get { return _status; }
            set { _status = value; }
        }
        private string _txtname = "";
        public string TextBoxName
        {
            get { return _txtname; }
            set { _txtname = value; }
        }
        
        private void frmspellcheck_Load(object sender, EventArgs e)
        {
            
            //Spelled.CustomDictionaryFileName = AppDomain.CurrentDomain.BaseDirectory + "CHCUSTOM.CUD";
            rapidSpellAsYouType1.UserDictionaryFile = AppDomain.CurrentDomain.BaseDirectory + "Dictionary.txt";
            if (RtfData != null && RtfData != "")
            {
                Spelled.Rtf = RtfData;
            }
        }

        private void btnok_Click(object sender, EventArgs e)
        {
            Status = true;
            RtfData = Spelled.Rtf;
            this.Close();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            Status = false;
            this.Close();
        }

        //private void Spelled_MouseDownEvent(object sender, AxChadoSpellEditor.__SpellEditor_MouseDownEvent e)
        //{
            
        //    System.Windows.Forms.ContextMenuStrip ctxmenu = new ContextMenuStrip();
        //    try
        //    {

        //        if (e.button == 2)
        //        {
        //            int mstart = 0;
        //            int mend = 0;
        //            Spelled.GetSelection(ref mstart, ref mend);

        //            Soundex.Soundex.query.Clear();
        //            ctxmenu.Items.Clear();
        //            string strsearch = "";
        //            if (Spelled.SelectedText != null && Spelled.SelectedText != "")
        //            {
        //                strsearch = Spelled.SelectedText;
        //            }
        //            else
        //            {
        //                strsearch = GetString(mstart);
        //            }

        //            Soundex.Soundex.query.CreateSearchTerm("ChemistryWords", strsearch);

        //            var fuzzyResult = Soundex.Soundex.fuzzy.Search(Soundex.Soundex.query, Soundex.Soundex.scope, 10);

        //            ToolStripMenuItem mnuitemignore = new ToolStripMenuItem();
        //            mnuitemignore.Text = "Ignore";
        //            mnuitemignore.Name = "Ignore123";

        //            if (fuzzyResult != null)
        //            {
        //                foreach (var searchResult in fuzzyResult)
        //                {
        //                    string[] split = Soundex.Soundex.chemistry[searchResult.Key].Split(new char[] { ' ' });
        //                    if (split != null && split.Length > 0)
        //                    {
        //                        ToolStripMenuItem mnuitem = new ToolStripMenuItem();
        //                        mnuitem.Text = split[0].ToString();
        //                        mnuitem.Name = split[0].ToString() + System.DateTime.Now.Ticks;
        //                        //mnuitem.Click += new EventHandler(mnuitem_Click);
        //                        ctxmenu.Items.Add(mnuitem);
        //                    }

        //                }
        //            }

        //            ctxmenu.ItemClicked += new ToolStripItemClickedEventHandler(contextMenuStrip1_ItemClicked);
        //            ctxmenu.Items.Add(mnuitemignore);
        //            ctxmenu.Show(Spelled, new System.Drawing.Point(Convert.ToInt32(e.x + 2), Convert.ToInt32(e.y + 50)));

        //            //Spelled.AddWordsToCustom(strsearch);
        //            //Spelled.IgnoreAll(GetString(mstart));
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    finally
        //    {
        //        //ctxmenu.Dispose();
        //    }
            
        //}




        private string GetString(int index)
        {

            string strbacktext = "";
            string strforwartext = "";
            int startpos = 0;
            int endpos = 0;

            if (Spelled.Text != null && Spelled.Text.Length > index)
            {
                for (int i = index; i < Spelled.Text.Length; i--)
                {
                    if (i < 0)
                    {
                        startpos = i + 1;
                        break;
                    }

                    if (Spelled.Text.Substring(i, 1) != " " && Spelled.Text.Substring(i, 1) != "-" && Spelled.Text.Substring(i, 1) != "  " && Spelled.Text.Substring(i, 1) != "[" && Spelled.Text.Substring(i, 1) != "]" && Spelled.Text.Substring(i, 1) != ")" && Spelled.Text.Substring(i, 1) != "(")
                    {
                        strbacktext += Spelled.Text.Substring(i, 1);

                    }
                    else
                    {
                        startpos = i + 1;
                        break;
                    }
                }
                for (int i = index; i < Spelled.Text.Length; i++)
                {

                    if (i > Spelled.Text.Length)
                    {
                        endpos = i + 1;
                        break;
                    }

                    if (Spelled.Text.Substring(i + 1, 1) != " " && Spelled.Text.Substring(i + 1, 1) != "." && Spelled.Text.Substring(i + 1, 1) != "," && Spelled.Text.Substring(i + 1, 1) != "-" && Spelled.Text.Substring(i + 1, 1) != "  " && Spelled.Text.Substring(i + 1, 1) != "[" && Spelled.Text.Substring(i + 1, 1) != "]" && Spelled.Text.Substring(i + 1, 1) != "(" && Spelled.Text.Substring(i + 1, 1) != ")")
                    {
                        strforwartext += Spelled.Text.Substring(i + 1, 1);

                    }
                    else
                    {
                        endpos = i + 1;
                        break;
                    }
                }
                int length = endpos - startpos;
            
                Spelled.Select(startpos, length);
                
                return Spelled.SelectedText.ToString();

            }
            return "";
        }

        private void contextMenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            try
            {
                if (sender != null && e != null)
                {
                    if (e.ClickedItem.Text.ToUpper() != "&IGNORE ALL")
                    {
                        if (Spelled.SelectedText != null && Spelled.SelectedText != "")
                        {

                            Spelled.SelectedText = e.ClickedItem.Text;
                            //Spelled.IgnoreAll(e.ClickedItem.Text);
                           

                        }
                    }
                    else
                    {
                        if (Spelled.SelectedText != null && Spelled.SelectedText != "")
                        {
                            //rapidSpellAsYouType1.RapidSpellChecker.IgnoreAll(Spelled.SelectedText);
                            
                            //Spelled.Refresh();
                        }
                    }

                }
            }
            catch (Exception ex)
            {
              //  ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void Spelled_MouseDown(object sender, MouseEventArgs e)
        {
            

            System.Windows.Forms.ContextMenuStrip ctxmenu = new ContextMenuStrip();
            try
            {

                //if (e.Button==MouseButtons.Right)
                //{

                //    int mstart = 0;
                //    int mend = 0;
                    
                //    mstart = Spelled.GetCharIndexFromPos(new Point(e.X, e.Y));
                //    //MessageBox.Show(i.ToString());
                //    //Spelled.GetSelection(ref mstart, ref mend);

                //    Soundex.Soundex.query.Clear();
                //    ctxmenu.Items.Clear();
                //    string strsearch = "";
                //    if (Spelled.SelectedText != null && Spelled.SelectedText != "")
                //    {
                //        strsearch = Spelled.SelectedText;
                //    }
                //    else
                //    {
                //        //MessageBox.Show("Please select text");
                //        //return;
                //        strsearch = GetString(mstart);
                //    }

                //    Soundex.Soundex.query.CreateSearchTerm("ChemistryWords", strsearch);

                //    var fuzzyResult = Soundex.Soundex.fuzzy.Search(Soundex.Soundex.query, Soundex.Soundex.scope, 10);

             

                //    if (fuzzyResult != null)
                //    {
                //        foreach (var searchResult in fuzzyResult)
                //        {
                //            string[] split = Soundex.Soundex.chemistry[searchResult.Key].Split(new char[] { ' ' });
                //            if (split != null && split.Length > 0)
                //            {
                //                ToolStripMenuItem mnuitem = new ToolStripMenuItem();
                //                mnuitem.Text = split[0].ToString();
                //                mnuitem.Name = split[0].ToString() + System.DateTime.Now.Ticks;
                //                //mnuitem.Click += new EventHandler(mnuitem_Click);
                //                ctxmenu.Items.Add(mnuitem);
                //            }

                //        }
                //    }
                //    ToolStripItem[] suggestions = rapidSpellAsYouType1.GetSuggestionsToolStripItems();
                //    if (suggestions != null)
                //    {
                //        for (int i = 0; i < suggestions.Length; i++)
                //        {
                //            if (suggestions[i].Text.ToUpper() == "&IGNORE ALL")
                //            {
                //                ctxmenu.Items.Add(suggestions[i]);
                //            }
                //            else if (suggestions[i].Text.ToUpper() != "&ALL")
                //            {
                //                ctxmenu.Items.Add(suggestions[i]);
                //            }
                //        }
                //    }

                //    ctxmenu.ItemClicked += new ToolStripItemClickedEventHandler(contextMenuStrip1_ItemClicked);
                //    //ctxmenu.Items.Add(mnuitemignore);
                //    ctxmenu.Show(Spelled, new System.Drawing.Point(Convert.ToInt32(e.X + 2), Convert.ToInt32(e.Y +10)));
                //}
            }
            catch (Exception ex)
            {
               // ErrorHandling.WriteErrorLog(ex.ToString());
            }
          

        }

        //private void rapidSpellAsYouType1_WordIgnored(object sender, Keyoti.RapidSpell.Event.WordIgnoredEventArgs e)
        //{
            
        //}
    }
}
