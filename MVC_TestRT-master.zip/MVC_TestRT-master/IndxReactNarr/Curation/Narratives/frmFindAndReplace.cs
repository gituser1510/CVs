﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using IndxReactNarrBll;
using IndxReactNarrDAL;
using HtmlRichText;
using IndxReactNarr.Common;

namespace IndxReactNarr.Curation.Narratives
{
    public partial class frmFindAndReplace : Form
    {
        public frmFindAndReplace()
        {
            InitializeComponent();
        }

        public DataTable TAN_Reactions_FR { get; set; }

        public DataTable TAN_Findings_FR { get; set; }

        public string TAN_Name { get; set; }
        public int TAN_ID { get; set; }

        private void btnFind_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(ucHrtbFind.hrtbPara.Text.Trim()))
                {
                    Cursor = Cursors.WaitCursor;

                    List<FindReplaceType> lstFindType = GetReplacementCharsList(ucHrtbFind.hrtbPara.Rtf);

                    DataTable dtSrchResults = FindAndReplaceString.FindStringInReactionsInTAN(ucHrtbFind.hrtbPara.Rtf, lstFindType,TAN_Name, TAN_ID, TAN_Reactions_FR, TAN_Findings_FR);

                    //DataTable dtSrchResults = GetFindResultsFromReactionsData(ucHrtbFind.hrtbPara.Rtf);

                    dgvSrchResults.AutoGenerateColumns = false;
                    dgvSrchResults.DataSource = dtSrchResults;
                    colRxnID.DataPropertyName = "RXN_ID";
                    colRxnSNo.DataPropertyName = "NARID";
                    colField.DataPropertyName = "FIELDNAME";
                    colFieldValue.DataPropertyName = "FIELDVALUE";

                    lblStatusValue.Text = dtSrchResults.Rows.Count + " records found";

                    Cursor = Cursors.Default;
                }
            }
            catch (Exception ex)
            {
                Cursor = Cursors.Default;
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public HtmlRichTextBox GetActiveControlFromForm()
        {
            HtmlRichTextBox hrtbActive = null;
            try
            {
                if (ucHrtbFind.hrtbPara.Focused)
                {
                    hrtbActive = ucHrtbFind.hrtbPara;
                }
                else if (ucHrtbReplace.hrtbPara.Focused)
                {
                    hrtbActive = ucHrtbReplace.hrtbPara;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return hrtbActive;
        }      

        private void btnReplace_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;

                FindReplaceBO objFndRepl = GetReplacementRxnsForUpdation();
                if (objFndRepl != null)
                {
                    //Save Reactions id DB
                    if (NarrativesDB.UpdateFindReplaceReactionsData(objFndRepl))
                    {
                        Cursor = Cursors.Default;
                        MessageBox.Show("Updated selected reactions successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        DialogResult = DialogResult.OK;
                        this.Close();
                    }
                    else
                    {
                        Cursor = Cursors.Default;
                        MessageBox.Show("Error in updating selected reactions", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                Cursor = Cursors.Default;
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private List<FindReplaceType> GetReplacementCharsList(string rtfString)
        {
            List<FindReplaceType> fndReplist = new List<FindReplaceType>();
            if (!string.IsNullOrEmpty(rtfString))
            {
                using (HtmlRichTextBox hrtbSrch = new HtmlRichTextBox())
                {
                    hrtbSrch.Rtf = rtfString;

                    if (hrtbSrch.Text.Length > 0)
                    {
                        for (int i = 0; i < hrtbSrch.Text.Length; i++)
                        {
                            hrtbSrch.Select(i, 1);
                            string strrtf = hrtbSrch.SelectedRtf;                            
                            FindReplaceType fr = new FindReplaceType();
                            #region MyRegion
                            //if (strrtf.Contains("\\b"))
                            //{
                            //    fr.IsBold = true;
                            //}
                            //if (strrtf.Contains("\\i"))
                            //{
                            //    fr.IsItalic = true;

                            //}
                            //if (strrtf.Contains("\\super"))
                            //{
                            //    fr.IsSupScr = true;
                            //}
                            //if (strrtf.Contains("\\sub"))
                            //{
                            //    fr.IsSubScr = true;
                            //} 
                            #endregion

                            string html = Html_RtfConversions.Instance.GetHTMLFromRTFString(strrtf);
                            if(html.Contains("<sup>"))
                            {
                                fr.IsSupScr = true;
                            }
                            else if (html.Contains("<sub>"))
                            {
                                fr.IsSubScr = true;
                            }
                            else if (html.Contains("<bold>") && html.Contains("<ital>"))
                            {
                                fr.IsBoldItalic = true;
                            }
                            else if (html.Contains("<bold>"))
                            {
                                fr.IsBold = true;
                            }
                            else if (html.Contains("<ital>"))
                            {
                                fr.IsItalic = true;
                            }

                            fr.CharValue = Convert.ToChar(hrtbSrch.SelectedText);
                            fndReplist.Add(fr);
                        }
                    }
                }
            }
            return fndReplist;
        }

        private FindReplaceBO GetReplacementRxnsForUpdation()
        {
            FindReplaceBO fndRepBll = null;
            try
            {
                if (dgvSrchResults.Rows.Count > 0)
                {
                    List<FindReplaceType> lstFndRepType = GetReplacementCharsList(ucHrtbReplace.hrtbPara.Rtf);

                    string htmlFind = Html_RtfConversions.Instance.GetHTMLFromRTFString(ucHrtbFind.hrtbPara.Rtf);
                    string htmlFindText = ucHrtbFind.hrtbPara.Text;
                    string htmlReplace = Html_RtfConversions.Instance.GetHTMLFromRTFString(ucHrtbReplace.hrtbPara.Rtf);
                    string replaceText = ucHrtbReplace.hrtbPara.Text;

                    fndRepBll = new FindReplaceBO();

                    //Get selected reactions for replace
                    DataTable selRxns = GetSelectedReactionsForReplace();

                    FindAndReplaceString.ReplaceDataInReactions(htmlFindText, replaceText, lstFndRepType, ref selRxns);

                    if (selRxns != null)
                    {                       
                        List<int> lstRxnIDs = new List<int>();
                        List<string> lstField = new List<string>();
                        List<string> lstFieldValue = new List<string>();
                        string replaceValue = "";
                        string fieldName = "";

                        for (int i = 0; i < selRxns.Rows.Count; i++)
                        {
                            fieldName = "";
                            
                            lstRxnIDs.Add(Convert.ToInt32(selRxns.Rows[i]["RXN_ID"]));
                            fieldName = selRxns.Rows[i]["FIELDNAME"].ToString().ToUpper();
                            lstField.Add(fieldName);

                            #region Code commented on 13 July 2015
                            //if (selRxns.Rows[i]["FIELDNAME"].ToString().ToUpper() == "PARA_TEXT")
                            //{
                            //    fieldName = "PARA_TEXT";
                            //}
                            //if (selRxns.Rows[i]["FIELDNAME"].ToString().ToUpper() == "DATA_TEXT")
                            //{
                            //    fieldName = "DATA_TEXT";
                            //}
                            //if (selRxns.Rows[i]["FIELDNAME"].ToString().ToUpper() == "TEXT_LINE")
                            //{
                            //    fieldName = "TEXT_LINE";
                            //}
                            //if (selRxns.Rows[i]["FIELDNAME"].ToString().ToUpper() == "YIELD_TEXT")
                            //{
                            //    fieldName = "YIELD_TEXT";
                            //}
                            //if (selRxns.Rows[i]["FIELDNAME"].ToString().ToUpper() == "PROCEDURE_TEXT")
                            //{
                            //    fieldName = "PROCEDURE_TEXT";
                            //}                            
                            #endregion
                            
                            replaceValue = Html_RtfConversions.Instance.GetHTMLFromRTFString(selRxns.Rows[i]["FIELDVALUE"].ToString());                            
                            lstFieldValue.Add(replaceValue);
                        }

                        fndRepBll.Rxn_IDs = lstRxnIDs;
                        fndRepBll.FieldNames = lstField;
                        fndRepBll.FieldValues = lstFieldValue;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return fndRepBll;
        }

        private DataTable GetSelectedReactionsForReplace()
        {
            DataTable dtSelRxns = null;
            try
            {
                if (dgvSrchResults.Rows.Count > 0)
                {
                    DataTable gridSource = dgvSrchResults.DataSource as DataTable;
                    if (gridSource != null)
                    {
                        dtSelRxns = gridSource.Clone();

                        for (int i = 0; i < dgvSrchResults.Rows.Count; i++)
                        {
                            if (dgvSrchResults.Rows[i].Cells[colSelect.Name].Value != null)
                            {
                                if (dgvSrchResults.Rows[i].Cells[colSelect.Name].Value.ToString().ToUpper() == "TRUE")
                                {
                                    dtSelRxns.ImportRow(gridSource.Rows[i]);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtSelRxns;
        }

        private void dgvSrchResults_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            try
            {
                dgvSrchResults.AutoResizeRows(DataGridViewAutoSizeRowsMode.AllCells);
            }
            catch (Exception ex)
            {                
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvSrchResults_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvSrchResults.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;
                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvSrchResults.Font);
                if (dgvSrchResults.RowHeadersWidth < (int)(size.Width + 20)) dgvSrchResults.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;

                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void chkSelectAll_CheckStateChanged(object sender, EventArgs e)
        {
            try
            {
                bool blStatus = false;
                if (chkSelectAll.Checked)
                {
                    blStatus = true;
                }
                if (dgvSrchResults.Rows.Count > 0)
                {
                    foreach (DataGridViewRow dgRow in dgvSrchResults.Rows)
                    {
                        dgRow.Cells[colSelect.Name].Value = blStatus;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void frmFindAndReplace_Load(object sender, EventArgs e)
        {

        }        
    }
}
