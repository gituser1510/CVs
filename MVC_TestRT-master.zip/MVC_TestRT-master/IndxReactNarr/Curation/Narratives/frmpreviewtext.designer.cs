﻿namespace IndxReactNarr
{
    partial class frmpreviewtext
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.transferToTeiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transferToPara1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transferToPara2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transferToDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.ContextMenuStrip = this.contextMenuStrip1;
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(0, 0);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(535, 568);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            this.richTextBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.richTextBox1_KeyDown);
            this.richTextBox1.DoubleClick += new System.EventHandler(this.richTextBox1_DoubleClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.transferToTeiToolStripMenuItem,
            this.transferToPara1ToolStripMenuItem,
            this.transferToPara2ToolStripMenuItem,
            this.transferToDataToolStripMenuItem,
            this.hiToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(179, 114);
            this.contextMenuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.contextMenuStrip1_ItemClicked);
            // 
            // transferToTeiToolStripMenuItem
            // 
            this.transferToTeiToolStripMenuItem.Name = "transferToTeiToolStripMenuItem";
            this.transferToTeiToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.transferToTeiToolStripMenuItem.Text = "Transfer To Textline";
            this.transferToTeiToolStripMenuItem.Click += new System.EventHandler(this.transferToTeiToolStripMenuItem_Click);
            // 
            // transferToPara1ToolStripMenuItem
            // 
            this.transferToPara1ToolStripMenuItem.Name = "transferToPara1ToolStripMenuItem";
            this.transferToPara1ToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.transferToPara1ToolStripMenuItem.Text = "Transfer To Para1";
            this.transferToPara1ToolStripMenuItem.Click += new System.EventHandler(this.transferToPara1ToolStripMenuItem_Click);
            // 
            // transferToPara2ToolStripMenuItem
            // 
            this.transferToPara2ToolStripMenuItem.Name = "transferToPara2ToolStripMenuItem";
            this.transferToPara2ToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.transferToPara2ToolStripMenuItem.Text = "Transfer To Para2";
            this.transferToPara2ToolStripMenuItem.Click += new System.EventHandler(this.transferToPara2ToolStripMenuItem_Click);
            // 
            // transferToDataToolStripMenuItem
            // 
            this.transferToDataToolStripMenuItem.Name = "transferToDataToolStripMenuItem";
            this.transferToDataToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.transferToDataToolStripMenuItem.Text = "Transfer To Data";
            this.transferToDataToolStripMenuItem.Click += new System.EventHandler(this.transferToDataToolStripMenuItem_Click);
            // 
            // hiToolStripMenuItem
            // 
            this.hiToolStripMenuItem.Name = "hiToolStripMenuItem";
            this.hiToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.hiToolStripMenuItem.Text = "Hi";
            this.hiToolStripMenuItem.Visible = false;
            this.hiToolStripMenuItem.Click += new System.EventHandler(this.hiToolStripMenuItem_Click);
            // 
            // frmpreviewtext
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(535, 568);
            this.Controls.Add(this.richTextBox1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmpreviewtext";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Preview";
            this.Load += new System.EventHandler(this.frmpreviewtext_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmpreviewtext_KeyDown);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        public System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        public System.Windows.Forms.ToolStripMenuItem transferToTeiToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem transferToPara1ToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem transferToPara2ToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem transferToDataToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem hiToolStripMenuItem;



    }
}