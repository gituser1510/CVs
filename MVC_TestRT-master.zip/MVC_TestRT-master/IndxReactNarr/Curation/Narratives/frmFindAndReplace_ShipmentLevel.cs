﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using IndxReactNarrBll;
using IndxReactNarrDAL;
using HtmlRichText;
using IndxReactNarr.Common;

namespace IndxReactNarr.Curation.Narratives
{
    public partial class frmFindAndReplace_ShipmentLevel : Form
    {
        public frmFindAndReplace_ShipmentLevel()
        {
            InitializeComponent();
        }

        public DataTable TAN_Reactions_FR { get; set; }
        public DataTable TAN_Findings_FR { get; set; }
        public DataTable BatchTANs { get; set; }
        public DataTable TANFindings { get; set; }
        List<string> lstTans = null;
        List<int> lstTanIDs = null;

        private void btnFind_Click(object sender, EventArgs e)
        {
            try
            {
                if (chklstTANs.Items.Count > 0 && chklstTANs.CheckedItems.Count > 0)
                {
                    if (!string.IsNullOrEmpty(ucHrtbFind.hrtbPara.Text.Trim()))
                    {
                        Cursor = Cursors.WaitCursor;

                        ClearControlValues();

                        //Get selected TAN IDs
                        lstTanIDs = GetSelectedTanIDs();

                        if (lstTanIDs != null && lstTanIDs.Count > 0)
                        {
                            List<FindReplaceType> lstFindType = GetReplacementCharsList(ucHrtbFind.hrtbPara.Rtf);
                                                       
                            DataTable dtTANResults = null;
                                                        
                            DataSet dsTemp = NarrativesDB.GetShipmentTANReactionsAndFindingsOnTanIDs(lstTanIDs);
                            if (dsTemp != null && dsTemp.Tables.Count == 2)
                            {
                                TAN_Reactions_FR = dsTemp.Tables[0];
                                TAN_Findings_FR = dsTemp.Tables[1]; //NarrativesDB.GetTANFindingsOnTANID(tanID);

                                dtTANResults = FindAndReplaceString.FindStringInReactions_Test(ucHrtbFind.hrtbPara.Rtf, lstFindType, TAN_Reactions_FR, TAN_Findings_FR);                               
                            }

                            dgvSrchResults.DefaultCellStyle.WrapMode = DataGridViewTriState.True;

                            dgvSrchResults.AutoGenerateColumns = false;
                            dgvSrchResults.DataSource = dtTANResults;                           

                            colTAN.DataPropertyName = "TAN_NAME";
                            colRxnID.DataPropertyName = "RXN_ID";
                            colRxnSNo.DataPropertyName = "NARID";
                            colField.DataPropertyName = "FIELDNAME";
                            colFieldValue.DataPropertyName = "FIELDVALUE";

                            lblStatusValue.Text = dtTANResults.Rows.Count + " records found";

                            Cursor = Cursors.Default;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("No TANs are selected", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                Cursor = Cursors.Default;
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void ClearControlValues()
        {
            try
            {
                dgvSrchResults.DataSource = null;
                lblStatusValue.Text = "--";
                chkSelectAll.Checked = false;

            }
            catch (Exception ex)
            {                
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetTANNameOnTAN_ID(int tanID)
        {
            string tanName = "";
            try
            {
                if (BatchTANs != null && BatchTANs.Rows.Count > 0)
                {
                    var query = from r in BatchTANs.AsEnumerable()
                                where r.Field<Int64>("TAN_ID") == tanID
                                select new
                                {
                                    tanName = r["TAN_NAME"].ToString()
                                };
                    if (query != null && query.Any())
                    {
                        tanName = query.ElementAt(0).tanName;
                    }
                }
            }
            catch (Exception ex)
            {               
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return tanName;
        }

        public HtmlRichTextBox GetActiveControlFromForm()
        {
            HtmlRichTextBox hrtbActive = null;
            try
            {
                if (ucHrtbFind.hrtbPara.Focused)
                {
                    hrtbActive = ucHrtbFind.hrtbPara;
                }
                else if (ucHrtbReplace.hrtbPara.Focused)
                {
                    hrtbActive = ucHrtbReplace.hrtbPara;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return hrtbActive;
        }      

        private void btnReplace_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;

                FindReplaceBO objFndRepl = GetReplacementRxnsForUpdation();
                if (objFndRepl != null)
                {
                    //Save Reactions id DB
                    if (NarrativesDB.UpdateFindReplaceReactionsData(objFndRepl))
                    {
                        Cursor = Cursors.Default;
                        MessageBox.Show("Updated selected reactions successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);

                        ClearControlValues();
                        
                    }
                    else
                    {
                        Cursor = Cursors.Default;
                        MessageBox.Show("Error in updating selected reactions", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                Cursor = Cursors.Default;
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private List<FindReplaceType> GetReplacementCharsList(string rtfString)
        {
            List<FindReplaceType> fndReplist = new List<FindReplaceType>();
            if (!string.IsNullOrEmpty(rtfString))
            {
                using (HtmlRichTextBox hrtbSrch = new HtmlRichTextBox())
                {
                    hrtbSrch.Rtf = rtfString;

                    if (hrtbSrch.Text.Length > 0)
                    {
                        for (int i = 0; i < hrtbSrch.Text.Length; i++)
                        {
                            hrtbSrch.Select(i, 1);
                            string strrtf = hrtbSrch.SelectedRtf;                            
                            FindReplaceType fr = new FindReplaceType();
                            #region MyRegion
                            //if (strrtf.Contains("\\b"))
                            //{
                            //    fr.IsBold = true;
                            //}
                            //if (strrtf.Contains("\\i"))
                            //{
                            //    fr.IsItalic = true;

                            //}
                            //if (strrtf.Contains("\\super"))
                            //{
                            //    fr.IsSupScr = true;
                            //}
                            //if (strrtf.Contains("\\sub"))
                            //{
                            //    fr.IsSubScr = true;
                            //} 
                            #endregion

                            string html = Html_RtfConversions.Instance.GetHTMLFromRTFString(strrtf);
                            if(html.Contains("<sup>"))
                            {
                                fr.IsSupScr = true;
                            }
                            else if (html.Contains("<sub>"))
                            {
                                fr.IsSubScr = true;
                            }
                            else if (html.Contains("<bold>") && html.Contains("<ital>"))
                            {
                                fr.IsBoldItalic = true;
                            }
                            else if (html.Contains("<bold>"))
                            {
                                fr.IsBold = true;
                            }
                            else if (html.Contains("<ital>"))
                            {
                                fr.IsItalic = true;
                            }

                            fr.CharValue = Convert.ToChar(hrtbSrch.SelectedText);
                            fndReplist.Add(fr);
                        }
                    }
                }
            }
            return fndReplist;
        }

        private FindReplaceBO GetReplacementRxnsForUpdation()
        {
            FindReplaceBO fndRepBll = null;
            try
            {
                if (dgvSrchResults.Rows.Count > 0)
                {
                    List<FindReplaceType> lstFndRepType = GetReplacementCharsList(ucHrtbReplace.hrtbPara.Rtf);

                    string htmlFind = Html_RtfConversions.Instance.GetHTMLFromRTFString(ucHrtbFind.hrtbPara.Rtf);
                    string htmlFindText = ucHrtbFind.hrtbPara.Text;
                    string htmlReplace = Html_RtfConversions.Instance.GetHTMLFromRTFString(ucHrtbReplace.hrtbPara.Rtf);
                    string replaceText = ucHrtbReplace.hrtbPara.Text;

                    fndRepBll = new FindReplaceBO();

                    //Get selected reactions for replace
                    DataTable selRxns = GetSelectedReactionsForReplace();

                    FindAndReplaceString.ReplaceDataInReactions(htmlFindText, replaceText, lstFndRepType, ref selRxns);

                    if (selRxns != null)
                    {                       
                        List<int> lstRxnIDs = new List<int>();
                        List<string> lstField = new List<string>();
                        List<string> lstFieldValue = new List<string>();
                        string replaceValue = "";
                        string fieldName = "";

                        for (int i = 0; i < selRxns.Rows.Count; i++)
                        {
                            fieldName = "";
                            
                            lstRxnIDs.Add(Convert.ToInt32(selRxns.Rows[i]["RXN_ID"]));
                            fieldName = selRxns.Rows[i]["FIELDNAME"].ToString().ToUpper();
                            lstField.Add(fieldName);

                            #region Code commented on 13 July 2015
                            //if (selRxns.Rows[i]["FIELDNAME"].ToString().ToUpper() == "PARA_TEXT")
                            //{
                            //    fieldName = "PARA_TEXT";
                            //}
                            //if (selRxns.Rows[i]["FIELDNAME"].ToString().ToUpper() == "DATA_TEXT")
                            //{
                            //    fieldName = "DATA_TEXT";
                            //}
                            //if (selRxns.Rows[i]["FIELDNAME"].ToString().ToUpper() == "TEXT_LINE")
                            //{
                            //    fieldName = "TEXT_LINE";
                            //}
                            //if (selRxns.Rows[i]["FIELDNAME"].ToString().ToUpper() == "YIELD_TEXT")
                            //{
                            //    fieldName = "YIELD_TEXT";
                            //}
                            //if (selRxns.Rows[i]["FIELDNAME"].ToString().ToUpper() == "PROCEDURE_TEXT")
                            //{
                            //    fieldName = "PROCEDURE_TEXT";
                            //}                            
                            #endregion
                            
                            replaceValue = Html_RtfConversions.Instance.GetHTMLFromRTFString(selRxns.Rows[i]["FIELDVALUE"].ToString());                            
                            lstFieldValue.Add(replaceValue);
                        }

                        fndRepBll.Rxn_IDs = lstRxnIDs;
                        fndRepBll.FieldNames = lstField;
                        fndRepBll.FieldValues = lstFieldValue;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return fndRepBll;
        }

        private DataTable GetSelectedReactionsForReplace()
        {
            DataTable dtSelRxns = null;
            try
            {
                if (dgvSrchResults.Rows.Count > 0)
                {
                    DataTable gridSource = dgvSrchResults.DataSource as DataTable;
                    if (gridSource != null)
                    {
                        dtSelRxns = gridSource.Clone();

                        for (int i = 0; i < dgvSrchResults.Rows.Count; i++)
                        {
                            if (dgvSrchResults.Rows[i].Cells[colSelect.Name].Value != null)
                            {
                                if (dgvSrchResults.Rows[i].Cells[colSelect.Name].Value.ToString().ToUpper() == "TRUE")
                                {
                                    dtSelRxns.ImportRow(gridSource.Rows[i]);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtSelRxns;
        }

        private void dgvSrchResults_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            try
            {
                //for (int i = 0; i < this.dgvSrchResults.Rows.Count; i++)
                //{
                //    this.dgvSrchResults.AutoResizeRow(i, DataGridViewAutoSizeRowMode.AllCells);
                //}
            }
            catch (Exception ex)
            {                
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvSrchResults_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvSrchResults.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;
                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvSrchResults.Font);
                if (dgvSrchResults.RowHeadersWidth < (int)(size.Width + 20)) dgvSrchResults.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;

                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void chkSelectAll_CheckStateChanged(object sender, EventArgs e)
        {
            try
            {
                bool blStatus = false;
                if (chkSelectAll.Checked)
                {
                    blStatus = true;
                }
                if (dgvSrchResults.Rows.Count > 0)
                {
                    foreach (DataGridViewRow dgRow in dgvSrchResults.Rows)
                    {
                        dgRow.Cells[colSelect.Name].Value = blStatus;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        

        private void frmFindAndReplace_ShipmentLevel_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;
                txtShipmentName.Focus();

                //Get Shipment Names and Set Autofill
                GetShipmentNamesAndSetToUserNameTxtBox_AutoComplete();
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetShipmentNamesAndSetToUserNameTxtBox_AutoComplete()
        {
            try
            {
                DataTable dtTanTypes = null;
                DataTable dtShipments = null;
                using (dtShipments = ReactDB.GetShipmentDetailsByAppName(GlobalVariables.ApplicationName, out dtTanTypes))//EXPPROCEDURES
                {
                    if (dtShipments != null && dtShipments.Rows.Count > 0)
                    {
                        AutoCompleteStringCollection shipmentColl = new AutoCompleteStringCollection();

                        for (int i = 0; i < dtShipments.Rows.Count; i++)
                        {
                            if (dtShipments.Rows[i][0] != null)
                            {
                                shipmentColl.Add(dtShipments.Rows[i]["SHIPMENT_NAME"].ToString());
                            }
                        }

                        txtShipmentName.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                        txtShipmentName.AutoCompleteSource = AutoCompleteSource.CustomSource;
                        txtShipmentName.AutoCompleteCustomSource = shipmentColl;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindTANsToCheckBoxlistBox(DataTable dtBatchTANS)
        {
            try
            {
                lstTans = dtBatchTANS.Rows.Cast<DataRow>().Select(row => row["TAN_NAME"].ToString()).ToList();
                BindListToCheckListBox(lstTans);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindListToCheckListBox(List<string> lstTans)
        {
            try
            {
                chklstTANs.Items.Clear();
                chklstTANs.Items.Add("Select All");
                foreach (string Tan in lstTans)
                {
                    chklstTANs.Items.Add(Tan);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnGetList_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;

                if (!string.IsNullOrEmpty(txtShipmentName.Text.Trim()))
                {
                    int intBNo = 0;
                    int.TryParse(txtBNo.Text.Trim(), out intBNo);

                    DataTable dtBatchTANS = ShipmentMasterDB.GetTANsForExportOnApp_Shipment(GlobalVariables.ApplicationName, txtShipmentName.Text.Trim(), intBNo);
                    if (dtBatchTANS != null)
                    {
                        BatchTANs = dtBatchTANS;
                        txtTANSrch.Text = "";
                        BindTANsToCheckBoxlistBox(dtBatchTANS);
                    }
                }

                Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private bool ValidUserInputs(out string strErrmsg)
        {
            bool status = true;
            string Err = string.Empty;

            try
            {
                if (chklstTANs.CheckedItems.Count == 0)
                {
                    status = false;
                    Err += "Please select reactions";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            strErrmsg = Err;
            return status;
        }

        private List<int> GetSelectedTanIDs()
        {
            lstTanIDs = new List<int>();
            int TAN_ID = 0;
            try
            {
                if (BatchTANs != null && BatchTANs.Rows.Count > 0)
                {
                    // Rxn id for secondary reaction
                    for (int i = 0; i < chklstTANs.CheckedItems.Count; i++)
                    {
                        if (chklstTANs.CheckedItems[i].ToString() != "Select All")
                        {
                            TAN_ID = (from DataRow dr in BatchTANs.Rows
                                      where Convert.ToString(dr["TAN_NAME"]) == chklstTANs.CheckedItems[i].ToString()
                                      select (Convert.ToInt32(dr["TAN_ID"]))).FirstOrDefault();

                            lstTanIDs.Add(TAN_ID);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstTanIDs;
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            string strErrmsg = string.Empty;
            try
            {
                if (ValidUserInputs(out strErrmsg))
                {
                    lstTanIDs = GetSelectedTanIDs();

                    TANFindings = NarrativesDB.GetReactionFindingsOnTanIDs(lstTanIDs);

                    dgvSrchResults.AutoGenerateColumns = false;
                    BindingSource bsTANFindings = new BindingSource(TANFindings, null);
                    dgvSrchResults.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                    dgvSrchResults.DataSource = bsTANFindings;

                }
                else
                {
                    MessageBox.Show(strErrmsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void DeSelectAllItems()
        {
            try
            {
                chklstTANs.BeginUpdate();
                chklstTANs.ItemCheck -= chklstTANs_ItemCheck;
                for (int i = 0; i < this.chklstTANs.Items.Count; i++)
                {
                    this.chklstTANs.SetItemChecked(i, false);
                }
                chklstTANs.SetSelected(0, false);
                chklstTANs.EndUpdate();
                chklstTANs.ItemCheck += chklstTANs_ItemCheck;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void SelectAllItems()
        {
            try
            {
                chklstTANs.BeginUpdate();
                chklstTANs.ItemCheck -= chklstTANs_ItemCheck;
                for (int i = 0; i < this.chklstTANs.Items.Count; i++)
                {
                    this.chklstTANs.SetItemChecked(i, true);
                }
                chklstTANs.SetSelected(0, false);
                chklstTANs.EndUpdate();
                chklstTANs.ItemCheck += chklstTANs_ItemCheck;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void chklstTANs_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            try
            {
                if (e.Index == 0 && e.NewValue == CheckState.Checked)
                {
                    SelectAllItems();

                }

                if (e.Index == 0 && e.NewValue == CheckState.Unchecked)
                {
                    DeSelectAllItems();

                }

                if (e.Index != 0 && e.NewValue == CheckState.Unchecked)
                {
                    chklstTANs.BeginUpdate();
                    chklstTANs.ItemCheck -= chklstTANs_ItemCheck;
                    chklstTANs.SetItemChecked(0, false);
                    chklstTANs.EndUpdate();
                    chklstTANs.ItemCheck += chklstTANs_ItemCheck;
                }

                if (e.Index != 0 && e.NewValue == CheckState.Checked && chklstTANs.CheckedItems.Count == chklstTANs.Items.Count - 2)
                {
                    chklstTANs.BeginUpdate();
                    chklstTANs.ItemCheck -= chklstTANs_ItemCheck;
                    chklstTANs.SetItemChecked(0, true);
                    chklstTANs.EndUpdate();
                    chklstTANs.ItemCheck += chklstTANs_ItemCheck;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnHideSplChars_Click(object sender, EventArgs e)
        {
            try
            {
                if (ucSplCharsToolStrip_Indexing1.Visible == true)
                {
                    ucSplCharsToolStrip_Indexing1.Visible = false;
                }
                else
                {
                    ucSplCharsToolStrip_Indexing1.Visible = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
