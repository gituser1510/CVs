﻿namespace IndxReactNarr.Curation.Narratives
{
    partial class frmTANReportView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.splCont = new System.Windows.Forms.SplitContainer();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.chklstReactions = new System.Windows.Forms.CheckedListBox();
            this.btnResetSelection = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvReactions = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNarID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAnalogousTo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnNUM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnSeq = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDocRef = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNoExpDetails = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colIsGenTypical = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPageNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPageLabel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colXOffSet = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colYOffSet = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colXPageSize = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colYPageSize = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTextLine = new DataGridViewRichTextBox.DataGridViewRichTextBoxColumn();
            this.colYieldText = new DataGridViewRichTextBox.DataGridViewRichTextBoxColumn();
            this.colPara1 = new DataGridViewRichTextBox.DataGridViewRichTextBoxColumn();
            this.colPara2 = new DataGridViewRichTextBox.DataGridViewRichTextBoxColumn();
            this.colData = new DataGridViewRichTextBox.DataGridViewRichTextBoxColumn();
            this.colProcedureText = new DataGridViewRichTextBox.DataGridViewRichTextBoxColumn();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splCont)).BeginInit();
            this.splCont.Panel1.SuspendLayout();
            this.splCont.Panel2.SuspendLayout();
            this.splCont.SuspendLayout();
            this.pnlTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReactions)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.splCont);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1163, 472);
            this.pnlMain.TabIndex = 0;
            // 
            // splCont
            // 
            this.splCont.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splCont.Location = new System.Drawing.Point(0, 0);
            this.splCont.Name = "splCont";
            this.splCont.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splCont.Panel1
            // 
            this.splCont.Panel1.Controls.Add(this.pnlTop);
            // 
            // splCont.Panel2
            // 
            this.splCont.Panel2.Controls.Add(this.dgvReactions);
            this.splCont.Size = new System.Drawing.Size(1163, 472);
            this.splCont.SplitterDistance = 107;
            this.splCont.TabIndex = 2;
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.chklstReactions);
            this.pnlTop.Controls.Add(this.btnResetSelection);
            this.pnlTop.Controls.Add(this.label1);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1163, 107);
            this.pnlTop.TabIndex = 0;
            // 
            // chklstReactions
            // 
            this.chklstReactions.CheckOnClick = true;
            this.chklstReactions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chklstReactions.FormattingEnabled = true;
            this.chklstReactions.Location = new System.Drawing.Point(0, 27);
            this.chklstReactions.MultiColumn = true;
            this.chklstReactions.Name = "chklstReactions";
            this.chklstReactions.Size = new System.Drawing.Size(1161, 78);
            this.chklstReactions.TabIndex = 0;
            this.chklstReactions.SelectedValueChanged += new System.EventHandler(this.chklstReactions_SelectedValueChanged);
            // 
            // btnResetSelection
            // 
            this.btnResetSelection.Image = global::IndxReactNarr.Properties.Resources.refresh;
            this.btnResetSelection.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnResetSelection.Location = new System.Drawing.Point(216, 1);
            this.btnResetSelection.Name = "btnResetSelection";
            this.btnResetSelection.Size = new System.Drawing.Size(75, 24);
            this.btnResetSelection.TabIndex = 2;
            this.btnResetSelection.Text = "Reset";
            this.btnResetSelection.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnResetSelection.UseVisualStyleBackColor = true;
            this.btnResetSelection.Click += new System.EventHandler(this.btnResetSelection_Click);
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1161, 27);
            this.label1.TabIndex = 1;
            this.label1.Text = "Select Reactions for Comparision";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dgvReactions
            // 
            this.dgvReactions.AllowUserToAddRows = false;
            this.dgvReactions.AllowUserToDeleteRows = false;
            this.dgvReactions.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvReactions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReactions.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colRxnID,
            this.colNarID,
            this.colAnalogousTo,
            this.colRxnNUM,
            this.colRxnSeq,
            this.colDocRef,
            this.colNoExpDetails,
            this.colIsGenTypical,
            this.colPageNo,
            this.colPageLabel,
            this.colXOffSet,
            this.colYOffSet,
            this.colXPageSize,
            this.colYPageSize,
            this.colTextLine,
            this.colYieldText,
            this.colPara1,
            this.colPara2,
            this.colData,
            this.colProcedureText});
            this.dgvReactions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvReactions.Location = new System.Drawing.Point(0, 0);
            this.dgvReactions.Name = "dgvReactions";
            this.dgvReactions.ReadOnly = true;
            this.dgvReactions.Size = new System.Drawing.Size(1163, 361);
            this.dgvReactions.TabIndex = 1;
            this.dgvReactions.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvReactions_RowPostPaint);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "RxnID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn2.HeaderText = "NarID";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 50;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn3.HeaderText = "NUM";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 50;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn4.HeaderText = "Seq";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 40;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn5.HeaderText = "PageNo";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 40;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn6.HeaderText = "PageLbl";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 40;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn7.HeaderText = "XOffSet";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 40;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn8.HeaderText = "YOffSet";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Width = 40;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "XPageSize";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn10.HeaderText = "YPageSize";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Width = 40;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn11.HeaderText = "TextLine";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn12.HeaderText = "Para";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn13.HeaderText = "Data";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            // 
            // colRxnID
            // 
            this.colRxnID.HeaderText = "RxnID";
            this.colRxnID.Name = "colRxnID";
            this.colRxnID.ReadOnly = true;
            this.colRxnID.Visible = false;
            // 
            // colNarID
            // 
            this.colNarID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colNarID.HeaderText = "NarID";
            this.colNarID.Name = "colNarID";
            this.colNarID.ReadOnly = true;
            this.colNarID.Width = 50;
            // 
            // colAnalogousTo
            // 
            this.colAnalogousTo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colAnalogousTo.HeaderText = "Analg.To";
            this.colAnalogousTo.Name = "colAnalogousTo";
            this.colAnalogousTo.ReadOnly = true;
            this.colAnalogousTo.Width = 50;
            // 
            // colRxnNUM
            // 
            this.colRxnNUM.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colRxnNUM.HeaderText = "NUM";
            this.colRxnNUM.Name = "colRxnNUM";
            this.colRxnNUM.ReadOnly = true;
            this.colRxnNUM.Width = 50;
            // 
            // colRxnSeq
            // 
            this.colRxnSeq.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colRxnSeq.HeaderText = "Seq";
            this.colRxnSeq.Name = "colRxnSeq";
            this.colRxnSeq.ReadOnly = true;
            this.colRxnSeq.Width = 40;
            // 
            // colDocRef
            // 
            this.colDocRef.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colDocRef.HeaderText = "DocRef";
            this.colDocRef.Name = "colDocRef";
            this.colDocRef.ReadOnly = true;
            this.colDocRef.Width = 40;
            // 
            // colNoExpDetails
            // 
            this.colNoExpDetails.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colNoExpDetails.HeaderText = "NoExp";
            this.colNoExpDetails.Name = "colNoExpDetails";
            this.colNoExpDetails.ReadOnly = true;
            this.colNoExpDetails.Width = 50;
            // 
            // colIsGenTypical
            // 
            this.colIsGenTypical.HeaderText = "GenTyp";
            this.colIsGenTypical.Name = "colIsGenTypical";
            this.colIsGenTypical.ReadOnly = true;
            this.colIsGenTypical.Width = 50;
            // 
            // colPageNo
            // 
            this.colPageNo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colPageNo.HeaderText = "PageNo";
            this.colPageNo.Name = "colPageNo";
            this.colPageNo.ReadOnly = true;
            this.colPageNo.Width = 40;
            // 
            // colPageLabel
            // 
            this.colPageLabel.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colPageLabel.HeaderText = "PageLbl";
            this.colPageLabel.Name = "colPageLabel";
            this.colPageLabel.ReadOnly = true;
            this.colPageLabel.Width = 40;
            // 
            // colXOffSet
            // 
            this.colXOffSet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colXOffSet.HeaderText = "XOffSet";
            this.colXOffSet.Name = "colXOffSet";
            this.colXOffSet.ReadOnly = true;
            this.colXOffSet.Width = 40;
            // 
            // colYOffSet
            // 
            this.colYOffSet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colYOffSet.HeaderText = "YOffSet";
            this.colYOffSet.Name = "colYOffSet";
            this.colYOffSet.ReadOnly = true;
            this.colYOffSet.Width = 40;
            // 
            // colXPageSize
            // 
            this.colXPageSize.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colXPageSize.HeaderText = "XPageSize";
            this.colXPageSize.Name = "colXPageSize";
            this.colXPageSize.ReadOnly = true;
            this.colXPageSize.Width = 40;
            // 
            // colYPageSize
            // 
            this.colYPageSize.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colYPageSize.HeaderText = "YPageSize";
            this.colYPageSize.Name = "colYPageSize";
            this.colYPageSize.ReadOnly = true;
            this.colYPageSize.Width = 40;
            // 
            // colTextLine
            // 
            this.colTextLine.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.colTextLine.DefaultCellStyle = dataGridViewCellStyle1;
            this.colTextLine.HeaderText = "TextLine";
            this.colTextLine.Name = "colTextLine";
            this.colTextLine.ReadOnly = true;
            this.colTextLine.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colTextLine.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // colYieldText
            // 
            this.colYieldText.HeaderText = "YieldText";
            this.colYieldText.Name = "colYieldText";
            this.colYieldText.ReadOnly = true;
            // 
            // colPara1
            // 
            this.colPara1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.colPara1.DefaultCellStyle = dataGridViewCellStyle2;
            this.colPara1.HeaderText = "Para1";
            this.colPara1.Name = "colPara1";
            this.colPara1.ReadOnly = true;
            this.colPara1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colPara1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // colPara2
            // 
            this.colPara2.HeaderText = "Para2";
            this.colPara2.Name = "colPara2";
            this.colPara2.ReadOnly = true;
            // 
            // colData
            // 
            this.colData.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.colData.DefaultCellStyle = dataGridViewCellStyle3;
            this.colData.HeaderText = "Data";
            this.colData.Name = "colData";
            this.colData.ReadOnly = true;
            this.colData.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colData.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // colProcedureText
            // 
            this.colProcedureText.HeaderText = "ProcedureText";
            this.colProcedureText.Name = "colProcedureText";
            this.colProcedureText.ReadOnly = true;
            // 
            // frmTANReportView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1163, 472);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmTANReportView";
            this.ShowIcon = false;
            this.Text = "TAN Report View";
            this.Load += new System.EventHandler(this.frmTANReportView_Load);
            this.pnlMain.ResumeLayout(false);
            this.splCont.Panel1.ResumeLayout(false);
            this.splCont.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splCont)).EndInit();
            this.splCont.ResumeLayout(false);
            this.pnlTop.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvReactions)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.CheckedListBox chklstReactions;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvReactions;
        private System.Windows.Forms.SplitContainer splCont;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.Button btnResetSelection;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNarID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAnalogousTo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnNUM;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnSeq;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDocRef;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNoExpDetails;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIsGenTypical;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPageNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPageLabel;
        private System.Windows.Forms.DataGridViewTextBoxColumn colXOffSet;
        private System.Windows.Forms.DataGridViewTextBoxColumn colYOffSet;
        private System.Windows.Forms.DataGridViewTextBoxColumn colXPageSize;
        private System.Windows.Forms.DataGridViewTextBoxColumn colYPageSize;
        private DataGridViewRichTextBox.DataGridViewRichTextBoxColumn colTextLine;
        private DataGridViewRichTextBox.DataGridViewRichTextBoxColumn colYieldText;
        private DataGridViewRichTextBox.DataGridViewRichTextBoxColumn colPara1;
        private DataGridViewRichTextBox.DataGridViewRichTextBoxColumn colPara2;
        private DataGridViewRichTextBox.DataGridViewRichTextBoxColumn colData;
        private DataGridViewRichTextBox.DataGridViewRichTextBoxColumn colProcedureText;
    }
}