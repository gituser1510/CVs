﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using IndxReactNarr.Common;

namespace IndxReactNarr
{
    public partial class frmConceptTextHeadings : Form
    {
        public frmConceptTextHeadings()
        {
            InitializeComponent();
        }

        public string SelectedCTH { get; set; }
        public DataTable ConceptHeadings { get; set; }

        private void dgvCTH_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex >= 0 && e.RowIndex >= 0)
                {
                    if (dgvCTH.Rows[e.RowIndex].Cells["colCthName"].Value != null)
                    {
                        if (!string.IsNullOrEmpty(dgvCTH.Rows[e.RowIndex].Cells["colCthName"].Value.ToString()))
                        {
                            SelectedCTH = dgvCTH.Rows[e.RowIndex].Cells["colCthName"].Value.ToString();
                        }
                    }                    

                    DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvCTH_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvCTH.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvCTH.Font);

                if (dgvCTH.RowHeadersWidth < (int)(size.Width + 20)) dgvCTH.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void frmConceptTextHeadings_Load(object sender, EventArgs e)
        {
            try
            {
                if (GlobalVariables.ConceptTextHeadings != null)
                {
                    var rows = GlobalVariables.ConceptTextHeadings.AsEnumerable()
                                                   .Where(r => r.Field<string>("APPLICATION") == GlobalVariables.ApplicationName);
                    ConceptHeadings = rows.Any() ? rows.CopyToDataTable() : GlobalVariables.ConceptTextHeadings.Clone();
                    
                    BindDataToCTHGrid(ConceptHeadings);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindDataToCTHGrid(DataTable cthData)
        {
            try
            {
                if (cthData != null)
                {
                    dgvCTH.AutoGenerateColumns = false;
                    dgvCTH.DataSource = cthData;

                    colCthClass.DataPropertyName = "CTH_CLASS";
                    colCthName.DataPropertyName = "CTH_NAME";

                    if (GlobalVariables.ApplicationName.ToUpper() == Enums.ApplicationName.MACRO.ToString())
                    {
                        colCTHType.DataPropertyName = "CTH_TYPE";
                        colCTHCategory.DataPropertyName = "CATEGORY_TYPE";

                        colCTHType.Visible = true;
                        colCTHCategory.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetFilterCondition()
        {
            string strFilerCond = "";
            try
            {
                if (!string.IsNullOrEmpty(txtCTHClass.Text.Trim()))
                {
                    strFilerCond = "CTH_CLASS like '" + txtCTHClass.Text.Trim() + "%'";
                }
                if (!string.IsNullOrEmpty(txtCTHName.Text.Trim()))
                {
                    if (string.IsNullOrEmpty(strFilerCond.Trim()))
                    {
                        strFilerCond = "CTH_NAME like '" + DataConversions.EscapeSpecialCharsInFilterCondition(txtCTHName.Text.Trim()) + "%'";
                    }
                    else
                    {
                        strFilerCond = strFilerCond + " and CTH_NAME like '" + DataConversions.EscapeSpecialCharsInFilterCondition(txtCTHName.Text.Trim()) + "%'";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strFilerCond;
        }

        private void GetFilteredDataBindToGrid()
        {
            try
            {
                string strFiltCond = GetFilterCondition();
                if (strFiltCond.Trim() != "")
                {
                    DataView dtView = ConceptHeadings.Copy().DefaultView;
                    dtView.RowFilter = strFiltCond;
                    DataTable dtGridData = dtView.ToTable();

                    //Bind data to NUMs grid
                    BindDataToCTHGrid(dtGridData);
                }
                else
                {
                    //Bind data to NUMs grid
                    BindDataToCTHGrid(ConceptHeadings);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void txtCTHClass_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilteredDataBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
