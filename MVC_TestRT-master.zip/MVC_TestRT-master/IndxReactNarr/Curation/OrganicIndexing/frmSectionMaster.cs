﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarrDAL;
using IndxReactNarr.Generic;

namespace IndxReactNarr
{
    public partial class frmSectionMaster : Form
    {
        public frmSectionMaster()
        {
            InitializeComponent();
        }

        public string SelectedSection { get; set; }
        public string SelectedSubSec { get; set; }
        public DataTable SectionMaster { get; set; }
        private void frmSectionMaster_Load(object sender, EventArgs e)
        {
            try
            {
                if (GlobalVariables.IndexingSections != null)
                {
                    var rows = GlobalVariables.IndexingSections.AsEnumerable()
                                                   .Where(r => r.Field<string>("APPLICATION") == GlobalVariables.ApplicationName);
                    SectionMaster = rows.Any() ? rows.CopyToDataTable() : GlobalVariables.IndexingSections.Clone();

                    BindSectionsToGrid(SectionMaster);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
      
        private void BindSectionsToGrid(DataTable sections)
        {
            try
            {
                if (sections != null)
                {
                    dgvSectionMaster.AutoGenerateColumns = false;
                    dgvSectionMaster.DataSource = sections;

                    colSection_ID.DataPropertyName = "SECTION_ID";
                    colSection_Code.DataPropertyName = "SECTION_CODE";
                    colSection_Name.DataPropertyName = "SECTION_NAME";
                    colDisplay_Order.DataPropertyName = "DISPLAY_ORDER";
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindSubSectionsToGrid(DataTable subsections)
        {
            try
            {
                if (subsections != null)
                {
                    dgvSubSections.AutoGenerateColumns = false;
                    dgvSubSections.DataSource = subsections;

                    colSubSecNo.DataPropertyName = "SUB_SEC_NO";
                    colSubSecName.DataPropertyName = "SUB_SEC_NAME";                    
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetFilteredDataBindToGrid()
        {
            try
            {
                string strFiltCond = "SECTION_NAME like '" + txtSrchSection.Text.Trim() + "%'";
                if (!string.IsNullOrEmpty(strFiltCond.Trim()))
                {
                    DataView dtView = SectionMaster.Copy().DefaultView;
                    dtView.RowFilter = strFiltCond;
                    DataTable dtSections = dtView.ToTable();

                    //Bind data to Sections grid
                    BindSectionsToGrid(dtSections);
                }
                else
                {
                    //Bind data to Sections grid
                    BindSectionsToGrid(SectionMaster);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #region Grid RowPostPaint Events

        private void dgvSectionMaster_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvSectionMaster.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvSectionMaster.Font);

                if (dgvSectionMaster.RowHeadersWidth < (int)(size.Width + 20)) dgvSectionMaster.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvSubSections_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvSectionMaster.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvSectionMaster.Font);

                if (dgvSectionMaster.RowHeadersWidth < (int)(size.Width + 20)) dgvSectionMaster.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        private void dgvSectionMaster_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex >= 0 && e.RowIndex >= 0)
                {
                    if (dgvSectionMaster.Rows[e.RowIndex].Cells["colSection_Name"].Value != null)
                    {
                        if (!string.IsNullOrEmpty(dgvSectionMaster.Rows[e.RowIndex].Cells["colSection_Name"].Value.ToString()))
                        {
                            SelectedSection = dgvSectionMaster.Rows[e.RowIndex].Cells["colSection_ID"].Value.ToString();
                        }
                    }

                    DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void dgvSectionMaster_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    if (dgvSectionMaster.Rows[e.RowIndex].Cells["colSection_ID"].Value != null)
                    {
                        int intSecID = Convert.ToInt32(dgvSectionMaster.Rows[e.RowIndex].Cells["colSection_ID"].Value);

                        if (GlobalVariables.IndexingSubSections != null)
                        {
                            var rows = GlobalVariables.IndexingSubSections.AsEnumerable()
                                                    .Where(r => r.Field<Int64>("SECTION_ID") == intSecID);
                            var dtSubSecs = rows.Any() ? rows.CopyToDataTable() : GlobalVariables.IndexingSubSections.Clone();
                            
                            if (dtSubSecs != null)
                            {
                                BindSubSectionsToGrid(dtSubSecs);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtSrchSection_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilteredDataBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvSectionMaster.SelectedRows.Count > 0)
                {
                    if (dgvSectionMaster.SelectedRows[0].Cells["colSection_Name"].Value != null)
                    {
                        if (!string.IsNullOrEmpty(dgvSectionMaster.SelectedRows[0].Cells["colSection_Name"].Value.ToString()))
                        {
                            SelectedSection = dgvSectionMaster.SelectedRows[0].Cells["colSection_ID"].Value.ToString();
                        }
                    }
                }

                if (dgvSubSections.SelectedRows.Count > 0)
                {
                    if (dgvSubSections.SelectedRows[0].Cells["colSubSecNo"].Value != null)
                    {
                        if (!string.IsNullOrEmpty(dgvSubSections.SelectedRows[0].Cells["colSubSecName"].Value.ToString()))
                        {
                            SelectedSubSec = dgvSubSections.SelectedRows[0].Cells["colSubSecNo"].Value.ToString();
                        }
                    }
                }

                if (!string.IsNullOrEmpty(SelectedSection) && !string.IsNullOrEmpty(SelectedSubSec))
                {
                    DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Section & Sub-Section are mandatory",GlobalVariables.MessageCaption,MessageBoxButtons.OK,MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        
    }
}
