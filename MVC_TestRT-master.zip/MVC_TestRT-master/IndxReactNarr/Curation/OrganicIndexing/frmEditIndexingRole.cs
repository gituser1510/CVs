﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using IndxReactNarr.Generic;

namespace IndxReactNarr
{
    public partial class frmEditIndexingRole : Form
    {
        public frmEditIndexingRole()
        {
            InitializeComponent();
        }

        #region Public properties        
        
        public string SelectedRoles { get; set; } 
        
        #endregion

        private void frmEditIndexingRole_Load(object sender, EventArgs e)
        {
            try
            {
               //Bind role to grid
                BindIndexingRolesToGrid();

                //Check and select role
                CheckAndSelectRoleInGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindIndexingRolesToGrid()
        {
            try
            {
                if (GlobalVariables.IndexingRoles != null)
                {
                    dgvRoles.AutoGenerateColumns = false;
                    dgvRoles.DataSource = GlobalVariables.IndexingRoles;

                    colRoleCode.DataPropertyName = "role_code";
                    colRoleIndicator.DataPropertyName = "role_indicator";
                } 
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void CheckAndSelectRoleInGrid()
        {
            try
            {
                //Check and Select Indexing roles
                if (!string.IsNullOrEmpty(SelectedRoles))
                {
                    string[] saRoles = SelectedRoles.Trim().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                    if (saRoles != null)
                    {
                        if (saRoles.Length > 0)
                        {
                            foreach (string role in saRoles)
                            {
                                foreach (DataGridViewRow row in dgvRoles.Rows)
                                {
                                    if (row.Cells[1].Value != null)
                                    {
                                        if (row.Cells[1].Value.ToString().Trim() == role.Trim())
                                        {
                                            row.Cells[0].Value = true;
                                            row.DefaultCellStyle.BackColor = Color.Azure;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {               
                string strRole = string.Empty;
                string roleSep = " ";
                foreach (DataGridViewRow row in dgvRoles.Rows)
                {
                    if (row.Cells[0].Value != null &&
                           Convert.ToBoolean(row.Cells[0].Value) == true)
                    {
                        strRole += (row.Cells[1].Value.ToString().Trim() + roleSep);
                    }
                }

                string strErrMsg = "";
                if (ValidateNUUinRoles(strRole, roleSep, out strErrMsg))
                {
                    //if (!string.IsNullOrEmpty(strRole.Trim()))
                    //{
                    SelectedRoles = strRole.Trim();
                    DialogResult = DialogResult.OK;
                    //}
                }
                else
                {
                    MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private bool ValidateNUUinRoles(string roles, string roleSep, out string errMsg)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (!string.IsNullOrEmpty(roles) && !string.IsNullOrEmpty(roleSep))
                {
                    List<string> lstRoles = roles.Trim().Split(new string[] { roleSep }, StringSplitOptions.RemoveEmptyEntries).ToList();
                    if (lstRoles.Contains("NUU") && lstRoles.Count > 1 && GlobalVariables.ApplicationName == "ORGANIC")
                    {
                        blStatus = false;
                        strErrMsg = "If 'NUU' is selected, no other roles are allowed";
                    }
                    //if (lstRoles.Contains("AGR") && !lstRoles.Contains("BSU"))
                    //{
                    //    blStatus = false;
                    //    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "If 'AGR' is selected, 'BSU' is mandatory";
                    //}
                    if (lstRoles.Contains("PAC") && !lstRoles.Contains("THU"))
                    {
                        blStatus = false;
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "If 'PAC' is selected, 'THU' is mandatory";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsg = strErrMsg.Trim();
            return blStatus;
        }


        private void dgvRoles_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvRoles.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvRoles.Font);

                if (dgvRoles.RowHeadersWidth < (int)(size.Width + 20)) dgvRoles.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
