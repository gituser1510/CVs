﻿namespace IndxReactNarr
{
    partial class frmEditPAR_TMD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMain = new System.Windows.Forms.Panel();
            this.rtbPAR_TMD = new System.Windows.Forms.RichTextBox();
           // this.ucSpecialChars1 = new CASRxnTool.ucSpecialChars();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.pnlCntrls = new System.Windows.Forms.Panel();
            this.lblPAR_TMD = new System.Windows.Forms.Label();
            this.pnlMain.SuspendLayout();
            this.pnlBottom.SuspendLayout();
            this.pnlCntrls.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.pnlCntrls);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1219, 176);
            this.pnlMain.TabIndex = 0;
            // 
            // rtbPAR_TMD
            // 
            this.rtbPAR_TMD.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.rtbPAR_TMD.Location = new System.Drawing.Point(48, 3);
            this.rtbPAR_TMD.Name = "rtbPAR_TMD";
            this.rtbPAR_TMD.Size = new System.Drawing.Size(1168, 76);
            this.rtbPAR_TMD.TabIndex = 0;
            this.rtbPAR_TMD.Text = "";
            // 
            // ucSpecialChars1
            // 
            //this.ucSpecialChars1.Dock = System.Windows.Forms.DockStyle.Bottom;
            //this.ucSpecialChars1.Location = new System.Drawing.Point(0, 80);
            //this.ucSpecialChars1.Name = "ucSpecialChars1";
            //this.ucSpecialChars1.Size = new System.Drawing.Size(1219, 67);
            //this.ucSpecialChars1.TabIndex = 1;
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom.Controls.Add(this.button1);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 147);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(1219, 29);
            this.pnlBottom.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1140, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // pnlCntrls
            // 
            this.pnlCntrls.Controls.Add(this.lblPAR_TMD);
            //this.pnlCntrls.Controls.Add(this.ucSpecialChars1);
            this.pnlCntrls.Controls.Add(this.rtbPAR_TMD);
            this.pnlCntrls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlCntrls.Location = new System.Drawing.Point(0, 0);
            this.pnlCntrls.Name = "pnlCntrls";
            this.pnlCntrls.Size = new System.Drawing.Size(1219, 147);
            this.pnlCntrls.TabIndex = 3;
            // 
            // lblPAR_TMD
            // 
            this.lblPAR_TMD.AutoSize = true;
            this.lblPAR_TMD.Location = new System.Drawing.Point(12, 6);
            this.lblPAR_TMD.Name = "lblPAR_TMD";
            this.lblPAR_TMD.Size = new System.Drawing.Size(30, 15);
            this.lblPAR_TMD.TabIndex = 2;
            this.lblPAR_TMD.Text = "PAR";
            // 
            // frmEditPAR_TMD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1219, 176);
            this.Controls.Add(this.pnlMain);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmEditPAR_TMD";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Edit PAR/TMD";
            this.pnlMain.ResumeLayout(false);
            this.pnlBottom.ResumeLayout(false);
            this.pnlCntrls.ResumeLayout(false);
            this.pnlCntrls.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        //private CASRxnTool.ucSpecialChars ucSpecialChars1;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel pnlCntrls;
        private System.Windows.Forms.Label lblPAR_TMD;
        public System.Windows.Forms.RichTextBox rtbPAR_TMD;
    }
}