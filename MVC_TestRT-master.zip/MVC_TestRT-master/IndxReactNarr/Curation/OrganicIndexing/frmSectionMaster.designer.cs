﻿namespace IndxReactNarr
{
    partial class frmSectionMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvSectionMaster = new System.Windows.Forms.DataGridView();
            this.colSectionID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSection_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSection_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSection_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDisplay_Order = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.splContSecSubSec = new System.Windows.Forms.SplitContainer();
            this.dgvSubSections = new System.Windows.Forms.DataGridView();
            this.colSubSecNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSubSecName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlSearch = new System.Windows.Forms.Panel();
            this.lblTan = new System.Windows.Forms.Label();
            this.txtSrchSection = new System.Windows.Forms.TextBox();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSectionMaster)).BeginInit();
            this.pnlMain.SuspendLayout();
            this.splContSecSubSec.Panel1.SuspendLayout();
            this.splContSecSubSec.Panel2.SuspendLayout();
            this.splContSecSubSec.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSubSections)).BeginInit();
            this.pnlSearch.SuspendLayout();
            this.pnlBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvSectionMaster
            // 
            this.dgvSectionMaster.AllowUserToAddRows = false;
            this.dgvSectionMaster.AllowUserToDeleteRows = false;
            this.dgvSectionMaster.AllowUserToResizeRows = false;
            this.dgvSectionMaster.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSectionMaster.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvSectionMaster.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSectionMaster.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSectionID,
            this.colSection_ID,
            this.colSection_Name,
            this.colSection_Code,
            this.colDisplay_Order});
            this.dgvSectionMaster.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSectionMaster.Location = new System.Drawing.Point(0, 0);
            this.dgvSectionMaster.MultiSelect = false;
            this.dgvSectionMaster.Name = "dgvSectionMaster";
            this.dgvSectionMaster.ReadOnly = true;
            this.dgvSectionMaster.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvSectionMaster.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSectionMaster.Size = new System.Drawing.Size(521, 364);
            this.dgvSectionMaster.StandardTab = true;
            this.dgvSectionMaster.TabIndex = 4;
            this.dgvSectionMaster.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSectionMaster_CellDoubleClick);
            this.dgvSectionMaster.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSectionMaster_RowEnter);
            this.dgvSectionMaster.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvSectionMaster_RowPostPaint);
            // 
            // colSectionID
            // 
            this.colSectionID.HeaderText = "SectionID";
            this.colSectionID.Name = "colSectionID";
            this.colSectionID.ReadOnly = true;
            this.colSectionID.Visible = false;
            // 
            // colSection_ID
            // 
            this.colSection_ID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colSection_ID.HeaderText = "Sec.No";
            this.colSection_ID.Name = "colSection_ID";
            this.colSection_ID.ReadOnly = true;
            this.colSection_ID.Width = 60;
            // 
            // colSection_Name
            // 
            this.colSection_Name.HeaderText = "Section Name";
            this.colSection_Name.Name = "colSection_Name";
            this.colSection_Name.ReadOnly = true;
            // 
            // colSection_Code
            // 
            this.colSection_Code.HeaderText = "Section Code";
            this.colSection_Code.Name = "colSection_Code";
            this.colSection_Code.ReadOnly = true;
            this.colSection_Code.Visible = false;
            // 
            // colDisplay_Order
            // 
            this.colDisplay_Order.HeaderText = "Display Order";
            this.colDisplay_Order.Name = "colDisplay_Order";
            this.colDisplay_Order.ReadOnly = true;
            this.colDisplay_Order.Visible = false;
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.splContSecSubSec);
            this.pnlMain.Controls.Add(this.pnlSearch);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(966, 428);
            this.pnlMain.TabIndex = 5;
            // 
            // splContSecSubSec
            // 
            this.splContSecSubSec.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splContSecSubSec.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContSecSubSec.Location = new System.Drawing.Point(0, 32);
            this.splContSecSubSec.Name = "splContSecSubSec";
            // 
            // splContSecSubSec.Panel1
            // 
            this.splContSecSubSec.Panel1.Controls.Add(this.dgvSectionMaster);
            // 
            // splContSecSubSec.Panel2
            // 
            this.splContSecSubSec.Panel2.Controls.Add(this.dgvSubSections);
            this.splContSecSubSec.Size = new System.Drawing.Size(966, 366);
            this.splContSecSubSec.SplitterDistance = 523;
            this.splContSecSubSec.TabIndex = 7;
            // 
            // dgvSubSections
            // 
            this.dgvSubSections.AllowUserToAddRows = false;
            this.dgvSubSections.AllowUserToDeleteRows = false;
            this.dgvSubSections.AllowUserToResizeRows = false;
            this.dgvSubSections.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSubSections.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvSubSections.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSubSections.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSubSecNo,
            this.colSubSecName});
            this.dgvSubSections.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSubSections.Location = new System.Drawing.Point(0, 0);
            this.dgvSubSections.Name = "dgvSubSections";
            this.dgvSubSections.ReadOnly = true;
            this.dgvSubSections.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvSubSections.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSubSections.Size = new System.Drawing.Size(437, 364);
            this.dgvSubSections.StandardTab = true;
            this.dgvSubSections.TabIndex = 5;
            this.dgvSubSections.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvSubSections_RowPostPaint);
            // 
            // colSubSecNo
            // 
            this.colSubSecNo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colSubSecNo.HeaderText = "Sec.No";
            this.colSubSecNo.Name = "colSubSecNo";
            this.colSubSecNo.ReadOnly = true;
            this.colSubSecNo.Width = 60;
            // 
            // colSubSecName
            // 
            this.colSubSecName.HeaderText = "Sub Section Name";
            this.colSubSecName.Name = "colSubSecName";
            this.colSubSecName.ReadOnly = true;
            // 
            // pnlSearch
            // 
            this.pnlSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSearch.Controls.Add(this.lblTan);
            this.pnlSearch.Controls.Add(this.txtSrchSection);
            this.pnlSearch.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSearch.Location = new System.Drawing.Point(0, 0);
            this.pnlSearch.Name = "pnlSearch";
            this.pnlSearch.Size = new System.Drawing.Size(966, 32);
            this.pnlSearch.TabIndex = 6;
            // 
            // lblTan
            // 
            this.lblTan.AutoSize = true;
            this.lblTan.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTan.ForeColor = System.Drawing.Color.Black;
            this.lblTan.Location = new System.Drawing.Point(5, 8);
            this.lblTan.Name = "lblTan";
            this.lblTan.Size = new System.Drawing.Size(90, 15);
            this.lblTan.TabIndex = 207;
            this.lblTan.Text = "Search Section";
            // 
            // txtSrchSection
            // 
            this.txtSrchSection.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSrchSection.Location = new System.Drawing.Point(101, 4);
            this.txtSrchSection.Name = "txtSrchSection";
            this.txtSrchSection.Size = new System.Drawing.Size(861, 22);
            this.txtSrchSection.TabIndex = 0;
            this.txtSrchSection.TextChanged += new System.EventHandler(this.txtSrchSection_TextChanged);
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom.Controls.Add(this.btnSubmit);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 398);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(966, 30);
            this.pnlBottom.TabIndex = 5;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSubmit.Location = new System.Drawing.Point(886, 1);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 26);
            this.btnSubmit.TabIndex = 0;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn1.DataPropertyName = "SECTION_ID";
            this.dataGridViewTextBoxColumn1.HeaderText = "Section ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Visible = false;
            this.dataGridViewTextBoxColumn1.Width = 259;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn2.DataPropertyName = "SECTION_NAME";
            this.dataGridViewTextBoxColumn2.HeaderText = "Section Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 260;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "SECTION_CODE";
            this.dataGridViewTextBoxColumn3.HeaderText = "Section Code";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Visible = false;
            this.dataGridViewTextBoxColumn3.Width = 260;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "DISPLAY_ORDER";
            this.dataGridViewTextBoxColumn4.HeaderText = "Display Order";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Visible = false;
            this.dataGridViewTextBoxColumn4.Width = 260;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn5.DataPropertyName = "SECTION_ID";
            this.dataGridViewTextBoxColumn5.HeaderText = "Sec.No";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Visible = false;
            this.dataGridViewTextBoxColumn5.Width = 60;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn6.DataPropertyName = "SECTION_NAME";
            this.dataGridViewTextBoxColumn6.HeaderText = "Sub Section Name";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 334;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "Sub Section Name";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 334;
            // 
            // frmSectionMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(966, 428);
            this.Controls.Add(this.pnlMain);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSectionMaster";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Section Master";
            this.Load += new System.EventHandler(this.frmSectionMaster_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSectionMaster)).EndInit();
            this.pnlMain.ResumeLayout(false);
            this.splContSecSubSec.Panel1.ResumeLayout(false);
            this.splContSecSubSec.Panel2.ResumeLayout(false);
            this.splContSecSubSec.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSubSections)).EndInit();
            this.pnlSearch.ResumeLayout(false);
            this.pnlSearch.PerformLayout();
            this.pnlBottom.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvSectionMaster;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.Panel pnlSearch;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.TextBox txtSrchSection;
        private System.Windows.Forms.Label lblTan;
        private System.Windows.Forms.SplitContainer splContSecSubSec;
        private System.Windows.Forms.DataGridView dgvSubSections;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSectionID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSection_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSection_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSection_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDisplay_Order;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSubSecNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSubSecName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
    }
}

