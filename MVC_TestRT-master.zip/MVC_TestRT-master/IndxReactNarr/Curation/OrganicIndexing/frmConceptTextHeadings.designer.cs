﻿namespace IndxReactNarr
{
    partial class frmConceptTextHeadings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvCTH = new System.Windows.Forms.DataGridView();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.txtCTHName = new System.Windows.Forms.TextBox();
            this.lblNrnReg = new System.Windows.Forms.Label();
            this.txtCTHClass = new System.Windows.Forms.TextBox();
            this.lblCTHClass = new System.Windows.Forms.Label();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCthClass = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCthName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCTHType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCTHCategory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCTH)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.dgvCTH);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(918, 488);
            this.pnlMain.TabIndex = 4;
            // 
            // dgvCTH
            // 
            this.dgvCTH.AllowUserToAddRows = false;
            this.dgvCTH.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvCTH.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvCTH.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvCTH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCTH.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCthClass,
            this.colCthName,
            this.colCTHType,
            this.colCTHCategory});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCTH.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvCTH.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCTH.Location = new System.Drawing.Point(0, 34);
            this.dgvCTH.Name = "dgvCTH";
            this.dgvCTH.ReadOnly = true;
            this.dgvCTH.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCTH.Size = new System.Drawing.Size(918, 454);
            this.dgvCTH.TabIndex = 7;
            this.dgvCTH.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCTH_CellDoubleClick);
            this.dgvCTH.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvCTH_RowPostPaint);
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.White;
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.txtCTHName);
            this.pnlTop.Controls.Add(this.lblNrnReg);
            this.pnlTop.Controls.Add(this.txtCTHClass);
            this.pnlTop.Controls.Add(this.lblCTHClass);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(918, 34);
            this.pnlTop.TabIndex = 0;
            // 
            // txtCTHName
            // 
            this.txtCTHName.BackColor = System.Drawing.Color.White;
            this.txtCTHName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCTHName.Location = new System.Drawing.Point(282, 4);
            this.txtCTHName.Name = "txtCTHName";
            this.txtCTHName.Size = new System.Drawing.Size(631, 25);
            this.txtCTHName.TabIndex = 12;
            this.txtCTHName.TextChanged += new System.EventHandler(this.txtCTHClass_TextChanged);
            // 
            // lblNrnReg
            // 
            this.lblNrnReg.AutoSize = true;
            this.lblNrnReg.Location = new System.Drawing.Point(200, 8);
            this.lblNrnReg.Name = "lblNrnReg";
            this.lblNrnReg.Size = new System.Drawing.Size(78, 17);
            this.lblNrnReg.TabIndex = 11;
            this.lblNrnReg.Text = "CTH Name";
            // 
            // txtCTHClass
            // 
            this.txtCTHClass.BackColor = System.Drawing.Color.White;
            this.txtCTHClass.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCTHClass.Location = new System.Drawing.Point(81, 4);
            this.txtCTHClass.Name = "txtCTHClass";
            this.txtCTHClass.Size = new System.Drawing.Size(100, 25);
            this.txtCTHClass.TabIndex = 10;
            this.txtCTHClass.TextChanged += new System.EventHandler(this.txtCTHClass_TextChanged);
            // 
            // lblCTHClass
            // 
            this.lblCTHClass.AutoSize = true;
            this.lblCTHClass.Location = new System.Drawing.Point(3, 8);
            this.lblCTHClass.Name = "lblCTHClass";
            this.lblCTHClass.Size = new System.Drawing.Size(74, 17);
            this.lblCTHClass.TabIndex = 9;
            this.lblCTHClass.Text = "CTH Class";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "CTH Class";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.HeaderText = "CTH Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn3.HeaderText = "Type";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Visible = false;
            this.dataGridViewTextBoxColumn3.Width = 70;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn4.HeaderText = "Category";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Visible = false;
            this.dataGridViewTextBoxColumn4.Width = 80;
            // 
            // colCthClass
            // 
            this.colCthClass.HeaderText = "CTH Class";
            this.colCthClass.Name = "colCthClass";
            this.colCthClass.ReadOnly = true;
            // 
            // colCthName
            // 
            this.colCthName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colCthName.HeaderText = "CTH Name";
            this.colCthName.Name = "colCthName";
            this.colCthName.ReadOnly = true;
            // 
            // colCTHType
            // 
            this.colCTHType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colCTHType.HeaderText = "Type";
            this.colCTHType.Name = "colCTHType";
            this.colCTHType.ReadOnly = true;
            this.colCTHType.Visible = false;
            this.colCTHType.Width = 80;
            // 
            // colCTHCategory
            // 
            this.colCTHCategory.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colCTHCategory.HeaderText = "Category";
            this.colCTHCategory.Name = "colCTHCategory";
            this.colCTHCategory.ReadOnly = true;
            this.colCTHCategory.Visible = false;
            this.colCTHCategory.Width = 80;
            // 
            // frmConceptTextHeadings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(918, 488);
            this.Controls.Add(this.pnlMain);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmConceptTextHeadings";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Concept Text Headings";
            this.Load += new System.EventHandler(this.frmConceptTextHeadings_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCTH)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.DataGridView dgvCTH;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.TextBox txtCTHName;
        private System.Windows.Forms.Label lblNrnReg;
        private System.Windows.Forms.TextBox txtCTHClass;
        private System.Windows.Forms.Label lblCTHClass;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCthClass;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCthName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCTHType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCTHCategory;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
    }
}