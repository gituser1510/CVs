﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;

namespace IndxReactNarr.Curation.OrgIndexing
{
    public partial class frmCrossReference : Form
    {
        public frmCrossReference()
        {
            InitializeComponent();
        }

        public string SelCrossRefs { get; set; } 

        private void frmCrossReference_Load(object sender, EventArgs e)
        {
            try
            {
                //Bind Cross Reference Sections to grid
                BindCrossReferenceSectionsToGrid();

                //Check and select role
                CheckAndSelectCrossRefSectionsInGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindCrossReferenceSectionsToGrid()
        {
            try
            {
                if (GlobalVariables.IndexingRoles != null)
                {
                    dgvCrossRef.AutoGenerateColumns = false;
                    dgvCrossRef.DataSource = GlobalVariables.IndexingSections;

                    colSectionID.DataPropertyName = "SECTION_ID";
                    colSectionName.DataPropertyName = "SECTION_NAME";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void CheckAndSelectCrossRefSectionsInGrid()
        {
            try
            {
                //Check and Select Indexing roles
                if (!string.IsNullOrEmpty(SelCrossRefs))
                {
                    string[] saRoles = SelCrossRefs.Trim().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                    if (saRoles != null)
                    {
                        if (saRoles.Length > 0)
                        {
                            foreach (string role in saRoles)
                            {
                                foreach (DataGridViewRow row in dgvCrossRef.Rows)
                                {
                                    if (row.Cells[1].Value != null)
                                    {
                                        if (row.Cells[1].Value.ToString().Trim() == role.Trim())
                                        {
                                            row.Cells[0].Value = true;
                                            row.DefaultCellStyle.BackColor = Color.Azure;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                string strRole = string.Empty;
                foreach (DataGridViewRow row in dgvCrossRef.Rows)
                {
                    if (row.Cells[0].Value != null &&
                           Convert.ToBoolean(row.Cells[0].Value) == true)
                    {
                        strRole += (row.Cells[1].Value + " ");
                    }
                }
                
                SelCrossRefs = strRole.Trim();
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvCrossRef_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvCrossRef.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvCrossRef.Font);

                if (dgvCrossRef.RowHeadersWidth < (int)(size.Width + 20)) dgvCrossRef.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
