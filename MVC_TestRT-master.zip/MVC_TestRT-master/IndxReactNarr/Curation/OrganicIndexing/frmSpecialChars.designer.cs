﻿namespace IndxReactNarr
{
    partial class frmSpecialChars
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ucSplCharsToolStrip = new IndxReactNarr.ucSplCharsToolStrip();
            this.SuspendLayout();
            // 
            // ucSplCharsToolStrip
            // 
            this.ucSplCharsToolStrip.BackColor = System.Drawing.Color.White;
            this.ucSplCharsToolStrip.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ucSplCharsToolStrip.Dock = System.Windows.Forms.DockStyle.Top;
            this.ucSplCharsToolStrip.Location = new System.Drawing.Point(0, 0);
            this.ucSplCharsToolStrip.Name = "ucSplCharsToolStrip";
            this.ucSplCharsToolStrip.Size = new System.Drawing.Size(1132, 52);
            this.ucSplCharsToolStrip.TabIndex = 0;            
            // 
            // frmSpecialChars
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1132, 52);
            this.Controls.Add(this.ucSplCharsToolStrip);
            this.DockAreas = WeifenLuo.WinFormsUI.Docking.DockAreas.DockTop;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSpecialChars";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.TabText = "Special Chars Panel";
            this.Text = "Special Chars";
            this.ResumeLayout(false);

        }

        #endregion

        private ucSplCharsToolStrip ucSplCharsToolStrip;
    }
}