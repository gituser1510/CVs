﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;

namespace IndxReactNarr
{
    public partial class frmNUM_SEQ : Form
    {
        public frmNUM_SEQ()
        {
            InitializeComponent();
        }

        #region Property Procedures
        
        public DataTable Num_Seq_Data
        { get; set; }

        public string RxnNUM_Sel
        { get; set; }

        public string RxnSeq_Sel
        { get; set; }

        public int RxnID_Sel
        { get; set; } 

        #endregion

        private void frmNUM_SEQ_Load(object sender, EventArgs e)
        {
            try
            {
                //Change Column datatype for filtering option
                if (Num_Seq_Data != null)
                {
                    DataTable dtRxnsData = Num_Seq_Data.Clone();
                    dtRxnsData.Columns["RXN_NUM"].DataType = System.Type.GetType("System.String");
                    dtRxnsData.Columns["RXN_SEQ"].DataType = System.Type.GetType("System.String");

                    foreach (DataRow dr in Num_Seq_Data.Rows)
                    {
                        dtRxnsData.ImportRow(dr);
                    }
                    Num_Seq_Data = dtRxnsData;
                }                
                
                BindNUMSeqDataToGrid(Num_Seq_Data);
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindNUMSeqDataToGrid(DataTable num_seqdata)
        {
            try
            {
                if (num_seqdata != null)
                {
                    dgvNUM_Seq.AutoGenerateColumns = false;
                    dgvNUM_Seq.DataSource = num_seqdata;

                    colRxnID.DataPropertyName = "RXN_ID";
                    colRxnNUM.DataPropertyName = "RXN_NUM";
                    colRxnSeq.DataPropertyName = "RXN_SEQ";
                }
                else
                {
                    dgvNUM_Seq.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvNUM_Seq_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                {
                    RxnNUM_Sel = dgvNUM_Seq.Rows[e.RowIndex].Cells[colRxnNUM.Name].Value.ToString();
                    RxnSeq_Sel = dgvNUM_Seq.Rows[e.RowIndex].Cells[colRxnSeq.Name].Value.ToString();

                    RxnID_Sel = dgvNUM_Seq.Rows[e.RowIndex].Cells[colRxnID.Name].Value != null ? Convert.ToInt32(dgvNUM_Seq.Rows[e.RowIndex].Cells[colRxnID.Name].Value) : 0;

                    DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvNUM_Seq_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvNUM_Seq.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvNUM_Seq.Font);

                if (dgvNUM_Seq.RowHeadersWidth < (int)(size.Width + 20)) dgvNUM_Seq.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtRxnNUM_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (Num_Seq_Data != null)
                {
                    if (!string.IsNullOrEmpty(txtRxnNUM.Text.Trim()))
                    {
                        DataView dtView = Num_Seq_Data.Copy().DefaultView;
                        dtView.RowFilter = "RXN_NUM like '" + txtRxnNUM.Text.Trim() + "%'"; 
                        DataTable dtFiltData = dtView.ToTable();
                        BindNUMSeqDataToGrid(dtFiltData);
                    }
                    else
                    {
                        BindNUMSeqDataToGrid(Num_Seq_Data);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
