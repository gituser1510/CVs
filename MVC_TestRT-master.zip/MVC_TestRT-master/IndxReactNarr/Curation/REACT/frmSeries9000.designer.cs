﻿namespace IndxReactNarr
{
    partial class frmSeries9000
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvOrgRef = new System.Windows.Forms.DataGridView();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.txtNrnReg = new System.Windows.Forms.TextBox();
            this.lblNrnReg = new System.Windows.Forms.Label();
            this.txtNrnNum = new System.Windows.Forms.TextBox();
            this.lblNrnNum = new System.Windows.Forms.Label();
            this.colNUM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRegNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOrgRefName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrgRef)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.dgvOrgRef);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(754, 482);
            this.pnlMain.TabIndex = 1;
            // 
            // dgvOrgRef
            // 
            this.dgvOrgRef.AllowUserToAddRows = false;
            this.dgvOrgRef.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvOrgRef.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvOrgRef.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvOrgRef.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrgRef.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colNUM,
            this.colRegNo,
            this.colOrgRefName});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvOrgRef.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvOrgRef.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvOrgRef.Location = new System.Drawing.Point(0, 34);
            this.dgvOrgRef.Name = "dgvOrgRef";
            this.dgvOrgRef.ReadOnly = true;
            this.dgvOrgRef.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvOrgRef.Size = new System.Drawing.Size(754, 448);
            this.dgvOrgRef.TabIndex = 7;
            this.dgvOrgRef.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgOrgRef_CellDoubleClick);
            this.dgvOrgRef.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgOrgRef_RowPostPaint);
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.txtName);
            this.pnlTop.Controls.Add(this.lblName);
            this.pnlTop.Controls.Add(this.txtNrnReg);
            this.pnlTop.Controls.Add(this.lblNrnReg);
            this.pnlTop.Controls.Add(this.txtNrnNum);
            this.pnlTop.Controls.Add(this.lblNrnNum);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(754, 34);
            this.pnlTop.TabIndex = 0;
            // 
            // txtName
            // 
            this.txtName.BackColor = System.Drawing.Color.White;
            this.txtName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(409, 4);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(341, 25);
            this.txtName.TabIndex = 14;
            this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(362, 8);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(44, 17);
            this.lblName.TabIndex = 13;
            this.lblName.Text = "Name";
            // 
            // txtNrnReg
            // 
            this.txtNrnReg.BackColor = System.Drawing.Color.White;
            this.txtNrnReg.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNrnReg.Location = new System.Drawing.Point(250, 4);
            this.txtNrnReg.Name = "txtNrnReg";
            this.txtNrnReg.Size = new System.Drawing.Size(100, 25);
            this.txtNrnReg.TabIndex = 12;
            this.txtNrnReg.TextChanged += new System.EventHandler(this.txtNrnReg_TextChanged);
            // 
            // lblNrnReg
            // 
            this.lblNrnReg.AutoSize = true;
            this.lblNrnReg.Location = new System.Drawing.Point(192, 8);
            this.lblNrnReg.Name = "lblNrnReg";
            this.lblNrnReg.Size = new System.Drawing.Size(54, 17);
            this.lblNrnReg.TabIndex = 11;
            this.lblNrnReg.Text = "Reg.No";
            // 
            // txtNrnNum
            // 
            this.txtNrnNum.BackColor = System.Drawing.Color.White;
            this.txtNrnNum.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNrnNum.Location = new System.Drawing.Point(82, 4);
            this.txtNrnNum.Name = "txtNrnNum";
            this.txtNrnNum.Size = new System.Drawing.Size(100, 25);
            this.txtNrnNum.TabIndex = 10;
            this.txtNrnNum.TextChanged += new System.EventHandler(this.txtNrnNum_TextChanged);
            // 
            // lblNrnNum
            // 
            this.lblNrnNum.AutoSize = true;
            this.lblNrnNum.Location = new System.Drawing.Point(4, 8);
            this.lblNrnNum.Name = "lblNrnNum";
            this.lblNrnNum.Size = new System.Drawing.Size(76, 17);
            this.lblNrnNum.TabIndex = 9;
            this.lblNrnNum.Text = "Series 9000";
            // 
            // colNUM
            // 
            this.colNUM.HeaderText = "Series 9000";
            this.colNUM.Name = "colNUM";
            this.colNUM.ReadOnly = true;
            // 
            // colRegNo
            // 
            this.colRegNo.HeaderText = "RegNo";
            this.colRegNo.Name = "colRegNo";
            this.colRegNo.ReadOnly = true;
            // 
            // colOrgRefName
            // 
            this.colOrgRefName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colOrgRefName.HeaderText = "Name";
            this.colOrgRefName.Name = "colOrgRefName";
            this.colOrgRefName.ReadOnly = true;
            // 
            // frmSeries9000
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(754, 482);
            this.Controls.Add(this.pnlMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSeries9000";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Series 9000";
            this.Load += new System.EventHandler(this.frmSeries9000_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrgRef)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.DataGridView dgvOrgRef;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtNrnReg;
        private System.Windows.Forms.Label lblNrnReg;
        private System.Windows.Forms.TextBox txtNrnNum;
        private System.Windows.Forms.Label lblNrnNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNUM;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRegNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOrgRefName;
    }
}