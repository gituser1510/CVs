﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarrDAL;
using IndxReactNarr.Generic;

namespace IndxReactNarr
{
    public partial class frmIndexingReactTAN : Form
    {
        public frmIndexingReactTAN()
        {
            InitializeComponent();
        }

        public string SelectedTool { get; set; }
        public string SelectedTAN { get; set; }
        public int TAN_ID { get; set; }
        public DataTable TANDetails { get; set; }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtTAN.Text.Trim()))
                {
                    //Check for TAN exist
                    DataTable dtTanDtls = ReactDB.GetTANDetailsOnTANName(txtTAN.Text.Trim());
                    if (dtTanDtls != null)
                    {
                        if (dtTanDtls.Rows.Count > 0)
                        {
                            SelectedTool = "REACT";

                            TAN_ID = Convert.ToInt32(dtTanDtls.Rows[0]["TAN_ID"].ToString());
                            SelectedTAN = txtTAN.Text.Trim();
                            TANDetails = dtTanDtls;
                            DialogResult = DialogResult.OK;
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("TAN is not available", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("TAN is not available", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
