﻿namespace IndxReactNarr
{
    partial class frmNUMs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            MDL.Draw.Chemistry.Molecule molecule1 = new MDL.Draw.Chemistry.Molecule();
            MDL.Draw.Renderer.Preferences.DisplayPreferences displayPreferences1 = new MDL.Draw.Renderer.Preferences.DisplayPreferences();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.splCont = new System.Windows.Forms.SplitContainer();
            this.dgvNUMs = new System.Windows.Forms.DataGridView();
            this.colNUM_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNUM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRegNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRole = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMolImage = new System.Windows.Forms.DataGridViewImageColumn();
            this.colMolHexCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMolFile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pbChemImg = new System.Windows.Forms.PictureBox();
            this.renderer1 = new MDL.Draw.Renderer.Renderer();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.pnlSearch = new System.Windows.Forms.Panel();
            this.txtRegNo = new System.Windows.Forms.TextBox();
            this.lblNrnNum = new System.Windows.Forms.Label();
            this.txtNUM = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblNrnReg = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.pnlOptions = new System.Windows.Forms.Panel();
            this.rbnSer8000 = new System.Windows.Forms.RadioButton();
            this.rbnSer9000 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.rbnSer8500 = new System.Windows.Forms.RadioButton();
            this.rbnNUMs = new System.Windows.Forms.RadioButton();
            this.pnlNewRxn = new System.Windows.Forms.Panel();
            this.txtSeq_Insert = new System.Windows.Forms.TextBox();
            this.txtNUM_Insert = new System.Windows.Forms.TextBox();
            this.chkDupRxn = new System.Windows.Forms.CheckBox();
            this.grpDupRxn = new System.Windows.Forms.GroupBox();
            this.txtSeq_Dup = new System.Windows.Forms.TextBox();
            this.txtNUM_Dup = new System.Windows.Forms.TextBox();
            this.lblProdNo = new System.Windows.Forms.Label();
            this.lblRxnSeq = new System.Windows.Forms.Label();
            this.lblRXNNUM = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.rbnAfter = new System.Windows.Forms.RadioButton();
            this.rbnBefore = new System.Windows.Forms.RadioButton();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splCont)).BeginInit();
            this.splCont.Panel1.SuspendLayout();
            this.splCont.Panel2.SuspendLayout();
            this.splCont.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNUMs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbChemImg)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.pnlSearch.SuspendLayout();
            this.pnlOptions.SuspendLayout();
            this.pnlNewRxn.SuspendLayout();
            this.grpDupRxn.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.splCont);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 33);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1170, 447);
            this.pnlMain.TabIndex = 3;
            // 
            // splCont
            // 
            this.splCont.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splCont.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splCont.Location = new System.Drawing.Point(0, 60);
            this.splCont.Name = "splCont";
            // 
            // splCont.Panel1
            // 
            this.splCont.Panel1.Controls.Add(this.dgvNUMs);
            // 
            // splCont.Panel2
            // 
            this.splCont.Panel2.Controls.Add(this.pbChemImg);
            this.splCont.Panel2.Controls.Add(this.renderer1);
            this.splCont.Size = new System.Drawing.Size(1170, 387);
            this.splCont.SplitterDistance = 751;
            this.splCont.TabIndex = 8;
            // 
            // dgvNUMs
            // 
            this.dgvNUMs.AllowUserToAddRows = false;
            this.dgvNUMs.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.HighlightText;
            this.dgvNUMs.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvNUMs.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvNUMs.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            this.dgvNUMs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNUMs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colNUM_ID,
            this.colNUM,
            this.colRegNo,
            this.colName,
            this.colRole,
            this.colMolImage,
            this.colMolHexCode,
            this.colMolFile});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvNUMs.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvNUMs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvNUMs.Location = new System.Drawing.Point(0, 0);
            this.dgvNUMs.Name = "dgvNUMs";
            this.dgvNUMs.ReadOnly = true;
            this.dgvNUMs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvNUMs.Size = new System.Drawing.Size(749, 385);
            this.dgvNUMs.TabIndex = 7;
            this.dgvNUMs.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNUMs_CellDoubleClick);
            this.dgvNUMs.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgvNUMs_DataError);
            this.dgvNUMs.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNUMs_RowEnter);
            this.dgvNUMs.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvNUMs_RowPostPaint);
            // 
            // colNUM_ID
            // 
            this.colNUM_ID.HeaderText = "NUM_ID";
            this.colNUM_ID.Name = "colNUM_ID";
            this.colNUM_ID.ReadOnly = true;
            this.colNUM_ID.Visible = false;
            // 
            // colNUM
            // 
            this.colNUM.HeaderText = "NUM";
            this.colNUM.Name = "colNUM";
            this.colNUM.ReadOnly = true;
            // 
            // colRegNo
            // 
            this.colRegNo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colRegNo.HeaderText = "RegistryNo";
            this.colRegNo.Name = "colRegNo";
            this.colRegNo.ReadOnly = true;
            // 
            // colName
            // 
            this.colName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colName.HeaderText = "Name";
            this.colName.Name = "colName";
            this.colName.ReadOnly = true;
            // 
            // colRole
            // 
            this.colRole.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colRole.HeaderText = "Role";
            this.colRole.Name = "colRole";
            this.colRole.ReadOnly = true;
            // 
            // colMolImage
            // 
            this.colMolImage.HeaderText = "MolImage";
            this.colMolImage.Name = "colMolImage";
            this.colMolImage.ReadOnly = true;
            this.colMolImage.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colMolImage.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colMolImage.Visible = false;
            // 
            // colMolHexCode
            // 
            this.colMolHexCode.HeaderText = "MolHexCode";
            this.colMolHexCode.Name = "colMolHexCode";
            this.colMolHexCode.ReadOnly = true;
            this.colMolHexCode.Visible = false;
            // 
            // colMolFile
            // 
            this.colMolFile.HeaderText = "MolFile";
            this.colMolFile.Name = "colMolFile";
            this.colMolFile.ReadOnly = true;
            this.colMolFile.Visible = false;
            // 
            // pbChemImg
            // 
            this.pbChemImg.BackColor = System.Drawing.Color.White;
            this.pbChemImg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbChemImg.Location = new System.Drawing.Point(0, 0);
            this.pbChemImg.Name = "pbChemImg";
            this.pbChemImg.Size = new System.Drawing.Size(413, 385);
            this.pbChemImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbChemImg.TabIndex = 1;
            this.pbChemImg.TabStop = false;
            // 
            // renderer1
            // 
            this.renderer1.AutoSizeStructure = true;
            this.renderer1.BinHexSketch = "01030004412400214372656174656420627920416363656C7279734472617720342E322E302E36303" +
    "502040000005805000000005905000000000B0B0005417269616C780000140200";
            this.renderer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.renderer1.ChimeString = null;
            this.renderer1.CopyingEnabled = true;
            this.renderer1.DisplayOnEmpty = null;
            this.renderer1.FileName = null;
            this.renderer1.HighlightInfo = "";
            this.renderer1.IsBitmapFromOLE = false;
            this.renderer1.Location = new System.Drawing.Point(177, 38);
            molecule1.ArrowDir = MDL.Draw.ArrowDirType.No;
            molecule1.ArrowStyle = MDL.Draw.ArrowStyleType.Empty;
            molecule1.AtomValenceDisplay = true;
            molecule1.BaseFormBoxSetting = 0;
            molecule1.BondLineThickness = 0D;
            molecule1.CarbonLabelDisplay = false;
            molecule1.ChemLabelFont = null;
            molecule1.ChemLabelFontString = "(none)";
            molecule1.ColorAtomsByTypeInSketch = false;
            molecule1.ConfigLabelFont = null;
            molecule1.ConfigLabelFontString = "(none)";
            molecule1.ConvertRingBondIntoOneToMany = true;
            molecule1.Coords = null;
            molecule1.DashSpacing = 0.1D;
            molecule1.DisplaySinCys = false;
            molecule1.DisplaySulfurInCysSequence = false;
            molecule1.DoubleBondWidth = 0.18D;
            molecule1.FillColor = System.Drawing.Color.Empty;
            molecule1.FillStyle = MDL.Draw.ChemGraphicsObject.FillStyles.SOLID;
            molecule1.ForeColor = System.Drawing.Color.Empty;
            molecule1.ForeColorString = "";
            molecule1.ForSubsequenceQuery = false;
            molecule1.HighlightChildren = "";
            molecule1.HighlightColor = System.Drawing.Color.Blue;
            molecule1.HydrogenDisplayMode = MDL.Draw.Chemistry.Atom.HydrogenDisplayMode.Off;
            molecule1.Id = 663;
            molecule1.Initial = "";
            molecule1.IsAModel = false;
            molecule1.IsARotatedModel = false;
            molecule1.KeepRSLabelsInSketch = true;
            molecule1.LastModifyChemText = -1;
            molecule1.MaintainXMLChildOrderFlag = false;
            molecule1.MustPerceiveStereo = true;
            molecule1.PenColor = System.Drawing.Color.Empty;
            molecule1.PenStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            molecule1.PenStyleToken = 0;
            molecule1.PenWidth = ((byte)(0));
            molecule1.PenWidthUnit = MDL.Draw.ChemGraphicsObject.PenWidthUnits.Default;
            molecule1.RefId = 663;
            molecule1.Replaced = false;
            molecule1.RgroupCleeanUpNeeded = false;
            molecule1.RgroupLabelsPresentFlag = false;
            molecule1.RLabelAtAbsCenter = "R";
            molecule1.RLabelAtAndCenter = "R*";
            molecule1.RLabelAtOrCenter = "(R)";
            molecule1.ScaleLabelsToBondLength = false;
            molecule1.Selected = false;
            molecule1.SequenceDictionary = null;
            molecule1.SequenceNeedsRealign = false;
            molecule1.SequenceView = MDL.Draw.Chemistry.Molecule.SequenceViewEnum.None;
            molecule1.Size = 0;
            molecule1.SkcWritten = false;
            molecule1.SkNumber = ((short)(0));
            molecule1.SLabelAtAbsCenter = "S";
            molecule1.SLabelAtAndCenter = "S*";
            molecule1.SLabelAtOrCenter = "(S)";
            molecule1.StandardBondLength = 0D;
            molecule1.StereoChemistryMode = MDL.Draw.Chemistry.Molecule.StereoChemistryModeEnum.And;
            molecule1.TextBorder = 0.1D;
            molecule1.Transparent = false;
            molecule1.UndoableEditListener = null;
            molecule1.WedgeWidth = 0.1D;
            molecule1.ZLayer = -99354;
            this.renderer1.Molecule = molecule1;
            this.renderer1.MolfileString = "";
            this.renderer1.Name = "renderer1";
            this.renderer1.PastingEnabled = true;
            this.renderer1.Preferences = displayPreferences1;
            this.renderer1.PreferencesFileName = "default.xml";
            this.renderer1.RendererBorderStyle = System.Windows.Forms.ButtonBorderStyle.Inset;
            this.renderer1.Size = new System.Drawing.Size(180, 153);
            this.renderer1.SketchString = "AQMABEEkACFDcmVhdGVkIGJ5IEFjY2VscnlzRHJhdyA0LjIuMC42MDUCBAAAAFgFAAAAAFkFAAAAAAsLA" +
    "AVBcmlhbHgAABQCAA==";
            this.renderer1.SmilesString = "";
            this.renderer1.TabIndex = 9;
            this.renderer1.URLEncodedMolfileString = "";
            this.renderer1.Visible = false;
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.White;
            this.pnlTop.Controls.Add(this.pnlSearch);
            this.pnlTop.Controls.Add(this.pnlOptions);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1170, 60);
            this.pnlTop.TabIndex = 0;
            // 
            // pnlSearch
            // 
            this.pnlSearch.Controls.Add(this.txtRegNo);
            this.pnlSearch.Controls.Add(this.lblNrnNum);
            this.pnlSearch.Controls.Add(this.txtNUM);
            this.pnlSearch.Controls.Add(this.txtName);
            this.pnlSearch.Controls.Add(this.lblNrnReg);
            this.pnlSearch.Controls.Add(this.lblName);
            this.pnlSearch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlSearch.Location = new System.Drawing.Point(0, 28);
            this.pnlSearch.Name = "pnlSearch";
            this.pnlSearch.Size = new System.Drawing.Size(1170, 32);
            this.pnlSearch.TabIndex = 29;
            // 
            // txtRegNo
            // 
            this.txtRegNo.BackColor = System.Drawing.Color.White;
            this.txtRegNo.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRegNo.Location = new System.Drawing.Point(241, 3);
            this.txtRegNo.Name = "txtRegNo";
            this.txtRegNo.Size = new System.Drawing.Size(129, 25);
            this.txtRegNo.TabIndex = 12;
            this.txtRegNo.TextChanged += new System.EventHandler(this.txtRegNo_TextChanged);
            // 
            // lblNrnNum
            // 
            this.lblNrnNum.AutoSize = true;
            this.lblNrnNum.Location = new System.Drawing.Point(51, 6);
            this.lblNrnNum.Name = "lblNrnNum";
            this.lblNrnNum.Size = new System.Drawing.Size(43, 17);
            this.lblNrnNum.TabIndex = 9;
            this.lblNrnNum.Text = "NUM";
            // 
            // txtNUM
            // 
            this.txtNUM.BackColor = System.Drawing.Color.White;
            this.txtNUM.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNUM.Location = new System.Drawing.Point(103, 3);
            this.txtNUM.Name = "txtNUM";
            this.txtNUM.Size = new System.Drawing.Size(61, 25);
            this.txtNUM.TabIndex = 0;
            this.txtNUM.TextChanged += new System.EventHandler(this.txtNUM_TextChanged);
            // 
            // txtName
            // 
            this.txtName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtName.BackColor = System.Drawing.Color.White;
            this.txtName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(416, 3);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(751, 25);
            this.txtName.TabIndex = 19;
            this.txtName.TextChanged += new System.EventHandler(this.txtNrnNUM_TextChanged);
            // 
            // lblNrnReg
            // 
            this.lblNrnReg.AutoSize = true;
            this.lblNrnReg.Location = new System.Drawing.Point(181, 7);
            this.lblNrnReg.Name = "lblNrnReg";
            this.lblNrnReg.Size = new System.Drawing.Size(54, 17);
            this.lblNrnReg.TabIndex = 11;
            this.lblNrnReg.Text = "Reg.No";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(371, 6);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(44, 17);
            this.lblName.TabIndex = 18;
            this.lblName.Text = "Name";
            // 
            // pnlOptions
            // 
            this.pnlOptions.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlOptions.Controls.Add(this.rbnSer8000);
            this.pnlOptions.Controls.Add(this.rbnSer9000);
            this.pnlOptions.Controls.Add(this.label1);
            this.pnlOptions.Controls.Add(this.rbnSer8500);
            this.pnlOptions.Controls.Add(this.rbnNUMs);
            this.pnlOptions.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlOptions.Location = new System.Drawing.Point(0, 0);
            this.pnlOptions.Name = "pnlOptions";
            this.pnlOptions.Size = new System.Drawing.Size(1170, 28);
            this.pnlOptions.TabIndex = 27;
            // 
            // rbnSer8000
            // 
            this.rbnSer8000.AutoSize = true;
            this.rbnSer8000.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnSer8000.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.rbnSer8000.Location = new System.Drawing.Point(401, 3);
            this.rbnSer8000.Name = "rbnSer8000";
            this.rbnSer8000.Size = new System.Drawing.Size(94, 21);
            this.rbnSer8000.TabIndex = 26;
            this.rbnSer8000.Text = "Series 8000";
            this.rbnSer8000.UseVisualStyleBackColor = true;
            this.rbnSer8000.CheckedChanged += new System.EventHandler(this.rbnNUM_CheckedChanged);
            // 
            // rbnSer9000
            // 
            this.rbnSer9000.AutoSize = true;
            this.rbnSer9000.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnSer9000.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.rbnSer9000.Location = new System.Drawing.Point(179, 3);
            this.rbnSer9000.Name = "rbnSer9000";
            this.rbnSer9000.Size = new System.Drawing.Size(94, 21);
            this.rbnSer9000.TabIndex = 24;
            this.rbnSer9000.Text = "Series 9000";
            this.rbnSer9000.UseVisualStyleBackColor = true;
            this.rbnSer9000.CheckedChanged += new System.EventHandler(this.rbnNUM_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 17);
            this.label1.TabIndex = 13;
            this.label1.Text = "NUM Type";
            // 
            // rbnSer8500
            // 
            this.rbnSer8500.AutoSize = true;
            this.rbnSer8500.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnSer8500.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.rbnSer8500.Location = new System.Drawing.Point(290, 3);
            this.rbnSer8500.Name = "rbnSer8500";
            this.rbnSer8500.Size = new System.Drawing.Size(94, 21);
            this.rbnSer8500.TabIndex = 25;
            this.rbnSer8500.Text = "Series 8500";
            this.rbnSer8500.UseVisualStyleBackColor = true;
            this.rbnSer8500.CheckedChanged += new System.EventHandler(this.rbnNUM_CheckedChanged);
            // 
            // rbnNUMs
            // 
            this.rbnNUMs.AutoSize = true;
            this.rbnNUMs.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnNUMs.ForeColor = System.Drawing.Color.Red;
            this.rbnNUMs.Location = new System.Drawing.Point(102, 3);
            this.rbnNUMs.Name = "rbnNUMs";
            this.rbnNUMs.Size = new System.Drawing.Size(61, 21);
            this.rbnNUMs.TabIndex = 21;
            this.rbnNUMs.Text = "NUM";
            this.rbnNUMs.UseVisualStyleBackColor = true;
            this.rbnNUMs.CheckedChanged += new System.EventHandler(this.rbnNUM_CheckedChanged);
            // 
            // pnlNewRxn
            // 
            this.pnlNewRxn.BackColor = System.Drawing.Color.White;
            this.pnlNewRxn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlNewRxn.Controls.Add(this.txtSeq_Insert);
            this.pnlNewRxn.Controls.Add(this.txtNUM_Insert);
            this.pnlNewRxn.Controls.Add(this.chkDupRxn);
            this.pnlNewRxn.Controls.Add(this.grpDupRxn);
            this.pnlNewRxn.Controls.Add(this.lblRXNNUM);
            this.pnlNewRxn.Controls.Add(this.label2);
            this.pnlNewRxn.Controls.Add(this.label3);
            this.pnlNewRxn.Controls.Add(this.rbnAfter);
            this.pnlNewRxn.Controls.Add(this.rbnBefore);
            this.pnlNewRxn.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlNewRxn.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlNewRxn.Location = new System.Drawing.Point(0, 0);
            this.pnlNewRxn.Name = "pnlNewRxn";
            this.pnlNewRxn.Size = new System.Drawing.Size(1170, 33);
            this.pnlNewRxn.TabIndex = 28;
            // 
            // txtSeq_Insert
            // 
            this.txtSeq_Insert.BackColor = System.Drawing.Color.White;
            this.txtSeq_Insert.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSeq_Insert.ForeColor = System.Drawing.Color.Blue;
            this.txtSeq_Insert.Location = new System.Drawing.Point(415, 3);
            this.txtSeq_Insert.Name = "txtSeq_Insert";
            this.txtSeq_Insert.ReadOnly = true;
            this.txtSeq_Insert.Size = new System.Drawing.Size(33, 25);
            this.txtSeq_Insert.TabIndex = 45;
            this.txtSeq_Insert.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtNUM_Insert
            // 
            this.txtNUM_Insert.BackColor = System.Drawing.Color.White;
            this.txtNUM_Insert.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNUM_Insert.ForeColor = System.Drawing.Color.Blue;
            this.txtNUM_Insert.Location = new System.Drawing.Point(304, 3);
            this.txtNUM_Insert.Name = "txtNUM_Insert";
            this.txtNUM_Insert.ReadOnly = true;
            this.txtNUM_Insert.Size = new System.Drawing.Size(68, 25);
            this.txtNUM_Insert.TabIndex = 44;
            this.txtNUM_Insert.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtNUM_Insert.Click += new System.EventHandler(this.txtNUM_Insert_Click);
            // 
            // chkDupRxn
            // 
            this.chkDupRxn.AutoSize = true;
            this.chkDupRxn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkDupRxn.ForeColor = System.Drawing.Color.Blue;
            this.chkDupRxn.Location = new System.Drawing.Point(462, 6);
            this.chkDupRxn.Name = "chkDupRxn";
            this.chkDupRxn.Size = new System.Drawing.Size(168, 21);
            this.chkDupRxn.TabIndex = 41;
            this.chkDupRxn.Text = "Duplicate with Reaction";
            this.chkDupRxn.UseVisualStyleBackColor = true;
            this.chkDupRxn.CheckedChanged += new System.EventHandler(this.chkDupRxn_CheckedChanged);
            // 
            // grpDupRxn
            // 
            this.grpDupRxn.Controls.Add(this.txtSeq_Dup);
            this.grpDupRxn.Controls.Add(this.txtNUM_Dup);
            this.grpDupRxn.Controls.Add(this.lblProdNo);
            this.grpDupRxn.Controls.Add(this.lblRxnSeq);
            this.grpDupRxn.Enabled = false;
            this.grpDupRxn.Location = new System.Drawing.Point(632, -10);
            this.grpDupRxn.Name = "grpDupRxn";
            this.grpDupRxn.Size = new System.Drawing.Size(219, 43);
            this.grpDupRxn.TabIndex = 43;
            this.grpDupRxn.TabStop = false;
            // 
            // txtSeq_Dup
            // 
            this.txtSeq_Dup.BackColor = System.Drawing.Color.White;
            this.txtSeq_Dup.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSeq_Dup.ForeColor = System.Drawing.Color.Blue;
            this.txtSeq_Dup.Location = new System.Drawing.Point(170, 13);
            this.txtSeq_Dup.Name = "txtSeq_Dup";
            this.txtSeq_Dup.ReadOnly = true;
            this.txtSeq_Dup.Size = new System.Drawing.Size(43, 25);
            this.txtSeq_Dup.TabIndex = 38;
            this.txtSeq_Dup.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtNUM_Dup
            // 
            this.txtNUM_Dup.BackColor = System.Drawing.Color.White;
            this.txtNUM_Dup.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNUM_Dup.ForeColor = System.Drawing.Color.Blue;
            this.txtNUM_Dup.Location = new System.Drawing.Point(65, 13);
            this.txtNUM_Dup.Name = "txtNUM_Dup";
            this.txtNUM_Dup.ReadOnly = true;
            this.txtNUM_Dup.Size = new System.Drawing.Size(67, 25);
            this.txtNUM_Dup.TabIndex = 37;
            this.txtNUM_Dup.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtNUM_Dup.Click += new System.EventHandler(this.txtNUM_Dup_Click);
            // 
            // lblProdNo
            // 
            this.lblProdNo.AutoSize = true;
            this.lblProdNo.ForeColor = System.Drawing.Color.Blue;
            this.lblProdNo.Location = new System.Drawing.Point(5, 17);
            this.lblProdNo.Name = "lblProdNo";
            this.lblProdNo.Size = new System.Drawing.Size(54, 17);
            this.lblProdNo.TabIndex = 8;
            this.lblProdNo.Text = "Product";
            // 
            // lblRxnSeq
            // 
            this.lblRxnSeq.AutoSize = true;
            this.lblRxnSeq.ForeColor = System.Drawing.Color.Blue;
            this.lblRxnSeq.Location = new System.Drawing.Point(139, 17);
            this.lblRxnSeq.Name = "lblRxnSeq";
            this.lblRxnSeq.Size = new System.Drawing.Size(30, 17);
            this.lblRxnSeq.TabIndex = 10;
            this.lblRxnSeq.Text = "Seq";
            // 
            // lblRXNNUM
            // 
            this.lblRXNNUM.AutoSize = true;
            this.lblRXNNUM.ForeColor = System.Drawing.Color.Blue;
            this.lblRXNNUM.Location = new System.Drawing.Point(247, 7);
            this.lblRXNNUM.Name = "lblRXNNUM";
            this.lblRXNNUM.Size = new System.Drawing.Size(54, 17);
            this.lblRXNNUM.TabIndex = 37;
            this.lblRXNNUM.Text = "Product";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(384, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 17);
            this.label2.TabIndex = 40;
            this.label2.Text = "Seq";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(0, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 17);
            this.label3.TabIndex = 42;
            this.label3.Text = "New Reaction";
            // 
            // rbnAfter
            // 
            this.rbnAfter.AutoSize = true;
            this.rbnAfter.Checked = true;
            this.rbnAfter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnAfter.ForeColor = System.Drawing.Color.Red;
            this.rbnAfter.Location = new System.Drawing.Point(179, 6);
            this.rbnAfter.Name = "rbnAfter";
            this.rbnAfter.Size = new System.Drawing.Size(58, 21);
            this.rbnAfter.TabIndex = 39;
            this.rbnAfter.TabStop = true;
            this.rbnAfter.Text = "After";
            this.rbnAfter.UseVisualStyleBackColor = true;
            // 
            // rbnBefore
            // 
            this.rbnBefore.AutoSize = true;
            this.rbnBefore.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnBefore.ForeColor = System.Drawing.Color.Red;
            this.rbnBefore.Location = new System.Drawing.Point(102, 6);
            this.rbnBefore.Name = "rbnBefore";
            this.rbnBefore.Size = new System.Drawing.Size(67, 21);
            this.rbnBefore.TabIndex = 38;
            this.rbnBefore.Text = "Before";
            this.rbnBefore.UseVisualStyleBackColor = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "NUM_ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "NUM";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn3.HeaderText = "RegistryNo";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn4.HeaderText = "Name";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn5.HeaderText = "Role";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.HeaderText = "MolImage";
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            this.dataGridViewImageColumn1.ReadOnly = true;
            this.dataGridViewImageColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewImageColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewImageColumn1.Visible = false;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "MolHexCode";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Visible = false;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "MolFile";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Visible = false;
            // 
            // frmNUMs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1170, 480);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlNewRxn);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmNUMs";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NUMs";
            this.Load += new System.EventHandler(this.frmNUMs_Load);
            this.pnlMain.ResumeLayout(false);
            this.splCont.Panel1.ResumeLayout(false);
            this.splCont.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splCont)).EndInit();
            this.splCont.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNUMs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbChemImg)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlSearch.ResumeLayout(false);
            this.pnlSearch.PerformLayout();
            this.pnlOptions.ResumeLayout(false);
            this.pnlOptions.PerformLayout();
            this.pnlNewRxn.ResumeLayout(false);
            this.pnlNewRxn.PerformLayout();
            this.grpDupRxn.ResumeLayout(false);
            this.grpDupRxn.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.DataGridView dgvNUMs;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.TextBox txtRegNo;
        private System.Windows.Forms.Label lblNrnReg;
        private System.Windows.Forms.TextBox txtNUM;
        private System.Windows.Forms.Label lblNrnNum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.RadioButton rbnNUMs;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.RadioButton rbnSer9000;
        private System.Windows.Forms.RadioButton rbnSer8500;
        private System.Windows.Forms.RadioButton rbnSer8000;
        private System.Windows.Forms.Panel pnlOptions;
        private System.Windows.Forms.Panel pnlNewRxn;
        private System.Windows.Forms.TextBox txtSeq_Insert;
        private System.Windows.Forms.TextBox txtNUM_Insert;
        private System.Windows.Forms.CheckBox chkDupRxn;
        private System.Windows.Forms.GroupBox grpDupRxn;
        private System.Windows.Forms.TextBox txtSeq_Dup;
        private System.Windows.Forms.TextBox txtNUM_Dup;
        private System.Windows.Forms.Label lblProdNo;
        private System.Windows.Forms.Label lblRxnSeq;
        private System.Windows.Forms.Label lblRXNNUM;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton rbnAfter;
        private System.Windows.Forms.RadioButton rbnBefore;
        private System.Windows.Forms.Panel pnlSearch;
        private System.Windows.Forms.SplitContainer splCont;
        public System.Windows.Forms.PictureBox pbChemImg;
        private MDL.Draw.Renderer.Renderer renderer1;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNUM_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNUM;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRegNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRole;
        private System.Windows.Forms.DataGridViewImageColumn colMolImage;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMolHexCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMolFile;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
    }
}