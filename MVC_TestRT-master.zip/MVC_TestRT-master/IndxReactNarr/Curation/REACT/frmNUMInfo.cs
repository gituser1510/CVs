﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using System.Xml;
using System.Text.RegularExpressions;
using IndxReactNarrBll;

namespace IndxReactNarr
{
    public partial class frmNUMInfo : Form
    {
        public frmNUMInfo()
        {
            InitializeComponent();
        }       

        private void frmNUMInfo_Load(object sender, EventArgs e)
        {

        }

        public void BindDataToStructurePanel(int nrnreg, int numval)
        {
            try
            {
                if (nrnreg > 0 && numval > 0)
                {
                    string strIUPAC = "";
                    string[] strAbsStrArr = null;
                    string[] strMFormArr = null;
                    string strSynonym = "";
                    string strMolFormula = "";
                    string[] strHexArr = GetHex_Name_MF_StrChem_Synonym_OnRegNo(nrnreg, out strIUPAC, out strMolFormula, out strAbsStrArr, out strMFormArr, out strSynonym);
                    if (strHexArr != null)
                    {
                        if (strHexArr.Length > 0)
                        {
                            ucNUMDtls.NrnNum = numval.ToString();
                            ucNUMDtls.RegNo = nrnreg.ToString();
                            ucNUMDtls.IUPACName = strIUPAC;
                            ucNUMDtls.MolFormula = strMolFormula;
                            ucNUMDtls.MolFormulaArr = strMFormArr;
                            ucNUMDtls.Synonyms = strSynonym;
                            ucNUMDtls.HexCodeArr = strHexArr;
                            ucNUMDtls.StereoChemArr = strAbsStrArr;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public void BindStructureDataToPanel(ChemStructure chemStruct)
        {
            try
            {
                if (chemStruct != null)
                {
                    ucNUMDtls.NrnNum = chemStruct.SeriesNum;
                    ucNUMDtls.RegNo = chemStruct.RegNo;
                    ucNUMDtls.IUPACName = chemStruct.MolName;
                    ucNUMDtls.MolFormula = chemStruct.MolFormula;
                    ucNUMDtls.MolFormulaArr = chemStruct.MolFormulas;
                    ucNUMDtls.Synonyms = chemStruct.MolSynonym;
                    ucNUMDtls.HexCodeArr = chemStruct.MolHexArr;
                    ucNUMDtls.StereoChemArr = chemStruct.AbsoluteStrereo;
                    ucNUMDtls.MolStructure = chemStruct.MolStructure;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string[] GetHex_Name_MF_StrChem_Synonym_OnRegNo(int _regno, out string compname, out string molformula, out string[] absstrarr, out string[] molformarr, out string synonym)
        {
            string[] strHexArr = null;
            string strName = "";
            string[] strAbsStrArr = null;
            string[] strMFArr = null;
            string strMolFormula = "";
            string strSynonym = "";

            try
            {
                if (GlobalVariables.SubstancesData != null)
                {
                    if (GlobalVariables.SubstancesData.Rows.Count > 0)
                    {
                        DataTable dtsubstance = GlobalVariables.SubstancesData.Copy();
                        DataTable dt = new DataTable();

                        string strFCond = "<SUBSTANC><RN ID=" + "\"" + _regno + "\"" + ">*";
                        try
                        {
                            DataTable dtoutput = dtsubstance.AsEnumerable().Where(a => Regex.IsMatch(a[dtsubstance.Columns[0].ColumnName].ToString(), strFCond)).CopyToDataTable();
                            if (dtoutput != null)
                            {
                                if (dtoutput.Rows.Count > 0)
                                {
                                    string cellValue = dtoutput.Rows[0][0].ToString();
                                    if (cellValue.Contains("<SIM>"))//Single structure
                                    {
                                        strHexArr = new string[1];
                                        strName = "";
                                        strAbsStrArr = new string[1];
                                        strMFArr = new string[1];
                                        strSynonym = "";

                                        string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";
                                        cellValue = GetConvertedXmlString(cellValue);
                                        cellValue = strXml + "\r\n" + cellValue;

                                        XmlDocument xDoc = new XmlDocument();
                                        xDoc.LoadXml(cellValue);

                                        XmlNodeList xNdLst_Hex = xDoc.SelectNodes("SUBSTANC/SIM");
                                        if (xNdLst_Hex.Count > 0)
                                        {
                                            strHexArr[0] = xNdLst_Hex[0].InnerText;
                                        }
                                        XmlNodeList xNdLst_Name = xDoc.SelectNodes("SUBSTANC/IN");
                                        if (xNdLst_Name.Count > 0)
                                        {
                                            strName = xNdLst_Name[0].InnerXml;
                                            strName = DeleteXMLTagsFromName(strName);
                                            strName = SetGreekLetters_IUPACName(strName);
                                        }
                                        XmlNodeList xNdLst_MF = xDoc.SelectNodes("SUBSTANC/MF");
                                        if (xNdLst_MF.Count > 0)
                                        {
                                            string strMform = xNdLst_MF[0].InnerText;
                                            strMform = strMform.Replace("<SUB>", "");
                                            strMform = strMform.Replace("</SUB>", "");
                                            strMolFormula = strMform;
                                        }
                                        XmlNodeList xNdLst_AbsStr = xDoc.SelectNodes("SUBSTANC/STEMSG");
                                        if (xNdLst_AbsStr.Count > 0)
                                        {
                                            strAbsStrArr[0] = xNdLst_AbsStr[0].InnerText;
                                        }
                                        XmlNodeList xNdLst_Synonym = xDoc.SelectNodes("SUBSTANC/SYN");
                                        if (xNdLst_Synonym.Count > 0)
                                        {
                                            for (int i = 0; i < xNdLst_Synonym.Count; i++)
                                            {
                                                if (xNdLst_Synonym[i].InnerText.ToString() != "")
                                                {
                                                    if (strSynonym.Trim() == "")
                                                    {
                                                        strSynonym = xNdLst_Synonym[i].InnerText;
                                                    }
                                                    else
                                                    {
                                                        strSynonym = strSynonym + "\r\n" + xNdLst_Synonym[i].InnerText;
                                                    }
                                                }
                                            }
                                            strSynonym = SetGreekLetters_IUPACName(strSynonym);
                                        }
                                        compname = strName;
                                        molformarr = strMFArr;
                                        absstrarr = strAbsStrArr;
                                        synonym = strSynonym;
                                        molformula = strMolFormula;
                                        return strHexArr;
                                    }
                                    else if (cellValue.Contains("<CSIM>"))//Multiple strucrures
                                    {
                                        string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";
                                        cellValue = strXml + "\r\n" + GetConvertedXmlString(cellValue);

                                        XmlDocument xDoc = new XmlDocument();
                                        xDoc.LoadXml(cellValue);

                                        XmlNodeList xNdLst_Hex = xDoc.SelectNodes("SUBSTANC/COMP/CSIM");
                                        if (xNdLst_Hex.Count > 0)
                                        {
                                            //Define arrays of equal size
                                            strHexArr = new string[xNdLst_Hex.Count];
                                            strAbsStrArr = new string[xNdLst_Hex.Count];
                                            strMFArr = new string[xNdLst_Hex.Count];
                                            strSynonym = "";

                                            //Structure Hex code Array
                                            for (int i = 0; i < xNdLst_Hex.Count; i++)
                                            {
                                                strHexArr[i] = xNdLst_Hex[i].InnerText;
                                            }
                                            //IUPAC name
                                            XmlNodeList xNdLst_Name = xDoc.SelectNodes("SUBSTANC/IN");
                                            if (xNdLst_Name.Count > 0)
                                            {
                                                strName = "";
                                                strName = xNdLst_Name[0].InnerXml;
                                                strName = DeleteXMLTagsFromName(strName);
                                                strName = SetGreekLetters_IUPACName(strName);
                                            }
                                            //Absolute Stereo
                                            XmlNodeList xNdLst_AbsStereo = xDoc.SelectNodes("SUBSTANC/COMP");//CSTEMSG
                                            if (xNdLst_AbsStereo.Count > 0)
                                            {
                                                for (int i = 0; i < strAbsStrArr.Length; i++)
                                                {
                                                    cellValue = "";
                                                    cellValue = strXml + "\r\n" + xNdLst_AbsStereo[i].OuterXml;

                                                    XmlDocument xDoc_Abs = new XmlDocument();
                                                    xDoc_Abs.LoadXml(cellValue);

                                                    XmlNodeList xNdLst_Abs = xDoc_Abs.SelectNodes("COMP/CSTEMSG");
                                                    if (xNdLst_Abs.Count > 0)
                                                    {
                                                        strAbsStrArr[i] = xNdLst_Abs[0].InnerText;
                                                    }
                                                    else
                                                    {
                                                        strAbsStrArr[i] = "";
                                                    }
                                                }
                                            }
                                            //Molecule Formula - Whole compound molecule formula
                                            XmlNodeList xNdLst_MForm = xDoc.SelectNodes("SUBSTANC/MF");
                                            if (xNdLst_MForm.Count > 0)
                                            {
                                                for (int i = 0; i < xNdLst_MForm.Count; i++)
                                                {
                                                    string strMform = xNdLst_MForm[i].InnerText;
                                                    strMform = strMform.Replace("<SUB>", "");
                                                    strMform = strMform.Replace("</SUB>", "");
                                                    strMolFormula = strMform;
                                                }
                                            }

                                            //Molecule Formula Array
                                            XmlNodeList xNdLst_MFormArr = xDoc.SelectNodes("SUBSTANC/COMP/CMF");
                                            if (xNdLst_MFormArr.Count > 0)
                                            {
                                                for (int i = 0; i < xNdLst_MFormArr.Count; i++)
                                                {
                                                    string strMformula = xNdLst_MFormArr[i].InnerText;
                                                    strMformula = strMformula.Replace("<SUB>", "");
                                                    strMformula = strMformula.Replace("</SUB>", "");
                                                    strMFArr[i] = strMformula;
                                                }
                                            }
                                            //Synonyms
                                            XmlNodeList xNdLst_Synonym = xDoc.SelectNodes("SUBSTANC/SYN");
                                            if (xNdLst_Synonym.Count > 0)
                                            {
                                                for (int i = 0; i < xNdLst_Synonym.Count; i++)
                                                {
                                                    if (xNdLst_Synonym[i].InnerText.ToString() != "")
                                                    {
                                                        if (strSynonym.Trim() == "")
                                                        {
                                                            strSynonym = xNdLst_Synonym[i].InnerText;
                                                        }
                                                        else
                                                        {
                                                            strSynonym = strSynonym + "\r\n" + xNdLst_Synonym[i].InnerText;
                                                        }
                                                    }
                                                }
                                                strSynonym = SetGreekLetters_IUPACName(strSynonym);
                                            }
                                        }

                                        compname = strName;
                                        molformarr = strMFArr;
                                        absstrarr = strAbsStrArr;
                                        synonym = strSynonym;
                                        molformula = strMolFormula;
                                        return strHexArr;
                                    }
                                    else //No Structure available
                                    {
                                        strHexArr = new string[1];
                                        strName = "";
                                        strAbsStrArr = new string[1];
                                        strMFArr = new string[1];
                                        strSynonym = "";

                                        string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";
                                        cellValue = GetConvertedXmlString(cellValue);
                                        cellValue = strXml + "\r\n" + cellValue;

                                        XmlDocument xDoc = new XmlDocument();
                                        xDoc.LoadXml(cellValue);

                                        //IUPAC name
                                        XmlNodeList xNdLst_Name = xDoc.SelectNodes("SUBSTANC/IN");
                                        if (xNdLst_Name.Count > 0)
                                        {
                                            strName = "";
                                            strName = xNdLst_Name[0].InnerXml;
                                            strName = DeleteXMLTagsFromName(strName);
                                            strName = SetGreekLetters_IUPACName(strName);
                                        }
                                        //Molecule Formula
                                        XmlNodeList xNdLst_MF = xDoc.SelectNodes("SUBSTANC/MF");
                                        if (xNdLst_MF.Count > 0)
                                        {
                                            string strMformula = xNdLst_MF[0].InnerText;
                                            strMformula = strMformula.Replace("<SUB>", "");
                                            strMformula = strMformula.Replace("</SUB>", "");
                                            strMFArr[0] = strMformula;
                                        }

                                        //Synonyms
                                        XmlNodeList xNdLst_Synonym = xDoc.SelectNodes("SUBSTANC/SYN");
                                        if (xNdLst_Synonym.Count > 0)
                                        {
                                            for (int i = 0; i < xNdLst_Synonym.Count; i++)
                                            {
                                                if (xNdLst_Synonym[i].InnerText.ToString() != "")
                                                {
                                                    if (strSynonym.Trim() == "")
                                                    {
                                                        strSynonym = xNdLst_Synonym[i].InnerText;
                                                    }
                                                    else
                                                    {
                                                        strSynonym = strSynonym + "\r\n" + xNdLst_Synonym[i].InnerText;
                                                    }
                                                }
                                            }
                                            strSynonym = SetGreekLetters_IUPACName(strSynonym);
                                        }

                                        compname = strName;
                                        molformarr = strMFArr;
                                        absstrarr = strAbsStrArr;
                                        synonym = strSynonym;
                                        molformula = strMolFormula;
                                        return strHexArr;
                                    }
                                }
                            }
                        }
                        catch
                        {

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            compname = strName;
            molformarr = strMFArr;
            absstrarr = strAbsStrArr;
            synonym = strSynonym;
            molformula = strMolFormula;
            return strHexArr;
        }
               
        private string GetConvertedXmlString(string _xmltag)
        {
            string strConvXml = _xmltag;
            try
            {
                if (GlobalVariables.XMLConvTbl != null)
                {
                    if (GlobalVariables.XMLConvTbl.Rows.Count > 0)
                    {
                        for (int i = 0; i < GlobalVariables.XMLConvTbl.Rows.Count; i++)
                        {
                            strConvXml = strConvXml.Replace(GlobalVariables.XMLConvTbl.Rows[i]["xmlstring"].ToString(), GlobalVariables.XMLConvTbl.Rows[i]["xmlstring_replacement"].ToString());
                        }
                    }
                }
                return strConvXml;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strConvXml;
        }

        private string SetGreekLetters_IUPACName(string _iupacname)
        {
            string strIUPAC = _iupacname;
            try
            {
                if (GlobalVariables.XMLConvTbl != null)
                {
                    if (GlobalVariables.XMLConvTbl.Rows.Count > 0)
                    {
                        for (int i = 0; i < GlobalVariables.XMLConvTbl.Rows.Count; i++)
                        {
                            if (strIUPAC.Trim().Contains(GlobalVariables.XMLConvTbl.Rows[i]["xmlstring"].ToString()))
                            {
                                strIUPAC = strIUPAC.Replace(GlobalVariables.XMLConvTbl.Rows[i]["xmlstring"].ToString(), GlobalVariables.XMLConvTbl.Rows[i]["greek_letter"].ToString());
                            }
                            if (strIUPAC.Trim().Contains(GlobalVariables.XMLConvTbl.Rows[i]["xmlstring_replacement"].ToString()))
                            {
                                strIUPAC = strIUPAC.Replace(GlobalVariables.XMLConvTbl.Rows[i]["xmlstring_replacement"].ToString(), GlobalVariables.XMLConvTbl.Rows[i]["greek_letter"].ToString());
                            }
                        }
                    }
                }
                return strIUPAC;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strIUPAC;
        }

        private string DeleteXMLTagsFromName(string _iupacname)
        {
            string strIUPAC = _iupacname;
            try
            {
                strIUPAC = strIUPAC.Replace("<IT>", "");
                strIUPAC = strIUPAC.Replace("</IT>", "");
                //strIUPAC = strIUPAC.Replace("<SUP>", "");
                //strIUPAC = strIUPAC.Replace("</SUP>", "");
                strIUPAC = strIUPAC.Replace("<SCP>", "");
                strIUPAC = strIUPAC.Replace("</SCP>", "");
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strIUPAC;
        }
    }
}
