﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;

namespace IndxReactNarr
{
    public partial class frmSeries8000 : Form
    {
        public frmSeries8000()
        {
            InitializeComponent();
        }
        
        #region Property Procedures

        public DataTable DtSer8000
        {
            get;
            set;
        }

        public string TANID
        {
            get;
            set;
        }

        public int Sel_8000 { get; set; }

        public string SubstName { get; set; }

        public string SubstLoc { get; set; }

        public string AuthorName { get; set; }

        public string OtherName { get; set; }

        public object SubstMol { get; set; }

        public Image SubstImage { get; set; }        

        #endregion

        private void frmSeries8000_Load(object sender, EventArgs e)
        {
            try
            {
                GetSeries8000DataAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetSeries8000DataAndBindToGrid()
        {
            try
            {
                if (IndxReactNarr.Generic.GlobalVariables.TAN_Series8000Data != null)              
                {                   
                    if (!string.IsNullOrEmpty(TANID.Trim()))
                    {
                        //DataView dtView = GlobalVariables.TAN_Series8000Data.DefaultView;
                        //dtView.RowFilter = "TAN = '" + TANID.Trim() + "'";
                        //dtView.Sort = "ser8000 asc";
                        //DataTable dtTemp = dtView.ToTable();
                                             
                        DataTable dtTemp = GlobalVariables.TAN_Series8000Data;

                        DataTable dtGridData = dtTemp.Clone();
                        dtGridData.Columns["SERIES_8000"].DataType = System.Type.GetType("System.String");                        

                        foreach (DataRow dr in dtTemp.Rows)
                        {
                            dtGridData.ImportRow(dr);
                        }

                        //Insert 0 at starting
                        DataRow dRow = dtGridData.NewRow();
                        dRow["SERIES_8000"] = 0;
                        dtGridData.Rows.InsertAt(dRow, 0);

                        if (dtGridData != null)
                        {
                            dtGridData.Columns.Add("SUBSTMOLIMAGE", typeof(Image));
                            for (int i = 0; i < dtGridData.Rows.Count; i++)
                            {
                                if (dtGridData.Rows[i]["SUBST_MOLECULE"].ToString() != "")
                                {
                                    renditor1.MolfileString = dtGridData.Rows[i]["SUBST_MOLECULE"].ToString();
                                    dtGridData.Rows[i]["SUBSTMOLIMAGE"] = (object)renditor1.Image;
                                }
                            }
                            dtGridData.AcceptChanges();
                        }

                        DtSer8000 = dtGridData;

                        //Bind data to grid
                        BindDataToSer8000Grid(dtGridData);                                              
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindDataToSer8000Grid(DataTable ser8000data)
        {
            try
            {
                if (ser8000data != null)
                {
                    dgvSer8000.AutoGenerateColumns = false;
                    dgvSer8000.DataSource = ser8000data;
                    
                    colSer8000.DataPropertyName = "SERIES_8000";
                    colSubstName.DataPropertyName = "SUBST_NAME";
                    colAuthorName.DataPropertyName = "SUBST_AUTHOR_NAME";
                    colOtherName.DataPropertyName = "SUBST_OTHER_NAME";
                    colSubstLoc.DataPropertyName = "SUBST_LOC";
                    dgvSer8000.Columns["SubstMolecule"].DataPropertyName = "SUBST_MOLECULE";
                    dgvSer8000.Columns["Structure"].DataPropertyName = "SUBSTMOLIMAGE";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvSer8000_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvSer8000.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvSer8000.Font);

                if (dgvSer8000.RowHeadersWidth < (int)(size.Width + 20)) dgvSer8000.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvSer8000_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex >= 0 && e.RowIndex >= 0)
                {
                    if (dgvSer8000.Rows[e.RowIndex].Cells["colSer8000"].Value.ToString() != "")
                    {
                        Sel_8000 = Convert.ToInt32(dgvSer8000.Rows[e.RowIndex].Cells["colSer8000"].Value.ToString());
                    }

                    if (dgvSer8000.Rows[e.RowIndex].Cells["colSubstName"].Value.ToString() != "")
                    {
                        SubstName = dgvSer8000.Rows[e.RowIndex].Cells["colSubstName"].Value.ToString();
                    }

                    if (dgvSer8000.Rows[e.RowIndex].Cells["colSubstLoc"].Value.ToString() != "")
                    {
                        SubstLoc = dgvSer8000.Rows[e.RowIndex].Cells["colSubstLoc"].Value.ToString();
                    }

                    if (dgvSer8000.Rows[e.RowIndex].Cells["colAuthorName"].Value.ToString() != "")
                    {
                        AuthorName = dgvSer8000.Rows[e.RowIndex].Cells["colAuthorName"].Value.ToString();
                    }

                    if (dgvSer8000.Rows[e.RowIndex].Cells["colOtherName"].Value.ToString() != "")
                    {
                        OtherName = dgvSer8000.Rows[e.RowIndex].Cells["colOtherName"].Value.ToString();
                    }
                                        
                    SubstMol = dgvSer8000.Rows[e.RowIndex].Cells["colSubstMolecule"].Value != null ? dgvSer8000.Rows[e.RowIndex].Cells["colSubstMolecule"].Value : "";
                    SubstImage =dgvSer8000.Rows[e.RowIndex].Cells["colStructure"].Value != null ? (Image)dgvSer8000.Rows[e.RowIndex].Cells["colStructure"].Value : null;
                   
                    DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtSer8000_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilteredDataBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        

        private string GetFilterCondition()
        {
            string strFilerCond = "";
            try
            {              
                if (txtSer8000.Text.Trim() != "")
                {
                    strFilerCond = "ser8000 like '" + txtSer8000.Text.Trim() + "%'";
                }
                if (txtSubstName.Text.Trim() != "")
                {
                    if (strFilerCond.Trim() == "")
                    {
                        strFilerCond = "SUBST_NAME like '" + txtSubstName.Text.Trim() + "%'";
                    }
                    else
                    {
                        strFilerCond = strFilerCond + " and SUBST_NAME like '" + txtSubstName.Text.Trim() + "%'";
                    }
                }
                if (txtAuthorName.Text.Trim() != "")
                {
                    if (strFilerCond.Trim() == "")
                    {
                        strFilerCond = "SUBST_AUTHOR_NAME like '" + txtAuthorName.Text.Trim() + "%'";
                    }
                    else
                    {
                        strFilerCond = strFilerCond + " and SUBST_AUTHOR_NAME like '" + txtAuthorName.Text.Trim() + "%'";
                    }
                }
                if (txtOtherName.Text.Trim() != "")
                {
                    if (strFilerCond.Trim() == "")
                    {
                        strFilerCond = "SUBST_OTHER_NAME like '" + txtOtherName.Text.Trim() + "%'";
                    }
                    else
                    {
                        strFilerCond = strFilerCond + " and SUBST_OTHER_NAME like '" + txtOtherName.Text.Trim() + "%'";
                    }
                }
                if (txtSubstLoc.Text.Trim() != "")
                {
                    if (strFilerCond.Trim() == "")
                    {
                        strFilerCond = "SUBST_LOC like '" + txtSubstLoc.Text.Trim() + "%'";
                    }
                    else
                    {
                        strFilerCond = strFilerCond + " and SUBST_LOC like '" + txtSubstLoc.Text.Trim() + "%'";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strFilerCond;
        }

        private void GetFilteredDataBindToGrid()
        {
            try
            {
                string strFiltCond = GetFilterCondition();
                if (strFiltCond.Trim() != "")
                {
                    DataView dtView = new DataView(DtSer8000);
                    dtView.RowFilter = strFiltCond;
                    DataTable dtGridData = dtView.ToTable();

                    //Bind data to grid
                    BindDataToSer8000Grid(dtGridData);
                }
                else
                {
                    //Bind data to grid
                    BindDataToSer8000Grid(DtSer8000);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
