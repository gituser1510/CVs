﻿using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Collections;
using IndxReactNarrDAL;
using IndxReactNarr.Generic;
using chemaxon.util;
using chemaxon.struc;
using java.io;
using chemaxon.formats;
using System.Text.RegularExpressions;
using IndxReactNarrBll;

namespace IndxReactNarr
{
    public partial class frmManage8000 : Form
    {
        #region Constructor

        public frmManage8000()
        {
            InitializeComponent();
        }

        #endregion

        #region Property Procedures

        public DataTable Ser8000Data
        { get; set; }

        public DataTable NUM_RegNoTbl
        { get; set; }

        public string TAN_Name
        {
            get;
            set;
        }

        public int TAN_ID
        {
            get;
            set;
        }

        public frmReactCuration RxnMain
        {
            get;
            set;
        }

        #endregion

        DataTable dtGridData = null;

        private void frmManage8000_Load(object sender, EventArgs e)
        {
            try
            {       
                //Bind data to 8000 grid
                BindSeries8000DataToGrid();

                //Check 8000 series data and enable 7000 series if exceeds - New code on 14th May 2013
               AddSeries7000CollectionAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void AddSeries7000CollectionAndBindToGrid()
        {
            try
            {
                ////Add 7000 Series to Collection
                //if (GlobalVariables.Series7000Coll == null)
                //{
                //    IndxReactNarr.CAS_Classes.CAS_AutoFillCollection.Add7000SeriesToCollection();
                //}
                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
           
        private void BindSeries8000DataToGrid()
        {
            try
            {
                //Ser8000Tbl = CASRxnDataAccess.GetSeries8000CombDetailsOnTAN("62527259B");
                if (Ser8000Data != null)
                {
                    //if (TAN_Name != "")
                    //{
                        //DataView dtView = Ser8000Data.DefaultView;
                        //dtView.RowFilter = "tan = '" + TAN_Name + "'";
                        //dtView.Sort = "ser8000 asc";
                        //dtGridData = dtView.ToTable();

                        dtGridData = Ser8000Data.Copy();

                        if (dtGridData != null)
                        {

                            dtGridData.Columns.Add("SUBSTMOLIMAGE", typeof(Image));
                            for (int i = 0; i < dtGridData.Rows.Count; i++)
                            {
                                if (dtGridData.Rows[i]["SUBST_MOLECULE"].ToString() != "")
                                {
                                    renditor1.MolfileString = "";
                                    renditor1.MolfileString = dtGridData.Rows[i]["SUBST_MOLECULE"].ToString();
                                    dtGridData.Rows[i]["SUBSTMOLIMAGE"] = (object)renditor1.Image;
                                }
                            }
                            dtGridData.AcceptChanges();
                        }
                    //}

                    dg8000Series.AutoGenerateColumns = false;
                    dg8000Series.DataSource = dtGridData;

                    colTS_ID.DataPropertyName = "TS_ID";
                    dg8000Series.Columns["Series8000"].DataPropertyName = "SERIES_8000";
                    dg8000Series.Columns["SubstName"].DataPropertyName = "SUBST_NAME";
                    dg8000Series.Columns["SubstLoc"].DataPropertyName = "SUBST_LOC";                    
                    dg8000Series.Columns["colAuthorName"].DataPropertyName = "SUBST_AUTHOR_NAME";
                    dg8000Series.Columns["colOtherName"].DataPropertyName = "SUBST_OTHER_NAME";
                    dg8000Series.Columns["SubstStruct"].DataPropertyName = "SUBSTMOLIMAGE";

                    UpdateSeries8000InTextBox(dtGridData);
                }
                else
                {
                    txtSeries8000.Text = "8001";
                    lblSer8000.Text = "Series 8000";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void UpdateSeries8000InTextBox(DataTable ser8000Data)
        {
            try
            {
                if (ser8000Data.Rows.Count > 0)
                {
                    if (ser8000Data.Rows.Count <= 499)
                    {
                        int intSer8000 = 0;
                        int.TryParse(ser8000Data.Rows[ser8000Data.Rows.Count - 1]["SERIES_8000"].ToString(), out intSer8000);
                        if (intSer8000 > 8000)
                        {
                            txtSeries8000.Text = (intSer8000 + 1).ToString();
                            lblSer8000.Text = "Series 8000";
                        }
                    }
                    else
                    {
                        int ser_8000 = Convert.ToInt32(ser8000Data.Rows[ser8000Data.Rows.Count - 1]["SERIES_8000"]);
                        if (ser_8000 > 7000 && ser_8000 < 7999)
                        {
                            int intSer7000 = 0;
                            int.TryParse(ser8000Data.Rows[ser8000Data.Rows.Count - 1]["SERIES_8000"].ToString(), out intSer7000);

                            txtSeries8000.Text = (intSer7000 + 1).ToString();
                            lblSer8000.Text = "Series 7000";
                        }
                    }
                }
                else
                {
                    txtSeries8000.Text = "8001";
                    lblSer8000.Text = "Series 8000";
                }
            }
            catch (Exception ex)
            {                
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }


        int intTS_ID = -1;
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string strErrMsg = "";
                if (ValidateUserInputs(out strErrMsg))
                {
                    int int8000 = 0;
                    if (!string.IsNullOrEmpty(txtSeries8000.Text))
                    {
                        int.TryParse(txtSeries8000.Text, out int8000);
                    }

                    if (int8000 > 0)
                    {
                        //Remove Extra spaces
                        txtSubstName.Text = Regex.Replace(txtSubstName.Text.Trim(), @"\s+", " ", RegexOptions.Multiline).Replace("", "");//Zero width space
                        txtAuthorName.Text = Regex.Replace(txtAuthorName.Text.Trim(), @"\s+", " ", RegexOptions.Multiline).Replace("", "");//Zero width space
                        txtOtherName.Text = Regex.Replace(txtOtherName.Text.Trim(), @"\s+", " ", RegexOptions.Multiline).Replace("", "");//Zero width space

                        ManageSeries8000 objSer8000 = new ManageSeries8000();
                        objSer8000.TS_ID = intTS_ID;
                        objSer8000.TAN_ID = TAN_ID;
                        objSer8000.Ser8000Val = int8000;
                        objSer8000.SubstName = txtSubstName.Text.Trim();
                        objSer8000.SubstLocation = txtSubstLoc.Text.Trim();
                        objSer8000.SubstMolecule = ChemRenditor.MolfileString;
                        objSer8000.SubstAuthorName = txtAuthorName.Text.Trim();
                        objSer8000.SubstOtherName = txtOtherName.Text.Trim();
                        objSer8000.Option = intTS_ID == -1 ? "INSERT" : "UPDATE";

                        if (ReactDB.UpdateSeries8000DetailsOnTAN(objSer8000))
                        {
                            GlobalVariables.TAN_Series8000Data = ReactDB.GetSeries8000DetailsOnTAN(TAN_ID);
                            Ser8000Data = GlobalVariables.TAN_Series8000Data;
                            
                            BindSeries8000DataToGrid();

                            //Clear user inputs
                            ClearUserInputs();

                            UpdateSeries8000InTextBox(dtGridData);

                            if (intTS_ID > 0)
                            {
                                MessageBox.Show("Changes done successfully.To reflect the changes close and re-open the TAN", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else
                            {
                                MessageBox.Show("8000 series data saved successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            //Reset TS_ID
                            intTS_ID = -1;
                        }
                    }
                }
                else
                {
                    MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void ClearUserInputs()
        {
            try
            {
                txtSubstName.Text = "";
                txtSubstLoc.Text = "";
                txtAuthorName.Text = "";
                txtOtherName.Text = "";

                txtPage.Text = "";
                txtLine.Text = "";
                txtPara.Text = "";
                txtColumn.Text = "";
                txtTable.Text = "";
                txtFigure.Text = "";
                txtSheet.Text = "";
                txtFootNote.Text = "";
                txtOther.Text = "";

                txtMolFormula.Text = "";

                ChemRenditor.MolfileString = "";
                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void UpdateRowInSer8000Table(string _tan, int _ser8000val, string _substname,string _substloc,string _substmol, Image _substmolimg, string _authorname, string _othername)
        {
            try
            {
                if (Ser8000Data != null)
                {
                    if (Ser8000Data.Rows.Count > 0)
                    {
                        for (int i = 0; i < Ser8000Data.Rows.Count; i++)
                        {
                            if (Ser8000Data.Rows[i]["tan"].ToString() == _tan
                                && Ser8000Data.Rows[i]["ser8000"].ToString() == _ser8000val.ToString())
                            {
                                Ser8000Data.Rows[i]["subst_name"] = _substname;
                                Ser8000Data.Rows[i]["subst_loc"] = _substloc;
                                Ser8000Data.Rows[i]["substmol"] = _substmol;
                                Ser8000Data.Rows[i]["author_name"] = _authorname;
                                Ser8000Data.Rows[i]["other_name"] = _othername;
                                break;
                            }
                        }
                        Ser8000Data.AcceptChanges();
                    }
                }

                if (dtGridData != null)
                {
                    if (dtGridData.Rows.Count > 0)
                    {
                        for (int i = 0; i < dtGridData.Rows.Count; i++)
                        {
                            if (dtGridData.Rows[i]["ser8000"].ToString() == _ser8000val.ToString())
                            {
                                dtGridData.Rows[i]["subst_name"] = _substname;
                                dtGridData.Rows[i]["subst_loc"] = _substloc;
                                dtGridData.Rows[i]["substmol"] = _substmol;
                                dtGridData.Rows[i]["substmolimage"] = _substmolimg;
                                dtGridData.Rows[i]["author_name"] = _authorname;
                                dtGridData.Rows[i]["other_name"] = _othername;
                                break;
                            }
                        }
                        dtGridData.AcceptChanges();
                    }
                }

                //Update Series 8000 value in the current reaction
                UpdateSer8000InCurrentReaction(_ser8000val.ToString(), _substname, _substloc, _authorname, _othername, _substmol, _substmolimg);
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void UpdateSer8000InCurrentReaction(string ser8000val, string substname, string substloc, string authorname, string othername, string substmol, Image substmol_img)
        {
            try
            {
                if (ser8000val.Trim() != "")
                {
                    frmReactCuration objRxnMain = RxnMain;
                    if (objRxnMain != null)
                    {
                        //Update Product Table
                        DataTable dtProd = objRxnMain.RxnProductsTbl;                
                        UpdateSer8000ValuesInTable(dtProd,ser8000val,substname,substloc,authorname,othername,substmol,substmol_img);
                        
                        ucParticipants ucPartpnt = null;
                        for (int j = 0; j < objRxnMain.tcStages.TabCount; j++)
                        {
                            ucPartpnt = (ucParticipants)objRxnMain.tcStages.TabPages[j].Controls[0];
                            if (ucPartpnt != null)
                            {
                                //Update Reactant Table
                                DataTable dtReact = ucPartpnt.dtReactant;
                                UpdateSer8000ValuesInTable(dtReact, ser8000val, substname, substloc, authorname, othername, substmol, substmol_img);

                                //Update Agent Table
                                DataTable dtAgent = ucPartpnt.dtAgent;
                                UpdateSer8000ValuesInTable(dtAgent, ser8000val, substname, substloc, authorname, othername, substmol, substmol_img);

                                //Update Solvent Table
                                DataTable dtSolv = ucPartpnt.dtSolvent;
                                UpdateSer8000ValuesInTable(dtSolv, ser8000val, substname, substloc, authorname, othername, substmol, substmol_img);

                                //Update Catalyst Table
                                DataTable dtCatl = ucPartpnt.dtCatalyst;
                                UpdateSer8000ValuesInTable(dtCatl, ser8000val, substname, substloc, authorname, othername, substmol, substmol_img);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void UpdateSer8000ValuesInTable(DataTable partpnttbl, string ser8000val, string substname, string substloc, string authorname, string othername, string substmol, Image substmol_img)
        {
            try
            {
                if (partpnttbl != null)
                {
                    for (int i = 0; i < partpnttbl.Rows.Count; i++)
                    {
                        if (partpnttbl.Rows[i]["p_8000"].ToString() == ser8000val)
                        {
                            partpnttbl.Rows[i]["subst_name"] = substname;
                            partpnttbl.Rows[i]["subst_loc"] = substloc;
                            partpnttbl.Rows[i]["subst_author_name"] = authorname;
                            partpnttbl.Rows[i]["subst_other_name"] = othername;
                            partpnttbl.Rows[i]["subst_molecule"] = substmol;
                            partpnttbl.Rows[i]["subst_mol_image"] = substmol_img;

                            partpnttbl.AcceptChanges();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private bool ValidateUserInputs(out string _errmsg)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {              

                //Substance Name validation
                if (string.IsNullOrEmpty(txtSubstName.Text.Trim()) && string.IsNullOrEmpty(txtAuthorName.Text.Trim()))
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Please enter Substance Name / Compound No.";//Author Name";
                }
                else if (CheckForRestrictedName(txtSubstName.Text.Trim()))
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + txtSubstName.Text.Trim() + " not allowed. Please enter appropriate RSN term";                    
                }
                else if (txtSubstName.Text.Trim().Contains(";"))
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "';' is not allowed in the Substance Name / Mol Formula";                    
                }
                else if (txtSubstName.Text.Trim().Contains("\r\n"))
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "New line character is not allowed in the Substance Name / Mol Formula";   
                }

                //Author Name(Compound No) validation
                if (txtAuthorName.Text.Trim() != "" && txtAuthorName.Text.Trim().Contains(";"))
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "';' is not allowed in the Compound No.";//Author Name";                    
                }

                //Other Name (Generic Name) validation
                if (txtOtherName.Text.Trim() != "" && txtOtherName.Text.Trim().Contains(";"))
                {
                    blStatus = false;                    
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "';' is not allowed in the Generic Name";//Other Name";                    
                }

                //Substance Location validation
                if (string.IsNullOrEmpty(txtSubstLoc.Text.Trim()))
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Substance Location is mandatory";                                       
                }

                //Structure Validation
                if (ChemRenditor.MolfileString == null || string.IsNullOrEmpty(ChemRenditor.MolfileString))
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Substance structure is mandatory";                                       
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg;
            return blStatus;
        }

        private bool CheckForRestrictedName(string _substname)
        {
            bool blStatus = false;
            try
            {
                ArrayList alstNames = new ArrayList();
                alstNames.Add("polyphosphoric acid");
                alstNames.Add("silica gel");
                alstNames.Add("lindlar catalyst");
                alstNames.Add("jones reagent");
                alstNames.Add("molecular sieves");
                alstNames.Add("petroleum ether");
                alstNames.Add("light petroleum");
                alstNames.Add("davis reagent");
                alstNames.Add("ligroin");
                alstNames.Add("ligroine");
                //alstNames.Add("all zeolites");
                //alstNames.Add("aliquat 336");

                if(alstNames.Contains(_substname.ToLower()))
                {
                    blStatus = true;
                }
                else if (_substname.ToLower().Contains("zeolite"))
                {
                    blStatus = true;
                }
                else if (_substname.ToLower().Contains("aliquat"))
                {
                    blStatus = true;
                }
                return blStatus;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }
              
        private void dg8000Series_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dg8000Series.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString().ToUpper() == "DELETE")
                {
                    DialogResult diaRes = MessageBox.Show("Do you want to delete?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (diaRes == DialogResult.Yes)
                    {
                        int int8000Val = Convert.ToInt32(dg8000Series.Rows[e.RowIndex].Cells["Series8000"].Value.ToString());
                        int intTSID = Convert.ToInt32(dg8000Series.Rows[e.RowIndex].Cells["colTS_ID"].Value.ToString()); 

                        DataTable dt8000_Saved = ReactDB.GetSavedSeriesDataOnTANAndSeriesValue(TAN_ID, intTSID, int8000Val, 8000);
                        if (dt8000_Saved != null)
                        {
                            if (dt8000_Saved.Rows.Count > 0)
                            {
                                frm8500ValsExist obj8500Vals = new frm8500ValsExist();
                                DataView dvTemp = dt8000_Saved.Copy().DefaultView;
                                dvTemp.RowFilter = "PP_TYPE = 'PRODUCT'";
                                DataTable dtProduct = dvTemp.ToTable();
                                obj8500Vals.ProdSavedSeries = dtProduct;

                                //DataView dvTemp = dt8000_Saved.Copy().DefaultView;
                                dvTemp.RowFilter = "PP_TYPE <> 'PRODUCT'";
                                DataTable dtParticipant = dvTemp.ToTable();
                                obj8500Vals.PartpntSavedSeries = dtParticipant;

                                obj8500Vals.ShowDialog();
                            }
                            else
                            {
                                ManageSeries8000 objSer8000 = new ManageSeries8000();
                                objSer8000.TS_ID = intTSID;//Convert.ToInt32(dtGridData.Rows[e.RowIndex]["TS_ID"].ToString());                                
                                objSer8000.Option = "DELETE";

                                //Delete series 8000 value from database

                                if (ReactDB.UpdateSeries8000DetailsOnTAN(objSer8000))
                                //if (CASRxnDataAccess.DeleteSeries8000DetailsOnTAN(TAN_ID, int8000Val))
                                {
                                    //Delete8000ValFromTable(int8000Val.ToString(), TAN_Name);

                                    GlobalVariables.TAN_Series8000Data = ReactDB.GetSeries8000DetailsOnTAN(TAN_ID);
                                    Ser8000Data = GlobalVariables.TAN_Series8000Data;

                                    dg8000Series.DataSource = null;
                                    BindSeries8000DataToGrid();

                                    //Reset User inputs
                                    ClearUserInputs();
                                }
                            }
                        }   
                    }
                }
                else if (dg8000Series.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString().ToUpper() == "EDIT")
                {
                   DialogResult diaRes = MessageBox.Show("Do you want to edit?", "Edit 8000", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                   if (diaRes == DialogResult.Yes)
                   {
                       Cursor = Cursors.WaitCursor;

                       if (dg8000Series.Rows[e.RowIndex].Cells["colTS_ID"].Value != null)
                       {
                           intTS_ID = Convert.ToInt32(dg8000Series.Rows[e.RowIndex].Cells["colTS_ID"].Value.ToString());
                       }

                       int intSer_8000 = Convert.ToInt32(dg8000Series.Rows[e.RowIndex].Cells["series8000"].Value.ToString());
                       txtSeries8000.Text = intSer_8000.ToString();

                       strInchi_BeforeChange = "";
                      
                       txtSubstName.Text = dtGridData.Rows[e.RowIndex]["SUBST_NAME"].ToString();
                       txtSubstLoc.Text = dtGridData.Rows[e.RowIndex]["SUBST_LOC"].ToString();
                       _strSubstLoc = txtSubstLoc.Text;
                       ChemRenditor.MolfileString = dtGridData.Rows[e.RowIndex]["SUBST_MOLECULE"].ToString();
                       txtAuthorName.Text = dtGridData.Rows[e.RowIndex]["SUBST_AUTHOR_NAME"].ToString();
                       txtOtherName.Text = dtGridData.Rows[e.RowIndex]["SUBST_OTHER_NAME"].ToString();

                       Cursor = Cursors.Default;
                   }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void Delete8000ValFromTable(string _ser8000val, string _tan)
        {
            try
            {
                if (Ser8000Data != null)
                {
                    if (Ser8000Data.Rows.Count > 0)
                    {
                        for (int i = 0; i < Ser8000Data.Rows.Count; i++)
                        {
                            if (Ser8000Data.Rows[i]["ser8000"].ToString() == _ser8000val && Ser8000Data.Rows[i]["tan"].ToString() == _tan)
                            {
                                Ser8000Data.Rows[i].Delete();
                                Ser8000Data.AcceptChanges();
                                return;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dg8000Series_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dg8000Series.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dg8000Series.Font);

                if (dg8000Series.RowHeadersWidth < (int)(size.Width + 20)) dg8000Series.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        string _strSubstLoc = "";
        private void btnSubstLoc_Click(object sender, EventArgs e)
        {
            try
            {
                string strErrMsg = "";
                if (ValidateSubstLocation(out strErrMsg))
                {
                    txtOther.Text = txtOther.Text.Trim().Replace("\r\n", " ");
                    txtOther.Text = Regex.Replace(txtOther.Text.Trim(), @"\s+", " ", RegexOptions.Multiline);
                    
                    if (_strSubstLoc.Trim() != "")
                    {
                        _strSubstLoc = _strSubstLoc + "  ";
                    }
                    if (_strSubstLoc.Contains("  "))
                    {
                        _strSubstLoc = _strSubstLoc.Replace("  ", ",");
                    }

                    FormSubstLocString(txtPage.Text.Trim(), "PAGE");
                    FormSubstLocString(txtLine.Text.Trim(), "LINE");
                    FormSubstLocString(txtPara.Text.Trim(), "PARAGRAPH");
                    FormSubstLocString(txtColumn.Text.Trim(), "COLUMN");
                    FormSubstLocString(txtTable.Text.Trim(), "TABLE");
                    FormSubstLocString(txtFigure.Text.Trim(), "FIGURE");
                    FormSubstLocString(txtScheme.Text.Trim(), "SCHEME");
                    FormSubstLocString(txtSheet.Text.Trim(), "SHEET");
                    FormSubstLocString(txtFootNote.Text.Trim(), "FOOTNOTE");
                    FormSubstLocString(txtOther.Text, "OTHER");

                    if (_strSubstLoc.Trim().Contains(" and "))
                    {
                        _strSubstLoc = _strSubstLoc.Replace(" and ", ", ");
                    }
                    if (_strSubstLoc.Trim().Contains(", "))
                    {
                        int intCommaIndx = _strSubstLoc.LastIndexOf(", ");
                        _strSubstLoc = _strSubstLoc.Remove(intCommaIndx, 1);
                        _strSubstLoc = _strSubstLoc.Insert(intCommaIndx, " and");
                    }

                    txtSubstLoc.Text = _strSubstLoc;

                    //Clear Page/Line/Column... values
                    ClearPageValues();
                }
                else
                {
                    MessageBox.Show(strErrMsg, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private bool ValidateSubstLocation(out string errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (txtPage.Text.Trim() == "" && txtLine.Text.Trim() == "" && txtPara.Text.Trim() == "" &&
                   txtColumn.Text.Trim() == "" && txtTable.Text.Trim() == "" && txtFigure.Text.Trim() == "" &&
                   txtScheme.Text.Trim() == "" && txtSheet.Text.Trim() == "" && txtFootNote.Text.Trim() == "" &&
                    txtOther.Text.Trim() == "")
                {
                    blStatus = false;
                    strErrMsg = "Please enter Substance location";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg;
            return blStatus;
        }

        private void ClearPageValues()
        {
            try
            {
                txtPage.Text = "";
                txtLine.Text = "";
                txtPara.Text = "";
                txtColumn.Text = "";
                txtTable.Text = "";
                txtFigure.Text = "";
                txtScheme.Text = "";
                txtSheet.Text = "";
                txtFootNote.Text = "";
                txtOther.Text = "";
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void FormSubstLocString(string srctext,string srccntrl)
        {
            try
            {
                string strSource = "";

                switch (srccntrl.ToUpper())
                {
                    case "PAGE":
                        strSource = " on p. ";
                        break;
                    case "LINE":
                        strSource = " ln ";
                        break;
                    case "PARAGRAPH":
                        strSource = " paragraph ";
                        break;
                    case "COLUMN":
                        strSource = " column ";
                        break;
                    case "TABLE":
                        strSource = " table ";
                        break;
                    case "FIGURE":
                        strSource = " figure ";
                        break;
                    case "SCHEME":
                        strSource =  " scheme ";
                        break;
                    case "SHEET":
                        strSource =  " sheet ";
                        break;
                    case "FOOTNOTE":
                        strSource = " footnote ";
                        break;
                    case "OTHER":
                        strSource = " ";
                        break;
                }
                _strSubstLoc = !string.IsNullOrEmpty(srctext.Trim()) ? _strSubstLoc.Trim() + strSource + srctext.Trim() : _strSubstLoc;

                #region MyRegion
                //if (_srccntrl.ToUpper() == "PAGE")
                //{
                //    if (_srctext.Trim() != "")
                //    {
                //        if (_strSubstLoc.Trim() == "")
                //        {
                //            _strSubstLoc = "on p. " + _srctext.Trim();
                //        }
                //        else
                //        {                            
                //            _strSubstLoc = _strSubstLoc + " on p. " + _srctext.Trim();
                //        }
                //    }                    
                //}
                //else if (_srccntrl.ToUpper() == "LINE")
                //{
                //    if (_srctext.Trim() != "")
                //    {
                //        if (_strSubstLoc.Trim() == "")
                //        {
                //            _strSubstLoc = "ln " + _srctext.Trim();
                //        }
                //        else
                //        {
                //            _strSubstLoc = _strSubstLoc + " ln " + _srctext.Trim(); 
                //        }
                //    }
                //}
                //else if (_srccntrl.ToUpper() == "PARAGRAPH")
                //{
                //    if (_srctext.Trim() != "")
                //    {
                //        if (_strSubstLoc.Trim() == "")
                //        {
                //            _strSubstLoc = "paragraph " + _srctext.Trim();
                //        }
                //        else
                //        {
                //            _strSubstLoc = _strSubstLoc + " paragraph " + _srctext.Trim();
                //        }
                //    }
                //}
                //else if (_srccntrl.ToUpper() == "COLUMN")
                //{
                //    if (_srctext.Trim() != "")
                //    {
                //        if (_strSubstLoc.Trim() == "")
                //        {
                //            _strSubstLoc = "column " + _srctext.Trim();
                //        }
                //        else
                //        {
                //            _strSubstLoc = _strSubstLoc + " column " + _srctext.Trim();
                //        }
                //    }
                //}
                //else if (_srccntrl.ToUpper() == "TABLE")
                //{
                //    if (_srctext.Trim() != "")
                //    {
                //        if (_strSubstLoc.Trim() == "")
                //        {
                //            _strSubstLoc = "table " + _srctext.Trim();
                //        }
                //        else
                //        {
                //            _strSubstLoc = _strSubstLoc + " table " + _srctext.Trim();
                //        }
                //    }
                //}
                //else if (_srccntrl.ToUpper() == "FIGURE")
                //{
                //    if (_srctext.Trim() != "")
                //    {
                //        if (_strSubstLoc.Trim() == "")
                //        {
                //            _strSubstLoc = "figure " + _srctext.Trim();
                //        }
                //        else
                //        {
                //            _strSubstLoc = _strSubstLoc + " figure " + _srctext.Trim();
                //        }
                //    }
                //}
                //else if (_srccntrl.ToUpper() == "SCHEME")
                //{
                //    if (_srctext.Trim() != "")
                //    {
                //        if (_strSubstLoc.Trim() == "")
                //        {
                //            _strSubstLoc = "scheme " + _srctext.Trim();
                //        }
                //        else
                //        {
                //            _strSubstLoc = _strSubstLoc + " scheme " + _srctext.Trim();
                //        }
                //    }
                //}
                //else if (_srccntrl.ToUpper() == "SHEET")
                //{
                //    if (_srctext.Trim() != "")
                //    {
                //        if (_strSubstLoc.Trim() == "")
                //        {
                //            _strSubstLoc = "sheet " + _srctext.Trim();
                //        }
                //        else
                //        {
                //            _strSubstLoc = _strSubstLoc + " sheet " + _srctext.Trim();
                //        }
                //    }
                //}
                //else if (_srccntrl.ToUpper() == "FOOTNOTE")
                //{
                //    if (_srctext.Trim() != "")
                //    {
                //        if (_strSubstLoc.Trim() == "")
                //        {
                //            _strSubstLoc = "footnote " + _srctext.Trim();
                //        }
                //        else
                //        {
                //            _strSubstLoc = _strSubstLoc + " footnote " + _srctext.Trim();
                //        }
                //    }
                //}
                //else if (_srccntrl.ToUpper() == "OTHER")
                //{
                //    if (_srctext.Trim() != "")
                //    {
                //        if (_strSubstLoc.Trim() == "")
                //        {
                //            _strSubstLoc = _srctext.Trim();
                //        }
                //        else
                //        {
                //            _strSubstLoc = _strSubstLoc + " " + _srctext.Trim();
                //        }
                //    }
                //}    
                #endregion
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            try
            {
                _strSubstLoc = "";
                txtSubstLoc.Text = _strSubstLoc;

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        string strInchi_BeforeChange = "";
        string strStruct_BeforeChange = "";        

        private void ChemRenditor_ComStructureChanged()
        {
            try
            {
                if (ChemRenditor.MolfileString != null && Ser8000Data != null)
                {
                    string strSer8000Val =  intTS_ID > 0 ? txtSeries8000.Text : "0";
                    txtMolFormula.Text = GetMoleculeFormula(ChemRenditor.MolfileString);

                    string strErrMsg = "";
                    string strInchi = ChemistryOperations.GetStructureInchiKey(ChemRenditor.MolfileString);
                    if (!string.IsNullOrEmpty(strInchi.Trim()))
                    {
                        //Check the duplicate in the Series 9000 and Series 8500 OrgRef Master data
                        if (!ChemistryOperations.CheckDuplicateStructureOnInchiInOrgRefData(strInchi, out strErrMsg))
                        {
                            //Check the duplicate in the TAN Managed 8000 Series data
                            DataTable dtSer8000_TAN = Ser8000Data;
                            if (ChemistryOperations.CheckForDuplicateStructureInTANSeries8000Data(ChemRenditor.MolfileString, dtSer8000_TAN, strSer8000Val, out strErrMsg))
                            {
                                MessageBox.Show(strErrMsg, "Manage 8000 series", MessageBoxButtons.OK, MessageBoxIcon.Error);

                                strInchi_BeforeChange = "";
                                ChemRenditor.MolfileString = strStruct_BeforeChange;
                                strStruct_BeforeChange = "";
                            }
                        }
                        else
                        {
                            MessageBox.Show(strErrMsg, "Manage 8000 series", MessageBoxButtons.OK, MessageBoxIcon.Error);

                            strInchi_BeforeChange = "";
                            ChemRenditor.MolfileString = strStruct_BeforeChange;
                            strStruct_BeforeChange = "";
                        }
                    }

                    #region Old Code commented on 23rd June 2014 by Sairam
                    //if (Ser8000Data.Rows.Count > 0)
                    //{
                    //    //DataView dvTemp = Ser8000Data.DefaultView;
                    //    //dvTemp.RowFilter = "tan = '" + TAN_Name + "'";
                    //    DataTable dtSer8000_TAN = Ser8000Data;

                    //    string strSer8000Val = !string.IsNullOrEmpty(txtSeries8000.Text) ? txtSeries8000.Text : "0";

                    //    txtMolFormula.Text = GetMoleculeFormula(ChemRenditor.MolfileString);

                    //    if (ChemistryOperations.CheckForDuplicateStructure(ChemRenditor.MolfileString, dtSer8000_TAN, strSer8000Val, out strErrMsg))
                    //    {
                    //        MessageBox.Show(strErrMsg, "Manage 8000 series", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    //        strInchi_BeforeChange = "";
                    //        ChemRenditor.MolfileString = strStruct_BeforeChange;
                    //        strStruct_BeforeChange = "";
                    //    }
                    //    else
                    //    {
                    //        strInchi = ChemistryOperations.GetStructureInchiKey(ChemRenditor.MolfileString);
                    //        if (!string.IsNullOrEmpty(strInchi.Trim()))
                    //        {
                    //            string strPNum = "";
                    //            string strRegNo = "";
                    //            IndxReactNarrDAL.CASRxnDataAccess.CheckDuplicateStructureOnInchi(strInchi, out strPNum, out strRegNo);

                    //            if (strPNum.Trim() != "" || strRegNo.Trim() != "")
                    //            {
                    //                if (strPNum.Trim() != "")
                    //                {
                    //                    strErrMsg = "Duplicate structure. Structure matching with " + strPNum;
                    //                }
                    //                else
                    //                {
                    //                    strErrMsg = "Duplicate structure. Structure matching with 8500 series RN: " + strRegNo;
                    //                }

                    //                MessageBox.Show(strErrMsg, "Manage 8000 series", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //                strInchi_BeforeChange = "";
                    //                ChemRenditor.MolfileString = strStruct_BeforeChange;
                    //                strStruct_BeforeChange = "";
                    //            }
                    //        }
                    //    }
                    //}
                    //else
                    //{
                    //    strInchi = ChemistryOperations.GetStructureInchiKey(ChemRenditor.MolfileString);
                    //    if (strInchi.Trim() != "")
                    //    {
                    //        string strPNum = "";
                    //        string strRegNo = "";
                    //        IndxReactNarrDAL.CASRxnDataAccess.CheckDuplicateStructureOnInchi(strInchi, out strPNum, out strRegNo);
                    //        if (strPNum.Trim() != "" || strRegNo.Trim() != "")
                    //        {
                    //            if (strPNum.Trim() != "")
                    //            {
                    //                strErrMsg = "Duplicate structure. Structure matching with " + strPNum;
                    //            }
                    //            else
                    //            {
                    //                strErrMsg = "Duplicate structure. Structure matching with 8500 series RN: " + strRegNo;
                    //            }

                    //            MessageBox.Show(strErrMsg, "Manage 8000 series", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //            strInchi_BeforeChange = "";
                    //            ChemRenditor.MolfileString = strStruct_BeforeChange;
                    //            strStruct_BeforeChange = "";
                    //        }
                    //    }
                    //} 
                    #endregion
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public static string GetMoleculeFormula(string molstring)
        {
            //string strMolWeight = "";
            string strMolFormula = "";
            try
            {
                MolHandler mHandler = new MolHandler(molstring);
                //float molWeight = mHandler.calcMolWeight();

                strMolFormula = mHandler.calcMolFormula();
                //strMolWeight = molWeight.ToString();

                //molweight_out = strMolWeight;
                return strMolFormula;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            //molweight_out = strMolWeight;
            return strMolFormula;
        }    

        private void btnSdf_Click(object sender, EventArgs e)
        {
            try
            {
                DataView dvTemp = Ser8000Data.DefaultView;
                dvTemp.RowFilter = "tan = '" + TAN_Name + "'";
                dvTemp.Sort = "ser8000 asc";
                DataTable dtSer8000_TAN = dvTemp.ToTable();
                ArrayList alstCols = new ArrayList();

                EmportToSdFile("c:\\sd_" + TAN_Name + ".sdf", dtSer8000_TAN, alstCols);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public bool EmportToSdFile(string _filename, DataTable _dtTanDetails, ArrayList _selproplist)
        {
            bool blWriteStatus = false;
            try
            {
                if (_filename.Trim() != "" && _dtTanDetails != null)
                {
                    if (_dtTanDetails.Rows.Count > 0)
                    {
                        FileOutputStream fOutStream = new FileOutputStream(_filename, true);
                        MolExporter objmExporter = new MolExporter(fOutStream, "sdf");

                        MolHandler objmHandler = null;
                        Molecule objMol = null;

                        for (int rIndx = 0; rIndx < _dtTanDetails.Rows.Count; rIndx++)
                        {
                            objmHandler = new MolHandler(_dtTanDetails.Rows[rIndx]["substmol"].ToString());
                            objMol = objmHandler.getMolecule();

                            objMol.setProperty("P_8000", _dtTanDetails.Rows[rIndx]["ser8000"].ToString());
                            objMol.setProperty("Substance Name", _dtTanDetails.Rows[rIndx]["subst_name"].ToString());
                            objMol.setProperty("Substance Location", _dtTanDetails.Rows[rIndx]["subst_loc"].ToString());

                            objmExporter.write(objMol);
                        }

                        fOutStream.close();
                        objmExporter.close();

                        blWriteStatus = true;
                        return blWriteStatus;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blWriteStatus;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                //Re-Bind data to combobox
                //BindSer8000NumsToCombobox(0);
                
                strInchi_BeforeChange = "";
               
                txtSubstName.Text = "";
                txtSubstLoc.Text = "";
                ChemRenditor.MolfileString = "";
                txtAuthorName.Text = "";
                txtOtherName.Text = "";
                _strSubstLoc = "";

                txtMolFormula.Text = "";

                intTS_ID = -1;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #region TextBox KeyDown Events

        private void txtSubstName_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    e.SuppressKeyPress = true;
                }

                if (e.Control == true)
                {
                    if (e.KeyCode == Keys.V)
                    {
                        IDataObject iData = Clipboard.GetDataObject();
                        if (iData.GetDataPresent(DataFormats.Text))
                        {
                            txtSubstName.Clear();
                        }
                        e.Handled = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtAuthorName_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    e.SuppressKeyPress = true;
                }

                if (e.Control == true)
                {
                    if (e.KeyCode == Keys.V)
                    {
                        IDataObject iData = Clipboard.GetDataObject();
                        if (iData.GetDataPresent(DataFormats.Text))
                        {
                            txtAuthorName.Clear();
                        }
                        e.Handled = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtOtherName_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    e.SuppressKeyPress = true;
                }

                if (e.Control == true)
                {
                    if (e.KeyCode == Keys.V)
                    {
                        IDataObject iData = Clipboard.GetDataObject();
                        if (iData.GetDataPresent(DataFormats.Text))
                        {
                            txtOtherName.Clear();
                        }
                        e.Handled = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion
    }
}
