﻿namespace IndxReactNarr
{
    partial class frmNewRxn_New
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMain = new System.Windows.Forms.Panel();
            this.txtSeq_Insert = new System.Windows.Forms.TextBox();
            this.txtNUM_Insert = new System.Windows.Forms.TextBox();
            this.chkDupRxn = new System.Windows.Forms.CheckBox();
            this.grpDupRxn = new System.Windows.Forms.GroupBox();
            this.txtSeq_Dup = new System.Windows.Forms.TextBox();
            this.txtNUM_Dup = new System.Windows.Forms.TextBox();
            this.lblProdNo = new System.Windows.Forms.Label();
            this.lblRxnSeq = new System.Windows.Forms.Label();
            this.lblRXNNUM = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.grpNewRxn = new System.Windows.Forms.GroupBox();
            this.rbnNUMs = new System.Windows.Forms.RadioButton();
            this.rbnSer9000 = new System.Windows.Forms.RadioButton();
            this.rbnSer8500 = new System.Windows.Forms.RadioButton();
            this.rbnSer8000 = new System.Windows.Forms.RadioButton();
            this.txtRxnNum = new System.Windows.Forms.TextBox();
            this.rbnAfter = new System.Windows.Forms.RadioButton();
            this.rbnBefore = new System.Windows.Forms.RadioButton();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnCreate = new System.Windows.Forms.Button();
            this.pnlMain.SuspendLayout();
            this.grpDupRxn.SuspendLayout();
            this.grpNewRxn.SuspendLayout();
            this.pnlBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.txtSeq_Insert);
            this.pnlMain.Controls.Add(this.txtNUM_Insert);
            this.pnlMain.Controls.Add(this.chkDupRxn);
            this.pnlMain.Controls.Add(this.grpDupRxn);
            this.pnlMain.Controls.Add(this.lblRXNNUM);
            this.pnlMain.Controls.Add(this.label1);
            this.pnlMain.Controls.Add(this.label2);
            this.pnlMain.Controls.Add(this.grpNewRxn);
            this.pnlMain.Controls.Add(this.rbnAfter);
            this.pnlMain.Controls.Add(this.rbnBefore);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(524, 188);
            this.pnlMain.TabIndex = 0;
            // 
            // txtSeq_Insert
            // 
            this.txtSeq_Insert.BackColor = System.Drawing.Color.White;
            this.txtSeq_Insert.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSeq_Insert.ForeColor = System.Drawing.Color.Blue;
            this.txtSeq_Insert.Location = new System.Drawing.Point(467, 79);
            this.txtSeq_Insert.Name = "txtSeq_Insert";
            this.txtSeq_Insert.ReadOnly = true;
            this.txtSeq_Insert.Size = new System.Drawing.Size(43, 25);
            this.txtSeq_Insert.TabIndex = 36;
            this.txtSeq_Insert.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtNUM_Insert
            // 
            this.txtNUM_Insert.BackColor = System.Drawing.Color.White;
            this.txtNUM_Insert.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNUM_Insert.ForeColor = System.Drawing.Color.Blue;
            this.txtNUM_Insert.Location = new System.Drawing.Point(340, 79);
            this.txtNUM_Insert.Name = "txtNUM_Insert";
            this.txtNUM_Insert.ReadOnly = true;
            this.txtNUM_Insert.Size = new System.Drawing.Size(83, 25);
            this.txtNUM_Insert.TabIndex = 35;
            this.txtNUM_Insert.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtNUM_Insert.Click += new System.EventHandler(this.txtNUM_Insert_Click);
            // 
            // chkDupRxn
            // 
            this.chkDupRxn.AutoSize = true;
            this.chkDupRxn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkDupRxn.ForeColor = System.Drawing.Color.Blue;
            this.chkDupRxn.Location = new System.Drawing.Point(9, 102);
            this.chkDupRxn.Name = "chkDupRxn";
            this.chkDupRxn.Size = new System.Drawing.Size(168, 21);
            this.chkDupRxn.TabIndex = 30;
            this.chkDupRxn.Text = "Duplicate with Reaction";
            this.chkDupRxn.UseVisualStyleBackColor = true;
            this.chkDupRxn.CheckedChanged += new System.EventHandler(this.chkDupRxn_CheckedChanged);
            // 
            // grpDupRxn
            // 
            this.grpDupRxn.Controls.Add(this.txtSeq_Dup);
            this.grpDupRxn.Controls.Add(this.txtNUM_Dup);
            this.grpDupRxn.Controls.Add(this.lblProdNo);
            this.grpDupRxn.Controls.Add(this.lblRxnSeq);
            this.grpDupRxn.Enabled = false;
            this.grpDupRxn.Location = new System.Drawing.Point(3, 109);
            this.grpDupRxn.Name = "grpDupRxn";
            this.grpDupRxn.Size = new System.Drawing.Size(518, 43);
            this.grpDupRxn.TabIndex = 34;
            this.grpDupRxn.TabStop = false;
            // 
            // txtSeq_Dup
            // 
            this.txtSeq_Dup.BackColor = System.Drawing.Color.White;
            this.txtSeq_Dup.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSeq_Dup.ForeColor = System.Drawing.Color.Blue;
            this.txtSeq_Dup.Location = new System.Drawing.Point(464, 14);
            this.txtSeq_Dup.Name = "txtSeq_Dup";
            this.txtSeq_Dup.ReadOnly = true;
            this.txtSeq_Dup.Size = new System.Drawing.Size(43, 25);
            this.txtSeq_Dup.TabIndex = 38;
            this.txtSeq_Dup.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtNUM_Dup
            // 
            this.txtNUM_Dup.BackColor = System.Drawing.Color.White;
            this.txtNUM_Dup.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNUM_Dup.ForeColor = System.Drawing.Color.Blue;
            this.txtNUM_Dup.Location = new System.Drawing.Point(337, 14);
            this.txtNUM_Dup.Name = "txtNUM_Dup";
            this.txtNUM_Dup.ReadOnly = true;
            this.txtNUM_Dup.Size = new System.Drawing.Size(83, 25);
            this.txtNUM_Dup.TabIndex = 37;
            this.txtNUM_Dup.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtNUM_Dup.Click += new System.EventHandler(this.txtNUM_Dup_Click);
            // 
            // lblProdNo
            // 
            this.lblProdNo.AutoSize = true;
            this.lblProdNo.ForeColor = System.Drawing.Color.Blue;
            this.lblProdNo.Location = new System.Drawing.Point(277, 18);
            this.lblProdNo.Name = "lblProdNo";
            this.lblProdNo.Size = new System.Drawing.Size(54, 17);
            this.lblProdNo.TabIndex = 8;
            this.lblProdNo.Text = "Product";
            // 
            // lblRxnSeq
            // 
            this.lblRxnSeq.AutoSize = true;
            this.lblRxnSeq.ForeColor = System.Drawing.Color.Blue;
            this.lblRxnSeq.Location = new System.Drawing.Point(433, 18);
            this.lblRxnSeq.Name = "lblRxnSeq";
            this.lblRxnSeq.Size = new System.Drawing.Size(30, 17);
            this.lblRxnSeq.TabIndex = 10;
            this.lblRxnSeq.Text = "Seq";
            // 
            // lblRXNNUM
            // 
            this.lblRXNNUM.AutoSize = true;
            this.lblRXNNUM.ForeColor = System.Drawing.Color.Blue;
            this.lblRXNNUM.Location = new System.Drawing.Point(283, 83);
            this.lblRXNNUM.Name = "lblRXNNUM";
            this.lblRXNNUM.Size = new System.Drawing.Size(54, 17);
            this.lblRXNNUM.TabIndex = 21;
            this.lblRXNNUM.Text = "Product";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(436, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 17);
            this.label1.TabIndex = 26;
            this.label1.Text = "Seq";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 17);
            this.label2.TabIndex = 33;
            this.label2.Text = "Insert new Reaction";
            // 
            // grpNewRxn
            // 
            this.grpNewRxn.Controls.Add(this.rbnNUMs);
            this.grpNewRxn.Controls.Add(this.rbnSer9000);
            this.grpNewRxn.Controls.Add(this.rbnSer8500);
            this.grpNewRxn.Controls.Add(this.rbnSer8000);
            this.grpNewRxn.Controls.Add(this.txtRxnNum);
            this.grpNewRxn.ForeColor = System.Drawing.Color.Blue;
            this.grpNewRxn.Location = new System.Drawing.Point(3, 3);
            this.grpNewRxn.Name = "grpNewRxn";
            this.grpNewRxn.Size = new System.Drawing.Size(518, 69);
            this.grpNewRxn.TabIndex = 32;
            this.grpNewRxn.TabStop = false;
            this.grpNewRxn.Text = "Select Product from the available options";
            // 
            // rbnNUMs
            // 
            this.rbnNUMs.AutoSize = true;
            this.rbnNUMs.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnNUMs.ForeColor = System.Drawing.Color.Red;
            this.rbnNUMs.Location = new System.Drawing.Point(8, 30);
            this.rbnNUMs.Name = "rbnNUMs";
            this.rbnNUMs.Size = new System.Drawing.Size(61, 21);
            this.rbnNUMs.TabIndex = 20;
            this.rbnNUMs.Text = "NUM";
            this.rbnNUMs.UseVisualStyleBackColor = true;
            this.rbnNUMs.CheckedChanged += new System.EventHandler(this.rbnNUMs_CheckedChanged);
            // 
            // rbnSer9000
            // 
            this.rbnSer9000.AutoSize = true;
            this.rbnSer9000.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnSer9000.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.rbnSer9000.Location = new System.Drawing.Point(85, 30);
            this.rbnSer9000.Name = "rbnSer9000";
            this.rbnSer9000.Size = new System.Drawing.Size(94, 21);
            this.rbnSer9000.TabIndex = 21;
            this.rbnSer9000.Text = "Series 9000";
            this.rbnSer9000.UseVisualStyleBackColor = true;
            this.rbnSer9000.CheckedChanged += new System.EventHandler(this.rbnSer9000_CheckedChanged);
            // 
            // rbnSer8500
            // 
            this.rbnSer8500.AutoSize = true;
            this.rbnSer8500.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnSer8500.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.rbnSer8500.Location = new System.Drawing.Point(196, 30);
            this.rbnSer8500.Name = "rbnSer8500";
            this.rbnSer8500.Size = new System.Drawing.Size(94, 21);
            this.rbnSer8500.TabIndex = 22;
            this.rbnSer8500.Text = "Series 8500";
            this.rbnSer8500.UseVisualStyleBackColor = true;
            this.rbnSer8500.CheckedChanged += new System.EventHandler(this.rbnSer8500_CheckedChanged);
            // 
            // rbnSer8000
            // 
            this.rbnSer8000.AutoSize = true;
            this.rbnSer8000.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnSer8000.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.rbnSer8000.Location = new System.Drawing.Point(305, 30);
            this.rbnSer8000.Name = "rbnSer8000";
            this.rbnSer8000.Size = new System.Drawing.Size(94, 21);
            this.rbnSer8000.TabIndex = 23;
            this.rbnSer8000.Text = "Series 8000";
            this.rbnSer8000.UseVisualStyleBackColor = true;
            this.rbnSer8000.CheckedChanged += new System.EventHandler(this.rbnSer8000_CheckedChanged);
            // 
            // txtRxnNum
            // 
            this.txtRxnNum.BackColor = System.Drawing.Color.White;
            this.txtRxnNum.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRxnNum.ForeColor = System.Drawing.Color.Blue;
            this.txtRxnNum.HideSelection = false;
            this.txtRxnNum.Location = new System.Drawing.Point(412, 28);
            this.txtRxnNum.Name = "txtRxnNum";
            this.txtRxnNum.ReadOnly = true;
            this.txtRxnNum.Size = new System.Drawing.Size(95, 25);
            this.txtRxnNum.TabIndex = 24;
            this.txtRxnNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // rbnAfter
            // 
            this.rbnAfter.AutoSize = true;
            this.rbnAfter.Checked = true;
            this.rbnAfter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnAfter.ForeColor = System.Drawing.Color.Red;
            this.rbnAfter.Location = new System.Drawing.Point(218, 81);
            this.rbnAfter.Name = "rbnAfter";
            this.rbnAfter.Size = new System.Drawing.Size(58, 21);
            this.rbnAfter.TabIndex = 24;
            this.rbnAfter.TabStop = true;
            this.rbnAfter.Text = "After";
            this.rbnAfter.UseVisualStyleBackColor = true;
            // 
            // rbnBefore
            // 
            this.rbnBefore.AutoSize = true;
            this.rbnBefore.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnBefore.ForeColor = System.Drawing.Color.Red;
            this.rbnBefore.Location = new System.Drawing.Point(141, 81);
            this.rbnBefore.Name = "rbnBefore";
            this.rbnBefore.Size = new System.Drawing.Size(67, 21);
            this.rbnBefore.TabIndex = 23;
            this.rbnBefore.Text = "Before";
            this.rbnBefore.UseVisualStyleBackColor = true;
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlBottom.Controls.Add(this.btnReset);
            this.pnlBottom.Controls.Add(this.btnCreate);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 154);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(524, 34);
            this.pnlBottom.TabIndex = 6;
            // 
            // btnReset
            // 
            this.btnReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReset.Location = new System.Drawing.Point(346, 1);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 29);
            this.btnReset.TabIndex = 5;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnCreate
            // 
            this.btnCreate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCreate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCreate.Location = new System.Drawing.Point(444, 1);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(75, 29);
            this.btnCreate.TabIndex = 4;
            this.btnCreate.Text = "Create";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // frmNewRxn_New
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(524, 188);
            this.Controls.Add(this.pnlMain);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmNewRxn_New";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "New Reaction";
            this.Load += new System.EventHandler(this.frmNewRxn_New_Load);
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.grpDupRxn.ResumeLayout(false);
            this.grpDupRxn.PerformLayout();
            this.grpNewRxn.ResumeLayout(false);
            this.grpNewRxn.PerformLayout();
            this.pnlBottom.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.RadioButton rbnSer8000;
        private System.Windows.Forms.RadioButton rbnSer8500;
        private System.Windows.Forms.RadioButton rbnSer9000;
        private System.Windows.Forms.RadioButton rbnNUMs;
        private System.Windows.Forms.TextBox txtRxnNum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rbnAfter;
        private System.Windows.Forms.Label lblRXNNUM;
        private System.Windows.Forms.RadioButton rbnBefore;
        private System.Windows.Forms.Label lblProdNo;
        private System.Windows.Forms.Label lblRxnSeq;
        private System.Windows.Forms.CheckBox chkDupRxn;
        private System.Windows.Forms.GroupBox grpNewRxn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox grpDupRxn;
        private System.Windows.Forms.TextBox txtNUM_Insert;
        private System.Windows.Forms.TextBox txtSeq_Insert;
        private System.Windows.Forms.TextBox txtSeq_Dup;
        private System.Windows.Forms.TextBox txtNUM_Dup;
        private System.Windows.Forms.Button btnReset;
    }
}