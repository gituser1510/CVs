﻿namespace IndxReactNarr
{
    partial class frmSrch_RegNo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvSrchResult = new System.Windows.Forms.DataGridView();
            this.colRxnSNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnSeq = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPartpntType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSubstName = new System.Windows.Forms.TextBox();
            this.txtRegNo = new System.Windows.Forms.TextBox();
            this.txtTAN = new System.Windows.Forms.TextBox();
            this.lblTAN = new System.Windows.Forms.Label();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSrchResult)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.dgvSrchResult);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(741, 416);
            this.pnlMain.TabIndex = 0;
            // 
            // dgvSrchResult
            // 
            this.dgvSrchResult.AllowUserToAddRows = false;
            this.dgvSrchResult.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvSrchResult.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSrchResult.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvSrchResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvSrchResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSrchResult.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colRxnSNo,
            this.colRxnNum,
            this.colRxnSeq,
            this.colStage,
            this.colPartpntType});
            this.dgvSrchResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSrchResult.Location = new System.Drawing.Point(0, 65);
            this.dgvSrchResult.Name = "dgvSrchResult";
            this.dgvSrchResult.ReadOnly = true;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSrchResult.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvSrchResult.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.dgvSrchResult.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvSrchResult.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSrchResult.Size = new System.Drawing.Size(741, 351);
            this.dgvSrchResult.TabIndex = 1;
            this.dgvSrchResult.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvSrchResult_RowPostPaint);
            // 
            // colRxnSNo
            // 
            this.colRxnSNo.HeaderText = "S. No";
            this.colRxnSNo.Name = "colRxnSNo";
            this.colRxnSNo.ReadOnly = true;
            this.colRxnSNo.Width = 67;
            // 
            // colRxnNum
            // 
            this.colRxnNum.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colRxnNum.HeaderText = "RxnNum";
            this.colRxnNum.Name = "colRxnNum";
            this.colRxnNum.ReadOnly = true;
            this.colRxnNum.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colRxnSeq
            // 
            this.colRxnSeq.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colRxnSeq.HeaderText = "RxnSeq";
            this.colRxnSeq.Name = "colRxnSeq";
            this.colRxnSeq.ReadOnly = true;
            this.colRxnSeq.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colStage
            // 
            this.colStage.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colStage.HeaderText = "Stage";
            this.colStage.Name = "colStage";
            this.colStage.ReadOnly = true;
            this.colStage.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colPartpntType
            // 
            this.colPartpntType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colPartpntType.HeaderText = "Participant";
            this.colPartpntType.Name = "colPartpntType";
            this.colPartpntType.ReadOnly = true;
            this.colPartpntType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlTop.Controls.Add(this.label2);
            this.pnlTop.Controls.Add(this.label1);
            this.pnlTop.Controls.Add(this.txtSubstName);
            this.pnlTop.Controls.Add(this.txtRegNo);
            this.pnlTop.Controls.Add(this.txtTAN);
            this.pnlTop.Controls.Add(this.lblTAN);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(741, 65);
            this.pnlTop.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Subst. Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(254, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Reg. No";
            // 
            // txtSubstName
            // 
            this.txtSubstName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSubstName.BackColor = System.Drawing.Color.White;
            this.txtSubstName.ForeColor = System.Drawing.Color.Blue;
            this.txtSubstName.Location = new System.Drawing.Point(91, 34);
            this.txtSubstName.Name = "txtSubstName";
            this.txtSubstName.ReadOnly = true;
            this.txtSubstName.Size = new System.Drawing.Size(643, 25);
            this.txtSubstName.TabIndex = 3;
            this.txtSubstName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtRegNo_KeyDown);
            // 
            // txtRegNo
            // 
            this.txtRegNo.BackColor = System.Drawing.Color.White;
            this.txtRegNo.ForeColor = System.Drawing.Color.Blue;
            this.txtRegNo.Location = new System.Drawing.Point(317, 4);
            this.txtRegNo.Name = "txtRegNo";
            this.txtRegNo.ReadOnly = true;
            this.txtRegNo.Size = new System.Drawing.Size(145, 25);
            this.txtRegNo.TabIndex = 2;
            this.txtRegNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtRegNo_KeyDown);
            // 
            // txtTAN
            // 
            this.txtTAN.BackColor = System.Drawing.Color.White;
            this.txtTAN.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTAN.ForeColor = System.Drawing.Color.Blue;
            this.txtTAN.Location = new System.Drawing.Point(91, 4);
            this.txtTAN.Name = "txtTAN";
            this.txtTAN.ReadOnly = true;
            this.txtTAN.Size = new System.Drawing.Size(145, 25);
            this.txtTAN.TabIndex = 1;
            // 
            // lblTAN
            // 
            this.lblTAN.AutoSize = true;
            this.lblTAN.Location = new System.Drawing.Point(48, 8);
            this.lblTAN.Name = "lblTAN";
            this.lblTAN.Size = new System.Drawing.Size(38, 17);
            this.lblTAN.TabIndex = 0;
            this.lblTAN.Text = "TAN";
            // 
            // frmSrch_RegNo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(741, 416);
            this.Controls.Add(this.pnlMain);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSrch_RegNo";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Search Reg. No / Subst.Name";
            this.Load += new System.EventHandler(this.frmSrch_RegNo_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSrchResult)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.DataGridView dgvSrchResult;
        private System.Windows.Forms.TextBox txtTAN;
        private System.Windows.Forms.Label lblTAN;
        private System.Windows.Forms.TextBox txtRegNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSubstName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnSNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnSeq;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStage;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPartpntType;
    }
}