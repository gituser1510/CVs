﻿namespace IndxReactNarr
{
    partial class frmSeries8000
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            MDL.Draw.Chemistry.Molecule molecule1 = new MDL.Draw.Chemistry.Molecule();
            MDL.Draw.Renderer.Preferences.DisplayPreferences displayPreferences1 = new MDL.Draw.Renderer.Preferences.DisplayPreferences();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvSer8000 = new System.Windows.Forms.DataGridView();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.txtSubstLoc = new System.Windows.Forms.TextBox();
            this.lblSubstLoc = new System.Windows.Forms.Label();
            this.txtOtherName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAuthorName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSubstName = new System.Windows.Forms.TextBox();
            this.lblSubstName = new System.Windows.Forms.Label();
            this.txtSer8000 = new System.Windows.Forms.TextBox();
            this.lblNrnNum = new System.Windows.Forms.Label();
            this.renditor1 = new MDL.Draw.Renditor.Renditor();
            this.colSer8000 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSubstName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAuthorName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOtherName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSubstLoc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSubstMolecule = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStructure = new System.Windows.Forms.DataGridViewImageColumn();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSer8000)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.dgvSer8000);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(866, 480);
            this.pnlMain.TabIndex = 2;
            // 
            // dgvSer8000
            // 
            this.dgvSer8000.AllowUserToAddRows = false;
            this.dgvSer8000.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvSer8000.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSer8000.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvSer8000.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSer8000.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSer8000,
            this.colSubstName,
            this.colAuthorName,
            this.colOtherName,
            this.colSubstLoc,
            this.colSubstMolecule,
            this.colStructure});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvSer8000.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvSer8000.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSer8000.Location = new System.Drawing.Point(0, 98);
            this.dgvSer8000.Name = "dgvSer8000";
            this.dgvSer8000.ReadOnly = true;
            this.dgvSer8000.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSer8000.Size = new System.Drawing.Size(866, 382);
            this.dgvSer8000.TabIndex = 7;
            this.dgvSer8000.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSer8000_CellDoubleClick);
            this.dgvSer8000.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvSer8000_RowPostPaint);
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.White;
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.txtSubstLoc);
            this.pnlTop.Controls.Add(this.lblSubstLoc);
            this.pnlTop.Controls.Add(this.txtOtherName);
            this.pnlTop.Controls.Add(this.label2);
            this.pnlTop.Controls.Add(this.txtAuthorName);
            this.pnlTop.Controls.Add(this.label1);
            this.pnlTop.Controls.Add(this.txtSubstName);
            this.pnlTop.Controls.Add(this.lblSubstName);
            this.pnlTop.Controls.Add(this.txtSer8000);
            this.pnlTop.Controls.Add(this.lblNrnNum);
            this.pnlTop.Controls.Add(this.renditor1);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(866, 98);
            this.pnlTop.TabIndex = 0;
            // 
            // txtSubstLoc
            // 
            this.txtSubstLoc.BackColor = System.Drawing.Color.White;
            this.txtSubstLoc.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSubstLoc.Location = new System.Drawing.Point(531, 65);
            this.txtSubstLoc.Name = "txtSubstLoc";
            this.txtSubstLoc.Size = new System.Drawing.Size(330, 25);
            this.txtSubstLoc.TabIndex = 20;
            this.txtSubstLoc.TextChanged += new System.EventHandler(this.txtSer8000_TextChanged);
            // 
            // lblSubstLoc
            // 
            this.lblSubstLoc.AutoSize = true;
            this.lblSubstLoc.Location = new System.Drawing.Point(429, 69);
            this.lblSubstLoc.Name = "lblSubstLoc";
            this.lblSubstLoc.Size = new System.Drawing.Size(99, 17);
            this.lblSubstLoc.TabIndex = 19;
            this.lblSubstLoc.Text = "Subst. Location";
            // 
            // txtOtherName
            // 
            this.txtOtherName.BackColor = System.Drawing.Color.White;
            this.txtOtherName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOtherName.Location = new System.Drawing.Point(87, 65);
            this.txtOtherName.Name = "txtOtherName";
            this.txtOtherName.Size = new System.Drawing.Size(330, 25);
            this.txtOtherName.TabIndex = 18;
            this.txtOtherName.TextChanged += new System.EventHandler(this.txtSer8000_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 17);
            this.label2.TabIndex = 17;
            this.label2.Text = "Other Name";
            // 
            // txtAuthorName
            // 
            this.txtAuthorName.BackColor = System.Drawing.Color.White;
            this.txtAuthorName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAuthorName.Location = new System.Drawing.Point(531, 34);
            this.txtAuthorName.Name = "txtAuthorName";
            this.txtAuthorName.Size = new System.Drawing.Size(330, 25);
            this.txtAuthorName.TabIndex = 16;
            this.txtAuthorName.TextChanged += new System.EventHandler(this.txtSer8000_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(439, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 17);
            this.label1.TabIndex = 15;
            this.label1.Text = "Author Name";
            // 
            // txtSubstName
            // 
            this.txtSubstName.BackColor = System.Drawing.Color.White;
            this.txtSubstName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSubstName.Location = new System.Drawing.Point(87, 34);
            this.txtSubstName.Name = "txtSubstName";
            this.txtSubstName.Size = new System.Drawing.Size(330, 25);
            this.txtSubstName.TabIndex = 14;
            this.txtSubstName.TextChanged += new System.EventHandler(this.txtSer8000_TextChanged);
            // 
            // lblSubstName
            // 
            this.lblSubstName.AutoSize = true;
            this.lblSubstName.Location = new System.Drawing.Point(4, 38);
            this.lblSubstName.Name = "lblSubstName";
            this.lblSubstName.Size = new System.Drawing.Size(84, 17);
            this.lblSubstName.TabIndex = 13;
            this.lblSubstName.Text = "Subst. Name";
            // 
            // txtSer8000
            // 
            this.txtSer8000.BackColor = System.Drawing.Color.White;
            this.txtSer8000.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSer8000.Location = new System.Drawing.Point(87, 4);
            this.txtSer8000.Name = "txtSer8000";
            this.txtSer8000.Size = new System.Drawing.Size(100, 25);
            this.txtSer8000.TabIndex = 10;
            this.txtSer8000.TextChanged += new System.EventHandler(this.txtSer8000_TextChanged);
            // 
            // lblNrnNum
            // 
            this.lblNrnNum.AutoSize = true;
            this.lblNrnNum.Location = new System.Drawing.Point(10, 8);
            this.lblNrnNum.Name = "lblNrnNum";
            this.lblNrnNum.Size = new System.Drawing.Size(76, 17);
            this.lblNrnNum.TabIndex = 9;
            this.lblNrnNum.Text = "Series 8000";
            // 
            // renditor1
            // 
            this.renditor1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.renditor1.AutoSizeStructure = true;
            this.renditor1.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.renditor1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.renditor1.ChimeString = null;
            this.renditor1.ClearingEnabled = true;
            this.renditor1.CopyingEnabled = true;
            this.renditor1.DisplayOnEmpty = null;
            this.renditor1.EditingEnabled = true;
            this.renditor1.FileName = null;
            this.renditor1.HighlightInfo = "";
            this.renditor1.IsBitmapFromOLE = true;
            this.renditor1.Location = new System.Drawing.Point(423, 8);
            molecule1.ArrowDir = MDL.Draw.ArrowDirType.No;
            molecule1.ArrowStyle = MDL.Draw.ArrowStyleType.Empty;
            molecule1.AtomValenceDisplay = true;
            molecule1.BaseFormBoxSetting = 0;
            molecule1.BondLineThickness = 0D;
            molecule1.CarbonLabelDisplay = false;
            molecule1.ChemLabelFont = null;
            molecule1.ChemLabelFontString = "(none)";
            molecule1.ColorAtomsByTypeInSketch = false;
            molecule1.ConfigLabelFont = null;
            molecule1.ConfigLabelFontString = "(none)";
            molecule1.Coords = null;
            molecule1.DashSpacing = 0.1D;
            molecule1.DoubleBondWidth = 0.18D;
            molecule1.FillColor = System.Drawing.Color.Empty;
            molecule1.FillStyle = MDL.Draw.ChemGraphicsObject.FillStyles.SOLID;
            molecule1.ForeColor = System.Drawing.Color.Empty;
            molecule1.ForeColorString = "";
            molecule1.ForSubsequenceQuery = false;
            molecule1.HighlightChildren = "";
            molecule1.HighlightColor = System.Drawing.Color.Blue;
            molecule1.HydrogenDisplayMode = MDL.Draw.Chemistry.Atom.HydrogenDisplayMode.Off;
            molecule1.Id = 11088;
            molecule1.Initial = "";
            molecule1.IsAModel = false;
            molecule1.IsARotatedModel = false;
            molecule1.KeepRSLabelsInSketch = true;
            molecule1.LastModifyChemText = -1;
            molecule1.MaintainXMLChildOrderFlag = false;
            molecule1.MustPerceiveStereo = true;
            molecule1.PenColor = System.Drawing.Color.Empty;
            molecule1.PenStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            molecule1.PenStyleToken = 0;
            molecule1.PenWidth = ((byte)(0));
            molecule1.PenWidthUnit = MDL.Draw.ChemGraphicsObject.PenWidthUnits.Default;
            molecule1.RefId = 11088;
            molecule1.Replaced = false;
            molecule1.RgroupCleeanUpNeeded = false;
            molecule1.RgroupLabelsPresentFlag = false;
            molecule1.ScaleLabelsToBondLength = false;
            molecule1.Selected = false;
            molecule1.Size = 0;
            molecule1.SkcWritten = false;
            molecule1.SkNumber = ((short)(0));
            molecule1.TextBorder = 0.1D;
            molecule1.Transparent = false;
            molecule1.UndoableEditListener = null;
            molecule1.WedgeWidth = 0.1D;
            molecule1.ZLayer = -89421;
            this.renditor1.Molecule = molecule1;
            this.renditor1.MolfileString = "";
            this.renditor1.Name = "renditor1";
            this.renditor1.OldScalingMode = MDL.Draw.Renderer.Preferences.StructureScalingMode.ScaleToFitBox;
            this.renditor1.PastingEnabled = true;
            this.renditor1.Preferences = displayPreferences1;
            this.renditor1.PreferencesFileName = "default.xml";
            this.renditor1.RendererBorderStyle = System.Windows.Forms.ButtonBorderStyle.Inset;
            this.renditor1.RenditorMolecule = molecule1;
            this.renditor1.RenditorName = "Demo Renditor";
            this.renditor1.Size = new System.Drawing.Size(36, 32);
            this.renditor1.SketchString = "AQMABEElACJDcmVhdGVkIGJ5IEFjY2VscnlzRHJhdyA0LjEuMTAwLjcwAgQAAABYBQAAAABZBQAAAAALC" +
    "wAFQXJpYWx4AAAUAgA=";
            this.renditor1.SmilesString = "";
            this.renditor1.TabIndex = 41;
            this.renditor1.URLEncodedMolfileString = "";
            this.renditor1.UseLocalXMLConfig = false;
            this.renditor1.Visible = false;
            // 
            // colSer8000
            // 
            this.colSer8000.HeaderText = "Series 8000";
            this.colSer8000.Name = "colSer8000";
            this.colSer8000.ReadOnly = true;
            this.colSer8000.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colSubstName
            // 
            this.colSubstName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colSubstName.HeaderText = "Subst. Name";
            this.colSubstName.Name = "colSubstName";
            this.colSubstName.ReadOnly = true;
            this.colSubstName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colAuthorName
            // 
            this.colAuthorName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colAuthorName.HeaderText = "Author Name";
            this.colAuthorName.Name = "colAuthorName";
            this.colAuthorName.ReadOnly = true;
            this.colAuthorName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colOtherName
            // 
            this.colOtherName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colOtherName.HeaderText = "Other Name";
            this.colOtherName.Name = "colOtherName";
            this.colOtherName.ReadOnly = true;
            this.colOtherName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colSubstLoc
            // 
            this.colSubstLoc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colSubstLoc.HeaderText = "Subst. Location";
            this.colSubstLoc.Name = "colSubstLoc";
            this.colSubstLoc.ReadOnly = true;
            this.colSubstLoc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colSubstMolecule
            // 
            this.colSubstMolecule.HeaderText = "Subst. Molecule";
            this.colSubstMolecule.Name = "colSubstMolecule";
            this.colSubstMolecule.ReadOnly = true;
            this.colSubstMolecule.Visible = false;
            // 
            // colStructure
            // 
            this.colStructure.HeaderText = "Structure";
            this.colStructure.Name = "colStructure";
            this.colStructure.ReadOnly = true;
            // 
            // frmSeries8000
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(866, 480);
            this.Controls.Add(this.pnlMain);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSeries8000";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Series 8000";
            this.Load += new System.EventHandler(this.frmSeries8000_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSer8000)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.DataGridView dgvSer8000;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.TextBox txtSubstName;
        private System.Windows.Forms.Label lblSubstName;
        private System.Windows.Forms.TextBox txtSer8000;
        private System.Windows.Forms.Label lblNrnNum;
        private System.Windows.Forms.TextBox txtOtherName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAuthorName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSubstLoc;
        private System.Windows.Forms.Label lblSubstLoc;
        private MDL.Draw.Renditor.Renditor renditor1;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSer8000;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSubstName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAuthorName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOtherName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSubstLoc;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSubstMolecule;
        private System.Windows.Forms.DataGridViewImageColumn colStructure;
    }
}