﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using System.IO;

namespace IndxReactNarr
{
    public partial class frmAminoAcids : Form
    {
        public frmAminoAcids()
        {
            InitializeComponent();
        }

        public string FilePath_AminoAcids
        {
            get;
            set;
        }

        private void frmAminoAcids_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public void LoadFileInControl()
        {
            try
            {
                if (!string.IsNullOrEmpty(FilePath_AminoAcids))
                {
                    pdfCntrl_AminoAcid.Visible = true;
                    pdfCntrl_AminoAcid.IsAccessible = true;
                    pdfCntrl_AminoAcid.LoadFile(FilePath_AminoAcids);                    
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
