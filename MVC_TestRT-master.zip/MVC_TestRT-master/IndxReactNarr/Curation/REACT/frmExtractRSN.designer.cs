﻿namespace IndxReactNarr
{
    partial class frmExtractRSN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlGrid = new System.Windows.Forms.Panel();
            this.dgRSN_DB = new System.Windows.Forms.DataGridView();
            this.colRSNID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTAN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colProdNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxn_Seq = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFreeText = new Keyoti.RapidSpell.Grid.AYTDataGridViewTextBoxColumn();
            this.colRsnType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgRSN_Xml = new System.Windows.Forms.DataGridView();
            this.pnlBrowse = new System.Windows.Forms.Panel();
            this.pnlTANs = new System.Windows.Forms.Panel();
            this.btnGetBatchRSN = new System.Windows.Forms.Button();
            this.lblBNo = new System.Windows.Forms.Label();
            this.txtBatchNo = new System.Windows.Forms.TextBox();
            this.lblBatch = new System.Windows.Forms.Label();
            this.txtBatchName = new System.Windows.Forms.TextBox();
            this.btnFind_Replace = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.cmbTANs = new System.Windows.Forms.ComboBox();
            this.txtTAN = new System.Windows.Forms.TextBox();
            this.btnGet = new System.Windows.Forms.Button();
            this.lblTAN = new System.Windows.Forms.Label();
            this.pnlXML = new System.Windows.Forms.Panel();
            this.txtXmlFile = new System.Windows.Forms.TextBox();
            this.lblBrowseXml = new System.Windows.Forms.Label();
            this.btnSave_Exl = new System.Windows.Forms.Button();
            this.btnBrowseXML = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.dataGridView_AYT_Manager1 = new Keyoti.RapidSpell.Grid.DataGridView_AYT_Manager();
            this.rapidSpellAsYouType1 = new Keyoti.RapidSpell.RapidSpellAsYouType(this.components);
            this.pnlMain.SuspendLayout();
            this.pnlGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgRSN_DB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgRSN_Xml)).BeginInit();
            this.pnlBrowse.SuspendLayout();
            this.pnlTANs.SuspendLayout();
            this.pnlXML.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.pnlGrid);
            this.pnlMain.Controls.Add(this.pnlBrowse);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(981, 578);
            this.pnlMain.TabIndex = 0;
            // 
            // pnlGrid
            // 
            this.pnlGrid.Controls.Add(this.dgRSN_DB);
            this.pnlGrid.Controls.Add(this.dgRSN_Xml);
            this.pnlGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlGrid.Location = new System.Drawing.Point(0, 75);
            this.pnlGrid.Name = "pnlGrid";
            this.pnlGrid.Size = new System.Drawing.Size(981, 503);
            this.pnlGrid.TabIndex = 3;
            // 
            // dgRSN_DB
            // 
            this.dgRSN_DB.AllowUserToAddRows = false;
            this.dgRSN_DB.AllowUserToDeleteRows = false;
            this.dgRSN_DB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgRSN_DB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgRSN_DB.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colRSNID,
            this.colTAN,
            this.colSNo,
            this.colProdNo,
            this.colRxn_Seq,
            this.colStage,
            this.colCVT,
            this.colFreeText,
            this.colRsnType});
            this.dgRSN_DB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgRSN_DB.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgRSN_DB.Location = new System.Drawing.Point(0, 0);
            this.dgRSN_DB.Name = "dgRSN_DB";
            this.dgRSN_DB.ReadOnly = true;
            this.dgRSN_DB.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgRSN_DB.Size = new System.Drawing.Size(981, 503);
            this.dgRSN_DB.TabIndex = 1;
            this.dgRSN_DB.Visible = false;
            this.dgRSN_DB.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgRSN_DB_RowPostPaint);
            // 
            // colRSNID
            // 
            this.colRSNID.HeaderText = "rsn_id";
            this.colRSNID.Name = "colRSNID";
            this.colRSNID.ReadOnly = true;
            this.colRSNID.Visible = false;
            // 
            // colTAN
            // 
            this.colTAN.HeaderText = "TAN";
            this.colTAN.Name = "colTAN";
            this.colTAN.ReadOnly = true;
            this.colTAN.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colSNo
            // 
            this.colSNo.HeaderText = "S.No";
            this.colSNo.Name = "colSNo";
            this.colSNo.ReadOnly = true;
            this.colSNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colProdNo
            // 
            this.colProdNo.HeaderText = "Product No";
            this.colProdNo.Name = "colProdNo";
            this.colProdNo.ReadOnly = true;
            this.colProdNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colRxn_Seq
            // 
            this.colRxn_Seq.HeaderText = "RXN_SEQ";
            this.colRxn_Seq.Name = "colRxn_Seq";
            this.colRxn_Seq.ReadOnly = true;
            this.colRxn_Seq.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colStage
            // 
            this.colStage.HeaderText = "Stage";
            this.colStage.Name = "colStage";
            this.colStage.ReadOnly = true;
            this.colStage.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colCVT
            // 
            this.colCVT.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colCVT.DefaultCellStyle = dataGridViewCellStyle3;
            this.colCVT.HeaderText = "RSN CVT";
            this.colCVT.Name = "colCVT";
            this.colCVT.ReadOnly = true;
            this.colCVT.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colCVT.Width = 188;
            // 
            // colFreeText
            // 
            this.colFreeText.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colFreeText.DefaultCellStyle = dataGridViewCellStyle4;
            this.colFreeText.HeaderText = "RSN Free Text";
            this.colFreeText.Name = "colFreeText";
            this.colFreeText.ReadOnly = true;
            this.colFreeText.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colFreeText.Width = 187;
            // 
            // colRsnType
            // 
            this.colRsnType.HeaderText = "RSN Type";
            this.colRsnType.Name = "colRsnType";
            this.colRsnType.ReadOnly = true;
            this.colRsnType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dgRSN_Xml
            // 
            this.dgRSN_Xml.AllowUserToAddRows = false;
            this.dgRSN_Xml.AllowUserToDeleteRows = false;
            this.dgRSN_Xml.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgRSN_Xml.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgRSN_Xml.Location = new System.Drawing.Point(0, 0);
            this.dgRSN_Xml.Name = "dgRSN_Xml";
            this.dgRSN_Xml.ReadOnly = true;
            this.dgRSN_Xml.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgRSN_Xml.Size = new System.Drawing.Size(981, 503);
            this.dgRSN_Xml.TabIndex = 0;
            // 
            // pnlBrowse
            // 
            this.pnlBrowse.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlBrowse.Controls.Add(this.pnlTANs);
            this.pnlBrowse.Controls.Add(this.pnlXML);
            this.pnlBrowse.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlBrowse.Location = new System.Drawing.Point(0, 0);
            this.pnlBrowse.Name = "pnlBrowse";
            this.pnlBrowse.Size = new System.Drawing.Size(981, 75);
            this.pnlBrowse.TabIndex = 2;
            // 
            // pnlTANs
            // 
            this.pnlTANs.BackColor = System.Drawing.Color.White;
            this.pnlTANs.Controls.Add(this.btnGetBatchRSN);
            this.pnlTANs.Controls.Add(this.lblBNo);
            this.pnlTANs.Controls.Add(this.txtBatchNo);
            this.pnlTANs.Controls.Add(this.lblBatch);
            this.pnlTANs.Controls.Add(this.txtBatchName);
            this.pnlTANs.Controls.Add(this.btnFind_Replace);
            this.pnlTANs.Controls.Add(this.btnUpdate);
            this.pnlTANs.Controls.Add(this.cmbTANs);
            this.pnlTANs.Controls.Add(this.txtTAN);
            this.pnlTANs.Controls.Add(this.btnGet);
            this.pnlTANs.Controls.Add(this.lblTAN);
            this.pnlTANs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTANs.Location = new System.Drawing.Point(0, 36);
            this.pnlTANs.Name = "pnlTANs";
            this.pnlTANs.Size = new System.Drawing.Size(977, 35);
            this.pnlTANs.TabIndex = 23;
            // 
            // btnGetBatchRSN
            // 
            this.btnGetBatchRSN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGetBatchRSN.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGetBatchRSN.Location = new System.Drawing.Point(337, 3);
            this.btnGetBatchRSN.Name = "btnGetBatchRSN";
            this.btnGetBatchRSN.Size = new System.Drawing.Size(58, 29);
            this.btnGetBatchRSN.TabIndex = 30;
            this.btnGetBatchRSN.Text = "Get";
            this.btnGetBatchRSN.UseVisualStyleBackColor = true;
            this.btnGetBatchRSN.Click += new System.EventHandler(this.btnGetBatchRSN_Click);
            // 
            // lblBNo
            // 
            this.lblBNo.AutoSize = true;
            this.lblBNo.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBNo.Location = new System.Drawing.Point(207, 9);
            this.lblBNo.Name = "lblBNo";
            this.lblBNo.Size = new System.Drawing.Size(69, 17);
            this.lblBNo.TabIndex = 29;
            this.lblBNo.Text = "Batch No.";
            // 
            // txtBatchNo
            // 
            this.txtBatchNo.BackColor = System.Drawing.Color.White;
            this.txtBatchNo.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBatchNo.ForeColor = System.Drawing.Color.Blue;
            this.txtBatchNo.Location = new System.Drawing.Point(277, 5);
            this.txtBatchNo.Name = "txtBatchNo";
            this.txtBatchNo.Size = new System.Drawing.Size(53, 25);
            this.txtBatchNo.TabIndex = 28;
            this.txtBatchNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblBatch
            // 
            this.lblBatch.AutoSize = true;
            this.lblBatch.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBatch.Location = new System.Drawing.Point(3, 9);
            this.lblBatch.Name = "lblBatch";
            this.lblBatch.Size = new System.Drawing.Size(83, 17);
            this.lblBatch.TabIndex = 27;
            this.lblBatch.Text = "Batch Name";
            // 
            // txtBatchName
            // 
            this.txtBatchName.BackColor = System.Drawing.Color.White;
            this.txtBatchName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBatchName.ForeColor = System.Drawing.Color.Blue;
            this.txtBatchName.Location = new System.Drawing.Point(89, 5);
            this.txtBatchName.Name = "txtBatchName";
            this.txtBatchName.Size = new System.Drawing.Size(109, 25);
            this.txtBatchName.TabIndex = 26;
            this.txtBatchName.Text = "rxnfile.80000";
            // 
            // btnFind_Replace
            // 
            this.btnFind_Replace.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFind_Replace.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFind_Replace.Location = new System.Drawing.Point(725, 3);
            this.btnFind_Replace.Name = "btnFind_Replace";
            this.btnFind_Replace.Size = new System.Drawing.Size(126, 30);
            this.btnFind_Replace.TabIndex = 25;
            this.btnFind_Replace.Text = "Find and Replace";
            this.btnFind_Replace.UseVisualStyleBackColor = true;
            this.btnFind_Replace.Click += new System.EventHandler(this.btnFind_Replace_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdate.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.Location = new System.Drawing.Point(857, 3);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(115, 30);
            this.btnUpdate.TabIndex = 24;
            this.btnUpdate.Text = "Update Changes";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // cmbTANs
            // 
            this.cmbTANs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTANs.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTANs.FormattingEnabled = true;
            this.cmbTANs.Location = new System.Drawing.Point(503, 5);
            this.cmbTANs.Name = "cmbTANs";
            this.cmbTANs.Size = new System.Drawing.Size(95, 25);
            this.cmbTANs.TabIndex = 23;
            this.cmbTANs.Visible = false;
            // 
            // txtTAN
            // 
            this.txtTAN.BackColor = System.Drawing.Color.White;
            this.txtTAN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTAN.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTAN.ForeColor = System.Drawing.Color.Blue;
            this.txtTAN.Location = new System.Drawing.Point(505, 5);
            this.txtTAN.Name = "txtTAN";
            this.txtTAN.Size = new System.Drawing.Size(93, 25);
            this.txtTAN.TabIndex = 16;
            this.txtTAN.Visible = false;
            // 
            // btnGet
            // 
            this.btnGet.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGet.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGet.Location = new System.Drawing.Point(618, 3);
            this.btnGet.Name = "btnGet";
            this.btnGet.Size = new System.Drawing.Size(58, 29);
            this.btnGet.TabIndex = 19;
            this.btnGet.Text = "Get";
            this.btnGet.UseVisualStyleBackColor = true;
            this.btnGet.Visible = false;
            this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
            // 
            // lblTAN
            // 
            this.lblTAN.AutoSize = true;
            this.lblTAN.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTAN.Location = new System.Drawing.Point(462, 9);
            this.lblTAN.Name = "lblTAN";
            this.lblTAN.Size = new System.Drawing.Size(38, 17);
            this.lblTAN.TabIndex = 20;
            this.lblTAN.Text = "TAN";
            this.lblTAN.Visible = false;
            // 
            // pnlXML
            // 
            this.pnlXML.BackColor = System.Drawing.Color.White;
            this.pnlXML.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlXML.Controls.Add(this.txtXmlFile);
            this.pnlXML.Controls.Add(this.lblBrowseXml);
            this.pnlXML.Controls.Add(this.btnSave_Exl);
            this.pnlXML.Controls.Add(this.btnBrowseXML);
            this.pnlXML.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlXML.Location = new System.Drawing.Point(0, 0);
            this.pnlXML.Name = "pnlXML";
            this.pnlXML.Size = new System.Drawing.Size(977, 36);
            this.pnlXML.TabIndex = 24;
            // 
            // txtXmlFile
            // 
            this.txtXmlFile.BackColor = System.Drawing.Color.White;
            this.txtXmlFile.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtXmlFile.Location = new System.Drawing.Point(89, 4);
            this.txtXmlFile.Name = "txtXmlFile";
            this.txtXmlFile.ReadOnly = true;
            this.txtXmlFile.Size = new System.Drawing.Size(697, 25);
            this.txtXmlFile.TabIndex = 1;
            // 
            // lblBrowseXml
            // 
            this.lblBrowseXml.AutoSize = true;
            this.lblBrowseXml.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBrowseXml.Location = new System.Drawing.Point(2, 8);
            this.lblBrowseXml.Name = "lblBrowseXml";
            this.lblBrowseXml.Size = new System.Drawing.Size(90, 17);
            this.lblBrowseXml.TabIndex = 0;
            this.lblBrowseXml.Text = "Browse XML";
            // 
            // btnSave_Exl
            // 
            this.btnSave_Exl.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave_Exl.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave_Exl.Location = new System.Drawing.Point(856, 2);
            this.btnSave_Exl.Name = "btnSave_Exl";
            this.btnSave_Exl.Size = new System.Drawing.Size(115, 30);
            this.btnSave_Exl.TabIndex = 3;
            this.btnSave_Exl.Text = "Save in Excel";
            this.btnSave_Exl.UseVisualStyleBackColor = true;
            this.btnSave_Exl.Click += new System.EventHandler(this.btnSave_Exl_Click);
            // 
            // btnBrowseXML
            // 
            this.btnBrowseXML.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBrowseXML.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowseXML.Location = new System.Drawing.Point(792, 2);
            this.btnBrowseXML.Name = "btnBrowseXML";
            this.btnBrowseXML.Size = new System.Drawing.Size(58, 30);
            this.btnBrowseXML.TabIndex = 2;
            this.btnBrowseXML.Text = "...";
            this.btnBrowseXML.UseVisualStyleBackColor = true;
            this.btnBrowseXML.Click += new System.EventHandler(this.btnBrowseXML_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // dataGridView_AYT_Manager1
            // 
            this.dataGridView_AYT_Manager1.DataGridView = this.dgRSN_DB;
            this.dataGridView_AYT_Manager1.RapidSpellAsYouType = this.rapidSpellAsYouType1;
            // 
            // rapidSpellAsYouType1
            // 
            this.rapidSpellAsYouType1.AddMenuText = "Add";
            this.rapidSpellAsYouType1.AllowAnyCase = false;
            this.rapidSpellAsYouType1.AllowMixedCase = false;
            this.rapidSpellAsYouType1.AutoCorrectEnabled = true;
            this.rapidSpellAsYouType1.CheckAsYouType = true;
            this.rapidSpellAsYouType1.CheckCompoundWords = false;
            this.rapidSpellAsYouType1.CheckDisabledTextBoxes = false;
            this.rapidSpellAsYouType1.CheckReadOnlyTextBoxes = false;
            this.rapidSpellAsYouType1.ConsiderationRange = 500;
            this.rapidSpellAsYouType1.ContextMenuStripEnabled = true;
            this.rapidSpellAsYouType1.DictFilePath = "";
            this.rapidSpellAsYouType1.FindCapitalizedSuggestions = false;
            this.rapidSpellAsYouType1.GUILanguage = Keyoti.RapidSpell.LanguageType.ENGLISH;
            this.rapidSpellAsYouType1.IgnoreAllMenuText = "Ignore All";
            this.rapidSpellAsYouType1.IgnoreCapitalizedWords = false;
            this.rapidSpellAsYouType1.IgnoreURLsAndEmailAddresses = true;
            this.rapidSpellAsYouType1.IgnoreWordsWithDigits = true;
            this.rapidSpellAsYouType1.IgnoreXML = false;
            this.rapidSpellAsYouType1.IncludeUserDictionaryInSuggestions = true;
            this.rapidSpellAsYouType1.LanguageParser = Keyoti.RapidSpell.LanguageType.ENGLISH;
            this.rapidSpellAsYouType1.LookIntoHyphenatedText = true;
            this.rapidSpellAsYouType1.OptionsEnabled = true;
            this.rapidSpellAsYouType1.OptionsFileName = "RapidSpell_UserSettings.xml";
            this.rapidSpellAsYouType1.OptionsStorageLocation = Keyoti.RapidSpell.Options.UserOptions.StorageType.IsolatedStorage;
            this.rapidSpellAsYouType1.RemoveDuplicateWordText = "Remove duplicate word";
            this.rapidSpellAsYouType1.SeparateHyphenWords = false;
            this.rapidSpellAsYouType1.ShowAddMenuOption = true;
            this.rapidSpellAsYouType1.ShowCutCopyPasteMenuOnTextBoxBase = true;
            this.rapidSpellAsYouType1.ShowSuggestionsContextMenu = true;
            this.rapidSpellAsYouType1.ShowSuggestionsWhenTextIsSelected = false;
            this.rapidSpellAsYouType1.SuggestionsMethod = Keyoti.RapidSpell.SuggestionsMethodType.HashingSuggestions;
            this.rapidSpellAsYouType1.SuggestSplitWords = true;
            this.rapidSpellAsYouType1.TextBoxBase = null;
            this.rapidSpellAsYouType1.TextComponent = null;
            this.rapidSpellAsYouType1.UnderlineColor = System.Drawing.Color.Red;
            this.rapidSpellAsYouType1.UnderlineStyle = Keyoti.RapidSpell.UnderlineStyle.Wavy;
            this.rapidSpellAsYouType1.UpdateAllTextBoxes = true;
            this.rapidSpellAsYouType1.UserDictionaryFile = "";
            this.rapidSpellAsYouType1.V2Parser = true;
            this.rapidSpellAsYouType1.WarnDuplicates = true;
            // 
            // frmExtractRSN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(981, 578);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmExtractRSN";
            this.Text = "Extract RSN";
            this.Load += new System.EventHandler(this.frmExtractRSN_Load);
            this.pnlMain.ResumeLayout(false);
            this.pnlGrid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgRSN_DB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgRSN_Xml)).EndInit();
            this.pnlBrowse.ResumeLayout(false);
            this.pnlTANs.ResumeLayout(false);
            this.pnlTANs.PerformLayout();
            this.pnlXML.ResumeLayout(false);
            this.pnlXML.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlBrowse;
        private System.Windows.Forms.Button btnBrowseXML;
        private System.Windows.Forms.TextBox txtXmlFile;
        private System.Windows.Forms.Label lblBrowseXml;
        private System.Windows.Forms.Panel pnlGrid;
        private System.Windows.Forms.DataGridView dgRSN_Xml;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnSave_Exl;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.TextBox txtTAN;
        private System.Windows.Forms.Label lblTAN;
        private System.Windows.Forms.Button btnGet;
        private System.Windows.Forms.Panel pnlTANs;
        private System.Windows.Forms.Panel pnlXML;
        private System.Windows.Forms.ComboBox cmbTANs;
        private Keyoti.RapidSpell.Grid.DataGridView_AYT_Manager dataGridView_AYT_Manager1;
        private Keyoti.RapidSpell.RapidSpellAsYouType rapidSpellAsYouType1;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnFind_Replace;
        public System.Windows.Forms.DataGridView dgRSN_DB;
        private System.Windows.Forms.Label lblBatch;
        private System.Windows.Forms.TextBox txtBatchName;
        private System.Windows.Forms.Label lblBNo;
        private System.Windows.Forms.TextBox txtBatchNo;
        private System.Windows.Forms.Button btnGetBatchRSN;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRSNID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTAN;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colProdNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxn_Seq;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStage;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCVT;
        private Keyoti.RapidSpell.Grid.AYTDataGridViewTextBoxColumn colFreeText;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRsnType;
    }
}