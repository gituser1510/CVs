﻿namespace IndxReactNarr
{
    partial class frmRxnReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblCasReactant = new System.Windows.Forms.Label();
            this.lblTan = new System.Windows.Forms.Label();
            this.txtTan = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dgReportView = new System.Windows.Forms.DataGridView();
            this.lblReactionsct = new System.Windows.Forms.Label();
            this.lbltsct = new System.Windows.Forms.Label();
            this.lblppct = new System.Windows.Forms.Label();
            this.lblnppct = new System.Windows.Forms.Label();
            this.lblProduct = new System.Windows.Forms.Label();
            this.lblReactants = new System.Windows.Forms.Label();
            this.lblSolvent = new System.Windows.Forms.Label();
            this.lblCatalyst = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblTemp = new System.Windows.Forms.Label();
            this.lblPressure = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblAgent = new System.Windows.Forms.Label();
            this.lblrtct = new System.Windows.Forms.Label();
            this.lblstct = new System.Windows.Forms.Label();
            this.lblprodCnt = new System.Windows.Forms.Label();
            this.lblreactCnt = new System.Windows.Forms.Label();
            this.lblcatCnt = new System.Windows.Forms.Label();
            this.lblsolCnt = new System.Windows.Forms.Label();
            this.lblAgCnt = new System.Windows.Forms.Label();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.pnlLabels = new System.Windows.Forms.Panel();
            this.cmbTANs = new System.Windows.Forms.ComboBox();
            this.txtComments = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblAnalystID = new System.Windows.Forms.Label();
            this.lblAnlst = new System.Windows.Forms.Label();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.lblRxn8000 = new System.Windows.Forms.Label();
            this.lblDist8000 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblPhCnt = new System.Windows.Forms.Label();
            this.lblTempCnt = new System.Windows.Forms.Label();
            this.lblPrCnt = new System.Windows.Forms.Label();
            this.lblTimeCnt = new System.Windows.Forms.Label();
            this.lblBatchName = new System.Windows.Forms.Label();
            this.lblBatch = new System.Windows.Forms.Label();
            this.lblBatchNo = new System.Windows.Forms.Label();
            this.lblBNo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgReportView)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.pnlLabels.SuspendLayout();
            this.pnlBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblCasReactant
            // 
            this.lblCasReactant.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCasReactant.AutoSize = true;
            this.lblCasReactant.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCasReactant.Location = new System.Drawing.Point(405, 1);
            this.lblCasReactant.Name = "lblCasReactant";
            this.lblCasReactant.Size = new System.Drawing.Size(144, 21);
            this.lblCasReactant.TabIndex = 0;
            this.lblCasReactant.Text = "TAN Report Data";
            this.lblCasReactant.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTan
            // 
            this.lblTan.AutoSize = true;
            this.lblTan.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTan.ForeColor = System.Drawing.Color.Black;
            this.lblTan.Location = new System.Drawing.Point(3, 8);
            this.lblTan.Name = "lblTan";
            this.lblTan.Size = new System.Drawing.Size(40, 17);
            this.lblTan.TabIndex = 1;
            this.lblTan.Text = "TAN";
            // 
            // txtTan
            // 
            this.txtTan.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTan.Location = new System.Drawing.Point(46, 4);
            this.txtTan.Name = "txtTan";
            this.txtTan.Size = new System.Drawing.Size(86, 25);
            this.txtTan.TabIndex = 2;
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(146, 2);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 28);
            this.btnSearch.TabIndex = 3;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dgReportView
            // 
            this.dgReportView.AllowUserToAddRows = false;
            this.dgReportView.AllowUserToDeleteRows = false;
            this.dgReportView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgReportView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgReportView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgReportView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgReportView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgReportView.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgReportView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgReportView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgReportView.Location = new System.Drawing.Point(0, 96);
            this.dgReportView.Name = "dgReportView";
            this.dgReportView.ReadOnly = true;
            this.dgReportView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgReportView.Size = new System.Drawing.Size(955, 405);
            this.dgReportView.TabIndex = 47;
            // 
            // lblReactionsct
            // 
            this.lblReactionsct.AutoSize = true;
            this.lblReactionsct.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReactionsct.ForeColor = System.Drawing.Color.Black;
            this.lblReactionsct.Location = new System.Drawing.Point(14, 4);
            this.lblReactionsct.Name = "lblReactionsct";
            this.lblReactionsct.Size = new System.Drawing.Size(107, 17);
            this.lblReactionsct.TabIndex = 48;
            this.lblReactionsct.Text = "Total Reactions :";
            // 
            // lbltsct
            // 
            this.lbltsct.AutoSize = true;
            this.lbltsct.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltsct.ForeColor = System.Drawing.Color.Black;
            this.lbltsct.Location = new System.Drawing.Point(183, 4);
            this.lbltsct.Name = "lbltsct";
            this.lbltsct.Size = new System.Drawing.Size(88, 17);
            this.lbltsct.TabIndex = 49;
            this.lbltsct.Text = "Total Stages :";
            // 
            // lblppct
            // 
            this.lblppct.AutoSize = true;
            this.lblppct.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblppct.ForeColor = System.Drawing.Color.Black;
            this.lblppct.Location = new System.Drawing.Point(15, 29);
            this.lblppct.Name = "lblppct";
            this.lblppct.Size = new System.Drawing.Size(116, 17);
            this.lblppct.TabIndex = 50;
            this.lblppct.Text = "Participants Count";
            // 
            // lblnppct
            // 
            this.lblnppct.AutoSize = true;
            this.lblnppct.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnppct.ForeColor = System.Drawing.Color.Black;
            this.lblnppct.Location = new System.Drawing.Point(15, 56);
            this.lblnppct.Name = "lblnppct";
            this.lblnppct.Size = new System.Drawing.Size(160, 17);
            this.lblnppct.TabIndex = 51;
            this.lblnppct.Text = "Note/s-Participants Count";
            // 
            // lblProduct
            // 
            this.lblProduct.AutoSize = true;
            this.lblProduct.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduct.Location = new System.Drawing.Point(183, 29);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(65, 17);
            this.lblProduct.TabIndex = 52;
            this.lblProduct.Text = "Product : ";
            this.lblProduct.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblReactants
            // 
            this.lblReactants.AutoSize = true;
            this.lblReactants.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReactants.Location = new System.Drawing.Point(331, 31);
            this.lblReactants.Name = "lblReactants";
            this.lblReactants.Size = new System.Drawing.Size(78, 17);
            this.lblReactants.TabIndex = 53;
            this.lblReactants.Text = "Reactants : ";
            this.lblReactants.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSolvent
            // 
            this.lblSolvent.AutoSize = true;
            this.lblSolvent.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSolvent.Location = new System.Drawing.Point(645, 28);
            this.lblSolvent.Name = "lblSolvent";
            this.lblSolvent.Size = new System.Drawing.Size(62, 17);
            this.lblSolvent.TabIndex = 55;
            this.lblSolvent.Text = "Solvent : ";
            this.lblSolvent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCatalyst
            // 
            this.lblCatalyst.AutoSize = true;
            this.lblCatalyst.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCatalyst.Location = new System.Drawing.Point(485, 29);
            this.lblCatalyst.Name = "lblCatalyst";
            this.lblCatalyst.Size = new System.Drawing.Size(67, 17);
            this.lblCatalyst.TabIndex = 54;
            this.lblCatalyst.Text = "Catalyst : ";
            this.lblCatalyst.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(645, 54);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 17);
            this.label9.TabIndex = 59;
            this.label9.Text = "PH :";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTemp
            // 
            this.lblTemp.AutoSize = true;
            this.lblTemp.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTemp.Location = new System.Drawing.Point(485, 54);
            this.lblTemp.Name = "lblTemp";
            this.lblTemp.Size = new System.Drawing.Size(49, 17);
            this.lblTemp.TabIndex = 58;
            this.lblTemp.Text = "Temp :";
            this.lblTemp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPressure
            // 
            this.lblPressure.AutoSize = true;
            this.lblPressure.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPressure.Location = new System.Drawing.Point(331, 55);
            this.lblPressure.Name = "lblPressure";
            this.lblPressure.Size = new System.Drawing.Size(67, 17);
            this.lblPressure.TabIndex = 57;
            this.lblPressure.Text = "Pressure :";
            this.lblPressure.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.Location = new System.Drawing.Point(183, 55);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(45, 17);
            this.lblTime.TabIndex = 56;
            this.lblTime.Text = "Time :";
            this.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAgent
            // 
            this.lblAgent.AutoSize = true;
            this.lblAgent.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAgent.Location = new System.Drawing.Point(788, 28);
            this.lblAgent.Name = "lblAgent";
            this.lblAgent.Size = new System.Drawing.Size(55, 17);
            this.lblAgent.TabIndex = 60;
            this.lblAgent.Text = "Agent : ";
            this.lblAgent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblrtct
            // 
            this.lblrtct.AutoSize = true;
            this.lblrtct.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrtct.ForeColor = System.Drawing.Color.Blue;
            this.lblrtct.Location = new System.Drawing.Point(138, 5);
            this.lblrtct.Name = "lblrtct";
            this.lblrtct.Size = new System.Drawing.Size(15, 17);
            this.lblrtct.TabIndex = 61;
            this.lblrtct.Tag = "";
            this.lblrtct.Text = "0";
            // 
            // lblstct
            // 
            this.lblstct.AutoSize = true;
            this.lblstct.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstct.ForeColor = System.Drawing.Color.Blue;
            this.lblstct.Location = new System.Drawing.Point(276, 4);
            this.lblstct.Name = "lblstct";
            this.lblstct.Size = new System.Drawing.Size(15, 17);
            this.lblstct.TabIndex = 62;
            this.lblstct.Text = "0";
            // 
            // lblprodCnt
            // 
            this.lblprodCnt.AutoSize = true;
            this.lblprodCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprodCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblprodCnt.Location = new System.Drawing.Point(260, 30);
            this.lblprodCnt.Name = "lblprodCnt";
            this.lblprodCnt.Size = new System.Drawing.Size(15, 17);
            this.lblprodCnt.TabIndex = 63;
            this.lblprodCnt.Text = "0";
            // 
            // lblreactCnt
            // 
            this.lblreactCnt.AutoSize = true;
            this.lblreactCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblreactCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblreactCnt.Location = new System.Drawing.Point(413, 31);
            this.lblreactCnt.Name = "lblreactCnt";
            this.lblreactCnt.Size = new System.Drawing.Size(15, 17);
            this.lblreactCnt.TabIndex = 64;
            this.lblreactCnt.Text = "0";
            // 
            // lblcatCnt
            // 
            this.lblcatCnt.AutoSize = true;
            this.lblcatCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcatCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblcatCnt.Location = new System.Drawing.Point(567, 29);
            this.lblcatCnt.Name = "lblcatCnt";
            this.lblcatCnt.Size = new System.Drawing.Size(15, 17);
            this.lblcatCnt.TabIndex = 65;
            this.lblcatCnt.Text = "0";
            // 
            // lblsolCnt
            // 
            this.lblsolCnt.AutoSize = true;
            this.lblsolCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsolCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblsolCnt.Location = new System.Drawing.Point(720, 28);
            this.lblsolCnt.Name = "lblsolCnt";
            this.lblsolCnt.Size = new System.Drawing.Size(15, 17);
            this.lblsolCnt.TabIndex = 66;
            this.lblsolCnt.Text = "0";
            // 
            // lblAgCnt
            // 
            this.lblAgCnt.AutoSize = true;
            this.lblAgCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAgCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblAgCnt.Location = new System.Drawing.Point(853, 28);
            this.lblAgCnt.Name = "lblAgCnt";
            this.lblAgCnt.Size = new System.Drawing.Size(15, 17);
            this.lblAgCnt.TabIndex = 67;
            this.lblAgCnt.Text = "0";
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.pnlTop.Controls.Add(this.pnlLabels);
            this.pnlTop.Controls.Add(this.lblCasReactant);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(955, 96);
            this.pnlTop.TabIndex = 68;
            // 
            // pnlLabels
            // 
            this.pnlLabels.BackColor = System.Drawing.Color.White;
            this.pnlLabels.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlLabels.Controls.Add(this.lblBatchNo);
            this.pnlLabels.Controls.Add(this.lblBNo);
            this.pnlLabels.Controls.Add(this.lblBatchName);
            this.pnlLabels.Controls.Add(this.lblBatch);
            this.pnlLabels.Controls.Add(this.cmbTANs);
            this.pnlLabels.Controls.Add(this.txtComments);
            this.pnlLabels.Controls.Add(this.label3);
            this.pnlLabels.Controls.Add(this.lblAnalystID);
            this.pnlLabels.Controls.Add(this.lblAnlst);
            this.pnlLabels.Controls.Add(this.lblTan);
            this.pnlLabels.Controls.Add(this.btnSearch);
            this.pnlLabels.Controls.Add(this.txtTan);
            this.pnlLabels.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlLabels.Location = new System.Drawing.Point(0, 22);
            this.pnlLabels.Name = "pnlLabels";
            this.pnlLabels.Size = new System.Drawing.Size(955, 74);
            this.pnlLabels.TabIndex = 4;
            // 
            // cmbTANs
            // 
            this.cmbTANs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTANs.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTANs.FormattingEnabled = true;
            this.cmbTANs.Location = new System.Drawing.Point(45, 4);
            this.cmbTANs.Name = "cmbTANs";
            this.cmbTANs.Size = new System.Drawing.Size(95, 25);
            this.cmbTANs.TabIndex = 8;
            this.cmbTANs.Visible = false;
            // 
            // txtComments
            // 
            this.txtComments.AccessibleDescription = " ";
            this.txtComments.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtComments.BackColor = System.Drawing.Color.White;
            this.txtComments.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComments.ForeColor = System.Drawing.Color.Blue;
            this.txtComments.Location = new System.Drawing.Point(92, 33);
            this.txtComments.Multiline = true;
            this.txtComments.Name = "txtComments";
            this.txtComments.ReadOnly = true;
            this.txtComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtComments.Size = new System.Drawing.Size(858, 36);
            this.txtComments.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(7, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Comments";
            // 
            // lblAnalystID
            // 
            this.lblAnalystID.AutoSize = true;
            this.lblAnalystID.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnalystID.ForeColor = System.Drawing.Color.Blue;
            this.lblAnalystID.Location = new System.Drawing.Point(316, 6);
            this.lblAnalystID.Name = "lblAnalystID";
            this.lblAnalystID.Size = new System.Drawing.Size(15, 17);
            this.lblAnalystID.TabIndex = 5;
            this.lblAnalystID.Text = "0";
            // 
            // lblAnlst
            // 
            this.lblAnlst.AutoSize = true;
            this.lblAnlst.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnlst.ForeColor = System.Drawing.Color.Black;
            this.lblAnlst.Location = new System.Drawing.Point(230, 6);
            this.lblAnlst.Name = "lblAnlst";
            this.lblAnlst.Size = new System.Drawing.Size(87, 17);
            this.lblAnlst.TabIndex = 4;
            this.lblAnlst.Text = "Analyst ID: ";
            // 
            // pnlBottom
            // 
            this.pnlBottom.Controls.Add(this.lblRxn8000);
            this.pnlBottom.Controls.Add(this.lblDist8000);
            this.pnlBottom.Controls.Add(this.label2);
            this.pnlBottom.Controls.Add(this.label1);
            this.pnlBottom.Controls.Add(this.lblPhCnt);
            this.pnlBottom.Controls.Add(this.lblTempCnt);
            this.pnlBottom.Controls.Add(this.lblPrCnt);
            this.pnlBottom.Controls.Add(this.lblTimeCnt);
            this.pnlBottom.Controls.Add(this.lblReactionsct);
            this.pnlBottom.Controls.Add(this.lbltsct);
            this.pnlBottom.Controls.Add(this.lblAgCnt);
            this.pnlBottom.Controls.Add(this.lblppct);
            this.pnlBottom.Controls.Add(this.lblsolCnt);
            this.pnlBottom.Controls.Add(this.lblnppct);
            this.pnlBottom.Controls.Add(this.lblcatCnt);
            this.pnlBottom.Controls.Add(this.lblProduct);
            this.pnlBottom.Controls.Add(this.lblreactCnt);
            this.pnlBottom.Controls.Add(this.lblReactants);
            this.pnlBottom.Controls.Add(this.lblprodCnt);
            this.pnlBottom.Controls.Add(this.lblCatalyst);
            this.pnlBottom.Controls.Add(this.lblstct);
            this.pnlBottom.Controls.Add(this.lblSolvent);
            this.pnlBottom.Controls.Add(this.lblrtct);
            this.pnlBottom.Controls.Add(this.lblTime);
            this.pnlBottom.Controls.Add(this.lblAgent);
            this.pnlBottom.Controls.Add(this.lblPressure);
            this.pnlBottom.Controls.Add(this.label9);
            this.pnlBottom.Controls.Add(this.lblTemp);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlBottom.Location = new System.Drawing.Point(0, 501);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(955, 75);
            this.pnlBottom.TabIndex = 69;
            // 
            // lblRxn8000
            // 
            this.lblRxn8000.AutoSize = true;
            this.lblRxn8000.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxn8000.ForeColor = System.Drawing.Color.Blue;
            this.lblRxn8000.Location = new System.Drawing.Point(861, 5);
            this.lblRxn8000.Name = "lblRxn8000";
            this.lblRxn8000.Size = new System.Drawing.Size(15, 17);
            this.lblRxn8000.TabIndex = 75;
            this.lblRxn8000.Text = "0";
            // 
            // lblDist8000
            // 
            this.lblDist8000.AutoSize = true;
            this.lblDist8000.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDist8000.ForeColor = System.Drawing.Color.Blue;
            this.lblDist8000.Location = new System.Drawing.Point(507, 4);
            this.lblDist8000.Name = "lblDist8000";
            this.lblDist8000.Size = new System.Drawing.Size(15, 17);
            this.lblDist8000.TabIndex = 74;
            this.lblDist8000.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(643, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(212, 17);
            this.label2.TabIndex = 73;
            this.label2.Text = "No.of Reactions with 8000 Series :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(331, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 17);
            this.label1.TabIndex = 72;
            this.label1.Text = "No.of Distinct 8000 Series :";
            // 
            // lblPhCnt
            // 
            this.lblPhCnt.AutoSize = true;
            this.lblPhCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblPhCnt.Location = new System.Drawing.Point(720, 54);
            this.lblPhCnt.Name = "lblPhCnt";
            this.lblPhCnt.Size = new System.Drawing.Size(15, 17);
            this.lblPhCnt.TabIndex = 71;
            this.lblPhCnt.Text = "0";
            this.lblPhCnt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTempCnt
            // 
            this.lblTempCnt.AutoSize = true;
            this.lblTempCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTempCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblTempCnt.Location = new System.Drawing.Point(567, 55);
            this.lblTempCnt.Name = "lblTempCnt";
            this.lblTempCnt.Size = new System.Drawing.Size(15, 17);
            this.lblTempCnt.TabIndex = 70;
            this.lblTempCnt.Text = "0";
            this.lblTempCnt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPrCnt
            // 
            this.lblPrCnt.AutoSize = true;
            this.lblPrCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblPrCnt.Location = new System.Drawing.Point(413, 55);
            this.lblPrCnt.Name = "lblPrCnt";
            this.lblPrCnt.Size = new System.Drawing.Size(15, 17);
            this.lblPrCnt.TabIndex = 69;
            this.lblPrCnt.Text = "0";
            this.lblPrCnt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTimeCnt
            // 
            this.lblTimeCnt.AutoSize = true;
            this.lblTimeCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTimeCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblTimeCnt.Location = new System.Drawing.Point(260, 54);
            this.lblTimeCnt.Name = "lblTimeCnt";
            this.lblTimeCnt.Size = new System.Drawing.Size(15, 17);
            this.lblTimeCnt.TabIndex = 68;
            this.lblTimeCnt.Text = "0";
            this.lblTimeCnt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBatchName
            // 
            this.lblBatchName.AutoSize = true;
            this.lblBatchName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBatchName.ForeColor = System.Drawing.Color.Blue;
            this.lblBatchName.Location = new System.Drawing.Point(491, 7);
            this.lblBatchName.Name = "lblBatchName";
            this.lblBatchName.Size = new System.Drawing.Size(15, 17);
            this.lblBatchName.TabIndex = 10;
            this.lblBatchName.Text = "0";
            // 
            // lblBatch
            // 
            this.lblBatch.AutoSize = true;
            this.lblBatch.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBatch.ForeColor = System.Drawing.Color.Black;
            this.lblBatch.Location = new System.Drawing.Point(395, 6);
            this.lblBatch.Name = "lblBatch";
            this.lblBatch.Size = new System.Drawing.Size(97, 17);
            this.lblBatch.TabIndex = 9;
            this.lblBatch.Text = "Batch Name: ";
            // 
            // lblBatchNo
            // 
            this.lblBatchNo.AutoSize = true;
            this.lblBatchNo.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBatchNo.ForeColor = System.Drawing.Color.Blue;
            this.lblBatchNo.Location = new System.Drawing.Point(718, 7);
            this.lblBatchNo.Name = "lblBatchNo";
            this.lblBatchNo.Size = new System.Drawing.Size(15, 17);
            this.lblBatchNo.TabIndex = 12;
            this.lblBatchNo.Text = "0";
            // 
            // lblBNo
            // 
            this.lblBNo.AutoSize = true;
            this.lblBNo.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBNo.ForeColor = System.Drawing.Color.Black;
            this.lblBNo.Location = new System.Drawing.Point(643, 6);
            this.lblBNo.Name = "lblBNo";
            this.lblBNo.Size = new System.Drawing.Size(78, 17);
            this.lblBNo.TabIndex = 11;
            this.lblBNo.Text = "Batch No: ";
            // 
            // frmRxnReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(955, 576);
            this.Controls.Add(this.dgReportView);
            this.Controls.Add(this.pnlBottom);
            this.Controls.Add(this.pnlTop);
            this.Name = "frmRxnReport";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Report View";
            this.Load += new System.EventHandler(this.frmRxnReport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgReportView)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlLabels.ResumeLayout(false);
            this.pnlLabels.PerformLayout();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblCasReactant;
        private System.Windows.Forms.Label lblTan;
        private System.Windows.Forms.TextBox txtTan;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DataGridView dgReportView;
        private System.Windows.Forms.Label lblReactionsct;
        private System.Windows.Forms.Label lbltsct;
        private System.Windows.Forms.Label lblppct;
        private System.Windows.Forms.Label lblnppct;
        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.Label lblReactants;
        private System.Windows.Forms.Label lblSolvent;
        private System.Windows.Forms.Label lblCatalyst;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblTemp;
        private System.Windows.Forms.Label lblPressure;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Label lblAgent;
        private System.Windows.Forms.Label lblrtct;
        private System.Windows.Forms.Label lblstct;
        private System.Windows.Forms.Label lblprodCnt;
        private System.Windows.Forms.Label lblreactCnt;
        private System.Windows.Forms.Label lblcatCnt;
        private System.Windows.Forms.Label lblsolCnt;
        private System.Windows.Forms.Label lblAgCnt;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Label lblPhCnt;
        private System.Windows.Forms.Label lblTempCnt;
        private System.Windows.Forms.Label lblPrCnt;
        private System.Windows.Forms.Label lblTimeCnt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlLabels;
        private System.Windows.Forms.TextBox txtComments;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblAnalystID;
        private System.Windows.Forms.Label lblAnlst;
        private System.Windows.Forms.Label lblRxn8000;
        private System.Windows.Forms.Label lblDist8000;
        private System.Windows.Forms.ComboBox cmbTANs;
        private System.Windows.Forms.Label lblBatchName;
        private System.Windows.Forms.Label lblBatch;
        private System.Windows.Forms.Label lblBatchNo;
        private System.Windows.Forms.Label lblBNo;
    }
}