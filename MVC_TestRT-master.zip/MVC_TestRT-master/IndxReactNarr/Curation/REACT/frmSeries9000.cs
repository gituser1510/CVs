﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;

namespace IndxReactNarr
{
    public partial class frmSeries9000 : Form
    {
        public frmSeries9000()
        {
            InitializeComponent();
        }

        #region Property Procedures

        public DataTable DtOrgRef
        {
            get;
            set;
        }

        public string SrcGrid { get; set; }       

        public int Sel_9000 { get; set; }

        public int Sel_NrnReg { get; set; }

        public string Sel_Name { get; set; }

        #endregion

        private void frmSeries9000_Load(object sender, EventArgs e)
        {
            try
            {
                GetSer9000DataBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetSer9000DataBindToGrid()
        {
            try
            {
                if (Generic.GlobalVariables.Ser9000OrgRefData != null)
                {
                    if (Generic.GlobalVariables.Ser9000OrgRefData.Rows.Count > 0)
                    {
                        DataTable dtOrgRef = new DataTable();

                        DataTable dtTemp = Generic.GlobalVariables.Ser9000OrgRefData.Copy();
                        DataView dvTemp = dtTemp.DefaultView;
                        string strRowFiler = "";

                        if (SrcGrid.Trim().ToUpper() == "SOLVENT")
                        {
                            strRowFiler = @"NUM >= 9000 and NUM <> 9101 and NUM <> 9107 and NUM <> 9100 and NUM <> 9066
                                           and NUM <> 9059 and NUM <> 9559 and NUM <> 9109 and NUM <> 9266
                                           and NUM <> 9065 and NUM <> 9060 and NUM <> 9104 and NUM <> 9306
                                           and NUM <> 9075 and NUM <> 9212 and NUM <> 9213";
                        }
                        else
                        {
                            strRowFiler = "NUM >= 9000";
                        }

                        dvTemp.RowFilter = strRowFiler;
                        dvTemp.Sort = "NUM asc";
                        dtTemp = dvTemp.ToTable();

                        dtOrgRef = dtTemp.Clone();
                        dtOrgRef.Columns["NUM"].DataType = System.Type.GetType("System.String");
                        dtOrgRef.Columns["REG_NO"].DataType = System.Type.GetType("System.String");

                        #region Code Commented
                        //if (_srcgrid == "S" && 
                        //        (Convert.ToInt32(strcoll[i]) == 9101 || Convert.ToInt32(strcoll[i]) == 9266
                        //        || Convert.ToInt32(strcoll[i]) == 9100 || Convert.ToInt32(strcoll[i]) == 9065
                        //        || Convert.ToInt32(strcoll[i]) == 9066 || Convert.ToInt32(strcoll[i]) == 9060
                        //        || Convert.ToInt32(strcoll[i]) == 9059 || Convert.ToInt32(strcoll[i]) == 9104
                        //        || Convert.ToInt32(strcoll[i]) == 9559 || Convert.ToInt32(strcoll[i]) == 9306
                        //        || Convert.ToInt32(strcoll[i]) == 9109 || Convert.ToInt32(strcoll[i]) == 9075
                        //        || Convert.ToInt32(strcoll[i]) == 9266))
                        //    { 
                        #endregion

                        foreach (DataRow dr in dtTemp.Rows)
                        {
                            dtOrgRef.ImportRow(dr);
                        }

                        //Insert 0 at starting
                        DataRow dRow = dtOrgRef.NewRow();
                        dRow["NUM"] = 0;
                        dtOrgRef.Rows.InsertAt(dRow, 0);

                        DtOrgRef = dtOrgRef;

                        //Bind data to Ser9000 grid
                        BindDataToSer9000Grid(dtOrgRef);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindDataToSer9000Grid(DataTable ser9000tbl)
        {
            try
            {
                if (ser9000tbl != null)
                {
                    dgvOrgRef.AutoGenerateColumns = false;
                    dgvOrgRef.DataSource = ser9000tbl;

                    colNUM.DataPropertyName = "NUM";
                    colRegNo.DataPropertyName = "REG_NO";
                    colOrgRefName.DataPropertyName = "ORGREF_NAME";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetFilterCondition()
        {
            string strFilerCond = "";
            try
            {
                if (txtNrnNum.Text.Trim() != "")
                {
                    strFilerCond = "NUM like '" + txtNrnNum.Text.Trim() + "%'";
                }
                if (txtNrnReg.Text.Trim() != "")
                {
                    if (strFilerCond.Trim() == "")
                    {
                        strFilerCond = "REG_NO like '" + txtNrnReg.Text.Trim() + "%'";
                    }
                    else
                    {
                        strFilerCond = strFilerCond + " and REG_NO like '" + txtNrnReg.Text.Trim() + "%'";
                    }
                }
                if (txtName.Text.Trim() != "")
                {
                    if (strFilerCond.Trim() == "")
                    {
                        strFilerCond = "ORGREF_NAME like '" + txtName.Text.Trim() + "%'";
                    }
                    else
                    {
                        strFilerCond = strFilerCond + " and ORGREF_NAME like '" + txtName.Text.Trim() + "%'";
                    }
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strFilerCond;
        }

        private void GetFilteredDataBindToGrid()
        {
            try
            {
                string strFiltCond = GetFilterCondition();
                if (strFiltCond.Trim() != "")
                {
                    DataView dtView = new DataView(DtOrgRef);
                    dtView.RowFilter = strFiltCond;
                    DataTable dtGridData = dtView.ToTable();

                    //Bind data to grid
                    BindDataToSer9000Grid(dtGridData);
                }
                else
                {
                    //Bind data to grid
                    BindDataToSer9000Grid(DtOrgRef);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtNrnNum_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilteredDataBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtNrnReg_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilteredDataBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgOrgRef_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvOrgRef.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvOrgRef.Font);

                if (dgvOrgRef.RowHeadersWidth < (int)(size.Width + 20)) dgvOrgRef.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilteredDataBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgOrgRef_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex >= 0 && e.RowIndex >= 0)
                {
                    if (!string.IsNullOrEmpty(dgvOrgRef.Rows[e.RowIndex].Cells["colNUM"].Value.ToString())) 
                    {
                        Sel_9000 = Convert.ToInt32(dgvOrgRef.Rows[e.RowIndex].Cells["colNUM"].Value.ToString());
                    }
                    if (!string.IsNullOrEmpty(dgvOrgRef.Rows[e.RowIndex].Cells["colRegNo"].Value.ToString()))
                    {
                        Sel_NrnReg = Convert.ToInt32(dgvOrgRef.Rows[e.RowIndex].Cells["colRegNo"].Value.ToString());
                    }
                    if (!string.IsNullOrEmpty(dgvOrgRef.Rows[e.RowIndex].Cells["colOrgRefName"].Value.ToString())) 
                    {
                        Sel_Name = dgvOrgRef.Rows[e.RowIndex].Cells["colOrgRefName"].Value.ToString();
                    }
                    DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
