﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;


namespace IndxReactNarr
{
    public partial class frmSeries8500 : Form
    {
        public frmSeries8500()
        {
            InitializeComponent();
        }

        #region Property Procedures

        public DataTable Ser8500Tbl
        { get; set; }       

        public string TANID
        {
            get;
            set;
        }       

        public int Sel_8500 { get; set; }

        public int Sel_NrnReg { get; set; }

        public string Sel_Name { get; set; }

        #endregion

        private void frmSeries8500_Load(object sender, EventArgs e)
        {
            try
            {
                GetSeries8500DataBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetSeries8500DataBindToGrid()
        {
            try
            {
                if (GlobalVariables.TAN_Series8500Data != null)
                {
                    // if (TANID != "")
                    // {
                    //DataView dtView = GlobalVariables.TAN_Series8500Data.DefaultView;
                    //dtView.RowFilter = "tan = '" + TANID + "'";
                    //DataTable dtTemp = dtView.ToTable();

                    DataTable dtGridData = GlobalVariables.TAN_Series8500Data.Clone();
                    dtGridData.Columns["SERIES_8500"].DataType = System.Type.GetType("System.String");

                    foreach (DataRow dr in GlobalVariables.TAN_Series8500Data.Rows)
                    {
                        dtGridData.ImportRow(dr);
                    }

                    //Insert 0 at starting
                    DataRow dRow = dtGridData.NewRow();
                    dRow["SERIES_8500"] = 0;
                    dtGridData.Rows.InsertAt(dRow, 0);

                    Ser8500Tbl = dtGridData;

                    //Bind data to ser8500 grid
                    BindDataToSer8500Grid(dtGridData);
                    // }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindDataToSer8500Grid(DataTable _ser8500tbl)
        {
            try
            {
                if (_ser8500tbl != null)
                {
                    dgvSer8500.AutoGenerateColumns = false;
                    dgvSer8500.DataSource = _ser8500tbl;

                    dgvSer8500.Columns["Ser8500"].DataPropertyName = "SERIES_8500";
                    dgvSer8500.Columns["NrnReg"].DataPropertyName = "REG_NO";
                    dgvSer8500.Columns["NrnName"].DataPropertyName = "ORGREF_NAME";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtSer8500_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilteredDataBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetFilterCondition()
        {
            string strFilerCond = "";
            try
            {
                if (txtSer8500.Text.Trim() != "")
                {
                    strFilerCond = "ser8500 like '" + txtSer8500.Text.Trim() + "%'";
                }
                if (txtNrnReg.Text.Trim() != "")
                {
                    if (strFilerCond.Trim() == "")
                    {
                        strFilerCond = "nrnreg like '" + txtNrnReg.Text.Trim() + "%'";
                    }
                    else
                    {
                        strFilerCond = strFilerCond + " and nrnreg like '" + txtNrnReg.Text.Trim() + "%'";
                    }
                }
                if (txtName.Text.Trim() != "")
                {
                    if (strFilerCond.Trim() == "")
                    {
                        strFilerCond = "descriptor like '" + txtName.Text.Trim() + "%'";
                    }
                    else
                    {
                        strFilerCond = strFilerCond + " and descriptor like '" + txtName.Text.Trim() + "%'";
                    }
                }                            
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strFilerCond;
        }

        private void GetFilteredDataBindToGrid()
        {
            try
            {
                string strFiltCond = GetFilterCondition();
                if (strFiltCond.Trim() != "")
                {
                    DataView dtView = new DataView(Ser8500Tbl);
                    dtView.RowFilter = strFiltCond;
                    DataTable dtGridData = dtView.ToTable();

                    //Bind data to grid
                    BindDataToSer8500Grid(dtGridData);
                }
                else
                {
                    //Bind data to grid
                    BindDataToSer8500Grid(Ser8500Tbl);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvSer8500_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex >= 0 && e.RowIndex >= 0)
                {
                    if (dgvSer8500.Rows[e.RowIndex].Cells["Ser8500"].Value.ToString() != "")
                    {
                        Sel_8500 = Convert.ToInt32(dgvSer8500.Rows[e.RowIndex].Cells["Ser8500"].Value.ToString());
                    }
                    if (dgvSer8500.Rows[e.RowIndex].Cells["NrnReg"].Value.ToString() != "")
                    {
                        Sel_NrnReg = Convert.ToInt32(dgvSer8500.Rows[e.RowIndex].Cells["NrnReg"].Value.ToString());
                    }
                    if (dgvSer8500.Rows[e.RowIndex].Cells["NrnName"].Value.ToString() != "")
                    {
                        Sel_Name = dgvSer8500.Rows[e.RowIndex].Cells["NrnName"].Value.ToString();
                    }
                    DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvSer8500_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvSer8500.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvSer8500.Font);

                if (dgvSer8500.RowHeadersWidth < (int)(size.Width + 20)) dgvSer8500.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
