﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using System.Text.RegularExpressions;

namespace IndxReactNarr
{
    public partial class frmComments_New : Form
    {
        public frmComments_New()
        {
            InitializeComponent();
        }

        #region Property Procedures
        
        private bool _isquerytan = true;
        public bool IsQueryTAN
        {
            get
            {
                return _isquerytan;
            }
            set
            {
                _isquerytan = value;
            }
        }

        public string TANComments
        { get; set; }

        string[] saExcludedTerms = { "CAS consulted", "Author error", "Indexing error", "Other comment" };
        string[] saExclTermsAE_IE = { "NUM", "Page", " Line ", "Para", "Column", "Table", "Figure", "Schema", "Sheet", "Footnote" };
        char[] caSpecialChars = "!@#$%^&<>/~`:;".ToCharArray();

        public DataTable CommentsData
        { get; set; } 
        
        #endregion

        private void frmComments_New_Load(object sender, EventArgs e)
        {
            try
            {
                //Disable CAS comments               
                if (IsQueryTAN)
                {
                    txtCASComment.Enabled = true;
                    btnCASCmnts.Enabled = true;
                }
                else
                {
                    txtCASComment.Enabled = false;
                    btnCASCmnts.Enabled = false;
                }

                //Get Comments datatable from TAN comments 
                //CommentsData = GetCommentsTableFromTANComments(TANComments);
                
                //Bind comments to grid
                BindCommentsDataToGrid();                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindCommentsDataToGrid()
        {
            try
            {
                if (CommentsData != null)
                {
                    //Add Length column to Comments Data - New code on 19th Nov 2013
                    AddLengthColumnToCommentsData();

                    dgvComments.AutoGenerateColumns = false;
                    dgvComments.DataSource = CommentsData;

                    colTC_ID.DataPropertyName = "TC_ID"; 
                    colComments.DataPropertyName = "TAN_COMMENT";
                    colCommentsType.DataPropertyName = "COMMENT_TYPE";
                    colCommentsLength.DataPropertyName = "COMMENTSLENGTH";

                    //Calculate Comments Length
                    lblComLength.Text = GetCommentsLengthFromCommentsData().ToString();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void AddLengthColumnToCommentsData()
        {
            try
            {
                if (CommentsData != null)
                {
                    if (CommentsData.Rows.Count > 0)
                    {
                        //Add Length column to CommentsData
                        if (!CommentsData.Columns.Contains("COMMENTSLENGTH"))
                        {
                            CommentsData.Columns.Add("COMMENTSLENGTH", typeof(int));
                        }

                        for (int i = 0; i < CommentsData.Rows.Count; i++)
                        {
                            CommentsData.Rows[i]["COMMENTSLENGTH"] = CommentsData.Rows[i]["TAN_COMMENT"].ToString().Length;
                        }
                        CommentsData.AcceptChanges();
                    }
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private int GetCommentsLengthFromCommentsData()
        {
            int intLength = 0;
            try
            {
                if (CommentsData != null)
                {
                    if (CommentsData.Rows.Count > 0)
                    {
                        for (int i = 0; i < CommentsData.Rows.Count; i++)
                        {
                            if (CommentsData.Rows[i]["COMMENT_TYPE"].ToString() != "DEFAULT")
                            {
                                if (CommentsData.Rows[i]["COMMENTSLENGTH"] != null)
                                {
                                    intLength = intLength + Convert.ToInt32(CommentsData.Rows[i]["COMMENTSLENGTH"]);
                                }
                            }
                            else 
                            {
                                if (CommentsData.Rows[i]["TAN_COMMENT"] != null)
                                {
                                    if (!CommentsData.Rows[i]["TAN_COMMENT"].ToString().StartsWith("8000") &&
                                        !CommentsData.Rows[i]["TAN_COMMENT"].ToString().StartsWith("8500"))
                                    {
                                        intLength = intLength + Convert.ToInt32(CommentsData.Rows[i]["COMMENTSLENGTH"]);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return intLength;
        }

        #region Temperature Comments related methods
        
        private void BindAndFormatTemperatureComments(string temprture_cmnts)
        {
            try
            {
                if (!string.IsNullOrEmpty(temprture_cmnts))
                {
                    rtxtTempCmts.Text = temprture_cmnts.Trim();
                    rtxtTempCmts.Text = rtxtTempCmts.Text.Replace(". reaction", "\r\nreaction");

                    //Replace New line with junk characters before coloring and replace the same with new line after coloring
                    rtxtTempCmts.Rtf = rtxtTempCmts.Rtf.Replace("\r\n", "_|0|_");
                    ColourRichTextBoxText(rtxtTempCmts);
                    rtxtTempCmts.Rtf = rtxtTempCmts.Rtf.Replace("_|0|_", "\r\n");
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void ColourRichTextBoxText(RichTextBox rtb)
        {
            try
            {
                Regex regEx_P = new Regex("reaction");
                foreach (Match match in regEx_P.Matches(rtb.Text))
                {
                    rtb.Select(match.Index, match.Length);
                    rtb.SelectionColor = Color.Blue;
                }

                Regex regEx_Stg = new Regex("stage [0-9]{0,3}");
                foreach (Match match in regEx_Stg.Matches(rtb.Text))
                {
                    rtb.Select(match.Index, match.Length);
                    rtb.SelectionColor = Color.DeepPink;
                }

                Regex regEx_C = new Regex("TP=");
                foreach (Match match in regEx_C.Matches(rtb.Text))
                {
                    rtb.Select(match.Index, match.Length);
                    rtb.SelectionColor = Color.OrangeRed;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        #endregion

        private DataTable GetCommentsTableDefinition()
        {
            DataTable dtComments = new DataTable();
           
            DataColumn dcTCID = new DataColumn("TC_ID", typeof(Int32));
            dcTCID.AutoIncrement = true;
            dcTCID.AutoIncrementSeed = 1;

            dtComments.Columns.Add(dcTCID);
            dtComments.Columns.Add("TAN_COMMENT", typeof(string));
            dtComments.Columns.Add("COMMENT_TYPE", typeof(string));
            return dtComments;
        }
             
        private void FormIndexingError_AuthorErrorComments(string srctext, string srccntrl, ref string ie_ae_comments)
        {
            try
            {
                string strSource = "";
                if (!string.IsNullOrEmpty(srctext.Trim()))
                {
                    switch (srccntrl.ToUpper())
                    {
                        case "NUM":
                            strSource = " NUM ";
                            break;
                        case "PAGE":
                            strSource = " Page ";
                            break;
                        case "LINE":
                            strSource = "Line ";
                            break;
                        case "PARAGRAPH":
                            strSource = "Paragraph ";
                            break;
                        case "COLUMN":
                            strSource = "Column ";
                            break;
                        case "TABLE":
                            strSource = "Table ";
                            break;
                        case "FIGURE":
                            strSource = "Figure ";
                            break;
                        case "SCHEME":
                            strSource = "Scheme ";
                            break;
                        case "SHEET":
                            strSource = "Sheet ";
                            break;
                        case "FOOTNOTE":
                            strSource = "Footnote ";
                            break;
                        case "OTHER":
                            strSource = " ";
                            break;
                    }
                    ie_ae_comments = !string.IsNullOrEmpty(srctext.Trim()) ? ie_ae_comments.Trim() + strSource + srctext.Trim() + "`" : ie_ae_comments;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private bool CheckSpecialCharactersInText(string comment)
        {
            bool blStatus = false;
            try
            {
                if (!string.IsNullOrEmpty(comment.Trim()))
                {
                    int indexOf = comment.IndexOfAny(caSpecialChars);
                    if (indexOf >= 0)//Special Chars
                    {
                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }
        
        private bool CheckExcludedTermsInText(string[] excluded_terms, string comment, out string errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (!string.IsNullOrEmpty(comment.Trim()) && excluded_terms != null)
                {
                    for (int i = 0; i < excluded_terms.Length; i++)
                    {
                        if (comment.ToUpper().Contains(excluded_terms[i].ToUpper()))
                        {
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Comment contains invalid term '" + excluded_terms[i] + "'";
                            blStatus = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg.Trim();
            return blStatus;
        }

        private bool ValidateUserInputs(string commenttype, out string errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            string strErrMsgTemp = "";
            try
            {
                switch (commenttype.ToUpper())
                {
                    case "INDEXING":
                        if (string.IsNullOrEmpty(txtNUM_IE.Text.Trim()))
                        {
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "NUM can't be null";
                            blStatus = false;
                        }
                        if (string.IsNullOrEmpty(txtPage_IE.Text.Trim()))
                        {
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Page can't be null";
                            blStatus = false;
                        }
                        if (string.IsNullOrEmpty(txtComment_IE.Text.Trim()))
                        {
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Comments can't be null";
                            blStatus = false;
                        }
                        if (CheckSpecialCharactersInText(txtComment_IE.Text.Trim()))
                        {
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in comments";
                            blStatus = false;
                        }
                        if (!CheckExcludedTermsInText(saExcludedTerms, txtComment_IE.Text.Trim(), out strErrMsgTemp))
                        {
                            strErrMsg = strErrMsg.Trim() + "\r\n" + strErrMsgTemp;
                            blStatus = false;
                        }
                        if (!CheckExcludedTermsInText(saExclTermsAE_IE, txtComment_IE.Text.Trim(), out strErrMsgTemp))
                        {
                            strErrMsg = strErrMsg.Trim() + "\r\n" + strErrMsgTemp;
                            blStatus = false;
                        }
                        //Validate special chars in Indexing Comments controls
                        if (!ValidateSpecialCharsInIndexing_AuthorControls(Enums.CommentsType.INDEXING.ToString(), out strErrMsgTemp))
                        {
                            strErrMsg = strErrMsg.Trim() + "\r\n" + strErrMsgTemp.Trim();
                            blStatus = false;
                        }

                        if (!string.IsNullOrEmpty(selectedTab))
                        {
                            if (selectedTab.ToUpper() != Enums.CommentsType.INDEXING.ToString())
                            {
                                strErrMsg = strErrMsg.Trim() + "\r\n" + "Can't add Indexing Comments. " + selectedTab + " Comments are in edit mode. ";
                                blStatus = false;
                            }
                        }

                        break;

                    case "AUTHOR":
                        if (string.IsNullOrEmpty(txtNUM_AE.Text.Trim()))
                        {
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "NUM can't be null";
                            blStatus = false;
                        }
                        if (string.IsNullOrEmpty(txtPage_AE.Text.Trim()))
                        {
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Page can't be null";
                            blStatus = false;
                        }
                        if (string.IsNullOrEmpty(txtComment_AE.Text.Trim()))
                        {
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Comments can't be null";
                            blStatus = false;
                        }
                        if (CheckSpecialCharactersInText(txtComment_AE.Text.Trim()))
                        {
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in comments";
                            blStatus = false;
                        }
                        if (!CheckExcludedTermsInText(saExcludedTerms, txtComment_AE.Text.Trim(), out strErrMsgTemp))
                        {
                            strErrMsg = strErrMsg.Trim() + "\r\n" + strErrMsgTemp;
                            blStatus = false;
                        }
                        if (!CheckExcludedTermsInText(saExclTermsAE_IE, txtComment_AE.Text.Trim(), out strErrMsgTemp))
                        {
                            strErrMsg = strErrMsg.Trim() + "\r\n" + strErrMsgTemp;
                            blStatus = false;
                        }
                        //Validate special chars in Author comments controls                        
                        if (!ValidateSpecialCharsInIndexing_AuthorControls(Enums.CommentsType.AUTHOR.ToString(), out strErrMsgTemp))
                        {
                            strErrMsg = strErrMsg.Trim() + "\r\n" + strErrMsgTemp.Trim();
                            blStatus = false;
                        }

                        if (!string.IsNullOrEmpty(selectedTab))
                        {
                            if (selectedTab.ToUpper() != Enums.CommentsType.AUTHOR.ToString())
                            {
                                strErrMsg = strErrMsg.Trim() + "\r\n" + "Can't add Author Comments. " + selectedTab + " Comments are in edit mode. ";
                                blStatus = false;
                            }
                        }

                        break;

                    case "OTHER":
                        if (string.IsNullOrEmpty(txtOtherComment.Text.Trim()))
                        {
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Comments can't be null";
                            blStatus = false;
                        }
                        if (CheckSpecialCharactersInText(txtOtherComment.Text.Trim()))
                        {
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in comments";
                            blStatus = false;
                        }
                        if (!CheckExcludedTermsInText(saExcludedTerms, txtOtherComment.Text.Trim(), out strErrMsgTemp))
                        {
                            strErrMsg = strErrMsg.Trim() + "\r\n" + strErrMsgTemp;
                            blStatus = false;
                        }

                        if (!string.IsNullOrEmpty(selectedTab))
                        {
                            if (selectedTab.ToUpper() != Enums.CommentsType.OTHER.ToString())
                            {
                                strErrMsg = strErrMsg.Trim() + "\r\n" + "Can't add Other Comments. " + selectedTab + " Comments are in edit mode. ";
                                blStatus = false;
                            }
                        }

                        break;

                    case "CAS":
                        if (IsQueryTAN)
                        {
                            if (string.IsNullOrEmpty(txtCASComment.Text.Trim()))
                            {
                                strErrMsg = strErrMsg.Trim() + "\r\n" + "Comments can't be null";
                                blStatus = false;
                            }
                            if (CheckSpecialCharactersInText(txtCASComment.Text.Trim()))
                            {
                                strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in comments";
                                blStatus = false;
                            }
                            if (!CheckExcludedTermsInText(saExcludedTerms, txtCASComment.Text.Trim(), out strErrMsgTemp))
                            {
                                strErrMsg = strErrMsg.Trim() + "\r\n" + strErrMsgTemp;
                                blStatus = false;
                            }

                            if (!string.IsNullOrEmpty(selectedTab))
                            {
                                if (selectedTab.ToUpper() != Enums.CommentsType.CAS.ToString())
                                {
                                    strErrMsg = strErrMsg.Trim() + "\r\n" + "Can't add CAS Consulted for Comments. " + selectedTab + " Comments are in edit mode. ";
                                    blStatus = false;
                                }
                            }
                        }
                        break;
                }       
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg;
            return blStatus;
        }

        private bool ValidateSpecialCharsInIndexing_AuthorControls(string commentstype, out string errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (commentstype.ToUpper() == "INDEXING")
                {
                    if (CheckSpecialCharactersInText(txtPage_IE.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in Page";
                        blStatus = false;
                    }
                    if (CheckSpecialCharactersInText(txtLine_IE.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in Line";
                        blStatus = false;
                    }
                    if (CheckSpecialCharactersInText(txtPara_IE.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in Paragraph";
                        blStatus = false;
                    }
                    if (CheckSpecialCharactersInText(txtColumn_IE.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in Column";
                        blStatus = false;
                    }
                    if (CheckSpecialCharactersInText(txtTable_IE.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in Table";
                        blStatus = false;
                    }
                    if (CheckSpecialCharactersInText(txtFigure_IE.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in Figure";
                        blStatus = false;
                    }
                    if (CheckSpecialCharactersInText(txtScheme_IE.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in Scheme";
                        blStatus = false;
                    }
                    if (CheckSpecialCharactersInText(txtSheet_IE.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in Sheet";
                        blStatus = false;
                    }
                    if (CheckSpecialCharactersInText(txtFootNote_IE.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in Footnote";
                        blStatus = false;
                    }

                    //  txtPage_IE.Text
                    //  txtLine_IE.Text
                    //  txtPara_IE.Text
                    //txtColumn_IE.Text
                    //  txtTable_IE.Text
                    //  txtFigure_IE.Text
                    //  txtScheme_IE.Text
                    //  txtSheet_IE.Text
                    //  txtFootNote_IE.Text
                }
                else if (commentstype.ToUpper() == "AUTHOR")
                {
                    if (CheckSpecialCharactersInText(txtPage_AE.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in Page";
                        blStatus = false;
                    }
                    if (CheckSpecialCharactersInText(txtLine_AE.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in Line";
                        blStatus = false;
                    }
                    if (CheckSpecialCharactersInText(txtPara_AE.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in Paragraph";
                        blStatus = false;
                    }
                    if (CheckSpecialCharactersInText(txtColumn_AE.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in Column";
                        blStatus = false;
                    }
                    if (CheckSpecialCharactersInText(txtTable_AE.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in Table";
                        blStatus = false;
                    }
                    if (CheckSpecialCharactersInText(txtFigure_AE.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in Figure";
                        blStatus = false;
                    }
                    if (CheckSpecialCharactersInText(txtScheme_AE.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in Scheme";
                        blStatus = false;
                    }
                    if (CheckSpecialCharactersInText(txtSheet_AE.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in Sheet";
                        blStatus = false;
                    }
                    if (CheckSpecialCharactersInText(txtFootNote_AE.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Special characters are not allowed in Footnote";
                        blStatus = false;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg;
            return blStatus;
        }

        private void ClearCommentsControlValues(string commenttype)
        {
            try
            {
                if (!string.IsNullOrEmpty(commenttype))
                {
                    switch (commenttype.ToUpper())
                    {
                        case "INDEXING":
                            txtNUM_IE.Clear();
                            txtPage_IE.Clear();
                            txtLine_IE.Clear();
                            txtPara_IE.Clear();
                            txtColumn_IE.Clear();
                            txtTable_IE.Clear();
                            txtFigure_IE.Clear();
                            txtScheme_IE.Clear();
                            txtSheet_IE.Clear();
                            txtFootNote_IE.Clear();
                            txtComment_IE.Clear();
                            break;

                        case "AUTHOR":
                            txtNUM_AE.Clear();
                            txtPage_AE.Clear();
                            txtLine_AE.Clear();
                            txtPara_AE.Clear();
                            txtColumn_AE.Clear();
                            txtTable_AE.Clear();
                            txtFigure_AE.Clear();
                            txtScheme_AE.Clear();
                            txtSheet_AE.Clear();
                            txtFootNote_AE.Clear();
                            txtComment_AE.Clear();
                            chkCorrected_AE.CheckState = CheckState.Unchecked;
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetIndexing_AuthorErrorComments(string srccntrl)
        {
            string strComments = "";
            try
            {             
                if (srccntrl.ToUpper() == "INDEXING")
                {
                    strComments = !string.IsNullOrEmpty(txtNUM_IE.Text.Trim()) ? " NUM " + txtNUM_IE.Text.Trim() : strComments;
                    //FormIndexingError_AuthorErrorComments(txtNUM_IE.Text, "NUM", ref strComments);
                    strComments = !string.IsNullOrEmpty(strComments.Trim()) ? strComments.Trim() + ", " : strComments.Trim();

                    FormIndexingError_AuthorErrorComments(txtPage_IE.Text, "PAGE", ref strComments);
                    FormIndexingError_AuthorErrorComments(txtLine_IE.Text, "LINE", ref strComments);
                    FormIndexingError_AuthorErrorComments(txtPara_IE.Text, "PARAGRAPH", ref strComments);
                    FormIndexingError_AuthorErrorComments(txtColumn_IE.Text, "COLUMN", ref strComments);
                    FormIndexingError_AuthorErrorComments(txtTable_IE.Text, "TABLE", ref strComments);
                    FormIndexingError_AuthorErrorComments(txtFigure_IE.Text, "FIGURE", ref strComments);
                    FormIndexingError_AuthorErrorComments(txtScheme_IE.Text, "SCHEME", ref strComments);
                    FormIndexingError_AuthorErrorComments(txtSheet_IE.Text, "SHEET", ref strComments);
                    FormIndexingError_AuthorErrorComments(txtFootNote_IE.Text, "FOOTNOTE", ref strComments);

                    strComments = strComments.TrimEnd(new char[] { '`' });
                    strComments = strComments.Trim() + ", " + txtComment_IE.Text.Trim();
                }
                else if (srccntrl.ToUpper() == "AUTHOR")
                {
                    strComments = !string.IsNullOrEmpty(txtNUM_AE.Text.Trim()) ? " NUM " + txtNUM_AE.Text.Trim() : strComments;
                    //FormIndexingError_AuthorErrorComments(txtNUM_AE.Text, "NUM", ref strComments);
                    strComments = chkCorrected_AE.Checked ? strComments.Trim() + " (corrected)" : strComments;//Corrected NUM
                    strComments = !string.IsNullOrEmpty(strComments.Trim()) ? strComments.Trim() + ", " : strComments.Trim();

                    FormIndexingError_AuthorErrorComments(txtPage_AE.Text, "PAGE", ref strComments);
                    FormIndexingError_AuthorErrorComments(txtLine_AE.Text, "LINE", ref strComments);
                    FormIndexingError_AuthorErrorComments(txtPara_AE.Text, "PARAGRAPH", ref strComments);
                    FormIndexingError_AuthorErrorComments(txtColumn_AE.Text, "COLUMN", ref strComments);
                    FormIndexingError_AuthorErrorComments(txtTable_AE.Text, "TABLE", ref strComments);
                    FormIndexingError_AuthorErrorComments(txtFigure_AE.Text, "FIGURE", ref strComments);
                    FormIndexingError_AuthorErrorComments(txtScheme_AE.Text, "SCHEME", ref strComments);
                    FormIndexingError_AuthorErrorComments(txtSheet_AE.Text, "SHEET", ref strComments);
                    FormIndexingError_AuthorErrorComments(txtFootNote_AE.Text, "FOOTNOTE", ref strComments);

                    strComments = strComments.TrimEnd(new char[] { '`' });
                    strComments = strComments.Trim() + ", " + txtComment_AE.Text.Trim();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strComments;
        }
        
        private void btnAddIECmnt_Click(object sender, EventArgs e)
        {
            try
            {
                //Validate user inputs
                string strErrMsg = "";
                if (ValidateUserInputs(Enums.CommentsType.INDEXING.ToString(), out strErrMsg))
                {
                    if (editRowIndx == 0)
                    {
                        if (CommentsData == null)
                        {
                            CommentsData = GetCommentsTableDefinition();
                        }

                        DataRow dtRow = CommentsData.NewRow();
                        dtRow["TC_ID"] = 0;
                        dtRow["TAN_COMMENT"] = GetIndexing_AuthorErrorComments(Enums.CommentsType.INDEXING.ToString());
                        dtRow["COMMENT_TYPE"] = Enums.CommentsType.INDEXING;
                        CommentsData.Rows.Add(dtRow);
                    }
                    else
                    {
                        CommentsData.Rows[editRowIndx - 1]["TAN_COMMENT"] = GetIndexing_AuthorErrorComments(Enums.CommentsType.INDEXING.ToString());
                        CommentsData.AcceptChanges();
                        editRowIndx = 0;
                    }

                    //Bind comments to grid
                    BindCommentsDataToGrid();

                    //Clear all control values
                    ClearAllControlValues();
                }
                else
                {
                    MessageBox.Show(strErrMsg,GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnAddAECmnt_Click(object sender, EventArgs e)
        {
            try
            {
                //Validate user inputs
                string strErrMsg = "";
                if (ValidateUserInputs(Enums.CommentsType.AUTHOR.ToString(), out strErrMsg))
                {
                    if (editRowIndx == 0)
                    {
                        if (CommentsData == null)
                        {
                            CommentsData = GetCommentsTableDefinition();
                        }

                        DataRow dtRow = CommentsData.NewRow();
                        dtRow["TC_ID"] = 0;
                        dtRow["TAN_COMMENT"] = GetIndexing_AuthorErrorComments(Enums.CommentsType.AUTHOR.ToString());
                        dtRow["COMMENT_TYPE"] = Enums.CommentsType.AUTHOR;
                        CommentsData.Rows.Add(dtRow);
                    }
                    else
                    {
                        CommentsData.Rows[editRowIndx - 1]["TAN_COMMENT"] = GetIndexing_AuthorErrorComments(Enums.CommentsType.AUTHOR.ToString());
                        CommentsData.AcceptChanges();
                        editRowIndx = 0;
                    }

                    //Bind comments to grid
                    BindCommentsDataToGrid();

                    //Clear all control values
                    ClearAllControlValues();
                }
                else
                {
                    MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnAddOtherCmnts_Click(object sender, EventArgs e)
        {
            try
            {
                //Validate user inputs
                string strErrMsg = "";
                if (ValidateUserInputs(Enums.CommentsType.OTHER.ToString(), out strErrMsg))
                {
                    if (editRowIndx == 0)
                    {
                        if (CommentsData == null)
                        {
                            CommentsData = GetCommentsTableDefinition();
                        }

                        DataRow dtRow = CommentsData.NewRow();
                        dtRow["TC_ID"] = 0;
                        dtRow["TAN_COMMENT"] = txtOtherComment.Text.Trim();
                        dtRow["COMMENT_TYPE"] = Enums.CommentsType.OTHER.ToString();
                        CommentsData.Rows.Add(dtRow);
                    }
                    else
                    {
                        CommentsData.Rows[editRowIndx - 1]["TAN_COMMENT"] = txtOtherComment.Text.Trim();
                        CommentsData.AcceptChanges();
                        editRowIndx = 0;
                    }

                    //Bind comments to grid
                    BindCommentsDataToGrid();

                    //Clear all control values
                    ClearAllControlValues();     
                }
                else
                {
                    MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnCASCmnts_Click(object sender, EventArgs e)
        {
            try
            {
                //Validate user inputs
                string strErrMsg = "";
                if (ValidateUserInputs(Enums.CommentsType.CAS.ToString(), out strErrMsg))
                {
                    if (editRowIndx == 0)
                    {
                        if (CommentsData == null)
                        {
                            CommentsData = GetCommentsTableDefinition();
                        }

                        DataRow dtRow = CommentsData.NewRow();
                        dtRow["TC_ID"] = 0;
                        dtRow["TAN_COMMENT"] = txtCASComment.Text.Trim();
                        dtRow["COMMENT_TYPE"] = Enums.CommentsType.CAS.ToString();
                        CommentsData.Rows.Add(dtRow);
                    }
                    else
                    {
                        CommentsData.Rows[editRowIndx - 1]["TAN_COMMENT"] = txtCASComment.Text.Trim();
                        CommentsData.AcceptChanges();
                        editRowIndx = 0;
                    }

                    //Bind comments to grid
                    BindCommentsDataToGrid();

                    //Clear all control values
                    ClearAllControlValues();         
                }
                else
                {
                    MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvComments_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();
                while (strRowNumber.Length < dgvComments.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;
                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvComments.Font);
                if (dgvComments.RowHeadersWidth < (int)(size.Width + 20)) dgvComments.RowHeadersWidth = (int)(size.Width + 20);
                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnClear_IE_Click(object sender, EventArgs e)
        {
            try
            {
                ClearCommentsControlValues("INDEXING");
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnClear_AE_Click(object sender, EventArgs e)
        {
            try
            {
                ClearCommentsControlValues("AUTHOR");
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #region Code Commented
        //private string GetCommentsFromCommentsData(DataTable commentsdata, string commentstype, string delimiter)
        //{
        //    string strComments = "";
        //    try
        //    {
        //        if (commentsdata != null && !string.IsNullOrEmpty(commentstype) && !string.IsNullOrEmpty(delimiter))
        //        {
        //            strComments = string.Join(delimiter, (from DataRow row in commentsdata.Rows
        //                                            where (string)row["COMMENTSTYPE"] == commentstype
        //                                            select (string)row["TANCOMMENTS"]).ToArray());                    
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return strComments;
        //}

        //private DataTable GetCommentsTableFromTANComments(string comments)
        //{
        //    DataTable dtComments = null;
        //    try 
        //    {
        //        if (!string.IsNullOrEmpty(comments))
        //        {
        //            Regex regEx;                  
        //            string strCmnts = "";
        //            string[] saCmnts = null;

        //            dtComments = GetCommentsTableDefinition();                    
        //            DataRow dtRow = null;

        //            //CAS Comments
        //            regEx = new Regex("<CE>(.*?)</CE>");
        //            var vCE = regEx.Match(comments);
        //            strCmnts = vCE.Groups[1].ToString();
        //            if (!string.IsNullOrEmpty(strCmnts))
        //            {
        //                saCmnts = strCmnts.Split(new string[] { "~CE~" }, StringSplitOptions.RemoveEmptyEntries);
        //                if (saCmnts != null)
        //                {
        //                    for (int i = 0; i < saCmnts.Length; i++)
        //                    {
        //                        dtRow = dtComments.NewRow();
        //                        dtRow["TANCOMMENTS"] = saCmnts[i].Trim();
        //                        dtRow["COMMENTSTYPE"] = "CAS";
        //                        dtComments.Rows.Add(dtRow);
        //                    }
        //                }
        //            }

        //            //INDEXING Error Comments                   
        //            regEx = new Regex("<IE>(.*?)</IE>");
        //            var vIE = regEx.Match(comments);
        //            strCmnts = vIE.Groups[1].ToString();
        //            if (!string.IsNullOrEmpty(strCmnts))
        //            {
        //                saCmnts = strCmnts.Split(new string[] { "~IE~" }, StringSplitOptions.RemoveEmptyEntries);
        //                if (saCmnts != null)
        //                {
        //                    for (int i = 0; i < saCmnts.Length; i++)
        //                    {
        //                        dtRow = dtComments.NewRow();
        //                        dtRow["TANCOMMENTS"] = saCmnts[i].Trim();
        //                        dtRow["COMMENTSTYPE"] = "INDEXING";
        //                        dtComments.Rows.Add(dtRow);
        //                    }
        //                }
        //            }

        //            //Author Error Comments                   
        //            regEx = new Regex("<AE>(.*?)</AE>");
        //            var vAE = regEx.Match(comments);
        //            strCmnts = vAE.Groups[1].ToString();
        //            if (!string.IsNullOrEmpty(strCmnts))
        //            {
        //                saCmnts = strCmnts.Split(new string[] { "~AE~" }, StringSplitOptions.RemoveEmptyEntries);
        //                if (saCmnts != null)
        //                {
        //                    for (int i = 0; i < saCmnts.Length; i++)
        //                    {
        //                        dtRow = dtComments.NewRow();
        //                        dtRow["TANCOMMENTS"] = saCmnts[i].Trim();
        //                        dtRow["COMMENTSTYPE"] = "AUTHOR";
        //                        dtComments.Rows.Add(dtRow);
        //                    }
        //                }
        //            }

        //            //Other Comments 
        //            if (comments.Trim().Contains("<OE>") && comments.Trim().Contains("</OE>"))
        //            {
        //                regEx = new Regex("<OE>(.*?)</OE>");
        //                var vOE = regEx.Match(comments);
        //                strCmnts = vOE.Groups[1].ToString();
        //                if (!string.IsNullOrEmpty(strCmnts))
        //                {
        //                    saCmnts = strCmnts.Split(new string[] { "~OE~" }, StringSplitOptions.RemoveEmptyEntries);
        //                    if (saCmnts != null)
        //                    {
        //                        string strOtherCmnts = "";
        //                        for (int i = 0; i < saCmnts.Length; i++)
        //                        {
        //                            //dtRow = dtComments.NewRow();
        //                            //dtRow["TANCOMMENTS"] = saCmnts[i].Trim();
        //                            //dtRow["COMMENTSTYPE"] = "OTHER";
        //                            //dtComments.Rows.Add(dtRow);

        //                            strOtherCmnts = "";
        //                            strOtherCmnts = saCmnts[i].Trim();

        //                            //Old User Comments - format is DefaultComments~~TemperatureComments`UserComments
        //                            if (strOtherCmnts.Trim().Contains("~~") && strOtherCmnts.Trim().Contains("`"))
        //                            {
        //                                regEx = new Regex("^(.*)~~([^`]*)`(.+)$"); //
        //                                var vOUC = regEx.Match(strOtherCmnts);
        //                                if (vOUC.Groups.Count == 4)
        //                                {
        //                                    if (!string.IsNullOrEmpty(vOUC.Groups[1].ToString()))//Default Comments
        //                                    {
        //                                        dtRow = dtComments.NewRow();
        //                                        dtRow["TANCOMMENTS"] = vOUC.Groups[1].ToString().Trim();
        //                                        dtRow["COMMENTSTYPE"] = "DEFAULT";
        //                                        dtComments.Rows.Add(dtRow);
        //                                    }
        //                                    if (!string.IsNullOrEmpty(vOUC.Groups[2].ToString()))//Temperature Comments
        //                                    {
        //                                        dtRow = dtComments.NewRow();
        //                                        dtRow["TANCOMMENTS"] = vOUC.Groups[2].ToString().Trim();
        //                                        dtRow["COMMENTSTYPE"] = "TEMPERATURE";
        //                                        dtComments.Rows.Add(dtRow);
        //                                    }
        //                                    if (!string.IsNullOrEmpty(vOUC.Groups[3].ToString()))//Other Comments
        //                                    {
        //                                        dtRow = dtComments.NewRow();
        //                                        dtRow["TANCOMMENTS"] = vOUC.Groups[3].ToString().Trim();
        //                                        dtRow["COMMENTSTYPE"] = "OTHER";
        //                                        dtComments.Rows.Add(dtRow);
        //                                    }
        //                                }
        //                            }
        //                            else if (!strOtherCmnts.Trim().Contains("~~") && !strOtherCmnts.Trim().Contains("`"))//Only Default Comments
        //                            {
        //                                dtRow = dtComments.NewRow();
        //                                dtRow["TANCOMMENTS"] = strOtherCmnts.Trim();
        //                                dtRow["COMMENTSTYPE"] = "DEFAULT";
        //                                dtComments.Rows.Add(dtRow);
        //                            }
        //                            else if (strOtherCmnts.Trim().Contains("~~"))//Comments contains Temperature Comments
        //                            {
        //                                string[] saComments = strOtherCmnts.Trim().Split(new string[] { "~~" }, StringSplitOptions.RemoveEmptyEntries);
        //                                if (saComments != null)
        //                                {
        //                                    if (saComments.Length == 2)
        //                                    {
        //                                        dtRow = dtComments.NewRow();
        //                                        dtRow["TANCOMMENTS"] = saComments[0].Trim();
        //                                        dtRow["COMMENTSTYPE"] = "DEFAULT";
        //                                        dtComments.Rows.Add(dtRow);

        //                                        dtRow = dtComments.NewRow();
        //                                        dtRow["TANCOMMENTS"] = saComments[1].Trim();
        //                                        dtRow["COMMENTSTYPE"] = "TEMPERATURE";
        //                                        dtComments.Rows.Add(dtRow);
        //                                    }
        //                                    else if (saComments.Length == 1)
        //                                    {
        //                                        dtRow = dtComments.NewRow();
        //                                        dtRow["TANCOMMENTS"] = saComments[0].Trim();
        //                                        dtRow["COMMENTSTYPE"] = "TEMPERATURE";
        //                                        dtComments.Rows.Add(dtRow);
        //                                    }
        //                                }
        //                            }
        //                            else if (strOtherCmnts.Trim().Contains("`"))//Comments contains Temperature Comments
        //                            {
        //                                string[] saComments = strOtherCmnts.Trim().Split(new string[] { "`" }, StringSplitOptions.RemoveEmptyEntries);
        //                                if (saComments != null)
        //                                {
        //                                    if (saComments.Length == 2)
        //                                    {
        //                                        dtRow = dtComments.NewRow();
        //                                        dtRow["TANCOMMENTS"] = saComments[0].Trim();
        //                                        dtRow["COMMENTSTYPE"] = "DEFAULT";
        //                                        dtComments.Rows.Add(dtRow);

        //                                        dtRow = dtComments.NewRow();
        //                                        dtRow["TANCOMMENTS"] = saComments[1].Trim();
        //                                        dtRow["COMMENTSTYPE"] = "OTHER";
        //                                        dtComments.Rows.Add(dtRow);
        //                                    }
        //                                    else if (saComments.Length == 1)
        //                                    {
        //                                        dtRow = dtComments.NewRow();
        //                                        dtRow["TANCOMMENTS"] = saComments[0].Trim();
        //                                        dtRow["COMMENTSTYPE"] = "OTHER";
        //                                        dtComments.Rows.Add(dtRow);
        //                                    }
        //                                }
        //                            }
        //                        }
        //                    }
        //                }
        //            }
        //            else
        //            {
        //                //Old User Comments - format is DefaultComments~~TemperatureComments`UserComments
        //                if (comments.Trim().Contains("~~") && comments.Trim().Contains("`"))
        //                {
        //                    regEx = new Regex("^(.*)~~([^`]*)`(.+)$"); //
        //                    var vOUC = regEx.Match(comments);
        //                    if (vOUC.Groups.Count == 4)
        //                    {
        //                        if (!string.IsNullOrEmpty(vOUC.Groups[1].ToString()))//Default Comments
        //                        {
        //                            dtRow = dtComments.NewRow();
        //                            dtRow["TANCOMMENTS"] = vOUC.Groups[1].ToString().Trim();
        //                            dtRow["COMMENTSTYPE"] = "DEFAULT";
        //                            dtComments.Rows.Add(dtRow);
        //                        }
        //                        if (!string.IsNullOrEmpty(vOUC.Groups[2].ToString()))//Temperature Comments
        //                        {
        //                            dtRow = dtComments.NewRow();
        //                            dtRow["TANCOMMENTS"] = vOUC.Groups[2].ToString().Trim();
        //                            dtRow["COMMENTSTYPE"] = "TEMPERATURE";
        //                            dtComments.Rows.Add(dtRow);
        //                        }
        //                        if (!string.IsNullOrEmpty(vOUC.Groups[3].ToString()))//Other Comments
        //                        {
        //                            dtRow = dtComments.NewRow();
        //                            dtRow["TANCOMMENTS"] = vOUC.Groups[3].ToString().Trim();
        //                            dtRow["COMMENTSTYPE"] = "OTHER";
        //                            dtComments.Rows.Add(dtRow);
        //                        }
        //                    }
        //                }
        //                else if (!comments.Trim().Contains("~~") && !comments.Trim().Contains("`"))//Only Default Comments
        //                {
        //                    dtRow = dtComments.NewRow();
        //                    dtRow["TANCOMMENTS"] = comments.Trim();
        //                    dtRow["COMMENTSTYPE"] = "DEFAULT";
        //                    dtComments.Rows.Add(dtRow);
        //                }
        //                else if (comments.Trim().Contains("~~"))//Comments contains Temperature Comments
        //                {
        //                    string[] saComments = comments.Trim().Split(new string[] { "~~" }, StringSplitOptions.RemoveEmptyEntries);
        //                    if (saComments != null)
        //                    {
        //                        if (saComments.Length == 2)
        //                        {
        //                            dtRow = dtComments.NewRow();
        //                            dtRow["TANCOMMENTS"] = saComments[0].Trim();
        //                            dtRow["COMMENTSTYPE"] = "DEFAULT";
        //                            dtComments.Rows.Add(dtRow);

        //                            dtRow = dtComments.NewRow();
        //                            dtRow["TANCOMMENTS"] = saComments[1].Trim();
        //                            dtRow["COMMENTSTYPE"] = "TEMPERATURE";
        //                            dtComments.Rows.Add(dtRow);
        //                        }
        //                        else if (saComments.Length == 1)
        //                        {
        //                            dtRow = dtComments.NewRow();
        //                            dtRow["TANCOMMENTS"] = saComments[0].Trim();
        //                            dtRow["COMMENTSTYPE"] = "TEMPERATURE";
        //                            dtComments.Rows.Add(dtRow);
        //                        }
        //                    }
        //                }
        //                else if (comments.Trim().Contains("`"))//Comments contains Temperature Comments
        //                {
        //                    string[] saComments = comments.Trim().Split(new string[] { "`" }, StringSplitOptions.RemoveEmptyEntries);
        //                    if (saComments != null)
        //                    {
        //                        if (saComments.Length == 2)
        //                        {
        //                            dtRow = dtComments.NewRow();
        //                            dtRow["TANCOMMENTS"] = saComments[0].Trim();
        //                            dtRow["COMMENTSTYPE"] = "DEFAULT";
        //                            dtComments.Rows.Add(dtRow);

        //                            dtRow = dtComments.NewRow();
        //                            dtRow["TANCOMMENTS"] = saComments[1].Trim();
        //                            dtRow["COMMENTSTYPE"] = "OTHER";
        //                            dtComments.Rows.Add(dtRow);
        //                        }
        //                        else if (saComments.Length == 1)
        //                        {
        //                            dtRow = dtComments.NewRow();
        //                            dtRow["TANCOMMENTS"] = saComments[0].Trim();
        //                            dtRow["COMMENTSTYPE"] = "OTHER";
        //                            dtComments.Rows.Add(dtRow);
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return dtComments;
        //} 
        #endregion

        private void BindIndexing_AuthorCommentsToControls(string comment, string comment_type)
        {
            try
            {
                if (!string.IsNullOrEmpty(comment) && !string.IsNullOrEmpty(comment_type))
                {
                    if (comment_type.ToUpper() == "INDEXING")
                    {
                        List<string> lstIndxingCmnts = GetSplittedAuthor_IndexedComments(comment);

                        //string[] saIndxingCmnts = comment.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                        if (lstIndxingCmnts != null)
                        {
                            if (lstIndxingCmnts.Count == 3)
                            {
                                txtNUM_IE.Text = lstIndxingCmnts[0].Trim().Replace("NUM", "");//NUM
                                txtComment_IE.Text = lstIndxingCmnts[2].Trim();//Comment

                                //Page,Line,Para,Column,Table,Figure,Scheme,Sheet,Footnote
                                List<string> lstValues = GetValuesFromLocationInfo_New(lstIndxingCmnts[1].Trim());

                                if (lstValues != null)
                                {
                                    if (lstValues.Count == 9)
                                    {
                                        //page,line,para,column,table,figure,scheme,sheet,footnote
                                        txtPage_IE.Text = lstValues[0].Trim();
                                        txtLine_IE.Text = lstValues[1].Trim();
                                        txtPara_IE.Text = lstValues[2].Trim();
                                        txtColumn_IE.Text = lstValues[3].Trim();
                                        txtTable_IE.Text = lstValues[4].Trim();
                                        txtFigure_IE.Text = lstValues[5].Trim();
                                        txtScheme_IE.Text = lstValues[6].Trim();
                                        txtSheet_IE.Text = lstValues[7].Trim();
                                        txtFootNote_IE.Text = lstValues[8].Trim();
                                    }
                                }
                            }
                        }
                    }
                    else if (comment_type.ToUpper() == "AUTHOR")
                    {
                        List<string> lstIndxingCmnts = GetSplittedAuthor_IndexedComments(comment);
                        
                        //string[] saAuthorCmnts = comment.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                        if (lstIndxingCmnts != null)
                        {
                            if (lstIndxingCmnts.Count == 3)
                            {
                                if (lstIndxingCmnts[0].Trim().ToUpper().Contains("CORRECTED"))
                                {
                                    chkCorrected_AE.CheckState = CheckState.Checked;
                                }
                                txtNUM_AE.Text = lstIndxingCmnts[0].Trim().Replace("NUM", "").ToUpper().Replace("(CORRECTED)", "").Trim();//NUM - Corrected
                                txtComment_AE.Text = lstIndxingCmnts[2].Trim();//Comment

                                //Page,Line,Para,Column,Table,Figure,Scheme,Sheet,Footnote
                                List<string> lstValues = GetValuesFromLocationInfo_New(lstIndxingCmnts[1].Trim());
                                if (lstValues != null)
                                {
                                    if (lstValues.Count == 9)
                                    {
                                        //page,line,para,column,table,figure,scheme,sheet,footnote
                                        txtPage_AE.Text = lstValues[0].Trim();
                                        txtLine_AE.Text = lstValues[1].Trim();
                                        txtPara_AE.Text = lstValues[2].Trim();
                                        txtColumn_AE.Text = lstValues[3].Trim();
                                        txtTable_AE.Text = lstValues[4].Trim();
                                        txtFigure_AE.Text = lstValues[5].Trim();
                                        txtScheme_AE.Text = lstValues[6].Trim();
                                        txtSheet_AE.Text = lstValues[7].Trim();
                                        txtFootNote_AE.Text = lstValues[8].Trim();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private List<string> GetSplittedAuthor_IndexedComments(string comments)
        {
            List<string> lstComments = null;
            try
            {
                if (!string.IsNullOrEmpty(comments))
                {
                    lstComments = new List<string>();                    
                    string strNum = "";
                    string strPageInfo = "";
                    string strComments = "";

                    int i = GetNthIndexOfCharInComments(comments, ',', 2);
                    if (i > 0)
                    {
                        string strNum_PageInfo = comments.Substring(0, i);                     
                        strComments = comments.Substring(i, comments.Length - i);
                        strComments = strComments.Trim().TrimStart(new char[] { ',' });

                        if (!string.IsNullOrEmpty(strNum_PageInfo))
                        {
                            i = GetNthIndexOfCharInComments(strNum_PageInfo, ',', 1);
                            if (i > 0)
                            {
                                strNum = strNum_PageInfo.Substring(0, i);
                                strPageInfo = strNum_PageInfo.Substring(i, (strNum_PageInfo.Length - i));
                                strPageInfo = strPageInfo.Trim().TrimStart(new char[] { ',' });
                            }
                        }
                        

                        lstComments.Add(strNum.Trim());
                        lstComments.Add(strPageInfo.Trim());
                        lstComments.Add(strComments.Trim());
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstComments;
        }

        private int GetNthIndexOfCharInComments(string comments, char chr, int indx)
        {
            int intNthIndx = 0;
            try
            {
                if (!string.IsNullOrEmpty(comments))
                {
                    var str = comments;
                    var ch = chr;// ',';
                    var n = indx;// 2;
                    var result = str.Select((c, i) => new { c, i })
                                    .Where(x => x.c == ch)
                                    .Skip(n - 1)
                                    .FirstOrDefault();
                    intNthIndx = result != null ? result.i : -1;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return intNthIndx;
        }

        private List<string> GetValuesFromLocationInfo_New(string loc_info)
        {
            List<string> lstValues = new List<string>();
            try
            {
                if (!string.IsNullOrEmpty(loc_info))
                {
                    string strPage = "";
                    string strLine = "";
                    string strPara = "";
                    string strColumn = "";
                    string strTable = "";
                    string strFigure = "";
                    string strScheme = "";
                    string strSheet = "";
                    string strFootnote = "";

                    //Page,Line,Para,Column,Table,Figure,Scheme,Sheet,Footnote
                    //page xx table xx line xx - Page 15 Line 21 \
                    Regex regEx = new Regex("^(?:Page (?<page>[^`]+))?`?(?:Line (?<line>[^`]+))?`?(?:Paragraph (?<paragraph>[^`]+))?`?(?:Column (?<column>[^`]+))?`?(?:Table (?<table>[^`]+))?`?(?:Figure (?<figure>[^`]+))?`?(?:Scheme (?<scheme>[^`]+))?`?(?:Sheet (?<sheet>[^`]+))?`?(?:Footnote (?<footnote>[^`]+))?`?$");
                    var vPG = regEx.Match(loc_info);

                    strPage = vPG.Groups["page"].Value ?? "";
                    strLine = vPG.Groups["line"].Value ?? "";
                    strPara = vPG.Groups["paragraph"].Value ?? "";
                    strColumn = vPG.Groups["column"].Value ?? ""; 
                    strTable = vPG.Groups["table"].Value ?? "";
                    strFigure = vPG.Groups["figure"].Value ?? ""; 
                    strScheme = vPG.Groups["scheme"].Value ?? "";
                    strSheet = vPG.Groups["sheet"].Value ?? "";
                    strFootnote = vPG.Groups["footnote"].Value ?? "";

                    lstValues.Add(strPage);
                    lstValues.Add(strLine);
                    lstValues.Add(strPara);
                    lstValues.Add(strColumn);
                    lstValues.Add(strTable);
                    lstValues.Add(strFigure);
                    lstValues.Add(strScheme);
                    lstValues.Add(strSheet);
                    lstValues.Add(strFootnote);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstValues;
        }

        private void ClearAllControlValues()
        {
            try
            {
                //Indexing comments Controls
                txtNUM_IE.Clear();
                txtPage_IE.Clear();
                txtLine_IE.Clear();
                txtPara_IE.Clear();
                txtColumn_IE.Clear();
                txtTable_IE.Clear();
                txtFigure_IE.Clear();
                txtScheme_IE.Clear();
                txtSheet_IE.Clear();
                txtFootNote_IE.Clear();
                txtComment_IE.Clear();
                
                //Author Error Comments
                txtNUM_AE.Clear();
                chkCorrected_AE.CheckState = CheckState.Unchecked;
                txtPage_AE.Clear();
                txtLine_AE.Clear();
                txtPara_AE.Clear();
                txtColumn_AE.Clear();
                txtTable_AE.Clear();
                txtFigure_AE.Clear();
                txtScheme_AE.Clear();
                txtSheet_AE.Clear();
                txtFootNote_AE.Clear();
                txtComment_AE.Clear();

                //Other Comments Controls
                txtOtherComment.Clear();

                //Temperature & Default comments Controls
                rtxtTempCmts.Clear();
                txtDefaultComments.Clear();

                //CAS consulted for controls
                txtCASComment.Clear();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvComments.DataSource != null)
                {
                   int intComLength = GetCommentsLengthFromCommentsData();//New code on 19th Nov 2013
                   if (intComLength <= 4000)
                   {
                       DataTable dtComments = (DataTable)dgvComments.DataSource;
                       if (dtComments != null)
                       {
                           #region Code Commented
                           ////Get CAS Consulted for Comments from Comments data
                           //string strCASCmnts = GetCommentsFromCommentsData(dtComments, "CAS","~CE");
                           //strCASCmnts = !string.IsNullOrEmpty(strCASCmnts.Trim()) ? "<CE>" + strCASCmnts.Trim() + "</CE>" : strCASCmnts.Trim();

                           ////Get Author Error Comments from Comments data
                           //string strAuthorCmnts = GetCommentsFromCommentsData(dtComments, "AUTHOR", "~AE~");
                           //strAuthorCmnts = !string.IsNullOrEmpty(strAuthorCmnts.Trim()) ? "<AE>" + strAuthorCmnts.Trim() + "</AE>" : strAuthorCmnts.Trim();

                           ////Get Indexing Error Comments from Comments data
                           //string strIndexingCmnts = GetCommentsFromCommentsData(dtComments, "INDEXING", "~IE~");
                           //strIndexingCmnts = !string.IsNullOrEmpty(strIndexingCmnts.Trim()) ? "<IE>" + strIndexingCmnts.Trim() + "</IE>" : strIndexingCmnts.Trim();

                           ////Get Default Comments from Comments Data
                           //string strDefaultCmnts = GetCommentsFromCommentsData(dtComments, "DEFAULT", "~DC~");

                           ////Get Temperature Comments from Comments Data
                           //string strTempratureCmnts = GetCommentsFromCommentsData(dtComments, "TEMPERATURE", "~TC~");

                           ////Get Other Comments from Comments data
                           //string strOtherCmnts = GetCommentsFromCommentsData(dtComments, "OTHER","~OE~");
                           //strOtherCmnts = strDefaultCmnts + "~~" + strTempratureCmnts + "`" + strOtherCmnts;
                           //strOtherCmnts = !string.IsNullOrEmpty(strOtherCmnts.Trim()) ? "<OE>" + strOtherCmnts.Trim() + "</OE>" : strOtherCmnts.Trim();

                           ////Combine all the comments
                           //TANComments = strCASCmnts + strAuthorCmnts + strIndexingCmnts + strOtherCmnts; 
                           #endregion

                           CommentsData = dtComments;
                           DialogResult = DialogResult.OK;
                           this.Close();
                       }
                   }
                   else
                   {
                       MessageBox.Show("Comments maximum length is 4000 characters",GlobalVariables.MessageCaption,MessageBoxButtons.OK,MessageBoxIcon.Error);
                   }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvComments_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                {
                    if (dgvComments.Columns[e.ColumnIndex].HeaderText.ToString().ToUpper() == "DELETE")
                    {
                        if (editRowIndx == 0)
                        {
                            DialogResult diaRes = MessageBox.Show("Do you want to delete the selected comment?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            if (diaRes == DialogResult.Yes)
                            {
                                dgvComments.Rows.RemoveAt(e.RowIndex);
                                DataTable dtComments = (DataTable)dgvComments.DataSource;
                                dtComments.AcceptChanges();
                                CommentsData = dtComments;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Delete is not possible in edit mode", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void Enable_DisableButtonsInEditMode(string commentsType)
        {
            try
            {
                btnAddAECmnt.Enabled = false;
                btnAddIECmnt.Enabled = false;
                btnCASCmnts.Enabled = false;
                btnAddOtherCmnts.Enabled = false;

                switch (commentsType)
                {
                    case "INDEXING":
                        btnAddIECmnt.Enabled = true;
                        break;
                    case "AUTHOR":
                        btnAddAECmnt.Enabled = true;
                        break;
                    case "OTHER":
                        btnAddOtherCmnts.Enabled = true;
                        break;
                    case "CAS":
                        btnCASCmnts.Enabled = true;
                        break;
                    case "ALL"://Refresh button click
                        btnAddAECmnt.Enabled = true;
                        btnAddIECmnt.Enabled = true;                        
                        btnAddOtherCmnts.Enabled = true;
                        if(IsQueryTAN)
                            btnCASCmnts.Enabled = true;
                        break;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        int editRowIndx = 0;
        string selectedTab = "";

        private void dgvComments_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                {
                    //First clear all control values before values binding
                    ClearAllControlValues();

                    editRowIndx = e.RowIndex + 1;
                    string strCommntsType = dgvComments.Rows[e.RowIndex].Cells["colCommentsType"].Value.ToString();
                    string strComments = dgvComments.Rows[e.RowIndex].Cells["colComments"].Value.ToString();
                    selectedTab = strCommntsType;

                    //Enable/Disable Add buttons
                    Enable_DisableButtonsInEditMode(strCommntsType);

                    switch(strCommntsType)
                    {
                        case "OTHER":
                            txtOtherComment.Text = strComments;
                            tcComments.SelectedTab = tpOtherComment;                           
                            break;
                        case "CAS":
                            txtCASComment.Text = strComments;                            
                            tcComments.SelectedTab = tpCASConsulted;     
                            break;
                        case "TEMPERATURE":
                            BindAndFormatTemperatureComments(strComments);
                            tcComments.SelectedTab = tpTemperature;                       
                            break;
                        case "DEFAULT":
                            txtDefaultComments.Text = strComments;                            
                            tcComments.SelectedTab = tpTemperature;                            
                            break;
                        case "INDEXING":
                            //Bind Indexing comments to controls
                            BindIndexing_AuthorCommentsToControls(strComments,"INDEXING");
                            tcComments.SelectedTab = tpIndexError;   
                            //tpIndexError.Select();
                            break;
                        case "AUTHOR":
                            //Bind Author comments to controls
                            BindIndexing_AuthorCommentsToControls(strComments, "AUTHOR");
                            tcComments.SelectedTab = tpAuthorError;   
                            //tpAuthorError.Select();
                            break;                     
                    }                    
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            try
            {
                editRowIndx = 0;
                selectedTab = "";
                ClearAllControlValues();

                Enable_DisableButtonsInEditMode("ALL");
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }    
    }
}
