﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using IndxReactNarrDAL;
using System.Text.RegularExpressions;
using IndxReactNarr.Common;

namespace IndxReactNarr
{
    public partial class frmConditions : Form
    {
        public frmConditions()
        {
            InitializeComponent();
        }

        #region Property Procedures 

        private string _stagename = "";
        public string StageName
        { get
        {
            return _stagename;
        }
            set
            {
                _stagename = value;
                lblStageName.Text = _stagename;
            }
        }

        private string _prev_stagename = "";
        public string PrevStageName
        {
            get
            {
                return _prev_stagename;
            }
            set
            {
                _prev_stagename = value;
                lblPrevStage.Text = _prev_stagename;
            }
        }

        private string _prodnum = "";
        public string ProductNUM
        {
            get
            {
                return _prodnum;
            }
            set
            {
                _prodnum = value;
            }
        }

        private string _tempcomments = "";
        public string Temp_Comments
        {
            get
            {
                return _tempcomments;
            }
            set
            {
                _tempcomments = value;                
            }
        }

        public int RxnStageID
        {
            get;
            set;
        }

        public int ReactionID
        {
            get;
            set;
        }

        public DataTable ConditionsTbl
        { get; set; }

        public DataTable PrevStgCondsTbl
        { get; set; }

        #endregion

        private void frmConditions_Load(object sender, EventArgs e)
        {
            try
            {
                Enable_Disable_Conditions(true);
                
                rbnTemp_None.Checked = true;
                rbnTemp_None.BackColor = Color.FromArgb(255, 192, 128);
                rbnTime_None.Checked = true;
                rbnTime_None.BackColor = Color.FromArgb(255, 192, 128);
                rbnPH_None.Checked = true;
                rbnPH_None.BackColor = Color.FromArgb(255, 192, 128);
                rbnPres_None.Checked = true;
                rbnPres_None.BackColor = Color.FromArgb(255, 192, 128);
                
                if (ConditionsTbl != null)
                {
                    dgvConds.AutoGenerateColumns = false;
                    dgvConds.DataSource = ConditionsTbl;

                    colTemp.DataPropertyName = "TEMPERATURE";
                    colPressure.DataPropertyName = "PRESSURE";
                    colpH.DataPropertyName = "PH";
                    colTime.DataPropertyName = "RC_TIME";

                    colTemp_Type.DataPropertyName = "TEMP_TYPE";
                    colTime_Type.DataPropertyName = "TIME_TYPE";
                    colpH_Type.DataPropertyName = "PH_TYPE";
                    colPres_Type.DataPropertyName = "PRESSURE_TYPE";

                    if (dgvConds.Rows.Count > 0)
                    {
                        //dgvConds.Rows[dgvConds.Rows.Count - 1].Selected = true;
                        dgvConds.CurrentCell = dgvConds.Rows[dgvConds.Rows.Count - 1].Cells[0];
                    }
                }

                if (PrevStgCondsTbl != null)
                {
                    dgvPrevConds.AutoGenerateColumns = false;
                    dgvPrevConds.DataSource = PrevStgCondsTbl;

                    colTemp_PrevStg.DataPropertyName = "TEMPERATURE";
                    colPressure_PrevStg.DataPropertyName = "PRESSURE";
                    colPH_PrevStg.DataPropertyName = "PH";
                    colTime_PrevStg.DataPropertyName = "RC_TIME";
                }
                //Disable mouse scrolling
                DisableMouslWheelEventOnComboBox();   
                
                //Enable Custom controls for Supervisor
                EnableCustomControlsForSupervisor();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        //New validation on 14th May 2013
        private void EnableCustomControlsForSupervisor()
        {
            try
            {
                if (GlobalVariables.RoleName.ToUpper() == RolesMaster.TOOL_MANAGER.ToUpper())
                {
                    rbnCustomTemp.Enabled = true;
                    rbnCustPH.Enabled = true;
                    rbnCustPres.Enabled = true;
                    rbnCustTime.Enabled = true;

                    txtCustTemp.Enabled = true;
                    txtCustPH.Enabled = true;
                    txtCustPres.Enabled = true;
                    txtCustTime.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void DisableMouslWheelEventOnComboBox()
        {
            try
            {
                cmbTemp.MouseWheel += new MouseEventHandler(ComboBoxColumn_MouseWheel);
                cmbTemp_Direct.MouseWheel += new MouseEventHandler(ComboBoxColumn_MouseWheel);
                cmbTemp_PM.MouseWheel += new MouseEventHandler(ComboBoxColumn_MouseWheel);
                cmbTemp_Range.MouseWheel += new MouseEventHandler(ComboBoxColumn_MouseWheel);
                cmbTime.MouseWheel += new MouseEventHandler(ComboBoxColumn_MouseWheel);
                cmbTime_InExact.MouseWheel += new MouseEventHandler(ComboBoxColumn_MouseWheel);

                cmbTime_Range.MouseWheel += new MouseEventHandler(ComboBoxColumn_MouseWheel);
                cmbPressure.MouseWheel += new MouseEventHandler(ComboBoxColumn_MouseWheel);
                cmbPres_Direct.MouseWheel += new MouseEventHandler(ComboBoxColumn_MouseWheel);
                cmbPres_Range.MouseWheel += new MouseEventHandler(ComboBoxColumn_MouseWheel); 
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvConds_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvConds.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvConds.Font);

                if (dgvConds.RowHeadersWidth < (int)(size.Width + 20)) dgvConds.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        int editRowIndx = 0;
        private void dgvConds_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex < 0 || e.RowIndex < 0)
                {
                    return;
                }
                
                if (dgvConds.Columns[e.ColumnIndex].Name == "colEdit")
                {
                    Enable_Disable_Conditions(true);
                    
                    editRowIndx = e.RowIndex + 1;                   
                    
                    string strTemp = dgvConds.Rows[e.RowIndex].Cells["colTemp"].Value.ToString();
                    string strTime = dgvConds.Rows[e.RowIndex].Cells["colTime"].Value != null ? dgvConds.Rows[e.RowIndex].Cells["colTime"].Value.ToString() : "";
                    string strPressure = dgvConds.Rows[e.RowIndex].Cells["colPressure"].Value != null ? dgvConds.Rows[e.RowIndex].Cells["colPressure"].Value.ToString() : "";
                    string strPH = dgvConds.Rows[e.RowIndex].Cells["colPH"].Value.ToString();
                    string strTemp_Type =dgvConds.Rows[e.RowIndex].Cells["colTemp_Type"].Value != null ? dgvConds.Rows[e.RowIndex].Cells["colTemp_Type"].Value.ToString() : "";
                    string strTime_Type =dgvConds.Rows[e.RowIndex].Cells["colTime_Type"].Value != null ? dgvConds.Rows[e.RowIndex].Cells["colTime_Type"].Value.ToString() : "";
                    string strpH_Type = dgvConds.Rows[e.RowIndex].Cells["colPH_Type"].Value != null ? dgvConds.Rows[e.RowIndex].Cells["colPH_Type"].Value.ToString() : "";
                    string strPres_Type = dgvConds.Rows[e.RowIndex].Cells["colPres_Type"].Value != null ? dgvConds.Rows[e.RowIndex].Cells["colPres_Type"].Value.ToString() : "";

                    BindValuesToControls(strTemp, strTime, strPressure, strPH, strTemp_Type, strTime_Type, strPres_Type, strpH_Type);
                }
                else if (dgvConds.Columns[e.ColumnIndex].Name == "colDelete")
                {
                    DialogResult diaRes = MessageBox.Show("Do you want to delete the condition permanently?","Delete Condition",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
                    if (diaRes == DialogResult.Yes)
                    {
                        if (ConditionsTbl.Rows[e.RowIndex]["RC_ID"].ToString() != "")
                        {
                            int intCondID = 0;
                            int.TryParse(ConditionsTbl.Rows[e.RowIndex]["RC_ID"].ToString(), out intCondID);

                            if (intCondID > 0)
                            {
                                if (ReactDB.DeleteReactionParticipant(intCondID, "CONDITION"))
                                {
                                    ////Clear Temperature comments
                                    //if (ConditionsTbl.Rows[e.RowIndex]["Temp_Type"].ToString() == "PLUS_MINUS")
                                    //{
                                    //    Temp_Comments = "";
                                    //}
                                    
                                    ConditionsTbl.Rows[e.RowIndex].Delete();
                                    ConditionsTbl.AcceptChanges();

                                    //Change Display Order in Conditions table
                                    ChangeDisp_Order_In_CondsTable(e.RowIndex, "DELETE");

                                    //If currently editing condition delete
                                    if (editRowIndx > 0)
                                    {
                                        editRowIndx = 0;
                                        ClearAllValues();
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Error in delete condition", "Delete Condition", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnTemp_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnTemp);
                
                if (rbnTemp.Checked)
                {
                    txtTemp.Enabled = true;
                    txtTemp.Text = "";
                    txtTemp.BackColor = Color.FromArgb(255, 192, 128);

                    cmbTemp.Enabled = true;
                    cmbTemp.SelectedIndex = 0;//default is c
                    cmbTemp.BackColor = Color.FromArgb(255, 192, 128);
                }
                else
                {        
                    txtTemp.Enabled = false;
                    txtTemp.Text = "";
                    txtTemp.BackColor = Color.Empty;

                    cmbTemp.SelectedIndex = -1;
                    cmbTemp.Enabled = false;
                    cmbTemp.BackColor = Color.Empty;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnRTemp_X_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnRTemp_X);

                if (rbnRTemp_X.Checked)
                {       
                    txtRTemp_X.Enabled = true;
                    txtRTemp_X.Text = "";
                    txtRTemp_X.BackColor = Color.FromArgb(255, 192, 128);

                    cmbTemp_RTemp_X.Enabled = true;
                    cmbTemp_RTemp_X.SelectedIndex = 0;//default is c
                    cmbTemp_RTemp_X.BackColor = Color.FromArgb(255, 192, 128);
                }
                else
                {
                    txtRTemp_X.BackColor = Color.Empty;
                    txtRTemp_X.Enabled = false;
                    txtRTemp_X.Text = "";

                    cmbTemp_RTemp_X.Enabled = false;
                    cmbTemp_RTemp_X.SelectedIndex = -1;                    
                    cmbTemp_RTemp_X.BackColor = Color.Empty;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnX_RTemp_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnX_RTemp);
                
                if (rbnX_RTemp.Checked)
                {         
                    txtX_RTemp.Enabled = true;
                    txtX_RTemp.Text = "";
                    txtX_RTemp.BackColor = Color.FromArgb(255, 192, 128);
                    lblX_RTemp.BackColor = Color.FromArgb(255, 192, 128);

                    cmbTemp_X_RTemp.Enabled = true;
                    cmbTemp_X_RTemp.SelectedIndex = 0;//default is c
                    cmbTemp_X_RTemp.BackColor = Color.FromArgb(255, 192, 128);
                }
                else
                {
                    txtX_RTemp.Enabled = false;
                    txtX_RTemp.Text = "";
                    txtX_RTemp.BackColor = Color.Empty;
                    lblX_RTemp.BackColor = Color.Empty;

                    cmbTemp_X_RTemp.Enabled = false;
                    cmbTemp_X_RTemp.SelectedIndex = -1;
                    cmbTemp_X_RTemp.BackColor = Color.Empty;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnReflux_X_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnReflux_X);

                if (rbnReflux_X.Checked)
                {
                    txtReflux_X.Enabled = true;
                    txtReflux_X.Text = "";
                    txtReflux_X.BackColor = Color.FromArgb(255, 192, 128);

                    cmbTemp_Ref_X.Enabled = true;
                    cmbTemp_Ref_X.SelectedIndex = 0;//default is c
                    cmbTemp_Ref_X.BackColor = Color.FromArgb(255, 192, 128);
                }
                else
                {
                    txtReflux_X.Enabled = false;
                    txtReflux_X.Text = "";
                    txtReflux_X.BackColor = Color.Empty;

                    cmbTemp_Ref_X.Enabled = false;
                    cmbTemp_Ref_X.SelectedIndex = -1;
                    cmbTemp_Ref_X.BackColor = Color.Empty;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnX_Reflux_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnX_Reflux);

                if (rbnX_Reflux.Checked)
                {
                    txtX_Reflux.Enabled = true;
                    txtX_Reflux.Text = "";
                    txtX_Reflux.BackColor = Color.FromArgb(255, 192, 128);

                    cmbTemp_X_Ref.Enabled = true;
                    cmbTemp_X_Ref.SelectedIndex = 0;//default is c
                    cmbTemp_X_Ref.BackColor = Color.FromArgb(255, 192, 128);
                }
                else
                {
                    txtX_Reflux.Enabled = false;
                    txtX_Reflux.Text = "";
                    txtX_Reflux.BackColor = Color.Empty;

                    cmbTemp_X_Ref.Enabled = false;
                    cmbTemp_X_Ref.SelectedIndex = -1;
                    cmbTemp_X_Ref.BackColor = Color.Empty;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnDirectnal_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnDirectnal);

                if (rbnDirectnal.Checked)
                {
                    txtDirect_From.Enabled = true;
                    txtDirect_From.Text = "";
                    txtDirect_From.BackColor = Color.FromArgb(255, 192, 128);

                    txtDirect_To.Enabled = true;
                    txtDirect_To.Text = "";
                    txtDirect_To.BackColor = Color.FromArgb(255, 192, 128);

                    cmbTemp_Direct.Enabled = true;
                    cmbTemp_Direct.Text = "c";
                    cmbTemp_Direct.BackColor = Color.FromArgb(255, 192, 128);
                }
                else
                {
                    txtDirect_From.Enabled = false;
                    txtDirect_From.Text = "";
                    txtDirect_From.BackColor = Color.Empty;

                    txtDirect_To.Enabled = false;
                    txtDirect_To.Text = "";
                    txtDirect_To.BackColor = Color.Empty;

                    cmbTemp_Direct.Enabled = false;
                    cmbTemp_Direct.SelectedIndex = -1;
                    cmbTemp_Direct.BackColor = Color.Empty;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnTemp_Range_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnTemp_Range);
                
                if (rbnTemp_Range.Checked)
                {
                    txtRange_From.Enabled = true;
                    txtRange_From.Text = "";
                    txtRange_From.BackColor = Color.FromArgb(255, 192, 128);

                    txtRange_To.Enabled = true;
                    txtRange_To.Text = "";
                    txtRange_To.BackColor = Color.FromArgb(255, 192, 128);

                    cmbTemp_Range.Enabled = true;
                    cmbTemp_Range.Text = "c";
                    cmbTemp_Range.BackColor = Color.FromArgb(255, 192, 128);
                }
                else
                {
                    txtRange_From.Enabled = false;
                    txtRange_From.Text = "";
                    txtRange_From.BackColor = Color.Empty;

                    txtRange_To.Enabled = false;
                    txtRange_To.Text = "";
                    txtRange_To.BackColor = Color.Empty;

                    cmbTemp_Range.Enabled = false;
                    cmbTemp_Range.SelectedIndex = -1;
                    cmbTemp_Range.BackColor = Color.Empty;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnTemp_Plus_Minus_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnTemp_Plus_Minus);
                
                if (rbnTemp_Plus_Minus.Checked)
                {
                    txtTemp_PM_From.Enabled = true;
                    txtTemp_PM_From.Text = "";
                    txtTemp_PM_From.BackColor = Color.FromArgb(255, 192, 128);

                    txtTemp_PM_To.Enabled = true;
                    txtTemp_PM_To.Text = "";
                    txtTemp_PM_To.BackColor = Color.FromArgb(255, 192, 128);

                    cmbTemp_PM.Enabled = true;
                    cmbTemp_PM.Text = "c";
                    cmbTemp_PM.BackColor = Color.FromArgb(255, 192, 128);
                }
                else
                {            
                    txtTemp_PM_From.Enabled = false;
                    txtTemp_PM_From.Text = "";
                    txtTemp_PM_From.BackColor = Color.Empty;

                    txtTemp_PM_To.Enabled = false;
                    txtTemp_PM_To.Text = "";
                    txtTemp_PM_To.BackColor = Color.Empty;

                    cmbTemp_PM.Enabled = false;
                    cmbTemp_PM.SelectedIndex = -1;
                    cmbTemp_PM.BackColor = Color.Empty;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnEqual_Temp_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnEqual_Temp);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        } 

        private void rbnCustomTemp_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnCustomTemp);
                
                if (rbnCustomTemp.Checked)
                {
                    txtCustTemp.Enabled = true;
                    txtCustTemp.Text = "";
                    txtCustTemp.BackColor = Color.FromArgb(255, 192, 128);
                }
                else
                {
                    txtCustTemp.Enabled = false;
                    txtCustTemp.Text = "";
                    txtCustTemp.BackColor = Color.Empty;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnCool_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnCool);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnRoomTemp_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnRoomTemp);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnReflux_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnReflux);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnHeated_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnHeated);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnRTemp_Reflx_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnRTemp_Reflx);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnReflx_RTemp_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnReflx_RTemp);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnLtn_RTemp_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnLtn_RTemp);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnGrt_RTemp_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnGrt_RTemp);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnTemp_None_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
              ColorRadioButton(rbnTemp_None);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnTime_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnTime);
                
                if (rbnTime.Checked)
                {         
                    txtTime.Enabled = true;
                    txtTime.Text = "";
                    txtTime.BackColor = Color.FromArgb(255, 192, 128); 

                    cmbTime.Enabled = true;
                    cmbTime.Text = "h";
                    cmbTime.BackColor = Color.FromArgb(255, 192, 128);
                }
                else
                {
                    txtTime.Enabled = false;
                    txtTime.Text = "";
                    txtTime.BackColor = Color.Empty;

                    cmbTime.Enabled = false;
                    cmbTime.SelectedIndex = -1;
                    cmbTime.BackColor = Color.Empty;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnTime_Range_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnTime_Range);
                
                if (rbnTime_Range.Checked)
                {
                    txtTime_From.Enabled = true;
                    txtTime_From.Text = "";
                    txtTime_From.BackColor = Color.FromArgb(255, 192, 128);

                    txtTime_To.Enabled = true;
                    txtTime_To.Text = "";                    
                    txtTime_To.BackColor = Color.FromArgb(255, 192, 128); 

                    cmbTime_Range.Enabled = true;
                    cmbTime_Range.Text = "h";
                    cmbTime_Range.BackColor = Color.FromArgb(255, 192, 128); 
                }
                else
                {
                    txtTime_From.Text = "";
                    txtTime_From.Enabled = false;
                    txtTime_From.BackColor = Color.Empty;
                    
                    txtTime_To.Text = "";
                    txtTime_To.Enabled = false;
                    txtTime_To.BackColor = Color.Empty;

                    cmbTime_Range.Enabled = false;
                    cmbTime_Range.SelectedIndex = -1;
                    cmbTime_Range.BackColor = Color.Empty;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnTime_InExact_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnTime_InExact);
                
                if (rbnTime_InExact.Checked)
                {
                    cmbTime_InExact.Enabled = true;
                    cmbTime_InExact.Text = "few hours";
                    cmbTime_InExact.BackColor = Color.FromArgb(255, 192, 128); 
                }
                else
                {
                    cmbTime_InExact.Enabled = false;
                    cmbTime_InExact.SelectedIndex = -1;
                    cmbTime_InExact.BackColor = Color.Empty;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnTime_OvrN_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnTime_OvrN);                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnEqual_Time_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnEqual_Time);  
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnTime_None_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
               ColorRadioButton(rbnTime_None);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnCustTime_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnCustTime); 
                
                if (rbnCustTime.Checked)
                {
                    txtCustTime.Enabled = true;
                    txtCustTime.Text = "";
                    txtCustTime.BackColor = Color.FromArgb(255, 192, 128);
                }
                else
                {
                    txtCustTime.Enabled = false;
                    txtCustTime.Text = "";
                    txtCustTime.BackColor = Color.Empty;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnPH_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnPH);

                if (rbnPH.Checked)
                {          
                    txtPH.Enabled = true;
                    txtPH.Text = "";
                    txtPH.BackColor = Color.FromArgb(255, 192, 128); 
                }
                else
                {
                    txtPH.Enabled = false;
                    txtPH.Text = "";
                    txtPH.BackColor = Color.Empty; 
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnPH_Range_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnPH_Range);
                
                if (rbnPH_Range.Checked)
                {
                    txtPH_From.Enabled = true;
                    txtPH_From.Text = "";
                    txtPH_From.BackColor = Color.FromArgb(255, 192, 128); 

                    txtPH_To.Enabled = true;
                    txtPH_To.Text = "";
                    txtPH_To.BackColor = Color.FromArgb(255, 192, 128); 
                }
                else
                {
                    txtPH_From.Enabled = false;
                    txtPH_From.Text = "";
                    txtPH_From.BackColor = Color.Empty; 

                    txtPH_To.Enabled = false;
                    txtPH_To.Text = "";
                    txtPH_To.BackColor = Color.Empty; 
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnCustPH_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnCustPH);
                
                if (rbnCustPH.Checked)
                {
                    txtCustPH.Enabled = true;
                    txtCustPH.Text = "";
                    txtCustPH.BackColor = Color.FromArgb(255, 192, 128); 
                }
                else
                {
                    txtCustPH.Enabled = false;
                    txtCustPH.Text = "";
                    txtCustPH.BackColor = Color.Empty;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnEqual_pH_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnEqual_pH);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnpH_Acid_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnpH_Acid);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnpH_Basic_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnpH_Basic);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnpH_Nutral_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnpH_Nutral);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnPH_None_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
              ColorRadioButton(rbnPH_None);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnPressure_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnPressure);
                
                if (rbnPressure.Checked)
                {
                    txtPressure.Enabled = true;
                    txtPressure.Text = "";
                    txtPressure.BackColor = Color.FromArgb(255, 192, 128); 

                    cmbPressure.Enabled = true;
                    cmbPressure.Text = "a";
                    cmbPressure.BackColor = Color.FromArgb(255, 192, 128); 
                }
                else
                {
                    txtPressure.Enabled = false;
                    txtPressure.Text = "";
                    txtPressure.BackColor = Color.Empty;

                    cmbPressure.Enabled = false;
                    cmbPressure.SelectedIndex = -1;
                    cmbPressure.BackColor = Color.Empty;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       

        private void rbnPres_Range_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnPres_Range);
                
                if (rbnPres_Range.Checked)
                {
                    txtPres_From.Enabled = true;
                    txtPres_From.Text = "";
                    txtPres_From.BackColor = Color.FromArgb(255, 192, 128);

                    txtPres_To.Enabled = true;
                    txtPres_To.Text = "";
                    txtPres_To.BackColor = Color.FromArgb(255, 192, 128);

                    cmbPres_Range.Enabled = true;
                    cmbPres_Range.Text = "a";
                    cmbPres_Range.BackColor = Color.FromArgb(255, 192, 128);
                }
                else
                {
                    txtPres_From.Enabled = false;
                    txtPres_From.Text = "";
                    txtPres_From.BackColor = Color.Empty;

                    txtPres_To.Enabled = false;
                    txtPres_To.Text = "";
                    txtPres_To.BackColor = Color.Empty;

                    cmbPres_Range.Enabled = false;
                    cmbPres_Range.SelectedIndex = -1;
                    cmbPres_Range.BackColor = Color.Empty;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        

        private void rbnPres_Direct_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnPres_Direct);
                
                if (rbnPres_Direct.Checked)
                {
                    txtPres_D_From.Enabled = true;
                    txtPres_D_From.Text = "";
                    txtPres_D_From.BackColor = Color.FromArgb(255, 192, 128); 

                    txtPres_D_To.Enabled = true;
                    txtPres_D_To.Text = "";
                    txtPres_D_To.BackColor = Color.FromArgb(255, 192, 128); 

                    cmbPres_Direct.Enabled = true;
                    cmbPres_Direct.Text = "a";
                    cmbPres_Direct.BackColor = Color.FromArgb(255, 192, 128); 
                }
                else
                {
                    txtPres_D_From.Enabled = false;
                    txtPres_D_From.Text = "";
                    txtPres_D_From.BackColor = Color.Empty;

                    txtPres_D_To.Enabled = false;
                    txtPres_D_To.Text = "";
                    txtPres_D_To.BackColor = Color.Empty;

                    cmbPres_Direct.Enabled = false;
                    cmbPres_Direct.SelectedIndex = -1;
                    cmbPres_Direct.BackColor = Color.Empty;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnEqual_Pres_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnEqual_Pres);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnCustPres_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ColorRadioButton(rbnCustPres);
                
                if (rbnCustPres.Checked)
                {
                    txtCustPres.Enabled = true;
                    txtCustPres.BackColor = Color.FromArgb(255, 192, 128); 
                    txtCustPres.Text = "";
                }
                else
                {
                    txtCustPres.Enabled = false;
                    txtCustPres.BackColor = Color.Empty;
                    txtCustPres.Text = "";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void rbnPres_None_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
               ColorRadioButton(rbnPres_None);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtTemp_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                //BKSP-8,--45,.-46, <-60,>-62
                if (e.KeyChar == 8 || e.KeyChar == 45 || e.KeyChar == 46 || e.KeyChar == 60 || e.KeyChar == 62 || (e.KeyChar >= 48 && e.KeyChar <= 57) != false)
                {
                    e.Handled = false;
                }
                else
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtTemp_Range_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                //BKSP-8,--45,.-46, <-60,>-62
                if (e.KeyChar == 8 || e.KeyChar == 45 || e.KeyChar == 46 || e.KeyChar == 60 || e.KeyChar == 62 || (e.KeyChar >= 48 && e.KeyChar <= 57) != false)
                {
                    e.Handled = false;
                }
                else
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtTime_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                // 8-BKSP,--45,m-109,s-115,d-100,w-119,o-111,<-60,>-62,.-46,0-48,9-57                
                if (e.KeyChar == 8 || e.KeyChar == 45 || e.KeyChar == 46 || e.KeyChar == 60 || e.KeyChar == 62 || (e.KeyChar >= 48 && e.KeyChar <= 57) != false)
                {
                    e.Handled = false;
                    //if (e.KeyChar == 48)
                    //{
                    //    MessageBox.Show("0 for ZERO", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    //}
                }
                else
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtTime_Range_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                // 8-BKSP,--45,m-109,s-115,d-100,w-119,o-111,<-60,>-62,.-46,0-48,9-57                
                if (e.KeyChar == 8 || e.KeyChar == 45 || e.KeyChar == 46 || e.KeyChar == 60 || e.KeyChar == 62 || (e.KeyChar >= 48 && e.KeyChar <= 57) != false)
                {
                    e.Handled = false;
                    //if (e.KeyChar == 48)
                    //{
                    //    MessageBox.Show("0 for ZERO", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    //}
                }
                else
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtPressure_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                // 8-BKSP,-45,a-97,b-98,<-60,>-62,.-46, 0-48 ,9-57,=-61,]-93
                if (e.KeyChar == 8 || e.KeyChar == 45 || e.KeyChar == 46 || e.KeyChar == 60 || e.KeyChar == 62 || (e.KeyChar >= 48 && e.KeyChar <= 57) != false)
                {
                    e.Handled = false;
                }
                else
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtPressure_Range_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                // 8-BKSP,-45,a-97,b-98,<-60,>-62,.-46, 0-48 ,9-57,=-61,]-93
                if (e.KeyChar == 8 || e.KeyChar == 45 || e.KeyChar == 46 || e.KeyChar == 60 || e.KeyChar == 62 || (e.KeyChar >= 48 && e.KeyChar <= 57) != false)
                {
                    e.Handled = false;
                }
                else
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtPH_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                // BKSP-8,--45,a-97,b-98,<-60,>-62,.-46,n-110, 0-48 ,9-57
                if (e.KeyChar == 8 || e.KeyChar == 45 || e.KeyChar == 46 || e.KeyChar == 60 || e.KeyChar == 62 || (e.KeyChar >= 48 && e.KeyChar <= 57) != false)
                {
                    e.Handled = false;
                }
                else
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void ComboBoxColumn_MouseWheel(object sender, EventArgs e)
        {
            HandledMouseEventArgs ee = (HandledMouseEventArgs)e;
            ee.Handled = true;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                //Enable_Disable_Conditions(false);
                
                rbnTemp_None.Checked = true;
                rbnTime_None.Checked = true;
                rbnPH_None.Checked = true;
                rbnPres_None.Checked = true;

                dgvConds.Rows[editRowIndx - 1].Cells["colEdit"].Selected = false;
                editRowIndx = 0;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }                      
        
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {                
                string strErrMsg = "";
                if (ValidateUserInputs(out strErrMsg))
                {
                    if (CheckTime_TempValidations())//Time-Temperature Validation
                    {
                        string tempType = "";
                        string timeType = "";
                        string pHType = "";
                        string presType = "";
                        string strTemp = GetSelectedTemperature(out tempType);
                        string strTime = GetSelectedTime(out timeType);
                        string strPH = GetSelectedPH(out pHType);
                        string strPres = GetSelectedPressure(out presType);

                        insertOption = "AFTER";
                        insertRowIndx = 1;

                        int chkRIndx = 0;

                        if (dgvConds.CurrentRow != null)
                        {
                            chkRIndx = dgvConds.CurrentRow.Index;
                            
                            if (dgvConds.CurrentRow.Index <= 1)
                            {
                                insertRowIndx = dgvConds.CurrentRow.Index + 2;                               
                            }
                            else
                            {
                                insertRowIndx = dgvConds.CurrentRow.Index + 2;                                
                            }
                        }

                        //Validate againist given Condition validations
                        if (ValidateConditions(strTemp, strTime, strPH, strPres, chkRIndx, out strErrMsg))
                        {
                            if (editRowIndx == 0)
                            {
                                //int intNewCondID = CASRxnDataAccess.Insert_Get_RxnNewParticipantID("CONDITIONS", StageID, insertRowIndx, insertOption, GlobalVariables.URID);

                                int intNewCondID = ReactDB.GetReactionNewParticipantID("CONDITIONS", ReactionID, RxnStageID, insertRowIndx, insertOption, GlobalVariables.URID);
                                if (intNewCondID > 0)
                                {
                                    if (ConditionsTbl == null)
                                    {
                                        ConditionsTbl = Create_Rxn_ConditionTable();
                                    }
                                                                        
                                    DataRow drCon = ConditionsTbl.NewRow();
                                    //drCon["RXN_ID"] = ReactionID;
                                    drCon["RXN_STAGE_ID"] = RxnStageID;
                                    drCon["RC_ID"] = intNewCondID;
                                    drCon["TEMPERATURE"] = strTemp;
                                    drCon["RC_TIME"] = strTime;
                                    drCon["PH"] = strPH;
                                    drCon["PRESSURE"] = strPres;

                                    drCon["TEMP_TYPE"] = tempType;
                                    drCon["TIME_TYPE"] = timeType;
                                    drCon["PH_TYPE"] = pHType;
                                    drCon["PRESSURE_TYPE"] = presType;
                                    drCon["DISPLAY_ORDER"] = insertRowIndx;

                                    if (insertOption == "AFTER")
                                    {                                        
                                        ConditionsTbl.Rows.InsertAt(drCon, insertRowIndx - 1);

                                        if (dgvConds.Rows.Count > 1)
                                        {
                                            dgvConds.CurrentCell = dgvConds.Rows[dgvConds.Rows.Count - 1].Cells[0];
                                        }
                                    }
                                    #region Code Commented
                                    //}
                                    //else
                                    //{
                                    //    ConditionsTbl = Create_Rxn_ConditionTable();
                                    //    DataRow drCon = ConditionsTbl.NewRow();
                                    //    drCon["reaction_id"] = ReactionID;
                                    //    drCon["rxn_stage_id"] = StageID;
                                    //    drCon["id"] = intNewCondID;
                                    //    drCon["temperature"] = strTemp;
                                    //    drCon["time"] = strTime;
                                    //    drCon["ph"] = strPH;
                                    //    drCon["pressure"] = strPres;

                                    //    drCon["temp_type"] = tempType;
                                    //    drCon["time_type"] = timeType;
                                    //    drCon["ph_type"] = pHType;
                                    //    drCon["pressure_type"] = presType;

                                    //    if (insertOption == "AFTER")
                                    //    {
                                    //        drCon["display_order"] = insertRowIndx;
                                    //        ConditionsTbl.Rows.InsertAt(drCon, insertRowIndx - 1);

                                    //        if (dgvConds.Rows.Count > 1)
                                    //        {
                                    //            dgvConds.CurrentCell = dgvConds.Rows[dgvConds.Rows.Count - 1].Cells[0];
                                    //        } 
                                    //    }                                                              
                                    //} 
                                    #endregion

                                    //Change display order in Conditions table
                                    ChangeDisp_Order_In_CondsTable(insertRowIndx, insertOption);

                                    //Clear all values once add is clicked
                                    ClearAllValues();

                                    //Enable_Disable_Conditions(false);
                                }
                            }
                            else
                            {
                                ConditionsTbl.Rows[editRowIndx - 1]["TEMPERATURE"] = strTemp;
                                ConditionsTbl.Rows[editRowIndx - 1]["RC_TIME"] = strTime;
                                ConditionsTbl.Rows[editRowIndx - 1]["PH"] = strPH;
                                ConditionsTbl.Rows[editRowIndx - 1]["PRESSURE"] = strPres;

                                ConditionsTbl.Rows[editRowIndx - 1]["TEMP_TYPE"] = tempType;
                                ConditionsTbl.Rows[editRowIndx - 1]["TIME_TYPE"] = timeType;
                                ConditionsTbl.Rows[editRowIndx - 1]["PH_TYPE"] = pHType;
                                ConditionsTbl.Rows[editRowIndx - 1]["PRESSURE_TYPE"] = presType;
                                ConditionsTbl.AcceptChanges();

                                editRowIndx = 0;

                                //Clear all values once add is clicked
                                ClearAllValues();

                                //Enable_Disable_Conditions(false);
                            }
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(strErrMsg.Trim()))
                            {
                                MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
                else
                {
                    if (!string.IsNullOrEmpty(strErrMsg.Trim()))
                    {
                        MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void ColorRadioButton(RadioButton _selrbn)
        {
            try
            {
                if (_selrbn.Checked)
                {
                    _selrbn.BackColor = Color.FromArgb(255, 192, 128);
                }
                else
                {
                    _selrbn.BackColor = Color.Transparent;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private DataTable Create_Rxn_ConditionTable()
        {
            DataTable dtConditions = new DataTable();
            try
            {
                dtConditions.Columns.Add("RC_ID", typeof(Int32));
                dtConditions.Columns.Add("RXN_STAGE_ID", typeof(Int32));
                dtConditions.Columns.Add("TEMPERATURE", typeof(string));
                dtConditions.Columns.Add("PRESSURE", typeof(string));
                dtConditions.Columns.Add("PH", typeof(string));
                dtConditions.Columns.Add("RC_TIME", typeof(string));
                dtConditions.Columns.Add("TEMP_TYPE", typeof(string));
                dtConditions.Columns.Add("PRESSURE_TYPE", typeof(string));
                dtConditions.Columns.Add("PH_TYPE", typeof(string));
                dtConditions.Columns.Add("TIME_TYPE", typeof(string));
                dtConditions.Columns.Add("DISPLAY_ORDER", typeof(string));

                return dtConditions;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtConditions;
        }

        private bool ValidateUserInputs(out string _errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                //Temperature validation
                if (rbnTemp.Checked)
                {
                    if (string.IsNullOrEmpty(txtTemp.Text.Trim()))
                    {
                        strErrMsg = "Temperature can't be empty";
                        blStatus = false;
                    }
                    else
                    {
                        bool blTemp = IsValidNumber(txtTemp.Text.Trim());
                        if (blTemp == false)
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "In-Valid Temperature value";
                        }
                    }
                }
                else if (rbnRTemp_X.Checked)
                {
                    if (string.IsNullOrEmpty(txtRTemp_X.Text.Trim()))
                    {
                        strErrMsg = "Temperature can't be empty";
                        blStatus = false;
                    }
                    else
                    {
                       string strTUnits = "";
                       string strTemp = "";
                       strTemp = GetTemperatureAndUnitsFromString(txtRTemp_X.Text.Trim(), out strTUnits);
                       bool blTemp_X = IsValidNumber(strTemp);
                       if (blTemp_X == false)
                       {
                           blStatus = false;
                           strErrMsg = strErrMsg.Trim() + "\r\n" + "In-Valid Temperature value";
                       }
                    }
                }
                else if (rbnX_RTemp.Checked)
                {
                    if (string.IsNullOrEmpty(txtX_RTemp.Text.Trim()))
                    {
                        strErrMsg = "Temperature can't be empty";
                        blStatus = false;
                    }
                    else
                    {
                        bool blX_Temp = IsValidNumber(txtX_RTemp.Text.Trim());
                        if (blX_Temp == false)
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "In-Valid Temperature value";
                        }
                    }
                }
                else if (rbnReflux_X.Checked)
                {
                    if (string.IsNullOrEmpty(txtReflux_X.Text.Trim()))
                    {
                        strErrMsg = "Temperature can't be empty";
                        blStatus = false;
                    }
                    else
                    {
                        bool blRef_X = IsValidNumber(txtReflux_X.Text.Trim());
                        if (blRef_X == false)
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "In-Valid Temperature value";
                        }
                    }
                }
                else if (rbnX_Reflux.Checked)
                {
                    if (string.IsNullOrEmpty(txtX_Reflux.Text.Trim() ))
                    {
                        strErrMsg = "Temperature can't be empty";
                        blStatus = false;
                    }
                    else
                    {
                        bool blX_Ref = IsValidNumber(txtX_Reflux.Text.Trim());
                        if (blX_Ref == false)
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "In-Valid Temperature value";
                        }
                    }
                }
                else if (rbnDirectnal.Checked)
                {
                    if (string.IsNullOrEmpty(txtDirect_From.Text.Trim()) || string.IsNullOrEmpty(txtDirect_To.Text.Trim()))
                    {
                        strErrMsg = "Temperature Directional values can't be empty";
                        blStatus = false;
                    }
                    else if(txtDirect_From.Text.Trim() != "" && txtDirect_To.Text.Trim() != "")
                    {
                        if (txtDirect_From.Text.Trim() == txtDirect_To.Text.Trim())
                        {
                            strErrMsg = "Temperature Directional values can't be same";
                            blStatus = false;
                        }
                        else if ((txtDirect_From.Text.Trim() == "0" && txtDirect_To.Text.Trim() == "-0")
                            || (txtDirect_From.Text.Trim() == "-0" && txtDirect_To.Text.Trim() == "0"))
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Temperature Directional values are In-Valid";
                        }
                        else if (txtDirect_From.Text.Trim().Contains(">") || txtDirect_From.Text.Trim().Contains("<") ||
                                txtDirect_To.Text.Trim().Contains(">") || txtDirect_To.Text.Trim().Contains("<"))//New validation on 14th May 2013
                        {
                            strErrMsg = "> and < symbols not allowed in Temperature Directional values";
                            blStatus = false;
                        }
                        else
                        {
                            bool blD_From = IsValidNumber(txtDirect_From.Text.Trim());
                            bool blD_To = IsValidNumber(txtDirect_To.Text.Trim());

                            if (blD_From == false || blD_To == false)
                            {
                                strErrMsg = "Temperature Directional values are In-Valid";
                                blStatus = false;
                            }
                        }
                    }
                }
                else if (rbnTemp_Range.Checked)
                {
                    if (string.IsNullOrEmpty(txtRange_From.Text.Trim()) || string.IsNullOrEmpty(txtRange_To.Text.Trim()))
                    {
                        strErrMsg = "Temperature Range values can't be empty";
                        blStatus = false;
                    }
                    else if (txtRange_From.Text.Trim() != "" && txtRange_To.Text.Trim() != "")
                    {
                        if (txtRange_From.Text.Trim() == txtRange_To.Text.Trim())
                        {
                            strErrMsg = "Temperature Range values can't be same";
                            blStatus = false;
                        }
                        else if ((txtRange_From.Text.Trim() == "0" && txtRange_To.Text.Trim() == "-0")
                            || (txtRange_From.Text.Trim() == "-0" && txtRange_To.Text.Trim() == "0"))
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Temperature Range values are In-Valid";
                        }
                        else if (txtRange_From.Text.Trim().Contains(">") || txtRange_From.Text.Trim().Contains("<") ||
                                txtRange_To.Text.Trim().Contains(">") || txtRange_To.Text.Trim().Contains("<"))//New validation on 14th May 2013
                        {
                            strErrMsg = "> and < symbols not allowed in Temperature Range values";
                            blStatus = false;
                        }
                        else
                        {
                            bool blR_From = IsValidNumber(txtRange_From.Text.Trim());
                            bool blR_To = IsValidNumber(txtRange_To.Text.Trim());

                            if (blR_From == false || blR_To == false)
                            {
                                strErrMsg = "Temperature Range values are In-Valid";
                                blStatus = false;
                            }

                            //New validation on 14th May 2013 - From value < To value
                            double dblFromVal = 0;
                            double.TryParse(txtRange_From.Text.Trim(), out dblFromVal);

                            double dblToVal = 0;
                            double.TryParse(txtRange_To.Text.Trim(), out dblToVal);

                            if (dblToVal < dblFromVal)
                            {
                                strErrMsg = "Temperature Range From value should be < To value";
                                blStatus = false;
                            }
                        }
                    }
                }
                else if (rbnTemp_Plus_Minus.Checked)
                {
                    if (string.IsNullOrEmpty(txtTemp_PM_From.Text.Trim()) ||string.IsNullOrEmpty(txtTemp_PM_To.Text.Trim() ))
                    {
                        strErrMsg = "Temperature +/-  values can't be empty";
                        blStatus = false;
                    }
                    else if (txtTemp_PM_From.Text.Trim() != "" && txtTemp_PM_To.Text.Trim() != "")
                    {
                        if (txtTemp_PM_From.Text.Trim() == txtTemp_PM_To.Text.Trim())
                        {
                            strErrMsg = "Temperature +/- values can't be same";
                            blStatus = false;
                        }
                        else if ((txtTemp_PM_From.Text.Trim() == "0" && txtTemp_PM_To.Text.Trim() == "-0")
                            || (txtTemp_PM_From.Text.Trim() == "-0" && txtTemp_PM_To.Text.Trim() == "0"))
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Temperature +/- values are In-Valid";
                        }
                        else
                        {
                            bool blPM_From = IsValidNumber(txtTemp_PM_From.Text.Trim());
                            bool blPM_To = IsValidNumber(txtTemp_PM_To.Text.Trim());

                            if (blPM_From == false || blPM_To == false)
                            {
                                strErrMsg = "Temperature +/- values are In-Valid";
                                blStatus = false;
                            }
                        }
                    }
                }
                else if (rbnCustomTemp.Checked)
                {
                    if (string.IsNullOrEmpty(txtCustTemp.Text.Trim()))
                    {
                        strErrMsg = "Temperature can't be empty";
                        blStatus = false;
                    }
                }

                //Time validation
                if (rbnTime.Checked)
                {
                    if (string.IsNullOrEmpty(txtTime.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Time can't be empty";
                        blStatus = false;
                    }
                    else
                    {
                        bool blTime = IsValidNumber(txtTime.Text.Trim());
                        if (blTime == false)
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Time value is In-Valid";
                        }

                        double dblTimeVal = 0;
                        double.TryParse(txtTime.Text.Trim(), out dblTimeVal);
                        if (dblTimeVal < 0)
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Time value should be > 0";
                        }
                    }
                }
                else if (rbnTime_Range.Checked)
                {
                    if (txtTime_From.Text.Trim() == "" || txtTime_To.Text.Trim() == "")
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Time Range values can't be empty";
                        blStatus = false;
                    }
                    else if (txtTime_From.Text.Trim() != "" || txtTime_To.Text.Trim() != "")
                    {
                        if (txtTime_From.Text.Trim() == txtTime_To.Text.Trim())
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Time Range values can't be same";
                        }
                        else if ((txtTime_From.Text.Trim() == "0" && txtTime_To.Text.Trim() == "-0")
                            || (txtTime_From.Text.Trim() == "-0" && txtTime_To.Text.Trim() == "0"))
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Time Range values are In-Valid";
                        }
                        else if (txtTime_From.Text.Trim().Contains(">") || txtTime_From.Text.Trim().Contains("<") ||
                                txtTime_To.Text.Trim().Contains(">") || txtTime_To.Text.Trim().Contains("<"))//New validation on 14th May 2013
                        {
                            strErrMsg = "> and < symbols not allowed in Time Range values";
                            blStatus = false;
                        }
                        else
                        {
                            bool blTime_From = IsValidNumber(txtTime_From.Text.Trim());
                            bool blTime_To = IsValidNumber(txtTime_To.Text.Trim());

                            if (blTime_From == false || blTime_To == false)
                            {
                                blStatus = false;
                                strErrMsg = strErrMsg.Trim() + "\r\n" + "Time Range values are In-Valid";
                            }

                            double dblFromTimeVal = 0;
                            double dblToTimeVal = 0;
                            double.TryParse(txtTime_From.Text.Trim(), out dblFromTimeVal);
                            double.TryParse(txtTime_To.Text.Trim(), out dblToTimeVal);
                            if (dblFromTimeVal < 0 || dblToTimeVal < 0)
                            {
                                blStatus = false;
                                strErrMsg = strErrMsg.Trim() + "\r\n" + "Time value should be > 0";
                            }
                        }
                    }
                }
                else if (rbnCustTime.Checked)
                {
                    if (string.IsNullOrEmpty(txtCustTime.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Time Custom value can't be empty";
                        blStatus = false;
                    }
                }

                //pH validation
                if (rbnPH.Checked)
                {
                    if (string.IsNullOrEmpty(txtPH.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "pH can't be empty";
                        blStatus = false;
                    }
                    else
                    {
                        double dblPH = 0;
                        double.TryParse(txtPH.Text.Trim(), out dblPH);
                        if (dblPH > 0)
                        {
                            if (dblPH > 14)
                            {
                                strErrMsg = strErrMsg.Trim() + "\r\n" + "pH should be in the range of >= 0 and <= 14";
                                blStatus = false;
                            }
                        }                       
                        else // > or < validation
                        {
                            bool blPH = IsValidNumber(txtPH.Text.Trim());
                            if (blPH == false)
                            {
                                blStatus = false;
                                strErrMsg = strErrMsg.Trim() + "\r\n" + "pH value is In-Valid";
                            }
                        }
                    }
                }
                else if (rbnPH_Range.Checked)
                {
                    if (string.IsNullOrEmpty(txtPH_From.Text.Trim()) || string.IsNullOrEmpty(txtPH_To.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "pH Range values can't be empty";
                        blStatus = false;
                    }
                    else if (txtPH_From.Text.Trim() != "" || txtPH_To.Text.Trim() != "")
                    {
                        if (txtPH_From.Text.Trim() == txtPH_To.Text.Trim())
                        {
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "pH Range values can't be same";
                            blStatus = false;
                        }
                        else if ((txtPH_From.Text.Trim() == "0" && txtPH_To.Text.Trim() == "-0")
                            || (txtPH_From.Text.Trim() == "-0" && txtPH_To.Text.Trim() == "0"))
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "pH Range values are In-Valid";
                        }
                        else
                        {
                            double dblpH_From = 0.0;
                            double dblpH_To = 0.0;
                            double.TryParse(txtPH_From.Text.Trim(), out dblpH_From);
                            double.TryParse(txtPH_To.Text.Trim(), out dblpH_To);

                            if ((dblpH_From < 0 || dblpH_To < 0) || (dblpH_From > 14 || dblpH_To > 14))
                            {
                                blStatus = false;
                                strErrMsg = strErrMsg.Trim() + "\r\n" + "pH should be in range the of >= 0 and <= 14";
                            }
                            else if ((txtPH_From.Text.Trim().StartsWith("<") || txtPH_From.Text.Trim().StartsWith("<"))
                                  || (txtPH_From.Text.Trim().StartsWith(">") || txtPH_From.Text.Trim().StartsWith(">")))
                            {
                                string[] splitter = { "<", ">" };
                                string[] strPH_From = txtPH_From.Text.Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                                string[] strPH_To = txtPH_From.Text.Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);

                                if (strPH_From != null)
                                {
                                    if (strPH_From.Length > 0)
                                    {
                                        double.TryParse(strPH_From[0], out dblpH_From);
                                    }
                                }
                                if (strPH_To != null)
                                {
                                    if (strPH_To.Length > 0)
                                    {
                                        double.TryParse(strPH_To[0], out dblpH_From);
                                    }
                                }
                                if ((dblpH_From < 0 || dblpH_To < 0) || (dblpH_From > 14 || dblpH_To > 14))
                                {
                                    blStatus = false;
                                    strErrMsg = strErrMsg.Trim() + "\r\n" + "pH should be in range the of >= 0 and <= 14";
                                }
                            }
                            else
                            {
                                bool blPH_From = IsValidNumber(txtPH_From.Text.Trim());
                                bool blPH_To = IsValidNumber(txtPH_To.Text.Trim());

                                if (blPH_From == false || blPH_To == false)
                                {
                                    blStatus = false;
                                    strErrMsg = strErrMsg.Trim() + "\r\n" + "pH Range values are In-Valid";
                                }

                                //New validation on 14th May 2013 - From value < To value
                                double dblFromVal = 0;
                                double.TryParse(txtPH_From.Text.Trim(), out dblFromVal);

                                double dblToVal = 0;
                                double.TryParse(txtPH_To.Text.Trim(), out dblToVal);

                                if (dblToVal < dblFromVal)
                                {
                                    strErrMsg = "pH Range From value should be < To value";
                                    blStatus = false;
                                }
                            }
                        }
                    }                    
                }
                else if (rbnCustPH.Checked)
                {
                    if (string.IsNullOrEmpty(txtCustPH.Text.Trim() ))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "pH Custom value can't be empty";
                        blStatus = false;
                    }
                    else
                    {
                        double dblPH = 0;
                        double.TryParse(txtCustPH.Text.Trim(), out dblPH);
                        if (dblPH > 0)
                        {
                            if (dblPH > 14)
                            {
                                strErrMsg = strErrMsg.Trim() + "\r\n" + "pH should be in range the of >= 0 and <= 14";
                                blStatus = false;
                            }
                        }
                        else//> or < validation
                        {
                            bool blPH = IsValidNumber(txtCustPH.Text.Trim());
                            if (blPH == false)
                            {
                                blStatus = false;
                                strErrMsg = strErrMsg.Trim() + "\r\n" + "pH value is In-Valid";
                            }
                        }
                    }
                }

                //Pressure validation
                if (rbnPressure.Checked)
                {
                    if (string.IsNullOrEmpty( txtPressure.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Pressure can't be empty";
                        blStatus = false;
                    }
                    else //< > validations
                    {
                        bool blPres = IsValidNumber(txtPressure.Text.Trim());
                        if (blPres == false)
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Pressure value is In-Valid";
                        }
                    }
                }
                else if (rbnPres_Range.Checked)
                {
                    if (string.IsNullOrEmpty(txtPres_From.Text.Trim()) || string.IsNullOrEmpty(txtPres_To.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Pressure Range values can't be empty";
                        blStatus = false;
                    }
                    else if (txtPres_From.Text.Trim() != "" || txtPres_To.Text.Trim() != "")
                    {
                        if (txtPres_From.Text.Trim() == txtPres_To.Text.Trim())
                        {
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Pressure Range values can't be same";
                            blStatus = false;
                        }
                        else if ((txtPres_From.Text.Trim() == "0" && txtPres_To.Text.Trim() == "-0")
                            || (txtPres_From.Text.Trim() == "-0" && txtPres_To.Text.Trim() == "0"))
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Pressure Range values are In-Valid";
                        }
                        else if (txtPres_From.Text.Trim().Contains(">") || txtPres_From.Text.Trim().Contains("<") ||
                                txtPres_To.Text.Trim().Contains(">") || txtPres_To.Text.Trim().Contains("<"))//New validation on 14th May 2013
                        {
                            strErrMsg = "> and < symbols not allowed in Pressure Range values";
                            blStatus = false;
                        }
                        else
                        {
                            bool blPres_From = IsValidNumber(txtPres_From.Text.Trim());
                            bool blPres_To = IsValidNumber(txtPres_To.Text.Trim());

                            if (blPres_From == false || blPres_To == false)
                            {
                                blStatus = false;
                                strErrMsg = strErrMsg.Trim() + "\r\n" + "Pressure Range values are In-Valid";
                            }

                            //New validation on 14th May 2013 - From value < To value
                            double dblFromVal = 0;
                            double.TryParse(txtPres_From.Text.Trim(), out dblFromVal);

                            double dblToVal = 0;
                            double.TryParse(txtPres_To.Text.Trim(), out dblToVal);

                            if (dblToVal < dblFromVal)
                            {
                                strErrMsg = "Pressure Range From value should be < To value";
                                blStatus = false;
                            }
                        }
                    }
                }
                else if (rbnPres_Direct.Checked)
                {
                    if (string.IsNullOrEmpty(txtPres_D_From.Text.Trim()) || string.IsNullOrEmpty(txtPres_D_To.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Pressure Directional values can't be empty";
                        blStatus = false;
                    }
                    else if (txtPres_D_From.Text.Trim() != "" || txtPres_D_To.Text.Trim() != "")
                    {
                        if (txtPres_D_From.Text.Trim() == txtPres_D_To.Text.Trim())
                        {
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Pressure Directional values can't be same";
                            blStatus = false;
                        }
                        else if ((txtPres_D_From.Text.Trim() == "0" && txtPres_D_To.Text.Trim() == "-0")
                            || (txtPres_D_From.Text.Trim() == "-0" && txtPres_D_To.Text.Trim() == "0"))
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Pressure Directional values are In-Valid";
                        }
                        else if (txtPres_D_From.Text.Trim().Contains(">") || txtPres_D_From.Text.Trim().Contains("<") ||
                                txtPres_D_To.Text.Trim().Contains(">") || txtPres_D_To.Text.Trim().Contains("<"))//New validation on 14th May 2013
                        {
                            strErrMsg = "> and < symbols not allowed in Pressure Directional values";
                            blStatus = false;
                        }
                        else
                        {
                            bool blPr_D_From = IsValidNumber(txtPres_D_From.Text.Trim());
                            bool blPr_D_To = IsValidNumber(txtPres_D_To.Text.Trim());

                            if (blPr_D_From == false || blPr_D_To == false)
                            {
                                blStatus = false;
                                strErrMsg = strErrMsg.Trim() + "\r\n" + "Pressure Directional values are In-Valid";
                            }
                        }
                    }
                }
                else if (rbnCustPres.Checked)
                {
                    if (string.IsNullOrEmpty(txtCustPres.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Pressure Custom value can't be empty";
                        blStatus = false;
                    }
                }

                if (rbnTemp_None.Checked && rbnTime_None.Checked && rbnPH_None.Checked && rbnPres_None.Checked)
                {
                    strErrMsg = strErrMsg.Trim() + "\r\n" + "Empty condtion can't be added";
                    blStatus = false;
                }

                #region Time - Temperature Validation commented
                //string strTimeType = "";
                //string strTime = GetSelectedTime(out strTimeType);
                //if (strTime.Trim() != "")
                //{                    
                //    string strTempType = "";
                //    string strTemp = GetSelectedTemperature(out strTempType);
                //    if (strTemp.Trim() == "")
                //    {
                //        if (strErrMsg.Trim() == "")
                //        {
                //            strErrMsg = "Time corresponding Temperature is not there";
                //            blStatus = false;
                //        }
                //        else
                //        {
                //            strErrMsg = strErrMsg + "\r\n" + "Time corresponding Temperature is not there";
                //            blStatus = false;
                //        }
                //    }                    
                //}  
                #endregion               
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg_out = strErrMsg;
            return blStatus;
        }

        private bool IsValidNumber(string _numval)
        {
            bool blStatus = false;
            try
            {
                Regex objregex = new Regex(@"^[><]?-?[0-9]{1,4}(\.[0-9]{1,4})?$");
                blStatus = objregex.IsMatch(_numval);
                return blStatus;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool ValidateConditions(string _temprature,string _time,string _ph, string _pressure,int _rowindex, out string _errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (ConditionsTbl == null)
                {
                    if (_temprature == "=")
                    {
                        strErrMsg = "'=' is not allowed in the 1st sub-stage of the reaction";
                        blStatus = false;
                    }
                }
                else if (ConditionsTbl.Rows.Count == 0)
                {
                    if (_temprature == "=")
                    {
                        strErrMsg = "'=' is not allowed in the 1st sub-stage of the reaction";
                        blStatus = false;
                    }
                }
                else if (ConditionsTbl.Rows.Count > 0) //ConditionsTbl.Rows.Count -1
                {
                    if ((ConditionsTbl.Rows[_rowindex]["TEMPERATURE"].ToString() == "c" ||
                        ConditionsTbl.Rows[_rowindex]["TEMPERATURE"].ToString() == "h" ||
                        ConditionsTbl.Rows[_rowindex]["TEMPERATURE"].ToString().Contains("]"))
                        && _temprature == "=")
                    {
                        blStatus = false;
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "If Temperature is 'c' / 'h' / ']' in the previous sub-stage, = is not allowed in the current sub-stage";
                    }
                    else if (string.IsNullOrEmpty(ConditionsTbl.Rows[_rowindex]["TEMPERATURE"].ToString().Trim()) && _temprature == "=")
                    {
                        blStatus = false;
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "If Temperature is empty in the previous sub-stage, = is not allowed in the current sub-stage";
                    }
                    if (string.IsNullOrEmpty(ConditionsTbl.Rows[_rowindex]["RC_TIME"].ToString().Trim()) && _time == "=")
                    {
                        blStatus = false;
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "If Time is empty in the previous sub-stage, = is not allowed in the current sub-stage";
                    }
                    if (string.IsNullOrEmpty(ConditionsTbl.Rows[_rowindex]["PH"].ToString().Trim()) && _ph == "=")
                    {
                        blStatus = false;
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "If pH is empty in the previous sub-stage, = is not allowed in the current sub-stage";
                    }
                    if (string.IsNullOrEmpty(ConditionsTbl.Rows[_rowindex]["PRESSURE"].ToString().Trim()) && _pressure == "=")
                    {
                        blStatus = false;
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "If Pressure is empty in the previous sub-stage, = is not allowed in the current sub-stage";
                    }
                    if (ConditionsTbl.Rows[_rowindex]["PRESSURE"].ToString().Contains("]")
                        && _pressure == "=")
                    {
                        blStatus = false;
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "If Pressure is ']' in the previous sub-stage, = is not allowed in the current sub-stage";
                    }
                }
                
                if (PrevStgCondsTbl != null)
                {
                    if (PrevStgCondsTbl.Rows.Count > 0)
                    {
                        if (PrevStgCondsTbl.Rows[PrevStgCondsTbl.Rows.Count - 1]["TEMPERATURE"].ToString() == "c" && _temprature == "=")
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "If Temperature is 'c' in the last sub-stage of " + PrevStageName + ", = is not allowed in the " + StageName;
                        }
                        if (string.IsNullOrEmpty(PrevStgCondsTbl.Rows[PrevStgCondsTbl.Rows.Count - 1]["RC_TIME"].ToString()) && _time == "=")
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "If Time is empty in the last sub-stage of " + PrevStageName + ", = is not allowed in the " + StageName;
                        }
                        if (string.IsNullOrEmpty(PrevStgCondsTbl.Rows[PrevStgCondsTbl.Rows.Count - 1]["PH"].ToString()) && _ph == "=")
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "If pH is empty in the last sub-stage of " + PrevStageName + ", = is not allowed in the " + StageName;
                        }
                        if (string.IsNullOrEmpty(PrevStgCondsTbl.Rows[PrevStgCondsTbl.Rows.Count - 1]["PRESSURE"].ToString()) && _pressure == "=")
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "If Pressure is empty in the last sub-stage of " + PrevStageName + ", = is not allowed in the " + StageName;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg_out = strErrMsg; 
            return blStatus;
        }

        private bool CheckTime_TempValidations()
        {
            bool blStatus = true;
            try
            {
                string strTimeType = "";
                string strTime = GetSelectedTime(out strTimeType);
                if (strTime.Trim() != "")
                {
                    string strTempType = "";
                    string strTemp = GetSelectedTemperature(out strTempType);
                    if (strTemp.Trim() == "")
                    {
                        DialogResult diaRes = MessageBox.Show("Time corresponding Temperature is not there. Do you want to continue?", "Time-Temperature", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                        if (diaRes == DialogResult.Yes)
                        {
                            blStatus = true;
                        }
                        else
                        {
                            blStatus = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private void ClearAllValues()
        {
            try
            {
                rbnTemp_None.Checked = true;
                rbnTime_None.Checked = true;
                rbnPH_None.Checked = true;
                rbnPres_None.Checked = true;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetSelectedTemperature(out string _temptype)
        {
            string strTemp = "";
            string strTemp_Type = "";
            try
            {
                if (rbnTemp.Checked)
                {
                    if (cmbTemp.Text != "c")
                    {
                        strTemp = txtTemp.Text.Trim() + cmbTemp.Text.Trim();
                    }
                    else
                    {
                        strTemp = txtTemp.Text.Trim();
                    }
                    strTemp_Type = "REGULAR";
                }
                else if (rbnEqual_Temp.Checked)
                {
                    strTemp = "=";
                    strTemp_Type = "EQUAL";
                }
                else if (rbnRoomTemp.Checked)
                {
                    strTemp = "a";
                    strTemp_Type = "RTEMP";
                }
                else if(rbnReflux.Checked)
                {
                    strTemp = "x";
                    strTemp_Type = "REFLUX";
                }
                else if(rbnCool.Checked)
                {
                    strTemp = "c";
                    strTemp_Type = "COOL";
                }
                else if(rbnHeated.Checked)
                {
                    strTemp = "h";
                    strTemp_Type = "HEATED";
                }
                else if(rbnRTemp_Reflx.Checked)
                {
                    strTemp = "a]x";
                    strTemp_Type = "RTEMPTOREFLUX";
                }
                else if(rbnReflx_RTemp.Checked)
                {
                    strTemp = "x]a";
                    strTemp_Type = "REFLUXTORTEMP";
                }
                else if(rbnRTemp_X.Checked)
                {
                    if (cmbTemp_RTemp_X.Text.Trim() != "c")
                    {
                        strTemp = "a]" + txtRTemp_X.Text.Trim() + cmbTemp_RTemp_X.Text.Trim();
                    }
                    else
                    {
                        strTemp = "a]" + txtRTemp_X.Text.Trim();
                    }
                    strTemp_Type = "RTEMPTOX";
                }
                else if(rbnX_RTemp.Checked)
                {
                    if (cmbTemp_X_RTemp.Text.Trim() != "c")
                    {
                        strTemp = txtX_RTemp.Text.Trim() + cmbTemp_X_RTemp.Text.Trim() + "]a";
                    }
                    else
                    {
                        strTemp = txtX_RTemp.Text.Trim() + "]a";
                    }
                    strTemp_Type = "XTORTEMP";
                }
                else if(rbnLtn_RTemp.Checked)
                {
                    strTemp = "<a";
                    strTemp_Type = "LTHANRTEMP";
                }
                else if(rbnGrt_RTemp.Checked)
                {
                    strTemp = ">a";
                    strTemp_Type = "GTHANRTEMP";
                }
                else if(rbnReflux_X.Checked)
                {
                    if (cmbTemp_Ref_X.Text.Trim() != "c")
                    {
                        strTemp = "x]" + txtReflux_X.Text.Trim() + cmbTemp_Ref_X.Text.Trim();
                    }
                    else
                    {
                        strTemp = "x]" + txtReflux_X.Text.Trim();
                    }
                    strTemp_Type = "REFLUXTOX";
                }
                else if(rbnX_Reflux.Checked)
                {
                    if (cmbTemp_X_Ref.Text.Trim() != "c")
                    {
                        strTemp = txtX_Reflux.Text.Trim() + cmbTemp_X_Ref.Text.Trim() + "]x";
                    }
                    else
                    {
                        strTemp = txtX_Reflux.Text.Trim() + "]x";
                    }
                    strTemp_Type = "XTOREFLUX";
                }
                else if(rbnDirectnal.Checked)
                {
                    if (cmbTemp_Direct.Text == "c")
                    {
                        strTemp = txtDirect_From.Text.Trim() + "]" + txtDirect_To.Text.Trim();
                    }
                    else
                    {
                        strTemp = txtDirect_From.Text.Trim() + cmbTemp_Direct.Text.Trim() + "]" + txtDirect_To.Text.Trim() + cmbTemp_Direct.Text;
                    }
                    strTemp_Type = "DIRECTIONAL";
                }
                else if(rbnTemp_Range.Checked)
                {
                    if (cmbTemp_Range.Text == "c")
                    {
                        strTemp = txtRange_From.Text.Trim() + "-" + txtRange_To.Text.Trim();
                    }
                    else
                    {
                        strTemp = txtRange_From.Text.Trim() + cmbTemp_Range.Text.Trim() + "-" + txtRange_To.Text.Trim() + cmbTemp_Range.Text;
                    }
                    strTemp_Type = "RANGE";
                }
                else if (rbnTemp_Plus_Minus.Checked)
                {
                    if (cmbTemp_PM.Text == "c")
                    {
                        strTemp = txtTemp_PM_From.Text.Trim() + "+/-" + txtTemp_PM_To.Text.Trim();
                    }
                    else
                    {
                        strTemp = txtTemp_PM_From.Text.Trim() + cmbTemp_PM.Text.Trim() + "+/-" + txtTemp_PM_To.Text.Trim() + cmbTemp_PM.Text;
                    }

                    //Temperature comments
                    Temp_Comments = "Reaction " + ProductNUM + " needs TP=" + txtTemp_PM_From.Text.Trim() + "+/-" + txtTemp_PM_To.Text.Trim(); ;

                    strTemp_Type = "PLUS_MINUS";
                }
                else if(rbnCustomTemp.Checked)
                {
                    strTemp = txtCustTemp.Text.Trim();
                    strTemp_Type = "CUSTOM";
                }
                else if (rbnTemp_None.Checked)
                {
                    strTemp = "";
                    strTemp_Type = "NONE";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _temptype = strTemp_Type; 
            return strTemp;
        }

        private string GetSelectedTime(out string _timetype)
        {
            string strTime = "";
            string strTimeType = "";
            try
            {
                if (rbnTime.Checked)
                {
                    if (cmbTime.Text == "h")
                    {
                        strTime = txtTime.Text.Trim();
                    }
                    else
                    {
                        strTime = txtTime.Text.Trim() + cmbTime.Text;
                    }
                    strTimeType = "REGULAR";
                }
                else if (rbnTime_Range.Checked)
                {
                    if (cmbTime_Range.Text == "h")
                    {
                        strTime = txtTime_From.Text.Trim() + "-" + txtTime_To.Text.Trim();
                    }
                    else
                    {
                        strTime = txtTime_From.Text.Trim() + cmbTime_Range.Text + "-" + txtTime_To.Text.Trim() + cmbTime_Range.Text;
                    }
                    strTimeType = "RANGE";
                }
                else if (rbnTime_InExact.Checked)
                {
                    if (cmbTime_InExact.Text.Trim().ToUpper() == "FEW MINUTES" || cmbTime_InExact.Text.Trim().ToUpper() == "COUPLE OF MINUTES")
                    {
                        strTime = ">1m";
                    }
                    else if (cmbTime_InExact.Text.Trim().ToUpper() == "FEW HOURS" || cmbTime_InExact.Text.Trim().ToUpper() == "COUPLE OF HOURS")
                    {
                        strTime = ">1";
                    }
                    else //few days/couple of days/over the weekend
                    {
                        strTime = ">1d";
                    }
                    strTimeType = GetInExaceTimeType();//"INEXACT";
                }
                else if (rbnTime_OvrN.Checked)
                {
                    strTime = "o";
                    strTimeType = "OVERNIGHT";
                }
                else if (rbnEqual_Time.Checked)
                {
                    strTime = "=";
                    strTimeType = "EQUAL";
                }
                else if (rbnCustTime.Checked)
                {
                    strTime = txtCustTime.Text.Trim();
                    strTimeType = "CUSTOM";
                }
                else if (rbnTime_None.Checked)
                {
                    strTime = "";
                    strTimeType = "NONE";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _timetype = strTimeType;
            return strTime;
        }

        private string GetSelectedPH(out string _phtype)
        {
            string strPH = "";
            string strPHType = "";
            try
            {
                if (rbnPH.Checked)
                {
                    strPH = txtPH.Text.Trim();
                    strPHType = "REGULAR";
                }
                else if (rbnpH_Acid.Checked)
                {
                    strPH = "a";
                    strPHType = "ACID";
                }
                else if (rbnpH_Basic.Checked)
                {
                    strPH = "b";
                    strPHType = "BASIC";
                }
                else if (rbnpH_Nutral.Checked)
                {
                    strPH = "n";
                    strPHType = "NEUTRAL";
                }
                else if (rbnPH_Range.Checked)
                {
                   strPH = txtPH_From.Text.Trim() + "-" + txtPH_To.Text.Trim();
                   strPHType = "RANGE";
                }
                else if (rbnEqual_pH.Checked)
                {
                    strPH = "=";
                    strPHType = "EQUAL";
                }
                else if (rbnCustPH.Checked)
                {
                    strPH = txtCustPH.Text.Trim();
                    strPHType = "CUSTOM";
                }
                else if (rbnPH_None.Checked)
                {
                    strPH = "";
                    strPHType = "NONE";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _phtype = strPHType;
            return strPH;
        }

        private string GetSelectedPressure(out string _prestype)
        {
            string strPressure = "";
            string strPresType = "";
            try
            {
                if (rbnPressure.Checked)
                {
                    if (cmbPressure.Text == "a")
                    {
                        strPressure = txtPressure.Text.Trim();
                    }
                    else
                    {
                        strPressure = txtPressure.Text.Trim() + cmbPressure.Text;
                    }

                    strPresType = "REGULAR";
                }
                else if (rbnPres_Range.Checked)
                {
                    if (cmbPres_Range.Text == "a")
                    {
                        strPressure = txtPres_From.Text.Trim() + "-" + txtPres_To.Text.Trim();
                    }
                    else
                    {
                        strPressure = txtPres_From.Text.Trim() + cmbPres_Range.Text + "-" + txtPres_To.Text.Trim() + cmbPres_Range.Text;
                    }
                    strPresType = "RANGE";
                }
                else if (rbnPres_Direct.Checked)
                {
                    if (cmbPres_Direct.Text == "a")
                    {
                        strPressure = txtPres_D_From.Text.Trim() + "]" + txtPres_D_To.Text.Trim();
                    }
                    else
                    {
                        strPressure = txtPres_D_From.Text.Trim() + cmbPres_Direct.Text + "]" + txtPres_D_To.Text.Trim() + cmbPres_Direct.Text;
                    }
                    strPresType = "DIRECTIONAL";
                }
                else if (rbnEqual_Pres.Checked)
                {
                    strPressure = "=";
                    strPresType = "EQUAL";
                }
                else if (rbnCustPres.Checked)
                {
                    strPressure = txtCustPres.Text.Trim();
                    strPresType = "CUSTOM";
                }
                else if (rbnPres_None.Checked)
                {
                    strPressure = "";
                    strPresType = "NONE";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _prestype = strPresType;
            return strPressure;
        }

        private string GetInExaceTimeType()
        {
            string strTimeType = "INEXACT";
            try
            {
                if (cmbTime_InExact.Enabled)
                {
                    if (cmbTime_InExact.Text.Trim().ToUpper() == "FEW MINUTES")
                    {
                        strTimeType = strTimeType + "_FMIN";
                    }
                    else if (cmbTime_InExact.Text.Trim().ToUpper() == "FEW HOURS")
                    {
                        strTimeType = strTimeType + "_FHOUR";
                    }
                    else if (cmbTime_InExact.Text.Trim().ToUpper() == "FEW DAYS")
                    {
                        strTimeType = strTimeType + "_FDAY";
                    }
                    else if (cmbTime_InExact.Text.Trim().ToUpper() == "COUPLE OF MINUTES")
                    {
                        strTimeType = strTimeType + "_CMIN";
                    }
                    else if (cmbTime_InExact.Text.Trim().ToUpper() == "COUPLE OF HOURS")
                    {
                        strTimeType = strTimeType + "_CHOUR";
                    }
                    else if (cmbTime_InExact.Text.Trim().ToUpper() == "COUPLE OF DAYS")
                    {
                        strTimeType = strTimeType + "_CDAY";
                    }
                    else if (cmbTime_InExact.Text.Trim().ToUpper() == "OVER THE WEEKEND")
                    {
                        strTimeType = strTimeType + "_OWEEK";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strTimeType;
        }

        private void BindValuesToControls(string _temp, string _time, string _pressure, string _ph, string _temptype,string _timetype,string _prestype,string _phtype)
        {
            try
            {
                BindValuesToTemperatureControl(_temp.Trim(), _temptype.Trim());
                BindValueToTimeControl(_time.Trim(), _timetype.Trim());
                BindValueToPHControl(_ph.Trim(),_phtype.Trim());
                BindValueToPressureControl(_pressure.Trim(),_prestype.Trim());
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindValueToTimeControl(string _time,string _time_type)
        {
            try
            {
                if (_time_type.Trim() != "")
                {
                    if (_time_type.Trim() == "OVERNIGHT")
                    {
                        rbnTime_OvrN.Checked = true;
                    }
                    else if (_time_type.Trim() == "EQUAL")
                    {
                        rbnEqual_Time.Checked = true;
                    }                    
                    else if (_time_type.Trim() == "REGULAR")
                    {
                        rbnTime.Checked = true;
                        
                        string strTUnits = "";
                        txtTime.Text = GetTimeAndUnitsFromString(_time, out strTUnits);
                        cmbTime.Text = strTUnits;
                    }
                    else if (_time_type.Trim() == "RANGE")
                    {
                        rbnTime_Range.Checked = true;

                        string strRngFrom = "";
                        string strRngTo = "";
                        strRngFrom = GetRangeValuesFromString(_time, out strRngTo);
                        
                        string strTMUnits = "";

                        txtTime_From.Text = GetTimeAndUnitsFromString(strRngFrom, out strTMUnits);
                        txtTime_To.Text = GetTimeAndUnitsFromString(strRngTo, out strTMUnits);

                        cmbTime_Range.Text = strTMUnits;
                    }
                    else if (_time_type.Trim().Contains("INEXACT"))
                    {
                        rbnTime_InExact.Checked = true;

                        string[] splitter = { "_" };
                        string[] strTMVals = _time_type.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                        if (strTMVals != null)
                        {
                            if (strTMVals.Length > 0)
                            {
                                cmbTime_InExact.Text = GetSelectedINExactTimeFromString(strTMVals[1].Trim());
                            }
                        }
                    }
                    else if (_time_type.Trim() == "CUSTOM")
                    {
                        rbnCustTime.Checked = true;
                        txtCustTime.Text = _time;

                        if (GlobalVariables.RoleName.ToUpper() == "CURATOR" || GlobalVariables.RoleName.ToUpper() == "REVIEWER")
                        {
                            txtCustTime.ReadOnly = true;
                        }
                        else
                        {
                            txtCustTime.ReadOnly = false;
                        }
                    }
                    else
                    {
                        rbnTime_None.Checked = true;
                    }
                }
                else
                {
                    rbnCustTime.Checked = true;
                    txtCustTime.Text = _time;

                    if (GlobalVariables.RoleName.ToUpper() == "CURATOR" || GlobalVariables.RoleName.ToUpper() == "REVIEWER")
                    {
                        txtCustTime.ReadOnly = true;
                    }
                    else
                    {
                        txtCustTime.ReadOnly = false;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindValueToPHControl(string _ph,string _ph_type)
        {
            try
            {
                if (_ph_type.Trim() != "")
                {
                    if (_ph_type.Trim() == "REGULAR")
                    {
                        rbnPH.Checked = true;
                        txtPH.Text = _ph;
                    }
                    else if (_ph_type.Trim() == "RANGE")
                    {
                        rbnPH_Range.Checked = true;

                        string strRngFrom = "";
                        string strRngTo = "";
                        strRngFrom = GetRangeValuesFromString(_ph, out strRngTo);
                        
                        txtPH_From.Text = strRngFrom;
                        txtPH_To.Text = strRngTo;
                    }
                    else if (_ph_type.Trim() == "ACID")
                    {
                        rbnpH_Acid.Checked = true;
                    }
                    else if (_ph_type.Trim() == "BASIC")
                    {
                        rbnpH_Basic.Checked = true;
                    }
                    else if (_ph_type.Trim() == "NEUTRAL")
                    {
                        rbnpH_Nutral.Checked = true;
                    }
                    else if (_ph_type.Trim() == "EQUAL")
                    {
                        rbnEqual_pH.Checked = true;
                    }
                    else if (_ph_type.Trim() == "CUSTOM")
                    {
                        rbnCustPH.Checked = true;
                        txtCustPH.Text = _ph;

                        if (GlobalVariables.RoleName.ToUpper() == "CURATOR" || GlobalVariables.RoleName.ToUpper() == "REVIEWER")
                        {
                            txtCustPH.ReadOnly = true;
                        }
                        else
                        {
                            txtCustPH.ReadOnly = false;
                        }
                    }
                    else
                    {
                        rbnPH_None.Checked = true;
                    }
                }
                else
                {
                    rbnCustPH.Checked = true;
                    txtCustPH.Text = _ph;

                    if (GlobalVariables.RoleName.ToUpper() == "CURATOR" || GlobalVariables.RoleName.ToUpper() == "REVIEWER")
                    {
                        txtCustPH.ReadOnly = true;
                    }
                    else
                    {
                        txtCustPH.ReadOnly = false;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindValuesToTemperatureControl(string _temp, string _temptype)
        {
            try
            {

                if (_temptype.Trim() != "")
                {
                    if (_temptype.Trim().ToUpper() == "REGULAR")
                    {
                        string strTUnits = "";
                        rbnTemp.Checked = true;
                        txtTemp.Text = GetTemperatureAndUnitsFromString(_temp, out strTUnits);
                        cmbTemp.Text = strTUnits;
                    }
                    else if (_temptype.Trim().ToUpper() == "EQUAL")
                    {
                        rbnEqual_Temp.Checked = true;
                    }
                    else if (_temptype.Trim().ToUpper() == "RTEMP")
                    {
                        rbnRoomTemp.Checked = true;
                    }
                    else if (_temptype.Trim().ToUpper() == "REFLUX")
                    {
                        rbnReflux.Checked = true;
                    }
                    else if (_temptype.Trim().ToUpper() == "COOL")
                    {
                        rbnCool.Checked = true;
                    }
                    else if (_temptype.Trim().ToUpper() == "HEATED")
                    {
                        rbnHeated.Checked = true;
                    }
                    else if (_temptype.Trim().ToUpper() == "RTEMPTOREFLUX")
                    {
                        rbnRTemp_Reflx.Checked = true;
                    }
                    else if (_temptype.Trim().ToUpper() == "REFLUXTORTEMP")
                    {
                        rbnReflx_RTemp.Checked = true;
                    }
                    else if (_temptype.Trim().ToUpper() == "RTEMPTOX")
                    {
                        rbnRTemp_X.Checked = true;

                        string strTUnits = "";
                        string[] splitter = { "]" };
                        string[] strVals = _temp.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                        if (strVals != null)
                        {
                            if (strVals.Length > 0)
                            {
                                txtRTemp_X.Text = GetTemperatureAndUnitsFromString(strVals[1], out strTUnits);
                                cmbTemp_RTemp_X.Text = strTUnits;
                            }
                        }
                    }
                    else if (_temptype.Trim().ToUpper() == "XTORTEMP")
                    {
                        rbnX_RTemp.Checked = true;

                        string strTUnits = "";
                        string[] splitter = { "]" };
                        string[] strVals = _temp.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                        if (strVals != null)
                        {
                            if (strVals.Length > 0)
                            {
                                txtX_RTemp.Text = GetTemperatureAndUnitsFromString(strVals[0], out strTUnits);
                                cmbTemp_X_RTemp.Text = strTUnits;
                            }
                        }
                    }
                    else if (_temptype.Trim().ToUpper() == "LTHANRTEMP")
                    {
                        rbnLtn_RTemp.Checked = true;
                    }
                    else if (_temptype.Trim().ToUpper() == "GTHANRTEMP")
                    {
                        rbnGrt_RTemp.Checked = true;
                    }
                    else if (_temptype.Trim().ToUpper() == "REFLUXTOX")
                    {
                        rbnReflux_X.Checked = true;

                        string strTUnits = "";
                        string[] splitter = { "]" };
                        string[] strVals = _temp.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                        if (strVals != null)
                        {
                            if (strVals.Length > 0)
                            {
                                txtReflux_X.Text = GetTemperatureAndUnitsFromString(strVals[1], out strTUnits);
                                cmbTemp_Ref_X.Text = strTUnits;
                            }
                        }
                    }
                    else if (_temptype.Trim().ToUpper() == "XTOREFLUX")
                    {
                        rbnX_Reflux.Checked = true;

                        string strTUnits = "";
                        string[] splitter = { "]" };
                        string[] strVals = _temp.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                        if (strVals != null)
                        {
                            if (strVals.Length > 0)
                            {
                                txtX_Reflux.Text = GetTemperatureAndUnitsFromString(strVals[0], out strTUnits);
                                cmbTemp_X_Ref.Text = strTUnits;
                            }
                        }
                    }
                    else if (_temptype.Trim().ToUpper() == "DIRECTIONAL")
                    {
                        rbnDirectnal.Checked = true;
                        string[] splitter = { "]" };
                        string[] strVals = _temp.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                        if (strVals != null)
                        {
                            if (strVals.Length > 0)
                            {
                                string strTPUnits = "";
                                txtDirect_From.Text = GetTemperatureAndUnitsFromString(strVals[0], out strTPUnits);
                                txtDirect_To.Text = GetTemperatureAndUnitsFromString(strVals[1], out strTPUnits);

                                cmbTemp_Direct.Text = strTPUnits;
                            }
                        }
                    }
                    else if (_temptype.Trim().ToUpper() == "RANGE")
                    {
                        rbnTemp_Range.Checked = true;
                        
                        string strRngFrom = "";
                        string strRngTo = "";
                        strRngFrom = GetRangeValuesFromString(_temp, out strRngTo);

                        string strTPUnits = "";
                        txtRange_From.Text = GetTemperatureAndUnitsFromString(strRngFrom, out strTPUnits);
                        txtRange_To.Text = GetTemperatureAndUnitsFromString(strRngTo, out strTPUnits);

                        cmbTemp_Range.Text = strTPUnits;
                    }
                    else if (_temptype.Trim().ToUpper() == "PLUS_MINUS")
                    {
                        rbnTemp_Plus_Minus.Checked = true;

                        string[] splitter = { "+/-" };
                        string[] strVals = _temp.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                        if (strVals != null)
                        {
                            if (strVals.Length > 0)
                            {
                                string strTPUnits = "";
                                txtTemp_PM_From.Text = GetTemperatureAndUnitsFromString(strVals[0], out strTPUnits);
                                txtTemp_PM_To.Text = GetTemperatureAndUnitsFromString(strVals[1], out strTPUnits);

                                cmbTemp_PM.Text = strTPUnits;
                            }
                        }
                    }
                    else if (_temptype.Trim().ToUpper() == "CUSTOM")
                    {
                        rbnCustomTemp.Checked = true;
                        txtCustTemp.Text = _temp;

                        if (GlobalVariables.RoleName.ToUpper() == "CURATOR" || GlobalVariables.RoleName.ToUpper() == "REVIEWER")
                        {
                            txtCustTemp.ReadOnly = true;
                        }
                        else
                        {
                            txtCustTemp.ReadOnly = false;
                        }
                    }
                }
                else
                {
                    rbnCustomTemp.Checked = true;
                    txtCustTemp.Text = _temp;

                    if (GlobalVariables.RoleName.ToUpper() == "CURATOR" || GlobalVariables.RoleName.ToUpper() == "REVIEWER")
                    {
                        txtCustTemp.ReadOnly = true;
                    }
                    else
                    {
                        txtCustTemp.ReadOnly = false;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindValueToPressureControl(string _pressure,string _prestype)
        {
            try
            {
                if (_prestype.Trim() != "")
                {
                    if (_prestype.Trim() == "REGULAR")
                    {
                        rbnPressure.Checked = true;

                        string strPRUnits = "";
                        txtPressure.Text = GetPressureAndUnitsFromString(_pressure, out strPRUnits);
                        cmbPressure.Text = strPRUnits;
                    }
                    else if (_prestype.Trim() == "RANGE")
                    {
                        rbnPres_Range.Checked = true;

                        string strRngFrom = "";
                        string strRngTo = "";
                        strRngFrom = GetRangeValuesFromString(_pressure, out strRngTo);

                        string strPRUnits = "";
                        txtPres_From.Text = GetPressureAndUnitsFromString(strRngFrom, out strPRUnits);
                        txtPres_To.Text = GetPressureAndUnitsFromString(strRngTo, out strPRUnits);

                        cmbPres_Range.Text = strPRUnits;                        
                    }
                    else if (_prestype.Trim() == "DIRECTIONAL")
                    {
                        rbnPres_Direct.Checked = true;

                        string[] splitter = { "]" };
                        string[] strVals = _pressure.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                        if (strVals != null)
                        {
                            if (strVals.Length > 0)
                            {
                                string strPRUnits = "";
                                txtPres_D_From.Text = GetPressureAndUnitsFromString(strVals[0], out strPRUnits);
                                txtPres_D_To.Text = GetPressureAndUnitsFromString(strVals[1], out strPRUnits);

                                cmbPres_Direct.Text = strPRUnits;
                            }
                        }
                    }
                    else if (_prestype.Trim() == "EQUAL")
                    {
                        rbnEqual_Pres.Checked = true;
                    }
                    else if (_prestype.Trim() == "CUSTOM")
                    {
                        rbnCustPres.Checked = true;
                        txtCustPres.Text = _pressure;

                        if (GlobalVariables.RoleName.ToUpper() == "CURATOR" || GlobalVariables.RoleName.ToUpper() == "REVIEWER")
                        {
                            txtCustPres.ReadOnly = true;
                        }
                        else
                        {
                            txtCustPres.ReadOnly = false;
                        }
                    }
                    else
                    {
                        rbnPres_None.Checked = true;
                    }
                }
                else
                {
                    rbnCustPres.Checked = true;
                    txtCustPres.Text = _pressure;

                    if (GlobalVariables.RoleName.ToUpper() == "CURATOR" || GlobalVariables.RoleName.ToUpper() == "REVIEWER")
                    {
                        txtCustPres.ReadOnly = true;
                    }
                    else
                    {
                        txtCustPres.ReadOnly = false;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetPressureAndUnitsFromString(string _pressure,out string _pres_units)
        {
            string strPres = _pressure;
            string strPresUnits = "a";
            try
            {
                strPresUnits = GetPressureUnitsFromString(_pressure);

                string[] splitter = { "b", "kb", "mb", "j", "m", "p", "kp", "mp", "gp", "hp", "s", "t", "kc" };
                string[] strPresVals = strPres.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                if (strPresVals != null)
                {
                    if (strPresVals.Length > 0)
                    {
                        strPres = strPresVals[0];                        
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _pres_units = strPresUnits;
            return strPres;
        }

        private string GetTemperatureAndUnitsFromString(string _temp,out string _temp_units)
        {
            string strTemp = _temp;
            string strTempUnits = "c";
            try
            {
                strTempUnits = GetTempUnitsFromString(_temp);
                
                string[] splitter = { "f", "k", "r"};
                string[] strTempVals = strTemp.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                if (strTempVals != null)
                {
                    if (strTempVals.Length > 0)
                    {
                        strTemp = strTempVals[0];                        
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _temp_units = strTempUnits;
            return strTemp;
        }

        private string GetTimeAndUnitsFromString(string _time,out string _time_units)
        {
            string strTime = _time;
            string strTimeUnits = "h";
            try
            {
                strTimeUnits = GetTimeUnitsFromString(_time);

                string[] splitter = { "m", "s", "d","w","mo","ms"};
                string[] strTimeVals = strTime.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                if (strTimeVals != null)
                {
                    if (strTimeVals.Length > 0)
                    {
                        strTime = strTimeVals[0];                        
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _time_units = strTimeUnits;
            return strTime;
        }

        private string GetTempUnitsFromString(string _temp)
        {
            string strTPUnits = "c";
            try
            {
                if (_temp.Trim() != "")
                {
                    if (_temp.Trim().EndsWith("f"))
                    {
                        strTPUnits = "f";
                    }
                    else if (_temp.Trim().EndsWith("k"))
                    {
                        strTPUnits = "k";
                    }
                    else if (_temp.Trim().EndsWith("r"))
                    {
                        strTPUnits = "r";
                    }                   
                    return strTPUnits;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strTPUnits;
        }

        private string GetTimeUnitsFromString(string _time)
        {
            string strTMUnits = "h";
            try
            {
                if (_time.Trim() != "")
                {
                    if (_time.Trim().EndsWith("mo"))
                    {
                        strTMUnits = "mo";
                    }
                    else if (_time.Trim().EndsWith("ms"))
                    {
                        strTMUnits = "ms";
                    }
                    else if (_time.Trim().EndsWith("m"))
                    {
                        strTMUnits = "m";
                    }
                    else if (_time.Trim().EndsWith("s"))
                    {
                        strTMUnits = "s";
                    }
                    else if (_time.Trim().EndsWith("d"))
                    {
                        strTMUnits = "d";
                    }
                    else if (_time.Trim().EndsWith("w"))
                    {
                        strTMUnits = "w";
                    }
                    
                    return strTMUnits;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strTMUnits;
        }

        private string GetPressureUnitsFromString(string _pressure)
        {
            string strPRUnits = "h";
            try
            {
                if (_pressure.Trim() != "")
                {
                    if (_pressure.Trim().EndsWith("mb"))
                    {
                        strPRUnits = "mb";
                    }
                    else if (_pressure.Trim().EndsWith("kb"))
                    {
                        strPRUnits = "kb";
                    }
                    else if (_pressure.Trim().EndsWith("kp"))
                    {
                        strPRUnits = "kp";
                    }
                    else if (_pressure.Trim().EndsWith("mp"))
                    {
                        strPRUnits = "mp";
                    }
                    else if (_pressure.Trim().EndsWith("gp"))
                    {
                        strPRUnits = "gp";
                    }
                    else if (_pressure.Trim().EndsWith("hp"))
                    {
                        strPRUnits = "hp";
                    }
                    else if (_pressure.Trim().EndsWith("kc"))
                    {
                        strPRUnits = "kc";
                    }
                    else if (_pressure.Trim().EndsWith("b"))
                    {
                        strPRUnits = "b";
                    }              
                    else if (_pressure.Trim().EndsWith("j"))
                    {
                        strPRUnits = "j";
                    }
                    else if (_pressure.Trim().EndsWith("m"))
                    {
                        strPRUnits = "m";
                    }
                    else if (_pressure.Trim().EndsWith("p"))
                    {
                        strPRUnits = "p";
                    }                    
                    else if (_pressure.Trim().EndsWith("s"))
                    {
                        strPRUnits = "s";
                    }
                    else if (_pressure.Trim().EndsWith("t"))
                    {
                        strPRUnits = "t";
                    }                    
                    return strPRUnits;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strPRUnits;
        }

        private string GetRangeValuesFromString(string _rangetext, out string _rng_to_val)
        {
            string strFromVal = "";
            string strToVal = "";
            try
            {
                if (_rangetext.Trim() != "")
                {
                    char[] charArray = _rangetext.ToCharArray();
                    if (charArray != null)
                    {
                        if (charArray.Length > 0)
                        {
                            bool blRng = false;
                            bool blIsNum = false;
                            for (int i = 0; i < charArray.Length; i++)
                            {
                                if (charArray[i] != '-' && i != 0 && blRng == false)
                                {
                                    strFromVal = strFromVal.Trim() + charArray[i].ToString().Trim();
                                    
                                    //New validation
                                    double dblTemp = 0.0;
                                    if (double.TryParse(charArray[i].ToString(), out dblTemp))
                                    {
                                        blIsNum = true;
                                    }
                                }
                                else if (charArray[i] == '-' && i == 0)
                                {
                                    strFromVal = strFromVal.Trim() + charArray[i].ToString().Trim();
                                }
                                else if (charArray[i] == '-' && i != 0 && blRng == false && blIsNum == true)
                                {
                                    blRng = true;
                                }
                                else if (charArray[i] != '-' && blRng == false)
                                {
                                    strFromVal = strFromVal.Trim() + charArray[i].ToString().Trim();

                                    //New validation
                                    double dblTemp = 0.0;
                                    if (double.TryParse(charArray[i].ToString(), out dblTemp))
                                    {
                                        blIsNum = true;
                                    }
                                }
                                else if (charArray[i] == '-' && blRng == false && blIsNum == false)//New validation
                                {
                                    strFromVal = strFromVal.Trim() + charArray[i].ToString().Trim();                                    
                                }
                                else if (blRng)
                                {
                                    strToVal = strToVal.Trim() + charArray[i].ToString().Trim();
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _rng_to_val = strToVal;
            return strFromVal;
        }

        private string GetSelectedINExactTimeFromString(string _inexacttime)
        {
            string strInExact = "";
            try
            {
                if (_inexacttime.Trim() != "")
                {
                    switch (_inexacttime.Trim())
                    {
                        case "FMIN":
                            strInExact = "few minutes";
                            break;
                        case "FHOUR":
                            strInExact = "few hours";
                            break;
                        case "FDAY":
                            strInExact = "few days";
                            break;
                        case "CMIN":
                            strInExact = "couple of minutes";
                            break;
                        case "CHOUR":
                            strInExact = "couple of hours";
                            break;
                        case "CDAY":
                            strInExact = "couple of days";
                            break;
                        case "OWEEK":
                            strInExact = "over the weekend";
                            break;
                        default:
                            strInExact = "few hours";
                            break;                     
                    }            
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strInExact;
        }
        
        string insertOption = "AFTER";
        int insertRowIndx = 0;
        private void addCondAfterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Enable_Disable_Conditions(true);
                insertOption = "AFTER";
                if (dgvConds.CurrentCell != null)
                {
                    insertRowIndx = dgvConds.CurrentCell.RowIndex;
                }
                else
                {
                    insertRowIndx = 0;
                    insertOption = "END";
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void addCondBeforeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Enable_Disable_Conditions(true);
                insertOption = "BEFORE";
                if (dgvConds.CurrentCell != null)
                {
                    insertRowIndx = dgvConds.CurrentCell.RowIndex;
                }
                else
                {
                    insertRowIndx = 0;
                    insertOption = "END";
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void Enable_Disable_Conditions(bool blstatus)
        {
            try
            {
                grpTemprture.Enabled = blstatus;
                grpTime.Enabled = blstatus;
                grpPH.Enabled = blstatus;
                grpPressure.Enabled = blstatus;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void ChangeDisp_Order_In_CondsTable(int _rowindex, string _insOpt)
        {
            try
            {
                if (ConditionsTbl != null)
                {
                    if (ConditionsTbl.Rows.Count > 0)
                    {
                        if (_insOpt == "BEFORE" || _insOpt == "AFTER")
                        {
                            int rIndx = 0;
                            if (_insOpt == "AFTER")
                            {
                                rIndx = _rowindex;// +2;
                            }
                            //else if (_insOpt == "BEFORE")
                            //{
                            //    rIndx = _rowindex + 1;
                            //}
                            for (int i = rIndx; i < ConditionsTbl.Rows.Count; i++)
                            {
                                ConditionsTbl.Rows[i]["DISPLAY_ORDER"] = Convert.ToInt32(ConditionsTbl.Rows[i]["DISPLAY_ORDER"].ToString()) + 1;
                            }
                            ConditionsTbl.AcceptChanges();
                        }
                        else if (_insOpt == "DELETE")
                        {
                            int rIndx = _rowindex;
                            for (int i = rIndx; i < ConditionsTbl.Rows.Count; i++)
                            {
                                ConditionsTbl.Rows[i]["DISPLAY_ORDER"] = Convert.ToInt32(ConditionsTbl.Rows[i]["DISPLAY_ORDER"].ToString()) - 1;
                            }
                            ConditionsTbl.AcceptChanges();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
