﻿namespace IndxReactNarr
{
    partial class frmCASREACTHelp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCASREACTHelp));
            this.tbCntrl_Pdfs = new System.Windows.Forms.TabControl();
            this.tpInputManual = new System.Windows.Forms.TabPage();
            this.pdfCntrl_Input = new AxAcroPDFLib.AxAcroPDF();
            this.tpCodingHints = new System.Windows.Forms.TabPage();
            this.pdfCntrl_CHints = new AxAcroPDFLib.AxAcroPDF();
            this.tpGenRmdrs_Conds = new System.Windows.Forms.TabPage();
            this.pdfCntrl_Conds = new AxAcroPDFLib.AxAcroPDF();
            this.tpStructConvensions = new System.Windows.Forms.TabPage();
            this.axPdfStructConv = new AxAcroPDFLib.AxAcroPDF();
            this.tpProtocol_Updates = new System.Windows.Forms.TabPage();
            this.pdfCntrl_pUpdates = new AxAcroPDFLib.AxAcroPDF();
            this.tpRSNManual = new System.Windows.Forms.TabPage();
            this.pdfCntrl_RSNManual = new AxAcroPDFLib.AxAcroPDF();
            this.tpAbstract = new System.Windows.Forms.TabPage();
            this.tpIndxManual = new System.Windows.Forms.TabPage();
            this.tpRoleIndicators = new System.Windows.Forms.TabPage();
            this.axPdfIndxManual = new AxAcroPDFLib.AxAcroPDF();
            this.axPdfRoleInd = new AxAcroPDFLib.AxAcroPDF();
            this.axPdfAbstract = new AxAcroPDFLib.AxAcroPDF();
            this.tpTitle = new System.Windows.Forms.TabPage();
            this.tpStereoChem = new System.Windows.Forms.TabPage();
            this.axPdfTitle = new AxAcroPDFLib.AxAcroPDF();
            this.axPdfStereoChem = new AxAcroPDFLib.AxAcroPDF();
            this.tbCntrl_Pdfs.SuspendLayout();
            this.tpInputManual.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pdfCntrl_Input)).BeginInit();
            this.tpCodingHints.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pdfCntrl_CHints)).BeginInit();
            this.tpGenRmdrs_Conds.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pdfCntrl_Conds)).BeginInit();
            this.tpStructConvensions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axPdfStructConv)).BeginInit();
            this.tpProtocol_Updates.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pdfCntrl_pUpdates)).BeginInit();
            this.tpRSNManual.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pdfCntrl_RSNManual)).BeginInit();
            this.tpAbstract.SuspendLayout();
            this.tpIndxManual.SuspendLayout();
            this.tpRoleIndicators.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axPdfIndxManual)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axPdfRoleInd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axPdfAbstract)).BeginInit();
            this.tpTitle.SuspendLayout();
            this.tpStereoChem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axPdfTitle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axPdfStereoChem)).BeginInit();
            this.SuspendLayout();
            // 
            // tbCntrl_Pdfs
            // 
            this.tbCntrl_Pdfs.Controls.Add(this.tpInputManual);
            this.tbCntrl_Pdfs.Controls.Add(this.tpCodingHints);
            this.tbCntrl_Pdfs.Controls.Add(this.tpGenRmdrs_Conds);
            this.tbCntrl_Pdfs.Controls.Add(this.tpStructConvensions);
            this.tbCntrl_Pdfs.Controls.Add(this.tpProtocol_Updates);
            this.tbCntrl_Pdfs.Controls.Add(this.tpRSNManual);
            this.tbCntrl_Pdfs.Controls.Add(this.tpAbstract);
            this.tbCntrl_Pdfs.Controls.Add(this.tpIndxManual);
            this.tbCntrl_Pdfs.Controls.Add(this.tpRoleIndicators);
            this.tbCntrl_Pdfs.Controls.Add(this.tpTitle);
            this.tbCntrl_Pdfs.Controls.Add(this.tpStereoChem);
            this.tbCntrl_Pdfs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbCntrl_Pdfs.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbCntrl_Pdfs.Location = new System.Drawing.Point(0, 0);
            this.tbCntrl_Pdfs.Name = "tbCntrl_Pdfs";
            this.tbCntrl_Pdfs.SelectedIndex = 0;
            this.tbCntrl_Pdfs.Size = new System.Drawing.Size(1208, 530);
            this.tbCntrl_Pdfs.TabIndex = 1;
            // 
            // tpInputManual
            // 
            this.tpInputManual.Controls.Add(this.pdfCntrl_Input);
            this.tpInputManual.Location = new System.Drawing.Point(4, 26);
            this.tpInputManual.Name = "tpInputManual";
            this.tpInputManual.Padding = new System.Windows.Forms.Padding(3);
            this.tpInputManual.Size = new System.Drawing.Size(1200, 500);
            this.tpInputManual.TabIndex = 0;
            this.tpInputManual.Text = "Input Manual";
            this.tpInputManual.UseVisualStyleBackColor = true;
            // 
            // pdfCntrl_Input
            // 
            this.pdfCntrl_Input.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pdfCntrl_Input.Enabled = true;
            this.pdfCntrl_Input.Location = new System.Drawing.Point(3, 3);
            this.pdfCntrl_Input.Name = "pdfCntrl_Input";
            this.pdfCntrl_Input.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("pdfCntrl_Input.OcxState")));
            this.pdfCntrl_Input.Size = new System.Drawing.Size(1194, 494);
            this.pdfCntrl_Input.TabIndex = 0;
            // 
            // tpCodingHints
            // 
            this.tpCodingHints.Controls.Add(this.pdfCntrl_CHints);
            this.tpCodingHints.Location = new System.Drawing.Point(4, 26);
            this.tpCodingHints.Name = "tpCodingHints";
            this.tpCodingHints.Padding = new System.Windows.Forms.Padding(3);
            this.tpCodingHints.Size = new System.Drawing.Size(1062, 500);
            this.tpCodingHints.TabIndex = 1;
            this.tpCodingHints.Text = "Coding Hints";
            this.tpCodingHints.UseVisualStyleBackColor = true;
            // 
            // pdfCntrl_CHints
            // 
            this.pdfCntrl_CHints.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pdfCntrl_CHints.Enabled = true;
            this.pdfCntrl_CHints.Location = new System.Drawing.Point(3, 3);
            this.pdfCntrl_CHints.Name = "pdfCntrl_CHints";
            this.pdfCntrl_CHints.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("pdfCntrl_CHints.OcxState")));
            this.pdfCntrl_CHints.Size = new System.Drawing.Size(1056, 494);
            this.pdfCntrl_CHints.TabIndex = 0;
            // 
            // tpGenRmdrs_Conds
            // 
            this.tpGenRmdrs_Conds.Controls.Add(this.pdfCntrl_Conds);
            this.tpGenRmdrs_Conds.Location = new System.Drawing.Point(4, 26);
            this.tpGenRmdrs_Conds.Name = "tpGenRmdrs_Conds";
            this.tpGenRmdrs_Conds.Size = new System.Drawing.Size(1062, 500);
            this.tpGenRmdrs_Conds.TabIndex = 2;
            this.tpGenRmdrs_Conds.Text = "General Remainders for Conditions";
            this.tpGenRmdrs_Conds.UseVisualStyleBackColor = true;
            // 
            // pdfCntrl_Conds
            // 
            this.pdfCntrl_Conds.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pdfCntrl_Conds.Enabled = true;
            this.pdfCntrl_Conds.Location = new System.Drawing.Point(0, 0);
            this.pdfCntrl_Conds.Name = "pdfCntrl_Conds";
            this.pdfCntrl_Conds.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("pdfCntrl_Conds.OcxState")));
            this.pdfCntrl_Conds.Size = new System.Drawing.Size(1062, 500);
            this.pdfCntrl_Conds.TabIndex = 0;
            // 
            // tpStructConvensions
            // 
            this.tpStructConvensions.Controls.Add(this.axPdfStructConv);
            this.tpStructConvensions.Location = new System.Drawing.Point(4, 26);
            this.tpStructConvensions.Name = "tpStructConvensions";
            this.tpStructConvensions.Size = new System.Drawing.Size(1062, 500);
            this.tpStructConvensions.TabIndex = 3;
            this.tpStructConvensions.Text = "Structuring Convensions";
            this.tpStructConvensions.UseVisualStyleBackColor = true;
            // 
            // axPdfStructConv
            // 
            this.axPdfStructConv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.axPdfStructConv.Enabled = true;
            this.axPdfStructConv.Location = new System.Drawing.Point(0, 0);
            this.axPdfStructConv.Name = "axPdfStructConv";
            this.axPdfStructConv.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axPdfStructConv.OcxState")));
            this.axPdfStructConv.Size = new System.Drawing.Size(1062, 500);
            this.axPdfStructConv.TabIndex = 0;
            // 
            // tpProtocol_Updates
            // 
            this.tpProtocol_Updates.Controls.Add(this.pdfCntrl_pUpdates);
            this.tpProtocol_Updates.Location = new System.Drawing.Point(4, 26);
            this.tpProtocol_Updates.Name = "tpProtocol_Updates";
            this.tpProtocol_Updates.Size = new System.Drawing.Size(1062, 500);
            this.tpProtocol_Updates.TabIndex = 4;
            this.tpProtocol_Updates.Text = "Protocol Updates";
            this.tpProtocol_Updates.UseVisualStyleBackColor = true;
            // 
            // pdfCntrl_pUpdates
            // 
            this.pdfCntrl_pUpdates.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pdfCntrl_pUpdates.Enabled = true;
            this.pdfCntrl_pUpdates.Location = new System.Drawing.Point(0, 0);
            this.pdfCntrl_pUpdates.Name = "pdfCntrl_pUpdates";
            this.pdfCntrl_pUpdates.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("pdfCntrl_pUpdates.OcxState")));
            this.pdfCntrl_pUpdates.Size = new System.Drawing.Size(1062, 500);
            this.pdfCntrl_pUpdates.TabIndex = 0;
            // 
            // tpRSNManual
            // 
            this.tpRSNManual.Controls.Add(this.pdfCntrl_RSNManual);
            this.tpRSNManual.Location = new System.Drawing.Point(4, 26);
            this.tpRSNManual.Name = "tpRSNManual";
            this.tpRSNManual.Size = new System.Drawing.Size(1062, 500);
            this.tpRSNManual.TabIndex = 5;
            this.tpRSNManual.Text = "RSN manual";
            this.tpRSNManual.UseVisualStyleBackColor = true;
            // 
            // pdfCntrl_RSNManual
            // 
            this.pdfCntrl_RSNManual.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pdfCntrl_RSNManual.Enabled = true;
            this.pdfCntrl_RSNManual.Location = new System.Drawing.Point(0, 0);
            this.pdfCntrl_RSNManual.Name = "pdfCntrl_RSNManual";
            this.pdfCntrl_RSNManual.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("pdfCntrl_RSNManual.OcxState")));
            this.pdfCntrl_RSNManual.Size = new System.Drawing.Size(1062, 500);
            this.pdfCntrl_RSNManual.TabIndex = 0;
            // 
            // tpAbstract
            // 
            this.tpAbstract.Controls.Add(this.axPdfAbstract);
            this.tpAbstract.Location = new System.Drawing.Point(4, 26);
            this.tpAbstract.Name = "tpAbstract";
            this.tpAbstract.Padding = new System.Windows.Forms.Padding(3);
            this.tpAbstract.Size = new System.Drawing.Size(1062, 500);
            this.tpAbstract.TabIndex = 6;
            this.tpAbstract.Text = "Abstract guidelines";
            this.tpAbstract.UseVisualStyleBackColor = true;
            // 
            // tpIndxManual
            // 
            this.tpIndxManual.Controls.Add(this.axPdfIndxManual);
            this.tpIndxManual.Location = new System.Drawing.Point(4, 26);
            this.tpIndxManual.Name = "tpIndxManual";
            this.tpIndxManual.Size = new System.Drawing.Size(1062, 500);
            this.tpIndxManual.TabIndex = 7;
            this.tpIndxManual.Text = "Indexing Manual";
            this.tpIndxManual.UseVisualStyleBackColor = true;
            // 
            // tpRoleIndicators
            // 
            this.tpRoleIndicators.Controls.Add(this.axPdfRoleInd);
            this.tpRoleIndicators.Location = new System.Drawing.Point(4, 26);
            this.tpRoleIndicators.Name = "tpRoleIndicators";
            this.tpRoleIndicators.Size = new System.Drawing.Size(1062, 500);
            this.tpRoleIndicators.TabIndex = 8;
            this.tpRoleIndicators.Text = "Role Indicators";
            this.tpRoleIndicators.UseVisualStyleBackColor = true;
            // 
            // axPdfIndxManual
            // 
            this.axPdfIndxManual.Dock = System.Windows.Forms.DockStyle.Fill;
            this.axPdfIndxManual.Enabled = true;
            this.axPdfIndxManual.Location = new System.Drawing.Point(0, 0);
            this.axPdfIndxManual.Name = "axPdfIndxManual";
            this.axPdfIndxManual.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axPdfIndxManual.OcxState")));
            this.axPdfIndxManual.Size = new System.Drawing.Size(1062, 500);
            this.axPdfIndxManual.TabIndex = 1;
            // 
            // axPdfRoleInd
            // 
            this.axPdfRoleInd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.axPdfRoleInd.Enabled = true;
            this.axPdfRoleInd.Location = new System.Drawing.Point(0, 0);
            this.axPdfRoleInd.Name = "axPdfRoleInd";
            this.axPdfRoleInd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axPdfRoleInd.OcxState")));
            this.axPdfRoleInd.Size = new System.Drawing.Size(1062, 500);
            this.axPdfRoleInd.TabIndex = 1;
            // 
            // axPdfAbstract
            // 
            this.axPdfAbstract.Dock = System.Windows.Forms.DockStyle.Fill;
            this.axPdfAbstract.Enabled = true;
            this.axPdfAbstract.Location = new System.Drawing.Point(3, 3);
            this.axPdfAbstract.Name = "axPdfAbstract";
            this.axPdfAbstract.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axPdfAbstract.OcxState")));
            this.axPdfAbstract.Size = new System.Drawing.Size(1056, 494);
            this.axPdfAbstract.TabIndex = 2;
            // 
            // tpTitle
            // 
            this.tpTitle.Controls.Add(this.axPdfTitle);
            this.tpTitle.Location = new System.Drawing.Point(4, 26);
            this.tpTitle.Name = "tpTitle";
            this.tpTitle.Padding = new System.Windows.Forms.Padding(3);
            this.tpTitle.Size = new System.Drawing.Size(1200, 500);
            this.tpTitle.TabIndex = 9;
            this.tpTitle.Text = "Title";
            this.tpTitle.UseVisualStyleBackColor = true;
            // 
            // tpStereoChem
            // 
            this.tpStereoChem.Controls.Add(this.axPdfStereoChem);
            this.tpStereoChem.Location = new System.Drawing.Point(4, 26);
            this.tpStereoChem.Name = "tpStereoChem";
            this.tpStereoChem.Padding = new System.Windows.Forms.Padding(3);
            this.tpStereoChem.Size = new System.Drawing.Size(1200, 500);
            this.tpStereoChem.TabIndex = 10;
            this.tpStereoChem.Text = "StereoChemistry";
            this.tpStereoChem.UseVisualStyleBackColor = true;
            // 
            // axPdfTitle
            // 
            this.axPdfTitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.axPdfTitle.Enabled = true;
            this.axPdfTitle.Location = new System.Drawing.Point(3, 3);
            this.axPdfTitle.Name = "axPdfTitle";
            this.axPdfTitle.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axPdfTitle.OcxState")));
            this.axPdfTitle.Size = new System.Drawing.Size(1194, 494);
            this.axPdfTitle.TabIndex = 1;
            // 
            // axPdfStereoChem
            // 
            this.axPdfStereoChem.Dock = System.Windows.Forms.DockStyle.Fill;
            this.axPdfStereoChem.Enabled = true;
            this.axPdfStereoChem.Location = new System.Drawing.Point(3, 3);
            this.axPdfStereoChem.Name = "axPdfStereoChem";
            this.axPdfStereoChem.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axPdfStereoChem.OcxState")));
            this.axPdfStereoChem.Size = new System.Drawing.Size(1194, 494);
            this.axPdfStereoChem.TabIndex = 1;
            // 
            // frmCASREACTHelp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1208, 530);
            this.Controls.Add(this.tbCntrl_Pdfs);
            this.Name = "frmCASREACTHelp";
            this.Text = "CASREACT Help";
            this.Load += new System.EventHandler(this.frmCASREACTHelp_Load);
            this.tbCntrl_Pdfs.ResumeLayout(false);
            this.tpInputManual.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pdfCntrl_Input)).EndInit();
            this.tpCodingHints.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pdfCntrl_CHints)).EndInit();
            this.tpGenRmdrs_Conds.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pdfCntrl_Conds)).EndInit();
            this.tpStructConvensions.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.axPdfStructConv)).EndInit();
            this.tpProtocol_Updates.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pdfCntrl_pUpdates)).EndInit();
            this.tpRSNManual.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pdfCntrl_RSNManual)).EndInit();
            this.tpAbstract.ResumeLayout(false);
            this.tpIndxManual.ResumeLayout(false);
            this.tpRoleIndicators.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.axPdfIndxManual)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axPdfRoleInd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axPdfAbstract)).EndInit();
            this.tpTitle.ResumeLayout(false);
            this.tpStereoChem.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.axPdfTitle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axPdfStereoChem)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tbCntrl_Pdfs;
        private System.Windows.Forms.TabPage tpInputManual;
        private System.Windows.Forms.TabPage tpCodingHints;
        private System.Windows.Forms.TabPage tpGenRmdrs_Conds;
        private System.Windows.Forms.TabPage tpStructConvensions;
        private System.Windows.Forms.TabPage tpProtocol_Updates;
        private System.Windows.Forms.TabPage tpRSNManual;
        private AxAcroPDFLib.AxAcroPDF pdfCntrl_Input;
        private AxAcroPDFLib.AxAcroPDF pdfCntrl_CHints;
        private AxAcroPDFLib.AxAcroPDF pdfCntrl_Conds;
        private AxAcroPDFLib.AxAcroPDF axPdfStructConv;
        private AxAcroPDFLib.AxAcroPDF pdfCntrl_pUpdates;
        private AxAcroPDFLib.AxAcroPDF pdfCntrl_RSNManual;
        private System.Windows.Forms.TabPage tpAbstract;
        private System.Windows.Forms.TabPage tpIndxManual;
        private System.Windows.Forms.TabPage tpRoleIndicators;
        private AxAcroPDFLib.AxAcroPDF axPdfIndxManual;
        private AxAcroPDFLib.AxAcroPDF axPdfRoleInd;
        private AxAcroPDFLib.AxAcroPDF axPdfAbstract;
        private System.Windows.Forms.TabPage tpTitle;
        private System.Windows.Forms.TabPage tpStereoChem;
        private AxAcroPDFLib.AxAcroPDF axPdfTitle;
        private AxAcroPDFLib.AxAcroPDF axPdfStereoChem;
    }
}