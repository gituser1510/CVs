﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarrDAL;
using IndxReactNarr.Generic;

namespace IndxReactNarr
{
    public partial class frmDuplicateTAN : Form
    {
        public frmDuplicateTAN()
        {
            InitializeComponent();
        }

        private void btnGetTans_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dtB_TANS = CASRxnDataAccess.GetCuratedTANsOnBatch(txtfilename.Text.Trim(), Convert.ToInt32(txtBNo.Text.Trim()));
                if (dtB_TANS != null)
                {
                    if (dtB_TANS.Rows.Count > 0)
                    {
                        cmbTANs.DataSource = dtB_TANS;
                        cmbTANs.DisplayMember = dtB_TANS.Columns["TAN"].ColumnName;
                        cmbTANs.SelectedIndex = 0;

                       DataTable dtNrn_Reg = DAL.CASRxnDataAccess.GetTanNum_RegNoDetails(cmbTANs.Text.ToString());

                       if (dtNrn_Reg != null)
                       {          
                           dgvSrcTan.AutoGenerateColumns = false;

                           dgvSrcTan.DataSource = dtNrn_Reg;
                           dgvSrcTan.Columns["colTAN_Src"].DataPropertyName = dtNrn_Reg.Columns["tan"].ColumnName;
                           dgvSrcTan.Columns["colNUM_Src"].DataPropertyName = dtNrn_Reg.Columns["nrnnum"].ColumnName;
                           dgvSrcTan.Columns["colReg_Src"].DataPropertyName = dtNrn_Reg.Columns["nrnreg"].ColumnName;
                       }
                    }
                    else
                    {
                        cmbTANs.DataSource = null;
                        MessageBox.Show("No TANs found for the batch");
                    }
                }
                else
                {
                    cmbTANs.DataSource = null;
                    MessageBox.Show("No TANs found for the batch");
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }     

        private void btnDuplicate_Click(object sender, EventArgs e)
        {
            try
            {
                string strErrMsg = "";
                if (ValidateUserInputs(out strErrMsg))
                {
                    string strTAN_src = cmbTANs.Text.ToString();
                    string strTAN_trgt = cmbTANs_Trgt.Text.ToString();
                    string strCAN = txtCAN.Text.Trim();

                    string strBatch_New = txtBName_New.Text.Trim();
                    int intBNo_new = Convert.ToInt32(txtBNo_New.Text.Trim());
                    int intAnalyst = Convert.ToInt32(txtAnalyst.Text.Trim());

                    if (CASRxnDataAccess.DuplicateTANData(strTAN_src, strTAN_trgt, strCAN, strBatch_New, intBNo_new, intAnalyst,GlobalVariables.UserID))
                    {
                        MessageBox.Show(strTAN_src + " duplicated to " + strTAN_trgt + " successfully","Duplicate TAN",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Error in Duplicating " + strTAN_src + " to " + strTAN_trgt + "\r\nCheck whether NRNNUM & NRNReg are same or not" ,"Duplicate TAN",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show(strErrMsg, "Duplicate TAN", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private bool ValidateUserInputs(out string _errmsg)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (txtBName_New.Text.Trim() == "" || txtBName_New.Text == null)
                {
                    strErrMsg = strErrMsg + "\r\n" + "Batch Name field can't be blank";
                    blStatus = false;                    
                }
                else if (txtBNo_New.Text.Trim() == "" || txtBNo_New.Text == null)
                {
                    strErrMsg = strErrMsg + "\r\n" + "Batch No. field can't be blank";
                    blStatus = false;                   
                }
                else if (txtAnalyst.Text.Trim() == "" || txtAnalyst.Text == null)
                {
                    strErrMsg = strErrMsg + "\r\n" + "Analyst field can't be blank";
                    blStatus = false;                   
                }
                else if (cmbTANs_Trgt.SelectedItem == null)
                {
                    strErrMsg = strErrMsg + "\r\n" + "Target TAN can't be null";
                    blStatus = false;                   
                }
                else if (txtCAN.Text.Trim() == "" || txtCAN.Text == null)
                {
                    strErrMsg = strErrMsg + "\r\n" + "CAN field can't be blank";
                    blStatus = false;                   
                }                
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg.Trim();
            return blStatus;
        }

        private void btnGet_TrgtTAN_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dtB_TANS = CASRxnDataAccess.GetCuratedTANsOnBatch(txtBName_New.Text.Trim(), Convert.ToInt32(txtBNo_New.Text.Trim()));
                if (dtB_TANS != null)
                {
                    if (dtB_TANS.Rows.Count > 0)
                    {
                        cmbTANs_Trgt.DataSource = dtB_TANS;
                        cmbTANs_Trgt.DisplayMember = dtB_TANS.Columns["TAN"].ColumnName;
                        cmbTANs_Trgt.SelectedIndex = 0;
                    }
                    else
                    {
                        cmbTANs_Trgt.DataSource = null;
                        MessageBox.Show("No TANs found for the batch");
                    }
                }
                else
                {
                    cmbTANs_Trgt.DataSource = null;
                    MessageBox.Show("No TANs found for the batch");
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        

        private void cmbTANs_Trgt_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbTANs_Trgt.Text  != null)
                {
                    string strCAN = CASRxnDataAccess.GetCANOnBatchTAN(txtBName_New.Text.Trim(), cmbTANs_Trgt.Text.ToString());
                    if (strCAN != "")
                    {
                        txtCAN.Text = strCAN;
                    }

                    DataTable dtNrn_Reg = DAL.CASRxnDataAccess.GetTanNum_RegNoDetails(cmbTANs_Trgt.Text.ToString());

                    if (dtNrn_Reg != null)
                    {
                        dgvTrgt.AutoGenerateColumns = false;

                        dgvTrgt.DataSource = dtNrn_Reg;
                        dgvTrgt.Columns["colTAN_Trgt"].DataPropertyName = dtNrn_Reg.Columns["tan"].ColumnName;
                        dgvTrgt.Columns["colNUM_Trgt"].DataPropertyName = dtNrn_Reg.Columns["nrnnum"].ColumnName;
                        dgvTrgt.Columns["colReg_Trgt"].DataPropertyName = dtNrn_Reg.Columns["nrnreg"].ColumnName;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvSrcTan_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvSrcTan.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvSrcTan.Font);

                if (dgvSrcTan.RowHeadersWidth < (int)(size.Width + 20)) dgvSrcTan.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvTrgt_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvTrgt.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvTrgt.Font);

                if (dgvTrgt.RowHeadersWidth < (int)(size.Width + 20)) dgvTrgt.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void cmbTANs_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                DataTable dtNrn_Reg = DAL.CASRxnDataAccess.GetTanNum_RegNoDetails(cmbTANs.Text.ToString());

                if (dtNrn_Reg != null)
                {
                    dgvSrcTan.AutoGenerateColumns = false;

                    dgvSrcTan.DataSource = dtNrn_Reg;
                    dgvSrcTan.Columns["colTAN_Src"].DataPropertyName = dtNrn_Reg.Columns["tan"].ColumnName;
                    dgvSrcTan.Columns["colNUM_Src"].DataPropertyName = dtNrn_Reg.Columns["nrnnum"].ColumnName;
                    dgvSrcTan.Columns["colReg_Src"].DataPropertyName = dtNrn_Reg.Columns["nrnreg"].ColumnName;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        
    }
}
