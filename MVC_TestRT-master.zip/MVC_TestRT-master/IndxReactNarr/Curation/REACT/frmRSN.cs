﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using System.IO;
using IndxReactNarrDAL;
using System.Collections;
using System.Text.RegularExpressions;
using System.Globalization;
using IndxReactNarr.Common;

namespace IndxReactNarr
{
    public partial class frmRSN : Form
    {
        public frmRSN()
        {
            InitializeComponent();
        }

        #region Property Procedures

        public int ReactionID
        { get; set; }

        public int StageID
        { get; set; }

        public string StageName
        { get; set; }

        public int StageIndex
        { get; set; }

        public DataTable RSNData
        { get; set; }

        public DataTable CVTData
        { get; set; }

        public DataTable FreeTextData
        { get; set; }

        public DataTable StageFreeTextData
        { get; set; } 

        public TabControl TabCntrl_Stages
        { get; set; }

        public DataTable FT_StagesData
        { get; set; }

        #endregion

        private void frmRSN_Load(object sender, EventArgs e)
        {
            try
            {
                CVTData = GlobalVariables.RSN_CVT_Tbl;
                FreeTextData = GlobalVariables.RSN_FreeText_Tbl;
                StageFreeTextData = FreeTextData.Copy(); //GlobalVariables.RSN_StageFreeTextTbl; --Modified on 23rdSEP2015
          
                BindRSNDataToGrid(RSNData);
                               
                //Get User Dictionary and bind to control
                string strFilepath = AppDomain.CurrentDomain.BaseDirectory + "UserDictFile.txt";
                rapidSpellAsYouType1.UserDictionaryFile = strFilepath;

                //Set American English dictionary
                rapidSpellAsYouType1.DictFilePath = AppDomain.CurrentDomain.BaseDirectory + "DICT-EN-US-USEnglish.dict";

                if (StageName.ToUpper() != "STAGE 1")
                {
                    rbnStage.Checked = true;
                    rbnReaction.Enabled = false;

                    //code commentd on 30th Sep 2015
                    //pnlCVT_Entry.Visible = false;
                }
                else
                {
                    rbnStage.Checked = false;
                    rbnReaction.Checked = true;
                    rbnReaction.Enabled = true;
                }

                //Set RSN length values
                SetStagesRSNLenthValues();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void SetStagesRSNLenthValues()
        {
            try
            {
                //Set Current Stage RSN length - 26th Nov 2013    
                int intRsnLen = GetRSNLengthFromTable(RSNData);
                lblCurStgRsnLength.Text = intRsnLen.ToString();

                //Get Other Stages RSN Length 
                int intOthStgRsnLen = GetOtherStagesRSNLength();
                lblOthStgRSNLength.Text = intOthStgRsnLen.ToString();

                //Set Total RSN length
                lblTotalRSNLength.Text = (intRsnLen + intOthStgRsnLen).ToString();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindCVTDataToGrid(DataTable cvtdata)
        {
            try
            {
                if (cvtdata != null)
                {
                    dgvCVT.AutoGenerateColumns = false;
                    dgvCVT.DataSource = cvtdata;
                    colCVT.DataPropertyName = "cvt";
                }
                else
                {
                    dgvCVT.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindFreeTextDataToGrid(DataTable freetextdata)
        {
            try
            {
                if (freetextdata != null)
                {
                    dgvFreeText.AutoGenerateColumns = false;
                    dgvFreeText.DataSource = freetextdata;
                    colFreeText.DataPropertyName = "freetext";
                }
                else
                {
                    dgvFreeText.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindRSNDataToGrid(DataTable rsndata)
        {
            try
            {
                if (rsndata != null)
                {
                    dgvRSN.AutoGenerateColumns = false;
                    dgvRSN.DataSource = rsndata;

                    colCVT_RSN.DataPropertyName = "CVT";
                    colFreeText_RSN.DataPropertyName = "FREE_TEXT";
                    colSelect.DataPropertyName = "NOTE_LEVEL";

                    //Auto Resize rows
                    for (int i = 0; i < dgvRSN.Rows.Count; i++)
                    {
                        dgvRSN.AutoResizeRow(i, DataGridViewAutoSizeRowMode.AllCells);
                    }
                }
                else
                {
                    dgvRSN.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        

        #region Grid Cell DoubleClick Events
        
        private void dgvCVT_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                {
                    txtCVT.Text = dgvCVT.CurrentCell.Value.ToString();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvFreeText_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                {
                    if (rbnReplace_FT.Checked)
                    {
                        if (rbnReaction.Checked)
                        {
                            rtxtFreeText.Text = dgvFreeText.CurrentCell.Value.ToString();
                        }
                        else if (rbnStage.Checked)
                        {
                            rtxtFreeText.Text = dgvFreeText.CurrentCell.Value.ToString() + " (" + StageName.ToLower() + ")";
                        }
                    }
                    else if (rbnAppend_FT.Checked)
                    {
                        if (rbnReaction.Checked)
                        {
                            if (!rtxtFreeText.Text.Trim().Contains(dgvFreeText.CurrentCell.Value.ToString()))
                            {
                                if (string.IsNullOrEmpty(rtxtFreeText.Text.Trim()))
                                {
                                    rtxtFreeText.Text = dgvFreeText.CurrentCell.Value.ToString();
                                }
                                else
                                {
                                    rtxtFreeText.Text = rtxtFreeText.Text.Trim() + ", " + dgvFreeText.CurrentCell.Value.ToString();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Selected FreeText already exist", "RSN", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        else if (rbnStage.Checked)
                        {
                            if (!rtxtFreeText.Text.Trim().Contains(dgvFreeText.CurrentCell.Value.ToString()))
                            {
                                if (string.IsNullOrEmpty(rtxtFreeText.Text.Trim()))
                                {
                                    rtxtFreeText.Text = dgvFreeText.CurrentCell.Value.ToString() + " (" + StageName.ToLower() + ")";
                                }
                                else
                                {
                                    rtxtFreeText.Text = rtxtFreeText.Text.Trim() + ", " + dgvFreeText.CurrentCell.Value.ToString() + " (" + StageName.ToLower() + ")";
                                }
                            }
                            else
                            {
                                MessageBox.Show("Selected FreeText already exist", "RSN", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        } 
        
        #endregion

        private void rbnReaction_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (rbnReaction.Checked)
                {
                    splCntCVT_FT.Panel1Collapsed = false;

                    BindCVTDataToGrid(CVTData);
                    BindFreeTextDataToGrid(FreeTextData); 

                    dgvCVT.Rows[0].Selected = true;

                    lblStage.Text = "";
                    
                    txtCVT.Text = "";
                    rtxtFreeText.Text = "";
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnStage_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (rbnStage.Checked)
                {
                    //splCntCVT_FT.Panel1Collapsed = true;

                    txtCVT.Text = "";
                    rtxtFreeText.Text = "";

                    lblStage.Text = StageName;

                    BindFreeTextDataToGrid(StageFreeTextData);

                    //New code - 29th Sep 2015
                    BindCVTDataToGrid(CVTData);
                }               
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        } 

        #region Grid Row PostPaint Events
        
        private void dgvCVT_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvCVT.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvCVT.Font);

                if (dgvCVT.RowHeadersWidth < (int)(size.Width + 20)) dgvCVT.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvFreeText_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvFreeText.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvFreeText.Font);

                if (dgvFreeText.RowHeadersWidth < (int)(size.Width + 20)) dgvFreeText.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvRSN_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvRSN.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvRSN.Font);

                if (dgvRSN.RowHeadersWidth < (int)(size.Width + 20)) dgvRSN.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }         
        
        #endregion

        #region TextBox TextChanged Events
        
        private void txtSrch_CVT_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtSrch_CVT.Text) && CVTData != null)
                {
                    DataView dvTemp = CVTData.Copy().DefaultView;
                    dvTemp.RowFilter = "cvt like '" + txtSrch_CVT.Text.Trim() + "%' ";
                    DataTable dtFiltData = dvTemp.ToTable();
                    BindCVTDataToGrid(dtFiltData);
                }
                else
                {
                    BindCVTDataToGrid(CVTData);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtSrch_FreeText_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (rbnReaction.Checked)
                {
                    if (!string.IsNullOrEmpty(txtSrch_FreeText.Text) && FreeTextData != null)
                    {
                        DataView dvTemp = FreeTextData.Copy().DefaultView;
                        dvTemp.RowFilter = "freetext like '" + DataConversions.EscapeSpecialCharsInFilterCondition(txtSrch_FreeText.Text.Trim()) + "%' ";
                        DataTable dtFiltData = dvTemp.ToTable();
                        BindFreeTextDataToGrid(dtFiltData);
                    }
                    else
                    {
                        BindFreeTextDataToGrid(FreeTextData);
                    }
                }
                else if (rbnStage.Checked)
                {
                    if (!string.IsNullOrEmpty(txtSrch_FreeText.Text) && StageFreeTextData != null)
                    {
                        DataView dvTemp = StageFreeTextData.Copy().DefaultView;
                        dvTemp.RowFilter = "freetext like '" + DataConversions.EscapeSpecialCharsInFilterCondition(txtSrch_FreeText.Text.Trim()) + "%' ";
                        DataTable dtFiltData = dvTemp.ToTable();
                        BindFreeTextDataToGrid(dtFiltData);
                    }
                    else
                    {
                        BindFreeTextDataToGrid(StageFreeTextData);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        } 
        
        #endregion
                
        private bool ValidateCVTFreeTextUserInputs(out string errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                //FreeText & CVT Null values Validation
                if (string.IsNullOrEmpty(txtCVT.Text.Trim()) && string.IsNullOrEmpty(rtxtFreeText.Text.Trim()))
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Please enter CVT / FreeText";
                }
                
                if (!string.IsNullOrEmpty(rtxtFreeText.Text.Trim()))
                {
                    if (rtxtFreeText.Text.Trim().EndsWith(","))//cama at the end validation
                    {
                        blStatus = false;
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "' , ' at the end is not allowed in FreeText";
                    }
                    if (rtxtFreeText.Text.Trim().Contains(",,"))//double cama validation
                    {
                        blStatus = false;
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "' ,, ' not allowed in FreeText";
                    }
                    if (rtxtFreeText.Text.Trim().Contains(";"))// semicolon validation
                    {
                        blStatus = false;
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "' ; ' not allowed in FreeText";
                    }
                    if (rtxtFreeText.Text.Trim().Contains("))"))// double brackets validation
                    {
                        blStatus = false;
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "' )) ' not allowed in FreeText";
                    }
                    if (Common.Validations.ValidateUnicodeCharactersInString(rtxtFreeText.Text.Trim()))//New validation on 18th Feb 2014
                    {
                        blStatus = false;
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "FreeText contains special characters";
                    }
                }
                
                //Multiple CVT validation
                if (!string.IsNullOrEmpty(txtCVT.Text.Trim()))
                {
                   int intCVTCnt = GetCVTRecordsCount(txtCVT.Text.Trim());
                   //if (intCVTCnt >= 1 && editRowIndx == 0)
                   //{
                   //    blStatus = false;
                   //    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "CVT term '" + txtCVT.Text.Trim() + "' already exist";
                   //}
                   if (intCVTCnt >= 1 && (strCVT_Edit != txtCVT.Text.Trim()))
                   {
                       blStatus = false;
                       strErrMsg = strErrMsg.Trim() + Environment.NewLine + "CVT term '" + txtCVT.Text.Trim() + "' already exist";
                   }
                }
                
                //Single FreeText validation
                string strReaction_Stage = "Reaction";
                if (rbnStage.Checked)
                {
                    strReaction_Stage = "Stage";
                }

                if (strReaction_Stage == "Stage") //if (!string.IsNullOrEmpty(rtxtFreeText.Text.Trim()))--modification on 2nd Apr 2013
                {
                    if (string.IsNullOrEmpty(txtCVT.Text.Trim()) && !string.IsNullOrEmpty(rtxtFreeText.Text.Trim()))//Without CVT, only one FreeText is allowed-30th Sep 2015
                    {
                        int intFreeTextCnt = GetReaction_Stage_FreeTextRecordsCount(strReaction_Stage.ToUpper());
                        if (intFreeTextCnt == 1 && editRowIndx == -1)
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Without CVT, only One FreeText term is allowed";
                        }
                        else if (intFreeTextCnt == 1 && editRowIndx > 0)
                        {
                            if (strFreeText_Edit.Trim() == "")
                            {
                                blStatus = false;
                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Without CVT, only One FreeText term is allowed";
                            }
                        }
                    }

                    //Client feedback on Stage level CVT on 27th Sep 2015
                    //By default, CVT in the “RSN TYPE” are not tied to a particular stage of the reaction, but belong to the whole reaction. For example, “optimization study” in the following excerpt belongs to the whole reaction:
                    //<RXNPROCESS>
                    //  <RSN TYPE="optimization study"/>
                    //   <STAGE>
                    //If, however, a controlled vocabulary term needs to relate to a single stage, or has other information, this is the appropriate handling:
                    //<RXNPROCESS>
                    // <RSN TYPE="optimized on stoichiometry">optimized on stoichiometry of reactant</RSN>
                    
                    //New validation on 29th Sep 2015
                    if (!string.IsNullOrEmpty(txtCVT.Text.Trim()) && string.IsNullOrEmpty(rtxtFreeText.Text.Trim()))
                    {
                        blStatus = false;
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "When Stage level CVT is used, FreeText is mandatory.";
                    }
                    //else if (!string.IsNullOrEmpty(rtxtFreeText.Text.Trim()))//New validation on 29th Sep 2015
                    //{
                    //    //Stage Level FreeText contain CVT term validation
                    //    string strCVTOut = "";
                    //    if (CheckReactionLevelFreeTextContainsCVTTerm(rtxtFreeText.Text.Trim(), strReaction_Stage.ToUpper(), out strCVTOut))
                    //    {
                    //        blStatus = false;
                    //        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Stage level FreeText contains CVT term ' " + strCVTOut + " ' ";
                    //    }
                    //}
                }                

                ////Reaction level - Allow multiple FreeText in Reaction level - New validation on 2nd April 2013
                if (rbnReaction.Checked)
                {
                    if (string.IsNullOrEmpty(txtCVT.Text.Trim()) && !string.IsNullOrEmpty(rtxtFreeText.Text.Trim()))
                    {
                        int intRxnFreeCnt = GetReactionFreeTextOnlyRecordsCount("REACTION");
                        if (intRxnFreeCnt > 0 && editRowIndx == -1)
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Only One Reaction level FreeText term is allowed";
                        }
                    }
                    else if (!string.IsNullOrEmpty(txtCVT.Text.Trim()) && !string.IsNullOrEmpty(rtxtFreeText.Text.Trim()))
                    {
                        if (strFreeText_Edit.Trim() != rtxtFreeText.Text.Trim())
                        {
                            string strErr_FT = "";
                            //Check distinct Reaction level FreeText terms
                            if (!CheckForUniqueREactionLevelFreeTextTermInReaction(rtxtFreeText.Text.Trim(), out strErr_FT))
                            {
                                blStatus = false;
                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + strErr_FT;
                            }
                        }
                    }
                }

                //Reaction Level FreeText contain CVT term validation
                string strCVT = "";
                if (CheckFreeTextContainsCVTTerm(rtxtFreeText.Text.Trim(),strReaction_Stage, out strCVT))
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + strReaction_Stage + " level FreeText contains CVT term ' " + strCVT + " ' ";
                }
                
                //Check for unique FreeText in all stages of the reaction
                string strErr_CVT = "";
                if (!CheckForUniqueTermInReaction("FreeText", rtxtFreeText.Text.Trim(), out strErr_CVT))
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + strErr_CVT.Trim();
                }

                //Check for unique CVT terms in all stages of the reaction
                string strErrFT = "";
                if (!CheckForUniqueTermInReaction("CVT", txtCVT.Text.Trim(), out strErrFT))
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + strErrFT.Trim();
                }

                //Reaction level FreeText contains Stage Name/Stage
                if (rbnReaction.Checked && rtxtFreeText.Text.Trim().ToUpper().Contains("STAGE"))
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Reaction level FreeText should not contain Stage information";
                }

                string ErrMsg = "";
                //Stage level FreeText contains Stage Name/Stage
                if (rbnStage.Checked)
                {      
                    if (!CheckForFreeText_StageValidation(out  ErrMsg))
                    {
                        blStatus = false;
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + ErrMsg.Trim();
                    }
                }

                //RSN FreeText - RegNo Validation - New validation as on 23rd April 2012
                if (!CheckForRSNToNrnRegValidations(out ErrMsg))
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + ErrMsg.Trim();
                }

                //Failed reaction validation as first CVT term - New validation on 5th Apr 2016
                if (ValidateFailedReactionTermInCVT(out ErrMsg))
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + ErrMsg.Trim();
                }

                //Skip validations in Tool Manager/Admin level
                if (GlobalVariables.SkipValidations)
                {
                    blStatus = true;
                    strErrMsg = "";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg.Trim();
            return blStatus;
        }

        private bool ValidateFailedReactionTermInCVT(out string errMsgOut)
        {
            bool blStatus = false;
            string errMsg = "";
            try
            {
                if (txtCVT.Text.Trim().ToUpper() == "FAILED REACTION" && dgvRSN.Rows.Count > 0)
                {
                    blStatus = true;
                    errMsg = "failed reaction should be the first phrase in the RSN";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsgOut = errMsg;
            return blStatus;
        }

        private bool ValidateRSNData(out string errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                string ErrMsg = "";
                if (CheckForRSN_Free_Stage_Validation(out ErrMsg))
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + ErrMsg;
                } 
               
                //Validate RSN length - Max is 500 chars - 26th Nov 2013
                int intCurStgRSNLen = GetRSNLengthFromTable(RSNData);
                int intOthStgRSNLen = GetOtherStagesRSNLength();

                if ((intCurStgRSNLen + intOthStgRSNLen) > 500)
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "RSN maximum length should be <= 500 characters";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg;
            return blStatus;
        }

        private int GetCVTRecordsCount(string cvt)
        {
            int intRecCnt = 0;
            try
            {
                if (RSNData != null)
                {
                    var cnt = (from dr in RSNData.AsEnumerable()
                               where dr.Field<string>("CVT") == cvt && dr.Field<string>("NOTE_LEVEL") == "Reaction"
                               select dr).Count();
                    intRecCnt = cnt;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return intRecCnt;
        }

        private int GetReaction_Stage_FreeTextRecordsCount(string reaction_stage)
        {
            int intRecCnt = 0;
            try
            {
                if (RSNData != null)
                {
                    //var cnt = (from dr in RSNData.AsEnumerable()
                    //           where dr.Field<string>("rsn_free_text") != "" && dr.Field<string>("rsn_combined") == reaction_stage
                    //           select dr).Count();
                                       
                    var rows = from dr in RSNData.AsEnumerable()
                               where dr.Field<string>("FREE_TEXT") != "" && dr.Field<string>("CVT") == "" && dr.Field<string>("NOTE_LEVEL").ToUpper() == reaction_stage
                               select dr;

                    if(rows != null)
                    {
                       intRecCnt = rows.Count();
                    }

                    //var cnt = (from dr in RSNData.AsEnumerable()
                    //           where dr.Field<string>("FREE_TEXT") != "" && dr.Field<string>("NOTE_LEVEL").ToUpper() == reaction_stage
                    //           select dr).Count();
                    //intRecCnt = cnt;                    
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return intRecCnt; 
        }

        private int GetReactionFreeTextOnlyRecordsCount(string reaction_stage)
        {
            int intRecCnt = 0;
            try
            {
                if (RSNData != null)
                {
                    var cnt = (from dr in RSNData.AsEnumerable()
                               where dr.Field<string>("FREE_TEXT") != "" && (dr.Field<string>("CVT") == "" || dr.Field<string>("CVT") == null) && dr.Field<string>("NOTE_LEVEL").ToUpper() == reaction_stage
                               select dr).Count();

                    intRecCnt = cnt;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return intRecCnt;
        }

        private DataTable GetFreeText_StagesData()
        {
            DataTable dtFT_Stages = null;
            try
            {                
                if (!string.IsNullOrEmpty(rtxtFreeText.Text.Trim()))
                {
                    string strFT = rtxtFreeText.Text.Trim();
                    strFT = strFT.Replace("),", ")`");

                    string[] splitter = { "`" };
                    string[] saValues = strFT.Split(splitter, StringSplitOptions.RemoveEmptyEntries);

                    dtFT_Stages = new DataTable();
                    dtFT_Stages.Columns.Add("FreeText");
                    dtFT_Stages.Columns.Add("StageInfo");

                    string strFreeText = "";
                    string strStageInfo = "";                    
                    DataRow dRow = null;

                    for (int i = 0; i < saValues.Length; i++)
                    {
                        if (saValues[i].Trim().ToUpper().Contains(" (STAGE "))
                        {
                            string pattern = @"\(stage ";
                            string replacement = @"~(stage ";
                            Regex rgx = new Regex(pattern, RegexOptions.IgnoreCase);
                            string result = rgx.Replace(saValues[i].Trim(), replacement);

                            string[] splter = { "~" };
                            string[] saFTVals = result.Split(splter, StringSplitOptions.RemoveEmptyEntries);

                            if (saFTVals != null)
                            {
                                if (saFTVals.Length > 0)
                                {
                                    strFreeText = saFTVals[0].Trim();
                                    strStageInfo = saFTVals[1].Trim();
                                }
                            }                            
                        }
                        else if (saValues[i].Trim().ToUpper().Contains(" (STAGES "))
                        {
                            string pattern = @"\(stages ";
                            string replacement = @"~(stages ";
                            Regex rgx = new Regex(pattern, RegexOptions.IgnoreCase);
                            string result = rgx.Replace(saValues[i].Trim(), replacement);

                            string[] splter = { "~" };
                            string[] saFTVals = result.Split(splter, StringSplitOptions.RemoveEmptyEntries);

                            if (saFTVals != null)
                            {
                                if (saFTVals.Length > 0)
                                {
                                    strFreeText = saFTVals[0].Trim();
                                    strStageInfo = saFTVals[1].Trim();
                                }
                            }   
                        }

                        if (!string.IsNullOrEmpty(strFreeText))
                        {
                            dRow = dtFT_Stages.NewRow();

                            dRow["FreeText"] = strFreeText;
                            dRow["StageInfo"] = strStageInfo;

                            dtFT_Stages.Rows.Add(dRow);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtFT_Stages;
        }

        private string GetStageIndexFromStageName(string stagename)
        {
            string strStgIndx = "";
            try
            {
                if (!string.IsNullOrEmpty(stagename.Trim()))
                {
                    string[] saTemp = stagename.Trim().Split(' ');
                    if (saTemp != null)
                    {
                        if (saTemp.Length > 0)
                        {
                            strStgIndx = saTemp[1].Trim();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strStgIndx;
        }

        private bool SplitAndCheckForNumbersInStagesValidateStages(string stagesinfo, string splter,string currstg_index, ArrayList stageslist, out bool stgs_oth_ordr, out string errmsg_out)
        {
            bool blNumsStatus = false;
            bool blOther_Order = false;
            string strErrMsg = "";
            try
            {
                if (!string.IsNullOrEmpty(stagesinfo.Trim()) && !string.IsNullOrEmpty(splter.Trim()) && stageslist != null)
                {
                    string pattern = splter;                  
                    Regex rgx = new Regex(pattern, RegexOptions.IgnoreCase);                  
                    string[] saStages =  rgx.Split(stagesinfo.Trim());

                    if (saStages != null)
                    {
                        int intTemp = 0;
                        int intCntr = 0;

                        ArrayList alstOtherStgs = new ArrayList();

                        for (int i = 0; i < saStages.Length; i++)
                        {
                            if (int.TryParse(saStages[i].Trim(), out intTemp))
                            {
                                intCntr++;
                                if (!stageslist.Contains(saStages[i].Trim()))
                                {
                                    alstOtherStgs.Add(saStages[i].Trim());
                                }
                            }
                        }
                        //All are Numbers
                        if (intCntr == saStages.Length)
                        {
                            blNumsStatus = true;
                        }
                        
                        if (blNumsStatus && intCntr > 0)
                        {
                            if (alstOtherStgs.Count > 0)
                            {
                                blOther_Order = true;

                                alstOtherStgs.Sort();

                                string strTemp = string.Join(", ", (string[])alstOtherStgs.ToArray(typeof(string)));

                                strErrMsg = strErrMsg.Trim() + "\r\n" + " Stage(s) " + strTemp + " not exist";
                            }
                            else
                            {
                                intCntr = 0;
                                if (saStages.Length > 1)
                                {
                                    for (int j = 1; j < saStages.Length; j++)
                                    {
                                        if (Convert.ToInt32(saStages[j - 1].Trim()) > Convert.ToInt32(saStages[j].Trim()))
                                        {
                                            intCntr++;
                                        }
                                    }
                                }
                                if (intCntr > 0)
                                {
                                    blOther_Order = true;
                                    strErrMsg = strErrMsg.Trim() + "\r\n" + " Stage information not in order";
                                }
                                else if (saStages.Length == 1)
                                {
                                    blOther_Order = true;
                                    strErrMsg = strErrMsg.Trim() + "\r\n" + " Stage information is not correct";
                                }
                                else if (saStages[0].Trim() != currstg_index)
                                {
                                    blOther_Order = true;
                                    strErrMsg = strErrMsg.Trim() + "\r\n" + " Stage information is not correct";
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg;
            stgs_oth_ordr = blOther_Order;
            return blNumsStatus;

        }

        private bool SplitAndCheckForNumbersInStagesValidateStagesWithHiphen(string stagesinfo, string currstg_index, ArrayList stageslist, out bool stgs_oth_ordr, out string errmsg_out)
        {
            bool blNumsStatus = false;
            bool blOther_Order = false;
            string strErrMsg = "";
            try
            {
                if (!string.IsNullOrEmpty(stagesinfo.Trim()) && stageslist != null)
                {
                    string pattern = "-";                    
                    Regex rgx = new Regex(pattern, RegexOptions.IgnoreCase);
                    string[] saStages = rgx.Split(stagesinfo.Trim());

                    if (saStages != null)
                    {
                        if (saStages.Length == 2)
                        {
                            int intTemp = 0;
                            int intCntr = 0;

                            ArrayList alstOtherStgs = new ArrayList();

                            for (int i = 0; i < saStages.Length; i++)
                            {
                                if (int.TryParse(saStages[i].Trim(), out intTemp))
                                {
                                    intCntr++;
                                    if (!stageslist.Contains(saStages[i].Trim()))
                                    {
                                        alstOtherStgs.Add(saStages[i].Trim());
                                    }
                                }
                            }
                            //All are Numbers
                            if (intCntr == saStages.Length)
                            {
                                blNumsStatus = true;
                            }

                            if (blNumsStatus && intCntr > 0)
                            {
                                if (alstOtherStgs.Count > 0)
                                {
                                    blOther_Order = true;

                                    alstOtherStgs.Sort();

                                    string strTemp = string.Join(", ", (string[])alstOtherStgs.ToArray(typeof(string)));

                                    strErrMsg = strErrMsg.Trim() + "\r\n" + " Stage(s) " + strTemp + " not exist";
                                }
                                else
                                {
                                    intCntr = 0;
                                    if (saStages.Length > 1)
                                    {
                                        for (int j = 1; j < saStages.Length; j++)
                                        {
                                            if (Convert.ToInt32(saStages[j - 1].Trim()) > Convert.ToInt32(saStages[j].Trim()))
                                            {
                                                intCntr++;
                                            }
                                        }
                                    }
                                    if (intCntr > 0)
                                    {
                                        blOther_Order = true;
                                        strErrMsg = strErrMsg.Trim() + "\r\n" + " Stage information not in order";
                                    }
                                    else if (saStages.Length == 1)
                                    {
                                        blOther_Order = true;
                                        strErrMsg = strErrMsg.Trim() + "\r\n" + " Stage information is not correct";
                                    }
                                    else if (saStages[0].Trim() != currstg_index)
                                    {
                                        blOther_Order = true;
                                        strErrMsg = strErrMsg.Trim() + "\r\n" + " Stage information is not correct";
                                    }
                                }
                            }
                        }
                        else//Ex: 3-4-5
                        {
                            blOther_Order = true;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + " Stage information is not correct";
                        }                
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg;
            stgs_oth_ordr = blOther_Order;
            return blNumsStatus;

        }

        private bool CheckMixedTermsInStagesValidateStages(string stagesinfo, string currstg_index, ArrayList stageslist, out string errmsg_out)
        {            
            bool blOther_Order = true;
            string strErrMsg = "";
            try
            {
                if (!string.IsNullOrEmpty(stagesinfo.Trim()) && stageslist != null)
                {
                    string strStageInfo = stagesinfo.Trim();
                    strStageInfo = strStageInfo.Replace(",", "~");
                    strStageInfo = strStageInfo.Replace("-", "~");
                    strStageInfo = strStageInfo.Replace("and", "~");

                    string pattern = "~";                    
                    Regex rgx = new Regex(pattern, RegexOptions.IgnoreCase);
                    string[] saStages = rgx.Split(strStageInfo.Trim());

                    if (saStages != null)
                    {
                        int intTemp = 0;
                        int intCntr = 0;

                        ArrayList alstOtherStgs = new ArrayList();
                        ArrayList alstStgs = new ArrayList();
                        ArrayList alstDupStgs = new ArrayList();

                        for (int i = 0; i < saStages.Length; i++)
                        {
                            if (int.TryParse(saStages[i].Trim(), out intTemp))
                            {
                                intCntr++;
                                if (!stageslist.Contains(saStages[i].Trim()))
                                {
                                    if (!alstOtherStgs.Contains(saStages[i].Trim()))
                                    {
                                        alstOtherStgs.Add(saStages[i].Trim());
                                    }
                                }
                                if (!alstStgs.Contains(saStages[i].Trim()))
                                {
                                    alstStgs.Add(saStages[i].Trim());
                                }
                                else if (!alstDupStgs.Contains(saStages[i].Trim()))
                                {
                                    alstDupStgs.Add(saStages[i].Trim());
                                }
                            }
                            else//Junk Values
                            {
                                blOther_Order = false;
                                strErrMsg = strErrMsg.Trim() + "\r\n" + " Contains junk values";
                            }
                        }

                        if (alstOtherStgs.Count > 0)
                        {
                            blOther_Order = false;

                            alstOtherStgs.Sort();

                            string strTemp = string.Join(", ", (string[])alstOtherStgs.ToArray(typeof(string)));

                            strErrMsg = strErrMsg.Trim() + "\r\n" + " Stage(s) " + strTemp + " not exist";
                        }
                        else if (alstDupStgs.Count > 0)
                        {
                            blOther_Order = false;

                            alstDupStgs.Sort();

                            string strTemp = string.Join(", ", (string[])alstDupStgs.ToArray(typeof(string)));
                            strErrMsg = strErrMsg.Trim() + "\r\n" + " Duplicate stages " + strTemp;
                        }
                        else
                        {
                            intCntr = 0;
                            if (saStages.Length > 1)
                            {
                                for (int j = 1; j < saStages.Length; j++)
                                {
                                    if (Convert.ToInt32(saStages[j - 1].Trim()) > Convert.ToInt32(saStages[j].Trim()))
                                    {
                                        intCntr++;
                                    }                                    
                                }
                            }
                            if (intCntr > 0)
                            {
                                blOther_Order = false;
                                strErrMsg = strErrMsg.Trim() + "\r\n" + " Stage information not in order";
                            }
                            else if (saStages.Length == 1)
                            {
                                blOther_Order = false;
                                strErrMsg = strErrMsg.Trim() + "\r\n" + " Stage information is not correct";
                            }
                            else if (saStages[0].Trim() != currstg_index)
                            {
                                blOther_Order = false;
                                strErrMsg = strErrMsg.Trim() + "\r\n" + " Stage information is not correct";
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg;
            return blOther_Order;

        }

        private bool CheckForDuplicateFreeTextInDataTable(DataTable freetextdata, out string errmsg_out)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                if (freetextdata != null)
                {
                    ArrayList lstDuplicates = new ArrayList();
                    ArrayList lstFreeText = new ArrayList();

                    foreach (DataRow drow in freetextdata.Rows)
                    {
                        if (!lstFreeText.Contains(drow[0].ToString().Trim()))
                        {
                            lstFreeText.Add(drow[0].ToString().Trim());
                        }
                        else
                        {
                            if (!lstDuplicates.Contains(drow[0].ToString().Trim()))
                            {
                                lstDuplicates.Add(drow[0].ToString().Trim());
                            }
                        }
                    }

                    if (lstDuplicates.Count > 0)
                    {
                        blStatus = true;
                        string strTemp = string.Join("\r\n", (string[])lstDuplicates.ToArray(typeof(string)));
                        strErrMsg = "FreeText contains duplicates:\r\n" + strTemp.Trim();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg;
            return blStatus;
        }

        private bool CheckForFreeText_StageValidation(out string errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                //Alternative Solution - Testing
                DataTable dtFT_Stages = GetFreeText_StagesData();
                FT_StagesData = dtFT_Stages;

                if (dtFT_Stages != null)
                {                 
                    ArrayList alstOtherStgs = new ArrayList();

                    //Get Stage names from Stage Tabs
                    ArrayList alstStageNames = GetStageIndexesFromTabControl();

                    //Get Current Stage Index
                    string strStageIndx = GetStageIndexFromStageName(StageName);

                    if (dtFT_Stages.Rows.Count > 0)
                    {
                        //Check for duplicate FreeText terms
                        string strErr_Out = "";
                        if (CheckForDuplicateFreeTextInDataTable(dtFT_Stages, out strErr_Out))
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + strErr_Out;
                        }
                        else
                        {
                            string pattern_S = @"\(stage ";
                            string pattern_Stgs = @"\(stages ";
                            string replacement = "";
                            Regex rgx = null;
                            string strFTTemp = "";

                            bool blOther_Order = false;
                            string strErrMsg_Out = "";

                            for (int rIndx = 0; rIndx < dtFT_Stages.Rows.Count; rIndx++)
                            {
                                if (dtFT_Stages.Rows[rIndx][1].ToString().Trim() == "(" + StageName.ToUpper() + ")")
                                {
                                    //Do nothing
                                }
                                else if (dtFT_Stages.Rows[rIndx][0].ToString().Trim().Contains(","))
                                {
                                    //Ex: Ultrasound, inverse addition(stage 2)
                                    //New req on 6th June 2012
                                    int intLen = dtFT_Stages.Rows[rIndx][0].ToString().Trim().IndexOf(",");
                                    string strTerm = dtFT_Stages.Rows[rIndx][0].ToString().Trim().Substring(0, intLen);

                                    blStatus = false;
                                    strErrMsg = strErrMsg.Trim() + "\r\n" + "' " + strTerm + " ' should contain stage information";
                                }
                                else if (!dtFT_Stages.Rows[rIndx][1].ToString().Trim().EndsWith(")"))
                                {
                                    blStatus = false;
                                    strErrMsg = strErrMsg.Trim() + "\r\n" + dtFT_Stages.Rows[rIndx][0].ToString().Trim() + " should end with ')'";
                                }
                                else if (dtFT_Stages.Rows[rIndx][1].ToString().Trim().ToUpper().StartsWith("(STAGE "))
                                {                                    
                                    rgx = new Regex(pattern_S, RegexOptions.IgnoreCase);
                                    strFTTemp = rgx.Replace(dtFT_Stages.Rows[rIndx][1].ToString().Trim(), replacement);
                                    strFTTemp = strFTTemp.Replace(")", "");

                                    if (strStageIndx != strFTTemp.Trim())
                                    {
                                        blStatus = false;
                                        strErrMsg = strErrMsg.Trim() + "\r\n" + dtFT_Stages.Rows[rIndx][0].ToString().Trim() + " - Mismatched stage information";
                                    }
                                }
                                else if (dtFT_Stages.Rows[rIndx][1].ToString().Trim().ToUpper().StartsWith("(STAGES "))
                                {
                                    replacement = "";
                                    rgx = new Regex(pattern_Stgs, RegexOptions.IgnoreCase);
                                    strFTTemp = rgx.Replace(dtFT_Stages.Rows[rIndx][1].ToString().Trim(), replacement);
                                    strFTTemp = strFTTemp.Replace(")", "");

                                    blOther_Order = false;
                                    strErrMsg_Out = "";

                                    //Split with ',' and Check for All NUMs and Stages Order
                                    bool blNumsStatus = SplitAndCheckForNumbersInStagesValidateStages(strFTTemp, ",", strStageIndx, alstStageNames, out blOther_Order, out strErrMsg_Out);
                                    if (blNumsStatus == true && blOther_Order == true)
                                    {
                                        blStatus = false;
                                        strErrMsg = strErrMsg.Trim() + "\r\n" + dtFT_Stages.Rows[rIndx][0].ToString().Trim() + " - " + strErrMsg_Out.Trim();
                                    }
                                    else
                                    {
                                        //Split with '-' and Check for All NUMs and Stages Order
                                        blNumsStatus = SplitAndCheckForNumbersInStagesValidateStagesWithHiphen(strFTTemp, strStageIndx, alstStageNames, out blOther_Order, out strErrMsg_Out);
                                        if (blNumsStatus == true && blOther_Order == true)
                                        {
                                            blStatus = false;
                                            strErrMsg = strErrMsg.Trim() + "\r\n" + dtFT_Stages.Rows[rIndx][0].ToString().Trim() + " - " + strErrMsg_Out.Trim();
                                        }
                                        else
                                        {
                                            //Split with 'and' and Check for All NUMs and Stages Order
                                            blNumsStatus = SplitAndCheckForNumbersInStagesValidateStages(strFTTemp, "and", strStageIndx, alstStageNames, out blOther_Order, out strErrMsg_Out);
                                            if (blNumsStatus == true && blOther_Order == true)
                                            {
                                                blStatus = false;
                                                strErrMsg = strErrMsg.Trim() + "\r\n" + dtFT_Stages.Rows[rIndx][0].ToString().Trim() + " - " + strErrMsg_Out.Trim();
                                            }
                                            else//Mix terms
                                            {
                                                if (!CheckMixedTermsInStagesValidateStages(strFTTemp, strStageIndx, alstStageNames, out strErrMsg_Out))
                                                {
                                                    blStatus = false;
                                                    strErrMsg = strErrMsg.Trim() + "\r\n" + dtFT_Stages.Rows[rIndx][0].ToString().Trim() + " - " + strErrMsg_Out.Trim();
                                                }
                                            }
                                        }
                                    }
                                }
                                else //No Stage information
                                {
                                    blStatus = false;
                                    strErrMsg = strErrMsg.Trim() + "\r\n" + dtFT_Stages.Rows[rIndx][0].ToString().Trim() + " - Should contain stage information";
                                }
                            }
                        }
                    }
                    else
                    {
                        blStatus = false;
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "In-valid FreeText Data";
                    }
                }              
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg;
            return blStatus;

        }

        private bool CheckForRSNToNrnRegValidations(out string _errmsg_out)
        {
            bool blStatus = true;
            string srrErrMsg = "";
            try
            {
                DataTable dtFT_Stages = GetFreeText_StagesData();
                FT_StagesData = dtFT_Stages;

                if (FT_StagesData != null)
                {
                    ucParticipants ucPartpnt = null;
                    DataTable dt_R = null;
                    DataTable dt_A = null;
                    DataTable dt_S = null;
                    DataTable dt_C = null;                    
                    string strStage = "";                    

                    //Get Current User Control from Tab Pages
                    if (TabCntrl_Stages != null)
                    {
                        if (TabCntrl_Stages.TabPages.Count > 0)
                        {
                            foreach (TabPage tp in TabCntrl_Stages.TabPages)
                            {
                                ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                                if (StageName.ToUpper() == ucPartpnt.StageName.ToUpper())
                                {
                                    break;
                                }
                            }
                        }
                    }

                    if (ucPartpnt != null)
                    {
                        strStage = ucPartpnt.StageName;
                        
                        dt_R = ucPartpnt.dtReactant;
                        dt_A = ucPartpnt.dtAgent;
                        dt_S = ucPartpnt.dtSolvent;
                        dt_C = ucPartpnt.dtCatalyst;
                    }

                    string strFreeText = "";
                    string strErrStages = "";
                    string strThermMsg = "";

                    for (int i = 0; i < FT_StagesData.Rows.Count; i++)
                    {
                        strFreeText = "";
                        strFreeText = FT_StagesData.Rows[i][0].ToString().Trim().ToUpper();

                        //8007587 - FUMING NITRIC ACID USED
                        if (strFreeText ==  "FUMING NITRIC ACID USED")
                        {
                            if (!CheckNrnRegInStageParticipants(FT_StagesData.Rows[i][1].ToString(), 8007587, out strErrStages))
                            {
                                blStatus = false;
                                srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' fuming nitric acid used ', 8007587 should be used in the " + strErrStages;
                            }

                            #region MyRegion
                            //blStatus_R = CheckForNrnRegInTable(dt_R, 8007587);
                            //blStatus_A = CheckForNrnRegInTable(dt_A, 8007587);
                            //blStatus_S = CheckForNrnRegInTable(dt_S, 8007587);
                            //blStatus_C = CheckForNrnRegInTable(dt_C, 8007587);

                            //if (!blStatus_R && !blStatus_A && !blStatus_S && !blStatus_C)
                            //{
                            //    blStatus = false;
                            //    srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' fuming nitric acid used ', 8007587 should be used in the " + strStage;
                            //} 
                            #endregion
                        }

                        //8014957 - FUMING SULFURIC ACID USED
                        if (strFreeText ==  "FUMING SULFURIC ACID USED")
                        {
                            if (!CheckNrnRegInStageParticipants(FT_StagesData.Rows[i][1].ToString(), 8014957, out strErrStages))
                            {
                                blStatus = false;
                                srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' fuming sulfuric acid used ', 8014957 should be used in the " + strErrStages;
                            }

                            #region MyRegion
                            //blStatus_R = CheckForNrnRegInTable(dt_R, 8014957);
                            //blStatus_A = CheckForNrnRegInTable(dt_A, 8014957);
                            //blStatus_S = CheckForNrnRegInTable(dt_S, 8014957);
                            //blStatus_C = CheckForNrnRegInTable(dt_C, 8014957);

                            //if (!blStatus_R && !blStatus_A && !blStatus_S && !blStatus_C)
                            //{
                            //    blStatus = false;
                            //    srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' fuming sulfuric acid used ', 8014957 should be used in the " + strStage;
                            //} 
                            #endregion
                        }

                        //50000 - PARAFORMALDEHYDE USED
                        if (strFreeText ==  "PARAFORMALDEHYDE USED")
                        {
                            if (!CheckNrnRegInStageParticipants(FT_StagesData.Rows[i][1].ToString(), 50000, out strErrStages))
                            {
                                blStatus = false;
                                srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' paraformaldehyde used ', 50000 (paraformaldehyde) should be used in the " + strErrStages;
                            }

                            #region MyRegion
                            //blStatus_R = CheckForNrnRegInTable(dt_R, 50000);
                            //blStatus_A = CheckForNrnRegInTable(dt_A, 50000);
                            //blStatus_S = CheckForNrnRegInTable(dt_S, 50000);
                            //blStatus_C = CheckForNrnRegInTable(dt_C, 50000);

                            //if (!blStatus_R && !blStatus_A && !blStatus_S && !blStatus_C)
                            //{
                            //    blStatus = false;
                            //    srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' paraformaldehyde used ', 50000 (paraformaldehyde) should be used in the " + strStage;
                            //} 
                            #endregion
                        }

                        //7440020 - RANEY NICKEL USED
                        if (strFreeText ==  "RANEY NICKEL USED")
                        {
                            if (!CheckNrnRegInStageParticipants(FT_StagesData.Rows[i][1].ToString(), 7440020, out strErrStages))
                            {
                                blStatus = false;
                                srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' Raney nickel used ', 7440020 should be used in the " + strErrStages;
                            }

                            #region MyRegion
                            //blStatus_R = CheckForNrnRegInTable(dt_R, 7440020);
                            //blStatus_A = CheckForNrnRegInTable(dt_A, 7440020);
                            //blStatus_S = CheckForNrnRegInTable(dt_S, 7440020);
                            //blStatus_C = CheckForNrnRegInTable(dt_C, 7440020);

                            //if (!blStatus_R && !blStatus_A && !blStatus_S && !blStatus_C)
                            //{
                            //    blStatus = false;
                            //    srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' Raney nickel used ', 7440020 should be used in the " + strStage;
                            //} 
                            #endregion
                        }

                        //7440053 - LINDLAR'S CATALYST USED 
                        if (strFreeText ==  "LINDLAR'S CATALYST USED")
                        {
                            if (!CheckNrnRegInStageParticipants(FT_StagesData.Rows[i][1].ToString(), 7440053, out strErrStages))
                            {
                                blStatus = false;
                                srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' Lindlar's catalyst used ', pd(7440053) should be used in Catalyst in the " + strErrStages;
                            }

                            #region MyRegion
                            //blStatus_C = CheckForNrnRegInTable(dt_C, 7440053);//Check in Catalyst table
                            //if (!blStatus_C)
                            //{
                            //    blStatus = false;
                            //    srrErrMsg = srrErrMsg.Trim() + "\r\n" + "For RSN FreeText is ' Lindlar's catalyst used ', pd(7440053) should be used in Catalyst in the " + strStage;
                            //} 
                            #endregion
                        }

                        //7440064 - KARSTEDT'S CATALYST USED
                        if (strFreeText ==  "KARSTEDT'S CATALYST USED")
                        {
                            if (!CheckNrnRegInStageParticipants(FT_StagesData.Rows[i][1].ToString(), 7440064, out strErrStages))
                            {
                                blStatus = false;
                                srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' Karstedt's catalyst used ', Pt(7440064) should be used in Catalyst in the " + strErrStages;
                            }

                            #region MyRegion
                            //blStatus_C = CheckForNrnRegInTable(dt_C, 7440064);//Check in Catalyst table
                            //if (!blStatus_C)
                            //{
                            //    blStatus = false;
                            //    srrErrMsg = srrErrMsg.Trim() + "\r\n" + "For RSN FreeText is ' Karstedt's catalyst used ', Pt(7440064) should be used in Catalyst in the " + strStage;
                            //} 
                            #endregion
                        }

                        //7732185(Water) - If Buffer is used in RSN, Solvent - Water should be there
                        if (strFreeText.Contains("BUFFER"))
                        {
                            if (!CheckNrnRegInStageParticipants(FT_StagesData.Rows[i][1].ToString(), 7732185, out strErrStages))
                            {
                                blStatus = false;
                                srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' Buffer ', Water(7732185) should be used in Solvent in the " + strErrStages;
                            }
                        }

                        //Thermal - If Thermal is used in RSN, Check for RegNo in Solvent BoilingPoint table
                        if (strFreeText == "THERMAL")
                        {
                            if (!CheckValidSolventsForThermal(FT_StagesData.Rows[i][1].ToString(), out strThermMsg))
                            {
                                blStatus = false;
                                srrErrMsg = srrErrMsg.Trim() + "\r\n" + strThermMsg;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg_out = srrErrMsg;
            return blStatus;
        }

        private bool CheckNrnRegInStageParticipants(string stageinfo, int nrnreg, out string errstages_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (!string.IsNullOrEmpty(stageinfo))
                {                    
                    string[] saStages = GetStageIndexesFromStageInfo(stageinfo);
                    if (saStages != null)
                    {
                        ucParticipants ucPartpnt = null;
                        DataTable dt_R = null;
                        DataTable dt_A = null;
                        DataTable dt_S = null;
                        DataTable dt_C = null;
                        string strStageName = "";

                        bool blStatus_R = false;
                        bool blStatus_A = false;
                        bool blStatus_S = false;
                        bool blStatus_C = false;

                        string strStageIndx = "";
                        ArrayList astStages = new ArrayList();
                        
                        //Get Stage names from Stage Tabs
                        ArrayList alstStageNames = GetStageIndexesFromTabControl();

                        for (int i = 0; i < saStages.Length; i++)
                        {
                            if (!string.IsNullOrEmpty(saStages[i].Trim()))
                            {
                                foreach (TabPage tp in TabCntrl_Stages.TabPages)
                                {
                                    ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                                    if (ucPartpnt != null)
                                    {
                                        strStageName = ucPartpnt.StageName;
                                        strStageIndx = GetStageIndexFromStageName(strStageName);

                                        if (alstStageNames.Contains(strStageIndx.ToString()))//Check if Stage is available
                                        {
                                            if (strStageIndx == saStages[i].Trim())
                                            {
                                                dt_R = ucPartpnt.dtReactant.Copy();
                                                dt_A = ucPartpnt.dtAgent.Copy();
                                                dt_S = ucPartpnt.dtSolvent.Copy();
                                                dt_C = ucPartpnt.dtCatalyst.Copy();

                                                if (nrnreg == 7440053 || nrnreg == 7440064)//7440053 - Lindlar Catalyst, 7440064 - KARSTEDT'S CATALYST
                                                {
                                                    blStatus_C = CheckForNrnRegInTable(dt_C, nrnreg);
                                                    if (!blStatus_C)
                                                    {
                                                        blStatus = false;
                                                        if (!astStages.Contains(saStages[i].Trim()))
                                                        {
                                                            astStages.Add(saStages[i].Trim());
                                                        }
                                                    }
                                                }
                                                else if (nrnreg == 7732185)//7732185 - Water
                                                {
                                                    blStatus_S = CheckForNrnRegInTable(dt_S, nrnreg);
                                                    if (!blStatus_S)
                                                    {
                                                        blStatus = false;
                                                        if (!astStages.Contains(saStages[i].Trim()))
                                                        {
                                                            astStages.Add(saStages[i].Trim());
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    blStatus_R = CheckForNrnRegInTable(dt_R, nrnreg);
                                                    blStatus_A = CheckForNrnRegInTable(dt_A, nrnreg);
                                                    blStatus_S = CheckForNrnRegInTable(dt_S, nrnreg);
                                                    blStatus_C = CheckForNrnRegInTable(dt_C, nrnreg);

                                                    if (!blStatus_R && !blStatus_A && !blStatus_S && !blStatus_C)
                                                    {
                                                        blStatus = false;
                                                        if (!astStages.Contains(saStages[i].Trim()))
                                                        {
                                                            astStages.Add(saStages[i].Trim());
                                                        }
                                                    }
                                                }                                               
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (astStages.Count > 0)
                        {                           
                            string strTemp = string.Join("\r\n", (string[])astStages.ToArray(typeof(string)));
                            strErrMsg = "Stage(s) " + strTemp.Trim();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errstages_out = strErrMsg;
            return blStatus;
        }

        private string[] GetStageIndexesFromStageInfo(string stageinfo)
        {
            string[] saStgIndexes = null;
            try
            {
                string[] splter = { "~" };
                string strStgInfo = stageinfo.ToUpper().Trim().Replace("(STAGE ", "~");
                strStgInfo = strStgInfo.ToUpper().Trim().Replace("(STAGES ", "~");
                strStgInfo = strStgInfo.ToUpper().Trim().Replace("-", "~");
                strStgInfo = strStgInfo.ToUpper().Trim().Replace(",", "~");
                strStgInfo = strStgInfo.ToUpper().Trim().Replace(")", "~");
                strStgInfo = strStgInfo.ToUpper().Trim().Replace("AND", "~");

                saStgIndexes = strStgInfo.Trim().Split(splter, StringSplitOptions.RemoveEmptyEntries);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return saStgIndexes;
        }

        private bool CheckForRSNCVT_FreeTextInTable(DataTable _rsntbl, string _rsnterm)
        {
            bool blStatus = false;
            try
            {
                if (_rsntbl != null)
                {
                    if (_rsntbl.Rows.Count > 0)
                    {
                        //Reaction Level
                        DataRow[] drArr_Cvt = _rsntbl.Select("rsn_cvt = '" + _rsnterm.Replace("'", "''") + "'");
                        if (drArr_Cvt != null)
                        {
                            if (drArr_Cvt.Length > 0)
                            {
                                blStatus = true;
                                return blStatus;
                            }
                        }
                        //Stage Level - new feature as on 16th March 2011
                        DataRow[] drArr_Free = _rsntbl.Select("rsn_free_text like '%" + _rsnterm.Replace("'", "''") + "%'");
                        if (drArr_Free != null)
                        {
                            if (drArr_Free.Length > 0)
                            {
                                blStatus = true;
                                return blStatus;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckForNrnRegInTable(DataTable dtpartpnt, int regno)
        {
            bool blStatus = false;
            try
            {
                if (dtpartpnt != null && regno > 0)
                {
                    DataView dvTemp = dtpartpnt.Copy().DefaultView;
                    dvTemp.RowFilter = "REG_NO = " + regno + "";
                    DataTable dtTemp = dvTemp.ToTable();
                    if (dtTemp != null)
                    {
                        if (dtTemp.Rows.Count > 0)
                        {
                            if (regno == 50000)//For 50000 check the name along with Reg.No
                            {
                                if (dtTemp.Rows[0]["PP_NAME"].ToString().ToUpper() == "PARAFORMALDEHYDE")
                                {
                                    blStatus = true;
                                }
                                else
                                {
                                    blStatus = false;
                                }
                            }
                            else
                            {
                                blStatus = true;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckValidSolventsForThermal(string stageinfo, out string errstages_out)
        {
            bool blStatus = true;
            string strErrStages = "";
            try
            {
                if (!string.IsNullOrEmpty(stageinfo))
                {
                    string[] saStages = GetStageIndexesFromStageInfo(stageinfo);
                    if (saStages != null)
                    {
                        ucParticipants ucPartpnt = null;               
                        DataTable dtStgSolvents = null;
                        int intNrnReg = 0;
                        string strStageIndx = "";                       
                        bool blSolvUsed = false;
                        
                        for (int i = 0; i < saStages.Length; i++)
                        {
                            if (!string.IsNullOrEmpty(saStages[i].Trim()))
                            {
                                ucPartpnt = GetUserControlOnStageIndex(saStages[i].Trim());
                                if (ucPartpnt != null)
                                {
                                    strStageIndx = GetStageIndexFromStageName(ucPartpnt.StageName);
                                    
                                    dtStgSolvents = ucPartpnt.dtSolvent;

                                    if (dtStgSolvents != null)
                                    {
                                        blSolvUsed = false;

                                        for (int j = 0; j < dtStgSolvents.Rows.Count; j++)
                                        {
                                            int.TryParse(dtStgSolvents.Rows[j]["REG_NO"].ToString(), out intNrnReg);
                                            if (intNrnReg > 0)
                                            {
                                                if (CheckRegNoInSolventBoilingPoitnsTable(intNrnReg))
                                                {
                                                    blSolvUsed = true;
                                                }
                                            }
                                        }
                                        if (!blSolvUsed)
                                        {
                                            blStatus = false;
                                            strErrStages = strErrStages.Trim() + "\r\n" + "No valid Solvent is there. RSN ' thermal ' is not allowed in the Stage(s) " + saStages[i].Trim();                                           
                                        }
                                    }
                                }
                            }
                        }                        
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errstages_out = strErrStages;
            return blStatus;
        }

        private ucParticipants GetUserControlOnStageIndex(string stageindex)
        {
            ucParticipants ucPartpnt = null;
            try
            {
                if (!string.IsNullOrEmpty(stageindex) && TabCntrl_Stages != null)
                {
                    string strStgIndex = "";
                    ucParticipants objUcpartpnt = null;
                    foreach (TabPage tp in TabCntrl_Stages.TabPages)
                    {
                        objUcpartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                        if (objUcpartpnt != null)
                        {
                            strStgIndex = GetStageIndexFromStageName(objUcpartpnt.StageName);

                            if (strStgIndex == stageindex)
                            {
                                ucPartpnt = objUcpartpnt;
                                return ucPartpnt;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return ucPartpnt;
        }

        private bool CheckRegNoInSolventBoilingPoitnsTable(int regno)
        {
            bool blStatus = false;
            try
            {
                if (GlobalVariables.Solvent_BPoints != null && regno > 0)
                {
                    DataView dvTemp = GlobalVariables.Solvent_BPoints.Copy().DefaultView;
                    dvTemp.RowFilter = "REG_NO = " + regno;
                    DataTable dtTemp = dvTemp.ToTable();
                    if (dtTemp != null)
                    {
                        if (dtTemp.Rows.Count > 0)
                        {
                            blStatus = true;
                            return blStatus;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        #region Main Method Commented
        //private bool CheckForFreeText_StageValidation(out string errmsg_out)
        //{
        //    bool blStatus = true;
        //    string strErrMsg = "";
        //    try
        //    {
        //        //Alternative Solution - Testing
        //        DataTable dtFT_Stages = GetFreeText_StagesData();


        //        ArrayList alstOtherStgs = new ArrayList();

        //        //Get Stage names from Stage Tabs
        //        ArrayList alstStageNames = GetStageIndexesFromTabControl();  
        //        string[] splitter = { ")," };               

        //        string[] saValues = rtxtFreeText.Text.Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);
        //        if (saValues != null)
        //        {
        //            if (saValues.Length > 0)
        //            {
        //                string strStageIndx = "";
        //                string[] saTemp = StageName.Trim().Split(' ');
        //                if (saTemp != null)
        //                {
        //                    if (saTemp.Length > 0)
        //                    {
        //                        strStageIndx = saTemp[1];
        //                    }
        //                }                                           

        //                for (int i = 0; i < saValues.Length; i++)
        //                {
        //                    #region Code Commented
        //                    //if (saValues[i].Trim().ToUpper().EndsWith(" (" + StageName.ToUpper()))// + ")"))
        //                    //{
        //                    //    //blStatus = true;
        //                    //    //break;
        //                    //    //intPassCntr = intPassCntr + 1;
        //                    //}
        //                    //else if (saValues[i].Trim().ToUpper().EndsWith(" (" + StageName.ToUpper() + ")"))
        //                    //{
        //                    //    //blStatus = true;
        //                    //    //break;
        //                    //    //intPassCntr = intPassCntr + 1;
        //                    //} 
        //                    #endregion

        //                    string[] saStages = null;

        //                    if (saValues[i].Trim().ToUpper().EndsWith(" (" + StageName.ToUpper() + ")"))
        //                    {
        //                        //Do nothing
        //                    }
        //                    else if (!saValues[i].Trim().EndsWith(")"))
        //                    {
        //                        blStatus = false;
        //                        strErrMsg = strErrMsg.Trim() + "\r\n" + " FreeText contains should end with ')'";
        //                    }
        //                    else if (saValues[i].Trim().ToUpper().Contains("(STAGE "))
        //                    {
        //                        saStages = Regex.Split(saValues[i].Trim(), @"\(STAGE", RegexOptions.IgnoreCase);
        //                        if (saStages != null)
        //                        {
        //                            if (saStages.Length == 2)
        //                            {
        //                                string[] saStages_C = Regex.Split(saStages[1].Trim(), @"\)");
        //                                if (saStages_C != null)
        //                                {
        //                                    if (saStages_C.Length > 0)
        //                                    {
        //                                        if (strStageIndx != saStages_C[0].Trim())
        //                                        {
        //                                            blStatus = false;
        //                                            strErrMsg = strErrMsg.Trim() + "\r\n" + StageName + " FreeText contains mismatched stage ' " + saStages_C[0].Trim() + " '";
        //                                        }
        //                                    }
        //                                }
        //                            }
        //                        }
        //                    }
        //                    else if (saValues[i].Trim().ToUpper().Contains("(STAGES "))
        //                    {
        //                        saStages = Regex.Split(saValues[i].Trim(), @"\(STAGES", RegexOptions.IgnoreCase);

        //                        if (saStages != null)
        //                        {
        //                            if (saStages.Length > 1)
        //                            {
        //                                string strStgInfo = saStages[1].Trim();

        //                                if (!string.IsNullOrEmpty(strStgInfo))
        //                                {
        //                                    if ((strStgInfo.Contains("-") && strStgInfo.Contains("and")) || (strStgInfo.Contains(",") && strStgInfo.Contains("-")))
        //                                    {
        //                                        blStatus = false;
        //                                        strErrMsg = strErrMsg.Trim() + "FreeText ' " + saStages[0].Trim() + " ' contains In-valid stage info " + strStgInfo;
        //                                    }
        //                                    else
        //                                    {
        //                                        //Split with ')' (Ex: Stages 1 and 5))
        //                                        string[] saStages_B = Regex.Split(strStgInfo.Trim().ToUpper(), @"\)");
        //                                        if (saStages_B != null)
        //                                        {
        //                                            for (int b = 0; b < saStages_B.Length; b++)
        //                                            {
        //                                                if (!string.IsNullOrEmpty(saStages_B[b].Trim()))
        //                                                {
        //                                                    //Split with '-' (Ex: Stages 1-3)
        //                                                    string[] saStages_H = Regex.Split(saStages_B[b].Trim(), @"-");
        //                                                    if (saStages_H != null)
        //                                                    {
        //                                                        if (saStages_H.Length == 2)
        //                                                        {
        //                                                            int intFromStage = 0;
        //                                                            int intToStage = 0;
        //                                                            int.TryParse(saStages_H[0].Trim(), out intFromStage);
        //                                                            int.TryParse(saStages_H[1].Trim(), out intToStage);

        //                                                            if (intFromStage > intToStage)//Ex: 3-1
        //                                                            {
        //                                                                blStatus = false;
        //                                                                strErrMsg = strErrMsg.Trim() + "\r\n" + "In-valid stage order " + saStages_B[b].Trim();
        //                                                            }
        //                                                            else if (!saStages_B[b].Trim().StartsWith(strStageIndx))//Ex: Stage 2 contains 1-3
        //                                                            {
        //                                                                blStatus = false;
        //                                                                strErrMsg = strErrMsg.Trim() + "\r\n" + "In-valid stage order " + saStages_B[b].Trim();
        //                                                            }
        //                                                        }
        //                                                        else//Ex; 3 and 5
        //                                                        {
        //                                                            for (int j = 0; j < saStages_H.Length; j++)
        //                                                            {
        //                                                                if (!string.IsNullOrEmpty(saStages_H[j].Trim()))
        //                                                                {
        //                                                                    //Split with ',' (Ex: Stages 1,3,5)
        //                                                                    string[] saStages_C = Regex.Split(saStages_H[j].Trim().ToUpper(), @",");
        //                                                                    if (saStages_C != null)
        //                                                                    {
        //                                                                        for (int k = 0; k < saStages_C.Length; k++)
        //                                                                        {
        //                                                                            if (!string.IsNullOrEmpty(saStages_C[k].Trim()))
        //                                                                            {
        //                                                                                //Split with 'and' (Ex: Stage 1,2 and 5)
        //                                                                                string[] saStages_AND = Regex.Split(saStages_C[k].Trim().ToUpper(), @" AND ");
        //                                                                                if (saStages_AND != null)
        //                                                                                {
        //                                                                                    for (int m = 0; m < saStages_AND.Length; m++)
        //                                                                                    {
        //                                                                                        if (!string.IsNullOrEmpty(saStages_AND[m].Trim()))
        //                                                                                        {
        //                                                                                            if (!alstStageNames.Contains(saStages_AND[m].Trim()))
        //                                                                                            {
        //                                                                                                blStatus = false;
        //                                                                                                if (!alstOtherStgs.Contains(saStages_AND[m].Trim()))
        //                                                                                                {
        //                                                                                                    alstOtherStgs.Add(saStages_AND[m].Trim());
        //                                                                                                }
        //                                                                                            }
        //                                                                                        }
        //                                                                                    }
        //                                                                                }
        //                                                                            }
        //                                                                        }
        //                                                                    }
        //                                                                }
        //                                                            }
        //                                                        }
        //                                                    }
        //                                                }
        //                                            }
        //                                        }
        //                                    }
        //                                }
        //                            }
        //                        }
        //                    }
        //                    else //No Stage information
        //                    {
        //                        blStatus = false;
        //                        strErrMsg = strErrMsg.Trim() + "\r\n" + "FreeText ' " + saValues[i].Trim() + " ' should contain stage information";
        //                    }
        //                }                       
        //            }
        //        }
        //        if (blStatus == false)
        //        {
        //            string strTemp = "";
        //            if (alstOtherStgs.Count > 0)
        //            {
        //                alstOtherStgs.Sort();

        //                strTemp = string.Join(",", (string[])alstOtherStgs.ToArray(typeof(string)));
        //            }

        //            if (!string.IsNullOrEmpty(strTemp.Trim()))
        //            {
        //                strErrMsg = strErrMsg.Trim() + "\r\n" + "Stage(s) " + strTemp.Trim() + " not exist";
        //            }
        //            //strErrMsg = strErrMsg.Trim() + "\r\n" + "Stage level FreeText should contain correct stage information";
        //        }   
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    errmsg_out = strErrMsg;
        //    return blStatus;

        //} 
        #endregion

        private ArrayList GetStageIndexesFromTabControl()
        {
            ArrayList alstStgIDs = null;
            try
            {
                if (TabCntrl_Stages != null)
                {
                    alstStgIDs = new ArrayList();
                    string[] saTemp = null;

                    for (int i = 0; i < TabCntrl_Stages.TabPages.Count; i++)
                    {
                        saTemp = null;
                        saTemp = TabCntrl_Stages.TabPages[i].Text.Trim().Split(' ');
                        if (saTemp != null)
                        {
                            if (saTemp.Length > 1)
                            {                                
                                if (!alstStgIDs.Contains(saTemp[1].Trim()))
                                {
                                    alstStgIDs.Add(saTemp[1].Trim());
                                }
                            }
                        }                        
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return alstStgIDs;
        }

        private bool CheckForDuplicateRSN_FreeTextTerms(out string _errmsg)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                DataTable dtRSNTbl = null;
                ArrayList alstRSN = new ArrayList();
                string strStageName = "";
                string[] splitter = { "," };
                string[] spl_stage = { "(stage" };

                dtRSNTbl = RSNData;

                if (dtRSNTbl != null)
                {
                    if (dtRSNTbl.Rows.Count > 0)
                    {
                        for (int i = 0; i < dtRSNTbl.Rows.Count; i++)
                        {
                            if (dtRSNTbl.Rows[i]["rsn_free_text"].ToString() != "")
                            {
                                string[] strArr_Temp = dtRSNTbl.Rows[i]["rsn_free_text"].ToString().Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);

                                if (strArr_Temp != null)
                                {
                                    if (strArr_Temp.Length > 0)
                                    {
                                        for (int j = 0; j < strArr_Temp.Length; j++)
                                        {
                                            string[] strArr_Free = strArr_Temp[j].Split(spl_stage, StringSplitOptions.RemoveEmptyEntries);
                                            if (strArr_Free != null)
                                            {
                                                if (strArr_Free.Length > 0)
                                                {
                                                    if (strArr_Free[0].Trim().ToUpper() != "HIGH PRESSURE" &&
                                                        strArr_Free[0].Trim().ToUpper() != "LOW PRESSURE" &&
                                                        strArr_Free[0].Trim().ToUpper() != "THERMAL")//New condition on 28th Sep 2011 by Pradeep
                                                    {
                                                        if (!alstRSN.Contains(strArr_Free[0].Trim()))
                                                        {
                                                            alstRSN.Add(strArr_Free[0].Trim());
                                                        }
                                                        else
                                                        {
                                                            blStatus = true;

                                                            if (strErrMsg.Trim() == "")
                                                            {
                                                                strErrMsg = "Duplicate RSN FreeText '" + strArr_Free[0].Trim() + "' ";
                                                            }
                                                            else
                                                            {
                                                                strErrMsg = strErrMsg + "\r\n" + "Duplicate RSN FreeText '" + strArr_Free[0].Trim() + "' ";
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg;
            return blStatus;
        }

        private bool CheckFreeTextContainsCVTTerm(string freetext, string reaction_stage, out string cvtterm)
        {
            bool blStatus = false;
            cvtterm = "";
            try
            {
                if (CVTData != null && !string.IsNullOrEmpty(freetext))
                {
                    string[] splitter = { "," };
                    string[] saFTVals = freetext.Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);

                    if (saFTVals != null && saFTVals.Length > 0)
                    {
                        string[] splitter_Stg = { "(stage" };
                        string[] saFreeText = null;

                        for (int i = 0; i < saFTVals.Length; i++)
                        {
                            saFreeText = null;
                            saFreeText = saFTVals[i].Trim().Split(splitter_Stg, StringSplitOptions.RemoveEmptyEntries);
                            if (saFreeText != null && saFreeText.Length > 0)
                            {
                                //Code commented on 29th Sep 2015, FreeText should not contains CVT term
                                //if ((GetCVTTermCountInCVTTable(saFreeText[0].Trim()) > 0) && reaction_stage.ToUpper() == "REACTION")//FreeText Contains CVT term
                                //{
                                //    blStatus = true;
                                //    cvtterm = saFreeText[0].Trim();
                                //    return blStatus;
                                //}

                                if ((GetCVTTermCountInCVTTable(saFreeText[0].Trim()) > 0))//FreeText Contains CVT term
                                {
                                    blStatus = true;
                                    cvtterm = saFreeText[0].Trim();
                                    return blStatus;
                                }
                            }
                        }
                    }           
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private int GetCVTTermCountInCVTTable(string free_text)
        {
            int intRecCnt = 0;
            try
            {
                if (CVTData != null)
                {
                    var cnt = (from dr in CVTData.AsEnumerable()
                               where dr.Field<string>("CVT") != null && !Convert.IsDBNull(dr.Field<string>("CVT")) && dr.Field<string>("CVT").ToUpper() == free_text.ToUpper()
                               select dr).Count();

                    intRecCnt = cnt;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return intRecCnt;
        }

        /// <summary>
        /// New method on 2nd Apr 2013
        /// </summary>
        /// <param name="freetextval"></param>
        /// <param name="errmsg_out"></param>
        /// <returns></returns>
        private bool CheckForUniqueREactionLevelFreeTextTermInReaction(string freetextval, out string errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (!string.IsNullOrEmpty(freetextval))
                {
                    string strErr = "";
                    string[] splitter_C = { "," };
                    string[] saFreeText = freetextval.Trim().Split(splitter_C, StringSplitOptions.RemoveEmptyEntries);
                    if (saFreeText != null)
                    {
                        if (saFreeText.Length > 0)//multiple FreeText terms
                        {
                            string[] splitter_Stg = { "," };
                            string[] saFTVals = null;
                            for (int i = 0; i < saFreeText.Length; i++)
                            {
                                saFTVals = saFreeText[i].Trim().Split(splitter_Stg, StringSplitOptions.RemoveEmptyEntries);

                                if (saFTVals != null)
                                {
                                    if (saFTVals.Length > 0)
                                    {
                                        if (!CheckForReactionLevelFreeTextInAllStages(saFTVals[0].Trim(), out strErr))
                                        {
                                            strErrMsg = strErrMsg + "\r\n" + strErr;
                                            blStatus = false;
                                        }
                                    }                                    
                                }
                            }
                        }                        
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg;
            return blStatus;

        }

        /// <summary>
        /// New method on 2nd Apr 2013
        /// </summary>
        /// <param name="freetextval"></param>
        /// <param name="errmsg_out"></param>
        /// <returns></returns>
        private bool CheckForReactionLevelFreeTextInAllStages(string freetextval, out string errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";

            try
            {
                if (TabCntrl_Stages != null && !string.IsNullOrEmpty(freetextval))
                {
                    DataTable dtStgRSN = null;
                    ucParticipants ucPartpnt = null;
                    string strStageName = "";

                    foreach (TabPage tp in TabCntrl_Stages.TabPages)
                    {
                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            strStageName = ucPartpnt.StageName;
                            dtStgRSN = ucPartpnt.dtRSN;

                            if (StageName != strStageName)
                            {
                                if (dtStgRSN != null)
                                {                                  
                                    string[] splitter_C = { "," };

                                    for (int i = 0; i < dtStgRSN.Rows.Count; i++)
                                    {
                                        string[] saFreeText = dtStgRSN.Rows[i]["FREE_TEXT"].ToString().Trim().Split(splitter_C, StringSplitOptions.RemoveEmptyEntries);
                                        if (saFreeText != null)
                                        {
                                            if (saFreeText.Length > 0)//multiple FreeText terms
                                            {
                                                string[] splitter_Stg = { "(stage" };
                                                string[] saFTVals = null;

                                                for (int j = 0; j < saFreeText.Length; j++)
                                                {
                                                    saFTVals = saFreeText[j].Trim().Split(splitter_Stg, StringSplitOptions.RemoveEmptyEntries);
                                                    if (saFTVals != null)
                                                    {
                                                        if (saFTVals.Length > 0)
                                                        {
                                                            if (saFTVals[0].Trim().ToString().ToUpper() == freetextval.ToUpper())
                                                            {
                                                                strErrMsg = "' " + freetextval + " ' already used in the Reaction level FreeText";
                                                                blStatus = false;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else//Same Stage
                            {
                                if (dtStgRSN != null)
                                {                                   
                                    string[] splitter_C = { "," };

                                    for (int i = 0; i < dtStgRSN.Rows.Count; i++)
                                    {
                                        string[] saFreeText = dtStgRSN.Rows[i]["FREE_TEXT"].ToString().Trim().Split(splitter_C, StringSplitOptions.RemoveEmptyEntries);
                                        if (saFreeText != null)
                                        {
                                            if (saFreeText.Length > 0)//multiple FreeText terms
                                            {
                                                string[] splitter_Stg = { "," };
                                                string[] saFTVals = null;

                                                for (int j = 0; j < saFreeText.Length; j++)
                                                {
                                                    saFTVals = saFreeText[j].Trim().Split(splitter_Stg, StringSplitOptions.RemoveEmptyEntries);
                                                    if (saFTVals != null)
                                                    {
                                                        if (saFTVals.Length > 0)
                                                        {
                                                            if ((saFTVals[0].Trim().ToString().ToUpper() == freetextval.ToUpper()) && editRowIndx - 1 != i)
                                                            {
                                                                strErrMsg = "' " + freetextval + " ' already used in the Reaction level FreeText";
                                                                blStatus = false;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg;
            return blStatus;

        }

        private bool CheckForUniqueTermInReaction(string termname, string freetext_cvtval,out string errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (!string.IsNullOrEmpty(freetext_cvtval))
                {
                    string strErr = "";
                    string[] splitter_C = { "," };
                    string[] saFreeText = freetext_cvtval.Trim().Split(splitter_C, StringSplitOptions.RemoveEmptyEntries);
                    if (saFreeText != null)
                    {
                        if (saFreeText.Length > 0)//multiple FreeText terms
                        {
                            string[] splitter_Stg = { "(stage" };
                            string[] saFTVals = null;
                            for (int i = 0; i < saFreeText.Length; i++)
                            {                       
                                saFTVals = saFreeText[i].Trim().Split(splitter_Stg, StringSplitOptions.RemoveEmptyEntries);

                                if (saFTVals != null)
                                {
                                    if (saFTVals.Length > 0)
                                    {
                                        if (!CheckForFreeTextInAllStages(termname, saFTVals[0].Trim(), out strErr))
                                        {
                                            strErrMsg = strErrMsg + "\r\n" + strErr;
                                            blStatus = false;
                                        }
                                    }
                                    else
                                    {
                                        if (!CheckForFreeTextInAllStages(termname, saFreeText[i].Trim().ToUpper(), out strErr))
                                        {
                                            strErrMsg = strErrMsg + "\r\n" + strErr;
                                            blStatus = false;
                                        }
                                    }
                                }
                            }
                        }
                        else//single FreeText term
                        {
                            if (!CheckForFreeTextInAllStages(termname, freetext_cvtval.Trim().ToUpper(), out strErr))
                            {
                                strErrMsg = strErrMsg + "\r\n" + strErr;
                                blStatus = false;
                            }
                        }
                    }          
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg;
            return blStatus;
        }

        private bool CheckForFreeTextInAllStages(string termname, string freetext_cvtval, out string errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";

            try
            {
                if (TabCntrl_Stages != null && !string.IsNullOrEmpty(freetext_cvtval))
                {
                    DataTable dtStgRSN = null;                    
                    ucParticipants ucPartpnt = null;
                    string strStageName = "";

                    foreach (TabPage tp in TabCntrl_Stages.TabPages)
                    {
                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            strStageName = ucPartpnt.StageName;
                            dtStgRSN = ucPartpnt.dtRSN;

                            if (StageName != strStageName)
                            {
                                if (dtStgRSN != null)
                                {
                                    var recCnt = (from dr in dtStgRSN.AsEnumerable()
                                                  where dr.Field<string>("CVT") != null && !Convert.IsDBNull(dr.Field<string>("CVT")) && dr.Field<string>("CVT").ToUpper().Contains(freetext_cvtval.ToUpper())
                                                  select dr).Count();

                                    if (recCnt > 0)
                                    {
                                        strErrMsg = termname + " term ' " + freetext_cvtval + " ' already used in the " + strStageName + " CVT";
                                        blStatus = false;
                                        break;
                                    }
                                    else
                                    {                                        
                                        string[] splitter_C = { "," };
                                        
                                        for (int i = 0; i < dtStgRSN.Rows.Count; i++)
                                        {                                            
                                            string[] saFreeText = dtStgRSN.Rows[i]["FREE_TEXT"].ToString().Trim().Split(splitter_C, StringSplitOptions.RemoveEmptyEntries);
                                            if (saFreeText != null && saFreeText.Length > 0)//multiple FreeText terms
                                            {
                                                string[] splitter_Stg = { "(stage" };
                                                string[] saFTVals = null;

                                                for (int j = 0; j < saFreeText.Length; j++)
                                                {
                                                    saFTVals = saFreeText[j].Trim().Split(splitter_Stg, StringSplitOptions.RemoveEmptyEntries);
                                                    if (saFTVals != null)
                                                    {
                                                        if (saFTVals.Length > 0)
                                                        {
                                                            if (saFTVals[0].Trim().ToString().ToUpper() == freetext_cvtval.ToUpper())
                                                            {
                                                                strErrMsg = termname + " ' " + freetext_cvtval + " ' already used in the " + strStageName + " FreeText";
                                                                blStatus = false;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else//Same Stage
                            {
                                if (dtStgRSN != null)
                                {                                  
                                    var recCnt = (from dr in dtStgRSN.AsEnumerable() //RSNData
                                                where dr.Field<string>("CVT") != null && !Convert.IsDBNull(dr.Field<string>("CVT")) && dr.Field<string>("CVT").ToUpper().Contains(freetext_cvtval.ToUpper())
                                               select dr).Count();                                                                                                                                           

                                    if (recCnt > 0 && editRowIndx == -1)
                                    {
                                        strErrMsg = termname + " term ' " + freetext_cvtval + " ' already used in the " + strStageName + " CVT";
                                        blStatus = false;
                                        break;
                                    }
                                    else
                                    {                                      
                                        string[] splitter_C = { "," };

                                        for (int i = 0; i < dtStgRSN.Rows.Count; i++)
                                        {
                                            string[] saFreeText = dtStgRSN.Rows[i]["FREE_TEXT"].ToString().Trim().Split(splitter_C, StringSplitOptions.RemoveEmptyEntries);
                                            if (saFreeText != null)
                                            {
                                                if (saFreeText.Length > 0)//multiple FreeText terms
                                                {
                                                    string[] splitter_Stg = { "(stage" };
                                                    string[] saFTVals = null;

                                                    for (int j = 0; j < saFreeText.Length; j++)
                                                    {
                                                        saFTVals = saFreeText[j].Trim().Split(splitter_Stg, StringSplitOptions.RemoveEmptyEntries);
                                                        if (saFTVals != null)
                                                        {
                                                            if (saFTVals.Length > 0)
                                                            {
                                                                if ((saFTVals[0].Trim().ToString().ToUpper() == freetext_cvtval.ToUpper()) && editRowIndx == -1)
                                                                {
                                                                    strErrMsg = termname + " ' " + freetext_cvtval + " ' already used in the " + strStageName + " FreeText";
                                                                    blStatus = false;
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg;
            return blStatus;
        }

        private bool CheckForRSN_Free_Stage_Validation(out string _errmsg)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {               
                string strStageName = "";
                DataTable dtRSNTbl = null;                
                int intStageIndx = 0;

                intStageIndx = intStageIndx + 1;
                strStageName = StageName;

                strStageName = StageName;               

                dtRSNTbl = RSNData;
                if (dtRSNTbl != null)
                {
                    if (dtRSNTbl.Rows.Count > 0)
                    {
                        for (int i = 0; i < dtRSNTbl.Rows.Count; i++)
                        {
                            if (StageID.ToString() == dtRSNTbl.Rows[i]["RXN_STAGE_ID"].ToString())
                            {
                                if (dtRSNTbl.Rows[i]["CVT"].ToString().Trim() == "" && dtRSNTbl.Rows[i]["FREE_TEXT"].ToString().Trim() == "")
                                {
                                    blStatus = true;
                                    strErrMsg = strErrMsg.Trim() + "\r\n" + "Empty RSN in the " + strStageName + " of the Reaction";
                                }
                                else if (dtRSNTbl.Rows[i]["FREE_TEXT"].ToString().Trim() != "")
                                {
                                    if (dtRSNTbl.Rows[i]["FREE_TEXT"].ToString().Trim().ToUpper().Contains("(STAGE")
                                        && dtRSNTbl.Rows[i]["NOTE_LEVEL"].ToString().Trim().ToUpper() == "REACTION")
                                    {
                                        blStatus = true;
                                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Please check the RSN 'FreeText' at Reaction level in the " + strStageName;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg;
            return blStatus;
        }

        int insertRowIndx = -1;
        string strInsOpt = "AFTER";
        private void btnAddRSN_Click(object sender, EventArgs e)
        {
            try
            {
                string strErrMsg = "";
                if (ValidateCVTFreeTextUserInputs(out strErrMsg))
                {                   
                    strInsOpt = "AFTER";          
                    insertRowIndx = 1;                   

                    if (dgvRSN.CurrentRow != null)
                    {
                        if (dgvRSN.CurrentRow.Index <= 1)
                        {
                            insertRowIndx = dgvRSN.CurrentRow.Index + 2;
                        }
                        else
                        {
                            insertRowIndx = dgvRSN.CurrentRow.Index + 2;
                        }
                    }

                    string strRxn_Stage = "Reaction";
                    if (rbnStage.Checked)
                    {
                        strRxn_Stage = "Stage";
                        insertRowIndx = dgvRSN.Rows.Count + 1;
                    }

                    //FreeText should be there in the last row of the RSN table in the Stage 1
                    //In all other stages only one row is allowed

                    if (editRowIndx == -1)
                    {
                        if (rbnReaction.Checked)//Reaction Level RSN
                        {
                            string strFreeText_Out = "";                                                  
                            int intRIndx = GetRowIndexToAddReactionFreeText(out strFreeText_Out);

                            //if (intRIndx > 0 && rtxtFreeText.Text.Trim() != "" && txtCVT.Text.Trim() == "")
                            //{
                            //    RSNData.Rows[intRIndx - 1]["rsn_free_text"] = rtxtFreeText.Text.Trim();
                            //    RSNData.AcceptChanges();
                            //    txtCVT.Text = "";
                            //    rtxtFreeText.Text = "";
                            //}
                            if (rtxtFreeText.Text.Trim() != "" && txtCVT.Text.Trim() == "")
                            {
                                AddRecordToRSNTable(insertRowIndx, strInsOpt, txtCVT.Text.Trim(), rtxtFreeText.Text.Trim(), strRxn_Stage);
                            }   
                            else
                            {
                                //if (strFreeText_Out.Trim() == "")
                                //{
                                //    strFreeText_Out = rtxtFreeText.Text.Trim();
                                //}                                
                                //AddRecordToRSNTable(insertRowIndx, strInsOpt, txtCVT.Text.Trim(), strFreeText_Out.Trim(), strRxn_Stage);
                                AddRecordToRSNTable(insertRowIndx, strInsOpt, txtCVT.Text.Trim(), rtxtFreeText.Text.Trim(), strRxn_Stage);
                            }                            
                        }
                        else //Stage level RSN
                        {
                            AddRecordToRSNTable(insertRowIndx, strInsOpt, txtCVT.Text.Trim(), rtxtFreeText.Text.Trim(), strRxn_Stage);
                        }
                    }
                    else
                    {               
                        RSNData.Rows[editRowIndx - 1]["CVT"] = txtCVT.Text.Trim();
                        RSNData.Rows[editRowIndx - 1]["FREE_TEXT"] = rtxtFreeText.Text.Trim();
                        RSNData.Rows[editRowIndx - 1]["NOTE_LEVEL"] = strRxn_Stage;
                        RSNData.AcceptChanges();                        

                        txtCVT.Text = "";
                        rtxtFreeText.Text = "";
                    }

                    editRowIndx = -1;
                    strFreeText_Edit = "";

                    //Set Current Stage RSN length - 26th Nov 2013  
                    SetStagesRSNLenthValues();                   
                }
                else
                {
                    MessageBox.Show(strErrMsg, "RSN", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private int GetRowIndexToAddReactionFreeText(out string freetext)
        {
            int intRIndx = 0;
            string strFreeText = "";
            try
            {
                if (RSNData != null)
                {
                    for (int i = 0; i < RSNData.Rows.Count; i++)
                    {
                        if (RSNData.Rows[i]["CVT"].ToString().Trim() != "" && RSNData.Rows[i]["NOTE_LEVEL"].ToString().Trim() == "Reaction")
                        {
                            intRIndx = i + 1;
                            if (!string.IsNullOrEmpty(RSNData.Rows[i]["FREE_TEXT"].ToString().Trim()))
                            {
                                strFreeText = RSNData.Rows[i]["FREE_TEXT"].ToString().Trim();
                               // RSNData.Rows[i]["rsn_free_text"] = "";
                            }
                        }
                    }                    
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            freetext = strFreeText;
            return intRIndx;
        }

        private void AddRecordToRSNTable(int insertrowindex, string before_after,string rsn_cvt,string rsn_freetext, string reaction_stage)
        {
            try
            {
                //int intNewParpntID = CASRxnDataAccess.Insert_Get_RxnNewParticipantID("RSN", StageID, insertrowindex, before_after, GlobalVariables.URID); ;
                int intNewParpntID = ReactDB.GetReactionNewParticipantID("RSN",ReactionID, StageID, insertrowindex, before_after, GlobalVariables.URID); ;
                if (intNewParpntID > 0)
                {
                    if (RSNData == null)
                    {
                        RSNData = CreateRxnRSNTable();
                    }

                    DataRow drRSN = RSNData.NewRow();
                    
                    drRSN["RXN_STAGE_ID"] = StageID;
                    drRSN["RSN_ID"] = intNewParpntID;
                    drRSN["CVT"] = rsn_cvt;
                    drRSN["FREE_TEXT"] = rsn_freetext;
                    drRSN["NOTE_LEVEL"] = reaction_stage;
                    drRSN["DISPLAY_ORDER"] = insertrowindex;

                    //if (before_after == "BEFORE" || before_after == "END")
                    //{
                    //    drRSN["display_order"] = rowindex + 1;
                    //    RSNData.Rows.InsertAt(drRSN, rowindex);
                    //}
                    if (before_after == "AFTER")
                    {                       
                        RSNData.Rows.InsertAt(drRSN, insertrowindex - 1);

                        if (dgvRSN.Rows.Count > 1)
                        {
                            dgvRSN.CurrentCell = dgvRSN.Rows[dgvRSN.Rows.Count - 1].Cells[0];
                        }
                    }

                    //Change Display order in RSN table
                    ChangeDisplayOrderInRSNTable(insertrowindex, before_after);

                    txtCVT.Text = "";
                    rtxtFreeText.Text = "";
                }
                else
                {
                    MessageBox.Show("Error in adding RSN", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }     
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private DataTable CreateRxnRSNTable()
        {
            DataTable dtRSN = new DataTable();
            try
            {
                //dtRSN.Columns.Add("RXN_ID", typeof(Int32));
                dtRSN.Columns.Add("RXN_STAGE_ID", typeof(Int32));
                dtRSN.Columns.Add("RSN_ID", typeof(Int32));
                dtRSN.Columns.Add("CVT", typeof(string));
                dtRSN.Columns.Add("FREE_TEXT", typeof(string));
                dtRSN.Columns.Add("NOTE_LEVEL", typeof(string));
                dtRSN.Columns.Add("DISPLAY_ORDER", typeof(Int32));
                return dtRSN;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtRSN;
        }

        private DataTable ChangeDisplayOrderInRSNTable(int _rowindex, string _insOpt)
        {            
            try
            {
                if (RSNData != null)
                {
                    if (RSNData.Rows.Count > 0)
                    {
                        if (_insOpt == "AFTER")
                        {
                            int rIndx = _rowindex;
                            //if (_insOpt == "AFTER")
                            //{
                            //    rIndx = _rowindex;// +1;
                            //}
                            //else if (_insOpt == "BEFORE")
                            //{
                            //    rIndx = _rowindex;
                            //}
                            for (int i = rIndx; i < RSNData.Rows.Count; i++)
                            {
                                RSNData.Rows[i]["DISPLAY_ORDER"] = Convert.ToInt32(RSNData.Rows[i]["DISPLAY_ORDER"].ToString()) + 1;
                            }
                            RSNData.AcceptChanges();
                        }
                        else if (_insOpt == "DELETE")
                        {
                            int rIndx = _rowindex;
                            for (int i = rIndx; i < RSNData.Rows.Count; i++)
                            {
                                RSNData.Rows[i]["DISPLAY_ORDER"] = Convert.ToInt32(RSNData.Rows[i]["DISPLAY_ORDER"].ToString()) - 1;
                            }
                            RSNData.AcceptChanges();
                        }
                    }
                }
                return RSNData;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return RSNData;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                txtCVT.Text = "";
                rtxtFreeText.Text = "";
                txtSrch_CVT.Text = "";
                txtSrch_FreeText.Text = "";
                rbnReplace_FT.Checked = true;

                strFreeText_Edit = "";
                strCVT_Edit = "";
                editRowIndx = -1;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        int editRowIndx = -1;
        string strFreeText_Edit = "";
        string strCVT_Edit = "";

        private void dgvRSN_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex >= 0 && e.RowIndex >= 0)
                {
                    if (dgvRSN.Columns[e.ColumnIndex].Name == colEdit_RSN.Name)
                    {
                        DialogResult diaRes = MessageBox.Show("Do you want to edit the RSN term?", "Edit RSN", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (diaRes == DialogResult.Yes)
                        {
                            editRowIndx = e.RowIndex + 1;

                            string strRxn_Stage = dgvRSN.Rows[e.RowIndex].Cells[colSelect.Name].Value.ToString();
                            if (strRxn_Stage.ToUpper() == "REACTION")
                            {
                                rbnReaction.Checked = true;
                            }
                            else if (strRxn_Stage.ToUpper() == "STAGE")
                            {
                                rbnStage.Checked = true;
                            }

                            txtCVT.Text = dgvRSN.Rows[e.RowIndex].Cells[colCVT_RSN.Name].Value.ToString();
                            rtxtFreeText.Text = dgvRSN.Rows[e.RowIndex].Cells[colFreeText_RSN.Name].Value.ToString();

                            strCVT_Edit = dgvRSN.Rows[e.RowIndex].Cells[colCVT_RSN.Name].Value.ToString();
                            strFreeText_Edit = dgvRSN.Rows[e.RowIndex].Cells[colFreeText_RSN.Name].Value.ToString();
                        }
                    }
                    else if (dgvRSN.Columns[e.ColumnIndex].Name == colDelete_RSN.Name) 
                    {
                        DialogResult diaRes = MessageBox.Show("Do you want to delete the RSN term permanently?", "Delete RSN", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (diaRes == DialogResult.Yes)
                        {
                            if (RSNData.Rows[e.RowIndex]["RSN_ID"].ToString() != "")
                            {
                                int intPartpntID = 0;
                                int.TryParse(RSNData.Rows[e.RowIndex]["RSN_ID"].ToString(), out intPartpntID);

                                if (intPartpntID > 0)
                                {
                                    if (ReactDB.DeleteReactionParticipant(intPartpntID, "RSN"))
                                    {
                                        RSNData.Rows[e.RowIndex].Delete();
                                        RSNData.AcceptChanges();

                                        txtCVT.Text = "";
                                        rtxtFreeText.Text = "";
                                        editRowIndx = -1;
                                    }
                                    else
                                    {
                                        MessageBox.Show("Error in delete RSN", "Delete RSN", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult = DialogResult.OK;
                this.Close();

                //string strErrMsg = "";
                //if (ValidateRSNData(out strErrMsg))
                //{
                //    DialogResult = DialogResult.OK;
                //    this.Close();
                //}
                //else
                //{
                //    MessageBox.Show(strErrMsg, "RSN", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        /// <summary>
        /// Get Current Stage RSN length - 25th Nov 2013
        /// </summary>
        /// <returns></returns>
        private int GetRSNLengthFromTable(DataTable rsnData)
        {
            int intRsnLen = 0;
            try
            {
                if (rsnData != null)
                {
                    if (rsnData.Rows.Count > 0)
                    {
                        for (int i = 0; i < rsnData.Rows.Count; i++)
                        {
                            if (rsnData.Rows[i]["CVT"] != null)
                            {
                                intRsnLen = intRsnLen + rsnData.Rows[i]["CVT"].ToString().Length;
                            }
                            if (rsnData.Rows[i]["FREE_TEXT"] != null)
                            {
                                intRsnLen = intRsnLen + rsnData.Rows[i]["FREE_TEXT"].ToString().Length;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return intRsnLen;
        }

        /// <summary>
        /// Get Other Stages RSN Length
        /// </summary>
        /// <returns></returns>
        private int GetOtherStagesRSNLength()
        {
            int intRsnLen = 0;
            try
            {
                if (TabCntrl_Stages != null)
                {
                    if (TabCntrl_Stages.TabPages.Count > 0)
                    {
                        ucParticipants ucPartpnt;
                        DataTable dtRSN = null;

                        foreach (TabPage tp in TabCntrl_Stages.TabPages)
                        {
                            ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                            if (ucPartpnt != null)
                            {
                                if (StageName.ToUpper() != ucPartpnt.StageName.ToUpper())
                                {
                                    dtRSN = ucPartpnt.dtRSN;
                                    if (dtRSN != null)
                                    {
                                       intRsnLen = intRsnLen + GetRSNLengthFromTable(dtRSN);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return intRsnLen;
        }
        
        private void frmRSN_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                string strErrMsg = "";
                if (ValidateRSNData(out strErrMsg))
                {
                    DialogResult = DialogResult.OK;
                    e.Cancel = false;
                }
                else
                {
                    MessageBox.Show(strErrMsg, "RSN", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    e.Cancel = true;
                }    
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
