﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarrDAL;
using IndxReactNarr.Generic;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Collections;
using System.IO;

namespace IndxReactNarr
{
    public partial class frmBatchXml : Form
    {
        public frmBatchXml()
        {
            InitializeComponent();
        }

        #region Property Procedures

        public DataTable Batch_TANS
        { get; set; }       

        public string FileName
        { get; set; }

        public string FilePath
        { get; set; }

        public bool TrimXml
        { get; set; }

        public bool FreezeTANs
        { get; set; }

        public bool GenerateNarrXmls
        { get; set; }

        public bool GenerateReactXmls
        { get; set; }

        public bool GenerateIdxDAT_Sdf
        { get; set; }

        public string[] SelectedTANs
        { get; set; }

        public string MarkupPdfsPath
        { get; set; }

        private DataTable _dtavailtans = null;
        public DataTable AvailableTANsTbl
        {
            get
            {
                return _dtavailtans;
            }
            set
            {
                _dtavailtans = value;
            }
        }

        private DataTable _dtselectedtans = null;
        public DataTable SelectedTANsTbl
        {
            get
            {
                return _dtselectedtans;
            }
            set
            {
                _dtselectedtans = value;
            }
        }

        public DataTable TANsForXML
        { get; set; }

        #endregion

        private void frmBatchXml_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;

                if (GlobalVariables.RoleName.ToUpper() == "ADMINISTRATOR" || GlobalVariables.RoleName.ToUpper() == "TOOL MANAGER")
                {
                    chkSkipQcCheck.Visible = true;
                }

                if (GlobalVariables.ApplicationName == Enums.ApplicationName.ORGANIC.ToString().ToUpper())
                {
                    this.Text = "Organic Indexing - Export";
                    GenerateIdxDAT_Sdf = true;                   
                }
                else if (GlobalVariables.ApplicationName == Enums.ApplicationName.NARRATIVES.ToString().ToUpper())
                {
                    this.Text = "Narratives - Export";
                    GenerateNarrXmls = true;

                    //For Narrative FileName is not Required
                    txtFileName.Enabled = false;
                }
                else if (GlobalVariables.ApplicationName == Enums.ApplicationName.EXPPROCEDURES.ToString().ToUpper())
                {
                    this.Text = "Experimental Procedures - Export";
                    GenerateNarrXmls = true;

                    //For Narrative FileName is not Required
                    txtFileName.Enabled = false;
                }
                else if (GlobalVariables.ApplicationName == Enums.ApplicationName.REACT.ToString().ToUpper())
                {
                    this.Text = "Reaction Analysis - Export";
                    GenerateReactXmls = true;
                }

                //Get Shipment Names and Set Autofill
                GetShipmentNamesAndSetToUserNameTxtBox_AutoComplete();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private void GetShipmentNamesAndSetToUserNameTxtBox_AutoComplete()
        {
            try
            {
                DataTable dtTanTypes = null;
                DataTable dtShipments = null;
                using (dtShipments = ReactDB.GetShipmentDetailsByAppName(GlobalVariables.ApplicationName, out dtTanTypes))
                {
                    if (dtShipments != null)
                    {
                        if (dtShipments.Rows.Count > 0)
                        {
                            AutoCompleteStringCollection shipmentColl = new AutoCompleteStringCollection();

                            for (int i = 0; i < dtShipments.Rows.Count; i++)
                            {
                                if (dtShipments.Rows[i][0] != null)
                                {
                                    shipmentColl.Add(dtShipments.Rows[i]["SHIPMENT_NAME"].ToString());
                                }
                            }

                            txtBatchName.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                            txtBatchName.AutoCompleteSource = AutoCompleteSource.CustomSource;
                            txtBatchName.AutoCompleteCustomSource = shipmentColl;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        string strBatchName = "";
        string strBatchNo = "";
        private void btnGetTans_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;

                //Reset Status values
                ReSetStatusValues();

                int intBNo = 0;
                int.TryParse(txtBNo.Text.Trim(), out intBNo);

                //DataTable dtB_TANS = ReactDB.Get_Curated_TANs_On_Batch(txtBatchName.Text.Trim(), intBNo);
                DataTable dtB_TANS = ShipmentMasterDB.GetTANsForExportOnApp_Shipment(GlobalVariables.ApplicationName, txtBatchName.Text.Trim(), intBNo);
                if (dtB_TANS != null)
                {
                    if (dtB_TANS.Rows.Count > 0)
                    {
                        strBatchName = txtBatchName.Text.Trim();
                        strBatchNo = txtBNo.Text.Trim();

                        //Batch_TANS = dtB_TANS; 

                        AvailableTANsTbl = dtB_TANS;
                        //Bind Data to Available TANs grid
                        BindDataToAvailableTANsGrid(AvailableTANsTbl);

                        dtselTans = null;
                        SelectedTANsTbl = null;

                        //Bind data to Selected TANs grid
                        BindDataToSelectedTANsGrid(SelectedTANsTbl);                                             
                        
                        //Set Status Values
                        GetStatusValues_BindToControls(dtB_TANS);
                        Cursor = Cursors.Default;
                    }
                    else
                    {
                        AvailableTANsTbl = null;
                        BindDataToAvailableTANsGrid(AvailableTANsTbl);

                        Cursor = Cursors.Default;
                        MessageBox.Show("No TANs found for the batch",GlobalVariables.MessageCaption,MessageBoxButtons.OK,MessageBoxIcon.Information);
                    }
                }
                else
                {
                    AvailableTANsTbl = null;
                    BindDataToAvailableTANsGrid(AvailableTANsTbl);

                    Cursor = Cursors.Default;
                    MessageBox.Show("No TANs found for the batch", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
                Cursor = Cursors.Default;
            }
        }

        private void btnXml_Click(object sender, EventArgs e)
        {
            try
            {
                //CASRxnTool.Narratives_Xml.WriteNarrativesXml.WriteNarrativesXmlFile(@"C:\Documents and Settings\sairam.punyamantula\Desktop\CASRACT_Xmls", "24654666H", "JOURNAL");

                string strErrMsg = "";
                if (ValidateUserInputs(out strErrMsg))
                {
                    //TANs for Xml generation
                    Batch_TANS = TANsForXML;

                    FreezeTANs = false;// chkFreezeTANs.Checked;
                    TrimXml = true;
                   
                    FileName = txtFileName.Text.Trim();
                    FilePath = txtFilePath.Text.Trim();
                    MarkupPdfsPath = txtMarkupsPath.Text.Trim();

                    if (FreezeTANs)//chkFreezeTANs.Checked
                    {
                        //Selected Tans for freezing
                        SelectedTANs = Batch_TANS.Rows.Cast<DataRow>()
                                        .Select(row => row["TAN_NAME"].ToString())
                                        .ToArray();
                    }

                    //DialogResult = DialogResult.OK;
                    //this.Close();

                    IndxReactNarr.Export.INR_Export objB_XML = new IndxReactNarr.Export.INR_Export();
                    objB_XML.TANsForExport = Batch_TANS;
                    objB_XML.OutputFileName = FileName;
                    objB_XML.OutputFilesPath = txtFilePath.Text.Trim();
                    objB_XML.MarkUpFilesPath = txtMarkupsPath.Text.Trim();
                    objB_XML.TrimReactXml = TrimXml;
                    objB_XML.ApplicationName = GlobalVariables.ApplicationName;
                    
                    if (objB_XML.ExportTANsDataToFiles())
                    {
                        MessageBox.Show("Generated output files successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);

                        ////Freeze TANs once xml file is generated
                        //if (FreezeTANs && SelectedTANs != null)
                        //{
                        //    CASRxnDataAccess.FreezeTANs(objBatch.SelectedTANs);
                        //}

                        Cursor = Cursors.Default;
                    }
                    else
                    {
                        MessageBox.Show("Error in writing Xml file", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Cursor = Cursors.Default;
                    }
                }
                else
                {
                    MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }      
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private bool ValidateUserInputs(out string errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (dgvXmlTANs.Rows.Count == 0)
                {
                    strErrMsg = "No TANs are available to export";
                    blStatus = false;
                }
                if (string.IsNullOrEmpty(txtFileName.Text.Trim()) && GlobalVariables.ApplicationName != Enums.ApplicationName.NARRATIVES.ToString().ToUpper()
                    && GlobalVariables.ApplicationName != Enums.ApplicationName.EXPPROCEDURES.ToString().ToUpper())                    
                {
                    strErrMsg = strErrMsg.Trim() + "\r\n" + "Please enter File Name";
                    blStatus = false;
                }
                if (string.IsNullOrEmpty(txtFilePath.Text.Trim()))
                {
                    strErrMsg = strErrMsg.Trim() + "\r\n" + "Please select output folder path";
                    blStatus = false;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg.Trim();
            return blStatus;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
                {
                    if (folderBrowserDialog1.SelectedPath.ToString() != "")
                    {
                        txtFilePath.Text = folderBrowserDialog1.SelectedPath.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        ArrayList availTANList = new ArrayList();
        ArrayList selTANList = new ArrayList();
        DataTable dtselTans = null;

        private void btnSelOne_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvAvailableTANs.Rows.Count > 0)
                {
                    if (dgvAvailableTANs.SelectedRows.Count > 0)
                    {
                        if (dtselTans == null)
                        {
                            dtselTans = AvailableTANsTbl.Clone();
                        }
                        int rindex_out = 0;

                        DataGridViewSelectedRowCollection selRowColl = dgvAvailableTANs.SelectedRows;
                        if (selRowColl != null && selRowColl.Count > 0)
                        {
                            ArrayList alstRowIDs = new ArrayList();

                            string strErrMsg_Out = "";
                            string strCurQcStatus = "";
                            if (CheckTAN_Status_QC_Curation_Completed(selRowColl, out strCurQcStatus, out strErrMsg_Out))
                            {
                                //if (CheckTAN_IsFreezed(selRowColl, out strErrMsg_Out))
                                //{
                                //foreach (DataGridViewRow selRow in dgvAvailableTANs.SelectedRows.OfType<DataGridViewRow>().ToArray())
                                //{
                                //    dgvAvailableTANs.Rows.Remove(selRow);
                                //    dgvSelectedTANs.Rows.Add(selRow);
                                //}

                                for (int i = 0; i < selRowColl.Count; i++)
                                {
                                    dtselTans.ImportRow(GetSelectedRowFromMainTable(selRowColl[i].Cells[0].Value.ToString(), out rindex_out));
                                    if (!alstRowIDs.Contains(rindex_out))
                                    {
                                        alstRowIDs.Add(rindex_out);
                                    }

                                    //AvailableTANsTbl.Rows[rindex_out].Delete();
                                    //AvailableTANsTbl.AcceptChanges();
                                }

                                if (alstRowIDs != null && alstRowIDs.Count > 0)
                                {
                                    for (int i = 0; i < alstRowIDs.Count; i++)
                                    {
                                        if (AvailableTANsTbl.Rows.Count > Convert.ToInt32(alstRowIDs[i]))
                                        {
                                            AvailableTANsTbl.Rows[Convert.ToInt32(alstRowIDs[i])].Delete();
                                        }
                                    }
                                    AvailableTANsTbl.AcceptChanges();
                                }
                                //}
                                //else
                                //{
                                //    MessageBox.Show("Below TANs already submitted:\r\n" + strErrMsg_Out, "Batch XML", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                //}
                            }
                            else
                            {
                                MessageBox.Show("For the below TANs, " + strCurQcStatus + " is not completed:\r\n" + strErrMsg_Out, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }

                        DataView dvTemp = dtselTans.DefaultView;
                        dvTemp.Sort = "TAN_NAME asc";// "bt_id asc";
                        dtselTans = dvTemp.ToTable();

                        SelectedTANsTbl = dtselTans;

                        //Bind data to Selected TANs grid
                        BindDataToSelectedTANsGrid(dtselTans);

                        //Bind data to Available TANs grid
                        BindDataToAvailableTANsGrid(AvailableTANsTbl);

                        txtTANSrch.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnDelOne_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvSelectedTANs.Rows.Count > 0)
                {
                    if (dgvSelectedTANs.SelectedRows.Count > 0)
                    {
                        DataTable dtAvailTans = AvailableTANsTbl;
                        int selrowIndx = 0;

                        DataGridViewSelectedRowCollection selRowColl = dgvSelectedTANs.SelectedRows;
                        if (selRowColl != null)
                        {
                            if (selRowColl.Count > 0)
                            {
                                ArrayList alstRowIDs = new ArrayList();

                                for (int i = 0; i < selRowColl.Count; i++)
                                {
                                    if (selRowColl[i].Cells[0].Value != null)
                                    {
                                        DataRow dRow = GetSelectedRowFromSelectedTANSTable(selRowColl[i].Cells[0].Value.ToString(), out selrowIndx);
                                        if (dRow != null)
                                        {
                                            dtAvailTans.ImportRow(dRow);
                                            if (!alstRowIDs.Contains(selrowIndx))
                                            {
                                                alstRowIDs.Add(selrowIndx);
                                            }

                                            //SelectedTANsTbl.Rows[selrowIndx].Delete();
                                            //SelectedTANsTbl.AcceptChanges();
                                        }
                                    }
                                }

                                if (alstRowIDs != null)
                                {
                                    if (alstRowIDs.Count > 0)
                                    {
                                        for (int i = 0; i < alstRowIDs.Count; i++)
                                        {
                                            if (SelectedTANsTbl.Rows.Count >= Convert.ToInt32(alstRowIDs[i]))
                                            {
                                                SelectedTANsTbl.Rows[Convert.ToInt32(alstRowIDs[i])].Delete();
                                            }
                                        }
                                        SelectedTANsTbl.AcceptChanges();
                                    }
                                }                                                             
                            }
                        }

                        DataView dvTemp = dtAvailTans.DefaultView;
                        dvTemp.Sort = "TAN_NAME asc"; //"bt_id asc";
                        dtAvailTans = dvTemp.ToTable();  

                        AvailableTANsTbl = dtAvailTans;

                        //Bind data to Available TANs grid
                        BindDataToAvailableTANsGrid(dtAvailTans);

                        //Bind data to Selected TANs grid
                        BindDataToSelectedTANsGrid(SelectedTANsTbl);

                        txtTANSrch.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private bool CheckTAN_Status_QC_Curation_Completed(DataGridViewSelectedRowCollection selectedrows, out string cur_qcStatus, out string errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            string strCurQCStatus = "";
            try
            {
                if ((GlobalVariables.RoleName.ToUpper() == Common.RolesMaster.ADMIN.ToUpper() ||
                     GlobalVariables.RoleName.ToUpper() == Common.RolesMaster.TOOL_MANAGER.ToUpper())
                    && chkSkipQcCheck.Checked)
                {
                    //New validation on 05JAN2016, Curation completed is must for any TAN to export
                    for (int i = 0; i < selectedrows.Count; i++)
                    {
                        if (selectedrows[i].Cells[colTanStatus.Name].Value.ToString().ToUpper() == "NOT ASSIGNED" ||
                            selectedrows[i].Cells[colTanStatus.Name].Value.ToString().Contains("CURATION - PROGRESS") ||
                            selectedrows[i].Cells[colTanStatus.Name].Value.ToString().Contains("CURATION - ASSIGNED"))
                        {
                            blStatus = false;

                            strErrMsg = strErrMsg.Trim() == "" ? selectedrows[i].Cells[colTAN_Avail.Name].Value.ToString() :
                                strErrMsg.Trim() + ", " + selectedrows[i].Cells[colTAN_Avail.Name].Value.ToString();

                            strCurQCStatus = "Curation";
                        }
                    }
                }
                else if (selectedrows != null && selectedrows.Count > 0)
                {
                    for (int i = 0; i < selectedrows.Count; i++)
                    {
                        if (selectedrows[i].Cells[colTanStatus.Name].Value.ToString().ToUpper() != "QUALITY CHECK COMPLETED")
                        {
                            blStatus = false;

                            strErrMsg = strErrMsg.Trim() == "" ? selectedrows[i].Cells[colTAN_Avail.Name].Value.ToString() :
                                strErrMsg.Trim() + ", " + selectedrows[i].Cells[colTAN_Avail.Name].Value.ToString();

                            strCurQCStatus = "QC";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg;
            cur_qcStatus = strCurQCStatus;
            return blStatus;
        }

        private bool CheckTAN_IsFreezed(DataGridViewSelectedRowCollection selectedrows, out string errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (selectedrows != null)
                {
                    if (selectedrows.Count > 0)
                    {
                        for (int i = 0; i < selectedrows.Count; i++)
                        {
                            if (selectedrows[i].Cells["colIsFreezed_Avail"].Value.ToString().ToUpper() == "TRUE")
                            {
                                blStatus = false;
                                if (strErrMsg.Trim() == "")
                                {
                                    strErrMsg = selectedrows[i].Cells[0].Value.ToString();
                                }
                                else
                                {
                                    strErrMsg = strErrMsg.Trim() + ", " + selectedrows[i].Cells[0].Value.ToString();
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg;
            return blStatus;
        }

        private void BindDataToAvailableTANsGrid(DataTable dtavailabletans)
        {
            try
            {

                if (dtavailabletans != null)
                {
                    dgvAvailableTANs.AutoGenerateColumns = false;
                    dgvAvailableTANs.DataSource = dtavailabletans;

                    colTAN_ID_Avail.DataPropertyName = "TAN_ID";
                    colTAN_Avail.DataPropertyName = "TAN_NAME";
                    colBNo_Avail.DataPropertyName = "BATCH_NO";
                    colTANType_Avail.DataPropertyName = "TAN_TYPE";
                    colRxnCnt.DataPropertyName = "REACTION_CNT";
                    //colIsFreezed_Avail.DataPropertyName = "tan_freezed";
                    colTanStatus.DataPropertyName = "TASK_STATUS";
                    colDocClass_Avl.DataPropertyName = "DOC_CLASS";
                    colTANPriority_Avl.DataPropertyName = "TAN_PRIORITY";
                    colQueryTAN_Avl.DataPropertyName = "QUERY_TAN";
                    lblAvlTANCnt.Text = dgvAvailableTANs.Rows.Count.ToString();

                    if (GlobalVariables.ApplicationName != Enums.ApplicationName.REACT.ToString().ToUpper())
                    {
                        colDocClass_Avl.Visible = false;
                        colTANPriority_Avl.Visible = false;
                        colQueryTAN_Avl.Visible = false;
                        colIsFreezed_Avail.Visible = false;

                        colDocClass_Sel.Visible = false;
                        colTANPriority_Sel.Visible = false;
                        colQueryTAN_Sel.Visible = false;
                        colIsFreezed_Sel.Visible = false;

                        colDocClass_Xml.Visible = false;
                        colTANPriority_Xml.Visible = false;
                        colQueryTAN_Xml.Visible = false;                       
                    }
                }
                else
                {
                    dgvAvailableTANs.DataSource = dtavailabletans;
                    lblAvlTANCnt.Text = "0";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindDataToSelectedTANsGrid(DataTable dtselectedtans)
        {
            try
            {
                if (dtselectedtans != null)
                {
                    dgvSelectedTANs.AutoGenerateColumns = false;
                    dgvSelectedTANs.DataSource = dtselectedtans;

                    colTAN_ID_Sel.DataPropertyName = "TAN_ID";
                    colTAN_Sel.DataPropertyName = "TAN_NAME";
                    colBNo_Sel.DataPropertyName = "BATCH_NO";
                    colTANType_Sel.DataPropertyName = "TAN_TYPE";
                    colRxnCnt_Sel.DataPropertyName = "REACTION_CNT";
                    //colIsFreezed_Sel.DataPropertyName = "tan_freezed";
                    colTANStatus_Sel.DataPropertyName = "TASK_STATUS";
                    colDocClass_Sel.DataPropertyName = "DOC_CLASS";
                    colTANPriority_Sel.DataPropertyName = "TAN_PRIORITY";
                    colQueryTAN_Sel.DataPropertyName = "QUERY_TAN";
                    lblSelTANCnt.Text = dgvSelectedTANs.Rows.Count.ToString();
                }
                else
                {
                    dgvSelectedTANs.DataSource = dtselectedtans;
                    lblSelTANCnt.Text = "0";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindDataToXMLTANsGrid(DataTable xmltanstbl)
        {
            try
            {
                if (xmltanstbl != null)
                {
                    dgvXmlTANs.AutoGenerateColumns = false;
                    dgvXmlTANs.DataSource = xmltanstbl;

                    colTAN_ID_Xml.DataPropertyName = "TAN_ID";
                    colTAN_Xml.DataPropertyName = "TAN_NAME";
                    colTANType_Xml.DataPropertyName = "TAN_TYPE";
                    colRxnCnt_Xml.DataPropertyName = "REACTION_CNT";
                    colBatch_Xml.DataPropertyName = "BATCH_NAME";
                    colBNo_Xml.DataPropertyName = "BATCH_NO";
                    colTANStatus_Xml.DataPropertyName = "TASK_STATUS";
                    colDocClass_Xml.DataPropertyName = "DOC_CLASS";
                    colTANPriority_Xml.DataPropertyName = "TAN_PRIORITY";
                    colQueryTAN_Xml.DataPropertyName = "QUERY_TAN";

                    lblXmlTANCnt.Text = dgvXmlTANs.Rows.Count.ToString();
                }
                else
                {
                    dgvXmlTANs.DataSource = null;
                    lblXmlTANCnt.Text = dgvXmlTANs.Rows.Count.ToString();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetStatusValues_BindToControls(DataTable batchtansdata)
        {
            try
            {
                if (batchtansdata != null)
                {
                    if (batchtansdata.Rows.Count > 0)
                    {
                        //Curation Completed
                        DataView dv_Cur = batchtansdata.Copy().DefaultView;
                        dv_Cur.RowFilter = "TASK_STATUS = 'Curation Completed'";
                        DataTable dt_Cur = dv_Cur.ToTable();
                        if (dt_Cur != null)
                        {
                            lblCur_Done_Cnt.Text = dt_Cur.Rows.Count.ToString();
                        }

                        //Review Completed
                        DataView dv_Rev = batchtansdata.Copy().DefaultView;
                        dv_Rev.RowFilter = "TASK_STATUS = 'Review Completed'";
                        DataTable dt_Rev = dv_Rev.ToTable();
                        if (dt_Rev != null)
                        {
                            lblRev_Done_Cnt.Text = dt_Rev.Rows.Count.ToString();
                        }

                        //QC Completed
                        DataView dv_QC = batchtansdata.Copy().DefaultView;
                        dv_QC.RowFilter = "TASK_STATUS = 'Quality Check Completed'";
                        DataTable dt_QC = dv_QC.ToTable();
                        if (dt_QC != null)
                        {
                            lblQC_Done_Cnt.Text = dt_QC.Rows.Count.ToString();
                        }

                        //Assigned for Curation
                        DataView dv_AC = batchtansdata.Copy().DefaultView;
                        dv_AC.RowFilter = "TASK_STATUS = 'Assigned for Curation'";
                        DataTable dt_AC = dv_AC.ToTable();
                        if (dt_AC != null)
                        {
                            lblAssCur_Cnt.Text = dt_AC.Rows.Count.ToString();
                        }

                        //Assigned for Review
                        DataView dv_AR = batchtansdata.Copy().DefaultView;
                        dv_AR.RowFilter = "TASK_STATUS = 'Assigned for Review'";
                        DataTable dt_AR = dv_AR.ToTable();
                        if (dt_AR != null)
                        {
                            lblAssRev_Cnt.Text = dt_AR.Rows.Count.ToString();
                        }

                        //Assigned for Quality Check
                        DataView dv_AQC = batchtansdata.Copy().DefaultView;
                        dv_AQC.RowFilter = "TASK_STATUS = 'Assigned for Quality Check'";
                        DataTable dt_AQC = dv_AQC.ToTable();
                        if (dt_AQC != null)
                        {
                            lblAssQC_Cnt.Text = dt_AQC.Rows.Count.ToString();
                        }

                        //Re-Assigned for Quality Check
                        DataView dv_RAQC = batchtansdata.Copy().DefaultView;
                        dv_RAQC.RowFilter = "TASK_STATUS = 'Re-Assigned for Quality Check'";
                        DataTable dt_RAQC = dv_RAQC.ToTable();
                        if (dt_RAQC != null)
                        {
                            lblReAssQC_Cnt.Text = dt_RAQC.Rows.Count.ToString();
                        }

                        //Re-Assigned for Review
                        DataView dv_RAR = batchtansdata.Copy().DefaultView;
                        dv_RAR.RowFilter = "TASK_STATUS = 'Re-Assigned for Review'";
                        DataTable dt_RAR = dv_RAR.ToTable();
                        if (dt_RAR != null)
                        {
                            lblReAssRev_Cnt.Text = dt_RAR.Rows.Count.ToString();
                        }

                        //Re-Assigned for Curation
                        DataView dv_RAC = batchtansdata.Copy().DefaultView;
                        dv_RAC.RowFilter = "TASK_STATUS = 'Re-Assigned for Curation'";
                        DataTable dt_RAC = dv_RAC.ToTable();
                        if (dt_RAC != null)
                        {
                            lblReAssCur_Cnt.Text = dt_RAC.Rows.Count.ToString();
                        }

                        ////Freezed TANs
                        //DataView dv_FT = batchtansdata.Copy().DefaultView;
                        //dv_FT.RowFilter = "tan_freezed = true";
                        //DataTable dt_FT = dv_FT.ToTable();
                        //if (dt_FT != null)
                        //{
                        //    lblFreezeTAN_Cnt.Text = dt_FT.Rows.Count.ToString();
                        //}


                        ////Pending TANs
                        //DataView dv_Pend = batchtansdata.Copy().DefaultView;
                        //dv_Pend.RowFilter = "status = 'Pending'";
                        //DataTable dt_Pend = dv_Pend.ToTable();
                        //if (dt_Pend != null)
                        //{
                        //    lblPending_Val.Text = dt_Pend.Rows.Count.ToString();
                        //}

                        ////No.of Reactions
                        //object objRxnCnt = batchtansdata.Compute("sum([No.of Reactions])", "[No.of Reactions] is not null");
                        //if (objRxnCnt != null)
                        //{
                        //    lblRxns_Val.Text = objRxnCnt.ToString();
                        //}

                        ////No.of Extra Stages
                        //object objStgCnt = batchtansdata.Compute("sum([No.of Extra Stages])", "[No.of Extra Stages] is not null");
                        //if (objStgCnt != null)
                        //{
                        //    lblStages_Val.Text = objStgCnt.ToString();
                        //}

                        ////No.of TANs
                        //lblTANCnt.Text = batchtansdata.Rows.Count.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private DataRow GetSelectedRowFromMainTable(string _tannumber, out int _rowindex_out)
        {
            try
            {
                if (AvailableTANsTbl != null)
                {
                    if (AvailableTANsTbl.Rows.Count > 0)
                    {
                        DataRow dtRow = null;
                        for (int i = 0; i < AvailableTANsTbl.Rows.Count; i++)
                        {
                            if (AvailableTANsTbl.Rows[i][0].ToString() == _tannumber)
                            {
                                dtRow = AvailableTANsTbl.Rows[i];
                                _rowindex_out = i;
                                return dtRow;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _rowindex_out = 0;
            return null;
        }

        private DataRow GetSelectedRowFromSelectedTANSTable(string _tannumber, out int _rowindex_out)
        {
            try
            {
                if (SelectedTANsTbl != null)
                {
                    if (SelectedTANsTbl.Rows.Count > 0)
                    {
                        DataRow dtRow = null;
                        for (int i = 0; i < SelectedTANsTbl.Rows.Count; i++)
                        {
                            if (SelectedTANsTbl.Rows[i].RowState != DataRowState.Deleted)
                            {
                                if (SelectedTANsTbl.Rows[i][0].ToString() == _tannumber)
                                {
                                    dtRow = SelectedTANsTbl.Rows[i];
                                    _rowindex_out = i;
                                    return dtRow;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _rowindex_out = 0;
            return null;
        }

        private void txtTANSrch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (AvailableTANsTbl != null)
                {
                    if (txtTANSrch.Text.Trim() != "")
                    {
                        string strFCond = GetFilterCondition(txtTANSrch.Text.Trim());

                        DataTable dtAllTANs = AvailableTANsTbl.Copy();
                        DataView dvTemp = dtAllTANs.DefaultView;
                        dvTemp.RowFilter = strFCond;
                        DataTable dtTANs = dvTemp.ToTable();
                        dgvAvailableTANs.DataSource = dtTANs;
                    }
                    else
                    {
                        DataTable dtAllTANs = AvailableTANsTbl.Copy();
                        dgvAvailableTANs.DataSource = dtAllTANs;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetFilterCondition(string _query_tan)
        {
            string strFCond = "";
            try
            {
                if (_query_tan.Trim().Contains(";"))
                {
                    string[] splitter = { ";" };
                    string[] strArrTans = _query_tan.Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);

                    if (strArrTans != null)
                    {
                        if (strArrTans.Length > 0)
                        {
                            for (int i = 0; i < strArrTans.Length; i++)
                            {
                                if (i == 0)
                                {
                                    strFCond = "TAN_NAME Like '" + strArrTans[i] + "%' ";
                                }
                                else
                                {
                                    strFCond += " OR" + " TAN_NAME Like '" + strArrTans[i] + "%'";
                                }
                            }
                        }
                    }
                }
                else
                {
                    strFCond = "TAN_NAME Like '" + _query_tan.Trim() + "%'";
                }
                return strFCond;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strFCond;
        }

        private void btnAppend_Click(object sender, EventArgs e)
        {
            try
            {

                string strErrMsg = "";
                //Validate Doc Class for ENP_BF & ENP_FF & ENJ
                if (ValidateDocClassInSelectedTANs(out strErrMsg))
                {
                    string strTAN = "";
                    for (int i = 0; i < dgvSelectedTANs.Rows.Count; i++)
                    {
                        strTAN = "";
                        if (TANsForXML == null)
                        {
                            TANsForXML = new DataTable();
                            TANsForXML.Columns.Add("TAN_ID", typeof(int));
                            TANsForXML.Columns.Add("TAN_NAME");
                            TANsForXML.Columns.Add("TAN_TYPE");
                            TANsForXML.Columns.Add("REACTION_CNT");
                            TANsForXML.Columns.Add("BATCH_NAME");
                            TANsForXML.Columns.Add("BATCH_NO");
                            TANsForXML.Columns.Add("TASK_STATUS");
                            TANsForXML.Columns.Add("DOC_CLASS");
                            TANsForXML.Columns.Add("TAN_PRIORITY");
                            TANsForXML.Columns.Add("QUERY_TAN");
                        }

                        strTAN = dgvSelectedTANs.Rows[i].Cells["colTAN_Sel"].Value.ToString().Trim();

                        //Check if TAN already exist in the Table
                        if (!CheckForRowInXmlTANsTable(strTAN))
                        {
                            DataRow dRow = TANsForXML.NewRow();
                            dRow["TAN_ID"] = Convert.ToInt32(dgvSelectedTANs.Rows[i].Cells[colTAN_ID_Sel.Name].Value.ToString()); 
                            dRow["TAN_NAME"] = strTAN;
                            dRow["TAN_TYPE"] = dgvSelectedTANs.Rows[i].Cells[colTANType_Sel.Name].Value.ToString();
                            dRow["REACTION_CNT"] = dgvSelectedTANs.Rows[i].Cells[colRxnCnt_Sel.Name].Value.ToString();
                            dRow["BATCH_NAME"] = strBatchName;
                            dRow["BATCH_NO"] = dgvSelectedTANs.Rows[i].Cells[colBNo_Sel.Name].Value.ToString();
                            dRow["TASK_STATUS"] = dgvSelectedTANs.Rows[i].Cells[colTANStatus_Sel.Name].Value;
                            dRow["DOC_CLASS"] = dgvSelectedTANs.Rows[i].Cells[colDocClass_Sel.Name].Value;
                            dRow["TAN_PRIORITY"] = dgvSelectedTANs.Rows[i].Cells[colTANPriority_Sel.Name].Value;
                            dRow["QUERY_TAN"] = dgvSelectedTANs.Rows[i].Cells[colQueryTAN_Sel.Name].Value;
                            TANsForXML.Rows.Add(dRow);
                        }
                        else
                        {
                            strErrMsg = string.IsNullOrEmpty(strErrMsg) ? strTAN : strErrMsg + ", " + strTAN;
                        }
                    }

                    if (strErrMsg.Trim() != "")
                    {
                        MessageBox.Show("Below TANs already exist in the XML TANs grid.\r\n" + strErrMsg, "Batch XML", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    SelectedTANsTbl = null;
                    dtselTans = null;
                    BindDataToSelectedTANsGrid(SelectedTANsTbl);

                    //Bind Data to XML TANs grid
                    BindDataToXMLTANsGrid(TANsForXML);
                }
                else
                {
                    MessageBox.Show(strErrMsg, "Batch XML", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private bool ValidateDocClassInSelectedTANs(out string errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (dgvSelectedTANs.Rows.Count > 0)//dgvXmlTANs 
                {
                    DataTable dtSelectedTANs = dgvSelectedTANs.DataSource as DataTable;
                    if (dtSelectedTANs != null)
                    {
                        string[] saDocCol = { "Doc_Class" };
                        DataTable dttemp = dtSelectedTANs.DefaultView.ToTable(true, saDocCol);

                        List<string> list = (from row in dttemp.AsEnumerable()
                                             select row.Field<string>("Doc_Class")).ToList<string>();

                        if (list != null)
                        {
                            if (list.Count > 1)
                            {
                                blStatus = false;
                                strErrMsg = "Selected TANs contain mismatched Doc Class.";
                            }
                            else //Check with already appended tans
                            {
                                if (TANsForXML != null)
                                {                                   
                                    dttemp = TANsForXML.DefaultView.ToTable(true, saDocCol);

                                    List<string>  lstDC_Xml = (from row in dttemp.AsEnumerable()
                                                         select row.Field<string>("Doc_Class")).ToList<string>();
                                    if (lstDC_Xml != null)
                                    {
                                        if (!CompareListsForMatch(list, lstDC_Xml))
                                        {
                                            blStatus = false;
                                            strErrMsg = "Selected TANs contain mismatched Doc Class.";
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg;
            return blStatus;
        }

        private bool CompareListsForMatch(List<string> tans_sel, List<string> tans_xml)
        {
            return tans_sel.TrueForAll(tans_xml.Contains) && tans_xml.TrueForAll(tans_sel.Contains);
        }
        
        private bool CheckForRowInXmlTANsTable(string tan)
        {
            bool blStatus = false;           
            try
            {
                if (!string.IsNullOrEmpty(tan))
                {
                    if (TANsForXML != null)
                    {
                        if (TANsForXML.Rows.Count > 0)
                        {
                            for (int i = 0; i < TANsForXML.Rows.Count; i++)
                            {
                                if (TANsForXML.Rows[i]["TAN_NAME"].ToString() == tan)
                                {
                                    blStatus = true;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }           
            return blStatus;
        }

        private void ReSetStatusValues()
        {
            try
            {
                lblAvlTANCnt.Text = "0";
                lblSelTANCnt.Text = "0";
                lblCur_Done_Cnt.Text = "0";
                lblRev_Done_Cnt.Text = "0";
                lblQC_Done_Cnt.Text = "0";

                lblAssQC_Cnt.Text = "0";
                lblAssRev_Cnt.Text = "0";
                lblAssCur_Cnt.Text = "0";

                lblReAssQC_Cnt.Text = "0";
                lblReAssRev_Cnt.Text = "0";
                lblReAssCur_Cnt.Text = "0";                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #region Grid Row Post Paint Events

        private void dgTANs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvAvailableTANs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvAvailableTANs.Font);

                if (dgvAvailableTANs.RowHeadersWidth < (int)(size.Width + 20)) dgvAvailableTANs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvSelectedTANs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvSelectedTANs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvSelectedTANs.Font);

                if (dgvSelectedTANs.RowHeadersWidth < (int)(size.Width + 20)) dgvSelectedTANs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvXmlTANs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvXmlTANs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvXmlTANs.Font);

                if (dgvXmlTANs.RowHeadersWidth < (int)(size.Width + 20)) dgvXmlTANs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion        

        private void chkFreezeTANs_CheckStateChanged(object sender, EventArgs e)
        {
            try
            {
                if(FreezeTANs)//chkFreezeTANs.Checked
                {
                    MessageBox.Show("TANs will be freezed once xml is generated", "Batch XML", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private bool ValidateMarkup_ExcessPdfFiles(string markupPdfsPath, DataTable batchTANs, out string errMsgOut)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (!string.IsNullOrEmpty(markupPdfsPath) && batchTANs != null)
                {
                    //Get TANs list from table
                    List<string> lstTANs = batchTANs.Rows.Cast<DataRow>()
                                            .Select(row => row["tan"].ToString())
                                            .ToList();

                    List<string> lstPdfs = GetDistinctTANsFromFolder(markupPdfsPath);

                    if (lstTANs != null && lstPdfs != null)
                    {
                        if (lstTANs.Count > 0 || lstPdfs.Count > 0)
                        {
                            //No Markups pdfs list
                            var noMarkups = lstTANs.Except(lstPdfs);

                            //Excess Markup pdfs list
                            var excessPdfs = lstPdfs.Except(lstTANs);

                            string noMarkup = "";
                            string excessPdf = "";

                            if (noMarkups != null)
                            {
                                if (noMarkups.Count() > 0)
                                {
                                    blStatus = false;

                                    noMarkup = String.Join(", ", noMarkups.ToArray());
                                    strErrMsg = "No markup pdfs available for the below TANs:\r\n" + noMarkup.Trim();
                                }
                            }
                            if (excessPdfs != null)
                            {
                                if (excessPdfs.Count() > 0)
                                {
                                    blStatus = false;

                                    excessPdf = String.Join(", ", excessPdfs.ToArray());
                                    strErrMsg = strErrMsg.Trim() + "\r\n" + "Excess pdfs in the Markups path:\r\n" + excessPdf.Trim();
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsgOut = strErrMsg;
            return blStatus;
        }

        private static List<string> GetDistinctTANsFromFolder(string pdfFolderPath)
        {
            List<string> lstTANs = null;
            try
            {
                if (!string.IsNullOrEmpty(pdfFolderPath))
                {
                    DirectoryInfo dirInfo = new DirectoryInfo(pdfFolderPath);
                    FileInfo[] faFiles = dirInfo.GetFiles("*.pdf", SearchOption.TopDirectoryOnly);
                    if (faFiles != null)
                    {
                        lstTANs = new List<string>();
                        //Filename format is TAN_Markup_N.pdf
                        foreach (FileInfo f in faFiles)
                        {
                            string[] saFileNames = f.Name.Split(new char[] { '_' });
                            if (saFileNames != null)
                            {
                                if (saFileNames.Length > 0)
                                {
                                    if (!string.IsNullOrEmpty(saFileNames[0].Trim().Replace(".pdf", "")))
                                    {
                                        if (!lstTANs.Contains(saFileNames[0].Trim().Replace(".pdf", "")))
                                        {
                                            lstTANs.Add(saFileNames[0].Trim().Replace(".pdf", ""));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstTANs;
        }

        private void btnBrowsePdfFolder_Click(object sender, EventArgs e)
        {
            try
            {
                if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
                {
                    if (!string.IsNullOrEmpty(folderBrowserDialog1.SelectedPath.ToString()))
                    {
                        txtMarkupsPath.Text = folderBrowserDialog1.SelectedPath.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
