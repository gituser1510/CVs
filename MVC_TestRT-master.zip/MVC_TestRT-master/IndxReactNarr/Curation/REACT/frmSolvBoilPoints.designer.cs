﻿namespace IndxReactNarr
{
    partial class frmSolvBoilPoints
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvSolvBPs = new System.Windows.Forms.DataGridView();
            this.colSolvent = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSer9000 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNrnReg = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBP_C = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBP_K = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBP_FH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBP_R = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.lblNote = new System.Windows.Forms.Label();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSolvBPs)).BeginInit();
            this.pnlBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.dgvSolvBPs);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(921, 488);
            this.pnlMain.TabIndex = 1;
            // 
            // dgvSolvBPs
            // 
            this.dgvSolvBPs.AllowUserToAddRows = false;
            this.dgvSolvBPs.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.dgvSolvBPs.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSolvBPs.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvSolvBPs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSolvBPs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSolvent,
            this.colSer9000,
            this.colNrnReg,
            this.colBP_C,
            this.colBP_K,
            this.colBP_FH,
            this.colBP_R});
            this.dgvSolvBPs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSolvBPs.Location = new System.Drawing.Point(0, 0);
            this.dgvSolvBPs.Name = "dgvSolvBPs";
            this.dgvSolvBPs.ReadOnly = true;
            this.dgvSolvBPs.Size = new System.Drawing.Size(921, 460);
            this.dgvSolvBPs.TabIndex = 0;
            this.dgvSolvBPs.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvSolvBPs_RowPostPaint);
            // 
            // colSolvent
            // 
            this.colSolvent.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colSolvent.HeaderText = "Solvent";
            this.colSolvent.Name = "colSolvent";
            this.colSolvent.ReadOnly = true;
            this.colSolvent.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colSer9000
            // 
            this.colSer9000.HeaderText = "Series 9000";
            this.colSer9000.Name = "colSer9000";
            this.colSer9000.ReadOnly = true;
            this.colSer9000.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colNrnReg
            // 
            this.colNrnReg.HeaderText = "NrnReg";
            this.colNrnReg.Name = "colNrnReg";
            this.colNrnReg.ReadOnly = true;
            this.colNrnReg.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colBP_C
            // 
            this.colBP_C.HeaderText = "Degrees (C)";
            this.colBP_C.Name = "colBP_C";
            this.colBP_C.ReadOnly = true;
            this.colBP_C.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colBP_K
            // 
            this.colBP_K.HeaderText = "Kelvins";
            this.colBP_K.Name = "colBP_K";
            this.colBP_K.ReadOnly = true;
            this.colBP_K.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colBP_FH
            // 
            this.colBP_FH.HeaderText = "Fahrenheit";
            this.colBP_FH.Name = "colBP_FH";
            this.colBP_FH.ReadOnly = true;
            this.colBP_FH.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colBP_R
            // 
            this.colBP_R.HeaderText = "Rankine";
            this.colBP_R.Name = "colBP_R";
            this.colBP_R.ReadOnly = true;
            this.colBP_R.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // pnlBottom
            // 
            this.pnlBottom.BackColor = System.Drawing.Color.White;
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlBottom.Controls.Add(this.label1);
            this.pnlBottom.Controls.Add(this.lblNote);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 460);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(921, 28);
            this.pnlBottom.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(48, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(327, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Actual Boiling Points in Degrees are Degrees (C) - 20";
            // 
            // lblNote
            // 
            this.lblNote.AutoSize = true;
            this.lblNote.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNote.ForeColor = System.Drawing.Color.Blue;
            this.lblNote.Location = new System.Drawing.Point(4, 5);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(49, 17);
            this.lblNote.TabIndex = 2;
            this.lblNote.Text = "Note: ";
            // 
            // frmSolvBoilPoints
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(921, 488);
            this.Controls.Add(this.pnlMain);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSolvBoilPoints";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Solvent Boiling Points";
            this.Load += new System.EventHandler(this.frmSolvBoilPoints_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSolvBPs)).EndInit();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.DataGridView dgvSolvBPs;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblNote;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSolvent;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSer9000;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNrnReg;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBP_C;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBP_K;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBP_FH;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBP_R;
    }
}