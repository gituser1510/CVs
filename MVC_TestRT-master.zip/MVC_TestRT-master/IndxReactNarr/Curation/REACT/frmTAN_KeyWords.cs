﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace IndxReactNarr
{
    public partial class frmTAN_KeyWords : Form
    {
        public frmTAN_KeyWords()
        {
            InitializeComponent();
        }

        public string KeyWords
        { get; set; }

        private void frmTAN_KeyWords_Load(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(KeyWords.Trim()))
                {
                    txtKeyWords.Text = KeyWords.Trim().Replace(", ", "\r\n");
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
