﻿namespace IndxReactNarr
{
    partial class frmAminoAcids
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAminoAcids));
            this.pdfCntrl_AminoAcid = new AxAcroPDFLib.AxAcroPDF();
            this.pnlMain = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pdfCntrl_AminoAcid)).BeginInit();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // pdfCntrl_AminoAcid
            // 
            this.pdfCntrl_AminoAcid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pdfCntrl_AminoAcid.Enabled = true;
            this.pdfCntrl_AminoAcid.Location = new System.Drawing.Point(0, 0);
            this.pdfCntrl_AminoAcid.Name = "pdfCntrl_AminoAcid";
            this.pdfCntrl_AminoAcid.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("pdfCntrl_AminoAcid.OcxState")));
            this.pdfCntrl_AminoAcid.Size = new System.Drawing.Size(958, 512);
            this.pdfCntrl_AminoAcid.TabIndex = 1;
            this.pdfCntrl_AminoAcid.UseWaitCursor = true;
            this.pdfCntrl_AminoAcid.Visible = false;
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.pdfCntrl_AminoAcid);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(958, 512);
            this.pnlMain.TabIndex = 2;
            // 
            // frmAminoAcids
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(958, 512);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmAminoAcids";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Amino Acids";
            this.Load += new System.EventHandler(this.frmAminoAcids_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pdfCntrl_AminoAcid)).EndInit();
            this.pnlMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private AxAcroPDFLib.AxAcroPDF pdfCntrl_AminoAcid;
        private System.Windows.Forms.Panel pnlMain;
    }
}