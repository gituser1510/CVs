﻿namespace IndxReactNarr
{
    partial class frmManage8000
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            MDL.Draw.Chemistry.Molecule molecule1 = new MDL.Draw.Chemistry.Molecule();
            MDL.Draw.Renderer.Preferences.DisplayPreferences displayPreferences1 = new MDL.Draw.Renderer.Preferences.DisplayPreferences();
            MDL.Draw.Chemistry.Molecule molecule2 = new MDL.Draw.Chemistry.Molecule();
            MDL.Draw.Renderer.Preferences.DisplayPreferences displayPreferences2 = new MDL.Draw.Renderer.Preferences.DisplayPreferences();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlGrid = new System.Windows.Forms.Panel();
            this.dg8000Series = new System.Windows.Forms.DataGridView();
            this.colTS_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Series8000 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SubstName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAuthorName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOtherName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SubstLoc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SubstStruct = new System.Windows.Forms.DataGridViewImageColumn();
            this.lnkEdit = new System.Windows.Forms.DataGridViewLinkColumn();
            this.Delete = new System.Windows.Forms.DataGridViewLinkColumn();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.txtSeries8000 = new System.Windows.Forms.TextBox();
            this.txtMolFormula = new System.Windows.Forms.TextBox();
            this.btnReset = new System.Windows.Forms.Button();
            this.lblNote = new System.Windows.Forms.Label();
            this.lblOtherName = new System.Windows.Forms.Label();
            this.lblAuthor = new System.Windows.Forms.Label();
            this.txtOtherName = new System.Windows.Forms.TextBox();
            this.txtAuthorName = new System.Windows.Forms.TextBox();
            this.pnlSubstLoc = new System.Windows.Forms.Panel();
            this.lblOther = new System.Windows.Forms.Label();
            this.txtOther = new System.Windows.Forms.TextBox();
            this.txtFootNote = new System.Windows.Forms.TextBox();
            this.lblFNote = new System.Windows.Forms.Label();
            this.txtColumn = new System.Windows.Forms.TextBox();
            this.lblColumn = new System.Windows.Forms.Label();
            this.txtScheme = new System.Windows.Forms.TextBox();
            this.lblScheme = new System.Windows.Forms.Label();
            this.btnSdf = new System.Windows.Forms.Button();
            this.txtTable = new System.Windows.Forms.TextBox();
            this.lblTable = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtSheet = new System.Windows.Forms.TextBox();
            this.lblSheet = new System.Windows.Forms.Label();
            this.btnSubstLoc = new System.Windows.Forms.Button();
            this.txtSubstLoc = new System.Windows.Forms.TextBox();
            this.txtFigure = new System.Windows.Forms.TextBox();
            this.lblPage = new System.Windows.Forms.Label();
            this.lblFigure = new System.Windows.Forms.Label();
            this.txtPage = new System.Windows.Forms.TextBox();
            this.txtPara = new System.Windows.Forms.TextBox();
            this.lblLine = new System.Windows.Forms.Label();
            this.lblPara = new System.Windows.Forms.Label();
            this.txtLine = new System.Windows.Forms.TextBox();
            this.lblStructure = new System.Windows.Forms.Label();
            this.ChemRenditor = new MDL.Draw.Renditor.Renditor();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblSubstLoc = new System.Windows.Forms.Label();
            this.lblSubstName = new System.Windows.Forms.Label();
            this.lblSer8000 = new System.Windows.Forms.Label();
            this.txtSubstName = new System.Windows.Forms.TextBox();
            this.renditor1 = new MDL.Draw.Renditor.Renditor();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewLinkColumn1 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn2 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.pnlMain.SuspendLayout();
            this.pnlGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg8000Series)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.pnlSubstLoc.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.pnlGrid);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(985, 604);
            this.pnlMain.TabIndex = 0;
            // 
            // pnlGrid
            // 
            this.pnlGrid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlGrid.Controls.Add(this.dg8000Series);
            this.pnlGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlGrid.Location = new System.Drawing.Point(0, 357);
            this.pnlGrid.Name = "pnlGrid";
            this.pnlGrid.Size = new System.Drawing.Size(985, 247);
            this.pnlGrid.TabIndex = 2;
            // 
            // dg8000Series
            // 
            this.dg8000Series.AllowUserToAddRows = false;
            this.dg8000Series.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dg8000Series.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dg8000Series.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dg8000Series.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg8000Series.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTS_ID,
            this.Series8000,
            this.SubstName,
            this.colAuthorName,
            this.colOtherName,
            this.SubstLoc,
            this.SubstStruct,
            this.lnkEdit,
            this.Delete});
            this.dg8000Series.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dg8000Series.Location = new System.Drawing.Point(0, 0);
            this.dg8000Series.Name = "dg8000Series";
            this.dg8000Series.ReadOnly = true;
            this.dg8000Series.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.dg8000Series.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dg8000Series.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg8000Series.Size = new System.Drawing.Size(981, 243);
            this.dg8000Series.TabIndex = 0;
            this.dg8000Series.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg8000Series_CellContentClick);
            this.dg8000Series.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dg8000Series_RowPostPaint);
            // 
            // colTS_ID
            // 
            this.colTS_ID.HeaderText = "TS_ID";
            this.colTS_ID.Name = "colTS_ID";
            this.colTS_ID.ReadOnly = true;
            this.colTS_ID.Visible = false;
            // 
            // Series8000
            // 
            this.Series8000.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Series8000.HeaderText = "Series8000";
            this.Series8000.Name = "Series8000";
            this.Series8000.ReadOnly = true;
            this.Series8000.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Series8000.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Series8000.Width = 80;
            // 
            // SubstName
            // 
            this.SubstName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SubstName.HeaderText = "Substance Name";
            this.SubstName.Name = "SubstName";
            this.SubstName.ReadOnly = true;
            this.SubstName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colAuthorName
            // 
            this.colAuthorName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colAuthorName.HeaderText = "Compound No";
            this.colAuthorName.Name = "colAuthorName";
            this.colAuthorName.ReadOnly = true;
            this.colAuthorName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colOtherName
            // 
            this.colOtherName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colOtherName.HeaderText = "Generic Name";
            this.colOtherName.Name = "colOtherName";
            this.colOtherName.ReadOnly = true;
            this.colOtherName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // SubstLoc
            // 
            this.SubstLoc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SubstLoc.HeaderText = "Substance Location";
            this.SubstLoc.Name = "SubstLoc";
            this.SubstLoc.ReadOnly = true;
            // 
            // SubstStruct
            // 
            this.SubstStruct.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.SubstStruct.HeaderText = "Structure";
            this.SubstStruct.Name = "SubstStruct";
            this.SubstStruct.ReadOnly = true;
            this.SubstStruct.Width = 50;
            // 
            // lnkEdit
            // 
            this.lnkEdit.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.lnkEdit.HeaderText = "Edit";
            this.lnkEdit.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lnkEdit.Name = "lnkEdit";
            this.lnkEdit.ReadOnly = true;
            this.lnkEdit.Text = "Edit";
            this.lnkEdit.TrackVisitedState = false;
            this.lnkEdit.UseColumnTextForLinkValue = true;
            this.lnkEdit.Width = 60;
            // 
            // Delete
            // 
            this.Delete.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Delete.HeaderText = "Delete";
            this.Delete.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Delete.Name = "Delete";
            this.Delete.ReadOnly = true;
            this.Delete.Text = "Delete";
            this.Delete.UseColumnTextForLinkValue = true;
            this.Delete.Width = 60;
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.txtSeries8000);
            this.pnlTop.Controls.Add(this.txtMolFormula);
            this.pnlTop.Controls.Add(this.btnReset);
            this.pnlTop.Controls.Add(this.lblNote);
            this.pnlTop.Controls.Add(this.lblOtherName);
            this.pnlTop.Controls.Add(this.lblAuthor);
            this.pnlTop.Controls.Add(this.txtOtherName);
            this.pnlTop.Controls.Add(this.txtAuthorName);
            this.pnlTop.Controls.Add(this.pnlSubstLoc);
            this.pnlTop.Controls.Add(this.lblStructure);
            this.pnlTop.Controls.Add(this.ChemRenditor);
            this.pnlTop.Controls.Add(this.btnAdd);
            this.pnlTop.Controls.Add(this.lblSubstLoc);
            this.pnlTop.Controls.Add(this.lblSubstName);
            this.pnlTop.Controls.Add(this.lblSer8000);
            this.pnlTop.Controls.Add(this.txtSubstName);
            this.pnlTop.Controls.Add(this.renditor1);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(985, 357);
            this.pnlTop.TabIndex = 3;
            // 
            // txtSeries8000
            // 
            this.txtSeries8000.Location = new System.Drawing.Point(722, 325);
            this.txtSeries8000.Name = "txtSeries8000";
            this.txtSeries8000.ReadOnly = true;
            this.txtSeries8000.Size = new System.Drawing.Size(100, 25);
            this.txtSeries8000.TabIndex = 58;
            // 
            // txtMolFormula
            // 
            this.txtMolFormula.BackColor = System.Drawing.Color.White;
            this.txtMolFormula.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMolFormula.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMolFormula.ForeColor = System.Drawing.Color.Red;
            this.txtMolFormula.Location = new System.Drawing.Point(71, 116);
            this.txtMolFormula.Name = "txtMolFormula";
            this.txtMolFormula.ReadOnly = true;
            this.txtMolFormula.Size = new System.Drawing.Size(316, 18);
            this.txtMolFormula.TabIndex = 57;
            // 
            // btnReset
            // 
            this.btnReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReset.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(926, 322);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(54, 29);
            this.btnReset.TabIndex = 55;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // lblNote
            // 
            this.lblNote.AutoSize = true;
            this.lblNote.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNote.ForeColor = System.Drawing.Color.Blue;
            this.lblNote.Location = new System.Drawing.Point(275, 0);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(502, 16);
            this.lblNote.TabIndex = 54;
            this.lblNote.Text = "Note: Multiple Substance / Author / Other Names should be seperated by comma ( , " +
    ")";
            // 
            // lblOtherName
            // 
            this.lblOtherName.AutoSize = true;
            this.lblOtherName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOtherName.Location = new System.Drawing.Point(474, 58);
            this.lblOtherName.Name = "lblOtherName";
            this.lblOtherName.Size = new System.Drawing.Size(91, 16);
            this.lblOtherName.TabIndex = 53;
            this.lblOtherName.Text = "Generic Name";
            // 
            // lblAuthor
            // 
            this.lblAuthor.AutoSize = true;
            this.lblAuthor.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAuthor.Location = new System.Drawing.Point(0, 58);
            this.lblAuthor.Name = "lblAuthor";
            this.lblAuthor.Size = new System.Drawing.Size(160, 16);
            this.lblAuthor.TabIndex = 52;
            this.lblAuthor.Text = "Compound No./Author No.";
            // 
            // txtOtherName
            // 
            this.txtOtherName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOtherName.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOtherName.Location = new System.Drawing.Point(477, 77);
            this.txtOtherName.Multiline = true;
            this.txtOtherName.Name = "txtOtherName";
            this.txtOtherName.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtOtherName.Size = new System.Drawing.Size(503, 36);
            this.txtOtherName.TabIndex = 51;
            this.txtOtherName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtOtherName_KeyDown);
            // 
            // txtAuthorName
            // 
            this.txtAuthorName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAuthorName.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAuthorName.Location = new System.Drawing.Point(3, 77);
            this.txtAuthorName.Multiline = true;
            this.txtAuthorName.Name = "txtAuthorName";
            this.txtAuthorName.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtAuthorName.Size = new System.Drawing.Size(468, 36);
            this.txtAuthorName.TabIndex = 50;
            this.txtAuthorName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtAuthorName_KeyDown);
            // 
            // pnlSubstLoc
            // 
            this.pnlSubstLoc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlSubstLoc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSubstLoc.Controls.Add(this.lblOther);
            this.pnlSubstLoc.Controls.Add(this.txtOther);
            this.pnlSubstLoc.Controls.Add(this.txtFootNote);
            this.pnlSubstLoc.Controls.Add(this.lblFNote);
            this.pnlSubstLoc.Controls.Add(this.txtColumn);
            this.pnlSubstLoc.Controls.Add(this.lblColumn);
            this.pnlSubstLoc.Controls.Add(this.txtScheme);
            this.pnlSubstLoc.Controls.Add(this.lblScheme);
            this.pnlSubstLoc.Controls.Add(this.btnSdf);
            this.pnlSubstLoc.Controls.Add(this.txtTable);
            this.pnlSubstLoc.Controls.Add(this.lblTable);
            this.pnlSubstLoc.Controls.Add(this.btnClear);
            this.pnlSubstLoc.Controls.Add(this.txtSheet);
            this.pnlSubstLoc.Controls.Add(this.lblSheet);
            this.pnlSubstLoc.Controls.Add(this.btnSubstLoc);
            this.pnlSubstLoc.Controls.Add(this.txtSubstLoc);
            this.pnlSubstLoc.Controls.Add(this.txtFigure);
            this.pnlSubstLoc.Controls.Add(this.lblPage);
            this.pnlSubstLoc.Controls.Add(this.lblFigure);
            this.pnlSubstLoc.Controls.Add(this.txtPage);
            this.pnlSubstLoc.Controls.Add(this.txtPara);
            this.pnlSubstLoc.Controls.Add(this.lblLine);
            this.pnlSubstLoc.Controls.Add(this.lblPara);
            this.pnlSubstLoc.Controls.Add(this.txtLine);
            this.pnlSubstLoc.Location = new System.Drawing.Point(393, 136);
            this.pnlSubstLoc.Name = "pnlSubstLoc";
            this.pnlSubstLoc.Size = new System.Drawing.Size(589, 184);
            this.pnlSubstLoc.TabIndex = 49;
            // 
            // lblOther
            // 
            this.lblOther.AutoSize = true;
            this.lblOther.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOther.Location = new System.Drawing.Point(23, 58);
            this.lblOther.Name = "lblOther";
            this.lblOther.Size = new System.Drawing.Size(40, 16);
            this.lblOther.TabIndex = 62;
            this.lblOther.Text = "Other";
            // 
            // txtOther
            // 
            this.txtOther.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOther.ForeColor = System.Drawing.Color.Blue;
            this.txtOther.Location = new System.Drawing.Point(68, 53);
            this.txtOther.Multiline = true;
            this.txtOther.Name = "txtOther";
            this.txtOther.Size = new System.Drawing.Size(459, 27);
            this.txtOther.TabIndex = 61;
            // 
            // txtFootNote
            // 
            this.txtFootNote.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFootNote.ForeColor = System.Drawing.Color.Blue;
            this.txtFootNote.Location = new System.Drawing.Point(524, 22);
            this.txtFootNote.Multiline = true;
            this.txtFootNote.Name = "txtFootNote";
            this.txtFootNote.Size = new System.Drawing.Size(62, 27);
            this.txtFootNote.TabIndex = 59;
            // 
            // lblFNote
            // 
            this.lblFNote.AutoSize = true;
            this.lblFNote.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFNote.Location = new System.Drawing.Point(519, 2);
            this.lblFNote.Name = "lblFNote";
            this.lblFNote.Size = new System.Drawing.Size(59, 16);
            this.lblFNote.TabIndex = 60;
            this.lblFNote.Text = "Footnote";
            // 
            // txtColumn
            // 
            this.txtColumn.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtColumn.ForeColor = System.Drawing.Color.Blue;
            this.txtColumn.Location = new System.Drawing.Point(199, 22);
            this.txtColumn.Multiline = true;
            this.txtColumn.Name = "txtColumn";
            this.txtColumn.Size = new System.Drawing.Size(62, 27);
            this.txtColumn.TabIndex = 57;
            // 
            // lblColumn
            // 
            this.lblColumn.AutoSize = true;
            this.lblColumn.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColumn.Location = new System.Drawing.Point(195, 3);
            this.lblColumn.Name = "lblColumn";
            this.lblColumn.Size = new System.Drawing.Size(52, 16);
            this.lblColumn.TabIndex = 58;
            this.lblColumn.Text = "Column";
            // 
            // txtScheme
            // 
            this.txtScheme.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtScheme.ForeColor = System.Drawing.Color.Blue;
            this.txtScheme.Location = new System.Drawing.Point(394, 22);
            this.txtScheme.Multiline = true;
            this.txtScheme.Name = "txtScheme";
            this.txtScheme.Size = new System.Drawing.Size(62, 27);
            this.txtScheme.TabIndex = 55;
            // 
            // lblScheme
            // 
            this.lblScheme.AutoSize = true;
            this.lblScheme.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScheme.Location = new System.Drawing.Point(391, 2);
            this.lblScheme.Name = "lblScheme";
            this.lblScheme.Size = new System.Drawing.Size(56, 16);
            this.lblScheme.TabIndex = 56;
            this.lblScheme.Text = "Scheme";
            // 
            // btnSdf
            // 
            this.btnSdf.Location = new System.Drawing.Point(547, 58);
            this.btnSdf.Name = "btnSdf";
            this.btnSdf.Size = new System.Drawing.Size(30, 23);
            this.btnSdf.TabIndex = 54;
            this.btnSdf.Text = "sdf";
            this.btnSdf.UseVisualStyleBackColor = true;
            this.btnSdf.Visible = false;
            this.btnSdf.Click += new System.EventHandler(this.btnSdf_Click);
            // 
            // txtTable
            // 
            this.txtTable.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTable.ForeColor = System.Drawing.Color.Blue;
            this.txtTable.Location = new System.Drawing.Point(264, 22);
            this.txtTable.Multiline = true;
            this.txtTable.Name = "txtTable";
            this.txtTable.Size = new System.Drawing.Size(62, 27);
            this.txtTable.TabIndex = 52;
            // 
            // lblTable
            // 
            this.lblTable.AutoSize = true;
            this.lblTable.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTable.Location = new System.Drawing.Point(261, 3);
            this.lblTable.Name = "lblTable";
            this.lblTable.Size = new System.Drawing.Size(38, 16);
            this.lblTable.TabIndex = 53;
            this.lblTable.Text = "Table";
            // 
            // btnClear
            // 
            this.btnClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClear.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(532, 139);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(54, 27);
            this.btnClear.TabIndex = 51;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // txtSheet
            // 
            this.txtSheet.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSheet.ForeColor = System.Drawing.Color.Blue;
            this.txtSheet.Location = new System.Drawing.Point(459, 22);
            this.txtSheet.Multiline = true;
            this.txtSheet.Name = "txtSheet";
            this.txtSheet.Size = new System.Drawing.Size(62, 27);
            this.txtSheet.TabIndex = 5;
            // 
            // lblSheet
            // 
            this.lblSheet.AutoSize = true;
            this.lblSheet.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSheet.Location = new System.Drawing.Point(458, 2);
            this.lblSheet.Name = "lblSheet";
            this.lblSheet.Size = new System.Drawing.Size(42, 16);
            this.lblSheet.TabIndex = 50;
            this.lblSheet.Text = "Sheet";
            // 
            // btnSubstLoc
            // 
            this.btnSubstLoc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSubstLoc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSubstLoc.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubstLoc.Location = new System.Drawing.Point(532, 91);
            this.btnSubstLoc.Name = "btnSubstLoc";
            this.btnSubstLoc.Size = new System.Drawing.Size(54, 27);
            this.btnSubstLoc.TabIndex = 6;
            this.btnSubstLoc.Text = "Add";
            this.btnSubstLoc.UseVisualStyleBackColor = true;
            this.btnSubstLoc.Click += new System.EventHandler(this.btnSubstLoc_Click);
            // 
            // txtSubstLoc
            // 
            this.txtSubstLoc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSubstLoc.BackColor = System.Drawing.Color.White;
            this.txtSubstLoc.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSubstLoc.Location = new System.Drawing.Point(3, 83);
            this.txtSubstLoc.Multiline = true;
            this.txtSubstLoc.Name = "txtSubstLoc";
            this.txtSubstLoc.ReadOnly = true;
            this.txtSubstLoc.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtSubstLoc.Size = new System.Drawing.Size(524, 94);
            this.txtSubstLoc.TabIndex = 4;
            // 
            // txtFigure
            // 
            this.txtFigure.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFigure.ForeColor = System.Drawing.Color.Blue;
            this.txtFigure.Location = new System.Drawing.Point(329, 22);
            this.txtFigure.Multiline = true;
            this.txtFigure.Name = "txtFigure";
            this.txtFigure.Size = new System.Drawing.Size(62, 27);
            this.txtFigure.TabIndex = 4;
            // 
            // lblPage
            // 
            this.lblPage.AutoSize = true;
            this.lblPage.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPage.Location = new System.Drawing.Point(0, 3);
            this.lblPage.Name = "lblPage";
            this.lblPage.Size = new System.Drawing.Size(38, 16);
            this.lblPage.TabIndex = 41;
            this.lblPage.Text = "Page";
            // 
            // lblFigure
            // 
            this.lblFigure.AutoSize = true;
            this.lblFigure.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFigure.Location = new System.Drawing.Point(326, 2);
            this.lblFigure.Name = "lblFigure";
            this.lblFigure.Size = new System.Drawing.Size(44, 16);
            this.lblFigure.TabIndex = 47;
            this.lblFigure.Text = "Figure";
            // 
            // txtPage
            // 
            this.txtPage.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPage.ForeColor = System.Drawing.Color.Blue;
            this.txtPage.Location = new System.Drawing.Point(3, 22);
            this.txtPage.Multiline = true;
            this.txtPage.Name = "txtPage";
            this.txtPage.Size = new System.Drawing.Size(62, 27);
            this.txtPage.TabIndex = 1;
            // 
            // txtPara
            // 
            this.txtPara.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPara.ForeColor = System.Drawing.Color.Blue;
            this.txtPara.Location = new System.Drawing.Point(134, 22);
            this.txtPara.Multiline = true;
            this.txtPara.Name = "txtPara";
            this.txtPara.Size = new System.Drawing.Size(62, 27);
            this.txtPara.TabIndex = 3;
            // 
            // lblLine
            // 
            this.lblLine.AutoSize = true;
            this.lblLine.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLine.Location = new System.Drawing.Point(65, 3);
            this.lblLine.Name = "lblLine";
            this.lblLine.Size = new System.Drawing.Size(32, 16);
            this.lblLine.TabIndex = 43;
            this.lblLine.Text = "Line";
            // 
            // lblPara
            // 
            this.lblPara.AutoSize = true;
            this.lblPara.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPara.Location = new System.Drawing.Point(130, 3);
            this.lblPara.Name = "lblPara";
            this.lblPara.Size = new System.Drawing.Size(35, 16);
            this.lblPara.TabIndex = 45;
            this.lblPara.Text = "Para";
            // 
            // txtLine
            // 
            this.txtLine.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLine.ForeColor = System.Drawing.Color.Blue;
            this.txtLine.Location = new System.Drawing.Point(68, 22);
            this.txtLine.Multiline = true;
            this.txtLine.Name = "txtLine";
            this.txtLine.Size = new System.Drawing.Size(62, 27);
            this.txtLine.TabIndex = 2;
            // 
            // lblStructure
            // 
            this.lblStructure.AutoSize = true;
            this.lblStructure.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStructure.Location = new System.Drawing.Point(2, 116);
            this.lblStructure.Name = "lblStructure";
            this.lblStructure.Size = new System.Drawing.Size(61, 16);
            this.lblStructure.TabIndex = 40;
            this.lblStructure.Text = "Structure";
            // 
            // ChemRenditor
            // 
            this.ChemRenditor.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.ChemRenditor.AutoSizeStructure = true;
            this.ChemRenditor.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.ChemRenditor.BinHexSketch = "01030004412400214372656174656420627920416363656C7279734472617720342E322E302E36303" +
    "502040000005805000000005905000000000B0B0005417269616C780000140200";
            this.ChemRenditor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ChemRenditor.ChimeString = null;
            this.ChemRenditor.ClearingEnabled = true;
            this.ChemRenditor.CopyingEnabled = true;
            this.ChemRenditor.DisplayOnEmpty = "No Structure";
            this.ChemRenditor.EditingEnabled = true;
            this.ChemRenditor.FileName = null;
            this.ChemRenditor.HighlightInfo = "";
            this.ChemRenditor.IsBitmapFromOLE = true;
            this.ChemRenditor.Location = new System.Drawing.Point(3, 136);
            molecule1.ArrowDir = MDL.Draw.ArrowDirType.No;
            molecule1.ArrowStyle = MDL.Draw.ArrowStyleType.Empty;
            molecule1.AtomValenceDisplay = true;
            molecule1.BaseFormBoxSetting = 0;
            molecule1.BondLineThickness = 0D;
            molecule1.CarbonLabelDisplay = false;
            molecule1.ChemLabelFont = null;
            molecule1.ChemLabelFontString = "(none)";
            molecule1.ColorAtomsByTypeInSketch = false;
            molecule1.ConfigLabelFont = null;
            molecule1.ConfigLabelFontString = "(none)";
            molecule1.ConvertRingBondIntoOneToMany = true;
            molecule1.Coords = null;
            molecule1.DashSpacing = 0.1D;
            molecule1.DisplaySinCys = false;
            molecule1.DisplaySulfurInCysSequence = false;
            molecule1.DoubleBondWidth = 0.18D;
            molecule1.FillColor = System.Drawing.Color.Empty;
            molecule1.FillStyle = MDL.Draw.ChemGraphicsObject.FillStyles.SOLID;
            molecule1.ForeColor = System.Drawing.Color.Empty;
            molecule1.ForeColorString = "";
            molecule1.ForSubsequenceQuery = false;
            molecule1.HighlightChildren = "";
            molecule1.HighlightColor = System.Drawing.Color.Blue;
            molecule1.HydrogenDisplayMode = MDL.Draw.Chemistry.Atom.HydrogenDisplayMode.Off;
            molecule1.Id = 55;
            molecule1.Initial = "";
            molecule1.IsAModel = false;
            molecule1.IsARotatedModel = false;
            molecule1.KeepRSLabelsInSketch = true;
            molecule1.LastModifyChemText = -1;
            molecule1.MaintainXMLChildOrderFlag = false;
            molecule1.MustPerceiveStereo = true;
            molecule1.PenColor = System.Drawing.Color.Empty;
            molecule1.PenStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            molecule1.PenStyleToken = 0;
            molecule1.PenWidth = ((byte)(0));
            molecule1.PenWidthUnit = MDL.Draw.ChemGraphicsObject.PenWidthUnits.Default;
            molecule1.RefId = 55;
            molecule1.Replaced = false;
            molecule1.RgroupCleeanUpNeeded = false;
            molecule1.RgroupLabelsPresentFlag = false;
            molecule1.RLabelAtAbsCenter = "R";
            molecule1.RLabelAtAndCenter = "R*";
            molecule1.RLabelAtOrCenter = "(R)";
            molecule1.ScaleLabelsToBondLength = false;
            molecule1.Selected = false;
            molecule1.SequenceDictionary = null;
            molecule1.SequenceNeedsRealign = false;
            molecule1.SequenceView = MDL.Draw.Chemistry.Molecule.SequenceViewEnum.None;
            molecule1.Size = 0;
            molecule1.SkcWritten = false;
            molecule1.SkNumber = ((short)(0));
            molecule1.SLabelAtAbsCenter = "S";
            molecule1.SLabelAtAndCenter = "S*";
            molecule1.SLabelAtOrCenter = "(S)";
            molecule1.StandardBondLength = 0D;
            molecule1.StereoChemistryMode = MDL.Draw.Chemistry.Molecule.StereoChemistryModeEnum.And;
            molecule1.TextBorder = 0.1D;
            molecule1.Transparent = false;
            molecule1.UndoableEditListener = null;
            molecule1.WedgeWidth = 0.1D;
            molecule1.ZLayer = -99946;
            this.ChemRenditor.Molecule = molecule1;
            this.ChemRenditor.MolfileString = "";
            this.ChemRenditor.Name = "ChemRenditor";
            this.ChemRenditor.OldScalingMode = MDL.Draw.Renderer.Preferences.StructureScalingMode.ScaleToFitBox;
            this.ChemRenditor.PastingEnabled = true;
            displayPreferences1.AtomAtomDisplayMode = MDL.Draw.Renderer.Preferences.AtomAtomMappingDisplayMode.On;
            this.ChemRenditor.Preferences = displayPreferences1;
            this.ChemRenditor.PreferencesFileName = "default.xml";
            this.ChemRenditor.RendererBorderStyle = System.Windows.Forms.ButtonBorderStyle.Inset;
            this.ChemRenditor.RenditorMolecule = molecule1;
            this.ChemRenditor.RenditorName = "Demo Renditor";
            this.ChemRenditor.Size = new System.Drawing.Size(384, 216);
            this.ChemRenditor.SketchString = "AQMABEEkACFDcmVhdGVkIGJ5IEFjY2VscnlzRHJhdyA0LjIuMC42MDUCBAAAAFgFAAAAAFkFAAAAAAsLA" +
    "AVBcmlhbHgAABQCAA==";
            this.ChemRenditor.SmilesString = "";
            this.ChemRenditor.TabIndex = 7;
            this.ChemRenditor.URLEncodedMolfileString = "";
            this.ChemRenditor.UseLocalXMLConfig = false;
            this.ChemRenditor.ComStructureChanged += new MDL.Draw.Renditor.StructureChangedEventHandler(this.ChemRenditor_ComStructureChanged);
            // 
            // btnAdd
            // 
            this.btnAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(844, 322);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 30);
            this.btnAdd.TabIndex = 9;
            this.btnAdd.Text = "Save";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lblSubstLoc
            // 
            this.lblSubstLoc.AutoSize = true;
            this.lblSubstLoc.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubstLoc.Location = new System.Drawing.Point(393, 116);
            this.lblSubstLoc.Name = "lblSubstLoc";
            this.lblSubstLoc.Size = new System.Drawing.Size(123, 16);
            this.lblSubstLoc.TabIndex = 7;
            this.lblSubstLoc.Text = "Substance Location";
            // 
            // lblSubstName
            // 
            this.lblSubstName.AutoSize = true;
            this.lblSubstName.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblSubstName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubstName.Location = new System.Drawing.Point(0, 0);
            this.lblSubstName.Name = "lblSubstName";
            this.lblSubstName.Size = new System.Drawing.Size(196, 16);
            this.lblSubstName.TabIndex = 6;
            this.lblSubstName.Text = "Substance Name / IUPAC Name";
            // 
            // lblSer8000
            // 
            this.lblSer8000.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSer8000.AutoSize = true;
            this.lblSer8000.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSer8000.Location = new System.Drawing.Point(638, 330);
            this.lblSer8000.Name = "lblSer8000";
            this.lblSer8000.Size = new System.Drawing.Size(77, 16);
            this.lblSer8000.TabIndex = 5;
            this.lblSer8000.Text = "Series 8000";
            this.lblSer8000.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtSubstName
            // 
            this.txtSubstName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSubstName.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSubstName.Location = new System.Drawing.Point(3, 19);
            this.txtSubstName.Multiline = true;
            this.txtSubstName.Name = "txtSubstName";
            this.txtSubstName.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtSubstName.Size = new System.Drawing.Size(977, 36);
            this.txtSubstName.TabIndex = 0;
            this.txtSubstName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSubstName_KeyDown);
            // 
            // renditor1
            // 
            this.renditor1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.renditor1.AutoSizeStructure = true;
            this.renditor1.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.renditor1.BinHexSketch = "01030004412400214372656174656420627920416363656C7279734472617720342E322E302E36303" +
    "502040000005805000000005905000000000B0B0005417269616C780000140200";
            this.renditor1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.renditor1.ChimeString = null;
            this.renditor1.ClearingEnabled = true;
            this.renditor1.CopyingEnabled = true;
            this.renditor1.DisplayOnEmpty = null;
            this.renditor1.EditingEnabled = true;
            this.renditor1.FileName = null;
            this.renditor1.HighlightInfo = "";
            this.renditor1.IsBitmapFromOLE = true;
            this.renditor1.Location = new System.Drawing.Point(298, 196);
            molecule2.ArrowDir = MDL.Draw.ArrowDirType.No;
            molecule2.ArrowStyle = MDL.Draw.ArrowStyleType.Empty;
            molecule2.AtomValenceDisplay = true;
            molecule2.BaseFormBoxSetting = 0;
            molecule2.BondLineThickness = 0D;
            molecule2.CarbonLabelDisplay = false;
            molecule2.ChemLabelFont = null;
            molecule2.ChemLabelFontString = "(none)";
            molecule2.ColorAtomsByTypeInSketch = false;
            molecule2.ConfigLabelFont = null;
            molecule2.ConfigLabelFontString = "(none)";
            molecule2.ConvertRingBondIntoOneToMany = true;
            molecule2.Coords = null;
            molecule2.DashSpacing = 0.1D;
            molecule2.DisplaySinCys = false;
            molecule2.DisplaySulfurInCysSequence = false;
            molecule2.DoubleBondWidth = 0.18D;
            molecule2.FillColor = System.Drawing.Color.Empty;
            molecule2.FillStyle = MDL.Draw.ChemGraphicsObject.FillStyles.SOLID;
            molecule2.ForeColor = System.Drawing.Color.Empty;
            molecule2.ForeColorString = "";
            molecule2.ForSubsequenceQuery = false;
            molecule2.HighlightChildren = "";
            molecule2.HighlightColor = System.Drawing.Color.Blue;
            molecule2.HydrogenDisplayMode = MDL.Draw.Chemistry.Atom.HydrogenDisplayMode.Off;
            molecule2.Id = 79;
            molecule2.Initial = "";
            molecule2.IsAModel = false;
            molecule2.IsARotatedModel = false;
            molecule2.KeepRSLabelsInSketch = true;
            molecule2.LastModifyChemText = -1;
            molecule2.MaintainXMLChildOrderFlag = false;
            molecule2.MustPerceiveStereo = true;
            molecule2.PenColor = System.Drawing.Color.Empty;
            molecule2.PenStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            molecule2.PenStyleToken = 0;
            molecule2.PenWidth = ((byte)(0));
            molecule2.PenWidthUnit = MDL.Draw.ChemGraphicsObject.PenWidthUnits.Default;
            molecule2.RefId = 79;
            molecule2.Replaced = false;
            molecule2.RgroupCleeanUpNeeded = false;
            molecule2.RgroupLabelsPresentFlag = false;
            molecule2.RLabelAtAbsCenter = "R";
            molecule2.RLabelAtAndCenter = "R*";
            molecule2.RLabelAtOrCenter = "(R)";
            molecule2.ScaleLabelsToBondLength = false;
            molecule2.Selected = false;
            molecule2.SequenceDictionary = null;
            molecule2.SequenceNeedsRealign = false;
            molecule2.SequenceView = MDL.Draw.Chemistry.Molecule.SequenceViewEnum.None;
            molecule2.Size = 0;
            molecule2.SkcWritten = false;
            molecule2.SkNumber = ((short)(0));
            molecule2.SLabelAtAbsCenter = "S";
            molecule2.SLabelAtAndCenter = "S*";
            molecule2.SLabelAtOrCenter = "(S)";
            molecule2.StandardBondLength = 0D;
            molecule2.StereoChemistryMode = MDL.Draw.Chemistry.Molecule.StereoChemistryModeEnum.And;
            molecule2.TextBorder = 0.1D;
            molecule2.Transparent = false;
            molecule2.UndoableEditListener = null;
            molecule2.WedgeWidth = 0.1D;
            molecule2.ZLayer = -99922;
            this.renditor1.Molecule = molecule2;
            this.renditor1.MolfileString = "";
            this.renditor1.Name = "renditor1";
            this.renditor1.OldScalingMode = MDL.Draw.Renderer.Preferences.StructureScalingMode.ScaleToFitBox;
            this.renditor1.PastingEnabled = true;
            displayPreferences2.AtomAtomDisplayMode = MDL.Draw.Renderer.Preferences.AtomAtomMappingDisplayMode.On;
            this.renditor1.Preferences = displayPreferences2;
            this.renditor1.PreferencesFileName = "default.xml";
            this.renditor1.RendererBorderStyle = System.Windows.Forms.ButtonBorderStyle.Inset;
            this.renditor1.RenditorMolecule = molecule2;
            this.renditor1.RenditorName = "Demo Renditor";
            this.renditor1.Size = new System.Drawing.Size(36, 32);
            this.renditor1.SketchString = "AQMABEEkACFDcmVhdGVkIGJ5IEFjY2VscnlzRHJhdyA0LjIuMC42MDUCBAAAAFgFAAAAAFkFAAAAAAsLA" +
    "AVBcmlhbHgAABQCAA==";
            this.renditor1.SmilesString = "";
            this.renditor1.TabIndex = 40;
            this.renditor1.URLEncodedMolfileString = "";
            this.renditor1.UseLocalXMLConfig = false;
            this.renditor1.Visible = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn1.HeaderText = "Series8000";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Width = 80;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.HeaderText = "Substance Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn3.HeaderText = "Compound No";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn4.HeaderText = "Generic Name";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn5.HeaderText = "Substance Location";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewImageColumn1.HeaderText = "Structure";
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            this.dataGridViewImageColumn1.ReadOnly = true;
            this.dataGridViewImageColumn1.Width = 50;
            // 
            // dataGridViewLinkColumn1
            // 
            this.dataGridViewLinkColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewLinkColumn1.HeaderText = "Edit";
            this.dataGridViewLinkColumn1.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.dataGridViewLinkColumn1.Name = "dataGridViewLinkColumn1";
            this.dataGridViewLinkColumn1.ReadOnly = true;
            this.dataGridViewLinkColumn1.Text = "Edit";
            this.dataGridViewLinkColumn1.TrackVisitedState = false;
            this.dataGridViewLinkColumn1.UseColumnTextForLinkValue = true;
            this.dataGridViewLinkColumn1.Width = 60;
            // 
            // dataGridViewLinkColumn2
            // 
            this.dataGridViewLinkColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewLinkColumn2.HeaderText = "Delete";
            this.dataGridViewLinkColumn2.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.dataGridViewLinkColumn2.Name = "dataGridViewLinkColumn2";
            this.dataGridViewLinkColumn2.ReadOnly = true;
            this.dataGridViewLinkColumn2.Text = "Delete";
            this.dataGridViewLinkColumn2.UseColumnTextForLinkValue = true;
            this.dataGridViewLinkColumn2.Width = 60;
            // 
            // frmManage8000
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(985, 604);
            this.Controls.Add(this.pnlMain);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmManage8000";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Manage 8000 series";
            this.Load += new System.EventHandler(this.frmManage8000_Load);
            this.pnlMain.ResumeLayout(false);
            this.pnlGrid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dg8000Series)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlSubstLoc.ResumeLayout(false);
            this.pnlSubstLoc.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlGrid;
        private System.Windows.Forms.DataGridView dg8000Series;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Label lblSubstLoc;
        private System.Windows.Forms.Label lblSubstName;
        private System.Windows.Forms.Label lblSer8000;
        private System.Windows.Forms.TextBox txtSubstLoc;
        private System.Windows.Forms.TextBox txtSubstName;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label lblStructure;
        private MDL.Draw.Renditor.Renditor ChemRenditor;
        private MDL.Draw.Renditor.Renditor renditor1;
        private System.Windows.Forms.Panel pnlSubstLoc;
        private System.Windows.Forms.TextBox txtFigure;
        private System.Windows.Forms.Label lblPage;
        private System.Windows.Forms.Label lblFigure;
        private System.Windows.Forms.TextBox txtPage;
        private System.Windows.Forms.TextBox txtPara;
        private System.Windows.Forms.Label lblLine;
        private System.Windows.Forms.Label lblPara;
        private System.Windows.Forms.TextBox txtLine;
        private System.Windows.Forms.Button btnSubstLoc;
        private System.Windows.Forms.TextBox txtSheet;
        private System.Windows.Forms.Label lblSheet;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblTable;
        private System.Windows.Forms.Button btnSdf;
        private System.Windows.Forms.TextBox txtScheme;
        private System.Windows.Forms.Label lblScheme;
        private System.Windows.Forms.TextBox txtFootNote;
        private System.Windows.Forms.Label lblFNote;
        private System.Windows.Forms.TextBox txtColumn;
        private System.Windows.Forms.Label lblColumn;
        private System.Windows.Forms.TextBox txtTable;
        private System.Windows.Forms.Label lblOtherName;
        private System.Windows.Forms.Label lblAuthor;
        private System.Windows.Forms.TextBox txtOtherName;
        private System.Windows.Forms.TextBox txtAuthorName;
        private System.Windows.Forms.Label lblOther;
        private System.Windows.Forms.TextBox txtOther;
        private System.Windows.Forms.Label lblNote;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.TextBox txtSeries8000;
        private System.Windows.Forms.TextBox txtMolFormula;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTS_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Series8000;
        private System.Windows.Forms.DataGridViewTextBoxColumn SubstName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAuthorName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOtherName;
        private System.Windows.Forms.DataGridViewTextBoxColumn SubstLoc;
        private System.Windows.Forms.DataGridViewImageColumn SubstStruct;
        private System.Windows.Forms.DataGridViewLinkColumn lnkEdit;
        private System.Windows.Forms.DataGridViewLinkColumn Delete;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.DataGridViewLinkColumn dataGridViewLinkColumn1;
        private System.Windows.Forms.DataGridViewLinkColumn dataGridViewLinkColumn2;
    }
}