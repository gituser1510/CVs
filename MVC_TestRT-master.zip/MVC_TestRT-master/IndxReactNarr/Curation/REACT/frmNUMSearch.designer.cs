﻿namespace IndxReactNarr
{
    partial class frmNUMSearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMain = new System.Windows.Forms.Panel();
            this.tlpnlStructs = new System.Windows.Forms.TableLayoutPanel();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.pnlBatch_TAN = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.txtOtherName = new System.Windows.Forms.TextBox();
            this.lblIUPAC = new System.Windows.Forms.Label();
            this.txtIUPAC = new System.Windows.Forms.TextBox();
            this.lblFormula = new System.Windows.Forms.Label();
            this.txtFormula = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtRegNo = new System.Windows.Forms.TextBox();
            this.lblSrchNUM = new System.Windows.Forms.Label();
            this.txtNUM_Srch = new System.Windows.Forms.TextBox();
            this.txtCAN = new System.Windows.Forms.TextBox();
            this.lblCAN = new System.Windows.Forms.Label();
            this.txtBatch = new System.Windows.Forms.TextBox();
            this.lblBatch = new System.Windows.Forms.Label();
            this.btnExport = new System.Windows.Forms.Button();
            this.btnGetAll = new System.Windows.Forms.Button();
            this.txtTAN = new System.Windows.Forms.TextBox();
            this.lblTAN = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnGet = new System.Windows.Forms.Button();
            this.lblNum = new System.Windows.Forms.Label();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.cmbNUMs = new System.Windows.Forms.ComboBox();
            this.pnlMain.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.pnlBatch_TAN.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.tlpnlStructs);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(984, 641);
            this.pnlMain.TabIndex = 0;
            // 
            // tlpnlStructs
            // 
            this.tlpnlStructs.AutoScroll = true;
            this.tlpnlStructs.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tlpnlStructs.BackColor = System.Drawing.Color.White;
            this.tlpnlStructs.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tlpnlStructs.ColumnCount = 1;
            this.tlpnlStructs.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpnlStructs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpnlStructs.Location = new System.Drawing.Point(0, 92);
            this.tlpnlStructs.Name = "tlpnlStructs";
            this.tlpnlStructs.RowCount = 1;
            this.tlpnlStructs.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpnlStructs.Size = new System.Drawing.Size(984, 549);
            this.tlpnlStructs.TabIndex = 1;
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.White;
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.cmbNUMs);
            this.pnlTop.Controls.Add(this.pnlBatch_TAN);
            this.pnlTop.Controls.Add(this.txtCAN);
            this.pnlTop.Controls.Add(this.lblCAN);
            this.pnlTop.Controls.Add(this.txtBatch);
            this.pnlTop.Controls.Add(this.lblBatch);
            this.pnlTop.Controls.Add(this.btnExport);
            this.pnlTop.Controls.Add(this.btnGetAll);
            this.pnlTop.Controls.Add(this.txtTAN);
            this.pnlTop.Controls.Add(this.lblTAN);
            this.pnlTop.Controls.Add(this.btnClear);
            this.pnlTop.Controls.Add(this.btnGet);
            this.pnlTop.Controls.Add(this.lblNum);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(984, 92);
            this.pnlTop.TabIndex = 0;
            // 
            // pnlBatch_TAN
            // 
            this.pnlBatch_TAN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.pnlBatch_TAN.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlBatch_TAN.Controls.Add(this.label2);
            this.pnlBatch_TAN.Controls.Add(this.txtOtherName);
            this.pnlBatch_TAN.Controls.Add(this.lblIUPAC);
            this.pnlBatch_TAN.Controls.Add(this.txtIUPAC);
            this.pnlBatch_TAN.Controls.Add(this.lblFormula);
            this.pnlBatch_TAN.Controls.Add(this.txtFormula);
            this.pnlBatch_TAN.Controls.Add(this.label1);
            this.pnlBatch_TAN.Controls.Add(this.txtRegNo);
            this.pnlBatch_TAN.Controls.Add(this.lblSrchNUM);
            this.pnlBatch_TAN.Controls.Add(this.txtNUM_Srch);
            this.pnlBatch_TAN.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBatch_TAN.Location = new System.Drawing.Point(0, 31);
            this.pnlBatch_TAN.Name = "pnlBatch_TAN";
            this.pnlBatch_TAN.Size = new System.Drawing.Size(982, 59);
            this.pnlBatch_TAN.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(619, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 17);
            this.label2.TabIndex = 17;
            this.label2.Text = "Other Name";
            // 
            // txtOtherName
            // 
            this.txtOtherName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOtherName.BackColor = System.Drawing.Color.White;
            this.txtOtherName.ForeColor = System.Drawing.Color.Blue;
            this.txtOtherName.Location = new System.Drawing.Point(705, 3);
            this.txtOtherName.Name = "txtOtherName";
            this.txtOtherName.Size = new System.Drawing.Size(270, 25);
            this.txtOtherName.TabIndex = 16;
            this.txtOtherName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOtherName_KeyPress);
            // 
            // lblIUPAC
            // 
            this.lblIUPAC.AutoSize = true;
            this.lblIUPAC.Location = new System.Drawing.Point(35, 34);
            this.lblIUPAC.Name = "lblIUPAC";
            this.lblIUPAC.Size = new System.Drawing.Size(54, 17);
            this.lblIUPAC.TabIndex = 15;
            this.lblIUPAC.Text = "IUPAC";
            // 
            // txtIUPAC
            // 
            this.txtIUPAC.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtIUPAC.BackColor = System.Drawing.Color.White;
            this.txtIUPAC.ForeColor = System.Drawing.Color.Blue;
            this.txtIUPAC.Location = new System.Drawing.Point(92, 30);
            this.txtIUPAC.Name = "txtIUPAC";
            this.txtIUPAC.Size = new System.Drawing.Size(883, 25);
            this.txtIUPAC.TabIndex = 14;
            this.txtIUPAC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIUPAC_KeyPress);
            // 
            // lblFormula
            // 
            this.lblFormula.AutoSize = true;
            this.lblFormula.Location = new System.Drawing.Point(364, 6);
            this.lblFormula.Name = "lblFormula";
            this.lblFormula.Size = new System.Drawing.Size(56, 17);
            this.lblFormula.TabIndex = 13;
            this.lblFormula.Text = "Formula";
            // 
            // txtFormula
            // 
            this.txtFormula.BackColor = System.Drawing.Color.White;
            this.txtFormula.ForeColor = System.Drawing.Color.Blue;
            this.txtFormula.Location = new System.Drawing.Point(423, 2);
            this.txtFormula.Name = "txtFormula";
            this.txtFormula.Size = new System.Drawing.Size(184, 25);
            this.txtFormula.TabIndex = 12;
            this.txtFormula.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFormula_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(197, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 17);
            this.label1.TabIndex = 11;
            this.label1.Text = "Reg. No.";
            // 
            // txtRegNo
            // 
            this.txtRegNo.BackColor = System.Drawing.Color.White;
            this.txtRegNo.ForeColor = System.Drawing.Color.Blue;
            this.txtRegNo.Location = new System.Drawing.Point(261, 2);
            this.txtRegNo.Name = "txtRegNo";
            this.txtRegNo.Size = new System.Drawing.Size(93, 25);
            this.txtRegNo.TabIndex = 10;
            this.txtRegNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRegNo_KeyPress);
            // 
            // lblSrchNUM
            // 
            this.lblSrchNUM.AutoSize = true;
            this.lblSrchNUM.Location = new System.Drawing.Point(3, 6);
            this.lblSrchNUM.Name = "lblSrchNUM";
            this.lblSrchNUM.Size = new System.Drawing.Size(88, 17);
            this.lblSrchNUM.TabIndex = 9;
            this.lblSrchNUM.Text = "Search NUM";
            // 
            // txtNUM_Srch
            // 
            this.txtNUM_Srch.BackColor = System.Drawing.Color.White;
            this.txtNUM_Srch.ForeColor = System.Drawing.Color.Blue;
            this.txtNUM_Srch.Location = new System.Drawing.Point(92, 2);
            this.txtNUM_Srch.Name = "txtNUM_Srch";
            this.txtNUM_Srch.Size = new System.Drawing.Size(93, 25);
            this.txtNUM_Srch.TabIndex = 7;
            this.txtNUM_Srch.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNUM_KeyPress);
            // 
            // txtCAN
            // 
            this.txtCAN.BackColor = System.Drawing.Color.White;
            this.txtCAN.ForeColor = System.Drawing.Color.Blue;
            this.txtCAN.Location = new System.Drawing.Point(340, 3);
            this.txtCAN.Name = "txtCAN";
            this.txtCAN.ReadOnly = true;
            this.txtCAN.Size = new System.Drawing.Size(93, 25);
            this.txtCAN.TabIndex = 2;
            // 
            // lblCAN
            // 
            this.lblCAN.AutoSize = true;
            this.lblCAN.Location = new System.Drawing.Point(301, 8);
            this.lblCAN.Name = "lblCAN";
            this.lblCAN.Size = new System.Drawing.Size(40, 17);
            this.lblCAN.TabIndex = 13;
            this.lblCAN.Text = "CAN";
            // 
            // txtBatch
            // 
            this.txtBatch.BackColor = System.Drawing.Color.White;
            this.txtBatch.ForeColor = System.Drawing.Color.Blue;
            this.txtBatch.Location = new System.Drawing.Point(46, 4);
            this.txtBatch.Name = "txtBatch";
            this.txtBatch.Size = new System.Drawing.Size(93, 25);
            this.txtBatch.TabIndex = 0;
            // 
            // lblBatch
            // 
            this.lblBatch.AutoSize = true;
            this.lblBatch.Location = new System.Drawing.Point(0, 8);
            this.lblBatch.Name = "lblBatch";
            this.lblBatch.Size = new System.Drawing.Size(43, 17);
            this.lblBatch.TabIndex = 11;
            this.lblBatch.Text = "Batch";
            // 
            // btnExport
            // 
            this.btnExport.Location = new System.Drawing.Point(812, 3);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(75, 26);
            this.btnExport.TabIndex = 8;
            this.btnExport.Text = "Export";
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // btnGetAll
            // 
            this.btnGetAll.Location = new System.Drawing.Point(722, 3);
            this.btnGetAll.Name = "btnGetAll";
            this.btnGetAll.Size = new System.Drawing.Size(75, 26);
            this.btnGetAll.TabIndex = 5;
            this.btnGetAll.Text = "Get All";
            this.btnGetAll.UseVisualStyleBackColor = true;
            this.btnGetAll.Click += new System.EventHandler(this.btnGetAll_Click);
            // 
            // txtTAN
            // 
            this.txtTAN.BackColor = System.Drawing.Color.White;
            this.txtTAN.ForeColor = System.Drawing.Color.Blue;
            this.txtTAN.Location = new System.Drawing.Point(191, 3);
            this.txtTAN.Name = "txtTAN";
            this.txtTAN.Size = new System.Drawing.Size(93, 25);
            this.txtTAN.TabIndex = 1;
            this.txtTAN.Leave += new System.EventHandler(this.txtTAN_Leave);
            // 
            // lblTAN
            // 
            this.lblTAN.AutoSize = true;
            this.lblTAN.Location = new System.Drawing.Point(152, 8);
            this.lblTAN.Name = "lblTAN";
            this.lblTAN.Size = new System.Drawing.Size(39, 17);
            this.lblTAN.TabIndex = 4;
            this.lblTAN.Text = "TAN";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(896, 3);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 26);
            this.btnClear.TabIndex = 6;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnGet
            // 
            this.btnGet.Location = new System.Drawing.Point(639, 3);
            this.btnGet.Name = "btnGet";
            this.btnGet.Size = new System.Drawing.Size(75, 26);
            this.btnGet.TabIndex = 4;
            this.btnGet.Text = "Get";
            this.btnGet.UseVisualStyleBackColor = true;
            this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
            // 
            // lblNum
            // 
            this.lblNum.AutoSize = true;
            this.lblNum.Location = new System.Drawing.Point(447, 8);
            this.lblNum.Name = "lblNum";
            this.lblNum.Size = new System.Drawing.Size(83, 17);
            this.lblNum.TabIndex = 0;
            this.lblNum.Text = "Select NUM";
            // 
            // cmbNUMs
            // 
            this.cmbNUMs.FormattingEnabled = true;
            this.cmbNUMs.Location = new System.Drawing.Point(537, 3);
            this.cmbNUMs.Name = "cmbNUMs";
            this.cmbNUMs.Size = new System.Drawing.Size(72, 25);
            this.cmbNUMs.TabIndex = 15;
            // 
            // frmNUMSearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 641);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmNUMSearch";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NUM Search";
            this.Load += new System.EventHandler(this.frmNUMSearch_Load);
            this.pnlMain.ResumeLayout(false);
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlBatch_TAN.ResumeLayout(false);
            this.pnlBatch_TAN.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.TextBox txtTAN;
        private System.Windows.Forms.Label lblTAN;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnGet;
        private System.Windows.Forms.Label lblNum;
        private System.Windows.Forms.TableLayoutPanel tlpnlStructs;
        private System.Windows.Forms.Button btnGetAll;
        private System.Windows.Forms.Label lblSrchNUM;
        private System.Windows.Forms.TextBox txtNUM_Srch;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.TextBox txtBatch;
        private System.Windows.Forms.Label lblBatch;
        private System.Windows.Forms.TextBox txtCAN;
        private System.Windows.Forms.Label lblCAN;
        private System.Windows.Forms.Panel pnlBatch_TAN;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtRegNo;
        private System.Windows.Forms.Label lblFormula;
        private System.Windows.Forms.TextBox txtFormula;
        private System.Windows.Forms.Label lblIUPAC;
        private System.Windows.Forms.TextBox txtIUPAC;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtOtherName;
        private System.Windows.Forms.ComboBox cmbNUMs;
    }
}