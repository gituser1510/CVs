﻿namespace IndxReactNarr
{
    partial class frmComments_New
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.splcntMain = new System.Windows.Forms.SplitContainer();
            this.tcComments = new System.Windows.Forms.TabControl();
            this.tpIndexError = new System.Windows.Forms.TabPage();
            this.pnlIE = new System.Windows.Forms.Panel();
            this.lblNum_IE = new System.Windows.Forms.Label();
            this.txtNUM_IE = new System.Windows.Forms.TextBox();
            this.lblComment_IE = new System.Windows.Forms.Label();
            this.txtComment_IE = new System.Windows.Forms.TextBox();
            this.txtFootNote_IE = new System.Windows.Forms.TextBox();
            this.lblFootNote_IE = new System.Windows.Forms.Label();
            this.txtColumn_IE = new System.Windows.Forms.TextBox();
            this.lblColumn_IE = new System.Windows.Forms.Label();
            this.txtScheme_IE = new System.Windows.Forms.TextBox();
            this.lblScheme_IE = new System.Windows.Forms.Label();
            this.txtTable_IE = new System.Windows.Forms.TextBox();
            this.lblTable_IE = new System.Windows.Forms.Label();
            this.btnClear_IE = new System.Windows.Forms.Button();
            this.txtSheet_IE = new System.Windows.Forms.TextBox();
            this.lblSheet_IE = new System.Windows.Forms.Label();
            this.txtFigure_IE = new System.Windows.Forms.TextBox();
            this.lblPage_IE = new System.Windows.Forms.Label();
            this.lblFigure_IE = new System.Windows.Forms.Label();
            this.txtPage_IE = new System.Windows.Forms.TextBox();
            this.txtPara_IE = new System.Windows.Forms.TextBox();
            this.lblLine_IE = new System.Windows.Forms.Label();
            this.lblPara_IE = new System.Windows.Forms.Label();
            this.txtLine_IE = new System.Windows.Forms.TextBox();
            this.pnlBottom_IE = new System.Windows.Forms.Panel();
            this.btnAddIECmnt = new System.Windows.Forms.Button();
            this.tpAuthorError = new System.Windows.Forms.TabPage();
            this.pnlAE = new System.Windows.Forms.Panel();
            this.lblNum_AE = new System.Windows.Forms.Label();
            this.txtNUM_AE = new System.Windows.Forms.TextBox();
            this.lblComment_AE = new System.Windows.Forms.Label();
            this.txtComment_AE = new System.Windows.Forms.TextBox();
            this.txtFootNote_AE = new System.Windows.Forms.TextBox();
            this.lblFootNote_AE = new System.Windows.Forms.Label();
            this.txtColumn_AE = new System.Windows.Forms.TextBox();
            this.lblColumn_AE = new System.Windows.Forms.Label();
            this.txtScheme_AE = new System.Windows.Forms.TextBox();
            this.lblScheme_AE = new System.Windows.Forms.Label();
            this.txtTable_AE = new System.Windows.Forms.TextBox();
            this.lblTable_AE = new System.Windows.Forms.Label();
            this.btnClear_AE = new System.Windows.Forms.Button();
            this.txtSheet_AE = new System.Windows.Forms.TextBox();
            this.lblSheet_AE = new System.Windows.Forms.Label();
            this.txtFigure_AE = new System.Windows.Forms.TextBox();
            this.lblPage_AE = new System.Windows.Forms.Label();
            this.lblFigure_AE = new System.Windows.Forms.Label();
            this.txtPage_AE = new System.Windows.Forms.TextBox();
            this.txtPara_AE = new System.Windows.Forms.TextBox();
            this.lblLine_AE = new System.Windows.Forms.Label();
            this.lblPara_AE = new System.Windows.Forms.Label();
            this.txtLine_AE = new System.Windows.Forms.TextBox();
            this.chkCorrected_AE = new System.Windows.Forms.CheckBox();
            this.pnlBottom_AE = new System.Windows.Forms.Panel();
            this.btnAddAECmnt = new System.Windows.Forms.Button();
            this.tpOtherComment = new System.Windows.Forms.TabPage();
            this.txtOtherComment = new System.Windows.Forms.TextBox();
            this.pnlBottom_OC = new System.Windows.Forms.Panel();
            this.btnAddOtherCmnts = new System.Windows.Forms.Button();
            this.tpTemperature = new System.Windows.Forms.TabPage();
            this.lblDefCmnts = new System.Windows.Forms.Label();
            this.txtDefaultComments = new System.Windows.Forms.TextBox();
            this.rtxtTempCmts = new System.Windows.Forms.RichTextBox();
            this.tpCASConsulted = new System.Windows.Forms.TabPage();
            this.btnCASCmnts = new System.Windows.Forms.Button();
            this.txtCASComment = new System.Windows.Forms.TextBox();
            this.lblNote_CASConsulted = new System.Windows.Forms.Label();
            this.dgvComments = new System.Windows.Forms.DataGridView();
            this.pnlSubmit = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblComLength = new System.Windows.Forms.Label();
            this.lblLengthLabel = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.colTC_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colComments = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCommentsType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCommentsLength = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDelete = new System.Windows.Forms.DataGridViewLinkColumn();
            this.pnlMain.SuspendLayout();
            this.splcntMain.Panel1.SuspendLayout();
            this.splcntMain.Panel2.SuspendLayout();
            this.splcntMain.SuspendLayout();
            this.tcComments.SuspendLayout();
            this.tpIndexError.SuspendLayout();
            this.pnlIE.SuspendLayout();
            this.pnlBottom_IE.SuspendLayout();
            this.tpAuthorError.SuspendLayout();
            this.pnlAE.SuspendLayout();
            this.pnlBottom_AE.SuspendLayout();
            this.tpOtherComment.SuspendLayout();
            this.pnlBottom_OC.SuspendLayout();
            this.tpTemperature.SuspendLayout();
            this.tpCASConsulted.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvComments)).BeginInit();
            this.pnlSubmit.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlMain.Controls.Add(this.splcntMain);
            this.pnlMain.Controls.Add(this.pnlSubmit);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(871, 568);
            this.pnlMain.TabIndex = 0;
            // 
            // splcntMain
            // 
            this.splcntMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splcntMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splcntMain.Location = new System.Drawing.Point(0, 0);
            this.splcntMain.Name = "splcntMain";
            this.splcntMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splcntMain.Panel1
            // 
            this.splcntMain.Panel1.Controls.Add(this.tcComments);
            // 
            // splcntMain.Panel2
            // 
            this.splcntMain.Panel2.Controls.Add(this.dgvComments);
            this.splcntMain.Size = new System.Drawing.Size(869, 522);
            this.splcntMain.SplitterDistance = 283;
            this.splcntMain.SplitterWidth = 3;
            this.splcntMain.TabIndex = 2;
            // 
            // tcComments
            // 
            this.tcComments.Controls.Add(this.tpIndexError);
            this.tcComments.Controls.Add(this.tpAuthorError);
            this.tcComments.Controls.Add(this.tpOtherComment);
            this.tcComments.Controls.Add(this.tpTemperature);
            this.tcComments.Controls.Add(this.tpCASConsulted);
            this.tcComments.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcComments.Location = new System.Drawing.Point(0, 0);
            this.tcComments.Name = "tcComments";
            this.tcComments.SelectedIndex = 0;
            this.tcComments.Size = new System.Drawing.Size(865, 279);
            this.tcComments.TabIndex = 94;
            // 
            // tpIndexError
            // 
            this.tpIndexError.BackColor = System.Drawing.Color.White;
            this.tpIndexError.Controls.Add(this.pnlIE);
            this.tpIndexError.Controls.Add(this.pnlBottom_IE);
            this.tpIndexError.Location = new System.Drawing.Point(4, 26);
            this.tpIndexError.Name = "tpIndexError";
            this.tpIndexError.Padding = new System.Windows.Forms.Padding(3);
            this.tpIndexError.Size = new System.Drawing.Size(857, 249);
            this.tpIndexError.TabIndex = 0;
            this.tpIndexError.Text = "Indexing Error Comments";
            this.tpIndexError.UseVisualStyleBackColor = true;
            // 
            // pnlIE
            // 
            this.pnlIE.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlIE.Controls.Add(this.lblNum_IE);
            this.pnlIE.Controls.Add(this.txtNUM_IE);
            this.pnlIE.Controls.Add(this.lblComment_IE);
            this.pnlIE.Controls.Add(this.txtComment_IE);
            this.pnlIE.Controls.Add(this.txtFootNote_IE);
            this.pnlIE.Controls.Add(this.lblFootNote_IE);
            this.pnlIE.Controls.Add(this.txtColumn_IE);
            this.pnlIE.Controls.Add(this.lblColumn_IE);
            this.pnlIE.Controls.Add(this.txtScheme_IE);
            this.pnlIE.Controls.Add(this.lblScheme_IE);
            this.pnlIE.Controls.Add(this.txtTable_IE);
            this.pnlIE.Controls.Add(this.lblTable_IE);
            this.pnlIE.Controls.Add(this.btnClear_IE);
            this.pnlIE.Controls.Add(this.txtSheet_IE);
            this.pnlIE.Controls.Add(this.lblSheet_IE);
            this.pnlIE.Controls.Add(this.txtFigure_IE);
            this.pnlIE.Controls.Add(this.lblPage_IE);
            this.pnlIE.Controls.Add(this.lblFigure_IE);
            this.pnlIE.Controls.Add(this.txtPage_IE);
            this.pnlIE.Controls.Add(this.txtPara_IE);
            this.pnlIE.Controls.Add(this.lblLine_IE);
            this.pnlIE.Controls.Add(this.lblPara_IE);
            this.pnlIE.Controls.Add(this.txtLine_IE);
            this.pnlIE.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlIE.Location = new System.Drawing.Point(3, 3);
            this.pnlIE.Name = "pnlIE";
            this.pnlIE.Size = new System.Drawing.Size(851, 211);
            this.pnlIE.TabIndex = 53;
            // 
            // lblNum_IE
            // 
            this.lblNum_IE.AutoSize = true;
            this.lblNum_IE.Location = new System.Drawing.Point(72, 8);
            this.lblNum_IE.Name = "lblNum_IE";
            this.lblNum_IE.Size = new System.Drawing.Size(43, 17);
            this.lblNum_IE.TabIndex = 114;
            this.lblNum_IE.Text = "NUM";
            // 
            // txtNUM_IE
            // 
            this.txtNUM_IE.BackColor = System.Drawing.Color.OldLace;
            this.txtNUM_IE.ForeColor = System.Drawing.Color.Blue;
            this.txtNUM_IE.Location = new System.Drawing.Point(75, 27);
            this.txtNUM_IE.Multiline = true;
            this.txtNUM_IE.Name = "txtNUM_IE";
            this.txtNUM_IE.Size = new System.Drawing.Size(62, 27);
            this.txtNUM_IE.TabIndex = 113;
            // 
            // lblComment_IE
            // 
            this.lblComment_IE.AutoSize = true;
            this.lblComment_IE.Location = new System.Drawing.Point(7, 60);
            this.lblComment_IE.Name = "lblComment_IE";
            this.lblComment_IE.Size = new System.Drawing.Size(65, 17);
            this.lblComment_IE.TabIndex = 112;
            this.lblComment_IE.Text = "Comment";
            // 
            // txtComment_IE
            // 
            this.txtComment_IE.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtComment_IE.BackColor = System.Drawing.Color.OldLace;
            this.txtComment_IE.ForeColor = System.Drawing.Color.Blue;
            this.txtComment_IE.Location = new System.Drawing.Point(75, 57);
            this.txtComment_IE.Multiline = true;
            this.txtComment_IE.Name = "txtComment_IE";
            this.txtComment_IE.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtComment_IE.Size = new System.Drawing.Size(769, 149);
            this.txtComment_IE.TabIndex = 111;
            // 
            // txtFootNote_IE
            // 
            this.txtFootNote_IE.ForeColor = System.Drawing.Color.Blue;
            this.txtFootNote_IE.Location = new System.Drawing.Point(662, 27);
            this.txtFootNote_IE.Multiline = true;
            this.txtFootNote_IE.Name = "txtFootNote_IE";
            this.txtFootNote_IE.Size = new System.Drawing.Size(62, 27);
            this.txtFootNote_IE.TabIndex = 109;
            // 
            // lblFootNote_IE
            // 
            this.lblFootNote_IE.AutoSize = true;
            this.lblFootNote_IE.Location = new System.Drawing.Point(657, 8);
            this.lblFootNote_IE.Name = "lblFootNote_IE";
            this.lblFootNote_IE.Size = new System.Drawing.Size(59, 17);
            this.lblFootNote_IE.TabIndex = 110;
            this.lblFootNote_IE.Text = "Footnote";
            // 
            // txtColumn_IE
            // 
            this.txtColumn_IE.ForeColor = System.Drawing.Color.Blue;
            this.txtColumn_IE.Location = new System.Drawing.Point(337, 27);
            this.txtColumn_IE.Multiline = true;
            this.txtColumn_IE.Name = "txtColumn_IE";
            this.txtColumn_IE.Size = new System.Drawing.Size(62, 27);
            this.txtColumn_IE.TabIndex = 107;
            // 
            // lblColumn_IE
            // 
            this.lblColumn_IE.AutoSize = true;
            this.lblColumn_IE.Location = new System.Drawing.Point(333, 8);
            this.lblColumn_IE.Name = "lblColumn_IE";
            this.lblColumn_IE.Size = new System.Drawing.Size(53, 17);
            this.lblColumn_IE.TabIndex = 108;
            this.lblColumn_IE.Text = "Column";
            // 
            // txtScheme_IE
            // 
            this.txtScheme_IE.ForeColor = System.Drawing.Color.Blue;
            this.txtScheme_IE.Location = new System.Drawing.Point(532, 27);
            this.txtScheme_IE.Multiline = true;
            this.txtScheme_IE.Name = "txtScheme_IE";
            this.txtScheme_IE.Size = new System.Drawing.Size(62, 27);
            this.txtScheme_IE.TabIndex = 105;
            // 
            // lblScheme_IE
            // 
            this.lblScheme_IE.AutoSize = true;
            this.lblScheme_IE.Location = new System.Drawing.Point(529, 8);
            this.lblScheme_IE.Name = "lblScheme_IE";
            this.lblScheme_IE.Size = new System.Drawing.Size(55, 17);
            this.lblScheme_IE.TabIndex = 106;
            this.lblScheme_IE.Text = "Scheme";
            // 
            // txtTable_IE
            // 
            this.txtTable_IE.ForeColor = System.Drawing.Color.Blue;
            this.txtTable_IE.Location = new System.Drawing.Point(402, 27);
            this.txtTable_IE.Multiline = true;
            this.txtTable_IE.Name = "txtTable_IE";
            this.txtTable_IE.Size = new System.Drawing.Size(62, 27);
            this.txtTable_IE.TabIndex = 103;
            // 
            // lblTable_IE
            // 
            this.lblTable_IE.AutoSize = true;
            this.lblTable_IE.Location = new System.Drawing.Point(399, 8);
            this.lblTable_IE.Name = "lblTable_IE";
            this.lblTable_IE.Size = new System.Drawing.Size(40, 17);
            this.lblTable_IE.TabIndex = 104;
            this.lblTable_IE.Text = "Table";
            // 
            // btnClear_IE
            // 
            this.btnClear_IE.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClear_IE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClear_IE.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear_IE.Location = new System.Drawing.Point(791, 27);
            this.btnClear_IE.Name = "btnClear_IE";
            this.btnClear_IE.Size = new System.Drawing.Size(54, 27);
            this.btnClear_IE.TabIndex = 102;
            this.btnClear_IE.Text = "Clear";
            this.btnClear_IE.UseVisualStyleBackColor = true;
            this.btnClear_IE.Click += new System.EventHandler(this.btnClear_IE_Click);
            // 
            // txtSheet_IE
            // 
            this.txtSheet_IE.ForeColor = System.Drawing.Color.Blue;
            this.txtSheet_IE.Location = new System.Drawing.Point(597, 27);
            this.txtSheet_IE.Multiline = true;
            this.txtSheet_IE.Name = "txtSheet_IE";
            this.txtSheet_IE.Size = new System.Drawing.Size(62, 27);
            this.txtSheet_IE.TabIndex = 95;
            // 
            // lblSheet_IE
            // 
            this.lblSheet_IE.AutoSize = true;
            this.lblSheet_IE.Location = new System.Drawing.Point(596, 8);
            this.lblSheet_IE.Name = "lblSheet_IE";
            this.lblSheet_IE.Size = new System.Drawing.Size(41, 17);
            this.lblSheet_IE.TabIndex = 101;
            this.lblSheet_IE.Text = "Sheet";
            // 
            // txtFigure_IE
            // 
            this.txtFigure_IE.ForeColor = System.Drawing.Color.Blue;
            this.txtFigure_IE.Location = new System.Drawing.Point(467, 27);
            this.txtFigure_IE.Multiline = true;
            this.txtFigure_IE.Name = "txtFigure_IE";
            this.txtFigure_IE.Size = new System.Drawing.Size(62, 27);
            this.txtFigure_IE.TabIndex = 94;
            // 
            // lblPage_IE
            // 
            this.lblPage_IE.AutoSize = true;
            this.lblPage_IE.Location = new System.Drawing.Point(138, 8);
            this.lblPage_IE.Name = "lblPage_IE";
            this.lblPage_IE.Size = new System.Drawing.Size(38, 17);
            this.lblPage_IE.TabIndex = 97;
            this.lblPage_IE.Text = "Page";
            // 
            // lblFigure_IE
            // 
            this.lblFigure_IE.AutoSize = true;
            this.lblFigure_IE.Location = new System.Drawing.Point(464, 8);
            this.lblFigure_IE.Name = "lblFigure_IE";
            this.lblFigure_IE.Size = new System.Drawing.Size(45, 17);
            this.lblFigure_IE.TabIndex = 100;
            this.lblFigure_IE.Text = "Figure";
            // 
            // txtPage_IE
            // 
            this.txtPage_IE.BackColor = System.Drawing.Color.OldLace;
            this.txtPage_IE.ForeColor = System.Drawing.Color.Blue;
            this.txtPage_IE.Location = new System.Drawing.Point(141, 27);
            this.txtPage_IE.Multiline = true;
            this.txtPage_IE.Name = "txtPage_IE";
            this.txtPage_IE.Size = new System.Drawing.Size(62, 27);
            this.txtPage_IE.TabIndex = 91;
            // 
            // txtPara_IE
            // 
            this.txtPara_IE.ForeColor = System.Drawing.Color.Blue;
            this.txtPara_IE.Location = new System.Drawing.Point(272, 27);
            this.txtPara_IE.Multiline = true;
            this.txtPara_IE.Name = "txtPara_IE";
            this.txtPara_IE.Size = new System.Drawing.Size(62, 27);
            this.txtPara_IE.TabIndex = 93;
            // 
            // lblLine_IE
            // 
            this.lblLine_IE.AutoSize = true;
            this.lblLine_IE.Location = new System.Drawing.Point(203, 8);
            this.lblLine_IE.Name = "lblLine_IE";
            this.lblLine_IE.Size = new System.Drawing.Size(34, 17);
            this.lblLine_IE.TabIndex = 98;
            this.lblLine_IE.Text = "Line";
            // 
            // lblPara_IE
            // 
            this.lblPara_IE.AutoSize = true;
            this.lblPara_IE.Location = new System.Drawing.Point(268, 8);
            this.lblPara_IE.Name = "lblPara_IE";
            this.lblPara_IE.Size = new System.Drawing.Size(36, 17);
            this.lblPara_IE.TabIndex = 99;
            this.lblPara_IE.Text = "Para";
            // 
            // txtLine_IE
            // 
            this.txtLine_IE.BackColor = System.Drawing.Color.White;
            this.txtLine_IE.ForeColor = System.Drawing.Color.Blue;
            this.txtLine_IE.Location = new System.Drawing.Point(206, 27);
            this.txtLine_IE.Multiline = true;
            this.txtLine_IE.Name = "txtLine_IE";
            this.txtLine_IE.Size = new System.Drawing.Size(62, 27);
            this.txtLine_IE.TabIndex = 92;
            // 
            // pnlBottom_IE
            // 
            this.pnlBottom_IE.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom_IE.Controls.Add(this.btnAddIECmnt);
            this.pnlBottom_IE.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom_IE.Location = new System.Drawing.Point(3, 214);
            this.pnlBottom_IE.Name = "pnlBottom_IE";
            this.pnlBottom_IE.Size = new System.Drawing.Size(851, 32);
            this.pnlBottom_IE.TabIndex = 54;
            // 
            // btnAddIECmnt
            // 
            this.btnAddIECmnt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddIECmnt.Image = global::IndxReactNarr.Properties.Resources.add;
            this.btnAddIECmnt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddIECmnt.Location = new System.Drawing.Point(723, 2);
            this.btnAddIECmnt.Name = "btnAddIECmnt";
            this.btnAddIECmnt.Size = new System.Drawing.Size(123, 26);
            this.btnAddIECmnt.TabIndex = 0;
            this.btnAddIECmnt.Text = "Add Comment";
            this.btnAddIECmnt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAddIECmnt.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAddIECmnt.UseVisualStyleBackColor = true;
            this.btnAddIECmnt.Click += new System.EventHandler(this.btnAddIECmnt_Click);
            // 
            // tpAuthorError
            // 
            this.tpAuthorError.BackColor = System.Drawing.Color.White;
            this.tpAuthorError.Controls.Add(this.pnlAE);
            this.tpAuthorError.Controls.Add(this.pnlBottom_AE);
            this.tpAuthorError.Location = new System.Drawing.Point(4, 26);
            this.tpAuthorError.Name = "tpAuthorError";
            this.tpAuthorError.Padding = new System.Windows.Forms.Padding(3);
            this.tpAuthorError.Size = new System.Drawing.Size(857, 249);
            this.tpAuthorError.TabIndex = 1;
            this.tpAuthorError.Text = "Author Error Comments";
            this.tpAuthorError.UseVisualStyleBackColor = true;
            // 
            // pnlAE
            // 
            this.pnlAE.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlAE.Controls.Add(this.lblNum_AE);
            this.pnlAE.Controls.Add(this.txtNUM_AE);
            this.pnlAE.Controls.Add(this.lblComment_AE);
            this.pnlAE.Controls.Add(this.txtComment_AE);
            this.pnlAE.Controls.Add(this.txtFootNote_AE);
            this.pnlAE.Controls.Add(this.lblFootNote_AE);
            this.pnlAE.Controls.Add(this.txtColumn_AE);
            this.pnlAE.Controls.Add(this.lblColumn_AE);
            this.pnlAE.Controls.Add(this.txtScheme_AE);
            this.pnlAE.Controls.Add(this.lblScheme_AE);
            this.pnlAE.Controls.Add(this.txtTable_AE);
            this.pnlAE.Controls.Add(this.lblTable_AE);
            this.pnlAE.Controls.Add(this.btnClear_AE);
            this.pnlAE.Controls.Add(this.txtSheet_AE);
            this.pnlAE.Controls.Add(this.lblSheet_AE);
            this.pnlAE.Controls.Add(this.txtFigure_AE);
            this.pnlAE.Controls.Add(this.lblPage_AE);
            this.pnlAE.Controls.Add(this.lblFigure_AE);
            this.pnlAE.Controls.Add(this.txtPage_AE);
            this.pnlAE.Controls.Add(this.txtPara_AE);
            this.pnlAE.Controls.Add(this.lblLine_AE);
            this.pnlAE.Controls.Add(this.lblPara_AE);
            this.pnlAE.Controls.Add(this.txtLine_AE);
            this.pnlAE.Controls.Add(this.chkCorrected_AE);
            this.pnlAE.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAE.Location = new System.Drawing.Point(3, 3);
            this.pnlAE.Name = "pnlAE";
            this.pnlAE.Size = new System.Drawing.Size(851, 211);
            this.pnlAE.TabIndex = 52;
            // 
            // lblNum_AE
            // 
            this.lblNum_AE.AutoSize = true;
            this.lblNum_AE.Location = new System.Drawing.Point(4, 8);
            this.lblNum_AE.Name = "lblNum_AE";
            this.lblNum_AE.Size = new System.Drawing.Size(43, 17);
            this.lblNum_AE.TabIndex = 114;
            this.lblNum_AE.Text = "NUM";
            // 
            // txtNUM_AE
            // 
            this.txtNUM_AE.BackColor = System.Drawing.Color.OldLace;
            this.txtNUM_AE.ForeColor = System.Drawing.Color.Blue;
            this.txtNUM_AE.Location = new System.Drawing.Point(7, 27);
            this.txtNUM_AE.Multiline = true;
            this.txtNUM_AE.Name = "txtNUM_AE";
            this.txtNUM_AE.Size = new System.Drawing.Size(62, 27);
            this.txtNUM_AE.TabIndex = 113;
            // 
            // lblComment_AE
            // 
            this.lblComment_AE.AutoSize = true;
            this.lblComment_AE.Location = new System.Drawing.Point(7, 60);
            this.lblComment_AE.Name = "lblComment_AE";
            this.lblComment_AE.Size = new System.Drawing.Size(65, 17);
            this.lblComment_AE.TabIndex = 112;
            this.lblComment_AE.Text = "Comment";
            // 
            // txtComment_AE
            // 
            this.txtComment_AE.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtComment_AE.BackColor = System.Drawing.Color.OldLace;
            this.txtComment_AE.ForeColor = System.Drawing.Color.Blue;
            this.txtComment_AE.Location = new System.Drawing.Point(75, 57);
            this.txtComment_AE.Multiline = true;
            this.txtComment_AE.Name = "txtComment_AE";
            this.txtComment_AE.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtComment_AE.Size = new System.Drawing.Size(769, 149);
            this.txtComment_AE.TabIndex = 111;
            // 
            // txtFootNote_AE
            // 
            this.txtFootNote_AE.ForeColor = System.Drawing.Color.Blue;
            this.txtFootNote_AE.Location = new System.Drawing.Point(662, 27);
            this.txtFootNote_AE.Multiline = true;
            this.txtFootNote_AE.Name = "txtFootNote_AE";
            this.txtFootNote_AE.Size = new System.Drawing.Size(62, 27);
            this.txtFootNote_AE.TabIndex = 109;
            // 
            // lblFootNote_AE
            // 
            this.lblFootNote_AE.AutoSize = true;
            this.lblFootNote_AE.Location = new System.Drawing.Point(657, 8);
            this.lblFootNote_AE.Name = "lblFootNote_AE";
            this.lblFootNote_AE.Size = new System.Drawing.Size(59, 17);
            this.lblFootNote_AE.TabIndex = 110;
            this.lblFootNote_AE.Text = "Footnote";
            // 
            // txtColumn_AE
            // 
            this.txtColumn_AE.ForeColor = System.Drawing.Color.Blue;
            this.txtColumn_AE.Location = new System.Drawing.Point(337, 27);
            this.txtColumn_AE.Multiline = true;
            this.txtColumn_AE.Name = "txtColumn_AE";
            this.txtColumn_AE.Size = new System.Drawing.Size(62, 27);
            this.txtColumn_AE.TabIndex = 107;
            // 
            // lblColumn_AE
            // 
            this.lblColumn_AE.AutoSize = true;
            this.lblColumn_AE.Location = new System.Drawing.Point(333, 8);
            this.lblColumn_AE.Name = "lblColumn_AE";
            this.lblColumn_AE.Size = new System.Drawing.Size(53, 17);
            this.lblColumn_AE.TabIndex = 108;
            this.lblColumn_AE.Text = "Column";
            // 
            // txtScheme_AE
            // 
            this.txtScheme_AE.ForeColor = System.Drawing.Color.Blue;
            this.txtScheme_AE.Location = new System.Drawing.Point(532, 27);
            this.txtScheme_AE.Multiline = true;
            this.txtScheme_AE.Name = "txtScheme_AE";
            this.txtScheme_AE.Size = new System.Drawing.Size(62, 27);
            this.txtScheme_AE.TabIndex = 105;
            // 
            // lblScheme_AE
            // 
            this.lblScheme_AE.AutoSize = true;
            this.lblScheme_AE.Location = new System.Drawing.Point(529, 8);
            this.lblScheme_AE.Name = "lblScheme_AE";
            this.lblScheme_AE.Size = new System.Drawing.Size(55, 17);
            this.lblScheme_AE.TabIndex = 106;
            this.lblScheme_AE.Text = "Scheme";
            // 
            // txtTable_AE
            // 
            this.txtTable_AE.ForeColor = System.Drawing.Color.Blue;
            this.txtTable_AE.Location = new System.Drawing.Point(402, 27);
            this.txtTable_AE.Multiline = true;
            this.txtTable_AE.Name = "txtTable_AE";
            this.txtTable_AE.Size = new System.Drawing.Size(62, 27);
            this.txtTable_AE.TabIndex = 103;
            // 
            // lblTable_AE
            // 
            this.lblTable_AE.AutoSize = true;
            this.lblTable_AE.Location = new System.Drawing.Point(399, 8);
            this.lblTable_AE.Name = "lblTable_AE";
            this.lblTable_AE.Size = new System.Drawing.Size(40, 17);
            this.lblTable_AE.TabIndex = 104;
            this.lblTable_AE.Text = "Table";
            // 
            // btnClear_AE
            // 
            this.btnClear_AE.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClear_AE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClear_AE.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear_AE.Location = new System.Drawing.Point(791, 27);
            this.btnClear_AE.Name = "btnClear_AE";
            this.btnClear_AE.Size = new System.Drawing.Size(54, 27);
            this.btnClear_AE.TabIndex = 102;
            this.btnClear_AE.Text = "Clear";
            this.btnClear_AE.UseVisualStyleBackColor = true;
            this.btnClear_AE.Click += new System.EventHandler(this.btnClear_AE_Click);
            // 
            // txtSheet_AE
            // 
            this.txtSheet_AE.ForeColor = System.Drawing.Color.Blue;
            this.txtSheet_AE.Location = new System.Drawing.Point(597, 27);
            this.txtSheet_AE.Multiline = true;
            this.txtSheet_AE.Name = "txtSheet_AE";
            this.txtSheet_AE.Size = new System.Drawing.Size(62, 27);
            this.txtSheet_AE.TabIndex = 95;
            // 
            // lblSheet_AE
            // 
            this.lblSheet_AE.AutoSize = true;
            this.lblSheet_AE.Location = new System.Drawing.Point(596, 8);
            this.lblSheet_AE.Name = "lblSheet_AE";
            this.lblSheet_AE.Size = new System.Drawing.Size(41, 17);
            this.lblSheet_AE.TabIndex = 101;
            this.lblSheet_AE.Text = "Sheet";
            // 
            // txtFigure_AE
            // 
            this.txtFigure_AE.ForeColor = System.Drawing.Color.Blue;
            this.txtFigure_AE.Location = new System.Drawing.Point(467, 27);
            this.txtFigure_AE.Multiline = true;
            this.txtFigure_AE.Name = "txtFigure_AE";
            this.txtFigure_AE.Size = new System.Drawing.Size(62, 27);
            this.txtFigure_AE.TabIndex = 94;
            // 
            // lblPage_AE
            // 
            this.lblPage_AE.AutoSize = true;
            this.lblPage_AE.Location = new System.Drawing.Point(138, 8);
            this.lblPage_AE.Name = "lblPage_AE";
            this.lblPage_AE.Size = new System.Drawing.Size(38, 17);
            this.lblPage_AE.TabIndex = 97;
            this.lblPage_AE.Text = "Page";
            // 
            // lblFigure_AE
            // 
            this.lblFigure_AE.AutoSize = true;
            this.lblFigure_AE.Location = new System.Drawing.Point(464, 8);
            this.lblFigure_AE.Name = "lblFigure_AE";
            this.lblFigure_AE.Size = new System.Drawing.Size(45, 17);
            this.lblFigure_AE.TabIndex = 100;
            this.lblFigure_AE.Text = "Figure";
            // 
            // txtPage_AE
            // 
            this.txtPage_AE.BackColor = System.Drawing.Color.OldLace;
            this.txtPage_AE.ForeColor = System.Drawing.Color.Blue;
            this.txtPage_AE.Location = new System.Drawing.Point(141, 27);
            this.txtPage_AE.Multiline = true;
            this.txtPage_AE.Name = "txtPage_AE";
            this.txtPage_AE.Size = new System.Drawing.Size(62, 27);
            this.txtPage_AE.TabIndex = 91;
            // 
            // txtPara_AE
            // 
            this.txtPara_AE.ForeColor = System.Drawing.Color.Blue;
            this.txtPara_AE.Location = new System.Drawing.Point(272, 27);
            this.txtPara_AE.Multiline = true;
            this.txtPara_AE.Name = "txtPara_AE";
            this.txtPara_AE.Size = new System.Drawing.Size(62, 27);
            this.txtPara_AE.TabIndex = 93;
            // 
            // lblLine_AE
            // 
            this.lblLine_AE.AutoSize = true;
            this.lblLine_AE.Location = new System.Drawing.Point(203, 8);
            this.lblLine_AE.Name = "lblLine_AE";
            this.lblLine_AE.Size = new System.Drawing.Size(34, 17);
            this.lblLine_AE.TabIndex = 98;
            this.lblLine_AE.Text = "Line";
            // 
            // lblPara_AE
            // 
            this.lblPara_AE.AutoSize = true;
            this.lblPara_AE.Location = new System.Drawing.Point(268, 8);
            this.lblPara_AE.Name = "lblPara_AE";
            this.lblPara_AE.Size = new System.Drawing.Size(36, 17);
            this.lblPara_AE.TabIndex = 99;
            this.lblPara_AE.Text = "Para";
            // 
            // txtLine_AE
            // 
            this.txtLine_AE.BackColor = System.Drawing.Color.White;
            this.txtLine_AE.ForeColor = System.Drawing.Color.Blue;
            this.txtLine_AE.Location = new System.Drawing.Point(206, 27);
            this.txtLine_AE.Multiline = true;
            this.txtLine_AE.Name = "txtLine_AE";
            this.txtLine_AE.Size = new System.Drawing.Size(62, 27);
            this.txtLine_AE.TabIndex = 92;
            // 
            // chkCorrected_AE
            // 
            this.chkCorrected_AE.AutoSize = true;
            this.chkCorrected_AE.Location = new System.Drawing.Point(47, 7);
            this.chkCorrected_AE.Name = "chkCorrected_AE";
            this.chkCorrected_AE.Size = new System.Drawing.Size(86, 21);
            this.chkCorrected_AE.TabIndex = 115;
            this.chkCorrected_AE.Text = "Corrected";
            this.chkCorrected_AE.UseVisualStyleBackColor = true;
            // 
            // pnlBottom_AE
            // 
            this.pnlBottom_AE.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom_AE.Controls.Add(this.btnAddAECmnt);
            this.pnlBottom_AE.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom_AE.Location = new System.Drawing.Point(3, 214);
            this.pnlBottom_AE.Name = "pnlBottom_AE";
            this.pnlBottom_AE.Size = new System.Drawing.Size(851, 32);
            this.pnlBottom_AE.TabIndex = 55;
            // 
            // btnAddAECmnt
            // 
            this.btnAddAECmnt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddAECmnt.Image = global::IndxReactNarr.Properties.Resources.add;
            this.btnAddAECmnt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddAECmnt.Location = new System.Drawing.Point(723, 2);
            this.btnAddAECmnt.Name = "btnAddAECmnt";
            this.btnAddAECmnt.Size = new System.Drawing.Size(123, 26);
            this.btnAddAECmnt.TabIndex = 0;
            this.btnAddAECmnt.Text = "Add Comment";
            this.btnAddAECmnt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAddAECmnt.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAddAECmnt.UseVisualStyleBackColor = true;
            this.btnAddAECmnt.Click += new System.EventHandler(this.btnAddAECmnt_Click);
            // 
            // tpOtherComment
            // 
            this.tpOtherComment.BackColor = System.Drawing.Color.White;
            this.tpOtherComment.Controls.Add(this.txtOtherComment);
            this.tpOtherComment.Controls.Add(this.pnlBottom_OC);
            this.tpOtherComment.Location = new System.Drawing.Point(4, 26);
            this.tpOtherComment.Name = "tpOtherComment";
            this.tpOtherComment.Padding = new System.Windows.Forms.Padding(3);
            this.tpOtherComment.Size = new System.Drawing.Size(857, 249);
            this.tpOtherComment.TabIndex = 2;
            this.tpOtherComment.Text = "Other Comments";
            this.tpOtherComment.UseVisualStyleBackColor = true;
            // 
            // txtOtherComment
            // 
            this.txtOtherComment.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtOtherComment.ForeColor = System.Drawing.Color.Blue;
            this.txtOtherComment.Location = new System.Drawing.Point(3, 3);
            this.txtOtherComment.Multiline = true;
            this.txtOtherComment.Name = "txtOtherComment";
            this.txtOtherComment.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtOtherComment.Size = new System.Drawing.Size(851, 211);
            this.txtOtherComment.TabIndex = 67;
            // 
            // pnlBottom_OC
            // 
            this.pnlBottom_OC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom_OC.Controls.Add(this.btnAddOtherCmnts);
            this.pnlBottom_OC.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom_OC.Location = new System.Drawing.Point(3, 214);
            this.pnlBottom_OC.Name = "pnlBottom_OC";
            this.pnlBottom_OC.Size = new System.Drawing.Size(851, 32);
            this.pnlBottom_OC.TabIndex = 68;
            // 
            // btnAddOtherCmnts
            // 
            this.btnAddOtherCmnts.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddOtherCmnts.Image = global::IndxReactNarr.Properties.Resources.add;
            this.btnAddOtherCmnts.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddOtherCmnts.Location = new System.Drawing.Point(723, 2);
            this.btnAddOtherCmnts.Name = "btnAddOtherCmnts";
            this.btnAddOtherCmnts.Size = new System.Drawing.Size(123, 26);
            this.btnAddOtherCmnts.TabIndex = 0;
            this.btnAddOtherCmnts.Text = "Add Comment";
            this.btnAddOtherCmnts.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAddOtherCmnts.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAddOtherCmnts.UseVisualStyleBackColor = true;
            this.btnAddOtherCmnts.Click += new System.EventHandler(this.btnAddOtherCmnts_Click);
            // 
            // tpTemperature
            // 
            this.tpTemperature.BackColor = System.Drawing.Color.Transparent;
            this.tpTemperature.Controls.Add(this.lblDefCmnts);
            this.tpTemperature.Controls.Add(this.txtDefaultComments);
            this.tpTemperature.Controls.Add(this.rtxtTempCmts);
            this.tpTemperature.Location = new System.Drawing.Point(4, 26);
            this.tpTemperature.Name = "tpTemperature";
            this.tpTemperature.Padding = new System.Windows.Forms.Padding(3);
            this.tpTemperature.Size = new System.Drawing.Size(857, 249);
            this.tpTemperature.TabIndex = 4;
            this.tpTemperature.Text = "Temperature/Default Comments";
            // 
            // lblDefCmnts
            // 
            this.lblDefCmnts.AutoSize = true;
            this.lblDefCmnts.Location = new System.Drawing.Point(0, 141);
            this.lblDefCmnts.Name = "lblDefCmnts";
            this.lblDefCmnts.Size = new System.Drawing.Size(119, 17);
            this.lblDefCmnts.TabIndex = 99;
            this.lblDefCmnts.Text = "Default Comments";
            // 
            // txtDefaultComments
            // 
            this.txtDefaultComments.BackColor = System.Drawing.Color.White;
            this.txtDefaultComments.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtDefaultComments.ForeColor = System.Drawing.Color.Blue;
            this.txtDefaultComments.Location = new System.Drawing.Point(3, 186);
            this.txtDefaultComments.Multiline = true;
            this.txtDefaultComments.Name = "txtDefaultComments";
            this.txtDefaultComments.ReadOnly = true;
            this.txtDefaultComments.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtDefaultComments.Size = new System.Drawing.Size(851, 60);
            this.txtDefaultComments.TabIndex = 96;
            // 
            // rtxtTempCmts
            // 
            this.rtxtTempCmts.BackColor = System.Drawing.Color.White;
            this.rtxtTempCmts.Dock = System.Windows.Forms.DockStyle.Top;
            this.rtxtTempCmts.ForeColor = System.Drawing.SystemColors.WindowText;
            this.rtxtTempCmts.Location = new System.Drawing.Point(3, 3);
            this.rtxtTempCmts.Name = "rtxtTempCmts";
            this.rtxtTempCmts.ReadOnly = true;
            this.rtxtTempCmts.Size = new System.Drawing.Size(851, 136);
            this.rtxtTempCmts.TabIndex = 95;
            this.rtxtTempCmts.Text = "";
            // 
            // tpCASConsulted
            // 
            this.tpCASConsulted.BackColor = System.Drawing.Color.White;
            this.tpCASConsulted.Controls.Add(this.btnCASCmnts);
            this.tpCASConsulted.Controls.Add(this.txtCASComment);
            this.tpCASConsulted.Controls.Add(this.lblNote_CASConsulted);
            this.tpCASConsulted.Location = new System.Drawing.Point(4, 26);
            this.tpCASConsulted.Name = "tpCASConsulted";
            this.tpCASConsulted.Padding = new System.Windows.Forms.Padding(3);
            this.tpCASConsulted.Size = new System.Drawing.Size(857, 249);
            this.tpCASConsulted.TabIndex = 3;
            this.tpCASConsulted.Text = "CAS Consulted for Comments";
            this.tpCASConsulted.UseVisualStyleBackColor = true;
            // 
            // btnCASCmnts
            // 
            this.btnCASCmnts.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCASCmnts.Image = global::IndxReactNarr.Properties.Resources.add;
            this.btnCASCmnts.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCASCmnts.Location = new System.Drawing.Point(727, 225);
            this.btnCASCmnts.Name = "btnCASCmnts";
            this.btnCASCmnts.Size = new System.Drawing.Size(123, 26);
            this.btnCASCmnts.TabIndex = 94;
            this.btnCASCmnts.Text = "Add Comment";
            this.btnCASCmnts.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCASCmnts.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnCASCmnts.UseVisualStyleBackColor = true;
            this.btnCASCmnts.Click += new System.EventHandler(this.btnCASCmnts_Click);
            // 
            // txtCASComment
            // 
            this.txtCASComment.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCASComment.ForeColor = System.Drawing.Color.Blue;
            this.txtCASComment.Location = new System.Drawing.Point(3, 3);
            this.txtCASComment.Multiline = true;
            this.txtCASComment.Name = "txtCASComment";
            this.txtCASComment.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtCASComment.Size = new System.Drawing.Size(851, 211);
            this.txtCASComment.TabIndex = 92;
            // 
            // lblNote_CASConsulted
            // 
            this.lblNote_CASConsulted.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNote_CASConsulted.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblNote_CASConsulted.ForeColor = System.Drawing.Color.Blue;
            this.lblNote_CASConsulted.Location = new System.Drawing.Point(3, 214);
            this.lblNote_CASConsulted.Name = "lblNote_CASConsulted";
            this.lblNote_CASConsulted.Size = new System.Drawing.Size(851, 32);
            this.lblNote_CASConsulted.TabIndex = 93;
            this.lblNote_CASConsulted.Text = "Note: \'CAS Consulted for\' comments are available to query TANs only. ";
            this.lblNote_CASConsulted.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dgvComments
            // 
            this.dgvComments.AllowUserToAddRows = false;
            this.dgvComments.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvComments.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvComments.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvComments.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvComments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvComments.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTC_ID,
            this.colComments,
            this.colCommentsType,
            this.colCommentsLength,
            this.colDelete});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvComments.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvComments.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvComments.Location = new System.Drawing.Point(0, 0);
            this.dgvComments.Name = "dgvComments";
            this.dgvComments.ReadOnly = true;
            this.dgvComments.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            this.dgvComments.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvComments.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.dgvComments.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvComments.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvComments.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvComments.Size = new System.Drawing.Size(865, 232);
            this.dgvComments.TabIndex = 0;
            this.dgvComments.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvComments_CellContentClick);
            this.dgvComments.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvComments_CellDoubleClick);
            this.dgvComments.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvComments_RowPostPaint);
            // 
            // pnlSubmit
            // 
            this.pnlSubmit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlSubmit.Controls.Add(this.label2);
            this.pnlSubmit.Controls.Add(this.label1);
            this.pnlSubmit.Controls.Add(this.lblComLength);
            this.pnlSubmit.Controls.Add(this.lblLengthLabel);
            this.pnlSubmit.Controls.Add(this.btnRefresh);
            this.pnlSubmit.Controls.Add(this.btnSubmit);
            this.pnlSubmit.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlSubmit.Location = new System.Drawing.Point(0, 522);
            this.pnlSubmit.Name = "pnlSubmit";
            this.pnlSubmit.Size = new System.Drawing.Size(869, 44);
            this.pnlSubmit.TabIndex = 55;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(384, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "4000";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(200, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Comments maximum length: ";
            // 
            // lblComLength
            // 
            this.lblComLength.AutoSize = true;
            this.lblComLength.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComLength.ForeColor = System.Drawing.Color.Red;
            this.lblComLength.Location = new System.Drawing.Point(384, 3);
            this.lblComLength.Name = "lblComLength";
            this.lblComLength.Size = new System.Drawing.Size(16, 17);
            this.lblComLength.TabIndex = 2;
            this.lblComLength.Text = "0";
            // 
            // lblLengthLabel
            // 
            this.lblLengthLabel.AutoSize = true;
            this.lblLengthLabel.ForeColor = System.Drawing.Color.Blue;
            this.lblLengthLabel.Location = new System.Drawing.Point(4, 3);
            this.lblLengthLabel.Name = "lblLengthLabel";
            this.lblLengthLabel.Size = new System.Drawing.Size(374, 17);
            this.lblLengthLabel.TabIndex = 1;
            this.lblLengthLabel.Text = "Comments Length (Excluding default 8000 / 8500 comments): ";
            // 
            // btnRefresh
            // 
            this.btnRefresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRefresh.Image = global::IndxReactNarr.Properties.Resources.refresh;
            this.btnRefresh.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRefresh.Location = new System.Drawing.Point(675, 8);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(83, 26);
            this.btnRefresh.TabIndex = 1;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRefresh.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSubmit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSubmit.Location = new System.Drawing.Point(776, 8);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(87, 26);
            this.btnSubmit.TabIndex = 0;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // colTC_ID
            // 
            this.colTC_ID.HeaderText = "TC_ID";
            this.colTC_ID.Name = "colTC_ID";
            this.colTC_ID.ReadOnly = true;
            this.colTC_ID.Visible = false;
            // 
            // colComments
            // 
            this.colComments.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.colComments.DefaultCellStyle = dataGridViewCellStyle2;
            this.colComments.HeaderText = "Comment";
            this.colComments.Name = "colComments";
            this.colComments.ReadOnly = true;
            this.colComments.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colCommentsType
            // 
            this.colCommentsType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colCommentsType.HeaderText = "Comment Type";
            this.colCommentsType.Name = "colCommentsType";
            this.colCommentsType.ReadOnly = true;
            this.colCommentsType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colCommentsType.Width = 150;
            // 
            // colCommentsLength
            // 
            this.colCommentsLength.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colCommentsLength.HeaderText = "Length";
            this.colCommentsLength.Name = "colCommentsLength";
            this.colCommentsLength.ReadOnly = true;
            this.colCommentsLength.Width = 50;
            // 
            // colDelete
            // 
            this.colDelete.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colDelete.HeaderText = "Delete";
            this.colDelete.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.colDelete.Name = "colDelete";
            this.colDelete.ReadOnly = true;
            this.colDelete.Text = "Delete";
            this.colDelete.ToolTipText = "Delete Comment";
            this.colDelete.UseColumnTextForLinkValue = true;
            this.colDelete.Width = 80;
            // 
            // frmComments_New
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(871, 568);
            this.Controls.Add(this.pnlMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmComments_New";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Comments";
            this.Load += new System.EventHandler(this.frmComments_New_Load);
            this.pnlMain.ResumeLayout(false);
            this.splcntMain.Panel1.ResumeLayout(false);
            this.splcntMain.Panel2.ResumeLayout(false);
            this.splcntMain.ResumeLayout(false);
            this.tcComments.ResumeLayout(false);
            this.tpIndexError.ResumeLayout(false);
            this.pnlIE.ResumeLayout(false);
            this.pnlIE.PerformLayout();
            this.pnlBottom_IE.ResumeLayout(false);
            this.tpAuthorError.ResumeLayout(false);
            this.pnlAE.ResumeLayout(false);
            this.pnlAE.PerformLayout();
            this.pnlBottom_AE.ResumeLayout(false);
            this.tpOtherComment.ResumeLayout(false);
            this.tpOtherComment.PerformLayout();
            this.pnlBottom_OC.ResumeLayout(false);
            this.tpTemperature.ResumeLayout(false);
            this.tpTemperature.PerformLayout();
            this.tpCASConsulted.ResumeLayout(false);
            this.tpCASConsulted.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvComments)).EndInit();
            this.pnlSubmit.ResumeLayout(false);
            this.pnlSubmit.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.SplitContainer splcntMain;
        private System.Windows.Forms.DataGridView dgvComments;
        private System.Windows.Forms.TextBox txtCASComment;
        private System.Windows.Forms.TextBox txtOtherComment;
        private System.Windows.Forms.TabControl tcComments;
        private System.Windows.Forms.TabPage tpIndexError;
        private System.Windows.Forms.TabPage tpAuthorError;
        private System.Windows.Forms.TabPage tpOtherComment;
        private System.Windows.Forms.TabPage tpCASConsulted;
        private System.Windows.Forms.Panel pnlAE;
        private System.Windows.Forms.CheckBox chkCorrected_AE;
        private System.Windows.Forms.TextBox txtNUM_AE;
        private System.Windows.Forms.Label lblComment_AE;
        private System.Windows.Forms.TextBox txtComment_AE;
        private System.Windows.Forms.TextBox txtFootNote_AE;
        private System.Windows.Forms.Label lblFootNote_AE;
        private System.Windows.Forms.TextBox txtColumn_AE;
        private System.Windows.Forms.Label lblColumn_AE;
        private System.Windows.Forms.TextBox txtScheme_AE;
        private System.Windows.Forms.Label lblScheme_AE;
        private System.Windows.Forms.TextBox txtTable_AE;
        private System.Windows.Forms.Label lblTable_AE;
        private System.Windows.Forms.Button btnClear_AE;
        private System.Windows.Forms.TextBox txtSheet_AE;
        private System.Windows.Forms.Label lblSheet_AE;
        private System.Windows.Forms.TextBox txtFigure_AE;
        private System.Windows.Forms.Label lblPage_AE;
        private System.Windows.Forms.Label lblFigure_AE;
        private System.Windows.Forms.TextBox txtPage_AE;
        private System.Windows.Forms.TextBox txtPara_AE;
        private System.Windows.Forms.Label lblLine_AE;
        private System.Windows.Forms.Label lblPara_AE;
        private System.Windows.Forms.TextBox txtLine_AE;
        private System.Windows.Forms.Panel pnlIE;
        private System.Windows.Forms.Label lblNum_IE;
        private System.Windows.Forms.TextBox txtNUM_IE;
        private System.Windows.Forms.Label lblComment_IE;
        private System.Windows.Forms.TextBox txtComment_IE;
        private System.Windows.Forms.TextBox txtFootNote_IE;
        private System.Windows.Forms.Label lblFootNote_IE;
        private System.Windows.Forms.TextBox txtColumn_IE;
        private System.Windows.Forms.Label lblColumn_IE;
        private System.Windows.Forms.TextBox txtScheme_IE;
        private System.Windows.Forms.Label lblScheme_IE;
        private System.Windows.Forms.TextBox txtTable_IE;
        private System.Windows.Forms.Label lblTable_IE;
        private System.Windows.Forms.Button btnClear_IE;
        private System.Windows.Forms.TextBox txtSheet_IE;
        private System.Windows.Forms.Label lblSheet_IE;
        private System.Windows.Forms.TextBox txtFigure_IE;
        private System.Windows.Forms.Label lblPage_IE;
        private System.Windows.Forms.Label lblFigure_IE;
        private System.Windows.Forms.TextBox txtPage_IE;
        private System.Windows.Forms.TextBox txtPara_IE;
        private System.Windows.Forms.Label lblLine_IE;
        private System.Windows.Forms.Label lblPara_IE;
        private System.Windows.Forms.TextBox txtLine_IE;
        private System.Windows.Forms.TabPage tpTemperature;
        private System.Windows.Forms.RichTextBox rtxtTempCmts;
        private System.Windows.Forms.Label lblNum_AE;
        private System.Windows.Forms.Label lblNote_CASConsulted;
        private System.Windows.Forms.Panel pnlBottom_IE;
        private System.Windows.Forms.Button btnAddIECmnt;
        private System.Windows.Forms.Panel pnlBottom_AE;
        private System.Windows.Forms.Button btnAddAECmnt;
        private System.Windows.Forms.Panel pnlBottom_OC;
        private System.Windows.Forms.Button btnAddOtherCmnts;
        private System.Windows.Forms.Button btnCASCmnts;
        private System.Windows.Forms.Panel pnlSubmit;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Label lblDefCmnts;
        private System.Windows.Forms.TextBox txtDefaultComments;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Label lblComLength;
        private System.Windows.Forms.Label lblLengthLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTC_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colComments;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCommentsType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCommentsLength;
        private System.Windows.Forms.DataGridViewLinkColumn colDelete;
    }
}