﻿namespace IndxReactNarr
{
    partial class frmSubstMolImg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            MDL.Draw.Renderer.Preferences.DisplayPreferences displayPreferences1 = new MDL.Draw.Renderer.Preferences.DisplayPreferences();
            this.pbMolImage = new System.Windows.Forms.PictureBox();
            this.ChemRenditor = new MDL.Draw.Renditor.Renditor();
            ((System.ComponentModel.ISupportInitialize)(this.pbMolImage)).BeginInit();
            this.SuspendLayout();
            // 
            // pbMolImage
            // 
            this.pbMolImage.BackColor = System.Drawing.Color.White;
            this.pbMolImage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbMolImage.Location = new System.Drawing.Point(0, 0);
            this.pbMolImage.Name = "pbMolImage";
            this.pbMolImage.Size = new System.Drawing.Size(460, 353);
            this.pbMolImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMolImage.TabIndex = 1;
            this.pbMolImage.TabStop = false;
            // 
            // ChemRenditor
            // 
            this.ChemRenditor.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ChemRenditor.AutoSizeStructure = true;
            this.ChemRenditor.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.ChemRenditor.ChimeString = null;
            this.ChemRenditor.ClearingEnabled = true;
            this.ChemRenditor.CopyingEnabled = true;
            this.ChemRenditor.DisplayOnEmpty = null;
            this.ChemRenditor.EditingEnabled = true;
            this.ChemRenditor.FileName = null;
            this.ChemRenditor.HighlightInfo = null;
            this.ChemRenditor.IsBitmapFromOLE = true;
            this.ChemRenditor.Location = new System.Drawing.Point(12, 12);
            this.ChemRenditor.Metafile = null;
            this.ChemRenditor.Molecule = null;
            this.ChemRenditor.MolfileString = null;
            this.ChemRenditor.Name = "ChemRenditor";
            this.ChemRenditor.OldScalingMode = MDL.Draw.Renderer.Preferences.StructureScalingMode.ScaleToFitBox;
            this.ChemRenditor.PastingEnabled = true;
            this.ChemRenditor.Preferences = displayPreferences1;
            this.ChemRenditor.PreferencesFileName = "default.xml";
            this.ChemRenditor.RendererBorderStyle = System.Windows.Forms.ButtonBorderStyle.Inset;
            this.ChemRenditor.RenditorMolecule = null;
            this.ChemRenditor.RenditorName = "Demo Renditor";
            this.ChemRenditor.Size = new System.Drawing.Size(436, 329);
            this.ChemRenditor.SketchString = null;
            this.ChemRenditor.SmilesString = null;
            this.ChemRenditor.TabIndex = 39;
            this.ChemRenditor.URLEncodedMolfileString = null;
            this.ChemRenditor.UseLocalXMLConfig = false;
            this.ChemRenditor.Visible = false;
            // 
            // frmSubstMolImg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(460, 353);
            this.Controls.Add(this.pbMolImage);
            this.Controls.Add(this.ChemRenditor);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSubstMolImg";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Substance Molecule";
            this.Load += new System.EventHandler(this.frmSubstMolImg_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbMolImage)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbMolImage;
        private MDL.Draw.Renditor.Renditor ChemRenditor;
    }
}