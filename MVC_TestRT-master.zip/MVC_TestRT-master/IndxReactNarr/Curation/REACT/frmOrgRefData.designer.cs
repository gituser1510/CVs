﻿namespace IndxReactNarr
{
    partial class frmOrgRefData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            MDL.Draw.Chemistry.Molecule molecule1 = new MDL.Draw.Chemistry.Molecule();
            MDL.Draw.Renderer.Preferences.DisplayPreferences displayPreferences1 = new MDL.Draw.Renderer.Preferences.DisplayPreferences();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.renderer1 = new MDL.Draw.Renderer.Renderer();
            this.dgvOrgRef = new System.Windows.Forms.DataGridView();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.txtNrnReg = new System.Windows.Forms.TextBox();
            this.lblNrnReg = new System.Windows.Forms.Label();
            this.txtNrnNum = new System.Windows.Forms.TextBox();
            this.lblNrnNum = new System.Windows.Forms.Label();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNUM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRegNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMolFile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrgRef)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.renderer1);
            this.pnlMain.Controls.Add(this.dgvOrgRef);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1127, 537);
            this.pnlMain.TabIndex = 0;
            // 
            // renderer1
            // 
            this.renderer1.AutoSizeStructure = true;
            this.renderer1.BinHexSketch = "010300044122001F4372656174656420627920416363656C7279734472617720342E312E312E34020" +
    "40000005805000000005905000000000B0B0005417269616C780000140200";
            this.renderer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.renderer1.ChimeString = null;
            this.renderer1.CopyingEnabled = true;
            this.renderer1.DisplayOnEmpty = null;
            this.renderer1.Dock = System.Windows.Forms.DockStyle.Right;
            this.renderer1.FileName = null;
            this.renderer1.HighlightInfo = "";
            this.renderer1.IsBitmapFromOLE = false;
            this.renderer1.Location = new System.Drawing.Point(767, 35);
            molecule1.ArrowDir = MDL.Draw.ArrowDirType.No;
            molecule1.ArrowStyle = MDL.Draw.ArrowStyleType.Empty;
            molecule1.AtomValenceDisplay = true;
            molecule1.BaseFormBoxSetting = 0;
            molecule1.BondLineThickness = 0D;
            molecule1.CarbonLabelDisplay = false;
            molecule1.ChemLabelFont = null;
            molecule1.ChemLabelFontString = "(none)";
            molecule1.ColorAtomsByTypeInSketch = false;
            molecule1.ConfigLabelFont = null;
            molecule1.ConfigLabelFontString = "(none)";
            molecule1.ConvertRingBondIntoOneToMany = true;
            molecule1.Coords = null;
            molecule1.DashSpacing = 0.1D;
            molecule1.DisplaySinCys = false;
            molecule1.DisplaySulfurInCysSequence = false;
            molecule1.DoubleBondWidth = 0.18D;
            molecule1.FillColor = System.Drawing.Color.Empty;
            molecule1.FillStyle = MDL.Draw.ChemGraphicsObject.FillStyles.SOLID;
            molecule1.ForeColor = System.Drawing.Color.Empty;
            molecule1.ForeColorString = "";
            molecule1.ForSubsequenceQuery = false;
            molecule1.HighlightChildren = "";
            molecule1.HighlightColor = System.Drawing.Color.Blue;
            molecule1.HydrogenDisplayMode = MDL.Draw.Chemistry.Atom.HydrogenDisplayMode.Off;
            molecule1.Id = 1543;
            molecule1.Initial = "";
            molecule1.IsAModel = false;
            molecule1.IsARotatedModel = false;
            molecule1.KeepRSLabelsInSketch = true;
            molecule1.LastModifyChemText = -1;
            molecule1.MaintainXMLChildOrderFlag = false;
            molecule1.MustPerceiveStereo = true;
            molecule1.PenColor = System.Drawing.Color.Empty;
            molecule1.PenStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            molecule1.PenStyleToken = 0;
            molecule1.PenWidth = ((byte)(0));
            molecule1.PenWidthUnit = MDL.Draw.ChemGraphicsObject.PenWidthUnits.Default;
            molecule1.RefId = 1543;
            molecule1.Replaced = false;
            molecule1.RgroupCleeanUpNeeded = false;
            molecule1.RgroupLabelsPresentFlag = false;
            molecule1.RLabelAtAbsCenter = "R";
            molecule1.RLabelAtAndCenter = "R*";
            molecule1.RLabelAtOrCenter = "(R)";
            molecule1.ScaleLabelsToBondLength = false;
            molecule1.Selected = false;
            molecule1.SequenceDictionary = null;
            molecule1.SequenceNeedsRealign = false;
            molecule1.SequenceView = MDL.Draw.Chemistry.Molecule.SequenceViewEnum.None;
            molecule1.Size = 0;
            molecule1.SkcWritten = false;
            molecule1.SkNumber = ((short)(0));
            molecule1.SLabelAtAbsCenter = "S";
            molecule1.SLabelAtAndCenter = "S*";
            molecule1.SLabelAtOrCenter = "(S)";
            molecule1.StandardBondLength = 0D;
            molecule1.StereoChemistryMode = MDL.Draw.Chemistry.Molecule.StereoChemistryModeEnum.And;
            molecule1.TextBorder = 0.1D;
            molecule1.Transparent = false;
            molecule1.UndoableEditListener = null;
            molecule1.WedgeWidth = 0.1D;
            molecule1.ZLayer = -98498;
            this.renderer1.Molecule = molecule1;
            this.renderer1.MolfileString = "";
            this.renderer1.Name = "renderer1";
            this.renderer1.PastingEnabled = true;
            this.renderer1.Preferences = displayPreferences1;
            this.renderer1.PreferencesFileName = "default.xml";
            this.renderer1.RendererBorderStyle = System.Windows.Forms.ButtonBorderStyle.Inset;
            this.renderer1.Size = new System.Drawing.Size(360, 502);
            this.renderer1.SketchString = "AQMABEEiAB9DcmVhdGVkIGJ5IEFjY2VscnlzRHJhdyA0LjEuMS40AgQAAABYBQAAAABZBQAAAAALCwAFQ" +
    "XJpYWx4AAAUAgA=";
            this.renderer1.SmilesString = "";
            this.renderer1.TabIndex = 8;
            this.renderer1.URLEncodedMolfileString = "";
            // 
            // dgvOrgRef
            // 
            this.dgvOrgRef.AllowUserToAddRows = false;
            this.dgvOrgRef.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvOrgRef.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvOrgRef.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvOrgRef.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvOrgRef.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrgRef.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colNUM,
            this.colRegNo,
            this.colName,
            this.colMolFile});
            this.dgvOrgRef.Location = new System.Drawing.Point(0, 35);
            this.dgvOrgRef.Name = "dgvOrgRef";
            this.dgvOrgRef.ReadOnly = true;
            this.dgvOrgRef.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvOrgRef.Size = new System.Drawing.Size(767, 502);
            this.dgvOrgRef.TabIndex = 7;
            this.dgvOrgRef.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvOrgRef_RowEnter);
            this.dgvOrgRef.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgOrgRef_RowPostPaint);
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.txtName);
            this.pnlTop.Controls.Add(this.lblName);
            this.pnlTop.Controls.Add(this.txtNrnReg);
            this.pnlTop.Controls.Add(this.lblNrnReg);
            this.pnlTop.Controls.Add(this.txtNrnNum);
            this.pnlTop.Controls.Add(this.lblNrnNum);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1127, 35);
            this.pnlTop.TabIndex = 0;
            // 
            // txtName
            // 
            this.txtName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtName.BackColor = System.Drawing.Color.White;
            this.txtName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(379, 4);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(743, 25);
            this.txtName.TabIndex = 14;
            this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(333, 8);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(44, 17);
            this.lblName.TabIndex = 13;
            this.lblName.Text = "Name";
            // 
            // txtNrnReg
            // 
            this.txtNrnReg.BackColor = System.Drawing.Color.White;
            this.txtNrnReg.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNrnReg.Location = new System.Drawing.Point(215, 4);
            this.txtNrnReg.Name = "txtNrnReg";
            this.txtNrnReg.Size = new System.Drawing.Size(100, 25);
            this.txtNrnReg.TabIndex = 12;
            this.txtNrnReg.TextChanged += new System.EventHandler(this.txtNrnReg_TextChanged);
            // 
            // lblNrnReg
            // 
            this.lblNrnReg.AutoSize = true;
            this.lblNrnReg.Location = new System.Drawing.Point(163, 8);
            this.lblNrnReg.Name = "lblNrnReg";
            this.lblNrnReg.Size = new System.Drawing.Size(50, 17);
            this.lblNrnReg.TabIndex = 11;
            this.lblNrnReg.Text = "RegNo";
            // 
            // txtNrnNum
            // 
            this.txtNrnNum.BackColor = System.Drawing.Color.White;
            this.txtNrnNum.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNrnNum.Location = new System.Drawing.Point(50, 4);
            this.txtNrnNum.Name = "txtNrnNum";
            this.txtNrnNum.Size = new System.Drawing.Size(100, 25);
            this.txtNrnNum.TabIndex = 10;
            this.txtNrnNum.TextChanged += new System.EventHandler(this.txtNrnNum_TextChanged);
            // 
            // lblNrnNum
            // 
            this.lblNrnNum.AutoSize = true;
            this.lblNrnNum.Location = new System.Drawing.Point(4, 8);
            this.lblNrnNum.Name = "lblNrnNum";
            this.lblNrnNum.Size = new System.Drawing.Size(43, 17);
            this.lblNrnNum.TabIndex = 9;
            this.lblNrnNum.Text = "NUM";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "NUM";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "RegNo";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn3.HeaderText = "Name";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "MolFile";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Visible = false;
            // 
            // colNUM
            // 
            this.colNUM.HeaderText = "NUM";
            this.colNUM.Name = "colNUM";
            this.colNUM.ReadOnly = true;
            // 
            // colRegNo
            // 
            this.colRegNo.HeaderText = "RegNo";
            this.colRegNo.Name = "colRegNo";
            this.colRegNo.ReadOnly = true;
            // 
            // colName
            // 
            this.colName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colName.HeaderText = "Name";
            this.colName.Name = "colName";
            this.colName.ReadOnly = true;
            // 
            // colMolFile
            // 
            this.colMolFile.HeaderText = "MolFile";
            this.colMolFile.Name = "colMolFile";
            this.colMolFile.ReadOnly = true;
            this.colMolFile.Visible = false;
            // 
            // frmOrgRefData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1127, 537);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmOrgRefData";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "OrgRef Series 9000 Data";
            this.Load += new System.EventHandler(this.frmOrgRefData_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrgRef)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.TextBox txtNrnReg;
        private System.Windows.Forms.Label lblNrnReg;
        private System.Windows.Forms.TextBox txtNrnNum;
        private System.Windows.Forms.Label lblNrnNum;
        private System.Windows.Forms.DataGridView dgvOrgRef;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNUM;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRegNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMolFile;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private MDL.Draw.Renderer.Renderer renderer1;
    }
}