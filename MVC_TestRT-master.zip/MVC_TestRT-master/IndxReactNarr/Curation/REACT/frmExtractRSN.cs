﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using System.IO;
using System.Xml.Linq;
using System.Xml;
//using IndxReactNarr.CAS_XML;
using IndxReactNarr.Common;
using IndxReactNarrDAL;
using IndxReactNarrBll;
using IndxReactNarrBLL;
using System.Text.RegularExpressions;

namespace IndxReactNarr
{
    public partial class frmExtractRSN : Form
    {
        public frmExtractRSN()
        {
            InitializeComponent();
        }
        
        public DataTable RSNDATA_Xml
        { get; set; }

        public DataTable RSNDATA_DB
        { get; set; }

        private void btnBrowseXML_Click(object sender, EventArgs e)
        {
            try
            {
                openFileDialog1.Filter = "XML Files (*.xml)|*.xml";
                openFileDialog1.FilterIndex = 1;
                openFileDialog1.Title = "Select a file to open";
                openFileDialog1.FileName = "";
                openFileDialog1.ShowDialog();

                if (openFileDialog1.FileName != "")
                {
                    Cursor = Cursors.WaitCursor;

                    txtTAN.Text = "";
                    btnFind_Replace.Enabled = false;
                    btnUpdate.Enabled = false;
                    dgRSN_DB.DataSource = null;
                    RSNDATA_DB = null;
                    dgRSN_DB.Visible = false;

                    txtXmlFile.Text = openFileDialog1.FileName.Trim();
                    DataTable dtRSN = RSNOperations.ExtractRSNDetails(openFileDialog1.FileName.Trim());
                    if (dtRSN != null)
                    {
                        RSNDATA_Xml = dtRSN;

                        dgRSN_Xml.Visible = true;
                        dgRSN_DB.Visible = false;

                        dgRSN_Xml.DataSource = RSNDATA_Xml;
                        dgRSN_Xml.Columns["RSN_REACTION"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                        dgRSN_Xml.Columns["RSN_STAGE"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }

                    Cursor = Cursors.Default;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        } 

        private bool SaveAsSingleExcelFile(string _filepath)
        {
            try
            {
                if (_filepath.Trim() != "")
                {
                    StreamWriter sWriter;
                    sWriter = File.CreateText(_filepath);
                    StringBuilder objStrBlder = new StringBuilder();

                    int borderWidth = 1;

                    string boldTagStart = "<B>";
                    string boldTagEnd = "</B>";

                    objStrBlder.Append("<Table border=" + borderWidth + ">");

                    objStrBlder.Append("<TR>");

                    foreach (DataColumn oDataColumn in RSNDATA_Xml.Columns)
                    {
                        objStrBlder.Append("<TD>" + boldTagStart + oDataColumn.ColumnName + boldTagEnd + "</TD>");
                    }
                    objStrBlder.Append("</TR>");

                    foreach (DataRow oDataRow in RSNDATA_Xml.Rows)
                    {
                        objStrBlder.Append("<TR>");

                        foreach (DataColumn oDataColumn in RSNDATA_Xml.Columns)
                        {
                            if (oDataColumn.ColumnName.ToUpper() == "RSN_REACTION" || oDataColumn.ColumnName.ToUpper() == "RSN_STAGE")
                            {
                                string strCellData = oDataRow[oDataColumn.ColumnName].ToString();
                                if (strCellData.Trim() != "")
                                {
                                    objStrBlder.Append("<TD>" + "'" + strCellData + "'" + "</TD>");
                                }
                                else
                                {
                                    objStrBlder.Append("<TD>" + strCellData + "</TD>");
                                }
                            }
                            else
                            {
                                objStrBlder.Append("<TD>" + oDataRow[oDataColumn.ColumnName] + "</TD>");
                            }
                        }
                        objStrBlder.Append("</TR>");
                    }

                    objStrBlder.Append("</Table>");

                    sWriter.WriteLine(objStrBlder.ToString());
                    sWriter.Close();
                    return true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }
        
        private void frmExtractRSN_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;

                Cursor = Cursors.WaitCursor;

                //Get User Dictionary and bind to control
                DataTable dtUserDict = ReactDB.GetDictionaryTermsOnType("CVT");
                WriteDictFileAndBindToControl(dtUserDict);

                //if (Generic.GlobalVariables.RoleName.ToUpper() == "CURATOR" || Generic.GlobalVariables.RoleName.ToUpper() == "REVIEWER")
                //{
                //    txtTAN.Visible = false;
                //    cmbTANs.Visible = true;

                //    lblBatch.Visible = false;
                //    lblBNo.Visible = false;
                //    txtBatchName.Visible = false;
                //    txtBatchNo.Visible = false;
                //    btnGetBatchRSN.Visible = false;

                //    //Retrieve assigned TANs for the user based on userid,role
                //    DataTable dtAssignedTans = CASRxnDataAccess.GetUserAssignedTANs(Generic.GlobalVariables.URID, Generic.GlobalVariables.URID);
                //    if (dtAssignedTans != null)
                //    {
                //        if (dtAssignedTans.Rows.Count > 0)
                //        {
                //            cmbTANs.DataSource = dtAssignedTans;
                //            cmbTANs.DisplayMember = dtAssignedTans.Columns["TAN"].ColumnName.ToString();
                //            cmbTANs.SelectedIndex = 0;
                //        }
                //    }
                //}
                Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void WriteDictFileAndBindToControl(DataTable _user_dicttbl)
        {
            try
            {
                if (_user_dicttbl != null)
                {
                    if (_user_dicttbl.Rows.Count > 0)
                    {
                        string strFilepath = AppDomain.CurrentDomain.BaseDirectory +"UserDictFile.txt";

                        StreamWriter sWrtr = new StreamWriter(strFilepath);
                        for (int i = 0; i < _user_dicttbl.Rows.Count; i++)
                        {
                            if (_user_dicttbl.Rows[i][0].ToString().Trim() != "")
                            {
                                sWrtr.WriteLine(_user_dicttbl.Rows[i][0].ToString());
                            }
                        }
                        sWrtr.Close();
                        sWrtr.Dispose();

                        rapidSpellAsYouType1.UserDictionaryFile = strFilepath;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnSave_Exl_Click(object sender, EventArgs e)
        {
            try
            {
                saveFileDialog1.Filter = "XlS|*.xls";

                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    DataTable dtRSN = null;
                    if (dgRSN_Xml.Visible)
                    {
                        dtRSN = RSNDATA_Xml;
                    }
                    else if (dgRSN_DB.Visible)
                    {
                        dtRSN = RSNDATA_DB;
                    }
                    if (dtRSN != null)
                    {
                        if (dtRSN.Rows.Count > 0)
                        {
                            if (IndxReactNarr.Common.Export.Excel_FromDataTable(saveFileDialog1.FileName, dtRSN))
                            {
                                MessageBox.Show("Saved data successfully", "Save File", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                        else
                        {
                            MessageBox.Show("No Data is available to export","Extract RSN",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        MessageBox.Show("No Data is available to export", "Extract RSN", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       

        private void btnGet_Click(object sender, EventArgs e)
        {
            try
            {
                string strTAN = "";
                if (txtTAN.Visible)
                {
                    strTAN = txtTAN.Text.Trim();
                }
                else if (cmbTANs.Visible)
                {
                    if (cmbTANs.SelectedItem != null)
                    {
                        strTAN = cmbTANs.Text.Trim();
                    }
                }

                if (strTAN.Trim() != "")
                {
                    Cursor = Cursors.WaitCursor;
                    
                    txtBatchName.Text = "";
                    txtBatchNo.Text = "";

                    txtXmlFile.Text = "";
                    btnFind_Replace.Enabled = true;
                    btnUpdate.Enabled = true;
                    RSNDATA_Xml = null;
                    dgRSN_Xml.DataSource = null;
                    dgRSN_Xml.Visible = false;

                    DataTable dtRSN = ReactDB.Get_RSNDetails_On_TAN(strTAN.Trim());
                    BindDataToDBGrid(dtRSN);

                    Cursor = Cursors.Default;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindDataToDBGrid(DataTable dtrsntbl)
        {
            try
            {
                if (dtrsntbl != null)
                {
                    RSNDATA_DB = dtrsntbl;

                    dgRSN_Xml.Visible = false;
                    dgRSN_DB.Visible = true;

                    dgRSN_DB.AutoGenerateColumns = false;
                    dgRSN_DB.DataSource = RSNDATA_DB;

                    colRSNID.DataPropertyName = "RSN_ID";
                    colTAN.DataPropertyName ="TAN";
                    colSNo.DataPropertyName = "reaction_rank";
                    colProdNo.DataPropertyName = "product no";
                    colRxn_Seq.DataPropertyName = "RXN_SEQ";
                    colStage.DataPropertyName = "STAGE";
                    colCVT.DataPropertyName = "RSN_CVT";
                    colFreeText.DataPropertyName = "RSN_FREE_TEXT";
                    colRsnType.DataPropertyName = "rsn type";

                    dgRSN_DB.ReadOnly = false;
                    colTAN.ReadOnly = true;
                    colTAN.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                    colTAN.Width = 80;

                    colSNo.ReadOnly = true;
                    colSNo.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                    colSNo.Width = 50;

                    colProdNo.ReadOnly = true;
                    colProdNo.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                    colProdNo.Width = 70;

                    colRxn_Seq.ReadOnly = true;
                    colRxn_Seq.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                    colRxn_Seq.Width = 60;

                    colStage.ReadOnly = true;
                    dgRSN_DB.Columns["colStage"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                    dgRSN_DB.Columns["colStage"].Width = 50;

                    dgRSN_DB.Columns["colCVT"].ReadOnly = true;
                    dgRSN_DB.Columns["colCVT"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                    
                    dgRSN_DB.Columns["colFreeText"].ReadOnly = false;
                    dgRSN_DB.Columns["colFreeText"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                    dgRSN_DB.Columns["colFreeText"].DefaultCellStyle.BackColor = Color.LightYellow;
                    dgRSN_DB.Columns["colFreeText"].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                    dgRSN_DB.Columns["colFreeText"].Width = 380;

                    dgRSN_DB.Columns["colRSNType"].ReadOnly = true;
                    dgRSN_DB.Columns["colRSNType"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                    dgRSN_DB.Columns["colRSNType"].Width = 70;

                    //Auto Resize rows
                    for (int i = 0; i < dgRSN_DB.Rows.Count; i++)
                    {
                        dgRSN_DB.AutoResizeRow(i, DataGridViewAutoSizeRowMode.AllCells);
                    }
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public RxnSearchNoteArr GetRSNDetailsFromTable()
        {
            RxnSearchNoteArr rsnArr = null;
            try
            {
                //RSN details
                if (dgRSN_DB.Rows.Count > 0)
                {
                    rsnArr = new RxnSearchNoteArr();

                    List<int> lstRsnIDs = new List<int>();                    
                    List<string> lstFreeText = new List<string>();

                    for (int i = 0; i < dgRSN_DB.Rows.Count; i++)
                    {                      
                        lstRsnIDs.Add(Convert.ToInt32(dgRSN_DB.Rows[i].Cells[colRSNID.Name].Value.ToString()));
                        lstFreeText.Add(dgRSN_DB.Rows[i].Cells[colFreeText.Name].Value.ToString());                      
                    }

                    rsnArr.RSN_ID = lstRsnIDs;
                    rsnArr.FreeText = lstFreeText;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return rsnArr;
        }
     
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string strErrMsg = "";
                if (ValidateRSNStageNames(out strErrMsg))
                {
                    RxnSearchNoteArr rsnArr = GetRSNDetailsFromTable();
                    if (rsnArr != null && rsnArr.RSN_ID.Count > 0)
                   {
                       //ReactDB.Update_RSN_FreeText_On_RSNID(Convert.ToInt32(dtRSN.Rows[i]["RSN_ID"].ToString()), dtRSN.Rows[i]["RSN_FREE_TEXT"].ToString());

                       if (ReactDB.UpdateRSNFreeTextOnRSNID(rsnArr))
                       {
                           MessageBox.Show("RSN updates saved successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                       }
                   }
                }
                else
                {
                    MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                //DataTable dtRSN = null;
                //if (dgRSN_DB.Visible)
                //{
                //    dtRSN = RSNDATA_DB;
                //}
                //if (dtRSN != null)
                //{
                //    int intCntr = 0;
                //    if (dtRSN.Rows.Count > 0)
                //    {
                //        string strStageName = "";
                //        string strStages_Name = "";
                //        for (int i = 0; i < dtRSN.Rows.Count; i++)
                //        {
                //            strStageName = dtRSN.Rows[i]["stage"].ToString();
                //            strStageName = strStageName.Replace("stage", "stage ");
                //            strStages_Name = strStageName.Replace("stage", "stages");

                //            if (dtRSN.Rows[i]["rsn type"].ToString().ToUpper() == "STAGE")
                //            {
                //                if (dtRSN.Rows[i]["RSN_FREE_TEXT"].ToString().Contains(strStageName))
                //                {
                //                    ReactDB.Update_RSN_FreeText_On_RSNID(Convert.ToInt32(dtRSN.Rows[i]["RSN_ID"].ToString()), dtRSN.Rows[i]["RSN_FREE_TEXT"].ToString());
                //                    intCntr++;
                //                }
                //                else if (dtRSN.Rows[i]["RSN_FREE_TEXT"].ToString().Contains(strStages_Name))
                //                {
                //                    ReactDB.Update_RSN_FreeText_On_RSNID(Convert.ToInt32(dtRSN.Rows[i]["RSN_ID"].ToString()), dtRSN.Rows[i]["RSN_FREE_TEXT"].ToString());
                //                    intCntr++;
                //                }
                //                else if (dtRSN.Rows[i]["RSN_FREE_TEXT"].ToString().Contains(" (" + strStageName))
                //                {
                //                    ReactDB.Update_RSN_FreeText_On_RSNID(Convert.ToInt32(dtRSN.Rows[i]["RSN_ID"].ToString()), dtRSN.Rows[i]["RSN_FREE_TEXT"].ToString());
                //                    intCntr++;
                //                }
                //                else
                //                {
                //                    dgRSN_DB.CurrentCell = dgRSN_DB.Rows[i].Cells[colFreeText.Name];
                //                    MessageBox.Show("Mismatched stage name in the product: " + dtRSN.Rows[i]["product no"].ToString() + " and RXN_Seq: " + dtRSN.Rows[i]["rxn_seq"].ToString());
                //                    return;
                //                }
                //            }
                //            else if (dtRSN.Rows[i]["rsn type"].ToString().ToUpper() == "REACTION")
                //            {
                //                ReactDB.Update_RSN_FreeText_On_RSNID(Convert.ToInt32(dtRSN.Rows[i]["RSN_ID"].ToString()), dtRSN.Rows[i]["RSN_FREE_TEXT"].ToString());
                //                intCntr++;
                //            }
                //        }                        
                //    }
                //    if (intCntr > 0)
                //    {
                //        MessageBox.Show("RSN updates saved successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                //    }
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private bool ValidateRSNStageNames(out string errMsg)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                DataTable dtRSN = null;
                if (dgRSN_DB.Visible)
                {
                    dtRSN = RSNDATA_DB;
                }
                                
                 if (dtRSN != null && dtRSN.Rows.Count > 0)
                 {
                     string strStageName = "";
                     string strStages_Name = "";

                     for (int i = 0; i < dtRSN.Rows.Count; i++)
                     {
                         strStageName = dtRSN.Rows[i]["stage"].ToString();
                         strStageName = strStageName.Replace("stage", "stage ");
                         strStages_Name = strStageName.Replace("stage", "stages");

                         if (dtRSN.Rows[i]["rsn type"].ToString().ToUpper() == "STAGE")
                         {
                             if (!string.IsNullOrEmpty(dtRSN.Rows[i]["RSN_FREE_TEXT"].ToString().Trim()))
                             {
                                 if (dtRSN.Rows[i]["RSN_FREE_TEXT"].ToString().Contains(strStageName) ||
                                     dtRSN.Rows[i]["RSN_FREE_TEXT"].ToString().Contains(strStages_Name) ||
                                     dtRSN.Rows[i]["RSN_FREE_TEXT"].ToString().Contains(" (" + strStageName))
                                 {
                                     //Do nothing
                                 }
                                 else
                                 {
                                     strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Mismatched stage name in the TAN " + dtRSN.Rows[i]["tan"].ToString() + "product: " + dtRSN.Rows[i]["product no"].ToString() + " and RXN_Seq: " + dtRSN.Rows[i]["rxn_seq"].ToString();
                                     blStatus = false;
                                 }
                             }
                         }                         
                     }
                 }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsg = strErrMsg;
            return blStatus;
        }

        private void btnFind_Replace_Click(object sender, EventArgs e)
        {
            try
            {
                frmFind_Replace objFind_Replace = new frmFind_Replace();
                objFind_Replace.ExtractRSNfrm = this;
                objFind_Replace.ShowDialog();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgRSN_DB_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgRSN_DB.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgRSN_DB.Font);

                if (dgRSN_DB.RowHeadersWidth < (int)(size.Width + 20)) dgRSN_DB.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnGetBatchRSN_Click(object sender, EventArgs e)
        {
            try
            {      
                if (txtBatchName.Text.Trim() != "")
                {
                    Cursor = Cursors.WaitCursor;
                    
                    txtTAN.Text = "";

                    int intBatchNo = 0;
                    int.TryParse(txtBatchNo.Text.Trim(), out intBatchNo);

                    txtXmlFile.Text = "";
                    btnFind_Replace.Enabled = true;
                    btnUpdate.Enabled = true;
                    RSNDATA_Xml = null;
                    dgRSN_Xml.DataSource = null;
                    dgRSN_Xml.Visible = false;

                    DataTable dtRSN = ReactDB.Get_RSNDetails_On_BatchName_No(txtBatchName.Text.Trim(), intBatchNo);
                    BindDataToDBGrid(dtRSN);

                    Cursor = Cursors.Default;
                }
                else
                {
                    MessageBox.Show("Please enter Batch Name", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        
    }
}
