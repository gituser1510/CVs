﻿using IndxReactNarr.Common;
using System.Windows.Forms;
using System;

namespace IndxReactNarr
{
    partial class frmReactCuration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmReactCuration));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.splContPartpnts_RxnView = new System.Windows.Forms.SplitContainer();
            this.splContRxnTree_Partpnts = new System.Windows.Forms.SplitContainer();
            this.pnlRxnsTree = new System.Windows.Forms.Panel();
            this.tvReactions = new System.Windows.Forms.TreeView();
            this.pnlSearchRxn = new System.Windows.Forms.Panel();
            this.txtSrchProduct = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlProd_Stages = new System.Windows.Forms.Panel();
            this.tcStages = new System.Windows.Forms.TabControl();
            this.cntmnuTbStages = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.addStageAfterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.removeTabToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addStageBeforeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Stage1 = new System.Windows.Forms.TabPage();
            this.pnlProduct = new System.Windows.Forms.Panel();
            this.dgvProduct = new System.Windows.Forms.DataGridView();
            this.colRPPID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colProdSerNumID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colProdNumType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colProdNum = new System.Windows.Forms.DataGridViewLinkColumn();
            this.colProdRegNo = new System.Windows.Forms.DataGridViewLinkColumn();
            this.colProdYield = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colProdName = new System.Windows.Forms.DataGridViewLinkColumn();
            this.colDeleteProd = new System.Windows.Forms.DataGridViewImageColumn();
            this.lnkProduct = new System.Windows.Forms.LinkLabel();
            this.pnlButtons = new System.Windows.Forms.Panel();
            this.chkSkipValidations = new System.Windows.Forms.CheckBox();
            this.btnNumsExportToPdf = new System.Windows.Forms.Button();
            this.btnIndexingNUMs = new System.Windows.Forms.Button();
            this.btnRejectTAN = new System.Windows.Forms.Button();
            this.btnSrchNumSubst = new System.Windows.Forms.Button();
            this.btnTANComplete = new System.Windows.Forms.Button();
            this.lblRxnSaveMsg = new System.Windows.Forms.Label();
            this.btnExportToPdf = new System.Windows.Forms.Button();
            this.chkRxnComplete = new System.Windows.Forms.CheckBox();
            this.btnKeyWord = new System.Windows.Forms.Button();
            this.btnNumSearch = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnMng8000 = new System.Windows.Forms.Button();
            this.btnMng8500 = new System.Windows.Forms.Button();
            this.pnlTAN_Prod = new System.Windows.Forms.Panel();
            this.pnlRxns = new System.Windows.Forms.Panel();
            this.lblRxnSeqVal = new System.Windows.Forms.Label();
            this.lblProdNum = new System.Windows.Forms.Label();
            this.btnProdForm = new System.Windows.Forms.Button();
            this.lblRxnCnt = new System.Windows.Forms.Label();
            this.pnlNavigCntrls = new System.Windows.Forms.Panel();
            this.numGotoRecord = new System.Windows.Forms.NumericUpDown();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnFirst = new System.Windows.Forms.Button();
            this.btnAddRxn = new System.Windows.Forms.Button();
            this.btnDelReaction = new System.Windows.Forms.Button();
            this.lblrxn_seq = new System.Windows.Forms.Label();
            this.lblrxn_no = new System.Windows.Forms.Label();
            this.lblrxnnum = new System.Windows.Forms.Label();
            this.pnlTANInfo = new System.Windows.Forms.Panel();
            this.txtTANType = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lnkComments = new System.Windows.Forms.LinkLabel();
            this.txtBatchNo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAnalyst = new System.Windows.Forms.TextBox();
            this.txtTAN = new System.Windows.Forms.TextBox();
            this.lblCAN = new System.Windows.Forms.Label();
            this.lblAnalyst = new System.Windows.Forms.Label();
            this.txtCAN = new System.Windows.Forms.TextBox();
            this.lblTan = new System.Windows.Forms.Label();
            this.txtShipmentName = new System.Windows.Forms.TextBox();
            this.lblfilenum = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewLinkColumn1 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn2 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewLinkColumn3 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewLinkColumn4 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn5 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn6 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewImageColumn2 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewImageColumn3 = new System.Windows.Forms.DataGridViewImageColumn();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splContPartpnts_RxnView)).BeginInit();
            this.splContPartpnts_RxnView.Panel1.SuspendLayout();
            this.splContPartpnts_RxnView.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splContRxnTree_Partpnts)).BeginInit();
            this.splContRxnTree_Partpnts.Panel1.SuspendLayout();
            this.splContRxnTree_Partpnts.Panel2.SuspendLayout();
            this.splContRxnTree_Partpnts.SuspendLayout();
            this.pnlRxnsTree.SuspendLayout();
            this.pnlSearchRxn.SuspendLayout();
            this.pnlProd_Stages.SuspendLayout();
            this.tcStages.SuspendLayout();
            this.cntmnuTbStages.SuspendLayout();
            this.pnlProduct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProduct)).BeginInit();
            this.pnlButtons.SuspendLayout();
            this.pnlTAN_Prod.SuspendLayout();
            this.pnlRxns.SuspendLayout();
            this.pnlNavigCntrls.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numGotoRecord)).BeginInit();
            this.pnlTANInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.splContPartpnts_RxnView);
            this.pnlMain.Controls.Add(this.pnlButtons);
            this.pnlMain.Controls.Add(this.pnlTAN_Prod);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1148, 603);
            this.pnlMain.TabIndex = 3;
            // 
            // splContPartpnts_RxnView
            // 
            this.splContPartpnts_RxnView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContPartpnts_RxnView.Location = new System.Drawing.Point(0, 60);
            this.splContPartpnts_RxnView.Name = "splContPartpnts_RxnView";
            this.splContPartpnts_RxnView.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splContPartpnts_RxnView.Panel1
            // 
            this.splContPartpnts_RxnView.Panel1.Controls.Add(this.splContRxnTree_Partpnts);
            this.splContPartpnts_RxnView.Size = new System.Drawing.Size(1148, 520);
            this.splContPartpnts_RxnView.SplitterDistance = 258;
            this.splContPartpnts_RxnView.TabIndex = 49;
            // 
            // splContRxnTree_Partpnts
            // 
            this.splContRxnTree_Partpnts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContRxnTree_Partpnts.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splContRxnTree_Partpnts.Location = new System.Drawing.Point(0, 0);
            this.splContRxnTree_Partpnts.Name = "splContRxnTree_Partpnts";
            // 
            // splContRxnTree_Partpnts.Panel1
            // 
            this.splContRxnTree_Partpnts.Panel1.Controls.Add(this.pnlRxnsTree);
            // 
            // splContRxnTree_Partpnts.Panel2
            // 
            this.splContRxnTree_Partpnts.Panel2.Controls.Add(this.pnlProd_Stages);
            this.splContRxnTree_Partpnts.Size = new System.Drawing.Size(1148, 258);
            this.splContRxnTree_Partpnts.SplitterDistance = 158;
            this.splContRxnTree_Partpnts.TabIndex = 0;
            // 
            // pnlRxnsTree
            // 
            this.pnlRxnsTree.Controls.Add(this.tvReactions);
            this.pnlRxnsTree.Controls.Add(this.pnlSearchRxn);
            this.pnlRxnsTree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRxnsTree.Location = new System.Drawing.Point(0, 0);
            this.pnlRxnsTree.Name = "pnlRxnsTree";
            this.pnlRxnsTree.Size = new System.Drawing.Size(158, 258);
            this.pnlRxnsTree.TabIndex = 48;
            // 
            // tvReactions
            // 
            this.tvReactions.Cursor = System.Windows.Forms.Cursors.Default;
            this.tvReactions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvReactions.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tvReactions.ForeColor = System.Drawing.Color.Blue;
            this.tvReactions.HotTracking = true;
            this.tvReactions.Location = new System.Drawing.Point(0, 25);
            this.tvReactions.Name = "tvReactions";
            this.tvReactions.Size = new System.Drawing.Size(158, 233);
            this.tvReactions.TabIndex = 0;
            this.tvReactions.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvReactions_NodeMouseDoubleClick);
            // 
            // pnlSearchRxn
            // 
            this.pnlSearchRxn.Controls.Add(this.txtSrchProduct);
            this.pnlSearchRxn.Controls.Add(this.label2);
            this.pnlSearchRxn.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSearchRxn.Location = new System.Drawing.Point(0, 0);
            this.pnlSearchRxn.Name = "pnlSearchRxn";
            this.pnlSearchRxn.Size = new System.Drawing.Size(158, 25);
            this.pnlSearchRxn.TabIndex = 2;
            // 
            // txtSrchProduct
            // 
            this.txtSrchProduct.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSrchProduct.BackColor = System.Drawing.Color.AntiqueWhite;
            this.txtSrchProduct.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSrchProduct.Location = new System.Drawing.Point(97, 2);
            this.txtSrchProduct.Name = "txtSrchProduct";
            this.txtSrchProduct.Size = new System.Drawing.Size(58, 21);
            this.txtSrchProduct.TabIndex = 1;
            this.txtSrchProduct.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSrchProduct_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(1, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 16);
            this.label2.TabIndex = 203;
            this.label2.Text = "Srch RXN NUM";
            // 
            // pnlProd_Stages
            // 
            this.pnlProd_Stages.Controls.Add(this.tcStages);
            this.pnlProd_Stages.Controls.Add(this.pnlProduct);
            this.pnlProd_Stages.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlProd_Stages.Location = new System.Drawing.Point(0, 0);
            this.pnlProd_Stages.Name = "pnlProd_Stages";
            this.pnlProd_Stages.Size = new System.Drawing.Size(986, 258);
            this.pnlProd_Stages.TabIndex = 40;
            // 
            // tcStages
            // 
            this.tcStages.ContextMenuStrip = this.cntmnuTbStages;
            this.tcStages.Controls.Add(this.Stage1);
            this.tcStages.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcStages.HotTrack = true;
            this.tcStages.Location = new System.Drawing.Point(0, 82);
            this.tcStages.Name = "tcStages";
            this.tcStages.SelectedIndex = 0;
            this.tcStages.Size = new System.Drawing.Size(986, 176);
            this.tcStages.TabIndex = 9;
            // 
            // cntmnuTbStages
            // 
            this.cntmnuTbStages.BackColor = System.Drawing.Color.WhiteSmoke;
            this.cntmnuTbStages.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addStageAfterToolStripMenuItem,
            this.removeTabToolStripMenuItem,
            this.addStageBeforeToolStripMenuItem});
            this.cntmnuTbStages.Name = "ctmenutab";
            this.cntmnuTbStages.Size = new System.Drawing.Size(193, 70);
            this.cntmnuTbStages.Opening += new System.ComponentModel.CancelEventHandler(this.cntmnuTbStages_Opening);
            // 
            // addStageAfterToolStripMenuItem
            // 
            this.addStageAfterToolStripMenuItem.Name = "addStageAfterToolStripMenuItem";
            this.addStageAfterToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5;
            this.addStageAfterToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.addStageAfterToolStripMenuItem.Text = "Add Stage";
            this.addStageAfterToolStripMenuItem.ToolTipText = "Add Tab";
            this.addStageAfterToolStripMenuItem.Click += new System.EventHandler(this.addStageAfterToolStripMenuItem_Click);
            // 
            // removeTabToolStripMenuItem
            // 
            this.removeTabToolStripMenuItem.Name = "removeTabToolStripMenuItem";
            this.removeTabToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.removeTabToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.removeTabToolStripMenuItem.Text = "Remove Stage";
            this.removeTabToolStripMenuItem.Click += new System.EventHandler(this.removeTabToolStripMenuItem_Click);
            // 
            // addStageBeforeToolStripMenuItem
            // 
            this.addStageBeforeToolStripMenuItem.Name = "addStageBeforeToolStripMenuItem";
            this.addStageBeforeToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F6;
            this.addStageBeforeToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.addStageBeforeToolStripMenuItem.Text = "Add Stage - Before";
            this.addStageBeforeToolStripMenuItem.Click += new System.EventHandler(this.addStageBeforeToolStripMenuItem_Click);
            // 
            // Stage1
            // 
            this.Stage1.BackColor = System.Drawing.Color.White;
            this.Stage1.Location = new System.Drawing.Point(4, 23);
            this.Stage1.Name = "Stage1";
            this.Stage1.Size = new System.Drawing.Size(978, 149);
            this.Stage1.TabIndex = 0;
            this.Stage1.Text = "Stage1";
            this.Stage1.UseVisualStyleBackColor = true;
            // 
            // pnlProduct
            // 
            this.pnlProduct.BackColor = System.Drawing.Color.White;
            this.pnlProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlProduct.Controls.Add(this.dgvProduct);
            this.pnlProduct.Controls.Add(this.lnkProduct);
            this.pnlProduct.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlProduct.Location = new System.Drawing.Point(0, 0);
            this.pnlProduct.Name = "pnlProduct";
            this.pnlProduct.Size = new System.Drawing.Size(986, 82);
            this.pnlProduct.TabIndex = 36;
            // 
            // dgvProduct
            // 
            this.dgvProduct.AllowUserToAddRows = false;
            this.dgvProduct.AllowUserToDeleteRows = false;
            this.dgvProduct.AllowUserToResizeRows = false;
            this.dgvProduct.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvProduct.BackgroundColor = System.Drawing.Color.LightGray;
            this.dgvProduct.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvProduct.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Maroon;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvProduct.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProduct.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colRPPID,
            this.colProdSerNumID,
            this.colProdNumType,
            this.colProdNum,
            this.colProdRegNo,
            this.colProdYield,
            this.colProdName,
            this.colDeleteProd});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FloralWhite;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvProduct.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgvProduct.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvProduct.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvProduct.Location = new System.Drawing.Point(0, 16);
            this.dgvProduct.MultiSelect = false;
            this.dgvProduct.Name = "dgvProduct";
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.dgvProduct.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvProduct.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvProduct.Size = new System.Drawing.Size(984, 64);
            this.dgvProduct.TabIndex = 8;
            this.dgvProduct.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProduct_CellContentClick);
            this.dgvProduct.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProduct_CellDoubleClick);
            this.dgvProduct.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgProduct_CellEnter);
            this.dgvProduct.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgProduct_EditingControlShowing);
            this.dgvProduct.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgProduct_RowPostPaint);
            // 
            // colRPPID
            // 
            this.colRPPID.HeaderText = "RPPID";
            this.colRPPID.Name = "colRPPID";
            this.colRPPID.ReadOnly = true;
            this.colRPPID.Visible = false;
            // 
            // colProdSerNumID
            // 
            this.colProdSerNumID.HeaderText = "SerNUMID";
            this.colProdSerNumID.Name = "colProdSerNumID";
            this.colProdSerNumID.ReadOnly = true;
            this.colProdSerNumID.Visible = false;
            // 
            // colProdNumType
            // 
            this.colProdNumType.HeaderText = "NumType";
            this.colProdNumType.Name = "colProdNumType";
            this.colProdNumType.ReadOnly = true;
            this.colProdNumType.Visible = false;
            // 
            // colProdNum
            // 
            this.colProdNum.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.NullValue = "0";
            this.colProdNum.DefaultCellStyle = dataGridViewCellStyle2;
            this.colProdNum.HeaderText = "Num";
            this.colProdNum.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.colProdNum.LinkColor = System.Drawing.Color.Red;
            this.colProdNum.Name = "colProdNum";
            this.colProdNum.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colProdNum.TrackVisitedState = false;
            this.colProdNum.Width = 55;
            // 
            // colProdRegNo
            // 
            this.colProdRegNo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle3.NullValue = "0";
            this.colProdRegNo.DefaultCellStyle = dataGridViewCellStyle3;
            this.colProdRegNo.HeaderText = "RegNo";
            this.colProdRegNo.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.colProdRegNo.Name = "colProdRegNo";
            this.colProdRegNo.ReadOnly = true;
            this.colProdRegNo.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colProdRegNo.TrackVisitedState = false;
            this.colProdRegNo.Width = 87;
            // 
            // colProdYield
            // 
            this.colProdYield.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colProdYield.HeaderText = "Yield";
            this.colProdYield.Name = "colProdYield";
            this.colProdYield.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colProdYield.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colProdYield.Width = 50;
            // 
            // colProdName
            // 
            this.colProdName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colProdName.HeaderText = "Name";
            this.colProdName.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.colProdName.Name = "colProdName";
            this.colProdName.ReadOnly = true;
            this.colProdName.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colDeleteProd
            // 
            this.colDeleteProd.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colDeleteProd.HeaderText = "";
            this.colDeleteProd.Image = global::IndxReactNarr.Properties.Resources.delete_row;
            this.colDeleteProd.Name = "colDeleteProd";
            this.colDeleteProd.ToolTipText = "Delete Product";
            this.colDeleteProd.Width = 30;
            // 
            // lnkProduct
            // 
            this.lnkProduct.AutoSize = true;
            this.lnkProduct.Dock = System.Windows.Forms.DockStyle.Top;
            this.lnkProduct.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkProduct.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkProduct.Location = new System.Drawing.Point(0, 0);
            this.lnkProduct.Name = "lnkProduct";
            this.lnkProduct.Size = new System.Drawing.Size(65, 16);
            this.lnkProduct.TabIndex = 9;
            this.lnkProduct.TabStop = true;
            this.lnkProduct.Text = "Product +";
            this.lnkProduct.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkProduct_LinkClicked);
            // 
            // pnlButtons
            // 
            this.pnlButtons.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlButtons.Controls.Add(this.chkSkipValidations);
            this.pnlButtons.Controls.Add(this.btnNumsExportToPdf);
            this.pnlButtons.Controls.Add(this.btnIndexingNUMs);
            this.pnlButtons.Controls.Add(this.btnRejectTAN);
            this.pnlButtons.Controls.Add(this.btnSrchNumSubst);
            this.pnlButtons.Controls.Add(this.btnTANComplete);
            this.pnlButtons.Controls.Add(this.lblRxnSaveMsg);
            this.pnlButtons.Controls.Add(this.btnExportToPdf);
            this.pnlButtons.Controls.Add(this.chkRxnComplete);
            this.pnlButtons.Controls.Add(this.btnKeyWord);
            this.pnlButtons.Controls.Add(this.btnNumSearch);
            this.pnlButtons.Controls.Add(this.btnSave);
            this.pnlButtons.Controls.Add(this.btnMng8000);
            this.pnlButtons.Controls.Add(this.btnMng8500);
            this.pnlButtons.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlButtons.Location = new System.Drawing.Point(0, 580);
            this.pnlButtons.Name = "pnlButtons";
            this.pnlButtons.Size = new System.Drawing.Size(1148, 23);
            this.pnlButtons.TabIndex = 47;
            // 
            // chkSkipValidations
            // 
            this.chkSkipValidations.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.chkSkipValidations.AutoSize = true;
            this.chkSkipValidations.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkSkipValidations.ForeColor = System.Drawing.Color.Blue;
            this.chkSkipValidations.Location = new System.Drawing.Point(687, 3);
            this.chkSkipValidations.Name = "chkSkipValidations";
            this.chkSkipValidations.Size = new System.Drawing.Size(101, 18);
            this.chkSkipValidations.TabIndex = 58;
            this.chkSkipValidations.Text = "Skip Validations";
            this.chkSkipValidations.UseVisualStyleBackColor = true;
            this.chkSkipValidations.Visible = false;
            this.chkSkipValidations.CheckStateChanged += new System.EventHandler(this.chkSkipValidations_CheckStateChanged);
            // 
            // btnNumsExportToPdf
            // 
            this.btnNumsExportToPdf.ForeColor = System.Drawing.Color.Black;
            this.btnNumsExportToPdf.Image = global::IndxReactNarr.Properties.Resources.file_extension_pdf;
            this.btnNumsExportToPdf.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNumsExportToPdf.Location = new System.Drawing.Point(369, 0);
            this.btnNumsExportToPdf.Name = "btnNumsExportToPdf";
            this.btnNumsExportToPdf.Size = new System.Drawing.Size(60, 24);
            this.btnNumsExportToPdf.TabIndex = 57;
            this.btnNumsExportToPdf.Text = "NUMs";
            this.btnNumsExportToPdf.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNumsExportToPdf.UseVisualStyleBackColor = true;
            this.btnNumsExportToPdf.Click += new System.EventHandler(this.btnNumsExportToPdf_Click);
            // 
            // btnIndexingNUMs
            // 
            this.btnIndexingNUMs.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIndexingNUMs.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIndexingNUMs.ForeColor = System.Drawing.Color.Black;
            this.btnIndexingNUMs.Location = new System.Drawing.Point(509, 0);
            this.btnIndexingNUMs.Name = "btnIndexingNUMs";
            this.btnIndexingNUMs.Size = new System.Drawing.Size(74, 24);
            this.btnIndexingNUMs.TabIndex = 56;
            this.btnIndexingNUMs.Text = "Index NUMs";
            this.btnIndexingNUMs.UseVisualStyleBackColor = true;
            this.btnIndexingNUMs.Click += new System.EventHandler(this.btnIndexingNUMs_Click);
            // 
            // btnRejectTAN
            // 
            this.btnRejectTAN.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRejectTAN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRejectTAN.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRejectTAN.ForeColor = System.Drawing.Color.Black;
            this.btnRejectTAN.Location = new System.Drawing.Point(906, 0);
            this.btnRejectTAN.Name = "btnRejectTAN";
            this.btnRejectTAN.Size = new System.Drawing.Size(74, 24);
            this.btnRejectTAN.TabIndex = 55;
            this.btnRejectTAN.Text = "TAN Reject";
            this.btnRejectTAN.UseVisualStyleBackColor = true;
            this.btnRejectTAN.Click += new System.EventHandler(this.btnRejectTAN_Click);
            // 
            // btnSrchNumSubst
            // 
            this.btnSrchNumSubst.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSrchNumSubst.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSrchNumSubst.ForeColor = System.Drawing.Color.Black;
            this.btnSrchNumSubst.Location = new System.Drawing.Point(311, 0);
            this.btnSrchNumSubst.Name = "btnSrchNumSubst";
            this.btnSrchNumSubst.Size = new System.Drawing.Size(56, 24);
            this.btnSrchNumSubst.TabIndex = 54;
            this.btnSrchNumSubst.Text = "Search";
            this.btnSrchNumSubst.UseVisualStyleBackColor = true;
            this.btnSrchNumSubst.Click += new System.EventHandler(this.btnSrchNumSubst_Click);
            // 
            // btnTANComplete
            // 
            this.btnTANComplete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTANComplete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTANComplete.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTANComplete.ForeColor = System.Drawing.Color.Black;
            this.btnTANComplete.Location = new System.Drawing.Point(983, 0);
            this.btnTANComplete.Name = "btnTANComplete";
            this.btnTANComplete.Size = new System.Drawing.Size(89, 24);
            this.btnTANComplete.TabIndex = 53;
            this.btnTANComplete.Text = "TAN Complete";
            this.btnTANComplete.UseVisualStyleBackColor = true;
            this.btnTANComplete.Click += new System.EventHandler(this.btnTANComplete_Click);
            // 
            // lblRxnSaveMsg
            // 
            this.lblRxnSaveMsg.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblRxnSaveMsg.AutoSize = true;
            this.lblRxnSaveMsg.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnSaveMsg.ForeColor = System.Drawing.Color.Blue;
            this.lblRxnSaveMsg.Location = new System.Drawing.Point(573, 4);
            this.lblRxnSaveMsg.Name = "lblRxnSaveMsg";
            this.lblRxnSaveMsg.Size = new System.Drawing.Size(19, 15);
            this.lblRxnSaveMsg.TabIndex = 52;
            this.lblRxnSaveMsg.Text = "---";
            // 
            // btnExportToPdf
            // 
            this.btnExportToPdf.ForeColor = System.Drawing.Color.Black;
            this.btnExportToPdf.Image = global::IndxReactNarr.Properties.Resources.file_extension_pdf;
            this.btnExportToPdf.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExportToPdf.Location = new System.Drawing.Point(245, 0);
            this.btnExportToPdf.Name = "btnExportToPdf";
            this.btnExportToPdf.Size = new System.Drawing.Size(63, 24);
            this.btnExportToPdf.TabIndex = 51;
            this.btnExportToPdf.Text = "Rxns";
            this.btnExportToPdf.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExportToPdf.UseVisualStyleBackColor = true;
            this.btnExportToPdf.Click += new System.EventHandler(this.btnExportToPdf_Click);
            // 
            // chkRxnComplete
            // 
            this.chkRxnComplete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chkRxnComplete.AutoSize = true;
            this.chkRxnComplete.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkRxnComplete.ForeColor = System.Drawing.Color.Blue;
            this.chkRxnComplete.Location = new System.Drawing.Point(790, 3);
            this.chkRxnComplete.Name = "chkRxnComplete";
            this.chkRxnComplete.Size = new System.Drawing.Size(115, 18);
            this.chkRxnComplete.TabIndex = 50;
            this.chkRxnComplete.Text = "Reaction Complete";
            this.chkRxnComplete.UseVisualStyleBackColor = true;
            // 
            // btnKeyWord
            // 
            this.btnKeyWord.AutoSize = true;
            this.btnKeyWord.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKeyWord.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKeyWord.ForeColor = System.Drawing.Color.Black;
            this.btnKeyWord.Location = new System.Drawing.Point(174, 0);
            this.btnKeyWord.Name = "btnKeyWord";
            this.btnKeyWord.Size = new System.Drawing.Size(68, 24);
            this.btnKeyWord.TabIndex = 48;
            this.btnKeyWord.Text = "Keywords";
            this.btnKeyWord.UseVisualStyleBackColor = true;
            this.btnKeyWord.Click += new System.EventHandler(this.btnKeyWord_Click);
            // 
            // btnNumSearch
            // 
            this.btnNumSearch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNumSearch.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumSearch.ForeColor = System.Drawing.Color.Black;
            this.btnNumSearch.Location = new System.Drawing.Point(431, 0);
            this.btnNumSearch.Name = "btnNumSearch";
            this.btnNumSearch.Size = new System.Drawing.Size(75, 24);
            this.btnNumSearch.TabIndex = 15;
            this.btnNumSearch.Text = "NUM Search";
            this.btnNumSearch.UseVisualStyleBackColor = true;
            this.btnNumSearch.Click += new System.EventHandler(this.btnNumSearch_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.BackColor = System.Drawing.Color.Transparent;
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.Black;
            this.btnSave.Image = global::IndxReactNarr.Properties.Resources.save_1;
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(1077, 0);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(70, 24);
            this.btnSave.TabIndex = 14;
            this.btnSave.Text = "Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSaveNew_Click);
            // 
            // btnMng8000
            // 
            this.btnMng8000.AutoSize = true;
            this.btnMng8000.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMng8000.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMng8000.ForeColor = System.Drawing.Color.Black;
            this.btnMng8000.Location = new System.Drawing.Point(89, 0);
            this.btnMng8000.Name = "btnMng8000";
            this.btnMng8000.Size = new System.Drawing.Size(82, 24);
            this.btnMng8000.TabIndex = 11;
            this.btnMng8000.Text = "Manage 8000";
            this.btnMng8000.UseVisualStyleBackColor = true;
            this.btnMng8000.Click += new System.EventHandler(this.btnMng8000_Click);
            // 
            // btnMng8500
            // 
            this.btnMng8500.AutoSize = true;
            this.btnMng8500.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMng8500.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMng8500.ForeColor = System.Drawing.Color.Black;
            this.btnMng8500.Location = new System.Drawing.Point(3, 0);
            this.btnMng8500.Name = "btnMng8500";
            this.btnMng8500.Size = new System.Drawing.Size(82, 24);
            this.btnMng8500.TabIndex = 10;
            this.btnMng8500.Text = "Manage 8500";
            this.btnMng8500.UseVisualStyleBackColor = true;
            this.btnMng8500.Click += new System.EventHandler(this.btnMng8500_Click);
            // 
            // pnlTAN_Prod
            // 
            this.pnlTAN_Prod.AutoScroll = true;
            this.pnlTAN_Prod.BackColor = System.Drawing.Color.DarkGray;
            this.pnlTAN_Prod.Controls.Add(this.pnlRxns);
            this.pnlTAN_Prod.Controls.Add(this.pnlTANInfo);
            this.pnlTAN_Prod.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTAN_Prod.Location = new System.Drawing.Point(0, 0);
            this.pnlTAN_Prod.Name = "pnlTAN_Prod";
            this.pnlTAN_Prod.Size = new System.Drawing.Size(1148, 60);
            this.pnlTAN_Prod.TabIndex = 46;
            // 
            // pnlRxns
            // 
            this.pnlRxns.BackColor = System.Drawing.Color.White;
            this.pnlRxns.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlRxns.Controls.Add(this.lblRxnSeqVal);
            this.pnlRxns.Controls.Add(this.lblProdNum);
            this.pnlRxns.Controls.Add(this.btnProdForm);
            this.pnlRxns.Controls.Add(this.lblRxnCnt);
            this.pnlRxns.Controls.Add(this.pnlNavigCntrls);
            this.pnlRxns.Controls.Add(this.btnAddRxn);
            this.pnlRxns.Controls.Add(this.btnDelReaction);
            this.pnlRxns.Controls.Add(this.lblrxn_seq);
            this.pnlRxns.Controls.Add(this.lblrxn_no);
            this.pnlRxns.Controls.Add(this.lblrxnnum);
            this.pnlRxns.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRxns.Location = new System.Drawing.Point(0, 30);
            this.pnlRxns.Name = "pnlRxns";
            this.pnlRxns.Size = new System.Drawing.Size(1148, 30);
            this.pnlRxns.TabIndex = 39;
            // 
            // lblRxnSeqVal
            // 
            this.lblRxnSeqVal.AutoSize = true;
            this.lblRxnSeqVal.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnSeqVal.ForeColor = System.Drawing.Color.Red;
            this.lblRxnSeqVal.Location = new System.Drawing.Point(178, 6);
            this.lblRxnSeqVal.Name = "lblRxnSeqVal";
            this.lblRxnSeqVal.Size = new System.Drawing.Size(15, 16);
            this.lblRxnSeqVal.TabIndex = 48;
            this.lblRxnSeqVal.Text = "0";
            // 
            // lblProdNum
            // 
            this.lblProdNum.AutoSize = true;
            this.lblProdNum.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProdNum.ForeColor = System.Drawing.Color.Red;
            this.lblProdNum.Location = new System.Drawing.Point(67, 5);
            this.lblProdNum.Name = "lblProdNum";
            this.lblProdNum.Size = new System.Drawing.Size(15, 16);
            this.lblProdNum.TabIndex = 47;
            this.lblProdNum.Text = "0";
            // 
            // btnProdForm
            // 
            this.btnProdForm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnProdForm.AutoSize = true;
            this.btnProdForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProdForm.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnProdForm.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProdForm.Location = new System.Drawing.Point(511, 1);
            this.btnProdForm.Name = "btnProdForm";
            this.btnProdForm.Size = new System.Drawing.Size(95, 25);
            this.btnProdForm.TabIndex = 46;
            this.btnProdForm.Text = "View Reaction";
            this.btnProdForm.UseVisualStyleBackColor = true;
            this.btnProdForm.Click += new System.EventHandler(this.btnProdForm_Click);
            // 
            // lblRxnCnt
            // 
            this.lblRxnCnt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblRxnCnt.AutoSize = true;
            this.lblRxnCnt.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnCnt.ForeColor = System.Drawing.Color.Red;
            this.lblRxnCnt.Location = new System.Drawing.Point(862, 5);
            this.lblRxnCnt.Name = "lblRxnCnt";
            this.lblRxnCnt.Size = new System.Drawing.Size(16, 18);
            this.lblRxnCnt.TabIndex = 45;
            this.lblRxnCnt.Text = "0";
            // 
            // pnlNavigCntrls
            // 
            this.pnlNavigCntrls.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.pnlNavigCntrls.Controls.Add(this.numGotoRecord);
            this.pnlNavigCntrls.Controls.Add(this.btnLast);
            this.pnlNavigCntrls.Controls.Add(this.btnNext);
            this.pnlNavigCntrls.Controls.Add(this.btnPrevious);
            this.pnlNavigCntrls.Controls.Add(this.btnFirst);
            this.pnlNavigCntrls.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlNavigCntrls.Location = new System.Drawing.Point(932, 0);
            this.pnlNavigCntrls.Name = "pnlNavigCntrls";
            this.pnlNavigCntrls.Size = new System.Drawing.Size(212, 26);
            this.pnlNavigCntrls.TabIndex = 44;
            // 
            // numGotoRecord
            // 
            this.numGotoRecord.InterceptArrowKeys = false;
            this.numGotoRecord.Location = new System.Drawing.Point(84, 3);
            this.numGotoRecord.Name = "numGotoRecord";
            this.numGotoRecord.Size = new System.Drawing.Size(42, 20);
            this.numGotoRecord.TabIndex = 43;
            this.numGotoRecord.ValueChanged += new System.EventHandler(this.numGotoRecord_ValueChanged);
            this.numGotoRecord.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.numGotoRecord_KeyPress);
            // 
            // btnLast
            // 
            this.btnLast.BackgroundImage = global::IndxReactNarr.Properties.Resources.resultset_last;
            this.btnLast.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnLast.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLast.Enabled = false;
            this.btnLast.Location = new System.Drawing.Point(173, 0);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(35, 27);
            this.btnLast.TabIndex = 38;
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnNext
            // 
            this.btnNext.BackgroundImage = global::IndxReactNarr.Properties.Resources.resultset_next;
            this.btnNext.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnNext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNext.Enabled = false;
            this.btnNext.Location = new System.Drawing.Point(133, 0);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(35, 27);
            this.btnNext.TabIndex = 37;
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.BackgroundImage = global::IndxReactNarr.Properties.Resources.resultset_previous;
            this.btnPrevious.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnPrevious.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPrevious.Enabled = false;
            this.btnPrevious.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrevious.Location = new System.Drawing.Point(43, 0);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(35, 27);
            this.btnPrevious.TabIndex = 36;
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnFirst
            // 
            this.btnFirst.BackgroundImage = global::IndxReactNarr.Properties.Resources.resultset_first;
            this.btnFirst.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnFirst.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFirst.Enabled = false;
            this.btnFirst.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFirst.Location = new System.Drawing.Point(3, 0);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(35, 27);
            this.btnFirst.TabIndex = 35;
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // btnAddRxn
            // 
            this.btnAddRxn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddRxn.AutoSize = true;
            this.btnAddRxn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddRxn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnAddRxn.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddRxn.Location = new System.Drawing.Point(611, 1);
            this.btnAddRxn.Name = "btnAddRxn";
            this.btnAddRxn.Size = new System.Drawing.Size(94, 25);
            this.btnAddRxn.TabIndex = 6;
            this.btnAddRxn.Text = "New Reaction";
            this.btnAddRxn.UseVisualStyleBackColor = true;
            this.btnAddRxn.Click += new System.EventHandler(this.btnAddRxn_Click);
            // 
            // btnDelReaction
            // 
            this.btnDelReaction.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelReaction.AutoSize = true;
            this.btnDelReaction.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelReaction.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnDelReaction.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelReaction.Location = new System.Drawing.Point(709, 1);
            this.btnDelReaction.Name = "btnDelReaction";
            this.btnDelReaction.Size = new System.Drawing.Size(105, 25);
            this.btnDelReaction.TabIndex = 7;
            this.btnDelReaction.Text = "Delete Reaction";
            this.btnDelReaction.UseVisualStyleBackColor = true;
            this.btnDelReaction.Click += new System.EventHandler(this.btnDelReaction_Click);
            // 
            // lblrxn_seq
            // 
            this.lblrxn_seq.AutoSize = true;
            this.lblrxn_seq.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrxn_seq.ForeColor = System.Drawing.Color.Black;
            this.lblrxn_seq.Location = new System.Drawing.Point(114, 6);
            this.lblrxn_seq.Name = "lblrxn_seq";
            this.lblrxn_seq.Size = new System.Drawing.Size(57, 15);
            this.lblrxn_seq.TabIndex = 16;
            this.lblrxn_seq.Text = "RXN Seq";
            // 
            // lblrxn_no
            // 
            this.lblrxn_no.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblrxn_no.AutoSize = true;
            this.lblrxn_no.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrxn_no.ForeColor = System.Drawing.Color.Black;
            this.lblrxn_no.Location = new System.Drawing.Point(831, 7);
            this.lblrxn_no.Name = "lblrxn_no";
            this.lblrxn_no.Size = new System.Drawing.Size(28, 13);
            this.lblrxn_no.TabIndex = 14;
            this.lblrxn_no.Text = "RXN";
            // 
            // lblrxnnum
            // 
            this.lblrxnnum.AutoSize = true;
            this.lblrxnnum.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrxnnum.ForeColor = System.Drawing.Color.Black;
            this.lblrxnnum.Location = new System.Drawing.Point(3, 6);
            this.lblrxnnum.Name = "lblrxnnum";
            this.lblrxnnum.Size = new System.Drawing.Size(62, 15);
            this.lblrxnnum.TabIndex = 15;
            this.lblrxnnum.Text = "RXN NUM";
            // 
            // pnlTANInfo
            // 
            this.pnlTANInfo.BackColor = System.Drawing.Color.White;
            this.pnlTANInfo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlTANInfo.Controls.Add(this.txtTANType);
            this.pnlTANInfo.Controls.Add(this.label3);
            this.pnlTANInfo.Controls.Add(this.lnkComments);
            this.pnlTANInfo.Controls.Add(this.txtBatchNo);
            this.pnlTANInfo.Controls.Add(this.label1);
            this.pnlTANInfo.Controls.Add(this.txtAnalyst);
            this.pnlTANInfo.Controls.Add(this.txtTAN);
            this.pnlTANInfo.Controls.Add(this.lblCAN);
            this.pnlTANInfo.Controls.Add(this.lblAnalyst);
            this.pnlTANInfo.Controls.Add(this.txtCAN);
            this.pnlTANInfo.Controls.Add(this.lblTan);
            this.pnlTANInfo.Controls.Add(this.txtShipmentName);
            this.pnlTANInfo.Controls.Add(this.lblfilenum);
            this.pnlTANInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTANInfo.Location = new System.Drawing.Point(0, 0);
            this.pnlTANInfo.Name = "pnlTANInfo";
            this.pnlTANInfo.Size = new System.Drawing.Size(1148, 30);
            this.pnlTANInfo.TabIndex = 37;
            // 
            // txtTANType
            // 
            this.txtTANType.BackColor = System.Drawing.Color.SeaShell;
            this.txtTANType.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTANType.ForeColor = System.Drawing.Color.Black;
            this.txtTANType.Location = new System.Drawing.Point(590, 3);
            this.txtTANType.MaxLength = 6;
            this.txtTANType.Name = "txtTANType";
            this.txtTANType.ReadOnly = true;
            this.txtTANType.Size = new System.Drawing.Size(118, 21);
            this.txtTANType.TabIndex = 204;
            this.txtTANType.Text = "-";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(549, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 16);
            this.label3.TabIndex = 203;
            this.label3.Text = "Type";
            // 
            // lnkComments
            // 
            this.lnkComments.AutoSize = true;
            this.lnkComments.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lnkComments.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkComments.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkComments.LinkColor = System.Drawing.Color.Blue;
            this.lnkComments.Location = new System.Drawing.Point(714, 7);
            this.lnkComments.Name = "lnkComments";
            this.lnkComments.Size = new System.Drawing.Size(69, 15);
            this.lnkComments.TabIndex = 202;
            this.lnkComments.TabStop = true;
            this.lnkComments.Text = "Comments";
            this.lnkComments.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkComments_LinkClicked);
            // 
            // txtBatchNo
            // 
            this.txtBatchNo.BackColor = System.Drawing.Color.SeaShell;
            this.txtBatchNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtBatchNo.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBatchNo.ForeColor = System.Drawing.Color.Black;
            this.txtBatchNo.Location = new System.Drawing.Point(180, 3);
            this.txtBatchNo.MaxLength = 9;
            this.txtBatchNo.Name = "txtBatchNo";
            this.txtBatchNo.ReadOnly = true;
            this.txtBatchNo.Size = new System.Drawing.Size(32, 21);
            this.txtBatchNo.TabIndex = 1;
            this.txtBatchNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(143, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 16);
            this.label1.TabIndex = 201;
            this.label1.Text = "B.No";
            // 
            // txtAnalyst
            // 
            this.txtAnalyst.BackColor = System.Drawing.Color.SeaShell;
            this.txtAnalyst.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAnalyst.ForeColor = System.Drawing.Color.Black;
            this.txtAnalyst.Location = new System.Drawing.Point(480, 3);
            this.txtAnalyst.MaxLength = 6;
            this.txtAnalyst.Name = "txtAnalyst";
            this.txtAnalyst.ReadOnly = true;
            this.txtAnalyst.Size = new System.Drawing.Size(34, 21);
            this.txtAnalyst.TabIndex = 4;
            this.txtAnalyst.Text = "8001";
            this.txtAnalyst.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAnalyst_KeyPress);
            // 
            // txtTAN
            // 
            this.txtTAN.BackColor = System.Drawing.Color.SeaShell;
            this.txtTAN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTAN.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTAN.ForeColor = System.Drawing.Color.Black;
            this.txtTAN.Location = new System.Drawing.Point(240, 3);
            this.txtTAN.MaxLength = 9;
            this.txtTAN.Name = "txtTAN";
            this.txtTAN.ReadOnly = true;
            this.txtTAN.Size = new System.Drawing.Size(79, 21);
            this.txtTAN.TabIndex = 2;
            this.txtTAN.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTAN_KeyPress);
            // 
            // lblCAN
            // 
            this.lblCAN.AutoSize = true;
            this.lblCAN.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCAN.ForeColor = System.Drawing.Color.Black;
            this.lblCAN.Location = new System.Drawing.Point(322, 6);
            this.lblCAN.Name = "lblCAN";
            this.lblCAN.Size = new System.Drawing.Size(32, 15);
            this.lblCAN.TabIndex = 3;
            this.lblCAN.Text = "CAN";
            // 
            // lblAnalyst
            // 
            this.lblAnalyst.AutoSize = true;
            this.lblAnalyst.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnalyst.ForeColor = System.Drawing.Color.Black;
            this.lblAnalyst.Location = new System.Drawing.Point(429, 6);
            this.lblAnalyst.Name = "lblAnalyst";
            this.lblAnalyst.Size = new System.Drawing.Size(52, 16);
            this.lblAnalyst.TabIndex = 4;
            this.lblAnalyst.Text = "Analyst";
            // 
            // txtCAN
            // 
            this.txtCAN.BackColor = System.Drawing.Color.SeaShell;
            this.txtCAN.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCAN.ForeColor = System.Drawing.Color.Black;
            this.txtCAN.Location = new System.Drawing.Point(354, 3);
            this.txtCAN.MaxLength = 10;
            this.txtCAN.Name = "txtCAN";
            this.txtCAN.ReadOnly = true;
            this.txtCAN.Size = new System.Drawing.Size(74, 21);
            this.txtCAN.TabIndex = 3;
            // 
            // lblTan
            // 
            this.lblTan.AutoSize = true;
            this.lblTan.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTan.ForeColor = System.Drawing.Color.Black;
            this.lblTan.Location = new System.Drawing.Point(213, 6);
            this.lblTan.Name = "lblTan";
            this.lblTan.Size = new System.Drawing.Size(29, 15);
            this.lblTan.TabIndex = 5;
            this.lblTan.Text = "TAN";
            // 
            // txtShipmentName
            // 
            this.txtShipmentName.BackColor = System.Drawing.Color.SeaShell;
            this.txtShipmentName.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShipmentName.ForeColor = System.Drawing.Color.Black;
            this.txtShipmentName.Location = new System.Drawing.Point(43, 3);
            this.txtShipmentName.Name = "txtShipmentName";
            this.txtShipmentName.ReadOnly = true;
            this.txtShipmentName.Size = new System.Drawing.Size(95, 21);
            this.txtShipmentName.TabIndex = 0;
            this.txtShipmentName.Text = "Batch 5";
            // 
            // lblfilenum
            // 
            this.lblfilenum.AutoSize = true;
            this.lblfilenum.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfilenum.ForeColor = System.Drawing.Color.Black;
            this.lblfilenum.Location = new System.Drawing.Point(2, 5);
            this.lblfilenum.Name = "lblfilenum";
            this.lblfilenum.Size = new System.Drawing.Size(42, 16);
            this.lblfilenum.TabIndex = 1;
            this.lblfilenum.Text = "Batch";
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "RxnComplete.png");
            this.imageList1.Images.SetKeyName(1, "RxnNotComplete.jpg");
            this.imageList1.Images.SetKeyName(2, "SelectedRxn.png");
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.HeaderText = "P_Name";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn2.HeaderText = "P_Yield";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Visible = false;
            this.dataGridViewTextBoxColumn2.Width = 50;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn3.HeaderText = "Subst_Loc";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn3.Visible = false;
            // 
            // dataGridViewLinkColumn1
            // 
            this.dataGridViewLinkColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.NullValue = "0";
            this.dataGridViewLinkColumn1.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewLinkColumn1.HeaderText = "P_Num";
            this.dataGridViewLinkColumn1.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn1.LinkColor = System.Drawing.Color.Red;
            this.dataGridViewLinkColumn1.Name = "dataGridViewLinkColumn1";
            this.dataGridViewLinkColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn1.TrackVisitedState = false;
            this.dataGridViewLinkColumn1.Width = 55;
            // 
            // dataGridViewLinkColumn2
            // 
            this.dataGridViewLinkColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.NullValue = "0";
            this.dataGridViewLinkColumn2.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewLinkColumn2.HeaderText = "P_9000";
            this.dataGridViewLinkColumn2.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn2.LinkColor = System.Drawing.Color.Green;
            this.dataGridViewLinkColumn2.Name = "dataGridViewLinkColumn2";
            this.dataGridViewLinkColumn2.ReadOnly = true;
            this.dataGridViewLinkColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn2.TrackVisitedState = false;
            this.dataGridViewLinkColumn2.Width = 55;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn4.HeaderText = "Subst_Num";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Visible = false;
            this.dataGridViewTextBoxColumn4.Width = 50;
            // 
            // dataGridViewLinkColumn3
            // 
            this.dataGridViewLinkColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.NullValue = "0";
            this.dataGridViewLinkColumn3.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridViewLinkColumn3.HeaderText = "P_8500";
            this.dataGridViewLinkColumn3.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn3.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.dataGridViewLinkColumn3.Name = "dataGridViewLinkColumn3";
            this.dataGridViewLinkColumn3.ReadOnly = true;
            this.dataGridViewLinkColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn3.TrackVisitedState = false;
            this.dataGridViewLinkColumn3.Width = 55;
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewImageColumn1.HeaderText = "Molecule_Image";
            this.dataGridViewImageColumn1.Image = global::IndxReactNarr.Properties.Resources.delete_row;
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            this.dataGridViewImageColumn1.ToolTipText = "Delete Product";
            this.dataGridViewImageColumn1.Width = 88;
            // 
            // dataGridViewLinkColumn4
            // 
            this.dataGridViewLinkColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle9.NullValue = "0";
            this.dataGridViewLinkColumn4.DefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridViewLinkColumn4.HeaderText = "P_NrnReg";
            this.dataGridViewLinkColumn4.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn4.Name = "dataGridViewLinkColumn4";
            this.dataGridViewLinkColumn4.ReadOnly = true;
            this.dataGridViewLinkColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn4.TrackVisitedState = false;
            this.dataGridViewLinkColumn4.Width = 87;
            // 
            // dataGridViewLinkColumn5
            // 
            this.dataGridViewLinkColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.NullValue = "0";
            this.dataGridViewLinkColumn5.DefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridViewLinkColumn5.HeaderText = "P_8000";
            this.dataGridViewLinkColumn5.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn5.Name = "dataGridViewLinkColumn5";
            this.dataGridViewLinkColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn5.TrackVisitedState = false;
            this.dataGridViewLinkColumn5.Width = 55;
            // 
            // dataGridViewLinkColumn6
            // 
            this.dataGridViewLinkColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewLinkColumn6.HeaderText = "Subst_Name";
            this.dataGridViewLinkColumn6.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn6.Name = "dataGridViewLinkColumn6";
            this.dataGridViewLinkColumn6.ReadOnly = true;
            this.dataGridViewLinkColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewLinkColumn6.TrackVisitedState = false;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Subst_Molecule";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Visible = false;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Subst_Author";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn6.Width = 91;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "Subst_Other";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Width = 90;
            // 
            // dataGridViewImageColumn2
            // 
            this.dataGridViewImageColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewImageColumn2.HeaderText = "P_Mol";
            this.dataGridViewImageColumn2.Name = "dataGridViewImageColumn2";
            this.dataGridViewImageColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewImageColumn2.Visible = false;
            // 
            // dataGridViewImageColumn3
            // 
            this.dataGridViewImageColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewImageColumn3.HeaderText = "Subst_Mol";
            this.dataGridViewImageColumn3.Name = "dataGridViewImageColumn3";
            this.dataGridViewImageColumn3.ReadOnly = true;
            this.dataGridViewImageColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewImageColumn3.Width = 88;
            // 
            // frmReactCuration
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1148, 603);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmReactCuration";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TAN - Reactions Details";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmRxnEntryScreen_FormClosing);
            this.Load += new System.EventHandler(this.frmRxnEntryScreen_Load);
            this.pnlMain.ResumeLayout(false);
            this.splContPartpnts_RxnView.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splContPartpnts_RxnView)).EndInit();
            this.splContPartpnts_RxnView.ResumeLayout(false);
            this.splContRxnTree_Partpnts.Panel1.ResumeLayout(false);
            this.splContRxnTree_Partpnts.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splContRxnTree_Partpnts)).EndInit();
            this.splContRxnTree_Partpnts.ResumeLayout(false);
            this.pnlRxnsTree.ResumeLayout(false);
            this.pnlSearchRxn.ResumeLayout(false);
            this.pnlSearchRxn.PerformLayout();
            this.pnlProd_Stages.ResumeLayout(false);
            this.tcStages.ResumeLayout(false);
            this.cntmnuTbStages.ResumeLayout(false);
            this.pnlProduct.ResumeLayout(false);
            this.pnlProduct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProduct)).EndInit();
            this.pnlButtons.ResumeLayout(false);
            this.pnlButtons.PerformLayout();
            this.pnlTAN_Prod.ResumeLayout(false);
            this.pnlRxns.ResumeLayout(false);
            this.pnlRxns.PerformLayout();
            this.pnlNavigCntrls.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numGotoRecord)).EndInit();
            this.pnlTANInfo.ResumeLayout(false);
            this.pnlTANInfo.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.TextBox txtAnalyst;
        private System.Windows.Forms.TextBox txtTAN;
        private System.Windows.Forms.TextBox txtCAN;
        private System.Windows.Forms.TextBox txtShipmentName;
        private System.Windows.Forms.Label lblTan;
        private System.Windows.Forms.Label lblAnalyst;
        private System.Windows.Forms.Label lblCAN;
        private System.Windows.Forms.Label lblfilenum;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Label lblrxn_seq;
        private System.Windows.Forms.Label lblrxnnum;
        private System.Windows.Forms.Label lblrxn_no;
        private System.Windows.Forms.Panel pnlProd_Stages;
        private System.Windows.Forms.TabPage Stage1;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.ContextMenuStrip cntmnuTbStages;
        private System.Windows.Forms.ToolStripMenuItem addStageAfterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem removeTabToolStripMenuItem;
        private System.Windows.Forms.Panel pnlTAN_Prod;
        private System.Windows.Forms.Panel pnlButtons;
        private System.Windows.Forms.Panel pnlNavigCntrls;
        private System.Windows.Forms.Button btnAddRxn;
        private System.Windows.Forms.Button btnDelReaction;
        private System.Windows.Forms.Panel pnlProduct;
        private System.Windows.Forms.Button btnMng8000;
        private System.Windows.Forms.Button btnMng8500;
        private System.Windows.Forms.Panel pnlTANInfo;
        private System.Windows.Forms.Panel pnlRxns;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBatchNo;
        private System.Windows.Forms.Label lblRxnCnt;
        private Button btnSave;
        private LinkLabel lnkComments;
        public TabControl tcStages;
        private Button btnProdForm;
        private Button btnNumSearch;
        private ToolStripMenuItem addStageBeforeToolStripMenuItem;
        private Label lblRxnSeqVal;
        private Label lblProdNum;
        public DataGridView dgvProduct;
        private Button btnKeyWord;
        private CheckBox chkRxnComplete;
        public NumericUpDown numGotoRecord;
        private Button btnExportToPdf;
        private DataGridViewLinkColumn dataGridViewLinkColumn1;
        private DataGridViewLinkColumn dataGridViewLinkColumn2;
        private DataGridViewLinkColumn dataGridViewLinkColumn3;
        private DataGridViewLinkColumn dataGridViewLinkColumn4;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private DataGridViewImageColumn dataGridViewImageColumn1;
        private DataGridViewLinkColumn dataGridViewLinkColumn5;
        private DataGridViewImageColumn dataGridViewImageColumn2;
        private DataGridViewLinkColumn dataGridViewLinkColumn6;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private DataGridViewImageColumn dataGridViewImageColumn3;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private Panel pnlRxnsTree;
        private TreeView tvReactions;
        private TextBox txtSrchProduct;
        private Panel pnlSearchRxn;
        private Label label2;
        private SplitContainer splContPartpnts_RxnView;
        private SplitContainer splContRxnTree_Partpnts;
        private Label lblRxnSaveMsg;
        private Button btnTANComplete;
        private Label label3;
        private TextBox txtTANType;
        private Button btnSrchNumSubst;
        private Button btnRejectTAN;
        private LinkLabel lnkProduct;
        private DataGridViewTextBoxColumn colRPPID;
        private DataGridViewTextBoxColumn colProdSerNumID;
        private DataGridViewTextBoxColumn colProdNumType;
        private DataGridViewLinkColumn colProdNum;
        private DataGridViewLinkColumn colProdRegNo;
        private DataGridViewTextBoxColumn colProdYield;
        private DataGridViewLinkColumn colProdName;
        private DataGridViewImageColumn colDeleteProd;
        private Button btnIndexingNUMs;
        private ToolTip toolTip1;
        private Button btnNumsExportToPdf;
        private ImageList imageList1;
        private CheckBox chkSkipValidations;
    }
}