﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using System.IO;
using CADViewLib;
using System.Xml;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using System.Collections;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text;
using iTextSharp.text.pdf;

using IndxReactNarrBLL;
using IndxReactNarr.Common;

namespace IndxReactNarr
{
    public partial class frmNUMSearch : Form
    {
        #region Constructor

        public frmNUMSearch()
        {
            InitializeComponent();
        }

        #endregion

        #region Property Procedures

        private string _tan = "";
        public string TAN
        {
            get
            { return _tan; }
            set
            {
                _tan = value;
                txtTAN.Text = _tan;
            }
        }

        private string _batchname = "";
        public string BatchName
        {
            get
            { return _batchname; }
            set
            {
                _batchname = value;
                txtBatch.Text = _batchname;
            }
        }

        private string _can = "";
        public string CAN
        {
            get
            { return _can; }
            set
            {
                _can = value;
                txtCAN.Text = _can;
            }
        }

        private DataTable _cgmdatatbl = null;
        public DataTable CGMDataTbl
        {
            get
            { return _cgmdatatbl; }
            set
            {
                _cgmdatatbl = value;
            }
        }

        private DataTable _substancetbl = null;
        public DataTable SUBSTDataTbl
        {
            get
            { return _substancetbl; }
            set
            {
                _substancetbl = value;
            }
        }

        private DataTable _numstbl = null;
        public DataTable NUMsTbl
        {
            get
            { return _numstbl; }
            set
            {
                _numstbl = value;
            }
        }

        private DataTable _xmlconvtbl = null;
        public DataTable XMLConvTbl
        {
            get
            { return _xmlconvtbl; }
            set
            {
                _xmlconvtbl = value;
            }
        }

        public DataTable TANNUMsData { get; set; }

        #endregion

        int intRowCount = 0;
        private void btnGet_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;
                if (cmbNUMs.Text.Trim() != null)
                {
                    int intNUM = Convert.ToInt32(cmbNUMs.Text.Trim());
                    if (!alstSelNums.Contains(intNUM))
                    {                       
                        int intRegNo = GetRegNoOnNUM(intNUM.ToString());

                        intRowCount++;
                        tlpnlStructs.RowCount = intRowCount;
                        tlpnlStructs.ColumnCount = 1;

                        for (int i = 0; i <= intRowCount - 1; i++)
                        {
                            RowStyle rStyle = new RowStyle();
                            rStyle.Height = 408;// 320;
                            rStyle.SizeType = SizeType.Absolute;
                            tlpnlStructs.RowStyles.Add(rStyle);
                        }

                        BindDataToStructurePanel(intRegNo, intNUM);

                        for (int i = 0; i <= intRowCount - 1; i++)
                        {
                            tlpnlStructs.RowStyles[i].Height = 408;// 320;
                            tlpnlStructs.RowStyles[i].SizeType = SizeType.Absolute;
                        }

                        alstSelNums.Add(intNUM);
                    }
                    else
                    {
                        MessageBox.Show("NUM - " + intNUM + " already exist","",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    }
                }
                Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        ArrayList alstSelNums = new ArrayList();
        private void btnGetAll_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;
                
                if (NUMsTbl != null)
                {
                    alstSelNums.Clear();
                    if (NUMsTbl.Rows.Count > 0)
                    {
                        int intNUM = 0;
                        int intRegNo = 0;

                        tlpnlStructs.Controls.Clear();
                        tlpnlStructs.RowStyles.Clear();
                        intRowCount = 0;

                        tlpnlStructs.RowCount = NUMsTbl.Rows.Count;
                        tlpnlStructs.ColumnCount = 1;
                        
                        for (int i = 0; i <= tlpnlStructs.RowCount; i++)
                        {
                            RowStyle rStyle = new RowStyle();
                            rStyle.Height = 408;// 320;
                            rStyle.SizeType = SizeType.Absolute;
                            tlpnlStructs.RowStyles.Add(rStyle);
                        }

                        for (int i = 0; i < NUMsTbl.Rows.Count; i++)
                        {
                            intRowCount++;
                            intNUM = Convert.ToInt32(NUMsTbl.Rows[i]["NUM"].ToString().Trim());
                            intRegNo = GetRegNoOnNUM(intNUM.ToString());
                            BindDataToStructurePanel(intRegNo, intNUM);
                            alstSelNums.Add(intNUM);
                        }

                        for (int i = 0; i <= intRowCount - 1; i++)
                        {
                            tlpnlStructs.RowStyles[i].Height = 408;// 320;
                            tlpnlStructs.RowStyles[i].SizeType = SizeType.Absolute;
                        }                      
                    }
                }
                Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private int GetRegNoOnNUM(string _numval)
        {
            int intRegNo = 0;
            try
            {
                if (CGMDataTbl != null)
                {
                    if (CGMDataTbl.Rows.Count > 0)
                    {
                        DataTable dtcgm = CGMDataTbl.Copy();
                        DataTable dt = new DataTable();

                        string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";
                        
                        string cellValue = dtcgm.Rows[0][0].ToString();
                        cellValue = GetConvertedXmlString(cellValue);

                        cellValue = strXml + "\r\n" + cellValue;                 
                      
                        XElement xEle = XElement.Parse(cellValue, LoadOptions.None);

                        var query =  (from XElement r2 in xEle.Elements("CSIE")
                                      where r2.Descendants("NUM").ElementAt(0).Value == _numval
                                     select r2.Descendants("RN").Attributes("RID").ElementAt(0).Value.ToString());
                      
                        if(query != null)
                        {
                            if (query.ToString() != "")
                            {
                                intRegNo = Convert.ToInt32(query.ElementAt(0));
                            }
                        }                       
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return intRegNo;
        }

        private string GetConvertedXmlString(string _xmltag)
        {
            string strConvXml = _xmltag;
            try
            {
                if (XMLConvTbl != null)
                {
                    if (XMLConvTbl.Rows.Count > 0)
                    {
                        for (int i = 0; i < XMLConvTbl.Rows.Count; i++)
                        {
                            strConvXml = strConvXml.Replace(XMLConvTbl.Rows[i]["xmlstring"].ToString(), XMLConvTbl.Rows[i]["xmlstring_replacement"].ToString());
                        }
                    }
                }
                return strConvXml;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strConvXml;
        }

        private string SetGreekLetters_IUPACName(string _iupacname)
        {
            string strIUPAC = _iupacname;
            try
            {
                if (XMLConvTbl != null && XMLConvTbl.Rows.Count > 0)
                {
                    for (int i = 0; i < XMLConvTbl.Rows.Count; i++)
                    {
                        if (strIUPAC.Trim().Contains(XMLConvTbl.Rows[i]["CGM_STRING"].ToString()))
                        {
                            strIUPAC = strIUPAC.Replace(XMLConvTbl.Rows[i]["CGM_STRING"].ToString(), XMLConvTbl.Rows[i]["GREEK_LETTER"].ToString());
                        }
                        if (strIUPAC.Trim().Contains(XMLConvTbl.Rows[i]["STRING_REPLACEMENT"].ToString()))
                        {
                            strIUPAC = strIUPAC.Replace(XMLConvTbl.Rows[i]["STRING_REPLACEMENT"].ToString(), XMLConvTbl.Rows[i]["GREEK_LETTER"].ToString());
                        }
                    }
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strIUPAC;
        }

        private string DeleteXMLTagsFromName(string _iupacname)
        {
            string strIUPAC = _iupacname;
            try
            {
                strIUPAC = strIUPAC.Replace("<IT>", "");
                strIUPAC = strIUPAC.Replace("</IT>", "");
                //strIUPAC = strIUPAC.Replace("<SUP>", "");
                //strIUPAC = strIUPAC.Replace("</SUP>", "");
                strIUPAC = strIUPAC.Replace("<SCP>", "");
                strIUPAC = strIUPAC.Replace("</SCP>", "");
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strIUPAC;
        }

        private string[] GetHex_Name_MF_StrChem_Synonym_OnRegNo(int _regno, out string compname,out string molformula,out string[] absstrarr, out string[] molformarr, out string synonym)
        {
            string[] strHexArr = null;
            string strName = "";
            string[] strAbsStrArr = null;
            string[] strMFArr = null;
            string strMolFormula = "";
            string strSynonym = "";

            try
            {
                if (SUBSTDataTbl != null)
                {
                    if (SUBSTDataTbl.Rows.Count > 0)
                    {
                        DataTable dtsubstance = SUBSTDataTbl.Copy();
                        DataTable dt = new DataTable();

                        string strFCond = "<SUBSTANC><RN ID=" + "\"" + _regno + "\"" + ">*";
                        try
                        {
                            DataTable dtoutput = dtsubstance.AsEnumerable().Where(a => Regex.IsMatch(a[dtsubstance.Columns[0].ColumnName].ToString(), strFCond)).CopyToDataTable();
                            if (dtoutput != null)
                            {
                                if (dtoutput.Rows.Count > 0)
                                {
                                    string cellValue = dtoutput.Rows[0][0].ToString();
                                    if (cellValue.Contains("<SIM>"))//Single structure
                                    {
                                        strHexArr = new string[1];
                                        strName = "";
                                        strAbsStrArr = new string[1]; 
                                        strMFArr = new string[1];
                                        strSynonym = "";

                                        string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";
                                        cellValue = GetConvertedXmlString(cellValue);
                                        cellValue = strXml + "\r\n" + cellValue;

                                        XmlDocument xDoc = new XmlDocument();
                                        xDoc.LoadXml(cellValue);

                                        XmlNodeList xNdLst_Hex = xDoc.SelectNodes("SUBSTANC/SIM");
                                        if (xNdLst_Hex.Count > 0)
                                        {
                                            strHexArr[0] = xNdLst_Hex[0].InnerText;
                                        }
                                        XmlNodeList xNdLst_Name = xDoc.SelectNodes("SUBSTANC/IN");
                                        if (xNdLst_Name.Count > 0)
                                        {
                                            strName = xNdLst_Name[0].InnerXml;
                                            strName = DeleteXMLTagsFromName(strName);
                                            strName = SetGreekLetters_IUPACName(strName);
                                        }
                                        XmlNodeList xNdLst_MF = xDoc.SelectNodes("SUBSTANC/MF");
                                        if (xNdLst_MF.Count > 0)
                                        {
                                            string strMform = xNdLst_MF[0].InnerText;
                                            strMform = strMform.Replace("<SUB>", "");
                                            strMform = strMform.Replace("</SUB>", "");
                                            strMolFormula = strMform;
                                        }
                                        XmlNodeList xNdLst_AbsStr = xDoc.SelectNodes("SUBSTANC/STEMSG");
                                        if (xNdLst_AbsStr.Count > 0)
                                        {
                                            strAbsStrArr[0] = xNdLst_AbsStr[0].InnerText;   
                                        }
                                        XmlNodeList xNdLst_Synonym = xDoc.SelectNodes("SUBSTANC/SYN");
                                        if (xNdLst_Synonym.Count > 0)
                                        {
                                            for (int i = 0; i < xNdLst_Synonym.Count; i++)
                                            {
                                                if (xNdLst_Synonym[i].InnerText.ToString() != "")
                                                {
                                                    if (strSynonym.Trim() == "")
                                                    {
                                                        strSynonym = xNdLst_Synonym[i].InnerText;
                                                    }
                                                    else
                                                    {
                                                        strSynonym = strSynonym + "\r\n" + xNdLst_Synonym[i].InnerText;
                                                    }
                                                }
                                            }
                                            strSynonym = SetGreekLetters_IUPACName(strSynonym);
                                        }
                                        compname = strName;
                                        molformarr = strMFArr;
                                        absstrarr = strAbsStrArr;
                                        synonym = strSynonym;
                                        molformula = strMolFormula;
                                        return strHexArr;
                                    }
                                    else if (cellValue.Contains("<CSIM>"))//Multiple strucrures
                                    {
                                        string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";
                                        cellValue = strXml + "\r\n" + GetConvertedXmlString(cellValue);

                                        XmlDocument xDoc = new XmlDocument();
                                        xDoc.LoadXml(cellValue);

                                        XmlNodeList xNdLst_Hex = xDoc.SelectNodes("SUBSTANC/COMP/CSIM");
                                        if (xNdLst_Hex.Count > 0)
                                        {
                                            //Define arrays of equal size
                                            strHexArr = new string[xNdLst_Hex.Count];
                                            strAbsStrArr = new string[xNdLst_Hex.Count];
                                            strMFArr = new string[xNdLst_Hex.Count];
                                            strSynonym = "";

                                            //Structure Hex code Array
                                            for (int i = 0; i < xNdLst_Hex.Count; i++)
                                            {
                                                strHexArr[i] = xNdLst_Hex[i].InnerText;
                                            }
                                            //IUPAC name
                                            XmlNodeList xNdLst_Name = xDoc.SelectNodes("SUBSTANC/IN");
                                            if (xNdLst_Name.Count > 0)
                                            {
                                                strName = "";
                                                strName = xNdLst_Name[0].InnerXml;
                                                strName = DeleteXMLTagsFromName(strName);
                                                strName = SetGreekLetters_IUPACName(strName);
                                            }
                                            //Absolute Stereo
                                            XmlNodeList xNdLst_AbsStereo = xDoc.SelectNodes("SUBSTANC/COMP");//CSTEMSG
                                            if (xNdLst_AbsStereo.Count > 0)
                                            {
                                                for (int i = 0; i < strAbsStrArr.Length; i++)
                                                {
                                                    cellValue = "";
                                                    cellValue = strXml + "\r\n" + xNdLst_AbsStereo[i].OuterXml;

                                                    XmlDocument xDoc_Abs = new XmlDocument();
                                                    xDoc_Abs.LoadXml(cellValue);

                                                    XmlNodeList xNdLst_Abs = xDoc_Abs.SelectNodes("COMP/CSTEMSG");
                                                    if (xNdLst_Abs.Count > 0)
                                                    {
                                                        strAbsStrArr[i] = xNdLst_Abs[0].InnerText;
                                                    }
                                                    else
                                                    {
                                                        strAbsStrArr[i] = "";
                                                    }
                                                }
                                            }
                                            //Molecule Formula - Whole compound molecule formula
                                            XmlNodeList xNdLst_MForm = xDoc.SelectNodes("SUBSTANC/MF");
                                            if (xNdLst_MForm.Count > 0)
                                            {
                                                for (int i = 0; i < xNdLst_MForm.Count; i++)
                                                {
                                                    string strMform = xNdLst_MForm[i].InnerText;
                                                    strMform = strMform.Replace("<SUB>", "");
                                                    strMform = strMform.Replace("</SUB>", "");
                                                    strMolFormula = strMform;
                                                }
                                            }

                                            //Molecule Formula Array
                                            XmlNodeList xNdLst_MFormArr = xDoc.SelectNodes("SUBSTANC/COMP/CMF");
                                            if (xNdLst_MFormArr.Count > 0)
                                            {
                                                for (int i = 0; i < xNdLst_MFormArr.Count; i++)
                                                {
                                                    string strMformula = xNdLst_MFormArr[i].InnerText;
                                                    strMformula = strMformula.Replace("<SUB>", "");
                                                    strMformula = strMformula.Replace("</SUB>", "");
                                                    strMFArr[i] = strMformula;
                                                }
                                            }
                                            //Synonyms
                                            XmlNodeList xNdLst_Synonym = xDoc.SelectNodes("SUBSTANC/SYN");
                                            if (xNdLst_Synonym.Count > 0)
                                            {
                                                for (int i = 0; i < xNdLst_Synonym.Count; i++)
                                                {
                                                    if (xNdLst_Synonym[i].InnerText.ToString() != "")
                                                    {
                                                        if (strSynonym.Trim() == "")
                                                        {
                                                            strSynonym = xNdLst_Synonym[i].InnerText;
                                                        }
                                                        else
                                                        {
                                                            strSynonym = strSynonym + "\r\n" + xNdLst_Synonym[i].InnerText;
                                                        }
                                                    }
                                                }
                                                strSynonym = SetGreekLetters_IUPACName(strSynonym);
                                            }
                                        }

                                        compname = strName;
                                        molformarr = strMFArr;
                                        absstrarr = strAbsStrArr;
                                        synonym = strSynonym;
                                        molformula = strMolFormula;
                                        return strHexArr;
                                    }
                                    else //No Structure available
                                    {
                                        strHexArr = new string[1];
                                        strName = "";
                                        strAbsStrArr = new string[1];
                                        strMFArr = new string[1];
                                        strSynonym = "";

                                        string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";
                                        cellValue = GetConvertedXmlString(cellValue);
                                        cellValue = strXml + "\r\n" + cellValue;

                                        XmlDocument xDoc = new XmlDocument();
                                        xDoc.LoadXml(cellValue);

                                        //IUPAC name
                                        XmlNodeList xNdLst_Name = xDoc.SelectNodes("SUBSTANC/IN");
                                        if (xNdLst_Name.Count > 0)
                                        {
                                            strName = "";
                                            strName = xNdLst_Name[0].InnerXml;
                                            strName = DeleteXMLTagsFromName(strName);
                                            strName = SetGreekLetters_IUPACName(strName);
                                        }
                                        //Molecule Formula
                                        XmlNodeList xNdLst_MF = xDoc.SelectNodes("SUBSTANC/MF");
                                        if (xNdLst_MF.Count > 0)
                                        {
                                            string strMformula = xNdLst_MF[0].InnerText;
                                            strMformula = strMformula.Replace("<SUB>", "");
                                            strMformula = strMformula.Replace("</SUB>", "");
                                            strMFArr[0] = strMformula;
                                        }

                                        //Synonyms
                                        XmlNodeList xNdLst_Synonym = xDoc.SelectNodes("SUBSTANC/SYN");
                                        if (xNdLst_Synonym.Count > 0)
                                        {
                                            for (int i = 0; i < xNdLst_Synonym.Count; i++)
                                            {
                                                if (xNdLst_Synonym[i].InnerText.ToString() != "")
                                                {
                                                    if (strSynonym.Trim() == "")
                                                    {
                                                        strSynonym = xNdLst_Synonym[i].InnerText;
                                                    }
                                                    else
                                                    {
                                                        strSynonym = strSynonym + "\r\n" + xNdLst_Synonym[i].InnerText;
                                                    }
                                                }
                                            }
                                            strSynonym = SetGreekLetters_IUPACName(strSynonym);
                                        }

                                        compname = strName;
                                        molformarr = strMFArr;
                                        absstrarr = strAbsStrArr;
                                        synonym = strSynonym;
                                        molformula = strMolFormula;
                                        return strHexArr;
                                    }
                                }
                            }
                        }
                        catch
                        {

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            compname = strName;
            molformarr = strMFArr;
            absstrarr = strAbsStrArr;
            synonym = strSynonym;
            molformula = strMolFormula;
            return strHexArr;
        }

        XmlNodeList xnlPSEQ;
        XmlNodeList xnlNSeq;
        XmlDocument xDoc;
        XmlNodeList xnlSIMHex;
        XmlNodeList xnlIUPACName;
        XmlNodeList xnlMolFormula;
        XmlNodeList xnlMolFormArr;
        XmlNodeList xnlAbsStreo;
        XmlNodeList xnlSynonyms;

        private RegNoInfoBO GetRegNoPropertiesFromCGMSubstances(int _regno)
        {
            RegNoInfoBO objRegNoInfo = null;
            string[] saMolHexCode = null;
            //string strName = "";
            string[] saAbsStereo = null;
            string[] saMolFormulas = null;
            //string strMolFormula = "";
            //string strSynonym = "";
            //string strProteinSeq = "";
            //string strNuclicSeq = "";

            try
            {
                if (SUBSTDataTbl != null && _regno > 0)
                {
                    if (SUBSTDataTbl.Rows.Count > 0)
                    {
                        DataTable dtsubstance = SUBSTDataTbl.Copy();
                        DataTable dt = new DataTable();

                        string strFCond = "<SUBSTANC><RN ID=" + "\"" + _regno + "\"" + ">*";
                        try
                        {
                            DataTable dtoutput = dtsubstance.AsEnumerable().Where(a => Regex.IsMatch(a[dtsubstance.Columns[0].ColumnName].ToString(), strFCond)).CopyToDataTable();
                            if (dtoutput != null)
                            {
                                objRegNoInfo = new RegNoInfoBO();
                                objRegNoInfo.RegNo = _regno;
                                if (dtoutput.Rows.Count > 0)
                                {
                                    string cellValue = dtoutput.Rows[0][0].ToString();
                                    if (cellValue.Contains("<SIM>"))//Single structure
                                    {
                                        saMolHexCode = new string[1];
                                        //strName = "";
                                        saAbsStereo = new string[1];
                                        saMolFormulas = new string[1];
                                        //strSynonym = "";

                                        string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";
                                        cellValue = GetConvertedXmlString(cellValue);
                                        cellValue = strXml + "\r\n" + cellValue;

                                        xDoc = new XmlDocument();
                                        xDoc.LoadXml(cellValue);

                                        //Hex Codes
                                        xnlSIMHex = xDoc.SelectNodes("SUBSTANC/SIM");
                                        #region MyRegion
                                        //if (xnlSIMHex.Count > 0)
                                        //{
                                        //    saMolHexCode[0] = xnlSIMHex[0].InnerText;
                                        //} 
                                        #endregion
                                        objRegNoInfo.MolHexCodes = GetHexCodesFromNodeList(xnlSIMHex); //saMolHexCode;//New code on 19th Nov 2013

                                        //IUPAC Name
                                        xnlIUPACName = xDoc.SelectNodes("SUBSTANC/IN");
                                        objRegNoInfo.IUPACName = GetIUPACNameFromNodeList(xnlIUPACName);                                        

                                        //Mol Formula
                                        xnlMolFormula = xDoc.SelectNodes("SUBSTANC/MF");
                                        objRegNoInfo.MolFormula = GetMolFormulaFromNodeList(xnlMolFormula);
                                        #region MyRegion
                                        //if (xnlMolFormula.Count > 0)
                                        //{
                                        //    strMolFormula = xnlMolFormula[0].InnerText;
                                        //    strMolFormula = strMolFormula.Replace("<SUB>", "");
                                        //    strMolFormula = strMolFormula.Replace("</SUB>", "");

                                        //    objRegNoInfo.MolFormula = strMolFormula;//New code on 19th Nov 2013
                                        //} 
                                        #endregion
                                        objRegNoInfo.MolFormulas = saMolFormulas;//New code on 19th Nov 2013

                                        //Absolute Stereo
                                        xnlAbsStreo = xDoc.SelectNodes("SUBSTANC/STEMSG");
                                        #region MyRegion
                                        //if (xnlAbsStreo.Count > 0)
                                        //{
                                        //    saAbsStereo[0] = xnlAbsStreo[0].InnerText;
                                        //} 
                                        #endregion
                                        objRegNoInfo.MolAbsStereos = GetAbsoluteStereoFromNodeList(xnlAbsStreo, 0);//saAbsStereo;//New code on 19th Nov 2013

                                        //Synonyms
                                        xnlSynonyms = xDoc.SelectNodes("SUBSTANC/SYN");
                                        objRegNoInfo.MolSynonyms = GetSynonymsFromNodeList(xnlSynonyms);//New code on 19th Nov 2013

                                        //PSEQ - 18th NOv 2013
                                        xnlPSEQ = xDoc.SelectNodes("SUBSTANC/PSEQ");
                                        objRegNoInfo.MolProteinSeq = GetPeptideSequenceFromNodeList(xnlPSEQ);//New code on 19th Nov 2013

                                        //NSEQ - 18th NOv 2013
                                        xnlNSeq = xDoc.SelectNodes("SUBSTANC/NSEQ");
                                        objRegNoInfo.MolNuclicAcidSeq = GetNeuclicAcidSequenceFromNodeList(xnlNSeq);//New code on 19th Nov 2013
                                    }
                                    else if (cellValue.Contains("<CSIM>"))//Multiple structures
                                    {
                                        string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";
                                        cellValue = strXml + "\r\n" + GetConvertedXmlString(cellValue);

                                        XmlDocument xDoc = new XmlDocument();
                                        xDoc.LoadXml(cellValue);

                                        xnlSIMHex = xDoc.SelectNodes("SUBSTANC/COMP/CSIM");
                                        if (xnlSIMHex.Count > 0)
                                        {
                                            //Define arrays of equal size
                                            saMolHexCode = new string[xnlSIMHex.Count];
                                            saAbsStereo = new string[xnlSIMHex.Count];
                                            saMolFormulas = new string[xnlSIMHex.Count];
                                            //strSynonym = "";

                                            //Structure Hex code Array
                                            #region MyRegion
                                            //for (int i = 0; i < xnlSIMHex.Count; i++)
                                            //{
                                            //    saMolHexCode[i] = xnlSIMHex[i].InnerText;
                                            //} 
                                            #endregion
                                            objRegNoInfo.MolHexCodes = GetHexCodesFromNodeList(xnlSIMHex);// saMolHexCode;//New code on 19th Nov 2013

                                            //IUPAC name
                                            xnlIUPACName = xDoc.SelectNodes("SUBSTANC/IN");
                                            objRegNoInfo.IUPACName = GetIUPACNameFromNodeList(xnlIUPACName);
                                            
                                            //Absolute Stereo
                                            xnlAbsStreo = xDoc.SelectNodes("SUBSTANC/COMP");//CSTEMSG
                                            #region MyRegion
                                            //if (xnlAbsStreo.Count > 0)
                                            //{
                                            //    for (int i = 0; i < saAbsStereo.Length; i++)
                                            //    {
                                            //        cellValue = "";
                                            //        cellValue = strXml + "\r\n" + xnlAbsStreo[i].OuterXml;

                                            //        XmlDocument xDoc_Abs = new XmlDocument();
                                            //        xDoc_Abs.LoadXml(cellValue);

                                            //        XmlNodeList xNdLst_Abs = xDoc_Abs.SelectNodes("COMP/CSTEMSG");
                                            //        if (xNdLst_Abs.Count > 0)
                                            //        {
                                            //            saAbsStereo[i] = xNdLst_Abs[0].InnerText;
                                            //        }
                                            //        else
                                            //        {
                                            //            saAbsStereo[i] = "";
                                            //        }
                                            //    }
                                            //} 
                                            #endregion
                                            objRegNoInfo.MolAbsStereos = GetAbsoluteStereoFromNodeList(xnlAbsStreo, saAbsStereo.Length);// saAbsStereo;//New code on 19th Nov 2013

                                            //Molecule Formula - Whole compound molecule formula
                                            xnlMolFormula = xDoc.SelectNodes("SUBSTANC/MF");
                                            objRegNoInfo.MolFormula = GetMolFormulaFromNodeList(xnlMolFormula);

                                            //Molecule Formula Array, Individual compounds Mol Formulas
                                            xnlMolFormArr = xDoc.SelectNodes("SUBSTANC/COMP/CMF");
                                            #region MyRegion
                                            //if (xnlMolFormArr.Count > 0)
                                            //{
                                            //    for (int i = 0; i < saMolFormulas.Length; i++)//xnlMolFormArr.Count - Modified on 2nd Dec 2013, single structure, multiple formulas
                                            //    {
                                            //        strMolFormula = xnlMolFormArr[i].InnerText;
                                            //        strMolFormula = strMolFormula.Replace("<SUB>", "");
                                            //        strMolFormula = strMolFormula.Replace("</SUB>", "");
                                            //        saMolFormulas[i] = strMolFormula;
                                            //    }
                                            //} 
                                            #endregion
                                            objRegNoInfo.MolFormulas = GetMolFormulaArrayFromNodeList(xnlMolFormula, saMolFormulas.Length);//xnlMolFormArr.Count - Modified on 2nd Dec 2013, single structure, multiple formulas

                                            //Synonyms
                                            xnlSynonyms = xDoc.SelectNodes("SUBSTANC/SYN");
                                            objRegNoInfo.MolSynonyms = GetSynonymsFromNodeList(xnlSynonyms);//New code on 19th Nov 2013

                                            //ProteinSequence - 18th NOv 2013
                                            xnlPSEQ = xDoc.SelectNodes("SUBSTANC/PSEQ");
                                            objRegNoInfo.MolProteinSeq = GetPeptideSequenceFromNodeList(xnlPSEQ);//New code on 19th Nov 2013

                                            //NuclicAcidSequence - 18th NOv 2013
                                            xnlNSeq = xDoc.SelectNodes("SUBSTANC/NSEQ");                                            
                                            objRegNoInfo.MolNuclicAcidSeq = GetNeuclicAcidSequenceFromNodeList(xnlNSeq);//New code on 19th Nov 2013
                                        }
                                    }
                                    else //No Structure available
                                    {
                                        saMolHexCode = new string[1];
                                        //strName = "";
                                        saAbsStereo = new string[1];
                                        saMolFormulas = new string[1];
                                        //strSynonym = "";

                                        string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";
                                        cellValue = GetConvertedXmlString(cellValue);
                                        cellValue = strXml + "\r\n" + cellValue;

                                        xDoc = new XmlDocument();
                                        xDoc.LoadXml(cellValue);

                                        //IUPAC name
                                        xnlIUPACName = xDoc.SelectNodes("SUBSTANC/IN");
                                        objRegNoInfo.IUPACName = GetIUPACNameFromNodeList(xnlIUPACName);
                                        
                                        //Molecule Formula
                                        xnlMolFormula = xDoc.SelectNodes("SUBSTANC/MF");
                                        #region MyRegion
                                        //if (xnlMolFormula.Count > 0)
                                        //{
                                        //    strMolFormula = xnlMolFormula[0].InnerText;
                                        //    strMolFormula = strMolFormula.Replace("<SUB>", "");
                                        //    strMolFormula = strMolFormula.Replace("</SUB>", "");
                                        //    saMolFormulas[0] = strMolFormula;
                                        //} 
                                        #endregion
                                        objRegNoInfo.MolFormulas = GetMolFormulaArrayFromNodeList(xnlMolFormula, xnlMolFormula.Count);// saMolFormulas;//New code on 19th Nov 2013

                                        //Synonyms
                                        xnlSynonyms = xDoc.SelectNodes("SUBSTANC/SYN");                                        
                                        objRegNoInfo.MolSynonyms = GetSynonymsFromNodeList(xnlSynonyms);//New code on 19th Nov 2013

                                        //PSEQ - 18th NOv 2013
                                        xnlPSEQ = xDoc.SelectNodes("SUBSTANC/PSEQ");
                                        objRegNoInfo.MolProteinSeq = GetPeptideSequenceFromNodeList(xnlPSEQ);//New code on 19th Nov 2013

                                        //NSEQ - 18th NOv 2013
                                        xnlNSeq = xDoc.SelectNodes("SUBSTANC/NSEQ");
                                        objRegNoInfo.MolNuclicAcidSeq = GetNeuclicAcidSequenceFromNodeList(xnlNSeq);//New code on 19th Nov 2013
                                    }
                                }
                            }
                        }
                        catch
                        {

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return objRegNoInfo;
        }

        private RegNoInfoBO GetRegNoPropertiesFromNUMsData(int _num)
        {
            RegNoInfoBO regNoInfo = null;
            try
            {
                if (TANNUMsData != null && TANNUMsData.Rows.Count > 0 && _num > 0)
                {
                    DataTable dtsubstance = TANNUMsData.Copy();
                    DataTable dt = new DataTable();

                    string strFCond = "NUM =" + _num;
                    try
                    {
                        DataTable dtoutput = dtsubstance.Select(strFCond).CopyToDataTable();
                        if (dtoutput != null && dtoutput.Rows.Count > 0)
                        {
                            regNoInfo = new RegNoInfoBO();
                            regNoInfo.NUM = _num;
                            regNoInfo.RegNo = Convert.ToInt32(dtoutput.Rows[0]["REG_NO"].ToString());
                            regNoInfo.IUPACName = SetGreekLetters_IUPACName(dtoutput.Rows[0]["IUPAC_NAME"].ToString());
                            regNoInfo.MolProteinSeq = dtoutput.Rows[0]["PEPTIDE_SEQ"].ToString();
                            regNoInfo.MolNuclicAcidSeq = dtoutput.Rows[0]["NUCLIC_ACID_SEQ"].ToString();
                            regNoInfo.MolSynonyms = SetGreekLetters_IUPACName(dtoutput.Rows[0]["OTHER_NAMES"].ToString());
                            regNoInfo.MolFormula = dtoutput.Rows[0]["FORMULA"].ToString();
                            

                            if (!string.IsNullOrEmpty(dtoutput.Rows[0]["MOL_HEX_CODE"].ToString()))
                            {
                                regNoInfo.MolHexCodes = dtoutput.Rows[0]["MOL_HEX_CODE"].ToString().Split(new string[] { "<CSIM>" }, StringSplitOptions.RemoveEmptyEntries);
                            }
                            //else
                            //{ 
                            
                            //} 

                            regNoInfo.MolAbsStereos = dtoutput.Rows[0]["ABSOLUTE_STEREO"].ToString().Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                        }
                    }
                    catch
                    {

                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return regNoInfo;
        }


        #region Compound Elements - New methods on 11th Dec 2013

        private string GetIUPACNameFromNodeList(XmlNodeList nodeList)
        {
            string strIUPAC = "";
            try
            {
                if (nodeList != null)
                {
                    if (nodeList.Count > 0)
                    {
                        strIUPAC = nodeList[0].InnerXml;
                        strIUPAC = DeleteXMLTagsFromName(strIUPAC);
                        strIUPAC = SetGreekLetters_IUPACName(strIUPAC);
                    }
                }
            }
            catch (Exception ex)
            {                
              ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strIUPAC;
        }

        private string GetMolFormulaFromNodeList(XmlNodeList nodeList)
        {
            string strMolFormula = "";
            try
            {
                if (nodeList != null)
                {
                    if (nodeList.Count > 0)
                    {
                        strMolFormula = nodeList[0].InnerText;
                        strMolFormula = strMolFormula.Replace("<SUB>", "");
                        strMolFormula = strMolFormula.Replace("</SUB>", "");                        
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strMolFormula;
        }

        private string GetSynonymsFromNodeList(XmlNodeList nodeList)
        {
            string strSynonyms = "";
            try
            {
                if (nodeList != null)
                {
                    if (nodeList.Count > 0)
                    {
                        for (int i = 0; i < nodeList.Count; i++)
                        {
                            strSynonyms = strSynonyms.Trim() + "\r\n" + nodeList[i].InnerText.Trim();
                        }
                        strSynonyms = SetGreekLetters_IUPACName(strSynonyms);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strSynonyms.Trim();
        }

        private string GetPeptideSequenceFromNodeList(XmlNodeList nodeList)
        {
            string strPepSeq = "";
            try
            {
                if (nodeList != null)
                {
                    if (nodeList.Count > 0)
                    {
                        for (int i = 0; i < nodeList.Count; i++)
                        {
                            strPepSeq = strPepSeq.Trim() + "\r\n" + nodeList[i].InnerText.Trim();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
              ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strPepSeq.Trim();
        }

        private string GetNeuclicAcidSequenceFromNodeList(XmlNodeList nodeList)
        {
            string strNeuclicSeq = "";
            try
            {
                if (nodeList != null)
                {
                    if (nodeList.Count > 0)
                    {
                        for (int i = 0; i < nodeList.Count; i++)
                        {
                            strNeuclicSeq = strNeuclicSeq.Trim() + "\r\n" + nodeList[i].InnerText.Trim();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strNeuclicSeq.Trim();
        }

        private string[] GetHexCodesFromNodeList(XmlNodeList nodeList)
        {
            string[] saHexCodes = null;
            try
            {
                if (nodeList != null)
                {
                    saHexCodes = new string[xnlSIMHex.Count];
                    for (int i = 0; i < xnlSIMHex.Count; i++)
                    {
                        saHexCodes[i] = xnlSIMHex[i].InnerText;
                    }
                }
            }
            catch (Exception ex)
            {
              ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return saHexCodes;
        }

        private string[] GetMolFormulaArrayFromNodeList(XmlNodeList nodeList, int nodeLength)
        {
            string[] saMolFormulas = null;
            try
            {
                string strFormula = "";
                if (nodeList != null)
                {
                    if (nodeList.Count > 0 && nodeLength > 0)
                    {
                        int intLen = nodeLength;
                        if (nodeList.Count < nodeLength)
                        {
                            intLen = nodeList.Count;
                        }
                        saMolFormulas = new string[intLen];

                        for (int i = 0; i < saMolFormulas.Length; i++)//xnlMolFormArr.Count - Modified on 2nd Dec 2013, single structure, multiple formulas
                        {
                            strFormula = nodeList[i].InnerText;
                            strFormula = strFormula.Replace("<SUB>", "");
                            strFormula = strFormula.Replace("</SUB>", "");
                            saMolFormulas[i] = strFormula;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
               ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return saMolFormulas;
        }

        string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";
        private string[] GetAbsoluteStereoFromNodeList(XmlNodeList nodeList, int nodeLength)
        {
            string[] saAbsStereo = new string[nodeLength];
            try
            {
                if (nodeList != null)
                {
                    if (nodeList.Count > 0)
                    {
                        if (nodeLength == 0)//Single compound
                        {
                            saAbsStereo = new string[1];
                            saAbsStereo[0] = xnlAbsStreo[0].InnerText;
                        }
                        else //Multiple compounds
                        {
                            int intLen = nodeLength;
                            if (nodeList.Count < nodeLength)
                            {
                                intLen = nodeList.Count;
                            }
                            saAbsStereo = new string[intLen];

                            string strXmlData = "";
                            for (int i = 0; i < saAbsStereo.Length; i++)
                            {
                                strXmlData = "";
                                strXmlData = strXml + "\r\n" + xnlAbsStreo[i].OuterXml;

                                XmlDocument xDoc_Abs = new XmlDocument();
                                xDoc_Abs.LoadXml(strXmlData);

                                XmlNodeList xNdLst_Abs = xDoc_Abs.SelectNodes("COMP/CSTEMSG");
                                if (xNdLst_Abs.Count > 0)
                                {
                                    saAbsStereo[i] = xNdLst_Abs[0].InnerText;
                                }
                                else
                                {
                                    saAbsStereo[i] = "";
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return saAbsStereo;
        }

        #endregion

        private void frmNUMSearch_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;

                txtTAN.Text = TAN;
                txtCAN.Text = CAN;
                txtBatch.Text = BatchName;

                XMLConvTbl = GlobalVariables.XMLConvTbl;

                BindNumToComboBox(TANNUMsData);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public void BindDataToStructurePanel(int _regno,int _numval)
        {
            try
            {
                #region Code commented on 19th Nov 2013
                //string strIUPAC = "";
                //string[] strAbsStrArr = null;
                //string[] strMFormArr = null;
                //string strSynonym = "";
                //string strMolFormula = "";
                //string[] strHexArr = GetHex_Name_MF_StrChem_Synonym_OnRegNo(_regno, out strIUPAC,out strMolFormula, out strAbsStrArr, out strMFormArr, out strSynonym);
                //if (strHexArr != null)
                //{
                //    if (strHexArr.Length > 0)
                //    {
                //        ucNUMDetails objNumDtls = null;
                //        objNumDtls = new ucNUMDetails();
                //        objNumDtls.Dock = DockStyle.Fill;

                //        objNumDtls.NrnNum = _numval.ToString();
                //        objNumDtls.RegNo = _regno.ToString();
                //        objNumDtls.IUPACName = strIUPAC;
                //        objNumDtls.MolFormula = strMolFormula;
                //        objNumDtls.MolFormulaArr = strMFormArr;
                //        objNumDtls.Synonyms = strSynonym;
                //        objNumDtls.HexCodeArr = strHexArr;
                //        objNumDtls.StereoChemArr = strAbsStrArr;

                //        tlpnlStructs.Controls.Add(objNumDtls, 0, intRowCount - 1);
                //        tlpnlStructs.ScrollControlIntoView(objNumDtls);
                //    }
                //}
                //else//No Substance information in CGM file. New modification on 14June12
                //{
                //    ucNUMDetails objNumDtls = null;
                //    objNumDtls = new ucNUMDetails();
                //    objNumDtls.Dock = DockStyle.Fill;

                //    objNumDtls.NrnNum = _numval.ToString();
                //    objNumDtls.RegNo = _regno.ToString();

                //    tlpnlStructs.Controls.Add(objNumDtls, 0, intRowCount - 1);
                //    tlpnlStructs.ScrollControlIntoView(objNumDtls);
                //} 
                #endregion

                // RegNoInfoBO objRegInfo = GetRegNoPropertiesFromCGMSubstances(_regno);
                RegNoInfoBO objRegInfo = GetRegNoPropertiesFromNUMsData(_numval);
                if (objRegInfo != null)
                {
                    if (objRegInfo.MolHexCodes != null)
                    {
                        if (objRegInfo.MolHexCodes.Length > 0)
                        {
                            ucNUMDetails objNumDtls = null;
                            objNumDtls = new ucNUMDetails();
                            objNumDtls.Dock = DockStyle.Fill;

                            objNumDtls.NrnNum = objRegInfo.NUM.ToString();
                            objNumDtls.RegNo = objRegInfo.RegNo.ToString();
                            objNumDtls.IUPACName = objRegInfo.IUPACName;
                            objNumDtls.MolFormula = objRegInfo.MolFormula;
                            objNumDtls.MolFormulaArr = objRegInfo.MolFormulas;
                            objNumDtls.Synonyms = objRegInfo.MolSynonyms;
                            objNumDtls.HexCodeArr = objRegInfo.MolHexCodes;
                            objNumDtls.StereoChemArr = objRegInfo.MolAbsStereos;

                            objNumDtls.PeptideSeq = objRegInfo.MolProteinSeq;
                            objNumDtls.NuclicAcidSeq = objRegInfo.MolNuclicAcidSeq;

                            tlpnlStructs.Controls.Add(objNumDtls, 0, intRowCount - 1);
                            tlpnlStructs.ScrollControlIntoView(objNumDtls);
                        }
                    }
                    else//No Substance information in CGM file. New modification on 14June12
                    {
                        ucNUMDetails objNumDtls = null;
                        objNumDtls = new ucNUMDetails();
                        objNumDtls.Dock = DockStyle.Fill;

                        objNumDtls.NrnNum = objRegInfo.NUM.ToString();
                        objNumDtls.RegNo = objRegInfo.RegNo.ToString();
                        objNumDtls.IUPACName = objRegInfo.IUPACName;

                        tlpnlStructs.Controls.Add(objNumDtls, 0, intRowCount - 1);
                        tlpnlStructs.ScrollControlIntoView(objNumDtls);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            try
            {
                tlpnlStructs.RowStyles.Clear();
                tlpnlStructs.Controls.Clear();               
                tlpnlStructs.RowCount = 1;

                for (int i = 0; i < tlpnlStructs.RowCount; i++)
                {
                    RowStyle rStyle = new RowStyle();
                    rStyle.Height = 100;
                    rStyle.SizeType = SizeType.Absolute;
                    tlpnlStructs.RowStyles.Add(rStyle);
                }
                tlpnlStructs.RowStyles[0].Height = 100;
                tlpnlStructs.RowStyles[0].SizeType = SizeType.Absolute;
                tlpnlStructs.Height = 100;
                tlpnlStructs.Refresh();
                
                intRowCount = 0;
                alstSelNums.Clear();                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        public void Get_Set_Cgm_SubstData_XMLConvData()
        {
            try
            {
                //DataTable dtSubstance = null;
                //CGMDataTbl = GetCgmAndSubstanceDataOnBatchName(txtBatch.Text.Trim(), txtTAN.Text.Trim(), txtCAN.Text.Trim(), out dtSubstance);

                //if (dtSubstance != null)
                //{
                //    SUBSTDataTbl = dtSubstance;
                //}
                //TODO:analyse
                XMLConvTbl = IndxReactNarrDAL.ReactDB.GetXMLConvDetails();

                BindNumToComboBox(TANNUMsData);

                //if (CGMDataTbl != null)
                //{
                //    if (CGMDataTbl.Rows.Count > 0)
                //    {
                //        DataTable dtNums = GetNUMsFromTANData(CGMDataTbl.Rows[0][0].ToString());
                //        if (dtNums != null)
                //        {
                //            if (dtNums.Rows.Count > 0)
                //            {
                //                BindNumToComboBox(dtNums);
                //            }
                //        }
                //    }
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void BindNumToComboBox(DataTable numstbl)
        {
            try
            {
                if (numstbl != null && numstbl.Rows.Count > 0)
                {
                    DataView dvTemp = numstbl.DefaultView;
                    dvTemp.Sort = "NUM asc";
                    DataTable dtNumData = dvTemp.ToTable();

                    NUMsTbl = dtNumData;

                    cmbNUMs.DataSource = NUMsTbl;
                    cmbNUMs.DisplayMember = "NUM";
                    cmbNUMs.SelectedIndex = 0;
                }           
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private DataTable GetNUMsFromTANData(string _tandata)
        {
            DataTable dtNUMs = null;
            try
            {
                if (_tandata.Trim() != "")
                {
                    string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";
                    string strTANDat = GetConvertedXmlString(_tandata.Trim());
                    strTANDat = strXml + "\r\n" + strTANDat.Trim();

                    XmlDocument xDoc = new XmlDocument();
                    xDoc.LoadXml(strTANDat);

                    XmlNodeList xNdLst_NUMs = xDoc.SelectNodes("ARTICLE/CSIE/NUM");
                    if (xNdLst_NUMs.Count > 0)
                    {
                        dtNUMs = new DataTable();
                        dtNUMs.Columns.Add("NUM", typeof(Int32));
                        for (int i = 0; i < xNdLst_NUMs.Count; i++)
                        {
                            DataRow dtRow = dtNUMs.NewRow();
                            dtRow[0] = xNdLst_NUMs[i].InnerText;
                            dtNUMs.Rows.Add(dtRow);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtNUMs;
        }
            
        private void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
                {
                    string strFilePath = folderBrowserDialog1.SelectedPath + "\\" + TAN + "_cgm.pdf";

                    if (ExportNUMsDataToPdf_New(strFilePath))
                    {
                        MessageBox.Show("Exported to pdf file successfully", "NUM Search", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Error in file export", "NUM Search", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private bool ExportNUMsDataToPdf(string _pdffilepath)
        {
            bool blStatus = false;
            try
            {
                if (NUMsTbl != null)
                {
                    if (NUMsTbl.Rows.Count > 0)
                    {
                        string strNUM = "";

                        Document objPdf = new Document();
                        PdfWriter writer = PdfWriter.GetInstance(objPdf, new FileStream(_pdffilepath, FileMode.Create));

                        writer.SetFullCompression();
                        writer.StrictImageSequence = true;
                        writer.SetLinearPageMode();

                        objPdf.Open();

                        Paragraph objPara = null;
                        string strIUPAC = "";
                        string[] strAbsStrArr = null;
                        string[] strMFormArr = null;
                        string strSynonym = "";
                        string strMolFormula = "";
                        string[] strHexArr = null;
                        int intRegNo = 0;

                        iTextSharp.text.Font fntNUM = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.COURIER, 9f, iTextSharp.text.Font.NORMAL, new iTextSharp.text.BaseColor(163, 21, 21));
                        iTextSharp.text.Font lightblue = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.COURIER, 9f, iTextSharp.text.Font.NORMAL, new iTextSharp.text.BaseColor(43, 145, 175));
                        iTextSharp.text.Font courier = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.COURIER, 9f);
                        iTextSharp.text.Font georgia = FontFactory.GetFont("georgia", 10f);
                        georgia.Color = iTextSharp.text.BaseColor.GRAY;

                        float width = iTextSharp.text.PageSize.A4.Width - objPdf.LeftMargin - objPdf.RightMargin;
                        float height = iTextSharp.text.PageSize.A4.Height - objPdf.TopMargin - objPdf.BottomMargin;

                        Phrase objPhrse = null;
                        Chunk cnkNUM = null;
                        Chunk cnkNUM_Val = null;
                        Chunk cnkRegNo = null;
                        Chunk cnkRegNo_Val = null;
                        Chunk cnkForm = null;
                        Chunk cnkForm_Val = null;
                        Chunk cnkAbsStereo = null;
                        Chunk cnkAbsStereo_Val = null;
                        Chunk cnkName = null;
                        Chunk cnkName_Val = null;
                        Chunk cnkSyn = null;
                        Chunk cnkSyn_Val = null;

                        Paragraph emptypara = null;

                        iTextSharp.text.Image chemimg = null;

                        for (int i = 0; i < NUMsTbl.Rows.Count; i++)
                        {
                            strNUM = NUMsTbl.Rows[i][0].ToString();
                            intRegNo = GetRegNoOnNUM(strNUM);

                            //strIUPAC = "";
                            //strAbsStrArr = null;
                            //strMFormArr = null;
                            //strSynonym = "";
                            //strMolFormula = "";
                            //strHexArr = GetHex_Name_MF_StrChem_Synonym_OnRegNo(intRegNo, out strIUPAC, out strMolFormula, out strAbsStrArr, out strMFormArr, out strSynonym);

                            RegNoInfoBO objRegInfo = GetRegNoPropertiesFromCGMSubstances(intRegNo);
                            if (objRegInfo != null)
                            {
                                objPhrse = new Phrase();
                                cnkNUM = new Chunk("NUM: ", georgia);
                                cnkNUM_Val = new Chunk(strNUM, FontFactory.GetFont("Arial", 10, 3, iTextSharp.text.BaseColor.RED));
                                cnkRegNo = new Chunk("\r\nRegistry No: ", georgia);
                                cnkRegNo_Val = new Chunk(intRegNo.ToString(), FontFactory.GetFont("Arial", 10, 3, iTextSharp.text.BaseColor.BLUE));
                                cnkForm = new Chunk("\r\nFormula: ", georgia);
                                cnkForm_Val = new Chunk(objRegInfo.MolFormula, FontFactory.GetFont("Arial", 10, 3, iTextSharp.text.BaseColor.MAGENTA));

                                if (strAbsStrArr != null)
                                {
                                    cnkAbsStereo = new Chunk("\r\nAbsolute Stereo: ", georgia);
                                    cnkAbsStereo_Val = new Chunk(GetABS_StereoFromArray(objRegInfo.MolAbsStereos), FontFactory.GetFont("Arial", 10, 3, iTextSharp.text.BaseColor.ORANGE));
                                }

                                cnkName = new Chunk("\r\nName: ", georgia);
                                cnkName_Val = new Chunk(objRegInfo.IUPACName, FontFactory.GetFont("Arial", 9, 3, iTextSharp.text.BaseColor.BLUE));
                                cnkSyn = new Chunk("\r\nOther Names: \r\n", georgia);
                                cnkSyn_Val = new Chunk(objRegInfo.MolSynonyms.Replace("\r\n", ", "), FontFactory.GetFont("Arial", 9, 3, iTextSharp.text.BaseColor.BLUE));
                                objPhrse.Add(cnkNUM);
                                objPhrse.Add(cnkNUM_Val);
                                objPhrse.Add(cnkRegNo);
                                objPhrse.Add(cnkRegNo_Val);
                                objPhrse.Add(cnkForm);
                                objPhrse.Add(cnkForm_Val);
                                if (cnkAbsStereo != null)
                                {
                                    objPhrse.Add(cnkAbsStereo);
                                }
                                if (cnkAbsStereo_Val != null)
                                {
                                    objPhrse.Add(cnkAbsStereo_Val);
                                }
                                objPhrse.Add(cnkName);
                                objPhrse.Add(cnkName_Val);
                                objPhrse.Add(cnkSyn);
                                objPhrse.Add(cnkSyn_Val);

                                objPara = new Paragraph();
                                objPara.Add(objPhrse);
                                objPdf.Add(objPara);
                                if (objRegInfo.MolHexCodes != null)
                                {
                                    if (objRegInfo.MolHexCodes.Length > 0)
                                    {
                                        for (int j = 0; j < objRegInfo.MolHexCodes.Length; j++)
                                        {
                                            //Paragraph empty1 = new Paragraph("\r\n", FontFactory.GetFont("Arial", 10));
                                            //objPdf.Add(empty1);
                                            if (objRegInfo.MolHexCodes[j] != null)
                                            {
                                                if (objRegInfo.MolHexCodes[j].ToString().Trim() != "")
                                                {
                                                    #region Old Code commented
                                                    //strFilePath = GetChemImagePathOnHexCode(strHexArr[j], intRegNo.ToString());
                                                    //img = iTextSharp.text.Image.GetInstance(strFilePath);
                                                    ////Resize image depend upon your need
                                                    //img.ScaleToFit(280f, 260f);
                                                    ////Give space before image
                                                    //img.SpacingBefore = 30f;
                                                    ////Give some space after the image
                                                    //img.SpacingAfter = 1f;
                                                    //img.Alignment = Element.ALIGN_CENTER;
                                                    //objPdf.Add(img);
                                                    //if (File.Exists(strFilePath))
                                                    //{
                                                    //    File.Delete(strFilePath);
                                                    //} 
                                                    #endregion
                                                    try
                                                    {
                                                        chemimg = HexCodeToStructureImage.GetITextImageOnHexCode(objRegInfo.MolHexCodes[j].Trim(), intRegNo.ToString());

                                                        //Give space before image 
                                                        chemimg.SpacingBefore = 30f;
                                                        //Give some space after the image 
                                                        chemimg.SpacingAfter = 1f;
                                                        chemimg.Alignment = iTextSharp.text.Image.ALIGN_CENTER;// iTextSharp.text.Image.ALIGN_CENTER | iTextSharp.text.Image.TEXTWRAP;
                                                        //chemimg.ScaleToFit(width, height);
                                                        objPdf.Add(chemimg);
                                                    }
                                                    catch
                                                    {
                                                        objPdf.Add(new Chunk("Structure Error", FontFactory.GetFont("Arial", 10, 3, iTextSharp.text.BaseColor.RED)));
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                emptypara = new Paragraph("-------------------------------------------------------------------------------------------------------------------------------------------------------\r\n\r\n", georgia);
                                objPdf.Add(emptypara);
                            }
                        }
                        objPdf.Close();


                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool ExportNUMsDataToPdf_New(string _pdffilepath)
        {
            bool blStatus = false;
            Document objPdf = null;
            try
            {
                if (NUMsTbl != null && NUMsTbl.Rows.Count > 0)
                {
                    string strNUM = "";

                    objPdf = new Document();
                    PdfWriter writer = PdfWriter.GetInstance(objPdf, new FileStream(_pdffilepath, FileMode.Create));

                    writer.SetFullCompression();
                    writer.StrictImageSequence = true;
                    writer.SetLinearPageMode();

                    objPdf.Open();

                    Paragraph objPara = null;
                    //string strIUPAC = "";
                    //string[] strAbsStrArr = null;
                    //string[] strMFormArr = null;
                    //string strSynonym = "";
                    //string strMolFormula = "";
                    //string[] strHexArr = null;
                    int intRegNo = 0;

                    iTextSharp.text.Font fntNUM = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.COURIER, 9f, iTextSharp.text.Font.NORMAL, new iTextSharp.text.BaseColor(163, 21, 21));
                    iTextSharp.text.Font lightblue = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.COURIER, 9f, iTextSharp.text.Font.NORMAL, new iTextSharp.text.BaseColor(43, 145, 175));
                    iTextSharp.text.Font courier = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.COURIER, 9f);
                    iTextSharp.text.Font georgia = FontFactory.GetFont("georgia", 10f);
                    georgia.Color = iTextSharp.text.BaseColor.GRAY;

                    float width = iTextSharp.text.PageSize.A4.Width - objPdf.LeftMargin - objPdf.RightMargin;
                    float height = iTextSharp.text.PageSize.A4.Height - objPdf.TopMargin - objPdf.BottomMargin;

                    Phrase objPhrse = null;
                    Chunk cnkNUM = null;
                    Chunk cnkNUM_Val = null;
                    Chunk cnkRegNo = null;
                    Chunk cnkRegNo_Val = null;
                    Chunk cnkForm = null;
                    Chunk cnkForm_Val = null;
                    Chunk cnkAbsStereo = null;
                    Chunk cnkAbsStereo_Val = null;
                    Chunk cnkName = null;
                    Chunk cnkName_Val = null;

                    Chunk cnkPSeq = null;
                    Chunk cnkPSeq_Val = null;

                    Chunk cnkNSeq = null;
                    Chunk cnkNSeq_Val = null;

                    Chunk cnkSyn = null;
                    Chunk cnkSyn_Val = null;

                    Paragraph emptypara = null;
                    RegNoInfoBO objRegInfo = null;

                    for (int i = 0; i < NUMsTbl.Rows.Count; i++)
                    {
                        strNUM = NUMsTbl.Rows[i]["NUM"].ToString();
                        //intRegNo = GetRegNoOnNUM(strNUM);

                        //strIUPAC = "";
                        //strAbsStrArr = null;
                        //strMFormArr = null;
                        //strSynonym = "";
                        //strMolFormula = "";
                        //strHexArr = GetHex_Name_MF_StrChem_Synonym_OnRegNo(intRegNo, out strIUPAC, out strMolFormula, out strAbsStrArr, out strMFormArr, out strSynonym);

                        try
                        {
                            //objRegInfo = GetRegNoPropertiesFromCGMSubstances(intRegNo);
                            objRegInfo = GetRegNoPropertiesFromNUMsData(Convert.ToInt32(strNUM));
                            if (objRegInfo != null)
                            {
                                objPhrse = new Phrase();
                                cnkNUM = new Chunk("NUM: ", georgia);
                                cnkNUM_Val = new Chunk(objRegInfo.NUM.ToString(), FontFactory.GetFont("Arial", 10, 3, iTextSharp.text.BaseColor.RED));
                                cnkRegNo = new Chunk("\r\nRegistry No: ", georgia);
                                cnkRegNo_Val = new Chunk(objRegInfo.RegNo.ToString(), FontFactory.GetFont("Arial", 10, 3, iTextSharp.text.BaseColor.BLUE));
                                cnkForm = new Chunk("\r\nFormula: ", georgia);
                                cnkForm_Val = new Chunk(objRegInfo.MolFormula, FontFactory.GetFont("Arial", 10, 3, iTextSharp.text.BaseColor.MAGENTA));

                                if (objRegInfo.MolAbsStereos != null)
                                {
                                    cnkAbsStereo = new Chunk("\r\nAbsolute Stereo: ", georgia);
                                    cnkAbsStereo_Val = new Chunk(GetABS_StereoFromArray(objRegInfo.MolAbsStereos), FontFactory.GetFont("Arial", 10, 3, iTextSharp.text.BaseColor.ORANGE));
                                }

                                cnkName = new Chunk("\r\nName: ", georgia);
                                cnkName_Val = new Chunk(objRegInfo.IUPACName, FontFactory.GetFont("Arial", 9, 3, iTextSharp.text.BaseColor.BLUE));

                                //New code for PSEQ, NSEQ on 26th Nov 2013
                                cnkPSeq = new Chunk("\r\nPeptide Sequence: ", georgia);
                                cnkPSeq_Val = new Chunk(objRegInfo.MolProteinSeq, FontFactory.GetFont("Arial", 9, 3, iTextSharp.text.BaseColor.GREEN));

                                cnkNSeq = new Chunk("\r\nNeuclic Acid Sequence: ", georgia);
                                cnkNSeq_Val = new Chunk(objRegInfo.MolNuclicAcidSeq, FontFactory.GetFont("Arial", 9, 3, iTextSharp.text.BaseColor.GREEN));

                                cnkSyn = new Chunk("\r\nOther Names: \r\n", georgia);
                                cnkSyn_Val = new Chunk(objRegInfo.MolSynonyms.Replace("\r\n", ", "), FontFactory.GetFont("Arial", 9, 3, iTextSharp.text.BaseColor.BLUE));

                                objPhrse.Add(cnkNUM);
                                objPhrse.Add(cnkNUM_Val);
                                objPhrse.Add(cnkRegNo);
                                objPhrse.Add(cnkRegNo_Val);
                                objPhrse.Add(cnkForm);
                                objPhrse.Add(cnkForm_Val);
                                if (cnkAbsStereo != null)
                                {
                                    objPhrse.Add(cnkAbsStereo);
                                }
                                if (cnkAbsStereo_Val != null)
                                {
                                    objPhrse.Add(cnkAbsStereo_Val);
                                }
                                objPhrse.Add(cnkName);
                                objPhrse.Add(cnkName_Val);


                                objPhrse.Add(cnkPSeq);
                                objPhrse.Add(cnkPSeq_Val);

                                objPhrse.Add(cnkNSeq);
                                objPhrse.Add(cnkNSeq_Val);

                                objPhrse.Add(cnkSyn);
                                objPhrse.Add(cnkSyn_Val);

                                objPara = new Paragraph();
                                objPara.Add(objPhrse);
                                objPdf.Add(objPara);
                                if (objRegInfo.MolHexCodes != null)
                                {
                                    if (objRegInfo.MolHexCodes.Length > 0)
                                    {
                                        for (int j = 0; j < objRegInfo.MolHexCodes.Length; j++)
                                        {
                                            //Paragraph empty1 = new Paragraph("\r\n", FontFactory.GetFont("Arial", 10));
                                            //objPdf.Add(empty1);
                                            if (objRegInfo.MolHexCodes[j] != null)
                                            {
                                                if (objRegInfo.MolHexCodes[j].ToString().Trim() != "")
                                                {
                                                    #region Old Code commented
                                                    //strFilePath = GetChemImagePathOnHexCode(strHexArr[j], intRegNo.ToString());
                                                    //img = iTextSharp.text.Image.GetInstance(strFilePath);
                                                    ////Resize image depend upon your need
                                                    //img.ScaleToFit(280f, 260f);
                                                    ////Give space before image
                                                    //img.SpacingBefore = 30f;
                                                    ////Give some space after the image
                                                    //img.SpacingAfter = 1f;
                                                    //img.Alignment = Element.ALIGN_CENTER;
                                                    //objPdf.Add(img);
                                                    //if (File.Exists(strFilePath))
                                                    //{
                                                    //    File.Delete(strFilePath);
                                                    //} 
                                                    #endregion

                                                    try
                                                    {
                                                        iTextSharp.text.Image chemimg = HexCodeToStructureImage.GetITextImageOnHexCode(objRegInfo.MolHexCodes[j].Trim(), intRegNo.ToString());
                                                        //Give space before image 
                                                        chemimg.SpacingBefore = 30f;
                                                        //Give some space after the image 
                                                        chemimg.SpacingAfter = 1f;
                                                        chemimg.Alignment = iTextSharp.text.Image.ALIGN_CENTER;// iTextSharp.text.Image.ALIGN_CENTER | iTextSharp.text.Image.TEXTWRAP;
                                                        //chemimg.ScaleToFit(width, height);
                                                        objPdf.Add(chemimg);
                                                    }
                                                    catch
                                                    {
                                                        objPdf.Add(new Chunk("Structure Error", FontFactory.GetFont("Arial", 10, 3, iTextSharp.text.BaseColor.RED)));
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                emptypara = new Paragraph("-------------------------------------------------------------------------------------------------------------------------------------------------------\r\n\r\n", georgia);
                                objPdf.Add(emptypara);
                            }
                        }
                        catch
                        {

                        }
                    }
                    objPdf.Close();
                    blStatus = true;
                }
            }
            catch (Exception ex)
            {
                if (objPdf != null)
                {
                    objPdf.Close();
                }
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private string GetABS_StereoFromArray(string[] _absstereo_arr)
        {
            string strABS = "";
            try
            {
                if (_absstereo_arr != null)
                {
                    for (int i = 0; i < _absstereo_arr.Length; i++)
                    {
                        if (_absstereo_arr[i] != null)
                        {
                            if (_absstereo_arr[i].Trim() == "")
                            {
                                _absstereo_arr[i] = "--";
                            }
                        }
                        else
                        {
                            _absstereo_arr[i] = "--";
                        }
                        if (strABS.Trim() == "")
                        {
                            strABS = _absstereo_arr[i];
                        }
                        else
                        {
                            strABS = strABS + ", " + _absstereo_arr[i].Trim();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strABS;
        }

        private DataTable GetCgmAndSubstanceDataOnBatchName(string _batchname, string _tan, string _can, out DataTable _substtbl)
        {
            DataTable dtCGM = null;
            DataTable dtSubstance = null;
            try
            {
                if (_batchname.Trim() != "")
                {
                    string strCgmPath = AppDomain.CurrentDomain.BaseDirectory + _batchname + ".cgm";
                    if (File.Exists(strCgmPath))
                    {
                        dtCGM = ReadCgm.GetCgmFileDataForNUMSearch(strCgmPath, _tan, _can, out dtSubstance);                        
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _substtbl = dtSubstance;
            return dtCGM;
        }

        private void txtTAN_Leave(object sender, EventArgs e)
        {
            //try
            //{
            //    if (txtBatch.Text.Trim() != "" && txtTAN.Text.Trim() != "")
            //    {
            //        TAN = txtTAN.Text.Trim();
            //        //TODO:analyse
            //        string strCAN = IndxReactNarrDAL.ReactDB.GetCANOnBatchTAN(txtBatch.Text.Trim(), txtTAN.Text.Trim());
            //        if (strCAN != "")
            //        {
            //            txtCAN.Text = strCAN;
            //        }

            //        Get_Set_Cgm_SubstData_XMLConvData();
            //    }
            //}
            //catch (Exception ex)
            //{
            //    ErrorHandling.WriteErrorLog(ex.ToString());
            //}
        }

        private void txtNUM_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == 13)
                {
                    if (txtNUM_Srch.Text.Trim() != "")
                    {
                        txtRegNo.Text = "";
                        txtFormula.Text = "";
                        txtIUPAC.Text = "";
                        txtOtherName.Text = "";                        

                        if (tlpnlStructs.RowCount > 0)
                        {
                            bool blStatus = false;
                            ucNUMDetails objNumDtls = null;
                            Control[] cntrlArr = tlpnlStructs.Controls.Find("ucNUMDetails", true);
                            if (cntrlArr != null)
                            {
                                if (cntrlArr.Length > 0)
                                {
                                    for (int i = 0; i < cntrlArr.Length; i++)
                                    {
                                        objNumDtls = (ucNUMDetails)cntrlArr[i];
                                        if (objNumDtls.NrnNum == txtNUM_Srch.Text.Trim())
                                        {
                                            tlpnlStructs.ScrollControlIntoView(objNumDtls);
                                            blStatus = true;
                                            break;
                                        }
                                    }
                                }
                            }
                            if (!blStatus)
                            {
                                MessageBox.Show("NUM: " + txtNUM_Srch.Text.Trim() + " not found in the results", "NUM Search", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtRegNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {              
                if (e.KeyChar == 13)
                {
                    if (txtRegNo.Text.Trim() != "")
                    {
                        txtNUM_Srch.Text = "";
                        txtFormula.Text = "";
                        txtIUPAC.Text = "";
                        txtOtherName.Text = "";

                        if (tlpnlStructs.RowCount > 0)
                        {
                            bool blStatus = false;
                            ucNUMDetails objNumDtls = null;
                            Control[] cntrlArr = tlpnlStructs.Controls.Find("ucNUMDetails", true);
                            if (cntrlArr != null)
                            {
                                if (cntrlArr.Length > 0)
                                {
                                    for (int i = 0; i < cntrlArr.Length; i++)
                                    {
                                        objNumDtls = (ucNUMDetails)cntrlArr[i];
                                        if (objNumDtls.RegNo == txtRegNo.Text.Trim())
                                        {
                                            tlpnlStructs.ScrollControlIntoView(objNumDtls);
                                            blStatus = true;
                                            break;
                                        }
                                    }
                                }
                            }
                            if (!blStatus)
                            {
                                MessageBox.Show("Reg.No. : " + txtRegNo.Text.Trim() + " not found in the results", "NUM Search", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtFormula_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == 13)
                {
                    if (txtFormula.Text.Trim() != "")
                    {
                        txtRegNo.Text = "";
                        txtNUM_Srch.Text = "";
                        txtIUPAC.Text = "";
                        txtOtherName.Text = "";
                        
                        if (tlpnlStructs.RowCount > 0)
                        {
                            bool blStatus = false;
                            ucNUMDetails objNumDtls = null;
                            Control[] cntrlArr = tlpnlStructs.Controls.Find("ucNUMDetails", true);
                            if (cntrlArr != null)
                            {
                                if (cntrlArr.Length > 0)
                                {
                                    for (int i = 0; i < cntrlArr.Length; i++)
                                    {
                                        objNumDtls = (ucNUMDetails)cntrlArr[i];
                                        if (objNumDtls.MolFormula.Contains(txtFormula.Text.Trim()))
                                        {
                                            tlpnlStructs.ScrollControlIntoView(objNumDtls);
                                            blStatus = true;
                                            break;
                                        }
                                    }
                                }
                            }
                            if (!blStatus)
                            {
                                MessageBox.Show("Formula : " + txtFormula.Text.Trim() + " not found in the results", "NUM Search", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtOtherName_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == 13)
                {
                    if (txtOtherName.Text.Trim() != "")
                    {
                        txtRegNo.Text = "";
                        txtFormula.Text = "";
                        txtIUPAC.Text = "";
                        txtNUM_Srch.Text = "";
                        
                        if (tlpnlStructs.RowCount > 0)
                        {
                            bool blStatus = false;
                            ucNUMDetails objNumDtls = null;
                            Control[] cntrlArr = tlpnlStructs.Controls.Find("ucNUMDetails", true);
                            if (cntrlArr != null)
                            {
                                if (cntrlArr.Length > 0)
                                {
                                    for (int i = 0; i < cntrlArr.Length; i++)
                                    {
                                        objNumDtls = (ucNUMDetails)cntrlArr[i];
                                        if (objNumDtls.Synonyms.Contains(txtOtherName.Text.Trim()))
                                        {
                                            tlpnlStructs.ScrollControlIntoView(objNumDtls);
                                            blStatus = true;
                                            break;
                                        }
                                    }
                                }
                            }
                            if (!blStatus)
                            {
                                MessageBox.Show("Other Name : " + txtOtherName.Text.Trim() + " not found in the results", "NUM Search", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtIUPAC_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == 13)
                {
                    if (txtIUPAC.Text.Trim() != "")
                    {
                        txtRegNo.Text = "";
                        txtFormula.Text = "";
                        txtNUM_Srch.Text = "";
                        txtOtherName.Text = "";
                        
                        if (tlpnlStructs.RowCount > 0)
                        {
                            bool blStatus = false;
                            ucNUMDetails objNumDtls = null;
                            Control[] cntrlArr = tlpnlStructs.Controls.Find("ucNUMDetails", true);
                            if (cntrlArr != null)
                            {
                                if (cntrlArr.Length > 0)
                                {
                                    for (int i = 0; i < cntrlArr.Length; i++)
                                    {
                                        objNumDtls = (ucNUMDetails)cntrlArr[i];
                                        if (objNumDtls.IUPACName.Contains(txtIUPAC.Text.Trim()))
                                        {
                                            tlpnlStructs.ScrollControlIntoView(objNumDtls);
                                            blStatus = true;
                                            break;
                                        }
                                    }
                                }
                            }
                            if (!blStatus)
                            {
                                MessageBox.Show("IUPAC Name : " + txtIUPAC.Text.Trim() + " not found in the results", "NUM Search", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        //private void txtNUMs_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        frmNUMs objNUMs = new frmNUMs();
        //        objNUMs.NrnNUM_RegTbl = NUMsTbl;
        //        if (objNUMs.ShowDialog() == DialogResult.OK)
        //        {
        //            if (objNUMs.Sel_NUM > 0)
        //            {
        //                txtNUMs.Text = objNUMs.Sel_NUM.ToString();
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}        
    }
}
