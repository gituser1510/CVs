﻿namespace IndxReactNarr
{
    partial class frmRSN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.splCont_Main = new System.Windows.Forms.SplitContainer();
            this.pnlCntrls = new System.Windows.Forms.Panel();
            this.pnlCVT_Free = new System.Windows.Forms.Panel();
            this.splCntCVT_FT = new System.Windows.Forms.SplitContainer();
            this.dgvCVT = new System.Windows.Forms.DataGridView();
            this.pnlCVT = new System.Windows.Forms.Panel();
            this.lblCVTSrch = new System.Windows.Forms.Label();
            this.txtSrch_CVT = new System.Windows.Forms.TextBox();
            this.dgvFreeText = new System.Windows.Forms.DataGridView();
            this.pnlFT_Opts = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.rbnAppend_FT = new System.Windows.Forms.RadioButton();
            this.rbnReplace_FT = new System.Windows.Forms.RadioButton();
            this.pnlFreeText = new System.Windows.Forms.Panel();
            this.lblFreeTextSrch = new System.Windows.Forms.Label();
            this.txtSrch_FreeText = new System.Windows.Forms.TextBox();
            this.pnlRSN_Opts = new System.Windows.Forms.Panel();
            this.lblStage = new System.Windows.Forms.Label();
            this.lblRSNOpt = new System.Windows.Forms.Label();
            this.rbnStage = new System.Windows.Forms.RadioButton();
            this.rbnReaction = new System.Windows.Forms.RadioButton();
            this.pnlADD = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rtxtFreeText = new Keyoti.RapidSpell.AYTRichTextBox();
            this.lblFreeText = new System.Windows.Forms.Label();
            this.pnlCVT_Entry = new System.Windows.Forms.Panel();
            this.txtCVT = new System.Windows.Forms.TextBox();
            this.lblCVT = new System.Windows.Forms.Label();
            this.pnlBtns = new System.Windows.Forms.Panel();
            this.btnAddRSN = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.pnlRSNGrid = new System.Windows.Forms.Panel();
            this.dgvRSN = new System.Windows.Forms.DataGridView();
            this.pnlSubmit = new System.Windows.Forms.Panel();
            this.lblTotalRSNLength = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblOthStgRSNLength = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblCurStgRsnLength = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.rapidSpellAsYouType1 = new Keyoti.RapidSpell.RapidSpellAsYouType(this.components);
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewLinkColumn1 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn2 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.colCVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFreeText = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCVT_RSN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFreeText_RSN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSelect = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdit_RSN = new System.Windows.Forms.DataGridViewLinkColumn();
            this.colDelete_RSN = new System.Windows.Forms.DataGridViewLinkColumn();
            this.pnlMain.SuspendLayout();
            this.splCont_Main.Panel1.SuspendLayout();
            this.splCont_Main.Panel2.SuspendLayout();
            this.splCont_Main.SuspendLayout();
            this.pnlCntrls.SuspendLayout();
            this.pnlCVT_Free.SuspendLayout();
            this.splCntCVT_FT.Panel1.SuspendLayout();
            this.splCntCVT_FT.Panel2.SuspendLayout();
            this.splCntCVT_FT.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCVT)).BeginInit();
            this.pnlCVT.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFreeText)).BeginInit();
            this.pnlFT_Opts.SuspendLayout();
            this.pnlFreeText.SuspendLayout();
            this.pnlRSN_Opts.SuspendLayout();
            this.pnlADD.SuspendLayout();
            this.panel1.SuspendLayout();
            this.pnlCVT_Entry.SuspendLayout();
            this.pnlBtns.SuspendLayout();
            this.pnlRSNGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRSN)).BeginInit();
            this.pnlSubmit.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.splCont_Main);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1064, 528);
            this.pnlMain.TabIndex = 0;
            // 
            // splCont_Main
            // 
            this.splCont_Main.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splCont_Main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splCont_Main.Location = new System.Drawing.Point(0, 0);
            this.splCont_Main.Name = "splCont_Main";
            this.splCont_Main.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splCont_Main.Panel1
            // 
            this.splCont_Main.Panel1.Controls.Add(this.pnlCntrls);
            // 
            // splCont_Main.Panel2
            // 
            this.splCont_Main.Panel2.Controls.Add(this.pnlRSNGrid);
            this.splCont_Main.Size = new System.Drawing.Size(1064, 528);
            this.splCont_Main.SplitterDistance = 366;
            this.splCont_Main.SplitterWidth = 3;
            this.splCont_Main.TabIndex = 2;
            // 
            // pnlCntrls
            // 
            this.pnlCntrls.Controls.Add(this.pnlCVT_Free);
            this.pnlCntrls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlCntrls.Location = new System.Drawing.Point(0, 0);
            this.pnlCntrls.Name = "pnlCntrls";
            this.pnlCntrls.Size = new System.Drawing.Size(1060, 362);
            this.pnlCntrls.TabIndex = 1;
            // 
            // pnlCVT_Free
            // 
            this.pnlCVT_Free.Controls.Add(this.splCntCVT_FT);
            this.pnlCVT_Free.Controls.Add(this.pnlRSN_Opts);
            this.pnlCVT_Free.Controls.Add(this.pnlADD);
            this.pnlCVT_Free.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlCVT_Free.Location = new System.Drawing.Point(0, 0);
            this.pnlCVT_Free.Name = "pnlCVT_Free";
            this.pnlCVT_Free.Size = new System.Drawing.Size(1060, 362);
            this.pnlCVT_Free.TabIndex = 1;
            // 
            // splCntCVT_FT
            // 
            this.splCntCVT_FT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splCntCVT_FT.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splCntCVT_FT.Location = new System.Drawing.Point(0, 29);
            this.splCntCVT_FT.Name = "splCntCVT_FT";
            // 
            // splCntCVT_FT.Panel1
            // 
            this.splCntCVT_FT.Panel1.Controls.Add(this.dgvCVT);
            this.splCntCVT_FT.Panel1.Controls.Add(this.pnlCVT);
            // 
            // splCntCVT_FT.Panel2
            // 
            this.splCntCVT_FT.Panel2.Controls.Add(this.dgvFreeText);
            this.splCntCVT_FT.Panel2.Controls.Add(this.pnlFT_Opts);
            this.splCntCVT_FT.Panel2.Controls.Add(this.pnlFreeText);
            this.splCntCVT_FT.Size = new System.Drawing.Size(1060, 246);
            this.splCntCVT_FT.SplitterDistance = 441;
            this.splCntCVT_FT.SplitterWidth = 3;
            this.splCntCVT_FT.TabIndex = 1;
            // 
            // dgvCVT
            // 
            this.dgvCVT.AllowUserToAddRows = false;
            this.dgvCVT.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.SeaShell;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.dgvCVT.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvCVT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvCVT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCVT.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCVT});
            this.dgvCVT.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCVT.Location = new System.Drawing.Point(0, 32);
            this.dgvCVT.MultiSelect = false;
            this.dgvCVT.Name = "dgvCVT";
            this.dgvCVT.ReadOnly = true;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvCVT.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvCVT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCVT.Size = new System.Drawing.Size(437, 210);
            this.dgvCVT.TabIndex = 1;
            this.dgvCVT.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCVT_CellDoubleClick);
            this.dgvCVT.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvCVT_RowPostPaint);
            // 
            // pnlCVT
            // 
            this.pnlCVT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCVT.Controls.Add(this.lblCVTSrch);
            this.pnlCVT.Controls.Add(this.txtSrch_CVT);
            this.pnlCVT.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCVT.Location = new System.Drawing.Point(0, 0);
            this.pnlCVT.Name = "pnlCVT";
            this.pnlCVT.Size = new System.Drawing.Size(437, 32);
            this.pnlCVT.TabIndex = 0;
            // 
            // lblCVTSrch
            // 
            this.lblCVTSrch.AutoSize = true;
            this.lblCVTSrch.Location = new System.Drawing.Point(3, 7);
            this.lblCVTSrch.Name = "lblCVTSrch";
            this.lblCVTSrch.Size = new System.Drawing.Size(38, 17);
            this.lblCVTSrch.TabIndex = 7;
            this.lblCVTSrch.Text = "CVT";
            // 
            // txtSrch_CVT
            // 
            this.txtSrch_CVT.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSrch_CVT.BackColor = System.Drawing.Color.White;
            this.txtSrch_CVT.Location = new System.Drawing.Point(47, 3);
            this.txtSrch_CVT.Name = "txtSrch_CVT";
            this.txtSrch_CVT.Size = new System.Drawing.Size(385, 25);
            this.txtSrch_CVT.TabIndex = 6;
            this.txtSrch_CVT.TextChanged += new System.EventHandler(this.txtSrch_CVT_TextChanged);
            // 
            // dgvFreeText
            // 
            this.dgvFreeText.AllowUserToAddRows = false;
            this.dgvFreeText.AllowUserToDeleteRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.SeaShell;
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            this.dgvFreeText.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvFreeText.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvFreeText.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFreeText.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colFreeText});
            this.dgvFreeText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvFreeText.Location = new System.Drawing.Point(0, 32);
            this.dgvFreeText.Name = "dgvFreeText";
            this.dgvFreeText.ReadOnly = true;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvFreeText.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvFreeText.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvFreeText.Size = new System.Drawing.Size(612, 183);
            this.dgvFreeText.TabIndex = 2;
            this.dgvFreeText.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvFreeText_CellDoubleClick);
            this.dgvFreeText.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvFreeText_RowPostPaint);
            // 
            // pnlFT_Opts
            // 
            this.pnlFT_Opts.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlFT_Opts.Controls.Add(this.label1);
            this.pnlFT_Opts.Controls.Add(this.rbnAppend_FT);
            this.pnlFT_Opts.Controls.Add(this.rbnReplace_FT);
            this.pnlFT_Opts.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlFT_Opts.Location = new System.Drawing.Point(0, 215);
            this.pnlFT_Opts.Name = "pnlFT_Opts";
            this.pnlFT_Opts.Size = new System.Drawing.Size(612, 27);
            this.pnlFT_Opts.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "Select FreeText Option";
            // 
            // rbnAppend_FT
            // 
            this.rbnAppend_FT.AutoSize = true;
            this.rbnAppend_FT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnAppend_FT.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnAppend_FT.ForeColor = System.Drawing.Color.Blue;
            this.rbnAppend_FT.Location = new System.Drawing.Point(279, 2);
            this.rbnAppend_FT.Name = "rbnAppend_FT";
            this.rbnAppend_FT.Size = new System.Drawing.Size(77, 21);
            this.rbnAppend_FT.TabIndex = 6;
            this.rbnAppend_FT.Text = "Append";
            this.rbnAppend_FT.UseVisualStyleBackColor = true;
            // 
            // rbnReplace_FT
            // 
            this.rbnReplace_FT.AutoSize = true;
            this.rbnReplace_FT.Checked = true;
            this.rbnReplace_FT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnReplace_FT.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnReplace_FT.ForeColor = System.Drawing.Color.Blue;
            this.rbnReplace_FT.Location = new System.Drawing.Point(175, 2);
            this.rbnReplace_FT.Name = "rbnReplace_FT";
            this.rbnReplace_FT.Size = new System.Drawing.Size(79, 21);
            this.rbnReplace_FT.TabIndex = 5;
            this.rbnReplace_FT.TabStop = true;
            this.rbnReplace_FT.Text = "Replace";
            this.rbnReplace_FT.UseVisualStyleBackColor = true;
            // 
            // pnlFreeText
            // 
            this.pnlFreeText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlFreeText.Controls.Add(this.lblFreeTextSrch);
            this.pnlFreeText.Controls.Add(this.txtSrch_FreeText);
            this.pnlFreeText.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlFreeText.Location = new System.Drawing.Point(0, 0);
            this.pnlFreeText.Name = "pnlFreeText";
            this.pnlFreeText.Size = new System.Drawing.Size(612, 32);
            this.pnlFreeText.TabIndex = 1;
            // 
            // lblFreeTextSrch
            // 
            this.lblFreeTextSrch.AutoSize = true;
            this.lblFreeTextSrch.Location = new System.Drawing.Point(3, 7);
            this.lblFreeTextSrch.Name = "lblFreeTextSrch";
            this.lblFreeTextSrch.Size = new System.Drawing.Size(61, 17);
            this.lblFreeTextSrch.TabIndex = 7;
            this.lblFreeTextSrch.Text = "FreeText";
            // 
            // txtSrch_FreeText
            // 
            this.txtSrch_FreeText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSrch_FreeText.BackColor = System.Drawing.Color.White;
            this.txtSrch_FreeText.Location = new System.Drawing.Point(71, 3);
            this.txtSrch_FreeText.Name = "txtSrch_FreeText";
            this.txtSrch_FreeText.Size = new System.Drawing.Size(536, 25);
            this.txtSrch_FreeText.TabIndex = 6;
            this.txtSrch_FreeText.TextChanged += new System.EventHandler(this.txtSrch_FreeText_TextChanged);
            // 
            // pnlRSN_Opts
            // 
            this.pnlRSN_Opts.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlRSN_Opts.Controls.Add(this.lblStage);
            this.pnlRSN_Opts.Controls.Add(this.lblRSNOpt);
            this.pnlRSN_Opts.Controls.Add(this.rbnStage);
            this.pnlRSN_Opts.Controls.Add(this.rbnReaction);
            this.pnlRSN_Opts.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlRSN_Opts.Location = new System.Drawing.Point(0, 0);
            this.pnlRSN_Opts.Name = "pnlRSN_Opts";
            this.pnlRSN_Opts.Size = new System.Drawing.Size(1060, 29);
            this.pnlRSN_Opts.TabIndex = 2;
            // 
            // lblStage
            // 
            this.lblStage.AutoSize = true;
            this.lblStage.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStage.ForeColor = System.Drawing.Color.Red;
            this.lblStage.Location = new System.Drawing.Point(376, 6);
            this.lblStage.Name = "lblStage";
            this.lblStage.Size = new System.Drawing.Size(0, 17);
            this.lblStage.TabIndex = 7;
            // 
            // lblRSNOpt
            // 
            this.lblRSNOpt.AutoSize = true;
            this.lblRSNOpt.Location = new System.Drawing.Point(8, 5);
            this.lblRSNOpt.Name = "lblRSNOpt";
            this.lblRSNOpt.Size = new System.Drawing.Size(120, 17);
            this.lblRSNOpt.TabIndex = 6;
            this.lblRSNOpt.Text = "Select RSN Option";
            // 
            // rbnStage
            // 
            this.rbnStage.AutoSize = true;
            this.rbnStage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnStage.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnStage.ForeColor = System.Drawing.Color.Blue;
            this.rbnStage.Location = new System.Drawing.Point(261, 3);
            this.rbnStage.Name = "rbnStage";
            this.rbnStage.Size = new System.Drawing.Size(62, 21);
            this.rbnStage.TabIndex = 5;
            this.rbnStage.Text = "Stage";
            this.rbnStage.UseVisualStyleBackColor = true;
            this.rbnStage.CheckedChanged += new System.EventHandler(this.rbnStage_CheckedChanged);
            // 
            // rbnReaction
            // 
            this.rbnReaction.AutoSize = true;
            this.rbnReaction.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnReaction.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnReaction.ForeColor = System.Drawing.Color.Blue;
            this.rbnReaction.Location = new System.Drawing.Point(149, 3);
            this.rbnReaction.Name = "rbnReaction";
            this.rbnReaction.Size = new System.Drawing.Size(84, 21);
            this.rbnReaction.TabIndex = 4;
            this.rbnReaction.Text = "Reaction";
            this.rbnReaction.UseVisualStyleBackColor = true;
            this.rbnReaction.CheckedChanged += new System.EventHandler(this.rbnReaction_CheckedChanged);
            // 
            // pnlADD
            // 
            this.pnlADD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlADD.Controls.Add(this.panel1);
            this.pnlADD.Controls.Add(this.pnlCVT_Entry);
            this.pnlADD.Controls.Add(this.pnlBtns);
            this.pnlADD.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlADD.Location = new System.Drawing.Point(0, 275);
            this.pnlADD.Name = "pnlADD";
            this.pnlADD.Size = new System.Drawing.Size(1060, 87);
            this.pnlADD.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rtxtFreeText);
            this.panel1.Controls.Add(this.lblFreeText);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 31);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(975, 54);
            this.panel1.TabIndex = 13;
            // 
            // rtxtFreeText
            // 
            this.rtxtFreeText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rtxtFreeText.ContextMenuDefault = null;
            this.rtxtFreeText.ForeColor = System.Drawing.Color.Blue;
            this.rtxtFreeText.Location = new System.Drawing.Point(75, 2);
            this.rtxtFreeText.Name = "rtxtFreeText";
            this.rtxtFreeText.ShowCutCopyPasteContextMenu = false;
            this.rtxtFreeText.ShowCutCopyPasteContextMenuStrip = true;
            this.rtxtFreeText.Size = new System.Drawing.Size(897, 51);
            this.rtxtFreeText.TabIndex = 9;
            this.rtxtFreeText.Text = "";
            this.rtxtFreeText.UnderlineYOffset = 0;
            this.rtxtFreeText.UseAccurateBaselineOffsetMethod = false;
            this.rtxtFreeText.UseUndoCompatibleTextAccess = false;
            // 
            // lblFreeText
            // 
            this.lblFreeText.AutoSize = true;
            this.lblFreeText.Location = new System.Drawing.Point(9, 5);
            this.lblFreeText.Name = "lblFreeText";
            this.lblFreeText.Size = new System.Drawing.Size(61, 17);
            this.lblFreeText.TabIndex = 8;
            this.lblFreeText.Text = "FreeText";
            // 
            // pnlCVT_Entry
            // 
            this.pnlCVT_Entry.Controls.Add(this.txtCVT);
            this.pnlCVT_Entry.Controls.Add(this.lblCVT);
            this.pnlCVT_Entry.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCVT_Entry.Location = new System.Drawing.Point(0, 0);
            this.pnlCVT_Entry.Name = "pnlCVT_Entry";
            this.pnlCVT_Entry.Size = new System.Drawing.Size(975, 31);
            this.pnlCVT_Entry.TabIndex = 12;
            // 
            // txtCVT
            // 
            this.txtCVT.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCVT.BackColor = System.Drawing.Color.White;
            this.txtCVT.ForeColor = System.Drawing.Color.Blue;
            this.txtCVT.Location = new System.Drawing.Point(75, 3);
            this.txtCVT.Name = "txtCVT";
            this.txtCVT.ReadOnly = true;
            this.txtCVT.Size = new System.Drawing.Size(897, 25);
            this.txtCVT.TabIndex = 5;
            // 
            // lblCVT
            // 
            this.lblCVT.AutoSize = true;
            this.lblCVT.Location = new System.Drawing.Point(33, 7);
            this.lblCVT.Name = "lblCVT";
            this.lblCVT.Size = new System.Drawing.Size(38, 17);
            this.lblCVT.TabIndex = 7;
            this.lblCVT.Text = "CVT";
            // 
            // pnlBtns
            // 
            this.pnlBtns.Controls.Add(this.btnAddRSN);
            this.pnlBtns.Controls.Add(this.btnReset);
            this.pnlBtns.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlBtns.Location = new System.Drawing.Point(975, 0);
            this.pnlBtns.Name = "pnlBtns";
            this.pnlBtns.Size = new System.Drawing.Size(83, 85);
            this.pnlBtns.TabIndex = 11;
            // 
            // btnAddRSN
            // 
            this.btnAddRSN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddRSN.Location = new System.Drawing.Point(5, 10);
            this.btnAddRSN.Name = "btnAddRSN";
            this.btnAddRSN.Size = new System.Drawing.Size(74, 26);
            this.btnAddRSN.TabIndex = 2;
            this.btnAddRSN.Text = "Add";
            this.btnAddRSN.UseVisualStyleBackColor = true;
            this.btnAddRSN.Click += new System.EventHandler(this.btnAddRSN_Click);
            // 
            // btnReset
            // 
            this.btnReset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReset.Location = new System.Drawing.Point(4, 50);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 26);
            this.btnReset.TabIndex = 10;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // pnlRSNGrid
            // 
            this.pnlRSNGrid.Controls.Add(this.dgvRSN);
            this.pnlRSNGrid.Controls.Add(this.pnlSubmit);
            this.pnlRSNGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRSNGrid.Location = new System.Drawing.Point(0, 0);
            this.pnlRSNGrid.Name = "pnlRSNGrid";
            this.pnlRSNGrid.Size = new System.Drawing.Size(1060, 155);
            this.pnlRSNGrid.TabIndex = 0;
            // 
            // dgvRSN
            // 
            this.dgvRSN.AllowUserToAddRows = false;
            this.dgvRSN.AllowUserToDeleteRows = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.SeaShell;
            this.dgvRSN.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvRSN.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvRSN.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvRSN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRSN.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCVT_RSN,
            this.colFreeText_RSN,
            this.colSelect,
            this.colEdit_RSN,
            this.colDelete_RSN});
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRSN.DefaultCellStyle = dataGridViewCellStyle7;
            this.dgvRSN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvRSN.Location = new System.Drawing.Point(0, 0);
            this.dgvRSN.Name = "dgvRSN";
            this.dgvRSN.ReadOnly = true;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dgvRSN.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvRSN.RowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvRSN.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.dgvRSN.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvRSN.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRSN.Size = new System.Drawing.Size(1060, 126);
            this.dgvRSN.TabIndex = 0;
            this.dgvRSN.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRSN_CellContentClick);
            this.dgvRSN.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvRSN_RowPostPaint);
            // 
            // pnlSubmit
            // 
            this.pnlSubmit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSubmit.Controls.Add(this.lblTotalRSNLength);
            this.pnlSubmit.Controls.Add(this.label5);
            this.pnlSubmit.Controls.Add(this.lblOthStgRSNLength);
            this.pnlSubmit.Controls.Add(this.label4);
            this.pnlSubmit.Controls.Add(this.lblCurStgRsnLength);
            this.pnlSubmit.Controls.Add(this.label2);
            this.pnlSubmit.Controls.Add(this.btnSubmit);
            this.pnlSubmit.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlSubmit.Location = new System.Drawing.Point(0, 126);
            this.pnlSubmit.Name = "pnlSubmit";
            this.pnlSubmit.Size = new System.Drawing.Size(1060, 29);
            this.pnlSubmit.TabIndex = 1;
            // 
            // lblTotalRSNLength
            // 
            this.lblTotalRSNLength.AutoSize = true;
            this.lblTotalRSNLength.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalRSNLength.ForeColor = System.Drawing.Color.Blue;
            this.lblTotalRSNLength.Location = new System.Drawing.Point(587, 5);
            this.lblTotalRSNLength.Name = "lblTotalRSNLength";
            this.lblTotalRSNLength.Size = new System.Drawing.Size(16, 17);
            this.lblTotalRSNLength.TabIndex = 13;
            this.lblTotalRSNLength.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(466, 5);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(112, 17);
            this.label5.TabIndex = 12;
            this.label5.Text = "Total RSN length:";
            // 
            // lblOthStgRSNLength
            // 
            this.lblOthStgRSNLength.AutoSize = true;
            this.lblOthStgRSNLength.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOthStgRSNLength.ForeColor = System.Drawing.Color.Blue;
            this.lblOthStgRSNLength.Location = new System.Drawing.Point(410, 6);
            this.lblOthStgRSNLength.Name = "lblOthStgRSNLength";
            this.lblOthStgRSNLength.Size = new System.Drawing.Size(16, 17);
            this.lblOthStgRSNLength.TabIndex = 11;
            this.lblOthStgRSNLength.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(243, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(158, 17);
            this.label4.TabIndex = 10;
            this.label4.Text = "Other stages RSN length:";
            // 
            // lblCurStgRsnLength
            // 
            this.lblCurStgRsnLength.AutoSize = true;
            this.lblCurStgRsnLength.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurStgRsnLength.ForeColor = System.Drawing.Color.Blue;
            this.lblCurStgRsnLength.Location = new System.Drawing.Point(174, 5);
            this.lblCurStgRsnLength.Name = "lblCurStgRsnLength";
            this.lblCurStgRsnLength.Size = new System.Drawing.Size(16, 17);
            this.lblCurStgRsnLength.TabIndex = 9;
            this.lblCurStgRsnLength.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(163, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "Current stage RSN length:";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSubmit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnSubmit.Location = new System.Drawing.Point(980, 1);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(73, 26);
            this.btnSubmit.TabIndex = 4;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // rapidSpellAsYouType1
            // 
            this.rapidSpellAsYouType1.AddMenuText = "Add";
            this.rapidSpellAsYouType1.AllowAnyCase = false;
            this.rapidSpellAsYouType1.AllowMixedCase = false;
            this.rapidSpellAsYouType1.AutoCorrectEnabled = true;
            this.rapidSpellAsYouType1.CheckAsYouType = true;
            this.rapidSpellAsYouType1.CheckCompoundWords = false;
            this.rapidSpellAsYouType1.CheckDisabledTextBoxes = false;
            this.rapidSpellAsYouType1.CheckReadOnlyTextBoxes = false;
            this.rapidSpellAsYouType1.ConsiderationRange = 500;
            this.rapidSpellAsYouType1.ContextMenuStripEnabled = true;
            this.rapidSpellAsYouType1.DictFilePath = "";
            this.rapidSpellAsYouType1.FindCapitalizedSuggestions = false;
            this.rapidSpellAsYouType1.GUILanguage = Keyoti.RapidSpell.LanguageType.ENGLISH;
            this.rapidSpellAsYouType1.IgnoreAllMenuText = "Ignore All";
            this.rapidSpellAsYouType1.IgnoreCapitalizedWords = false;
            this.rapidSpellAsYouType1.IgnoreURLsAndEmailAddresses = true;
            this.rapidSpellAsYouType1.IgnoreWordsWithDigits = true;
            this.rapidSpellAsYouType1.IgnoreXML = false;
            this.rapidSpellAsYouType1.IncludeUserDictionaryInSuggestions = true;
            this.rapidSpellAsYouType1.LanguageParser = Keyoti.RapidSpell.LanguageType.ENGLISH;
            this.rapidSpellAsYouType1.LookIntoHyphenatedText = true;
            this.rapidSpellAsYouType1.OptionsEnabled = true;
            this.rapidSpellAsYouType1.OptionsFileName = "RapidSpell_UserSettings.xml";
            this.rapidSpellAsYouType1.OptionsStorageLocation = Keyoti.RapidSpell.Options.UserOptions.StorageType.IsolatedStorage;
            this.rapidSpellAsYouType1.RemoveDuplicateWordText = "Remove duplicate word";
            this.rapidSpellAsYouType1.SeparateHyphenWords = false;
            this.rapidSpellAsYouType1.ShowAddMenuOption = true;
            this.rapidSpellAsYouType1.ShowCutCopyPasteMenuOnTextBoxBase = true;
            this.rapidSpellAsYouType1.ShowSuggestionsContextMenu = true;
            this.rapidSpellAsYouType1.ShowSuggestionsWhenTextIsSelected = false;
            this.rapidSpellAsYouType1.SuggestionsMethod = Keyoti.RapidSpell.SuggestionsMethodType.HashingSuggestions;
            this.rapidSpellAsYouType1.SuggestSplitWords = true;
            this.rapidSpellAsYouType1.TextBoxBase = this.rtxtFreeText;
            this.rapidSpellAsYouType1.TextComponent = null;
            this.rapidSpellAsYouType1.UnderlineColor = System.Drawing.Color.Red;
            this.rapidSpellAsYouType1.UnderlineStyle = Keyoti.RapidSpell.UnderlineStyle.Wavy;
            this.rapidSpellAsYouType1.UpdateAllTextBoxes = true;
            this.rapidSpellAsYouType1.UserDictionaryFile = "";
            this.rapidSpellAsYouType1.V2Parser = true;
            this.rapidSpellAsYouType1.WarnDuplicates = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.HeaderText = "CVT";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.HeaderText = "Free Text";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn3.FillWeight = 60F;
            this.dataGridViewTextBoxColumn3.HeaderText = "CVT";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridViewTextBoxColumn4.HeaderText = "FreeText";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 498;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Reaction/Stage";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewLinkColumn1
            // 
            this.dataGridViewLinkColumn1.HeaderText = "Edit";
            this.dataGridViewLinkColumn1.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn1.Name = "dataGridViewLinkColumn1";
            this.dataGridViewLinkColumn1.ReadOnly = true;
            this.dataGridViewLinkColumn1.Text = "Edit";
            this.dataGridViewLinkColumn1.TrackVisitedState = false;
            this.dataGridViewLinkColumn1.UseColumnTextForLinkValue = true;
            this.dataGridViewLinkColumn1.Width = 60;
            // 
            // dataGridViewLinkColumn2
            // 
            this.dataGridViewLinkColumn2.HeaderText = "Delete";
            this.dataGridViewLinkColumn2.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn2.Name = "dataGridViewLinkColumn2";
            this.dataGridViewLinkColumn2.ReadOnly = true;
            this.dataGridViewLinkColumn2.Text = "Delete";
            this.dataGridViewLinkColumn2.TrackVisitedState = false;
            this.dataGridViewLinkColumn2.UseColumnTextForLinkValue = true;
            this.dataGridViewLinkColumn2.Width = 60;
            // 
            // colCVT
            // 
            this.colCVT.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colCVT.HeaderText = "CVT";
            this.colCVT.Name = "colCVT";
            this.colCVT.ReadOnly = true;
            // 
            // colFreeText
            // 
            this.colFreeText.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colFreeText.HeaderText = "Free Text";
            this.colFreeText.Name = "colFreeText";
            this.colFreeText.ReadOnly = true;
            // 
            // colCVT_RSN
            // 
            this.colCVT_RSN.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colCVT_RSN.FillWeight = 60F;
            this.colCVT_RSN.HeaderText = "CVT";
            this.colCVT_RSN.Name = "colCVT_RSN";
            this.colCVT_RSN.ReadOnly = true;
            this.colCVT_RSN.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colFreeText_RSN
            // 
            this.colFreeText_RSN.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.colFreeText_RSN.DefaultCellStyle = dataGridViewCellStyle6;
            this.colFreeText_RSN.HeaderText = "FreeText";
            this.colFreeText_RSN.Name = "colFreeText_RSN";
            this.colFreeText_RSN.ReadOnly = true;
            this.colFreeText_RSN.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colFreeText_RSN.Width = 498;
            // 
            // colSelect
            // 
            this.colSelect.HeaderText = "Reaction/Stage";
            this.colSelect.Name = "colSelect";
            this.colSelect.ReadOnly = true;
            this.colSelect.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colEdit_RSN
            // 
            this.colEdit_RSN.HeaderText = "Edit";
            this.colEdit_RSN.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.colEdit_RSN.Name = "colEdit_RSN";
            this.colEdit_RSN.ReadOnly = true;
            this.colEdit_RSN.Text = "Edit";
            this.colEdit_RSN.TrackVisitedState = false;
            this.colEdit_RSN.UseColumnTextForLinkValue = true;
            this.colEdit_RSN.Width = 60;
            // 
            // colDelete_RSN
            // 
            this.colDelete_RSN.HeaderText = "Delete";
            this.colDelete_RSN.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.colDelete_RSN.Name = "colDelete_RSN";
            this.colDelete_RSN.ReadOnly = true;
            this.colDelete_RSN.Text = "Delete";
            this.colDelete_RSN.TrackVisitedState = false;
            this.colDelete_RSN.UseColumnTextForLinkValue = true;
            this.colDelete_RSN.Width = 60;
            // 
            // frmRSN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1064, 528);
            this.Controls.Add(this.pnlMain);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmRSN";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reaction Search Note";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmRSN_FormClosing);
            this.Load += new System.EventHandler(this.frmRSN_Load);
            this.pnlMain.ResumeLayout(false);
            this.splCont_Main.Panel1.ResumeLayout(false);
            this.splCont_Main.Panel2.ResumeLayout(false);
            this.splCont_Main.ResumeLayout(false);
            this.pnlCntrls.ResumeLayout(false);
            this.pnlCVT_Free.ResumeLayout(false);
            this.splCntCVT_FT.Panel1.ResumeLayout(false);
            this.splCntCVT_FT.Panel2.ResumeLayout(false);
            this.splCntCVT_FT.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCVT)).EndInit();
            this.pnlCVT.ResumeLayout(false);
            this.pnlCVT.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFreeText)).EndInit();
            this.pnlFT_Opts.ResumeLayout(false);
            this.pnlFT_Opts.PerformLayout();
            this.pnlFreeText.ResumeLayout(false);
            this.pnlFreeText.PerformLayout();
            this.pnlRSN_Opts.ResumeLayout(false);
            this.pnlRSN_Opts.PerformLayout();
            this.pnlADD.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlCVT_Entry.ResumeLayout(false);
            this.pnlCVT_Entry.PerformLayout();
            this.pnlBtns.ResumeLayout(false);
            this.pnlRSNGrid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRSN)).EndInit();
            this.pnlSubmit.ResumeLayout(false);
            this.pnlSubmit.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlCntrls;
        private System.Windows.Forms.Panel pnlRSNGrid;
        private System.Windows.Forms.DataGridView dgvRSN;
        private System.Windows.Forms.Panel pnlCVT_Free;
        private System.Windows.Forms.Panel pnlADD;
        private System.Windows.Forms.Button btnAddRSN;
        private System.Windows.Forms.SplitContainer splCntCVT_FT;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Panel pnlRSN_Opts;
        private System.Windows.Forms.Label lblRSNOpt;
        private System.Windows.Forms.RadioButton rbnStage;
        private System.Windows.Forms.RadioButton rbnReaction;
        private System.Windows.Forms.TextBox txtCVT;
        private System.Windows.Forms.Label lblFreeText;
        private System.Windows.Forms.Label lblCVT;
        private System.Windows.Forms.Panel pnlCVT;
        private System.Windows.Forms.TextBox txtSrch_CVT;
        private System.Windows.Forms.DataGridView dgvCVT;
        private System.Windows.Forms.Label lblCVTSrch;
        private System.Windows.Forms.Panel pnlFreeText;
        private System.Windows.Forms.Label lblFreeTextSrch;
        private System.Windows.Forms.TextBox txtSrch_FreeText;
        private System.Windows.Forms.DataGridView dgvFreeText;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCVT;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFreeText;
        private Keyoti.RapidSpell.AYTRichTextBox rtxtFreeText;
        private Keyoti.RapidSpell.RapidSpellAsYouType rapidSpellAsYouType1;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label lblStage;
        private System.Windows.Forms.Panel pnlFT_Opts;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rbnAppend_FT;
        private System.Windows.Forms.RadioButton rbnReplace_FT;
        private System.Windows.Forms.SplitContainer splCont_Main;
        private System.Windows.Forms.Panel pnlSubmit;
        private System.Windows.Forms.Panel pnlCVT_Entry;
        private System.Windows.Forms.Panel pnlBtns;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCVT_RSN;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFreeText_RSN;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSelect;
        private System.Windows.Forms.DataGridViewLinkColumn colEdit_RSN;
        private System.Windows.Forms.DataGridViewLinkColumn colDelete_RSN;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblCurStgRsnLength;
        private System.Windows.Forms.Label lblOthStgRSNLength;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblTotalRSNLength;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewLinkColumn dataGridViewLinkColumn1;
        private System.Windows.Forms.DataGridViewLinkColumn dataGridViewLinkColumn2;
    }
}