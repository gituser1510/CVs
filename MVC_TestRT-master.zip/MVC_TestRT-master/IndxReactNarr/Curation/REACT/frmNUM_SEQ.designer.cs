﻿namespace IndxReactNarr
{
    partial class frmNUM_SEQ
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvNUM_Seq = new System.Windows.Forms.DataGridView();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtRxnNUM = new System.Windows.Forms.TextBox();
            this.colRxnID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnNUM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnSeq = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNUM_Seq)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.dgvNUM_Seq);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(340, 343);
            this.pnlMain.TabIndex = 0;
            // 
            // dgvNUM_Seq
            // 
            this.dgvNUM_Seq.AllowUserToAddRows = false;
            this.dgvNUM_Seq.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvNUM_Seq.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvNUM_Seq.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvNUM_Seq.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNUM_Seq.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colRxnID,
            this.colRxnNUM,
            this.colRxnSeq});
            this.dgvNUM_Seq.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvNUM_Seq.Location = new System.Drawing.Point(0, 35);
            this.dgvNUM_Seq.Name = "dgvNUM_Seq";
            this.dgvNUM_Seq.ReadOnly = true;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.dgvNUM_Seq.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvNUM_Seq.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvNUM_Seq.Size = new System.Drawing.Size(340, 308);
            this.dgvNUM_Seq.TabIndex = 1;
            this.dgvNUM_Seq.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNUM_Seq_CellDoubleClick);
            this.dgvNUM_Seq.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvNUM_Seq_RowPostPaint);
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.label1);
            this.pnlTop.Controls.Add(this.txtRxnNUM);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(340, 35);
            this.pnlTop.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Enter NUM";
            // 
            // txtRxnNUM
            // 
            this.txtRxnNUM.Location = new System.Drawing.Point(88, 4);
            this.txtRxnNUM.Name = "txtRxnNUM";
            this.txtRxnNUM.Size = new System.Drawing.Size(100, 25);
            this.txtRxnNUM.TabIndex = 0;
            this.txtRxnNUM.TextChanged += new System.EventHandler(this.txtRxnNUM_TextChanged);
            // 
            // colRxnID
            // 
            this.colRxnID.HeaderText = "RxnID";
            this.colRxnID.Name = "colRxnID";
            this.colRxnID.ReadOnly = true;
            this.colRxnID.Visible = false;
            // 
            // colRxnNUM
            // 
            this.colRxnNUM.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colRxnNUM.HeaderText = "NUM";
            this.colRxnNUM.Name = "colRxnNUM";
            this.colRxnNUM.ReadOnly = true;
            this.colRxnNUM.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colRxnSeq
            // 
            this.colRxnSeq.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colRxnSeq.HeaderText = "Seq";
            this.colRxnSeq.Name = "colRxnSeq";
            this.colRxnSeq.ReadOnly = true;
            this.colRxnSeq.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // frmNUM_SEQ
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(340, 343);
            this.Controls.Add(this.pnlMain);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmNUM_SEQ";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product - Seq";
            this.Load += new System.EventHandler(this.frmNUM_SEQ_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNUM_Seq)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.DataGridView dgvNUM_Seq;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtRxnNUM;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnNUM;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnSeq;
    }
}