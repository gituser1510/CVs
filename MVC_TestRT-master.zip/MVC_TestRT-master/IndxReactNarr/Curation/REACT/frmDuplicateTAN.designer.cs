﻿namespace IndxReactNarr
{
    partial class frmDuplicateTAN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMain = new System.Windows.Forms.Panel();
            this.splCont = new System.Windows.Forms.SplitContainer();
            this.dgvSrcTan = new System.Windows.Forms.DataGridView();
            this.colTAN_Src = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNUM_Src = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colReg_Src = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvTrgt = new System.Windows.Forms.DataGridView();
            this.colTAN_Trgt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNUM_Trgt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colReg_Trgt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.btnDuplicate = new System.Windows.Forms.Button();
            this.lblAnalyst = new System.Windows.Forms.Label();
            this.txtAnalyst = new System.Windows.Forms.TextBox();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.lblCopyFrom = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSelTAN_Trgt = new System.Windows.Forms.Label();
            this.cmbTANs_Trgt = new System.Windows.Forms.ComboBox();
            this.btnGet_TrgtTAN = new System.Windows.Forms.Button();
            this.txtCAN = new System.Windows.Forms.TextBox();
            this.lblCAN = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBName_New = new System.Windows.Forms.TextBox();
            this.txtBNo_New = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lblCopyTo = new System.Windows.Forms.Label();
            this.pnlCopy = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTAN = new System.Windows.Forms.Label();
            this.txtfilename = new System.Windows.Forms.TextBox();
            this.cmbTANs = new System.Windows.Forms.ComboBox();
            this.txtBNo = new System.Windows.Forms.TextBox();
            this.btnGetTans = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lblNote = new System.Windows.Forms.Label();
            this.pnlMain.SuspendLayout();
            this.splCont.Panel1.SuspendLayout();
            this.splCont.Panel2.SuspendLayout();
            this.splCont.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSrcTan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTrgt)).BeginInit();
            this.pnlBottom.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.panel1.SuspendLayout();
            this.pnlCopy.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.splCont);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(776, 490);
            this.pnlMain.TabIndex = 0;
            // 
            // splCont
            // 
            this.splCont.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splCont.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splCont.Location = new System.Drawing.Point(0, 84);
            this.splCont.Name = "splCont";
            // 
            // splCont.Panel1
            // 
            this.splCont.Panel1.Controls.Add(this.dgvSrcTan);
            // 
            // splCont.Panel2
            // 
            this.splCont.Panel2.Controls.Add(this.dgvTrgt);
            this.splCont.Size = new System.Drawing.Size(776, 376);
            this.splCont.SplitterDistance = 386;
            this.splCont.TabIndex = 27;
            // 
            // dgvSrcTan
            // 
            this.dgvSrcTan.AllowUserToAddRows = false;
            this.dgvSrcTan.AllowUserToDeleteRows = false;
            this.dgvSrcTan.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvSrcTan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSrcTan.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTAN_Src,
            this.colNUM_Src,
            this.colReg_Src});
            this.dgvSrcTan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSrcTan.Location = new System.Drawing.Point(0, 0);
            this.dgvSrcTan.Name = "dgvSrcTan";
            this.dgvSrcTan.ReadOnly = true;
            this.dgvSrcTan.Size = new System.Drawing.Size(382, 372);
            this.dgvSrcTan.TabIndex = 0;
            this.dgvSrcTan.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvSrcTan_RowPostPaint);
            // 
            // colTAN_Src
            // 
            this.colTAN_Src.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colTAN_Src.HeaderText = "TAN";
            this.colTAN_Src.Name = "colTAN_Src";
            this.colTAN_Src.ReadOnly = true;
            // 
            // colNUM_Src
            // 
            this.colNUM_Src.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colNUM_Src.HeaderText = "NRNNUM";
            this.colNUM_Src.Name = "colNUM_Src";
            this.colNUM_Src.ReadOnly = true;
            // 
            // colReg_Src
            // 
            this.colReg_Src.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colReg_Src.HeaderText = "NRNReg";
            this.colReg_Src.Name = "colReg_Src";
            this.colReg_Src.ReadOnly = true;
            // 
            // dgvTrgt
            // 
            this.dgvTrgt.AllowUserToAddRows = false;
            this.dgvTrgt.AllowUserToDeleteRows = false;
            this.dgvTrgt.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvTrgt.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTrgt.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTAN_Trgt,
            this.colNUM_Trgt,
            this.colReg_Trgt});
            this.dgvTrgt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTrgt.Location = new System.Drawing.Point(0, 0);
            this.dgvTrgt.Name = "dgvTrgt";
            this.dgvTrgt.ReadOnly = true;
            this.dgvTrgt.Size = new System.Drawing.Size(382, 372);
            this.dgvTrgt.TabIndex = 1;
            this.dgvTrgt.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvTrgt_RowPostPaint);
            // 
            // colTAN_Trgt
            // 
            this.colTAN_Trgt.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colTAN_Trgt.HeaderText = "TAN";
            this.colTAN_Trgt.Name = "colTAN_Trgt";
            this.colTAN_Trgt.ReadOnly = true;
            // 
            // colNUM_Trgt
            // 
            this.colNUM_Trgt.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colNUM_Trgt.HeaderText = "NRNNUM";
            this.colNUM_Trgt.Name = "colNUM_Trgt";
            this.colNUM_Trgt.ReadOnly = true;
            // 
            // colReg_Trgt
            // 
            this.colReg_Trgt.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colReg_Trgt.HeaderText = "NRNReg";
            this.colReg_Trgt.Name = "colReg_Trgt";
            this.colReg_Trgt.ReadOnly = true;
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom.Controls.Add(this.lblNote);
            this.pnlBottom.Controls.Add(this.btnDuplicate);
            this.pnlBottom.Controls.Add(this.lblAnalyst);
            this.pnlBottom.Controls.Add(this.txtAnalyst);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 460);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(776, 30);
            this.pnlBottom.TabIndex = 26;
            // 
            // btnDuplicate
            // 
            this.btnDuplicate.AutoSize = true;
            this.btnDuplicate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDuplicate.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnDuplicate.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDuplicate.Location = new System.Drawing.Point(694, 0);
            this.btnDuplicate.Name = "btnDuplicate";
            this.btnDuplicate.Size = new System.Drawing.Size(80, 28);
            this.btnDuplicate.TabIndex = 8;
            this.btnDuplicate.Text = "Duplicate";
            this.btnDuplicate.UseVisualStyleBackColor = true;
            this.btnDuplicate.Click += new System.EventHandler(this.btnDuplicate_Click);
            // 
            // lblAnalyst
            // 
            this.lblAnalyst.AutoSize = true;
            this.lblAnalyst.Location = new System.Drawing.Point(508, 6);
            this.lblAnalyst.Name = "lblAnalyst";
            this.lblAnalyst.Size = new System.Drawing.Size(124, 17);
            this.lblAnalyst.TabIndex = 24;
            this.lblAnalyst.Text = "Enter Analyst Code";
            // 
            // txtAnalyst
            // 
            this.txtAnalyst.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAnalyst.ForeColor = System.Drawing.Color.Blue;
            this.txtAnalyst.Location = new System.Drawing.Point(638, 4);
            this.txtAnalyst.Name = "txtAnalyst";
            this.txtAnalyst.Size = new System.Drawing.Size(50, 21);
            this.txtAnalyst.TabIndex = 23;
            this.txtAnalyst.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.lblCopyFrom);
            this.pnlTop.Controls.Add(this.panel1);
            this.pnlTop.Controls.Add(this.lblCopyTo);
            this.pnlTop.Controls.Add(this.pnlCopy);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(776, 84);
            this.pnlTop.TabIndex = 25;
            // 
            // lblCopyFrom
            // 
            this.lblCopyFrom.AutoSize = true;
            this.lblCopyFrom.Location = new System.Drawing.Point(3, 1);
            this.lblCopyFrom.Name = "lblCopyFrom";
            this.lblCopyFrom.Size = new System.Drawing.Size(74, 17);
            this.lblCopyFrom.TabIndex = 22;
            this.lblCopyFrom.Text = "Copy From";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lblSelTAN_Trgt);
            this.panel1.Controls.Add(this.cmbTANs_Trgt);
            this.panel1.Controls.Add(this.btnGet_TrgtTAN);
            this.panel1.Controls.Add(this.txtCAN);
            this.panel1.Controls.Add(this.lblCAN);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtBName_New);
            this.panel1.Controls.Add(this.txtBNo_New);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Location = new System.Drawing.Point(392, 20);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(379, 59);
            this.panel1.TabIndex = 24;
            // 
            // lblSelTAN_Trgt
            // 
            this.lblSelTAN_Trgt.AutoSize = true;
            this.lblSelTAN_Trgt.Location = new System.Drawing.Point(3, 34);
            this.lblSelTAN_Trgt.Name = "lblSelTAN_Trgt";
            this.lblSelTAN_Trgt.Size = new System.Drawing.Size(79, 17);
            this.lblSelTAN_Trgt.TabIndex = 27;
            this.lblSelTAN_Trgt.Text = "Select TAN";
            // 
            // cmbTANs_Trgt
            // 
            this.cmbTANs_Trgt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTANs_Trgt.ForeColor = System.Drawing.Color.Blue;
            this.cmbTANs_Trgt.FormattingEnabled = true;
            this.cmbTANs_Trgt.Location = new System.Drawing.Point(88, 30);
            this.cmbTANs_Trgt.Name = "cmbTANs_Trgt";
            this.cmbTANs_Trgt.Size = new System.Drawing.Size(124, 25);
            this.cmbTANs_Trgt.Sorted = true;
            this.cmbTANs_Trgt.TabIndex = 26;
            this.cmbTANs_Trgt.SelectedIndexChanged += new System.EventHandler(this.cmbTANs_Trgt_SelectedIndexChanged);
            // 
            // btnGet_TrgtTAN
            // 
            this.btnGet_TrgtTAN.AutoSize = true;
            this.btnGet_TrgtTAN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGet_TrgtTAN.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGet_TrgtTAN.Location = new System.Drawing.Point(293, 3);
            this.btnGet_TrgtTAN.Name = "btnGet_TrgtTAN";
            this.btnGet_TrgtTAN.Size = new System.Drawing.Size(80, 25);
            this.btnGet_TrgtTAN.TabIndex = 25;
            this.btnGet_TrgtTAN.Text = "Get";
            this.btnGet_TrgtTAN.UseVisualStyleBackColor = true;
            this.btnGet_TrgtTAN.Click += new System.EventHandler(this.btnGet_TrgtTAN_Click);
            // 
            // txtCAN
            // 
            this.txtCAN.BackColor = System.Drawing.Color.White;
            this.txtCAN.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCAN.ForeColor = System.Drawing.Color.Blue;
            this.txtCAN.Location = new System.Drawing.Point(253, 32);
            this.txtCAN.Name = "txtCAN";
            this.txtCAN.ReadOnly = true;
            this.txtCAN.Size = new System.Drawing.Size(120, 21);
            this.txtCAN.TabIndex = 7;
            // 
            // lblCAN
            // 
            this.lblCAN.AutoSize = true;
            this.lblCAN.Location = new System.Drawing.Point(215, 34);
            this.lblCAN.Name = "lblCAN";
            this.lblCAN.Size = new System.Drawing.Size(40, 17);
            this.lblCAN.TabIndex = 22;
            this.lblCAN.Text = "CAN";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 17);
            this.label3.TabIndex = 11;
            this.label3.Text = "Batch Name";
            // 
            // txtBName_New
            // 
            this.txtBName_New.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBName_New.ForeColor = System.Drawing.Color.Blue;
            this.txtBName_New.Location = new System.Drawing.Point(88, 5);
            this.txtBName_New.Name = "txtBName_New";
            this.txtBName_New.Size = new System.Drawing.Size(92, 21);
            this.txtBName_New.TabIndex = 4;
            this.txtBName_New.Text = "rxnfile.80000";
            // 
            // txtBNo_New
            // 
            this.txtBNo_New.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBNo_New.ForeColor = System.Drawing.Color.Blue;
            this.txtBNo_New.Location = new System.Drawing.Point(253, 5);
            this.txtBNo_New.Name = "txtBNo_New";
            this.txtBNo_New.Size = new System.Drawing.Size(36, 21);
            this.txtBNo_New.TabIndex = 5;
            this.txtBNo_New.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(184, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 17);
            this.label5.TabIndex = 13;
            this.label5.Text = "Batch No.";
            // 
            // lblCopyTo
            // 
            this.lblCopyTo.AutoSize = true;
            this.lblCopyTo.Location = new System.Drawing.Point(389, 0);
            this.lblCopyTo.Name = "lblCopyTo";
            this.lblCopyTo.Size = new System.Drawing.Size(59, 17);
            this.lblCopyTo.TabIndex = 23;
            this.lblCopyTo.Text = "Copy To";
            // 
            // pnlCopy
            // 
            this.pnlCopy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCopy.Controls.Add(this.label1);
            this.pnlCopy.Controls.Add(this.lblTAN);
            this.pnlCopy.Controls.Add(this.txtfilename);
            this.pnlCopy.Controls.Add(this.cmbTANs);
            this.pnlCopy.Controls.Add(this.txtBNo);
            this.pnlCopy.Controls.Add(this.btnGetTans);
            this.pnlCopy.Controls.Add(this.label2);
            this.pnlCopy.Location = new System.Drawing.Point(3, 20);
            this.pnlCopy.Name = "pnlCopy";
            this.pnlCopy.Size = new System.Drawing.Size(383, 59);
            this.pnlCopy.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 17);
            this.label1.TabIndex = 11;
            this.label1.Text = "Batch Name";
            // 
            // lblTAN
            // 
            this.lblTAN.AutoSize = true;
            this.lblTAN.Location = new System.Drawing.Point(3, 34);
            this.lblTAN.Name = "lblTAN";
            this.lblTAN.Size = new System.Drawing.Size(79, 17);
            this.lblTAN.TabIndex = 20;
            this.lblTAN.Text = "Select TAN";
            // 
            // txtfilename
            // 
            this.txtfilename.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfilename.ForeColor = System.Drawing.Color.Blue;
            this.txtfilename.Location = new System.Drawing.Point(88, 5);
            this.txtfilename.Name = "txtfilename";
            this.txtfilename.Size = new System.Drawing.Size(92, 21);
            this.txtfilename.TabIndex = 0;
            this.txtfilename.Text = "rxnfile.80000";
            // 
            // cmbTANs
            // 
            this.cmbTANs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTANs.ForeColor = System.Drawing.Color.Blue;
            this.cmbTANs.FormattingEnabled = true;
            this.cmbTANs.Location = new System.Drawing.Point(88, 30);
            this.cmbTANs.Name = "cmbTANs";
            this.cmbTANs.Size = new System.Drawing.Size(124, 25);
            this.cmbTANs.Sorted = true;
            this.cmbTANs.TabIndex = 3;
            this.cmbTANs.SelectedIndexChanged += new System.EventHandler(this.cmbTANs_SelectedIndexChanged);
            // 
            // txtBNo
            // 
            this.txtBNo.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBNo.ForeColor = System.Drawing.Color.Blue;
            this.txtBNo.Location = new System.Drawing.Point(254, 5);
            this.txtBNo.Name = "txtBNo";
            this.txtBNo.Size = new System.Drawing.Size(37, 21);
            this.txtBNo.TabIndex = 1;
            this.txtBNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnGetTans
            // 
            this.btnGetTans.AutoSize = true;
            this.btnGetTans.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGetTans.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGetTans.Location = new System.Drawing.Point(298, 3);
            this.btnGetTans.Name = "btnGetTans";
            this.btnGetTans.Size = new System.Drawing.Size(80, 25);
            this.btnGetTans.TabIndex = 2;
            this.btnGetTans.Text = "Get";
            this.btnGetTans.UseVisualStyleBackColor = true;
            this.btnGetTans.Click += new System.EventHandler(this.btnGetTans_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(185, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 17);
            this.label2.TabIndex = 13;
            this.label2.Text = "Batch No.";
            // 
            // lblNote
            // 
            this.lblNote.AutoSize = true;
            this.lblNote.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNote.ForeColor = System.Drawing.Color.Red;
            this.lblNote.Location = new System.Drawing.Point(0, 6);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(482, 15);
            this.lblNote.TabIndex = 25;
            this.lblNote.Text = "Note: Duplication is possible if  Source && Target TANs have same NRNNUM && NRNRe" +
                "g";
            // 
            // frmDuplicateTAN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(776, 490);
            this.Controls.Add(this.pnlMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmDuplicateTAN";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Duplicate TAN";
            this.pnlMain.ResumeLayout(false);
            this.splCont.Panel1.ResumeLayout(false);
            this.splCont.Panel2.ResumeLayout(false);
            this.splCont.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSrcTan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTrgt)).EndInit();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlCopy.ResumeLayout(false);
            this.pnlCopy.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtfilename;
        private System.Windows.Forms.Button btnGetTans;
        private System.Windows.Forms.ComboBox cmbTANs;
        private System.Windows.Forms.Label lblCopyFrom;
        private System.Windows.Forms.Panel pnlCopy;
        private System.Windows.Forms.Label lblTAN;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBName_New;
        private System.Windows.Forms.TextBox txtBNo_New;
        private System.Windows.Forms.Button btnDuplicate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblCopyTo;
        private System.Windows.Forms.Label lblCAN;
        private System.Windows.Forms.TextBox txtCAN;
        private System.Windows.Forms.Label lblAnalyst;
        private System.Windows.Forms.TextBox txtAnalyst;
        private System.Windows.Forms.Button btnGet_TrgtTAN;
        private System.Windows.Forms.Label lblSelTAN_Trgt;
        private System.Windows.Forms.ComboBox cmbTANs_Trgt;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.SplitContainer splCont;
        private System.Windows.Forms.DataGridView dgvSrcTan;
        private System.Windows.Forms.DataGridView dgvTrgt;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTAN_Trgt;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNUM_Trgt;
        private System.Windows.Forms.DataGridViewTextBoxColumn colReg_Trgt;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTAN_Src;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNUM_Src;
        private System.Windows.Forms.DataGridViewTextBoxColumn colReg_Src;
        private System.Windows.Forms.Label lblNote;
    }
}