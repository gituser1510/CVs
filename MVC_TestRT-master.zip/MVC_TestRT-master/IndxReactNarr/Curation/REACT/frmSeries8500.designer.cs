﻿namespace IndxReactNarr
{
    partial class frmSeries8500
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvSer8500 = new System.Windows.Forms.DataGridView();
            this.Ser8500 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NRNREG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NRNNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.txtNrnReg = new System.Windows.Forms.TextBox();
            this.lblNrnReg = new System.Windows.Forms.Label();
            this.txtSer8500 = new System.Windows.Forms.TextBox();
            this.lblNrnNum = new System.Windows.Forms.Label();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSer8500)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.dgvSer8500);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(752, 480);
            this.pnlMain.TabIndex = 2;
            // 
            // dgvSer8500
            // 
            this.dgvSer8500.AllowUserToAddRows = false;
            this.dgvSer8500.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvSer8500.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSer8500.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvSer8500.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSer8500.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Ser8500,
            this.NRNREG,
            this.NRNNAME});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvSer8500.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvSer8500.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSer8500.Location = new System.Drawing.Point(0, 34);
            this.dgvSer8500.Name = "dgvSer8500";
            this.dgvSer8500.ReadOnly = true;
            this.dgvSer8500.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSer8500.Size = new System.Drawing.Size(752, 446);
            this.dgvSer8500.TabIndex = 7;
            this.dgvSer8500.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSer8500_CellDoubleClick);
            this.dgvSer8500.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvSer8500_RowPostPaint);
            // 
            // Ser8500
            // 
            this.Ser8500.HeaderText = "Series 8500";
            this.Ser8500.Name = "Ser8500";
            this.Ser8500.ReadOnly = true;
            // 
            // NRNREG
            // 
            this.NRNREG.HeaderText = "NrnReg";
            this.NRNREG.Name = "NRNREG";
            this.NRNREG.ReadOnly = true;
            // 
            // NRNNAME
            // 
            this.NRNNAME.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.NRNNAME.HeaderText = "Name";
            this.NRNNAME.Name = "NRNNAME";
            this.NRNNAME.ReadOnly = true;
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.White;
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.txtName);
            this.pnlTop.Controls.Add(this.lblName);
            this.pnlTop.Controls.Add(this.txtNrnReg);
            this.pnlTop.Controls.Add(this.lblNrnReg);
            this.pnlTop.Controls.Add(this.txtSer8500);
            this.pnlTop.Controls.Add(this.lblNrnNum);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(752, 34);
            this.pnlTop.TabIndex = 0;
            // 
            // txtName
            // 
            this.txtName.BackColor = System.Drawing.Color.White;
            this.txtName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(404, 4);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(343, 25);
            this.txtName.TabIndex = 14;
            this.txtName.TextChanged += new System.EventHandler(this.txtSer8500_TextChanged);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(359, 8);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(44, 17);
            this.lblName.TabIndex = 13;
            this.lblName.Text = "Name";
            // 
            // txtNrnReg
            // 
            this.txtNrnReg.BackColor = System.Drawing.Color.White;
            this.txtNrnReg.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNrnReg.Location = new System.Drawing.Point(250, 4);
            this.txtNrnReg.Name = "txtNrnReg";
            this.txtNrnReg.Size = new System.Drawing.Size(100, 25);
            this.txtNrnReg.TabIndex = 12;
            this.txtNrnReg.TextChanged += new System.EventHandler(this.txtSer8500_TextChanged);
            // 
            // lblNrnReg
            // 
            this.lblNrnReg.AutoSize = true;
            this.lblNrnReg.Location = new System.Drawing.Point(193, 8);
            this.lblNrnReg.Name = "lblNrnReg";
            this.lblNrnReg.Size = new System.Drawing.Size(55, 17);
            this.lblNrnReg.TabIndex = 11;
            this.lblNrnReg.Text = "NrnReg";
            // 
            // txtSer8500
            // 
            this.txtSer8500.BackColor = System.Drawing.Color.White;
            this.txtSer8500.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSer8500.Location = new System.Drawing.Point(83, 4);
            this.txtSer8500.Name = "txtSer8500";
            this.txtSer8500.Size = new System.Drawing.Size(100, 25);
            this.txtSer8500.TabIndex = 10;
            this.txtSer8500.TextChanged += new System.EventHandler(this.txtSer8500_TextChanged);
            // 
            // lblNrnNum
            // 
            this.lblNrnNum.AutoSize = true;
            this.lblNrnNum.Location = new System.Drawing.Point(4, 8);
            this.lblNrnNum.Name = "lblNrnNum";
            this.lblNrnNum.Size = new System.Drawing.Size(76, 17);
            this.lblNrnNum.TabIndex = 9;
            this.lblNrnNum.Text = "Series 8500";
            // 
            // frmSeries8500
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(752, 480);
            this.Controls.Add(this.pnlMain);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSeries8500";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Series 8500";
            this.Load += new System.EventHandler(this.frmSeries8500_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSer8500)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.DataGridView dgvSer8500;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtNrnReg;
        private System.Windows.Forms.Label lblNrnReg;
        private System.Windows.Forms.TextBox txtSer8500;
        private System.Windows.Forms.Label lblNrnNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ser8500;
        private System.Windows.Forms.DataGridViewTextBoxColumn NRNREG;
        private System.Windows.Forms.DataGridViewTextBoxColumn NRNNAME;
    }
}