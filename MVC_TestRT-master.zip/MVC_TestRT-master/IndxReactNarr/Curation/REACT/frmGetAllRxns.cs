﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using IndxReactNarrDAL;


namespace IndxReactNarr
{
    public partial class frmGetAllRxns : Form
    {
        public frmGetAllRxns()
        {
            InitializeComponent();
        }

        #region Property Procedures
        
        public string TAN
        {
            get;
            set;
        }

        public int TAN_ID
        {
            get;
            set;
        }

        public DataTable ProductDataTbl
        {
            get;
            set;
        }
               
        public DataTable RSNDataTbl
        {
            get;
            set;
        }
               
        public DataTable RXNCondDataTbl
        {
            get;
            set;
        }

        public DataTable ParticipantsTbl
        {
            get;
            set;
        }

        public DataTable StagesTbl
        {
            get;
            set;
        }

        public DataTable CgmDataTbl
        {
            get;
            set;
        }
        
        public DataTable Product_DistTbl
        {
            get;
            set;
        }
                
        public int NUM_ScrollPos
        { get; set; }
               
        public DataTable ReactionsTbl
        {
            get;
            set;
        }

        int PageSize = 50;

        public List<ucGetReaction> RxnCntrlsList { get; set; }

        #endregion

        public void GetAllRxnsDataOnTAN_BindToControl()
        {
            try
            {
                if (!string.IsNullOrEmpty(TAN))
                {
                    lblTAN.Text = TAN;
                    
                    //Get Product, Participants, Conditions and RSN Data and Save in Variables
                    GetProductPartpntsCondsOnTAN(TAN_ID);

                    //Get Product and Bind to controls
                    //GetReactionsDataBindToControl(TAN);
                    //GetReactionsDataBindToTableLayoutControl(TAN);
                    AddControlsToList(TAN);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetProductPartpntsCondsOnTAN(int tanID)
        {
            try
            {
                //Product details
                DataTable prodPartpnts = ReactDB.GetProduct_ParticipantsDataOnTAN(tanID);
                if (prodPartpnts != null)
                {
                    DataView dvTemp = prodPartpnts.DefaultView;
                    dvTemp.RowFilter = "PP_TYPE = 'PRODUCT'";
                    ProductDataTbl = dvTemp.ToTable();
                }

                ParticipantsTbl = prodPartpnts;

                //RSN Details
                RSNDataTbl = ReactDB.GetRSNDetailsOnTAN(tanID);                

                //Reaction Condition Details
                RXNCondDataTbl = ReactDB.GetConditionDataOnTAN(tanID);
                
                //All Stages on TAN
                StagesTbl = ReactDB.GetStagesOnTAN(tanID);                
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void EnableNavigationControls(bool enable_status)
        {
            try
            {
                pnlNavigCntrls.Enabled = enable_status;
                
                btnFirst.Enabled = enable_status;
                btnPrevious.Enabled = enable_status;
                btnNext.Enabled = enable_status;
                btnLast.Enabled = enable_status;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        int intRowCount = 0;
        private void GetReactionsDataBindToControl(string tan)
        {
            try
            {
                EnableNavigationControls(false);  

                DataTable dtReactions = ReactDB.Get_ReactionsData_on_TAN(tan);
                if (dtReactions != null)
                {
                    if (dtReactions.Rows.Count > 0)
                    {
                        int intPageSize = 10;                        

                        ////Check if Reactions count > Page Size, then enable navigation control
                        //if (dtReactions.Rows.Count > intPageSize)
                        //{
                        //    EnableNavigationControls(true);
                        //    MaxRecCnt = Convert.ToInt32(dtReactions.Rows.Count % intPageSize) == 0 ? Convert.ToInt32(dtReactions.Rows.Count / intPageSize) : Convert.ToInt32(dtReactions.Rows.Count / intPageSize) + 1;
                        //    numGotoRecord.Maximum = MaxRecCnt;
                        //}
                        //else
                        //{
                        //    EnableNavigationControls(false);
                        //}        
                        
                        int intRxnID = 0;

                        tlpnl_AllRxns.Controls.Clear();
                        tlpnl_AllRxns.RowStyles.Clear();                      
                        
                        tlpnl_AllRxns.RowCount = dtReactions.Rows.Count;
                        tlpnl_AllRxns.ColumnCount = 1;

                        for (int i = 0; i <= tlpnl_AllRxns.RowCount; i++)
                        {
                            RowStyle rStyle = new RowStyle();
                            rStyle.Height = 420;
                            rStyle.SizeType = SizeType.Absolute;
                            tlpnl_AllRxns.RowStyles.Add(rStyle);
                        }

                        DataTable dtProdTbl = null;
                        DataTable dtReactantTbl = null;
                        DataTable dtPartpntTbl = null;
                        DataTable dtCondsTbl = null;
                        DataTable dtRsnTbl = null;
                        DataTable dtStagesTbl = null;
                        GlobalVariables.CGMTbl_ForRxns = CgmDataTbl;
                        ucGetReaction objGetRxn = null;

                        for (int i = 0; i < dtReactions.Rows.Count; i++)
                        {
                            intRowCount++;
                            intRxnID = Convert.ToInt32(dtReactions.Rows[i]["id"].ToString().Trim());

                            objGetRxn = new ucGetReaction();
                            objGetRxn.Dock = DockStyle.Fill;

                            objGetRxn.SerialNo = (i + 1).ToString();

                            dtProdTbl = GetProductDataOnRxnNUM(intRxnID);
                            objGetRxn.ProductTbl = GetProducts_For_ProdFormation(dtProdTbl, intRxnID, "PRODUCT");
                            objGetRxn.ProdNUM = GetProductNUMAndYieldFromTable(dtProdTbl);

                            dtReactantTbl = GetReactantsDataOnRxnNUM(intRxnID);
                            objGetRxn.ReactantTbl = GetReactants_For_ProdFormation(dtReactantTbl);

                            dtPartpntTbl = GetParticipantsDataOnRxnNUM(intRxnID);
                            dtCondsTbl = GetConditionsDataOnRxnNUM(intRxnID);
                            dtRsnTbl = GetRSNDataOnRxnNUM(intRxnID);
                            dtStagesTbl = GetStagesOnRxnNUM(intRxnID);

                            objGetRxn.PartpntsTbl = GetParticipants_For_ProdFormation(dtPartpntTbl, dtCondsTbl, dtRsnTbl, dtStagesTbl);

                            //objGetRxn.CGMDataTbl = CgmDataTbl;
                            objGetRxn.GetReactionData_BindToPanel_New();
                            objGetRxn.TabIndex = i + 1;
                            objGetRxn.TabStop = true;
                            tlpnl_AllRxns.Controls.Add(objGetRxn, 0, intRowCount - 1);
                            tlpnl_AllRxns.ScrollControlIntoView(objGetRxn);
                        }

                        for (int i = 0; i <= intRowCount - 1; i++)
                        {
                            tlpnl_AllRxns.RowStyles[i].Height = 420;
                            tlpnl_AllRxns.RowStyles[i].SizeType = SizeType.Absolute;
                        }               
                    }
                }

                #region Main code commented
                //if (ProductDataTbl != null)
                //{
                //    if (ProductDataTbl.Rows.Count > 0)
                //    {
                //        int intRxnID = 0;

                //        tlpnl_AllRxns.Controls.Clear();
                //        tlpnl_AllRxns.RowStyles.Clear();

                //        DataTable dtProd_Dist = GetDistinctProducts();


                //        if (dtProd_Dist != null)
                //        {
                //            if (dtProd_Dist.Rows.Count > 0)
                //            {
                //                Product_DistTbl = dtProd_Dist;

                //                tlpnl_AllRxns.RowCount = dtProd_Dist.Rows.Count;
                //                tlpnl_AllRxns.ColumnCount = 1;

                //                for (int i = 0; i <= tlpnl_AllRxns.RowCount; i++)
                //                {
                //                    RowStyle rStyle = new RowStyle();
                //                    rStyle.Height = 420;
                //                    rStyle.SizeType = SizeType.Absolute;
                //                    tlpnl_AllRxns.RowStyles.Add(rStyle);
                //                }

                //                DataTable dtProdTbl = null;
                //                DataTable dtReactantTbl = null;
                //                DataTable dtPartpntTbl = null;
                //                DataTable dtCondsTbl = null;
                //                DataTable dtRsnTbl = null;
                //                DataTable dtStagesTbl = null;

                //                GlobalVariables.CGMTbl_ForRxns = CgmDataTbl;

                //                ucGetReaction objGetRxn = null;

                //                for (int i = 0; i < dtProd_Dist.Rows.Count; i++)
                //                {
                //                    intRowCount++;
                //                    intRxnID = Convert.ToInt32(dtProd_Dist.Rows[i][0].ToString().Trim());

                //                    objGetRxn = new ucGetReaction();
                //                    objGetRxn.Dock = DockStyle.Fill;

                //                    objGetRxn.SerialNo = (i + 1).ToString();

                //                    dtProdTbl = GetProductDataOnRxnNUM(intRxnID);
                //                    objGetRxn.ProductTbl = GetProducts_For_ProdFormation(dtProdTbl, intRxnID, "PRODUCT");
                //                    objGetRxn.ProdNUM = GetProductNUMAndYieldFromTable(dtProdTbl);

                //                    dtReactantTbl = GetReactantsDataOnRxnNUM(intRxnID);
                //                    objGetRxn.ReactantTbl = GetReactants_For_ProdFormation(dtReactantTbl);

                //                    dtPartpntTbl = GetParticipantsDataOnRxnNUM(intRxnID);
                //                    dtCondsTbl = GetConditionsDataOnRxnNUM(intRxnID);
                //                    dtRsnTbl = GetRSNDataOnRxnNUM(intRxnID);
                //                    dtStagesTbl = GetStagesOnRxnNUM(intRxnID);

                //                    objGetRxn.PartpntsTbl = GetParticipants_For_ProdFormation(dtPartpntTbl, dtCondsTbl, dtRsnTbl, dtStagesTbl);

                //                    //objGetRxn.CGMDataTbl = CgmDataTbl;
                //                    objGetRxn.GetReactionData_BindToPanel_New();

                //                    tlpnl_AllRxns.Controls.Add(objGetRxn, 0, intRowCount - 1);
                //                    tlpnl_AllRxns.ScrollControlIntoView(objGetRxn);
                //                }

                //                for (int i = 0; i <= intRowCount - 1; i++)
                //                {
                //                    tlpnl_AllRxns.RowStyles[i].Height = 420;
                //                    tlpnl_AllRxns.RowStyles[i].SizeType = SizeType.Absolute;
                //                }
                //            }
                //        }
                //    }
                //} 
                #endregion
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetReactionsDataBindToTableLayoutControl(string tan)
        {
            try
            {
                EnableNavigationControls(false);

                DataTable dtReactions = ReactDB.Get_ReactionsData_on_TAN(tan);
                if (dtReactions != null)
                {
                    ReactionsTbl = dtReactions;

                    if (dtReactions.Rows.Count > 0)
                    {
                        //Check if Reactions count > Page Size, then enable navigation control
                        if (dtReactions.Rows.Count > PageSize)
                        {
                            EnableNavigationControls(true);
                            MaxRecCnt = Convert.ToInt32(dtReactions.Rows.Count % PageSize) == 0 ? Convert.ToInt32(dtReactions.Rows.Count / PageSize) : Convert.ToInt32(dtReactions.Rows.Count / PageSize) + 1;
                            numGotoRecord.Minimum = 1;
                            numGotoRecord.Maximum = MaxRecCnt;
                            numGotoRecord.Value = 1;
                        }
                        else
                        {
                            numGotoRecord.Minimum = 1;
                            numGotoRecord.Maximum = dtReactions.Rows.Count;
                            numGotoRecord.Value = 1;
                            EnableNavigationControls(false);
                        }           
                    }
                }    
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        int rxnStartIndx = 0;
        int rxnEndIndx = 0;

        private void BindReactionsToTableLayOutPanelPageWise(int pagenum)
        {
            try
            {
                if (ReactionsTbl != null)
                {
                    if (pagenum > 0)
                    {
                        int intStart = (PageSize * (pagenum - 1)) + 1;
                        int intEnd = (PageSize + intStart) - 1;

                        rxnStartIndx = ReactionsTbl.Rows.Count <= intStart ? ReactionsTbl.Rows.Count : intStart;
                        rxnEndIndx = ReactionsTbl.Rows.Count <= intEnd ? ReactionsTbl.Rows.Count : intEnd;
                    }

                    tlpnl_AllRxns.Controls.Clear();
                    tlpnl_AllRxns.RowStyles.Clear();

                    tlpnl_AllRxns.RowCount = (rxnEndIndx - rxnStartIndx) + 1;//PageSize;
                    tlpnl_AllRxns.ColumnCount = 1;

                    for (int i = 0; i < tlpnl_AllRxns.RowCount; i++)
                    {
                        RowStyle rStyle = new RowStyle();
                        rStyle.Height = 420;
                        rStyle.SizeType = SizeType.Absolute;
                        tlpnl_AllRxns.RowStyles.Add(rStyle);
                    }

                    DataTable dtProdTbl = null;
                    DataTable dtReactantTbl = null;
                    DataTable dtPartpntTbl = null;
                    DataTable dtCondsTbl = null;
                    DataTable dtRsnTbl = null;
                    DataTable dtStagesTbl = null;
                    GlobalVariables.CGMTbl_ForRxns = CgmDataTbl;
                    ucGetReaction objGetRxn = null;
                    int intRxnID = 0;
                    intRowCount = 0;

                    for (int i = rxnStartIndx; i <= rxnEndIndx; i++)
                    {
                        intRowCount++;
                        intRxnID = Convert.ToInt32(ReactionsTbl.Rows[i - 1]["id"].ToString().Trim());

                        objGetRxn = new ucGetReaction();
                        objGetRxn.Dock = DockStyle.Fill;

                        objGetRxn.SerialNo = i.ToString();

                        dtProdTbl = GetProductDataOnRxnNUM(intRxnID);
                        objGetRxn.ProductTbl = GetProducts_For_ProdFormation(dtProdTbl, intRxnID, "PRODUCT");
                        objGetRxn.ProdNUM = GetProductNUMAndYieldFromTable(dtProdTbl);

                        dtReactantTbl = GetReactantsDataOnRxnNUM(intRxnID);
                        objGetRxn.ReactantTbl = GetReactants_For_ProdFormation(dtReactantTbl);

                        dtPartpntTbl = GetParticipantsDataOnRxnNUM(intRxnID);
                        dtCondsTbl = GetConditionsDataOnRxnNUM(intRxnID);
                        dtRsnTbl = GetRSNDataOnRxnNUM(intRxnID);
                        dtStagesTbl = GetStagesOnRxnNUM(intRxnID);

                        objGetRxn.PartpntsTbl = GetParticipants_For_ProdFormation(dtPartpntTbl, dtCondsTbl, dtRsnTbl, dtStagesTbl);
                                                
                        objGetRxn.GetReactionData_BindToPanel_New();
                        objGetRxn.TabIndex = i + 1;
                        objGetRxn.TabStop = true;
                        tlpnl_AllRxns.Controls.Add(objGetRxn, 0, intRowCount - 1);
                        tlpnl_AllRxns.ScrollControlIntoView(objGetRxn);
                    }

                    //for (int i = 0; i < tlpnl_AllRxns.RowCount; i++)
                    //{
                    //    tlpnl_AllRxns.RowStyles[i].Height = 420;
                    //    tlpnl_AllRxns.RowStyles[i].SizeType = SizeType.Absolute;
                    //}
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindReactionsToTableLayOutPanelPageWise_New(int pagenum)
        {
            try
            {
                if (ReactionsTbl != null)
                {
                    if (pagenum > 0)
                    {
                        int intStart = (PageSize * (pagenum - 1)) + 1;
                        int intEnd = (PageSize + intStart) - 1;

                        rxnStartIndx = ReactionsTbl.Rows.Count <= intStart ? ReactionsTbl.Rows.Count : intStart;
                        rxnEndIndx = ReactionsTbl.Rows.Count <= intEnd ? ReactionsTbl.Rows.Count : intEnd;
                    }

                    tlpnl_AllRxns.Controls.Clear();
                    tlpnl_AllRxns.RowStyles.Clear();

                    tlpnl_AllRxns.RowCount = (rxnEndIndx - rxnStartIndx) + 1;//PageSize;
                    tlpnl_AllRxns.ColumnCount = 1;

                    for (int i = 0; i < tlpnl_AllRxns.RowCount; i++)
                    {
                        RowStyle rStyle = new RowStyle();
                        rStyle.Height = 420;
                        rStyle.SizeType = SizeType.Absolute;
                        tlpnl_AllRxns.RowStyles.Add(rStyle);
                    }

                    int intCntrlIndx = 0;
                    for (int i = rxnStartIndx; i <= rxnEndIndx; i++)
                    {
                        tlpnl_AllRxns.Controls.Add(RxnCntrlsList[i - 1], 0, intCntrlIndx);
                        tlpnl_AllRxns.ScrollControlIntoView(RxnCntrlsList[i - 1]);
                        intCntrlIndx++;
                    }

                    for (int i = 0; i < tlpnl_AllRxns.RowCount; i++)
                    {
                        tlpnl_AllRxns.RowStyles[i].Height = 420;
                        tlpnl_AllRxns.RowStyles[i].SizeType = SizeType.Absolute;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void AddControlsToList(string tan)
        {
            try
            {
                EnableNavigationControls(false);

                DataTable dtReactions = ReactDB.Get_ReactionsData_on_TAN(tan);
                if (dtReactions != null)
                {
                    if (dtReactions.Rows.Count > 0)
                    {
                        ReactionsTbl = dtReactions;
                        
                        List<ucGetReaction> cntrlList = new List<ucGetReaction>();
                           
                        int intRxnID = 0;              

                        DataTable dtProdTbl = null;
                        DataTable dtReactantTbl = null;
                        DataTable dtPartpntTbl = null;
                        DataTable dtCondsTbl = null;
                        DataTable dtRsnTbl = null;
                        DataTable dtStagesTbl = null;
                        GlobalVariables.CGMTbl_ForRxns = CgmDataTbl;
                        ucGetReaction objGetRxn = null;

                        for (int i = 0; i < dtReactions.Rows.Count; i++)
                        {
                            intRowCount++;
                            intRxnID = Convert.ToInt32(dtReactions.Rows[i]["id"].ToString().Trim());

                            objGetRxn = new ucGetReaction();
                            //objGetRxn.Dock = DockStyle.Fill;
                            objGetRxn.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right) | System.Windows.Forms.AnchorStyles.Left)));

                            objGetRxn.SerialNo = (i + 1).ToString();

                            dtProdTbl = GetProductDataOnRxnNUM(intRxnID);
                            objGetRxn.ProductTbl = GetProducts_For_ProdFormation(dtProdTbl, intRxnID, "PRODUCT");
                            objGetRxn.ProdNUM = GetProductNUMAndYieldFromTable(dtProdTbl);

                            dtReactantTbl = GetReactantsDataOnRxnNUM(intRxnID);
                            objGetRxn.ReactantTbl = GetReactants_For_ProdFormation(dtReactantTbl);

                            dtPartpntTbl = GetParticipantsDataOnRxnNUM(intRxnID);
                            dtCondsTbl = GetConditionsDataOnRxnNUM(intRxnID);
                            dtRsnTbl = GetRSNDataOnRxnNUM(intRxnID);
                            dtStagesTbl = GetStagesOnRxnNUM(intRxnID);

                            objGetRxn.PartpntsTbl = GetParticipants_For_ProdFormation(dtPartpntTbl, dtCondsTbl, dtRsnTbl, dtStagesTbl);

                            //objGetRxn.CGMDataTbl = CgmDataTbl;
                            objGetRxn.GetReactionData_BindToPanel_New();
                            objGetRxn.TabIndex = i + 1;
                            objGetRxn.TabStop = true;
                            cntrlList.Add(objGetRxn);
                            //tlpnl_AllRxns.ScrollControlIntoView(objGetRxn);
                        }

                        RxnCntrlsList = cntrlList;

                        //Check if Reactions count > Page Size, then enable navigation control
                        if (dtReactions.Rows.Count > PageSize)
                        {
                            EnableNavigationControls(true);
                            MaxRecCnt = Convert.ToInt32(dtReactions.Rows.Count % PageSize) == 0 ? Convert.ToInt32(dtReactions.Rows.Count / PageSize) : Convert.ToInt32(dtReactions.Rows.Count / PageSize) + 1;
                            numGotoRecord.Minimum = 1;
                            numGotoRecord.Maximum = MaxRecCnt;
                            numGotoRecord.Value = 1;
                        }
                        else
                        {
                            numGotoRecord.Maximum = 1;//dtReactions.Rows.Count;
                            numGotoRecord.Minimum = 1;                           
                            numGotoRecord.Value = 1;
                            EnableNavigationControls(false);
                        }     
                        
                    }
                }             
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #region Helper Methods

        private DataTable GetDistinctProducts()
        {
            DataTable dtDistProd = null;
            try
            {
                if (ProductDataTbl != null)
                {
                    if (ProductDataTbl.Rows.Count > 0)
                    {
                        DataTable dtProd = ProductDataTbl.Copy();
                        DataView dvTemp = dtProd.DefaultView;
                       // dvTemp.Sort = "reaction_id asc";
                        DataTable dtTemp = dvTemp.ToTable(true, "reaction_id");
                        if (dtTemp != null)
                        {
                            dtDistProd = dtTemp;
                            return dtDistProd;

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtDistProd;
        }

        private DataTable GetProductDataOnRxnNUM(int _rxnnum)
        {
            DataTable dtProd = null;
            try
            {
                if (ProductDataTbl != null)
                {
                    if (ProductDataTbl.Rows.Count > 0)
                    {
                        dtProd = ProductDataTbl.Copy();
                        DataView dvTemp = dtProd.DefaultView;
                        dvTemp.RowFilter = "reaction_id = " + _rxnnum;
                        dtProd = dvTemp.ToTable();
                        return dtProd;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtProd;
        }

        private DataTable GetReactantsDataOnRxnNUM(int _rxnnum)
        {
            DataTable dtReactant = null;
            try
            {
                if (ParticipantsTbl != null)
                {
                    if (ParticipantsTbl.Rows.Count > 0)
                    {
                        dtReactant = ParticipantsTbl.Copy();
                        DataView dvTemp = dtReactant.DefaultView;
                        dvTemp.RowFilter = "reaction_id = " + _rxnnum + " and participant_type = 'REACTANT'";
                        //dvTemp.Sort = "rxn_stage_id asc";
                        dtReactant = dvTemp.ToTable();
                        return dtReactant;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtReactant;
        }

        private DataTable GetParticipantsDataOnRxnNUM(int _rxnnum)
        {
            DataTable dtPartpnts = null;
            try
            {
                if (ParticipantsTbl != null)
                {
                    if (ParticipantsTbl.Rows.Count > 0)
                    {
                        dtPartpnts = ParticipantsTbl.Copy();
                        DataView dvTemp = dtPartpnts.DefaultView;
                        dvTemp.RowFilter = "reaction_id = " + _rxnnum + " and participant_type <> 'REACTANT'";
                        //dvTemp.Sort = "rxn_stage_id asc";
                        dtPartpnts = dvTemp.ToTable();
                        return dtPartpnts;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtPartpnts;
        }

        private DataTable GetConditionsDataOnRxnNUM(int _rxnnum)
        {
            DataTable dtConds = null;
            try
            {
                if (RXNCondDataTbl != null)
                {
                    if (RXNCondDataTbl.Rows.Count > 0)
                    {
                        dtConds = RXNCondDataTbl.Copy();
                        DataView dvTemp = dtConds.DefaultView;
                        dvTemp.RowFilter = "reaction_id = " + _rxnnum;
                        //dvTemp.Sort = "rxn_stage_id asc";
                        dtConds = dvTemp.ToTable();
                        return dtConds;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtConds;
        }

        private DataTable GetRSNDataOnRxnNUM(int _rxnnum)
        {
            DataTable dtRsn = null;
            try
            {
                if (RSNDataTbl != null)
                {
                    if (RSNDataTbl.Rows.Count > 0)
                    {
                        dtRsn = RSNDataTbl.Copy();
                        DataView dvTemp = dtRsn.DefaultView;
                        dvTemp.RowFilter = "reaction_id = " + _rxnnum;
                        //dvTemp.Sort = "rxn_stage_id asc";
                        dtRsn = dvTemp.ToTable();
                        return dtRsn;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtRsn;
        }

        private DataTable GetStagesOnRxnNUM(int _rxnnum)
        {
            DataTable dtStages = null;
            try
            {
                if (StagesTbl != null)
                {
                    if (StagesTbl.Rows.Count > 0)
                    {
                        dtStages = StagesTbl.Copy();
                        DataView dvTemp = dtStages.DefaultView;
                        dvTemp.RowFilter = "reaction_id = " + _rxnnum;
                        //dvTemp.Sort = "stageid asc";
                        dtStages = dvTemp.ToTable();
                        return dtStages;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtStages;
        }

        private string GetStageNameOnRxnNUM_StageID(int _rxnnum,int _rxn_stage_id)
        {
            string strStageName = "";
            try
            {
                if (StagesTbl != null)
                {
                    if (StagesTbl.Rows.Count > 0)
                    {
                        DataTable dtStages = StagesTbl.Copy();
                        DataView dvTemp = dtStages.DefaultView;
                        dvTemp.RowFilter = "reaction_id = " + _rxnnum + " and stageid = " + _rxn_stage_id;                       
                        dtStages = dvTemp.ToTable();
                        strStageName = dtStages.Rows[0]["stage"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strStageName;
        }

        private string GetProductNUMAndYieldFromTable(DataTable _prodtbl)
        {
            string strProd = "";            
            try
            {
                if (_prodtbl != null)
                {
                    int intP_Num = 0;
                    int intP_9000 = 0;
                    int intP_8500 = 0;
                    int intP_8000 = 0;                    

                    if (_prodtbl.Rows.Count > 0)
                    {
                        for (int i = 0; i < _prodtbl.Rows.Count; i++)
                        {
                            int.TryParse(_prodtbl.Rows[i]["p_num"].ToString(), out intP_Num);
                            int.TryParse(_prodtbl.Rows[i]["p_9000"].ToString(), out intP_9000);
                            int.TryParse(_prodtbl.Rows[i]["p_8500"].ToString(), out intP_8500);
                            int.TryParse(_prodtbl.Rows[i]["p_8000"].ToString(), out intP_8000);
                                                        
                            if (intP_Num > 0)
                            {
                                if (strProd.Trim() == "")
                                {
                                    strProd = intP_Num.ToString();
                                }
                                else
                                {
                                    strProd = strProd + ", " + intP_Num.ToString();
                                }

                                if (_prodtbl.Rows[i]["yield"].ToString().Trim() != "")
                                {
                                    strProd = strProd + " (" + _prodtbl.Rows[i]["yield"].ToString().Trim() + "%" + ")";
                                }
                            }
                            else if (intP_9000 > 0)
                            {
                                if (strProd.Trim() == "")
                                {
                                    strProd = intP_9000.ToString();
                                }
                                else
                                {
                                    strProd = strProd + ", " + intP_9000.ToString();
                                }

                                if (_prodtbl.Rows[i]["yield"].ToString().Trim() != "")
                                {
                                    strProd = strProd + " (" + _prodtbl.Rows[i]["yield"].ToString().Trim() + "%" + ")";
                                }
                            }
                            else if (intP_8500 > 0)
                            {
                                if (strProd.Trim() == "")
                                {
                                    strProd = intP_8500.ToString();
                                }
                                else
                                {
                                    strProd = strProd + ", " + intP_8500.ToString();
                                }

                                if (_prodtbl.Rows[i]["yield"].ToString().Trim() != "")
                                {
                                    strProd = strProd + " (" + _prodtbl.Rows[i]["yield"].ToString().Trim() + "%" + ")";
                                }
                            }
                            else if (intP_8000 > 0)
                            {
                                if (strProd.Trim() == "")
                                {
                                    strProd = intP_8000.ToString();
                                }
                                else
                                {
                                    strProd = strProd + ", " + intP_8000.ToString();
                                }

                                if (_prodtbl.Rows[i]["yield"].ToString().Trim() != "")
                                {
                                    strProd = strProd + " (" + _prodtbl.Rows[i]["yield"].ToString().Trim() + "%" + ")";
                                }
                            }                          
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }           
            return strProd;
        }

        private DataTable GetProducts_For_ProdFormation(DataTable _dtprod_react,int _rxnnum, string _partpnttype)
        {
            DataTable dtReacts = null;
            try
            {
                if (_dtprod_react != null)
                {
                    if (_dtprod_react.Rows.Count > 0)
                    {
                        dtReacts = new DataTable();
                        dtReacts.Columns.Add("NUM", typeof(string));
                        dtReacts.Columns.Add("NrnReg", typeof(string));
                        dtReacts.Columns.Add("Structure", typeof(object));

                        DataView dvTemp = _dtprod_react.DefaultView;
                        if (_partpnttype.ToUpper() == "PRODUCT")
                        {
                            dvTemp.RowFilter = "reaction_id = " + _rxnnum + "";
                        }
                        else if (_partpnttype.ToUpper() == "REACTANT")
                        {
                            dvTemp.RowFilter = "reaction_id = " + _rxnnum + " and participant_type = 'REACTANT'";
                            dvTemp.Sort = "rxn_stage_id asc";
                        }
                        DataTable dtTemp = dvTemp.ToTable();

                        if (dtTemp != null)
                        {
                            if (dtTemp.Rows.Count > 0)
                            {
                                int intP_Num = 0;
                                int intP_9000 = 0;
                                int intP_8500 = 0;
                                int intP_8000 = 0;
                                DataRow dtRow = null;
                                object objStruct = null;

                                for (int i = 0; i < dtTemp.Rows.Count; i++)
                                {
                                    int.TryParse(dtTemp.Rows[i]["p_num"].ToString(), out intP_Num);
                                    int.TryParse(dtTemp.Rows[i]["p_9000"].ToString(), out intP_9000);
                                    int.TryParse(dtTemp.Rows[i]["p_8500"].ToString(), out intP_8500);
                                    int.TryParse(dtTemp.Rows[i]["p_8000"].ToString(), out intP_8000);

                                    if (intP_Num > 0)
                                    {
                                        dtRow = dtReacts.NewRow();
                                        dtRow["NUM"] = intP_Num;
                                        dtRow["NrnReg"] = dtTemp.Rows[i]["nrnreg"].ToString();
                                        objStruct = null;// CASRxnDataAccess.GetStructuresOnRegNo(intP_Num);
                                        if (objStruct == null)
                                        {
                                            // objStruct = GetStructure from CGM
                                        }
                                        else if (objStruct.ToString() == "")
                                        {
                                            objStruct = null;
                                        }

                                        dtRow["Structure"] = objStruct;
                                        dtReacts.Rows.Add(dtRow);
                                    }
                                    else if (intP_9000 > 0)
                                    {
                                        dtRow = dtReacts.NewRow();
                                        dtRow["NUM"] = intP_9000;
                                        dtRow["NrnReg"] = dtTemp.Rows[i]["nrnreg"].ToString();
                                        dtRow["Structure"] = null;// CASRxnDataAccess.GetStructuresOnRegNo(intP_9000);
                                        dtReacts.Rows.Add(dtRow);
                                    }
                                    else if (intP_8500 > 0)
                                    {
                                        dtRow = dtReacts.NewRow();
                                        dtRow["NUM"] = intP_8500;
                                        dtRow["NrnReg"] = dtTemp.Rows[i]["nrnreg"].ToString();
                                        dtRow["Structure"] = null;// CASRxnDataAccess.GetStructuresOnRegNo(intP_8500);
                                        dtReacts.Rows.Add(dtRow);
                                    }
                                    else if (intP_8000 > 0)
                                    {
                                        dtRow = dtReacts.NewRow();
                                        dtRow["NUM"] = intP_8000;
                                        dtRow["NrnReg"] = dtTemp.Rows[i]["nrnreg"].ToString();
                                        dtRow["Structure"] = GetStructureFrom8000Table(intP_8000);
                                        dtReacts.Rows.Add(dtRow);
                                    }
                                }
                                return dtReacts;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtReacts;
        }

        private DataTable GetReactants_For_ProdFormation(DataTable _reactanttbl)
        {
            DataTable dtReacts = null;
            try
            {
                if (_reactanttbl != null)
                {
                    if (_reactanttbl.Rows.Count > 0)
                    {
                        dtReacts = new DataTable();
                        dtReacts.Columns.Add("Stage", typeof(string));
                        dtReacts.Columns.Add("NUM", typeof(string));
                        dtReacts.Columns.Add("NrnReg", typeof(string));
                        dtReacts.Columns.Add("Structure", typeof(object));

                        DataTable dtReact = null;

                        int intP_Num = 0;
                        int intP_9000 = 0;
                        int intP_8500 = 0;
                        int intP_8000 = 0;

                        int intStageID = 0;

                        object objStruct = null;
                        DataRow dtRow = null;
                        string strStgName = "stage";

                        dtReact = _reactanttbl;

                        if (dtReact.Rows.Count > 0)
                        {
                            for (int rIndx = 0; rIndx < dtReact.Rows.Count; rIndx++)
                            {
                                int.TryParse(dtReact.Rows[rIndx]["p_num"].ToString(), out intP_Num);
                                int.TryParse(dtReact.Rows[rIndx]["p_9000"].ToString(), out intP_9000);
                                int.TryParse(dtReact.Rows[rIndx]["p_8500"].ToString(), out intP_8500);
                                int.TryParse(dtReact.Rows[rIndx]["p_8000"].ToString(), out intP_8000);
                                
                                objStruct = null;
                                if (intP_Num > 0)
                                {
                                    dtRow = dtReacts.NewRow();
                                    dtRow["Stage"] = GetStageNameOnRxnNUM_StageID(Convert.ToInt32(dtReact.Rows[rIndx]["reaction_id"]), Convert.ToInt32(dtReact.Rows[rIndx]["rxn_stage_id"]));
                                    dtRow["NUM"] = intP_Num;
                                    dtRow["NrnReg"] = dtReact.Rows[rIndx]["nrnreg"].ToString();
                                    objStruct = null;//  CASRxnDataAccess.GetStructuresOnRegNo(Convert.ToInt32(dtReact.Rows[rIndx]["nrnreg"]));
                                    if (objStruct == null)
                                    {
                                        // objStruct = GetStructure from CGM
                                    }
                                    dtRow["Structure"] = objStruct;
                                    dtReacts.Rows.Add(dtRow);
                                }
                                else if (intP_9000 > 0)
                                {
                                    dtRow = dtReacts.NewRow();
                                    dtRow["Stage"] = GetStageNameOnRxnNUM_StageID(Convert.ToInt32(dtReact.Rows[rIndx]["reaction_id"]), Convert.ToInt32(dtReact.Rows[rIndx]["rxn_stage_id"])); 
                                    dtRow["NUM"] = intP_9000;
                                    dtRow["NrnReg"] = dtReact.Rows[rIndx]["nrnreg"].ToString();
                                    dtRow["Structure"] = null;// CASRxnDataAccess.GetStructuresOnRegNo(Convert.ToInt32(dtReact.Rows[rIndx]["nrnreg"]));
                                    dtReacts.Rows.Add(dtRow);
                                }
                                else if (intP_8500 > 0)
                                {
                                    dtRow = dtReacts.NewRow();
                                    dtRow["Stage"] = GetStageNameOnRxnNUM_StageID(Convert.ToInt32(dtReact.Rows[rIndx]["reaction_id"]), Convert.ToInt32(dtReact.Rows[rIndx]["rxn_stage_id"]));
                                    dtRow["NUM"] = intP_8500;
                                    dtRow["NrnReg"] = dtReact.Rows[rIndx]["nrnreg"].ToString();
                                    dtRow["Structure"] = null;// CASRxnDataAccess.GetStructuresOnRegNo(Convert.ToInt32(dtReact.Rows[rIndx]["nrnreg"]));
                                    dtReacts.Rows.Add(dtRow);
                                }
                                else if (intP_8000 > 0)
                                {
                                    dtRow = dtReacts.NewRow();
                                    dtRow["Stage"] = GetStageNameOnRxnNUM_StageID(Convert.ToInt32(dtReact.Rows[rIndx]["reaction_id"]), Convert.ToInt32(dtReact.Rows[rIndx]["rxn_stage_id"]));
                                    dtRow["NUM"] = intP_8000;
                                    dtRow["NrnReg"] = dtReact.Rows[rIndx]["nrnreg"].ToString();
                                    dtRow["Structure"] = GetStructureFrom8000Table(intP_8000);
                                    dtReacts.Rows.Add(dtRow);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtReacts;
        }

        private DataTable GetParticipants_For_ProdFormation(DataTable _partpntstbl,DataTable _condstbl,DataTable _rsntbl,DataTable _stagestbl)
        {
            DataTable dtPartpnts = null;
            try
            {
                if (_stagestbl != null)
                {
                    if (_stagestbl.Rows.Count > 0)
                    {
                        dtPartpnts = new DataTable();
                        dtPartpnts.Columns.Add("Stage", typeof(string));
                        dtPartpnts.Columns.Add("Agents", typeof(string));
                        dtPartpnts.Columns.Add("Solvents", typeof(string));
                        dtPartpnts.Columns.Add("Catalysts", typeof(string));
                        dtPartpnts.Columns.Add("Temperature", typeof(string));
                        dtPartpnts.Columns.Add("Time", typeof(string));
                        dtPartpnts.Columns.Add("Pressure", typeof(string));
                        dtPartpnts.Columns.Add("pH", typeof(string));
                        dtPartpnts.Columns.Add("RSN_CVT", typeof(string));
                        dtPartpnts.Columns.Add("RSN_FT_Reaction", typeof(string));
                        dtPartpnts.Columns.Add("RSN_FT_Stage", typeof(string));

                        ucParticipants ucparpnt = null;
                        string strAgent = "";
                        string strSolvent = "";
                        string strCatalyst = "";
                        string strTemp = "";
                        string strTime = "";
                        string strPressure = "";
                        string strPh = "";
                        string strRSN_CVT = "";
                        string strRSN_FT_RXN = "";
                        string strRSN_FT_Stage = "";

                        int intStageID = 0;
                        string strStageName = "";

                        DataTable dt_Agent = null;
                        DataTable dt_Solvent = null;
                        DataTable dt_Catalyst = null;
                        DataTable dt_Conds = null;
                        DataTable dt_RSN = null;

                        for (int i = 0; i < _stagestbl.Rows.Count; i++)
                        {                            
                            intStageID = Convert.ToInt32(_stagestbl.Rows[i]["stageid"].ToString());
                            strStageName = _stagestbl.Rows[i]["stage"].ToString();

                            dt_Agent = GetPartpantDataFromTable_OnStageID(_partpntstbl, intStageID, "AGENT");
                            dt_Solvent = GetPartpantDataFromTable_OnStageID(_partpntstbl, intStageID, "SOLVENT");
                            dt_Catalyst = GetPartpantDataFromTable_OnStageID(_partpntstbl, intStageID, "CATALYST");
                            dt_Conds = GetPartpantDataFromTable_OnStageID(_condstbl, intStageID, "");
                            dt_RSN = GetPartpantDataFromTable_OnStageID(_rsntbl, intStageID, "");

                            strAgent = GetParticipantStringFromTable(dt_Agent, "AGENT");
                            strSolvent = GetParticipantStringFromTable(dt_Solvent, "SOLVENT");
                            strCatalyst = GetParticipantStringFromTable(dt_Catalyst, "CATALYST");
                            strTemp = GetCondtionsStringFromTable(dt_Conds, out strTime, out strPressure, out strPh);
                            strRSN_CVT = GetRSNDetailsFromTable(dt_RSN, out strRSN_FT_RXN, out strRSN_FT_Stage);

                            DataRow dtRow = dtPartpnts.NewRow();
                            dtRow["Stage"] = strStageName;
                            dtRow["Agents"] = strAgent;
                            dtRow["Solvents"] = strSolvent;
                            dtRow["Catalysts"] = strCatalyst;
                            dtRow["Temperature"] = strTemp;
                            dtRow["Time"] = strTime;
                            dtRow["Pressure"] = strPressure;
                            dtRow["pH"] = strPh;
                            dtRow["RSN_CVT"] = strRSN_CVT;
                            dtRow["RSN_FT_Reaction"] = strRSN_FT_RXN;
                            dtRow["RSN_FT_Stage"] = strRSN_FT_Stage;
                            dtPartpnts.Rows.Add(dtRow);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtPartpnts;
        }

        private DataTable GetPartpantDataFromTable_OnStageID(DataTable _partpnttbl, int _stageid,string _partpnttype)
        {
            DataTable dtpatpnt = null;
            try
            {
                if (_partpnttbl != null)
                {
                    if (_partpnttbl.Rows.Count > 0 && _stageid > 0)
                    {                       
                        DataView dvTemp = _partpnttbl.DefaultView;
                        if (_partpnttype.Trim() != "")
                        {
                            dvTemp.RowFilter = "rxn_stage_id = " + _stageid + " and participant_type = '" + _partpnttype + "'";
                        }
                        else
                        {
                            dvTemp.RowFilter = "rxn_stage_id = " + _stageid;
                        }
                        dtpatpnt = dvTemp.ToTable();
                        return dtpatpnt;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtpatpnt;
        }

        private object GetStructureFrom8000Table(int _ser8000val)
        {
            object objStruct = null;
            try
            {
                DataTable dtSer8000 = Generic.GlobalVariables.TAN_Series8000Data;
                if (dtSer8000 != null)
                {
                    if (dtSer8000.Rows.Count > 0)
                    {
                        DataView dvTemp = dtSer8000.DefaultView;
                        dvTemp.RowFilter = "tan = '" + TAN + "'";
                        DataTable dtTAN_8000 = dvTemp.ToTable();
                        if (dtTAN_8000 != null)
                        {
                            if (dtTAN_8000.Rows.Count > 0)
                            {
                                DataRow[] dtRArr = dtTAN_8000.Select("ser8000 = " + _ser8000val);
                                if (dtRArr != null)
                                {
                                    if (dtRArr.Length > 0)
                                    {
                                        objStruct = dtRArr[0]["substmol"];
                                        return objStruct;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return objStruct;
        }

        private string GetParticipantStringFromTable(DataTable partpnttbl, string partpnt)
        {
            string strPartpnt = "";
            string strValue = "";
            try
            {
                string strTemp = "";
                if (partpnt == "AGENT")
                {
                    strTemp = "NO AGENT";
                }
                else if (partpnt == "SOLVENT")
                {
                    strTemp = "NO SOLVENT";
                }
                else if (partpnt == "CATALYST")
                {
                    strTemp = "NO CATALYST";
                }

                if (partpnttbl != null)
                {
                    if (partpnttbl.Rows.Count > 0)
                    {
                        for (int i = 0; i < partpnttbl.Rows.Count; i++)
                        {
                            strValue = "";
                            
                            if (partpnttbl.Rows[i]["name"].ToString().Trim() != "")
                            {
                                if (partpnttbl.Rows[i]["name"].ToString().Trim().ToUpper() != strTemp)
                                {
                                    strValue = partpnttbl.Rows[i]["name"].ToString().Trim();
                                }
                                else if (partpnttbl.Rows[i]["name"].ToString().Trim().ToUpper() == strTemp)
                                {
                                    if (partpnttbl.Rows[i]["p_8000"].ToString().Trim() != "0")
                                    {
                                        strValue = partpnttbl.Rows[i]["p_8000"].ToString().Trim();
                                    }
                                }
                            }
                            if (partpnttbl.Rows[i]["p_num"].ToString().Trim() != "")
                            {
                                if (partpnttbl.Rows[i]["p_num"].ToString().Trim() != "0")
                                {
                                    strValue = partpnttbl.Rows[i]["p_num"].ToString().Trim();
                                }
                            }
                            if (partpnttbl.Rows[i]["p_8000"].ToString().Trim() != "")
                            {
                                if (partpnttbl.Rows[i]["p_8000"].ToString().Trim() != "0")
                                {
                                    strValue = partpnttbl.Rows[i]["p_8000"].ToString().Trim();
                                }
                            }

                            if (strPartpnt.Trim() == "")
                            {
                                if (strValue.Trim() != "")
                                {
                                    strPartpnt = partpnt + "= " + strValue;
                                }
                            }
                            else
                            {
                                if (strValue.Trim() != "")
                                {
                                    strPartpnt = strPartpnt + ", " + strValue;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strPartpnt;
        }

        private string GetCondtionsStringFromTable(DataTable condstbl, out string time_out, out string pressure_out, out string ph_out)
        {
            string strTemp = "";
            string strTime = "";
            string strPressure = "";
            string strPH = "";

            try
            {
                if (condstbl != null)
                {
                    if (condstbl.Rows.Count > 0)
                    {
                        for (int i = 0; i < condstbl.Rows.Count; i++)
                        {
                            if (condstbl.Rows[i]["temperature"].ToString().Trim() != "")
                            {
                                if (strTemp.Trim() == "")
                                {
                                    strTemp = "TP: " + condstbl.Rows[i]["temperature"].ToString();
                                }
                                else
                                {
                                    strTemp = strTemp + "," + condstbl.Rows[i]["temperature"].ToString();
                                }
                            }
                            if (condstbl.Rows[i]["time"].ToString().Trim() != "")
                            {
                                if (strTime.Trim() == "")
                                {
                                    strTime = "TM: " + condstbl.Rows[i]["time"].ToString();
                                }
                                else
                                {
                                    strTime = strTime + "," + condstbl.Rows[i]["time"].ToString();
                                }
                            }
                            else
                            {
                                if (condstbl.Rows[i]["temperature"].ToString().Trim() != "")
                                {
                                    if (strTime.Trim() == "")
                                    {
                                        strTime = "TM: ";
                                    }
                                    else
                                    {
                                        strTime = strTime + ",";
                                    }
                                }
                            }
                            if (condstbl.Rows[i]["pressure"].ToString().Trim() != "")
                            {
                                if (strPressure.Trim() == "")
                                {
                                    strPressure = "PR: " + condstbl.Rows[i]["pressure"].ToString();
                                }
                                else
                                {
                                    strPressure = strPressure + "," + condstbl.Rows[i]["pressure"].ToString();
                                }
                            }
                            if (condstbl.Rows[i]["ph"].ToString().Trim() != "")
                            {
                                if (strPH.Trim() == "")
                                {
                                    strPH = "PH: " + condstbl.Rows[i]["ph"].ToString();
                                }
                                else
                                {
                                    strPH = strPH + "," + condstbl.Rows[i]["ph"].ToString();
                                }
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            time_out = strTime;
            pressure_out = strPressure;
            ph_out = strPH;
            return strTemp;
        }

        private string GetRSNDetailsFromTable(DataTable rsntbl, out string _freetext_rxn, out string _freetext_stage)
        {
            string strRSN_CVT = "";
            string strRSN_FT_Rxn = "";
            string strRSN_FT_Stage = "";
            string strValue = "";
            try
            {
                if (rsntbl != null)
                {
                    if (rsntbl.Rows.Count > 0)
                    {
                        for (int i = 0; i < rsntbl.Rows.Count; i++)
                        {
                            if (rsntbl.Rows[i]["rsn_cvt"].ToString().Trim() != "")
                            {
                                strValue = rsntbl.Rows[i]["rsn_cvt"].ToString().Trim();
                                if (strRSN_CVT.Trim() == "")
                                {
                                    strRSN_CVT = strValue;
                                }
                                else
                                {
                                    strRSN_CVT = strRSN_CVT + ", " + strValue;
                                }
                            }
                            if (rsntbl.Rows[i]["rsn_free_text"].ToString().Trim() != "")
                            {
                                strValue = rsntbl.Rows[i]["rsn_free_text"].ToString().Trim();
                                if (rsntbl.Rows[i]["rsn_combined"].ToString().Trim() == "Reaction")
                                {
                                    if (strRSN_FT_Rxn.Trim() == "")
                                    {
                                        strRSN_FT_Rxn = strValue;
                                    }
                                    else
                                    {
                                        strRSN_FT_Rxn = strRSN_FT_Rxn + ", " + strValue;
                                    }
                                }
                                else if (rsntbl.Rows[i]["rsn_combined"].ToString().Trim() == "Stage")
                                {
                                    if (strRSN_FT_Stage.Trim() == "")
                                    {
                                        strRSN_FT_Stage = strValue;
                                    }
                                    else
                                    {
                                        strRSN_FT_Stage = strRSN_FT_Stage + ", " + strValue;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _freetext_rxn = strRSN_FT_Rxn;
            _freetext_stage = strRSN_FT_Stage;
            return strRSN_CVT;
        }

        #endregion

        private void tlpnl_AllRxns_Layout(object sender, LayoutEventArgs e)
        {
            if (sender == typeof(TableLayoutPanel))
            {
                try
                {
                    tlpnl_AllRxns.Controls[0].Dock = DockStyle.Fill;
                }
                catch (Exception ex)
                {
                    ErrorHandling.WriteErrorLog(ex.ToString());
                }
            }
        }

        private void txtNUM_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtNUM.Text.Trim()))
                {
                    if (e.KeyChar == 13)
                    {
                        SearchNUMAndScrollToUserControl(txtNUM.Text.Trim());
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void SearchNUMAndScrollToUserControl(string selected_num)
        {
            try
            {
                if (tlpnl_AllRxns.RowCount > 0)
                {
                    bool blStatus = false;
                    ucGetReaction objGetRxn = null;
                    Control[] cntrlArr = tlpnl_AllRxns.Controls.Find("ucGetReaction", true);
                    if (cntrlArr != null)
                    {
                        if (cntrlArr.Length > 0)
                        {
                            for (int i = 0; i < cntrlArr.Length; i++)
                            {
                                objGetRxn = (ucGetReaction)cntrlArr[i];
                                if (objGetRxn.ProdNUM == selected_num.Trim())
                                {                                                                    
                                    tlpnl_AllRxns.ScrollControlIntoView(objGetRxn);                                    
                                    blStatus = true;
                                    break;
                                }
                                else if (objGetRxn.ProdNUM.Contains(",")) //Multiple products
                                {
                                    string[] splitter = { "," };
                                    string[] prodNums = objGetRxn.ProdNUM.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                                    if (prodNums != null)
                                    {
                                        if (prodNums.Length > 0)
                                        {
                                            for (int k = 0; k < prodNums.Length; k++)
                                            {
                                                if (prodNums[k].Trim() == selected_num.Trim())
                                                {
                                                    tlpnl_AllRxns.ScrollControlIntoView(objGetRxn);
                                                    blStatus = true;
                                                    return;
                                                }
                                                else if (prodNums[k].Trim().Contains("("))
                                                {
                                                    string[] splter_b = { "(" };
                                                    string[] pNums = prodNums[k].Trim().Split(splter_b, StringSplitOptions.RemoveEmptyEntries);
                                                    if (pNums != null)
                                                    {
                                                        if (pNums.Length > 0)
                                                        {
                                                            if (pNums[0].Trim() == selected_num.Trim())
                                                            {
                                                                tlpnl_AllRxns.ScrollControlIntoView(objGetRxn);
                                                                blStatus = true;
                                                                return;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                else if (objGetRxn.ProdNUM.Contains("("))
                                {
                                    string[] splitter = { "(" };
                                    string[] prodNums = objGetRxn.ProdNUM.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                                    if (prodNums != null)
                                    {
                                        if (prodNums.Length > 0)
                                        {
                                            if (prodNums[0].Trim() == selected_num.Trim())
                                            {
                                                tlpnl_AllRxns.ScrollControlIntoView(objGetRxn);
                                                blStatus = true;
                                                return;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (!blStatus)
                    {
                        MessageBox.Show("Product: " + txtNUM.Text.Trim() + " not found in the results", "Get All Reactions", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void frmGetAllRxns_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void frmGetAllRxns_Enter(object sender, EventArgs e)
        {
            try
            {
                if (NUM_ScrollPos > 0)
                {
                    tlpnl_AllRxns.AutoScroll = false;
                    tlpnl_AllRxns.VerticalScroll.Value = NUM_ScrollPos;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #region Navigation control events

        int currRecIndex = 0;
        int MaxRecCnt = 0;

        private void btnFirst_Click(object sender, EventArgs e)
        {
            try
            {
                currRecIndex = 1;
                numGotoRecord.Value = currRecIndex;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog("btnFirst_Click() " + ex.ToString());
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                if (currRecIndex <= MaxRecCnt && currRecIndex > 1)
                {
                    currRecIndex = (currRecIndex - 1);
                }
                numGotoRecord.Value = currRecIndex;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog("btnPrevious_Click() " + ex.ToString());
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                if (currRecIndex < MaxRecCnt)
                {
                    currRecIndex = currRecIndex + 1;
                }
                else if (currRecIndex == MaxRecCnt)
                {
                    currRecIndex = MaxRecCnt;
                }
                numGotoRecord.Value = currRecIndex;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog("btnNext_Click() " + ex.ToString());
            }
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            try
            {
                currRecIndex = MaxRecCnt;
                numGotoRecord.Value = currRecIndex;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog("btnLast_Click() " + ex.ToString());
            }
        }

        private void numGotoRecord_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (numGotoRecord.Value > 0)
                {
                    Cursor = Cursors.WaitCursor;

                    currRecIndex = Convert.ToInt32(numGotoRecord.Value);
                    //BindReactionsToTableLayOutPanelPageWise(currRecIndex);
                    BindReactionsToTableLayOutPanelPageWise_New(currRecIndex);
                    
                    //Show Total No.of Reactions with current Reaction index
                    lblRxnCnt.Text = currRecIndex + " / " + numGotoRecord.Maximum.ToString();
                    lblRxnCnt.Refresh();

                    Cursor = Cursors.Default;
                }
                else
                {
                    //Show Total No.of Reactions with current Reaction index
                    lblRxnCnt.Text = currRecIndex + " / " + numGotoRecord.Maximum.ToString();
                    lblRxnCnt.Refresh();

                    Cursor = Cursors.Default;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog("numGotoRecord_ValueChanged() " + ex.ToString());
            }
        }
        #endregion

        private void btnExport_Click(object sender, EventArgs e)
        {
            
        }

        
    }
}
