﻿#region NameSpaces
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarrBLL;
using IndxReactNarrDAL;
using System.Text.RegularExpressions;
//using CustomToolTipDemo;
using System.Collections;
using MDL.Draw.Renditor;
using IndxReactNarr.Common;
using IndxReactNarr.Generic;
using System.IO;
using IndxReactNarr.PdfExport;
using IndxReactNarrBll;
using IndxReactNarr.TaskManagement;
using System.Diagnostics;
using IndxReactNarr.Common;
using IndxReactNarr.Curation.MacroIndexing;


#endregion

namespace IndxReactNarr
{
    public partial class frmReactCuration : Form
    {
        #region Contructor

        public frmReactCuration()
        {
            InitializeComponent();
        }

        #endregion

        #region Public Properties

        public int TAN_ID = 0;
        int reactionID = 0;

        int currRxnIndex = 0;
        int MaxRecCnt = 0;

        public string TAN_Name = "";
        int _RxnNum = 0;
       
        TANInfoBO objPT = new TANInfoBO();

        public int Task_ID { get; set; }
        public int TaskAlloc_ID { get; set; }

        public string TANKeywords
        {
            get;
            set;
        }

        public DataTable ReactionsTbl
        {
            get;
            set;
        }
        
        public DataTable ProductDataTbl
        {
            get;
            set;
        }

        public DataTable RSNDataTbl
        {
            get;
            set;
        }

        public DataTable ParticipantsTbl
        {
            get;
            set;
        }

        public DataTable RXNCondDataTbl
        {
            get;
            set;
        }

        public DataTable TANNUMsTbl
        { get; set; }

        public DataTable TAN_8000_CombTbl
        { get; set; }
        
        public DataTable TAN8500SerTbl
        { get; set; }
                      
        public int Analyst_ID
        { get; set; }

        public string UserComments
        {
            get;
            set;
        }

        public string DefaultComments
        {
            get;
            set;
        }

        public string TemperatureComments
        { get; set; }

        public bool IsTANFreezed
        {
            get;
            set;
        }

        public bool IsQueryTAN
        { get; set; }

        public string TANComments_New
        { get; set; }

        public DataTable TANCommentsData
        { get; set; }

        public DataTable TANDetailsData
        { get; set; }      

        #endregion

        private void frmRxnEntryScreen_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;

                //Disable UpDown buttons
                numGotoRecord.Controls[0].Enabled = false;
                               
                DataTable dtTANDetails = ReactDB.GetTANDetailsOnTANID(TAN_ID);
                TANDetailsData = dtTANDetails;
 
                //Hide buttons on User Role
                HideButtonsOnUserRole(GlobalVariables.RoleName);

                if (GlobalVariables.ApplicationName == Enums.ApplicationName.MACRO.ToString() || GlobalVariables.ApplicationName == Enums.ApplicationName.ORGANIC.ToString())
                {
                    btnMng8000.Enabled = false;
                    btnMng8500.Enabled = false;

                    btnIndexingNUMs.Visible = true;
                }
                else
                {
                    btnIndexingNUMs.Visible = false;
                }

                if (dtTANDetails != null && dtTANDetails.Rows.Count > 0)
                {
                    txtTAN.Text = dtTANDetails.Rows[0]["TAN_NAME"].ToString();
                    TAN_Name = txtTAN.Text;

                    //txtTAN.Text = "Doc 350";

                    ApplicationOperationTracking.LogOperation(txtTAN.Text);//Track which TAN is opened
                    this.Text = txtTAN.Text + " - Reactions";
                    //this.Text = "Document - Reactions";
                 
                    txtShipmentName.Text = dtTANDetails.Rows[0]["SHIPMENT_NAME"].ToString();
                    GlobalVariables.ShipmentName = dtTANDetails.Rows[0]["SHIPMENT_NAME"].ToString();

                    txtBatchNo.Text = dtTANDetails.Rows[0]["BATCH_NO"].ToString();
                    txtCAN.Text = dtTANDetails.Rows[0]["CAN"].ToString() ?? "-";

                    //txtAnalyst.Text = dtTANDetails.Rows[0]["ANALYST"].ToString();
                    txtTANType.Text = dtTANDetails.Rows[0]["TAN_TYPE"].ToString();
                    TANKeywords = dtTANDetails.Rows[0]["KEYWORDS"].ToString();

                    if (TAN_ID > 0)
                    {
                        //Get saved 8000 and NrnReg details on TAN and save in Global datatable                           
                        GlobalVariables.TAN_Series8000Data = ReactDB.GetSeries8000DetailsOnTAN(TAN_ID);

                        //Get saved 8500 and NrnReg details on TAN and save in Global datatable
                        ManageSeries8500 mngSer8500 = new ManageSeries8500();
                        mngSer8500.TAN_ID = TAN_ID;
                        mngSer8500.OrgRefID = 0;

                        DataTable dtTANSer8500 = null;
                        ReactDB.UpdateSeries8500DetailsOnTAN(mngSer8500, out dtTANSer8500);
                        GlobalVariables.TAN_Series8500Data = dtTANSer8500;

                        //Get TAN Comments On TANID
                        TANCommentsData = ReactDB.GetTANCommentsOnTANID(TAN_ID);
                        //txtcomments.Text = GetCommentsStringFromTable(TANCommentsData);

                        //Get TAN NUMs data on TAN ID
                        TANNUMsTbl = ReactDB.GetRxnNUM_RegNoDetailsOnTANID(TAN_ID);

                        //Get TAN Reactions on TAN ID
                        ReactionsTbl = ReactDB.GetReactionsOnTANID(TAN_ID);

                        if (ReactionsTbl != null)
                        {
                            if (ReactionsTbl.Rows.Count > 0)
                            {
                                //Bind Reactions to TreeView
                                BindReactionsToTreeView(ReactionsTbl);

                                //If more reaction then enable navigation controls
                                EnableReactionNavigationControls();

                                MaxRecCnt = ReactionsTbl.Rows.Count;

                                blValidRxn = true;//Set to true in the Page load, check in Reaction navigation whether reaction is valid or not

                                numGotoRecord.Maximum = MaxRecCnt;
                                currRxnIndex = 1;
                                numGotoRecord.Minimum = 1;

                                numGotoRecord.Value = currRxnIndex;
                            }
                            else
                            {
                                MaxRecCnt = ReactionsTbl.Rows.Count;

                                numGotoRecord.Maximum = MaxRecCnt;
                                numGotoRecord.Minimum = 0;
                                currRxnIndex = 0;

                                numGotoRecord.Value = currRxnIndex;
                            }
                        }

                        if (GlobalVariables.ChemistryRenditor == null)
                        {
                            GlobalVariables.ChemistryRenditor = new Renditor();
                        }
                    }

                    //Skip Validations in Tool Manager/Administrator level
                    if (GlobalVariables.RoleName == RolesMaster.TOOL_MANAGER || GlobalVariables.RoleName == RolesMaster.ADMIN)
                    {
                        chkSkipValidations.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void HideButtonsOnUserRole(string userRole)
        {
            try
            {
                if (!string.IsNullOrEmpty(userRole))
                {
                    btnRejectTAN.Visible = false;
                    btnTANComplete.Visible = false;
                    chkRxnComplete.Visible = false;

                    if ((userRole.ToUpper() == RolesMaster.ANALYST.ToUpper() || userRole.ToUpper() == RolesMaster.REV_ANALYST.ToUpper()
                        || userRole.ToUpper() == RolesMaster.QC_ANALYST.ToUpper()) && Task_ID > 0)
                    {
                        btnRejectTAN.Visible = userRole.ToUpper() == RolesMaster.ANALYST.ToUpper() ? false : true;
                        btnTANComplete.Visible = true;
                        chkRxnComplete.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void BindReactionsToTreeView(DataTable reactionsData)
        {
            try
            {
                if (reactionsData != null)
                {
                    tvReactions.Nodes.Clear();                    
                    tvReactions.ImageList = imageList1;

                    TreeNode rootNode = tvReactions.Nodes.Add("Reactions");
                    rootNode.ImageIndex = 2;                                       
                   
                    int intCntr = 0;
                    TreeNode rxnNode;

                    foreach (DataRow row in reactionsData.Rows)
                    {
                        intCntr = !string.IsNullOrEmpty(row["DISPLAY_ORDER"].ToString()) ?  Convert.ToInt32(row["DISPLAY_ORDER"]) : 0;
                        
                        rxnNode = new TreeNode();
                        rxnNode.Name = row["RXN_NUM"] + "-" + row["RXN_SEQ"];
                        rxnNode.Text = intCntr + " [" + row["RXN_NUM"] + "-" + row["RXN_SEQ"] + "]";
                        rxnNode.Tag = row["RXN_ID"];

                        if (GlobalVariables.RoleName.ToUpper() == RolesMaster.ANALYST.ToUpper())
                        {                            
                            if (!string.IsNullOrEmpty(row["CURATED_BY"].ToString()))
                            {
                                rxnNode.ImageIndex = 0;
                            }
                            else
                            {
                                rxnNode.ImageIndex = 1;
                            }
                        }
                        else if (GlobalVariables.RoleName.ToUpper() == "REVIEW ANALYST")
                        {                           
                            if (!string.IsNullOrEmpty(row["REVIEWED_BY"].ToString()))
                            {
                                rxnNode.ImageIndex = 0;
                            }
                            else
                            {
                                rxnNode.ImageIndex = 1;
                            }
                        }
                        else if (GlobalVariables.RoleName.ToUpper() == "QUALITY ANALYST")
                        {
                            if (!string.IsNullOrEmpty(row["QC_BY"].ToString()))
                            {
                                rxnNode.ImageIndex = 0;
                            }
                            else
                            {
                                rxnNode.ImageIndex = 1;
                            }
                        }
                        else
                        {
                            rxnNode.ImageIndex = 2;   
                        }                                        

                        rootNode.Nodes.Add(rxnNode);                                             
                    }

                    if (tvReactions.Nodes[0].Nodes.Count > 0)
                    {
                        tvReactions.ExpandAll();
                        TreeNode treeNode = tvReactions.Nodes[0].Nodes[0];
                        tvReactions.SelectedNode = treeNode;
                        //tvReactions.SelectedNode.NodeFont = new Font(tvReactions.Font, FontStyle.Bold);
                        tvReactions.SelectedNode.EnsureVisible();  //scroll if necessary                   
                        tvReactions.Focus();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #region Methods

        private DataTable GetCgmAndSubstanceDataOnBatchName(string _batchname, string _tan, string _can, out DataTable _substtbl)
        {
            DataTable dtCGM = null;
            DataTable dtSubstance = null;
            try
            {
                if (_batchname.Trim() != "")
                {
                    string strCgmPath = AppDomain.CurrentDomain.BaseDirectory + _batchname + ".cgm";
                    if (File.Exists(strCgmPath))
                    {
                        dtCGM = ReadCgm.GetCgmFileDataForNUMSearch(strCgmPath, _tan, _can, out dtSubstance);
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _substtbl = dtSubstance;
            return dtCGM;
        }
        
        //private void SetCommentsToCommentsTextBox()
        //{
        //    try
        //    {
        //        //string strUsrComnts = "";
        //        //string strDefComnts = "";
        //        //string strTempComnts = "";

        //        //strDefComnts = DefaultComments.Trim();
        //        ////strTempComnts = !string.IsNullOrEmpty(TemprtureComments) ? "~~" + TemprtureComments.Trim() : "";
        //        ////strUsrComnts = !string.IsNullOrEmpty(UserComments) ? "`" + UserComments.Trim() : "";

        //        //strTempComnts = "~~" + TemperatureComments.Trim();
        //        //strUsrComnts = "`" + UserComments.Trim();

        //        //txtcomments.Text = strDefComnts.Trim() + strTempComnts.Trim() + strUsrComnts.Trim();
        //        //TANComments_New = txtcomments.Text;//New code testing on 17th Apr 2013
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}

        public DataTable RxnProductsTbl = null;
        private bool SetReactionLabelsOnReactionIndex(int recordIndex)
        {
            bool blStatus = false;
            try
            {
                if (recordIndex >= 0)
                {
                    if (ReactionsTbl != null)
                    {
                        if (ReactionsTbl.Rows.Count > 0)
                        {
                            lblProdNum.Text = ReactionsTbl.Rows[recordIndex]["RXN_NUM"].ToString();
                            lblRxnSeqVal.Text = ReactionsTbl.Rows[recordIndex]["RXN_SEQ"].ToString();

                            int.TryParse(ReactionsTbl.Rows[recordIndex]["RXN_NUM"].ToString(), out _RxnNum);
                            int.TryParse(ReactionsTbl.Rows[recordIndex]["RXN_ID"].ToString(), out reactionID);

                            chkRxnComplete.Enabled = true;
                            chkRxnComplete.Checked = false;

                            //New feature on 21st July 2011
                            if (GlobalVariables.RoleName.ToUpper() == RolesMaster.ANALYST.ToUpper())
                            {
                                if (!string.IsNullOrEmpty(ReactionsTbl.Rows[recordIndex]["CURATED_BY"].ToString()))
                                {
                                    chkRxnComplete.Checked = true;
                                    chkRxnComplete.Enabled = false;
                                }
                            }
                            if (GlobalVariables.RoleName.ToUpper() == RolesMaster.REV_ANALYST.ToUpper())
                            {
                                if (!string.IsNullOrEmpty(ReactionsTbl.Rows[recordIndex]["REVIEWED_BY"].ToString()))
                                {
                                    chkRxnComplete.Checked = true;
                                    chkRxnComplete.Enabled = false;   
                                }                                
                            }
                            else if (GlobalVariables.RoleName.ToUpper() == RolesMaster.QC_ANALYST.ToUpper())
                            {
                                if (!string.IsNullOrEmpty(ReactionsTbl.Rows[recordIndex]["QC_BY"].ToString()))
                                {
                                    chkRxnComplete.Checked = true;
                                    chkRxnComplete.Enabled = false;
                                }
                            }
                        }
                    }

                    #region Old code commented by Sairam on 25th June 2014
                    //DataTable dtProductData = ProductDataTbl;
                    //DataTable dtProductData = CASRxnDataAccess.Get_Product_Data_On_RxnID(reactionID);

                    //Code commented on 16th June 2014 by Sairam
                    //DataTable dtProductData = CASRxnDataAccess.GetProductAndParticipantsOnRxnID(reactionID);
                    //if (!dtProductData.Columns.Contains("P_MOL"))
                    //{
                    //    dtProductData.Columns.Add("P_MOL", typeof(Image));
                    //}
                    //if (!dtProductData.Columns.Contains("Subst_Mol_Image"))
                    //{
                    //    dtProductData.Columns.Add("Subst_Mol_Image", typeof(Image));
                    //}

                    //FillTableWithChemistryImage(ref dtProductData, "P_MOL", "Subst_Mol_Image");

                    //_ProdDataTbl = dtProductData;

                    //BindProductDataToGrid(_ProdDataTbl); 
                    #endregion

                    this.Refresh();

                    blStatus = true;
                    return blStatus;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private DataTable GetProductDataOnReactionID(DataTable _proddatatbl, int _reactionid)
        {
            DataTable dtProd = null;
            try
            {
                if (_proddatatbl != null)
                {
                    if (_proddatatbl.Rows.Count > 0)
                    {
                        string strFilterCond = "reaction_id = " + reactionID;
                        DataView dvProd = _proddatatbl.DefaultView;
                        dvProd.RowFilter = strFilterCond;
                        dtProd = dvProd.ToTable();
                        return dtProd;
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtProd;
        }
        
        private void BindProductDataToGrid(DataTable productdata)
        {
            try
            {
                if (productdata != null)
                {
                    dgvProduct.AutoGenerateColumns = false;
                    dgvProduct.DataSource = productdata;

                    colRPPID.DataPropertyName = "RPP_ID";

                    colProdName.DataPropertyName = "PP_NAME";
                    colProdName.ReadOnly = true;

                    colProdNum.DataPropertyName = "SERIES_NUM";
                    colProdNum.ReadOnly = true;

                    colProdNumType.DataPropertyName = "SER_TYPE";                                     
                    colProdRegNo.DataPropertyName = "REG_NO";
                    colProdYield.DataPropertyName = "YIELD";
                    colProdSerNumID.DataPropertyName = "SER_TAN_NUM_ID";

                    //Once TAN is Freezed user can't modify anything in the TAN, Only Administrator can modify
                    if (IsTANFreezed)
                    {
                        if (GlobalVariables.RoleName.ToUpper() == "ADMINISTRATOR")
                        {
                            pnlProduct.Enabled = true;
                            pnlButtons.Enabled = true;
                        }
                        else
                        {
                            pnlProduct.Enabled = false;
                            pnlButtons.Enabled = false;
                            btnAddRxn.Enabled = false;
                            btnDelReaction.Enabled = false;
                            lnkComments.Enabled = false;
                        }
                    }
                    else
                    {
                        pnlProduct.Enabled = true;
                        pnlButtons.Enabled = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void ComboBoxColumn_MouseWheel(object sender, EventArgs e)
        {
            HandledMouseEventArgs ee = (HandledMouseEventArgs)e;
            ee.Handled = true;
        }

        private DataTable GetProductsFromParticipantsTable(DataTable prod_partpnts)
        {
            DataTable dtProduct = null;
            try
            {
                if (prod_partpnts != null)
                {
                    DataView dvTemp = prod_partpnts.DefaultView;
                    dvTemp.RowFilter = "PP_TYPE = 'PRODUCT'";
                    dvTemp.Sort = "RPP_ID asc";
                    dtProduct = dvTemp.ToTable();
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtProduct;
        }

        private void GetReactionPartpntsAndCreateStagesOnRxnID(int reactionID)
        {
            try
            {
                //Select Reaction in the TreeView
                               
                //DataTable dtRSN = CASRxnDataAccess.GetRSNDetailsOnReactionID(reactionID);
                DataTable dtRSN = ReactDB.GetRSNDetailsOnRxnID(reactionID);
                DataTable dtRxnCond = ReactDB.GetConditionsDetailsOnRxnID(reactionID);
                DataTable dtPartpnts = ReactDB.GetProductAndParticipantsOnRxnID(reactionID, TAN_ID);
                DataTable dtStages = ReactDB.GetReactionStagesOnRxnID(reactionID);

                DataTable dtProductData = GetProductsFromParticipantsTable(dtPartpnts);//CASRxnDataAccess.GetProductAndParticipantsOnRxnID(reactionID);
                #region MyRegion
                //if (!dtProductData.Columns.Contains("P_MOL"))
                //{
                //    dtProductData.Columns.Add("P_MOL", typeof(Image));
                //}
                //if (!dtProductData.Columns.Contains("Subst_Mol_Image"))
                //{
                //    dtProductData.Columns.Add("Subst_Mol_Image", typeof(Image));
                //}
                //FillTableWithChemistryImage(ref dtProductData, "P_MOL", "Subst_Mol_Image"); 
                #endregion

                RxnProductsTbl = dtProductData;

                //Bind Products data to Product grid
                BindProductDataToGrid(RxnProductsTbl);
                
                if (dtStages != null)
                {
                    if (dtStages.Rows.Count > 0)
                    {
                        int stageID = 0;
                        ucParticipants ucParpnt = null;
                        TabPage tPage = null;

                        //-------- New Code on 22nd Nov 2010 -----------                      
                        int stgIndx = 0;
                        for (stgIndx = 0; stgIndx < dtStages.Rows.Count; stgIndx++)
                        {
                            if (stgIndx < tcStages.TabPages.Count)
                            {
                                if (tcStages.TabPages[stgIndx].Controls.Count > 0)
                                {
                                    tcStages.TabPages[stgIndx].Text = "Stage " + (stgIndx + 1);
                                    ucParpnt = (ucParticipants)tcStages.TabPages[stgIndx].Controls[0];

                                    stageID = Convert.ToInt32(dtStages.Rows[stgIndx][0]);

                                    AddDataToUserControl(ref ucParpnt, stageID, reactionID, stgIndx, _RxnNum, TAN_Name, dtPartpnts, dtRxnCond, dtRSN);
                                    ucParpnt.TAN_ID = TAN_ID;                                
                                    ucParpnt.TAN_Freezed = IsTANFreezed;                                    
                                    ucParpnt.BindParticipantsDataToGrids();
                                    tcStages.TabPages[stgIndx].Refresh();

                                    if (IsTANFreezed)
                                    {
                                        tcStages.ContextMenuStrip = null;
                                    }
                                }
                                else
                                {
                                    tcStages.TabPages[stgIndx].Text = "Stage " + (stgIndx + 1);

                                    ucParpnt = new ucParticipants();
                                    ucParpnt.Dock = DockStyle.Fill;
                                    ucParpnt.AutoScroll = true;
                                    ucParpnt.TAN_Freezed = IsTANFreezed;
                                    ucParpnt.TAN_ID = TAN_ID;                                   
                                    stageID = Convert.ToInt32(dtStages.Rows[stgIndx][0]);
                                    AddDataToUserControl(ref ucParpnt, stageID, reactionID, stgIndx, _RxnNum, TAN_Name, dtPartpnts, dtRxnCond, dtRSN);
                                    tcStages.TabPages[stgIndx].Controls.Add(ucParpnt);

                                    if (IsTANFreezed)
                                    {
                                        tcStages.ContextMenuStrip = null;
                                    }
                                }
                            }
                            else if (stgIndx > tcStages.TabPages.Count - 1)
                            {
                                tPage = new TabPage("Stage " + (stgIndx + 1));

                                ucParpnt = new ucParticipants();
                                ucParpnt.Dock = DockStyle.Fill;
                                ucParpnt.AutoScroll = true;
                                ucParpnt.TAN_Freezed = IsTANFreezed;
                                ucParpnt.TAN_ID = TAN_ID;  
                                stageID = Convert.ToInt32(dtStages.Rows[stgIndx][0]);
                                AddDataToUserControl(ref ucParpnt, stageID, reactionID, stgIndx, _RxnNum, TAN_Name, dtPartpnts, dtRxnCond, dtRSN);
                                tPage.Controls.Add(ucParpnt);
                                tcStages.TabPages.Add(tPage);

                                if (IsTANFreezed)
                                {
                                    tcStages.ContextMenuStrip = null;
                                }
                            }
                        }

                        //Delete if more stages are there previously
                        if (stgIndx < tcStages.TabPages.Count)
                        {
                            do
                            {
                                tcStages.TabPages.RemoveAt(stgIndx);
                            }
                            while (stgIndx != tcStages.TabPages.Count);
                        }

                        //Default selected tab is tabpage1
                        tcStages.SelectTab(tcStages.TabPages[0]);
                        tcStages.Refresh();                      
                    }
                    else //No Stages are available
                    {
                        #region MyRegion
                        //int stgIndx = 0;
                        ////Delete if more stages are there previously
                        //if (stgIndx < tbStages.TabPages.Count)
                        //{
                        //    do
                        //    {
                        //        tbStages.TabPages.RemoveAt(stgIndx);
                        //    }
                        //    while (stgIndx != tbStages.TabPages.Count);
                        //}

                        //tPage = new TabPage("Stage " + (stgIndx + 1));

                        //ucParpnt = new ucParticipants();
                        //ucParpnt.Dock = DockStyle.Fill;
                        //ucParpnt.AutoScroll = true;

                        //stageID = Convert.ToInt32(dtStages.Rows[stgIndx][0]);

                        //AddDataToUserControl(ref ucParpnt, stageID, stgIndx, _RxnNum, _TANId, dtRASC, dtRxnCond, dtRSN);

                        //tPage.Controls.Add(ucParpnt);
                        //tbStages.TabPages.Add(tPage);

                        //Default selected tab is tabpage1
                        // tbStages.SelectTab(tbStages.TabPages[0]);
                        //tbStages.Refresh(); 
                        #endregion

                        tcStages.TabPages.Clear();
                        MessageBox.Show("No Stages are available", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

                //Refresh Reaction View
                if (Properties.Settings.Default.ReactionView.ToUpper() == "PANEL")
                {
                    RefreshReactionView();
                }
                else
                {
                    splContPartpnts_RxnView.Panel2Collapsed = true;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog("CreateStagesOnReactionID " + ex.ToString());
            }
        }

        private void AddDataToUserControl(ref ucParticipants ucpartpnt, int stageid, int reactionid, int stgindx, int rxnnum, string tanid, DataTable partpntsdata, DataTable rxnconds, DataTable rsndata)
        {
            try
            {
                ucpartpnt.ReactionID = reactionid;
                ucpartpnt.RxnStageID = stageid;
                ucpartpnt.TAN_Name = tanid;
                ucpartpnt.RXNNUM = rxnnum;
                ucpartpnt.StageName = "Stage " + (stgindx + 1);
                               
                ucpartpnt.NUM_RegNosTbl = TANNUMsTbl;

                ucpartpnt.dtAgent = GetFilterDataOnParticipant(partpntsdata, "AGENT", stageid);
                ucpartpnt.dtSolvent = GetFilterDataOnParticipant(partpntsdata, "SOLVENT", stageid);
                ucpartpnt.dtReactant = GetFilterDataOnParticipant(partpntsdata, "REACTANT", stageid);
                ucpartpnt.dtCatalyst = GetFilterDataOnParticipant(partpntsdata, "CATALYST", stageid);
                ucpartpnt.dtConditions = GetConditionsOnStageID(rxnconds, stageid);
                ucpartpnt.dtRSN = GetRSNDataOnStageID(rsndata, stageid);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog("AddDataToUserControl " + ex.ToString());
            }
        }

        private void GetStageIDsFromTable(DataTable _stagetbl, ref ArrayList _stageidlist)
        {
            try
            {
                if (_stagetbl != null)
                {
                    if (_stagetbl.Rows.Count > 0)
                    {
                        for (int i = 0; i < _stagetbl.Rows.Count; i++)
                        {
                            if (!_stageidlist.Contains(_stagetbl.Rows[i]["rxn_stage_id"].ToString()))
                            {
                                _stageidlist.Add(_stagetbl.Rows[i]["rxn_stage_id"].ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog("GetStageIDsFromTable " + ex.ToString());
            }
        }

        private DataTable GetFilterDataOnParticipant(DataTable _rascdata, string _partpnt, int rxnstageid)
        {
            DataTable dtParpnts = null;
            try
            {
                if (_rascdata != null)
                {
                    if (_rascdata.Rows.Count > 0)
                    {
                        #region Code commented
                        //dtParpnts = _rascdata.Clone();
                        //string strFilterCond = "rxn_stage_id = " + _stageid + " and participant_type = '" + _partpnt.ToUpper() + "'";
                        //string strSort = "display_order asc";
                        //DataRow[] dtRArr = _rascdata.Select(strFilterCond, strSort);
                        //if (dtRArr != null)
                        //{
                        //    if (dtRArr.Length > 0)
                        //    {
                        //        foreach (DataRow dRow in dtRArr)
                        //        {
                        //            dtParpnts.ImportRow(dRow);
                        //        }
                        //        return dtParpnts;
                        //    }
                        //} 
                        #endregion

                        dtParpnts = _rascdata.Copy();

                        string strFilterCond = "RXN_STAGE_ID = " + rxnstageid + " and PP_TYPE = '" + _partpnt.ToUpper() + "'";
                        string strSort = "DISPLAY_ORDER asc";

                        DataView dvPartpnt = dtParpnts.DefaultView;
                        dvPartpnt.RowFilter = strFilterCond;
                        dvPartpnt.Sort = strSort;

                        dtParpnts = dvPartpnt.ToTable();

                        //DataRow[] dtRArr = _rascdata.Select(strFilterCond, strSort);
                        //if (dtRArr != null)
                        //{
                        //    if (dtRArr.Length > 0)
                        //    {
                        //        foreach (DataRow dRow in dtRArr)
                        //        {
                        //            dtParpnts.ImportRow(dRow);
                        //        }
                        //        return dtParpnts;
                        //    }
                        //}
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog("CreateStagesOnRxnNum_Rxn_No " + ex.ToString());
            }
            return dtParpnts;
        }

        private DataTable GetConditionsOnStageID(DataTable _rxnconddata, int _stageid)
        {
            DataTable dtParpnts = null;
            try
            {
                if (_rxnconddata != null)
                {
                    if (_rxnconddata.Rows.Count > 0)
                    {
                        dtParpnts = _rxnconddata.Clone();
                        string strFilterCond = "RXN_STAGE_ID = " + _stageid;
                        string strSortCond = "DISPLAY_ORDER, RC_ID asc";

                        DataRow[] dtRArr = _rxnconddata.Select(strFilterCond, strSortCond);
                        if (dtRArr != null)
                        {
                            if (dtRArr.Length > 0)
                            {
                                foreach (DataRow dRow in dtRArr)
                                {
                                    dtParpnts.ImportRow(dRow);
                                }
                                return dtParpnts;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtParpnts;
        }

        private DataTable GetRSNDataOnStageID(DataTable _rsndata, int _stageid)
        {
            DataTable dtParpnts = null;
            try
            {
                if (_rsndata != null)
                {
                    if (_rsndata.Rows.Count > 0)
                    {
                        dtParpnts = _rsndata.Clone();
                        string strFilterCond = "RXN_STAGE_ID = " + _stageid;
                        string strSortCond = "RSN_ID asc";

                        DataRow[] dtRArr = _rsndata.Select(strFilterCond, strSortCond);
                        if (dtRArr != null)
                        {
                            if (dtRArr.Length > 0)
                            {
                                foreach (DataRow dRow in dtRArr)
                                {
                                    dtParpnts.ImportRow(dRow);
                                }
                                return dtParpnts;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtParpnts;
        }

        private void EnableReactionNavigationControls()
        {
            btnFirst.Enabled = true;
            btnNext.Enabled = true;
            btnPrevious.Enabled = true;
            btnLast.Enabled = true;
            numGotoRecord.Enabled = true;
        }

        public void AddStageonLoad()
        {
            try
            {
                tcStages.TabPages.Clear();

                TabPage tp = new TabPage();
                tp.Text = "Stage 1";
                tp.Name = "Stage1";
                ucParticipants uc = new ucParticipants();
                uc.Dock = DockStyle.Fill;
                uc.AutoScroll = true;

                uc.StageName = "Stage 1";
                uc.TAN_Name = TAN_Name;
                uc.RXNNUM = _RxnNum;
               
                uc.NUM_RegNosTbl = TANNUMsTbl;
                uc.ReactionID = reactionID;
                uc.RxnStageID = ReactDB.GetNewStageID(reactionID, 1, "END", GlobalVariables.URID);
                tp.Controls.Add(uc);

                tcStages.TabPages.Add(tp);
            }
            catch (Exception ex)
            {
                IndxReactNarr.Generic.ErrorHandling.WriteErrorLog(" AddStageonLoad() " + ex.ToString());
            }
        }

        private int GetStageIDFromParticipantsUsrCntrl(int _tabindex)
        {
            int intStageID = 0;
            try
            {
                if (tcStages.TabPages.Count > 0)
                {
                    TabPage tp = tcStages.TabPages[_tabindex];
                    Control[] ucctl = tp.Controls.Find(Generic.GlobalVariables.UCControlName, true);
                    if (ucctl != null)
                    {
                        if (ucctl.Length > 0)
                        {
                            ucParticipants ucpar = (ucParticipants)ucctl[0];
                            intStageID = ucpar.RxnStageID;
                            return intStageID;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                IndxReactNarr.Generic.ErrorHandling.WriteErrorLog(" GetStageIDFromUserControl() " + ex.ToString());
            }
            return intStageID;
        }

        private DataTable[] GetTablesfromUserControl(ucParticipants _uc)
        {
            DataTable[] _dts = null;
            try
            {
                if (_uc != null)
                {
                    _dts = new DataTable[4];
                    _dts[0] = _uc.dtReactant;
                    _dts[1] = _uc.dtAgent;
                    _dts[2] = _uc.dtCatalyst;
                    _dts[3] = _uc.dtSolvent;
                }
            }
            catch (Exception ex)
            {
                IndxReactNarr.Generic.ErrorHandling.WriteErrorLog(" GetTablesfromUserControl() " + ex.ToString());
                //  throw ex;
            }
            return _dts;
        }

        public bool GetParticipantsDetailsfromUserControl(int _intStageindex, out List<Product_ParticipantBO> objPartpnts)
        {
            objPartpnts = null;
            string strStage = "Stage";
            try
            {
                if (_intStageindex > 0)
                {
                    if (tcStages.TabPages.Count > 0)
                    {
                        foreach (TabPage tp in tcStages.TabPages)
                        {
                            if (tp.Text.ToUpper() == strStage.ToUpper() + _intStageindex.ToString())
                            {
                                Control[] ucctl = tp.Controls.Find(Generic.GlobalVariables.UCControlName, true);
                                if (ucctl != null)
                                {
                                    if (ucctl.Length > 0)
                                    {
                                        ucParticipants ucpar = (ucParticipants)ucctl[0];
                                        DataTable[] _dts = GetTablesfromUserControl(ucpar);
                                        objPartpnts = GetParticipantDetailsfromTable(_dts);
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                IndxReactNarr.Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return false;
        }

        public bool GetRSNDetailsFromUserControl(int _intStageindex, out List<RxnSearchNoteBO> _lstRSN_Out)
        {
            _lstRSN_Out = null;
            string strStage = "Stage";

            try
            {
                if (_intStageindex > 0)
                {
                    if (tcStages.TabPages.Count > 0)
                    {
                        foreach (TabPage tp in tcStages.TabPages)
                        {
                            if (tp.Text.ToUpper() == strStage.ToUpper() + _intStageindex.ToString())
                            {
                                Control[] ucctl = tp.Controls.Find(Generic.GlobalVariables.UCControlName, true);
                                if (ucctl != null)
                                {
                                    if (ucctl.Length > 0)
                                    {
                                        ucParticipants ucpar = (ucParticipants)ucctl[0];
                                        _lstRSN_Out = GetRSNDetailsFromTable(ucpar.dtRSN);
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(" GetUserControlRSNDetails() " + ex.ToString());
                //  throw ex;
            }
            return false;
        }

        public bool GetRxnConditionDetailsFromUserControl(int _intStageindex, out List<RxnConditionBO> _lstCond_Out)
        {
            _lstCond_Out = null;
            string strStage = "Stage";

            try
            {
                if (_intStageindex > 0)
                {
                    if (tcStages.TabPages.Count > 0)
                    {
                        foreach (TabPage tp in tcStages.TabPages)
                        {
                            if (tp.Text.ToUpper() == strStage.ToUpper() + _intStageindex.ToString())
                            {
                                Control[] ucctl = tp.Controls.Find(Generic.GlobalVariables.UCControlName, true);
                                if (ucctl != null)
                                {
                                    if (ucctl.Length > 0)
                                    {
                                        ucParticipants ucpar = (ucParticipants)ucctl[0];
                                        _lstCond_Out = GetRXNConditionDetailsFromTable(ucpar.dtConditions);
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
               ErrorHandling.WriteErrorLog(ex.ToString());               
            }
            return false;
        }              
        
        public bool GetPartpnt_RSN_Condition_DetailsFromUserControl(int _stageindex, out List<Product_ParticipantBO> _lstPartpnt_Out,
                                                                    out List<RxnSearchNoteBO> _lstRSN_Out,
                                                                    out List<RxnConditionBO> _lstCond_Out)
        {
            _lstCond_Out = null;
            _lstPartpnt_Out = null;
            _lstRSN_Out = null;
            string strStage = "Stage";

            try
            {
                if (_stageindex > 0)
                {
                    if (tcStages.TabPages.Count > 0)
                    {
                        foreach (TabPage tp in tcStages.TabPages)
                        {
                            if (tp.Text.ToUpper() == strStage.ToUpper() + " " + _stageindex.ToString())
                            {
                                Control[] ucctl = tp.Controls.Find(Generic.GlobalVariables.UCControlName, true);
                                if (ucctl != null)
                                {
                                    if (ucctl.Length > 0)
                                    {
                                        ucParticipants ucpar = (ucParticipants)ucctl[0];

                                        DataTable[] _dts = GetTablesfromUserControl(ucpar);
                                        _lstPartpnt_Out = GetParticipantDetailsfromTable(_dts);

                                        _lstRSN_Out = GetRSNDetailsFromTable(ucpar.dtRSN);
                                        _lstCond_Out = GetRXNConditionDetailsFromTable(ucpar.dtConditions);
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return false;
        }

        private List<RxnConditionBO> GetRXNConditionDetailsFromTable(DataTable _dtrxnCond)
        {
            List<RxnConditionBO> lstRxnConds = null;
            try
            {
                if (_dtrxnCond != null && _dtrxnCond.Rows.Count > 0)
                {
                    lstRxnConds = new List<RxnConditionBO>();

                    for (int i = 0; i < _dtrxnCond.Rows.Count; i++)
                    {
                        RxnConditionBO objrxncond = new RxnConditionBO();

                        objrxncond.Rxn_Stage_ID = Convert.ToInt32(_dtrxnCond.Rows[i]["RXN_STAGE_ID"].ToString());
                        objrxncond.RC_ID = Convert.ToInt32(_dtrxnCond.Rows[i]["RC_ID"].ToString());
                        objrxncond.Temperature = _dtrxnCond.Rows[i]["TEMPERATURE"].ToString();
                        objrxncond.Pressure = _dtrxnCond.Rows[i]["PRESSURE"].ToString();
                        objrxncond.pH = _dtrxnCond.Rows[i]["PH"].ToString();
                        objrxncond.Time = _dtrxnCond.Rows[i]["RC_TIME"].ToString();

                        objrxncond.TempType = _dtrxnCond.Rows[i]["TEMP_TYPE"].ToString();
                        objrxncond.TimeType = _dtrxnCond.Rows[i]["TIME_TYPE"].ToString();
                        objrxncond.PHType = _dtrxnCond.Rows[i]["PH_TYPE"].ToString();
                        objrxncond.PressureType = _dtrxnCond.Rows[i]["PRESSURE_TYPE"].ToString();
                        objrxncond.DisplayOrder = Convert.ToInt32(_dtrxnCond.Rows[i]["DISPLAY_ORDER"].ToString());
                        objrxncond.UserID = GlobalVariables.URID;

                        lstRxnConds.Add(objrxncond);
                    }
                }
            }
            catch (Exception ex)
            {
                IndxReactNarr.Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstRxnConds;
        }

        private List<RxnSearchNoteBO> GetRSNDetailsFromTable(DataTable rsnData)
        {
            List<RxnSearchNoteBO> lstRSN = new List<RxnSearchNoteBO>();
            try
            {
                if (rsnData != null)
                {
                    if (rsnData.Rows.Count > 0)
                    {
                        RxnSearchNoteBO objRSN = null;
                        for (int i = 0; i < rsnData.Rows.Count; i++)
                        {
                            objRSN = null;
                            objRSN = new RxnSearchNoteBO();

                            rsnData.Rows[i]["FREE_TEXT"] = Regex.Replace(rsnData.Rows[i]["FREE_TEXT"].ToString().Trim(), @"\s+", " ");//Automatically remove extra spaces

                            objRSN.RXN_Stage_ID = Convert.ToInt32(rsnData.Rows[i]["RXN_STAGE_ID"]);

                            if (rsnData.Rows[i]["RSN_ID"].ToString() != "")
                            {
                                objRSN.RSN_ID = Convert.ToInt32(rsnData.Rows[i]["RSN_ID"].ToString());
                            }
                            else
                            {
                                objRSN.RSN_ID = 0;
                            }

                            objRSN.CVT = rsnData.Rows[i]["CVT"].ToString();
                            objRSN.FreeText = rsnData.Rows[i]["FREE_TEXT"].ToString();//Regex.Replace(_dtRSN.Rows[i]["rsn_free_text"].ToString().Trim(), @"\s+", " ");

                            if (rsnData.Rows[i]["NOTE_LEVEL"].ToString() != "")
                            {
                                objRSN.NoteLevel = rsnData.Rows[i]["NOTE_LEVEL"].ToString();
                            }
                            else
                            {
                                objRSN.NoteLevel = "Stage";
                            }

                            objRSN.DisplayOrder = Convert.ToInt32(rsnData.Rows[i]["DISPLAY_ORDER"].ToString());
                            objRSN.UserID = GlobalVariables.URID;

                            lstRSN.Add(objRSN);
                        }
                    }
                    return lstRSN;
                }
            }
            catch (Exception ex)
            {
                IndxReactNarr.Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstRSN;
        }

        private List<Product_ParticipantBO> GetParticipantDetailsfromTable(DataTable[] _dts)
        {
            List<Product_ParticipantBO> lstPartpnt = new List<Product_ParticipantBO>();

            try
            {
                if (_dts != null && _dts.Length > 0)
                {
                    for (int j = 0; j < _dts.Length; j++)
                    {
                        DataTable _dt = _dts[j];

                        if (_dt != null && _dt.Rows.Count > 0)
                        {
                            for (int irow = 0; irow < _dt.Rows.Count; irow++)
                            {
                                Product_ParticipantBO objPartpnt = new Product_ParticipantBO();

                                objPartpnt.RPP_ID = Convert.ToInt32(_dt.Rows[irow]["RPP_ID"]);
                                objPartpnt.RxnID = reactionID;
                                objPartpnt.RxnStageID = Convert.ToInt32(_dt.Rows[irow]["RXN_STAGE_ID"]);
                                if (_dt.Rows[irow]["SER_TAN_NUM_ID"] != null)
                                {
                                    int intSerNumID = 0;
                                    int.TryParse(_dt.Rows[irow]["SER_TAN_NUM_ID"].ToString(), out intSerNumID);
                                    objPartpnt.SeriesNumID = intSerNumID;

                                }

                                objPartpnt.SeriesType = _dt.Rows[irow]["SER_TYPE"].ToString();

                                #region MyRegion
                                //if (_dt.Rows[irow]["SERIES_9000"] != null)
                                //{
                                //    if (_dt.Rows[irow]["SERIES_9000"].ToString() != "")
                                //    {
                                //        objPartpnt.Series9000 = Convert.ToInt32(_dt.Rows[irow]["SERIES_9000"]);
                                //    }
                                //}
                                //if (_dt.Rows[irow]["SERIES_8500"] != null)
                                //{
                                //    if (_dt.Rows[irow]["SERIES_8500"].ToString() != "")
                                //    {
                                //        objPartpnt.Series8500 = Convert.ToInt32(_dt.Rows[irow]["SERIES_8500"]);
                                //    }
                                //}

                                //if (_dt.Rows[irow]["REG_NO"] != null)
                                //{
                                //    if (_dt.Rows[irow]["REG_NO"].ToString().Trim() != "")
                                //    {
                                //        objPartpnt.RegNo = _dt.Rows[irow]["REG_NO"].ToString().Trim();//Convert.ToInt32(_dt.Rows[irow]["REG_NO"].ToString().Trim());
                                //    }
                                //}

                                //if (_dt.Rows[irow]["SERIES_8000"] != null)
                                //{
                                //    if (_dt.Rows[irow]["SERIES_8000"].ToString().Trim() != "")
                                //    {
                                //        objPartpnt.Series8000 = Convert.ToInt32(_dt.Rows[irow]["SERIES_8000"].ToString().Trim());
                                //    }
                                //}
                                //if (_dt.Rows[irow]["SUBST_NUM"] != null)
                                //{
                                //    if (_dt.Rows[irow]["SUBST_NUM"].ToString().Trim() != "")
                                //    {
                                //        objPartpnt.Subst_Num = Convert.ToInt32(_dt.Rows[irow]["SUBST_NUM"].ToString().Trim());
                                //    }
                                //}
                                //objPartpnt.SubstName = _dt.Rows[irow]["SUBST_NAME"].ToString();
                                //objPartpnt.SubstLocation = _dt.Rows[irow]["SUBST_LOC"].ToString();
                                //objPartpnt.SubstAuthorName = _dt.Rows[irow]["SUBST_AUTHOR_NAME"].ToString();
                                //objPartpnt.SubstOtherName = _dt.Rows[irow]["SUBST_OTHER_NAME"].ToString();

                                //if (_dt.Rows[irow]["SUBST_MOLECULE"] != null)
                                //{
                                //    if (_dt.Rows[irow]["SUBST_MOLECULE"].ToString() != "")
                                //    {
                                //        objPartpnt.SubstMolecule = _dt.Rows[irow]["SUBST_MOLECULE"].ToString();
                                //    }
                                //} 
                                #endregion

                                if (_dt.TableName.ToUpper() == Generic.Enums.ParticipantType.REACTANT.ToString().ToUpper())
                                {
                                    objPartpnt.PPType = Generic.Enums.ParticipantType.REACTANT.ToString().ToUpper();
                                }
                                else if (_dt.TableName.ToUpper() == Generic.Enums.ParticipantType.AGENT.ToString().ToUpper())
                                {
                                    objPartpnt.PPType = Generic.Enums.ParticipantType.AGENT.ToString().ToUpper();
                                }
                                else if (_dt.TableName.ToUpper() == Generic.Enums.ParticipantType.SOLVENT.ToString().ToUpper())
                                {
                                    objPartpnt.PPType = Generic.Enums.ParticipantType.SOLVENT.ToString().ToUpper();
                                }
                                else if (_dt.TableName.ToUpper() == Generic.Enums.ParticipantType.CATALYST.ToString().ToUpper())
                                {
                                    objPartpnt.PPType = Generic.Enums.ParticipantType.CATALYST.ToString().ToUpper();
                                }

                                objPartpnt.UserID = GlobalVariables.URID;

                                lstPartpnt.Add(objPartpnt);
                            }
                        }
                    }

                    return lstPartpnt;
                }
            }
            catch (Exception ex)
            {
                IndxReactNarr.Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstPartpnt;
        }

        public DataTable GetRSNDetailsFromUserControlOnStageIndex(int _intStageindex)
        {
            DataTable dtRSN = null;
            string strStage = "Stage";

            try
            {
                if (_intStageindex > 0)
                {
                    if (tcStages.TabPages.Count > 0)
                    {
                        foreach (TabPage tp in tcStages.TabPages)
                        {
                            if (tp.Text.ToUpper() == strStage.ToUpper() + " " + _intStageindex.ToString())
                            {
                                Control[] ucctl = tp.Controls.Find(Generic.GlobalVariables.UCControlName, true);
                                if (ucctl != null)
                                {
                                    if (ucctl.Length > 0)
                                    {
                                        ucParticipants ucpar = (ucParticipants)ucctl[0];
                                        dtRSN = ucpar.dtRSN;
                                        return dtRSN;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                IndxReactNarr.Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtRSN;
        }

        public DataTable GetRxnCondDetailsFromUserControlOnStageIndex(int _intStageindex)
        {
            DataTable dtConds = null;
            string strStage = "Stage";

            try
            {
                if (_intStageindex > 0)
                {
                    if (tcStages.TabPages.Count > 0)
                    {
                        foreach (TabPage tp in tcStages.TabPages)
                        {
                            if (tp.Text.ToUpper() == strStage.ToUpper() + " " + _intStageindex.ToString())
                            {
                                Control[] ucctl = tp.Controls.Find(Generic.GlobalVariables.UCControlName, true);
                                if (ucctl != null)
                                {
                                    if (ucctl.Length > 0)
                                    {
                                        ucParticipants ucpar = (ucParticipants)ucctl[0];
                                        dtConds = ucpar.dtConditions;
                                        return dtConds;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                IndxReactNarr.Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtConds;
        }

        public bool GetParticipantsFromUserControlOnStageIndex(int _intStageindex, out DataTable _dtreactant,
                                                               out DataTable _dtagent, out DataTable _dtsolvent,
                                                               out DataTable _dtcatalyst)
        {
            _dtreactant = null;
            _dtagent = null;
            _dtsolvent = null;
            _dtcatalyst = null;
            string strStage = "Stage";

            try
            {
                if (_intStageindex > 0)
                {
                    if (tcStages.TabPages.Count > 0)
                    {
                        foreach (TabPage tp in tcStages.TabPages)
                        {
                            if (tp.Text.ToUpper() == strStage.ToUpper() + " " + _intStageindex.ToString())
                            {
                                Control[] ucctl = tp.Controls.Find(Generic.GlobalVariables.UCControlName, true);
                                if (ucctl != null)
                                {
                                    if (ucctl.Length > 0)
                                    {
                                        ucParticipants ucpar = (ucParticipants)ucctl[0];
                                        _dtreactant = ucpar.dtReactant;
                                        _dtagent = ucpar.dtAgent;
                                        _dtsolvent = ucpar.dtSolvent;
                                        _dtcatalyst = ucpar.dtCatalyst;
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                IndxReactNarr.Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return false;
        }

        private void AddNewReactionStage(int _tabindex, string _before_after)
        {
            try
            {
                if (reactionID > 0)
                {
                    if (tcStages.TabCount >= 1)
                    {
                        //int intNewStageID = CASRxnDataAccess.Insert_Get_RxnNewStageID(reactionID, _tabindex + 1, _before_after, GlobalVariables.URID);
                        int intNewStageID = ReactDB.GetNewStageID(reactionID, _tabindex + 1, _before_after, GlobalVariables.URID);
                        if (intNewStageID > 0)
                        {
                            string strStgName = "";
                            TabPage tp = null;

                            if (_before_after == "BEFORE")
                            {
                                strStgName = "Stage " + _tabindex.ToString();
                                tp = new TabPage(strStgName);
                                tcStages.TabPages.Insert(_tabindex, tp);
                            }
                            else if (_before_after == "AFTER")
                            {
                                strStgName = "Stage " + (_tabindex + 1).ToString();
                                tp = new TabPage(strStgName);
                                tcStages.TabPages.Insert(_tabindex + 1, tp);
                            }

                            ucParticipants uc = new ucParticipants();
                            uc.Dock = DockStyle.Fill;
                            uc.AutoScroll = true;

                            uc.TAN_Name = TAN_Name;
                            uc.RXNNUM = _RxnNum;
                           
                            uc.NUM_RegNosTbl = TANNUMsTbl;
                            uc.StageName = strStgName;
                            uc.RxnStageID = intNewStageID;
                            uc.ReactionID = reactionID;

                            tp.Controls.Add(uc);
                            tcStages.SelectTab(tp);

                            //Reset Tabpage text
                            ResetTabPageText();
                        }
                        else
                        {
                            MessageBox.Show("Error in creating new stage", "Add Stage", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog("AddTab() " + ex.ToString());
            }
        }

        private void RemoveReactionStage()
        {
            try
            {
                if (tcStages.TabCount > 1)
                {
                    TabPage tp_selected = tcStages.SelectedTab;
                    if (tp_selected != null)
                    {
                        DialogResult diaRes = MessageBox.Show("Do you want to delete the stage?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                        if (diaRes == DialogResult.Yes)
                        {
                            Control[] cntrlArr = tp_selected.Controls.Find("ucParticipants", true);
                            if (cntrlArr != null && cntrlArr.Length > 0)
                            {
                                ucParticipants ucParpnts = (ucParticipants)cntrlArr[0];

                                int intStageID = ucParpnts.RxnStageID;
                                if (intStageID > 0)
                                {
                                    if (ReactDB.DeleteReactionStage(intStageID))
                                    {                                       
                                        tcStages.TabPages.Remove(tp_selected);

                                        //Reset Tab Text
                                        ResetTabPageText();

                                        //Check and set comments in the patent
                                        CheckAndSetAutoComments();
                                    }
                                    else
                                    {
                                        MessageBox.Show("Error in delete stage", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog("RemoveStage() " + ex.ToString());
            }

        }

        private void ResetTabPageText()
        {
            try
            {
                if (tcStages.TabPages.Count >= 1)
                {
                    ucParticipants ucprt = null;
                    for (int i = 0; i < tcStages.TabPages.Count; i++)
                    {
                        tcStages.TabPages[i].Text = "Stage " + (i + 1);
                        ucprt = (ucParticipants)tcStages.TabPages[i].Controls["ucParticipants"];
                        if (ucprt != null)
                        {
                            ucprt.StageName = "Stage " + (i + 1);
                        }
                    }
                    tcStages.Refresh();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
       
        #endregion

        #region events

        private void btnSave_Click(object sender, EventArgs e)
        {

        }
        
        private bool SaveReactionData(out string _errmsg_out, out string _err_source)
        {
            bool blStatus = true;
            string strErrMsg = "";
            string strErrSrc = "";
            try
            {
                if (ValidateUserInputs(out strErrMsg))
                {
                    TANInfoBO objPatent = new TANInfoBO();
                    ReactionsBO objRxn = new ReactionsBO();
                    Product_ParticipantBO objProduct = new Product_ParticipantBO();
                                        
                    //Zero reactions comments
                    if (reactionID == 0)
                    {
                        DefaultComments = "No reactions in the article";
                    }                   
                    
                    if (TAN_ID > 0)
                    {
                        if (reactionID > 0)
                        {
                            //Reactant details                   
                            objRxn.RXN_NUM = Convert.ToInt32(lblProdNum.Text);
                            objRxn.RXN_SEQ = Convert.ToInt32(lblRxnSeqVal.Text);
                            objRxn.RXN_ID = reactionID;
                            objRxn.TAN_ID = TAN_ID;
                            objRxn.UR_ID = GlobalVariables.URID;
                            objRxn.UserRole = GlobalVariables.RoleName.ToUpper();

                            //Show warning message if RXNSEQ is 2 and CVT is not there - new feature on 23rd Sep2010
                            if (objRxn.RXN_SEQ > 1)
                            {
                                //Check for CVT term 'alternative preparation shown' in Stage 1 RSN table. If not used show warning
                                if (!CheckForAlternativePrepShownInStage1_RSN_CVT())//New method on 12th Sep 2011
                                {
                                    MessageBox.Show("Check for RSN-CVT 'alternative preparation' related terms", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                            }

                            //Reaction Completed
                            if (chkRxnComplete.Checked && chkRxnComplete.Enabled)
                            {
                                //Insert/Update Reaction Data and get Reactant ID,if new Reaction
                                //reactionID = ReactDB.Insert_Update_ReactionData(objRxn);

                                ReactDB.UpdateReactionStatusOnRole(objRxn);
                            }

                            //Insert/Update Product Data
                            List<Product_ParticipantBO> lstProduct = GetProductDetailsFromProductGrid(reactionID);

                            if (lstProduct != null)
                            {
                                if (lstProduct.Count > 0)
                                {
                                    for (int i = 0; i < lstProduct.Count; i++)
                                    {
                                        //if (lstProduct[i].RegNo == "")
                                        //{
                                        //    lstProduct[i].RegNo = "0";
                                        //}

                                        //if (lstProduct[i].Series8000 == 0 && Convert.ToInt32(lstProduct[i].RegNo) == 0)
                                        //{
                                        //    strErrMsg = "Empty values in the PRODUCT. Please correct the values";
                                        //    strErrSrc = "PRODUCT";
                                        //    blStatus = false;

                                        //    _errmsg_out = strErrMsg;
                                        //    _err_source = strErrSrc;
                                        //    return blStatus;
                                        //}
                                        //else 
                                        if (CheckFor_Yield_Max_Allowed(lstProduct[i].Yield))
                                        {
                                            strErrMsg = "Yield should be less than 100%";
                                            strErrSrc = "PRODUCT-Yield";
                                            blStatus = false;

                                            _errmsg_out = strErrMsg;
                                            _err_source = strErrSrc;
                                            return blStatus;
                                        }
                                        else
                                        {
                                            if (ReactDB.UpdateProduct_ParticipantsData(lstProduct[i]))
                                            {
                                                continue;
                                            }
                                            else
                                            {
                                                strErrMsg = "Error in saving Product";
                                                strErrSrc = "PRODUCT";
                                                blStatus = false;

                                                _errmsg_out = strErrMsg;
                                                _err_source = strErrSrc;
                                                return blStatus;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            //Get Stages count
                            int stagecount = tcStages.TabCount;

                            if (reactionID > 0)
                            {
                                int _intStageID = 0;

                                //populate participants,RSN and Conditions tables
                                List<Product_ParticipantBO> lstPartpnts = null;
                                List<RxnConditionBO> lstRxnConds = null;
                                List<RxnSearchNoteBO> lstRSNNote = null;

                                string strErrMSg = "";

                                //Validate all the participants values
                                
                                if (CheckAndValidateAllValidations(out strErrMSg))
                                {                                    
                                    //Insert/Update all the stages information in the reaction 
                                    for (int stgindx = 0; stgindx < stagecount; stgindx++)
                                    {
                                        _intStageID = GetStageIDFromParticipantsUsrCntrl(stgindx);
                                        if (_intStageID > 0)
                                        {
                                            lstPartpnts = new List<Product_ParticipantBO>();
                                            lstRxnConds = new List<RxnConditionBO>();
                                            lstRSNNote = new List<RxnSearchNoteBO>();

                                            //Get Participants,RSN and Conditions details
                                            GetPartpnt_RSN_Condition_DetailsFromUserControl(stgindx + 1, out lstPartpnts, out lstRSNNote, out lstRxnConds);

                                            //if (!CheckForRSN_Free_Stage_Validation(out strErrMsg))
                                            //{
                                            //Insert/Update RSN Table                                         
                                            if (lstRSNNote != null)
                                            {
                                                for (int i = 0; i < lstRSNNote.Count; i++)
                                                {
                                                    if (lstRSNNote[i].CVT.Trim() != "" || lstRSNNote[i].FreeText.Trim() != "")
                                                    {
                                                        if (ReactDB.UpdateRSNData(lstRSNNote[i]))
                                                        {
                                                            continue;
                                                        }
                                                        else
                                                        {
                                                            strErrMsg = "Error in saving RSN in the Stage" + (stgindx + 1) + " of the RXNNUM " + objRxn.RXN_NUM;
                                                            strErrSrc = "RSN";
                                                            blStatus = false;

                                                            _errmsg_out = strErrMsg;
                                                            _err_source = strErrSrc;
                                                            return blStatus;
                                                        }
                                                    }
                                                }
                                            }

                                            //Insert/Update Participants tables here                                                  
                                            if (lstPartpnts != null)
                                            {
                                                for (int i = 0; i < lstPartpnts.Count; i++)
                                                {
                                                    //if (CASRxnDataAccess.Insert_Update_Participants_Data(lstPartpnts[i]))
                                                    if (ReactDB.UpdateProduct_ParticipantsData(lstPartpnts[i]))
                                                    {
                                                        continue;
                                                    }
                                                    else
                                                    {
                                                        strErrMsg = "Error in saving " + lstPartpnts[i].PPType + " in the Stage" + (stgindx + 1) + " of the RXNNUM " + objRxn.RXN_NUM;
                                                        strErrSrc = lstPartpnts[i].PPType;
                                                        blStatus = false;

                                                        _errmsg_out = strErrMsg;
                                                        _err_source = strErrSrc;
                                                        return blStatus;
                                                    }
                                                }
                                            }                                           

                                            //Insert/Update Rxn Conditions
                                            if (lstRxnConds != null)
                                            {
                                                for (int j = 0; j < lstRxnConds.Count; j++)
                                                {
                                                    if (ReactDB.UpdateConditionsData(lstRxnConds[j]))
                                                    {
                                                        continue;
                                                    }
                                                    else
                                                    {
                                                        strErrMsg = "Error in saving Conditions in the Stage" + (stgindx + 1) + " of the RXNNUM " + objRxn.RXN_NUM;
                                                        strErrSrc = "Conditions";
                                                        blStatus = false;

                                                        _errmsg_out = strErrMsg;
                                                        _err_source = strErrSrc;
                                                        return blStatus;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    strErrMsg = strErrMSg;
                                    strErrSrc = "In-Valid Data";
                                    blStatus = false;

                                    _errmsg_out = strErrMsg.Trim();
                                    _err_source = strErrSrc;
                                    return blStatus;
                                }

                                //Update Default Comments and User comments Here
                                CheckAndSetAutoComments();

                                //Update TAN Comments - 11 Aug 2014
                                TANCommentsBO tanComments = GetTANCommentsFromTable();
                                if (tanComments != null)
                                {
                                    if (ReactDB.UpdateCommentsOnTANID(tanComments))
                                    {
                                        TANCommentsData = ReactDB.GetTANCommentsOnTANID(TAN_ID);
                                    }
                                }

                                //Refresh Reaction table
                                ReactionsTbl = ReactDB.GetReactionsOnTANID(TAN_ID);                                
                            }
                        }                        
                    }
                }
                else
                {
                    blStatus = false;
                    _errmsg_out = strErrMsg.Trim();
                    _err_source = "In-Valid Data";
                    return blStatus;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg_out = strErrMsg.Trim();
            _err_source = strErrSrc;
            return blStatus;
        }

       

        private TANCommentsBO GetTANCommentsFromTable()
        {
            TANCommentsBO tanComments = null;
            try
            {
                tanComments = new TANCommentsBO();
                tanComments.TAN_ID = TAN_ID;
                tanComments.UR_ID = GlobalVariables.URID;

                List<string> TC_IDs = new List<string>();
                List<string> TAN_Comments = new List<string>();
                List<string> Comments_Type = new List<string>();

                if (TANCommentsData != null && TANCommentsData.Rows.Count > 0)
                {           
                    foreach (DataRow drow in TANCommentsData.Rows)
                    {
                        if (reactionID > 0 && drow["COMMENT_TYPE"] == "DEFAULT" && drow["TAN_COMMENT"].ToString().ToUpper() == "NO REACTIONS IN THE ARTICLE")
                        {
                            //Do nothing
                        }
                        else
                        {
                            TC_IDs.Add(drow["TC_ID"].ToString());
                            TAN_Comments.Add(drow["TAN_COMMENT"].ToString());
                            Comments_Type.Add(drow["COMMENT_TYPE"].ToString());
                        }
                    }

                    tanComments.TC_IDs = TC_IDs;// TANCommentsData.AsEnumerable().Select(x => x["TC_ID"].ToString()).ToList();
                    tanComments.TAN_Comments = TAN_Comments;// TANCommentsData.AsEnumerable().Select(x => x["TAN_COMMENT"].ToString()).ToList();
                    tanComments.Comments_Type = Comments_Type;// TANCommentsData.AsEnumerable().Select(x => x["COMMENT_TYPE"].ToString()).ToList();                    
                }
                else
                {
                    tanComments = new TANCommentsBO();
                    tanComments.TAN_ID = TAN_ID;
                    tanComments.TC_IDs = TC_IDs;
                    tanComments.TAN_Comments = TAN_Comments;
                    tanComments.Comments_Type = Comments_Type;                  
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return tanComments;
        }

        //New method as on 12th Sep 2011
        private bool CheckForAlternativePrepShownInStage1_RSN_CVT()
        {
            bool blStatus = false;
            try
            {
                if (tcStages.TabPages.Count > 0)
                {
                    ucParticipants ucPartpnt = null;
                    DataTable dt_Rsn = null;
                    TabPage tp = tcStages.TabPages[0];
                    if(tp != null)
                    {
                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            dt_Rsn = ucPartpnt.dtRSN.Copy();
                            if (dt_Rsn != null)
                            {
                                if (CheckForRSN_CVTInTable(dt_Rsn,"FREE_TEXT", "alternative preparation shown"))
                                {
                                    blStatus = true;
                                }
                            }
                        }
                    }
                }       
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckAndValidateAllValidations(out string _errmsg_out)
        {
            bool blStatus = true;
            string ErrorMsg = "";
            string strErrMsg_Out = "";

            try
            {
                //RSN Free text and stage validation
                if (CheckForRSN_Free_Stage_Validation(out ErrorMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg.Trim();
                }

                //RSN max length <= 500 validation - 11th Aug 2014
                if (CheckRSNMaxLenghtValidation(out ErrorMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg.Trim();
                }

                //Method commented on 27th April 2012 - Code shifted to RSN form
                ////RSN FreeText contains CVT validation
                //if (CheckForRSNFreeTextContainsCVT(out ErrorMsg))
                //{
                //    blStatus = false;
                //    strErrMsg_Out = strErrMsg_Out.Trim() + "\r\n" + ErrorMsg.Trim();
                //}

                //RSN(Buffer) - Solvent(Water) validation
                if (CheckForBuffer_WaterSolvent_Validation(out ErrorMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg.Trim();
                }

                //Method commented on 26th April 2012 - Code shifted to RSN form
                ////Duplicate RSN FreeText terms Validation
                //if (CheckForDuplicateRSN_FreeTextTerms(out ErrorMsg))
                //{
                //    blStatus = false;
                //    strErrMsg_Out = strErrMsg_Out.Trim() + "\r\n" + ErrorMsg.Trim();
                //}

                //Check for Empty participants
                if (CheckForEmptyParticipants(out ErrorMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg.Trim();
                }
                //Check for Empty Reactant in the Reaction
                if (CheckForEmptyReactantInReaction(out ErrorMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg.Trim();
                }
                //Check for duplicate Reactants in the TAN
                if (CheckForDuplicateReactantsInTAN_New(out ErrorMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg.Trim();
                }
                //Solvent should be there if the given Agent is used
                if (CheckForEmptySolventWhenGivenAgentUsed(out ErrorMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg.Trim();
                }

                ////Conditions Validations
                #region Code Commented
                //if (!CheckForConds_Validations(out srrErrorMsg))
                //{
                //    blStatus = true;
                //    if (srrErrorMsg.Trim() != "")
                //    {
                //        if (srrErrMsg_Out.Trim() == "")
                //        {
                //            srrErrMsg_Out = srrErrorMsg;
                //        }
                //        else
                //        {
                //            srrErrMsg_Out = srrErrMsg_Out + "\r\n" + srrErrorMsg;
                //        }
                //    }                      
                //} 
                #endregion

                //Conditions & RSN Validations
                if (!CheckForConds_Pres_RSN_Validations(out ErrorMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg.Trim();
                }

                //NrnReg - RSN Validation - New validation as on 16th March 2011
                if (!CheckForNrnRegToRSN_Validations(out ErrorMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg.Trim();
                }

                //Reverse RSN - NrnReg Validation - New validation as on 23rd April 2012
                if (!CheckForRSNToNrnRegValidations(out ErrorMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg.Trim();
                }

                //Solvent - Boiling Point Validation - New validation as on 23rd March 2011
                if (!CheckForSolventBoilingPointRangeValidation(out ErrorMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg.Trim();                    
                }

                //RSN Prophetic - Yield Validation - New validation as on 23rd March 2011
                if (!CheckForProphetic_YieldValidation(out ErrorMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg.Trim();
                }

                //Multiple Products Yield ratio validation - New validation on 3rd April 2013
                if (GlobalVariables.RoleName.ToUpper() != RolesMaster.TOOL_MANAGER)
                {
                    if (!ValidateMultiProductYieldsRatio(out ErrorMsg))
                    {
                        blStatus = false;
                        strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg.Trim();
                    }
                }

                //New validation on 3rd April 2013
                //For single stage Reaction, If only reactants and products are present in RSD, 
                //RSN term "no experimental detail" should be written. If not, an error 
                if (!CheckForOnlyProductAndReactantForSingleStageReaction(out ErrorMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg.Trim();   
                }

                //New validation on 3rd April 2013
                //If solvent is present in RSD, then  RSN term “no solvent" should not be present
                if (!CheckForSolventToNoSolventRSNInAllStages(out ErrorMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg.Trim(); 
                }

                //New validation on 5th May 2013 - Jones Reagent used
                if (!CheckAgent_9451_9101Validation(out ErrorMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg.Trim(); 
                }

                ////Agent LDA preparation Check Validation
                #region MyRegion
                //if (CheckAgent_9438_9068Validation(out ErrorMsg))
                //{
                //    blStatus = true;
                //    if (ErrorMsg.Trim() != "")
                //    {
                //        if (strErrMsg_Out.Trim() == "")
                //        {
                //            strErrMsg_Out = ErrorMsg;
                //        }
                //        else
                //        {
                //            strErrMsg_Out = strErrMsg_Out + "\r\n" + ErrorMsg;
                //        }
                //    }
                //} 
                #endregion

                //SOCL2(9212 Reg:7719097) & DMF(9019 Reg:68122) Validation - New validation as on 14th Feb 2012
                if (!CheckForSOCL2_DMFValidation(out ErrorMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg.Trim();                    
                }

                //Check whether Stage Names exist validation - New validation as on 19th April 2012
                if (!CheckForStageNamesInStageRSNTables(out ErrorMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg.Trim();
                }

                //If Single Stage Reaction, Stage Information is not allowed - New Validation as on 20th April 2012
                if (!CheckForSingleStage_RSNStageInformation(out ErrorMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg.Trim();                    
                }

                //8000 series reaction validation - New validation on 20th Dec 2012
                if (!CheckForSeries8000Reaction(out ErrorMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg.Trim();
                }

                //Journal - Prophetic Reaction validation - 24th May 2013
                if (CheckForJournal_PropheticReactionValidation(out ErrorMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg.Trim();
                }

                //New validation on 5th Apr 2016
                //failed reaction cannot have a yield
                if (CheckForFailedReactionAndYieldValidation(out ErrorMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + ErrorMsg;
                }

                //New feature on 12th Dec 2015
                //Skip Validations in Tool Manager/Administrator level
                if ((GlobalVariables.RoleName == RolesMaster.TOOL_MANAGER || GlobalVariables.RoleName == RolesMaster.ADMIN) 
                    && GlobalVariables.SkipValidations)
                {
                    blStatus = true;
                    strErrMsg_Out = "";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg_out = strErrMsg_Out;
            return blStatus;
        }

        private bool CheckForFailedReactionAndYieldValidation(out string errMsgOut)
        {
            bool blStatus = false;
            string errMsg = "";
            try
            {
                //Check if Product have Yield
                if (RxnProductsTbl != null && RxnProductsTbl.Rows.Count > 0)
                {
                    int yieldCnt = RxnProductsTbl.Select("YIELD is not null").Count();
                    if (yieldCnt > 0)
                    {
                        ucParticipants ucPartpnt;

                        //Check for Failed Reaction RSN in all the stages
                        foreach (TabPage tp in tcStages.TabPages)
                        {
                            ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                            if (ucPartpnt != null)
                            {
                                if (ucPartpnt.dtRSN != null && ucPartpnt.dtRSN.Rows.Count > 0)
                                {
                                    if (CheckForRSN_CVTInTable(ucPartpnt.dtRSN, "CVT", "failed reaction"))
                                    {
                                        blStatus = true;                                        
                                    }
                                }
                            }
                        }

                        if (blStatus)
                        {
                            errMsg = "Failed reaction cannot not have a yield";
                        }
                    }
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsgOut = errMsg;
            return blStatus;
        }

        private bool CheckForInCompleteReactions()
        {
            bool blStatus = true;
            try
            {
                if (ReactionsTbl != null)
                {
                    string rowFilter = "";
                    if (GlobalVariables.RoleName == RolesMaster.ANALYST)
                    {
                        rowFilter = "CURATED_BY is NULL"; //"CURATED_BY = " + GlobalVariables.URID;
                    }
                    if (GlobalVariables.RoleName == RolesMaster.REV_ANALYST)
                    {
                        rowFilter = "REVIEWED_BY is NULL";//"REVIEWED_BY = " + GlobalVariables.URID;                        
                    }

                    if (GlobalVariables.RoleName == RolesMaster.QC_ANALYST)
                    {
                        rowFilter = "QC_BY is NULL";//"QC_BY = " + GlobalVariables.URID;                        
                    }

                    DataView dvTemp = ReactionsTbl.DefaultView;
                    dvTemp.RowFilter = rowFilter;
                    DataTable dtTemp = dvTemp.ToTable();

                    ////var rows = ReactionsTbl.AsEnumerable().Select(r => r.Field<Int64>(rxnCompletedBy) == null);
                    //if (dtTemp.Rows.Count != ReactionsTbl.Rows.Count)
                    //{
                    //    blStatus = false;
                    //}
                    if (dtTemp != null && dtTemp.Rows.Count > 0)
                    {
                        blStatus = false;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        #region Series 8000 Reaction Methods
        /// <summary>
        /// Check if Reaction contains only series 8000 numbers
        /// </summary>
        /// <param name="errmsg_out"></param>
        /// <returns></returns>
        private bool CheckForSeries8000Reaction(out string errmsg_out)
        {
            bool blStatus = true;
            string srrErrMsg = "";
            try
            {
                int prodRegCnt = 0;
                int reacRegCnt = 0;
                int agtRegCnt = 0;
                int solvRegCnt = 0;
                int catlRegCnt = 0;
                DataTable dtProdDetails = (DataTable)dgvProduct.DataSource;
                if (dtProdDetails != null)
                {
                    prodRegCnt = dtProdDetails != null ? GetNrnRegCountFromTableOnColName(dtProdDetails.Copy(), "0") : 0;             
                }

                if (tcStages.TabPages.Count > 0)
                {
                    ucParticipants ucPartpnt = null;

                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            reacRegCnt += ucPartpnt.dtReactant != null ? GetNrnRegCountFromTableOnColName(ucPartpnt.dtReactant.Copy(), "0") : 0;
                            agtRegCnt += ucPartpnt.dtAgent != null ? GetNrnRegCountFromTableOnColName(ucPartpnt.dtAgent.Copy(), "0") : 0;
                            solvRegCnt += ucPartpnt.dtSolvent != null ? GetNrnRegCountFromTableOnColName(ucPartpnt.dtSolvent.Copy(), "0") : 0;
                            catlRegCnt += ucPartpnt.dtCatalyst != null ? GetNrnRegCountFromTableOnColName(ucPartpnt.dtCatalyst.Copy(), "0") : 0;
                        }
                    }
                }
                if ((prodRegCnt + reacRegCnt + agtRegCnt + solvRegCnt + catlRegCnt) == 0)
                {
                    blStatus = false;
                    srrErrMsg = "Reaction is not valid. Any one of the participants should contain CAS Reg.No";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = srrErrMsg;
            return blStatus;
        }

        private int GetNrnRegCountFromTableOnColName(DataTable partpntdata, string colvalue)
        {
            int intCnt = 0;
            try
            {
                if (partpntdata != null)
                {
                    if (partpntdata.Rows.Count > 0)
                    {
                        string strRowFilter = "";
                        if (partpntdata.Columns["REG_NO"].DataType.ToString() == "System.String")
                        {
                            strRowFilter = "REG_NO <> '" + colvalue + "'";
                        }
                        else
                        {
                            strRowFilter = "REG_NO > " + Convert.ToInt32(colvalue);
                        }

                        DataView dvProd = partpntdata.Copy().DefaultView;
                        dvProd.RowFilter = strRowFilter;
                        DataTable dtTemp = dvProd.ToTable();
                        if (dtTemp != null)
                        {
                            intCnt = dtTemp.Rows.Count;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }            
            return intCnt;
        }

        #endregion

        #region Single Stage Reaction, Stage Information Validation Methods

        private bool CheckForSingleStage_RSNStageInformation(out string errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg_Out = "";
            try
            {
                ArrayList asltStages = GetStageIndexesFromTabControl();
                if (asltStages != null)
                {
                    if (asltStages.Count == 1)
                    {
                        if (tcStages.TabPages.Count > 0)
                        {
                            TabPage tp = tcStages.TabPages[0];

                            DataTable dt_Rsn = null;
                            ucParticipants ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                            if (ucPartpnt != null)
                            {
                                dt_Rsn = ucPartpnt.dtRSN.Copy();
                                if (dt_Rsn != null)
                                {
                                    for (int i = 0; i < dt_Rsn.Rows.Count; i++)
                                    {
                                        if (dt_Rsn.Rows[i]["FREE_TEXT"].ToString().ToUpper().Contains("(STAGE ") ||
                                            dt_Rsn.Rows[i]["FREE_TEXT"].ToString().ToUpper().Contains("(STAGES "))
                                        {
                                            blStatus = false;
                                            strErrMsg_Out = "Single stage reaction. Stage information is not allowed in RSN FreeText";
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg_Out;
            return blStatus;
        }

        private bool CheckForStageNamesInStageRSNTables(out string errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {        
                ucParticipants ucPartpnt = null;
                DataTable dtRsn = null;

                ArrayList alstOtherStgs = new ArrayList();
                ArrayList alstStages = GetStageIndexesFromTabControl();
                string strStageName = "";

                foreach (TabPage tp in tcStages.TabPages)
                {
                    ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                    if (ucPartpnt != null)
                    {
                        strStageName = ucPartpnt.StageName;

                        dtRsn = ucPartpnt.dtRSN != null ? ucPartpnt.dtRSN.Copy() : null;

                        if (dtRsn != null && dtRsn.Rows.Count > 0)
                        {
                            string pattern = @"~";
                            Regex rgx = null;
                            string[] saFreeText = null;
                            string strFreeText = "";
                            alstOtherStgs.Clear();

                            string pattern1 = @"\(stages ";                            
                            Regex rgx1 = null;
                            string[] saFTTemp = null;

                            string pattern2 = "~";
                            Regex rgx2 = null;
                            string[] saStages = null;

                            for (int i = 0; i < dtRsn.Rows.Count; i++)
                            {
                                strFreeText = dtRsn.Rows[i]["FREE_TEXT"].ToString().Trim().Replace("),", ")~");
                                if (!string.IsNullOrEmpty(strFreeText))
                                {
                                    rgx = new Regex(pattern, RegexOptions.IgnoreCase);
                                    saFreeText = rgx.Split(strFreeText.Trim());

                                    if (saFreeText != null && saFreeText.Length > 0)
                                    {
                                        for (int j = 0; j < saFreeText.Length; j++)
                                        {
                                            if (saFreeText[j].Trim().ToUpper().Contains("(STAGES "))
                                            {
                                                rgx1 = new Regex(pattern1, RegexOptions.IgnoreCase);
                                                saFTTemp = rgx1.Split(saFreeText[j].Trim());

                                                if (saFTTemp != null && saFTTemp.Length > 0)
                                                {
                                                    string strStageInfo = saFTTemp[1].ToString();

                                                    strStageInfo = strStageInfo.Replace(")", "");

                                                    strStageInfo = strStageInfo.Replace(",", "~");
                                                    strStageInfo = strStageInfo.Replace("-", "~");
                                                    strStageInfo = strStageInfo.Replace("and", "~");

                                                    rgx2 = new Regex(pattern2, RegexOptions.IgnoreCase);
                                                    saStages = rgx2.Split(strStageInfo.Trim());

                                                    for (int k = 0; k < saStages.Length; k++)
                                                    {
                                                        if (!alstStages.Contains(saStages[k].Trim()) && !alstOtherStgs.Contains(saStages[k].Trim()))
                                                        {
                                                            alstOtherStgs.Add(saStages[k].Trim());
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            if (alstOtherStgs.Count > 0)
                            {
                                blStatus = false;

                                alstOtherStgs.Sort();

                                string strTemp = string.Join(", ", (string[])alstOtherStgs.ToArray(typeof(string)));
                                strErrMsg = strErrMsg.Trim() + "\r\n" + "Stage(s) " + strTemp + " not exist. Please check in " + strStageName + " RSN FreeText";
                            }                            
                        }
                    }
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg;
            return blStatus;
        }

        private ArrayList GetStageIndexesFromTabControl()
        {
            ArrayList alstStgIDs = null;
            try
            {
                if (tcStages != null)
                {
                    alstStgIDs = new ArrayList();
                    string[] saTemp = null;

                    for (int i = 0; i < tcStages.TabPages.Count; i++)
                    {
                        saTemp = null;
                        saTemp = tcStages.TabPages[i].Text.Trim().Split(' ');
                        if (saTemp != null && saTemp.Length > 1)
                        {
                            if (!alstStgIDs.Contains(saTemp[1].Trim()))
                            {
                                alstStgIDs.Add(saTemp[1].Trim());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return alstStgIDs;
        }

        #endregion
        
        /// <summary>
        ///New validation on 3rd April 2013
        ///For single stage Reaction, If only reactants and products are present in RSD, 
        ///RSN term "no experimental detail" should be written. If not, an error 
        /// </summary>
        /// <param name="_errmsg_out"></param>
        /// <returns></returns>
        private bool CheckForOnlyProductAndReactantForSingleStageReaction(out string _errmsg_out)
        {
            bool blStatus = true;
            string strErrorMsg = "";
            try
            {
                if (tcStages.TabPages.Count == 1)//Single Stage Reaction
                {
                    ucParticipants ucPartpnt = null;
                    DataTable dt_R = null;
                    DataTable dt_A = null;
                    DataTable dt_S = null;
                    DataTable dt_C = null;
                    DataTable dtRSN = null;
                    DataTable dtConds = null; 
                    //ProductDataTbl

                    TabPage tp = tcStages.TabPages[0];
                    ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                    if (ucPartpnt != null)
                    {
                        dt_R = ucPartpnt.dtReactant.Copy();
                        dt_A = ucPartpnt.dtAgent.Copy();
                        dt_S = ucPartpnt.dtSolvent.Copy();
                        dt_C = ucPartpnt.dtCatalyst.Copy();
                        dtRSN = ucPartpnt.dtRSN.Copy();
                        dtConds = ucPartpnt.dtConditions.Copy();

                        if (RxnProductsTbl.Rows.Count > 0 && dt_R.Rows.Count > 0 && dt_A.Rows.Count == 0
                            && dt_S.Rows.Count  == 0 && dt_C.Rows.Count == 0 && dtConds.Rows.Count == 0
                            && !CheckForRSNCVT_FreeTextInTable(dtRSN, "no experimental detail", "Reaction"))
                        {
                            //Allow Supervisor to skip this validation-17th May 2013
                            if (GlobalVariables.RoleName.ToUpper() != RolesMaster.TOOL_MANAGER.ToUpper())
                            {                              
                                blStatus = false;
                                strErrorMsg = "'no experimental detail' should be present in the RSN when only Product & Reactant are present.";
                            }
                        }
                        else if (RxnProductsTbl.Rows.Count > 0 && dt_R.Rows.Count > 0 && (dt_A.Rows.Count > 0
                            && dt_S.Rows.Count > 0 || dt_C.Rows.Count > 0 || dtConds.Rows.Count > 0)
                            && CheckForRSNCVT_FreeTextInTable(dtRSN, "no experimental detail", "Reaction"))
                        {
                            blStatus = false;
                            strErrorMsg = "In-valid RSN CVT 'no experimental detail'.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg_out = strErrorMsg;
            return blStatus;
        }
               
        //If solvent is present in RSD, then  RSN term "no solvent" should not be present - New validation on 3rd April 2013
        private bool CheckForSolventToNoSolventRSNInAllStages(out string _errmsg_out)
        {
            bool blStatus = true;
            string strErrorMsg = "";
            try
            {
                if (tcStages.TabPages.Count > 0)//Single Stage Reaction
                {
                    ucParticipants ucPartpnt = null;                    
                    DataTable dtSolvent = null;                    
                    DataTable dtRSN = null;
                    string strStageName = "";

                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            strStageName = ucPartpnt.StageName;

                            dtSolvent = ucPartpnt.dtSolvent.Copy();                            
                            dtRSN = ucPartpnt.dtRSN.Copy();                            

                            if (dtSolvent.Rows.Count > 0 && (CheckForRSNCVT_FreeTextInTable(dtRSN, "no solvent", "Reaction") ||
                                CheckForRSNCVT_FreeTextInTable(dtRSN, "no solvent", "Stage")))
                            {
                                blStatus = false;
                                strErrorMsg = "In-valid RSN 'no solvent' in the " + strStageName;
                            }                            
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg_out = strErrorMsg;
            return blStatus;
        }      
             

        //CrO3 & H2SO4 validation - New validation on 5th May 2013
        //If both 1333820 and 7664939 used in the Agent/Solvent/Catalyst in any stage 
        //then provide RSN "Jones reagent used' and remove both the Reg.Nos from the respective Agent/Solvent/Catalyst
        private bool CheckAgent_9451_9101Validation(out string _errmsg)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (tcStages.TabPages.Count > 0)
                {
                    ucParticipants ucPartpnt = null;
                    string strStageName = "";
                    DataTable dtAgentTbl = null;
                    //DataTable dtSolvTbl = null;
                    //DataTable dtCatlyTbl = null;
                    DataTable dtRSNTbl = null;
                    bool blVal_9451 = false;
                    bool blVal_9101 = false;
                    bool blJones = false;

                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        strStageName = "";

                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            strStageName = ucPartpnt.StageName;
                            dtAgentTbl = ucPartpnt.dtAgent != null ? ucPartpnt.dtAgent.Copy() : null;
                            dtRSNTbl = ucPartpnt.dtRSN != null ? ucPartpnt.dtRSN.Copy() : null;

                            blVal_9451 = false;
                            blVal_9101 = false;

                            if (dtAgentTbl != null && dtAgentTbl.Rows.Count > 0)
                            {
                                blVal_9451 = CheckForNrnRegInTable(dtAgentTbl, 1333820);
                                blVal_9101 = CheckForNrnRegInTable(dtAgentTbl, 7664939);
                                blJones = CheckForRSNTermInAllStagesRSN(dtRSNTbl, "Jones reagent used", strStageName);

                                if (blVal_9451 && blVal_9101)
                                {
                                    blStatus = false;
                                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Please remove 1333820 (9451) and 7664939 (9101) in the " + strStageName + " and keep 'Jones reagent used' in the RSN";
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg.Trim();
            return blStatus;
        }

        private bool CheckForSOCL2_DMFValidation(out string _errmsg_out)
        {
            bool blStatus = true;
            string srrErrMsg = "";       
            try
            {
                if (tcStages.TabPages.Count > 0)
                {
                    ucParticipants ucPartpnt = null;                   
                    DataTable dt_A = null;
                    DataTable dt_S = null;
                    DataTable dt_C = null;                   
                    string strStage = "";

                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            strStage = ucPartpnt.StageName;
                            dt_A = ucPartpnt.dtAgent != null ? ucPartpnt.dtAgent.Copy() : null;
                            dt_S = ucPartpnt.dtSolvent != null ? ucPartpnt.dtSolvent.Copy() : null;
                            dt_C = ucPartpnt.dtCatalyst != null ? ucPartpnt.dtCatalyst.Copy() : null;

                            int intReg9212 = 7719097;
                            int intReg9019 = 68122;

                            if (CheckForNrnRegInTable(dt_A, intReg9212) && CheckForNrnRegInTable(dt_S, intReg9019))
                            {
                               blStatus = false;
                               srrErrMsg = "If SOCL2 (9212) is Agent, then DMF (9019) should be Catalyst in the " + strStage;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg_out = srrErrMsg;
            return blStatus;
        }

        private bool CheckForNrnRegInTable(DataTable dtpartpnt, int regno)
        {
            bool blStatus = false;
            try
            {
                if (dtpartpnt != null && regno > 0)
                {
                    using (DataView dvTemp = dtpartpnt.Copy().DefaultView)
                    {
                        dvTemp.RowFilter = "REG_NO = " + regno + "";
                        DataTable dtTemp = dvTemp.ToTable();

                        if (dtTemp != null && dtTemp.Rows.Count > 0)
                        {
                            if (regno == 50000)//For 50000 check the name along with Reg.No
                            {
                                if (dtTemp.Rows[0]["PP_NAME"].ToString().ToUpper() == "PARAFORMALDEHYDE")
                                {
                                    blStatus = true;
                                }
                                else
                                {
                                    blStatus = false;
                                }
                            }
                            else
                            {
                                blStatus = true;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckForNrnRegToRSN_Validations(out string _errmsg_out)
        {
            bool blStatus = true;
            string srrErrMsg = "";
            string srrErrMsg_Out = "";
            try
            {
                if (tcStages.TabPages.Count > 0)
                {
                    ucParticipants ucPartpnt = null;
                    DataTable dt_R = null;
                    DataTable dt_A = null;
                    DataTable dt_S = null;
                    DataTable dt_C = null;
                    DataTable dt_Rsn = null;
                    string strStage = "";

                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            strStage = ucPartpnt.StageName;
                            dt_Rsn = ucPartpnt.dtRSN != null ? ucPartpnt.dtRSN.Copy() : null;

                            dt_R = ucPartpnt.dtReactant != null ? ucPartpnt.dtReactant.Copy() : null;
                            dt_A = ucPartpnt.dtAgent != null ? ucPartpnt.dtAgent.Copy() : null;
                            dt_S = ucPartpnt.dtSolvent != null ? ucPartpnt.dtSolvent.Copy() : null;
                            dt_C = ucPartpnt.dtCatalyst != null ? ucPartpnt.dtCatalyst.Copy() : null;

                            //Reactant Table
                            if (!CheckRSNTermForNrnReg(dt_R, dt_Rsn, strStage, "Reactant", out srrErrMsg))
                            {
                                blStatus = false;
                                srrErrMsg_Out = srrErrMsg_Out.Trim() + Environment.NewLine + srrErrMsg.Trim();
                            }
                            //Agent Table                           
                            if (!CheckRSNTermForNrnReg(dt_A, dt_Rsn, strStage, "Agent", out srrErrMsg))
                            {
                                blStatus = false;
                                srrErrMsg_Out = srrErrMsg_Out.Trim() + Environment.NewLine + srrErrMsg.Trim();
                            }
                            //Solvent Table
                            if (!CheckRSNTermForNrnReg(dt_S, dt_Rsn, strStage, "Solvent", out srrErrMsg))
                            {
                                blStatus = false;
                                srrErrMsg_Out = srrErrMsg_Out.Trim() + Environment.NewLine + srrErrMsg.Trim();
                            }
                            //Catalyst Table
                            if (!CheckRSNTermForNrnReg(dt_C, dt_Rsn, strStage, "Catalyst", out srrErrMsg))
                            {
                                blStatus = false;
                                srrErrMsg_Out = srrErrMsg_Out.Trim() + Environment.NewLine + srrErrMsg.Trim();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg_out = srrErrMsg_Out;
            return blStatus;
        }

        private bool CheckRSNTermForNrnReg(DataTable dtpartpnt, DataTable dtrsn, string _stage, string _partpnt, out string _errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            DataRow[] drArr = null;
            try
            {
                if (dtpartpnt != null && dtpartpnt.Rows.Count > 0)
                {
                    //New validation on 16th March 2011
                    drArr = dtpartpnt.Select("REG_NO = 8007587");
                    if (drArr != null && drArr.Length > 0)
                    {
                        //if (!CheckForRSNTermInRSNTable(_dtrsn, "fuming nitric acid used"))
                        if (!CheckForRSNTermInAllStagesRSN(dtrsn, "fuming nitric acid used", _stage))
                        {
                            blStatus = false;
                            strErrMsg = "For Reg.No: 8007587 RSN FreeText should be ' fuming nitric acid used ' in the " + _stage;
                        }
                    }

                    //New validation on 16th March 2011
                    drArr = dtpartpnt.Select("REG_NO = 8014957");
                    if (drArr != null && drArr.Length > 0)
                    {
                        //if (!(CheckForRSNTermInRSNTable(_dtrsn, "fuming sulfuric acid used") || CheckForRSNTermInRSNTable(_dtrsn, "oleum used")))
                        bool blStatus_Fumic = CheckForRSNTermInAllStagesRSN(dtrsn, "fuming sulfuric acid used", _stage);
                        bool blStatus_Olem = CheckForRSNTermInAllStagesRSN(dtrsn, "oleum used", _stage);
                        if (blStatus_Fumic == false && blStatus_Olem == false)
                        {
                            blStatus = false;
                            strErrMsg = "For Reg.No: 8014957 RSN FreeText should be ' fuming sulfuric acid used or oleum used based on author language ' in the " + _stage;
                        }
                    }

                    //New validation on 22nd March 2011
                    drArr = dtpartpnt.Select("REG_NO = 5137553");
                    if (drArr != null && drArr.Length > 0)
                    {
                        //if (!CheckForRSNTermInRSNTable(_dtrsn, "Aliquat 336 used"))
                        if (!CheckForRSNTermInAllStagesRSN(dtrsn, "Aliquat 336 used", _stage))
                        {
                            blStatus = false;
                            strErrMsg = "For Reg.No: 5137553 RSN FreeText should be ' Aliquat 336 used ' and remove NrnReg: 5137553 in the " + _stage;
                        }
                        else
                        {
                            blStatus = false;
                            strErrMsg = "If ' Aliquat 336 used ' please remove NrnReg: 5137553 in the " + _stage;
                        }
                    }

                    //New validation on 22nd March 2011
                    drArr = dtpartpnt.Select("REG_NO = 69849452");
                    if (drArr != null && drArr.Length > 0)
                    {
                        //if (!CheckForRSNTermInRSNTable(_dtrsn, "Davis reagent used"))
                        if (!CheckForRSNTermInAllStagesRSN(dtrsn, "Davis reagent used", _stage))
                        {
                            blStatus = false;
                            strErrMsg = "For Reg.No: 69849452 RSN FreeText should be ' Davis reagent used ' and remove NrnReg: 69849452 in the " + _stage;
                        }
                        else
                        {
                            blStatus = false;
                            strErrMsg = "If ' Davis reagent used ' please remove NrnReg: 69849452 in the " + _stage;
                        }
                    }

                    //New validation on 23rd June 2011
                    drArr = dtpartpnt.Select("REG_NO = 50000");
                    if (drArr != null && drArr.Length > 0)
                    {
                        if (drArr[0]["PP_NAME"].ToString().ToUpper() == "PARAFORMALDEHYDE")
                        {
                            //if (!CheckForRSNTermInRSNTable(_dtrsn, "paraformaldehyde used"))
                            if (!CheckForRSNTermInAllStagesRSN(dtrsn, "paraformaldehyde used", _stage))
                            {
                                blStatus = false;
                                strErrMsg = "If 'paraformaldehyde' used RSN FreeText should be 'paraformaldehyde used' in the " + _stage;
                            }
                        }
                    }

                    //New validation on 23rd June 2011
                    drArr = dtpartpnt.Select("REG_NO = 7440020");
                    if (drArr != null && drArr.Length > 0)
                    {
                        if (drArr[0]["PP_NAME"].ToString().ToUpper() == "RANEY NICKEL")
                        {
                            //if (!CheckForRSNTermInRSNTable(_dtrsn, "Raney nickel used"))
                            if (!CheckForRSNTermInAllStagesRSN(dtrsn, "Raney nickel used", _stage))
                            {
                                blStatus = false;
                                strErrMsg = "If ' Raney nickel ' (7440020) used, RSN FreeText should be 'Raney nickel used' in the " + _stage;
                            }
                        }
                    }

                    //New validation on 5th May 2013 - 9800
                    drArr = dtpartpnt.Select("REG_NO = 12408025");
                    if (drArr != null && drArr.Length > 0)
                    {
                        //Old code commented on 6th June 2013
                        //if (!CheckForRSNTermInAllStagesRSN(dtrsn, "unspecified reagent used for acidic hydrolysis", _stage))
                        //{
                        //    blStatus = false;
                        //    strErrMsg = "For NrnReg: 12408025 RSN FreeText should be 'unspecified reagent used for acidic hydrolysis / unspecified reagent used for acidification' based on the author in the " + _stage;
                        //}                               

                        //New code on 6th June 2013                               
                        if (CheckForRSNTermInAllStagesRSN(dtrsn, "unspecified reagent used for acidification", _stage) ||
                            CheckForRSNTermInAllStagesRSN(dtrsn, "unspecified reagent used for acidic hydrolysis", _stage))
                        {
                            //do nothing
                        }
                        else
                        {
                            blStatus = false;
                        }
                        if (!blStatus)
                        {
                            strErrMsg = "For Reg.No: 12408025 RSN FreeText should be 'unspecified reagent used for acidic hydrolysis / unspecified reagent used for acidification' based on the author in the " + _stage;
                        }
                    }

                    //New validation on 5th May 2013
                    drArr = dtpartpnt.Select("REG_NO = 14280309");
                    if (drArr != null && drArr.Length > 0)
                    {
                        if (!CheckForRSNTermInAllStagesRSN(dtrsn, "unspecified reagent used for basic hydrolysis", _stage))
                        {
                            blStatus = false;
                            strErrMsg = "For Reg.No: 14280309 RSN FreeText should be ' unspecified reagent used for basic hydrolysis ' in the " + _stage;
                        }
                    }


                    //New modification on 23rd June 2011
                    if (_partpnt.ToUpper() == "CATALYST")
                    {
                        drArr = dtpartpnt.Select("REG_NO = 81032588");
                        if (drArr != null && drArr.Length > 0)
                        {
                            //if (!CheckForRSNTermInRSNTable(_dtrsn, "Karstedt’s catalyst used"))
                            if (!CheckForRSNTermInAllStagesRSN(dtrsn, "Karstedt's catalyst used", _stage))
                            {
                                blStatus = false;
                                strErrMsg = "If Reg.No: 81032588 used as Catalyst, RSN FreeText should be 'Karstedt's catalyst used' and use Catalyst as Pt(7440064) in the " + _stage;
                            }
                            else
                            {
                                blStatus = false;
                                strErrMsg = "If 'Karstedt's catalyst used' please remove NrnReg: 81032588 in Catalyst and use Catalyst as Pt(7440064) in the " + _stage;
                            }

                            #region Karstedt Code Shifted to CheckForRSN_NrnRegValidations Method - 23 April 2012
                            ////else if (CheckForRSNTermInRSNTable(_dtrsn, "Karstedt’s catalyst used"))
                            //else if (CheckForRSNTermInAllStagesRSN(dtrsn, "Karstedt's catalyst used", _stage)) //single stage wise
                            //{
                            //    drArr = dtpartpnt.Select("nrnreg = 7440064");
                            //    if (drArr != null)
                            //    {
                            //        if (drArr.Length > 0)
                            //        {
                            //            blStatus = true;
                            //            strErrMsg = "";
                            //        }
                            //        else
                            //        {
                            //            blStatus = false;
                            //            strErrMsg = "If 'Karstedt's catalyst used' please use Catalyst as Pt(7440064) in the " + _stage;
                            //        }
                            //    }
                            //}
                            #endregion
                        }

                        #region Lindlar Code Shifted to CheckForRSN_NrnRegValidations Method - 23 April 2012
                        ////if (CheckForRSNTermInRSNTable(_dtrsn, "Lindlar"))
                        //if (CheckForRSNTermInAllStagesRSN(dtrsn, "Lindlar's catalyst used", _stage)) //It should be single stage wise
                        //{
                        //    drArr = dtpartpnt.Select("nrnreg = 7440053");
                        //    if (drArr != null)
                        //    {
                        //        if (drArr.Length == 0)
                        //        {
                        //            blStatus = false;
                        //            strErrMsg = "For RSN FreeText: Lindlar's catalyst, please use Catalyst as pd(7440053) in the " + _stage;
                        //        }
                        //    }
                        //}
                        #endregion

                        drArr = dtpartpnt.Select("REG_NO = 12135227");
                        if (drArr != null && drArr.Length > 0)
                        {
                            if (drArr[0]["PP_NAME"].ToString().ToUpper() == "PD(OH)2/C")
                            {
                                //if (!CheckForRSNTermInRSNTable(_dtrsn, "solid-supported catalyst"))
                                if (!CheckForRSNTermInAllStagesRSN(dtrsn, "solid-supported catalyst", _stage))
                                {
                                    blStatus = false;
                                    strErrMsg = "If Catalyst is ' Pd(OH)2/C ' (12135227) RSN CVT / FreeText should be 'solid-supported catalyst' in the " + _stage;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg_out = strErrMsg;
            return blStatus;
        }

        #region UnUsed Method
        //private bool CheckForRSNTermInRSNTable(DataTable dtrsn, string _rsn_free)
        //{
        //    bool blStatus = false;
        //    try
        //    {
        //        if (dtrsn != null)
        //        {
        //            if (dtrsn.Rows.Count > 0)
        //            {
        //                DataRow[] drArr_Fn = dtrsn.Select("rsn_free_text like '%" + _rsn_free.Replace("'", "''") + "%'");
        //                if (drArr_Fn != null)
        //                {
        //                    if (drArr_Fn.Length > 0)
        //                    {
        //                        blStatus = true;
        //                    }
        //                    else
        //                    {
        //                        DataRow[] drArr_Cvt = dtrsn.Select("rsn_cvt = '" + _rsn_free.Replace("'", "''") + "'");
        //                        if (drArr_Cvt != null)
        //                        {
        //                            if (drArr_Cvt.Length > 0)
        //                            {
        //                                blStatus = true;
        //                            }
        //                        }
        //                    }
        //                }                       
        //            }
        //        }               
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return blStatus;
        //}

        //===========Reverse RSN-RegNo Validation=========        
        #endregion

        private bool CheckForRSNToNrnRegValidations(out string _errmsg_out)
        {
            bool blStatus = true;      
            string srrErrMsg = "";
            try
            {
                if (tcStages.TabPages.Count > 0)
                {
                    ucParticipants ucPartpnt = null;
                    DataTable dt_R = null;
                    DataTable dt_A = null;
                    DataTable dt_S = null;
                    DataTable dt_C = null;
                    DataTable dt_Rsn = null;
                    string strStage = "";
                    string strStgIndex = "";

                    //Reverse validation is required for Reaction level, if single stage reaction
                   
                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            strStage = ucPartpnt.StageName;
                            strStgIndex = GetStageIndexFromStageName(strStage);

                            dt_Rsn = ucPartpnt.dtRSN.Copy();

                            #region MyRegion
                            //dt_R = ucPartpnt.dtReactant.Copy();
                            //dt_A = ucPartpnt.dtAgent.Copy();
                            //dt_S = ucPartpnt.dtSolvent.Copy();
                            //dt_C = ucPartpnt.dtCatalyst.Copy(); 
                            #endregion

                            //8007587 - FUMING NITRIC ACID USED
                            if (CheckForRSNCVT_FreeTextInTable(dt_Rsn, "FUMING NITRIC ACID USED", "Stage"))
                            {
                                //Get Stage Information on FreeText term from RSN table, Check RegNo in the stages, if not show error

                                string[] saStages = GetStagesOnFreeTextTerm(dt_Rsn, "FUMING NITRIC ACID USED");
                                if (saStages != null)
                                {
                                    for (int i = 0; i < saStages.Length; i++)
                                    {
                                        GetParticipantsFromUserControlOnStageIndex(Convert.ToInt32(saStages[i].Trim()), out dt_R, out dt_A, out dt_S, out dt_C);

                                        if (!CheckRegNoInParticipantTables(8007587, dt_R, dt_A, dt_S, dt_C))
                                        {
                                            blStatus = false;
                                            srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' fuming nitric acid used ', 8007587 should be used in the Stage " + saStages[i].Trim();
                                        }
                                    }
                                }
                            }
                            else if (CheckForRSNCVT_FreeTextInTable(dt_Rsn, "FUMING NITRIC ACID USED", "Reaction"))
                            {
                                GetParticipantsFromUserControlOnStageIndex(Convert.ToInt32(strStgIndex.Trim()), out dt_R, out dt_A, out dt_S, out dt_C);
                                if (!CheckRegNoInParticipantTables(8007587, dt_R, dt_A, dt_S, dt_C))
                                {
                                    blStatus = false;
                                    srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' fuming nitric acid used ', 8007587 should be used in the " + strStage;
                                }
                            }

                            //8014957 - FUMING SULFURIC ACID USED
                            if (CheckForRSNCVT_FreeTextInTable(dt_Rsn, "FUMING SULFURIC ACID USED", "Stage"))
                            {
                                string[] saStages = GetStagesOnFreeTextTerm(dt_Rsn, "FUMING SULFURIC ACID USED");
                                if (saStages != null)
                                {
                                    for (int i = 0; i < saStages.Length; i++)
                                    {
                                        GetParticipantsFromUserControlOnStageIndex(Convert.ToInt32(saStages[i].Trim()), out dt_R, out dt_A, out dt_S, out dt_C);

                                        if (!CheckRegNoInParticipantTables(8014957, dt_R, dt_A, dt_S, dt_C))
                                        {
                                            blStatus = false;
                                            srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' fuming sulfuric acid used ', 8014957 should be used in the Stage " + saStages[i].Trim();
                                        }
                                    }
                                }                              
                            }
                            else if(CheckForRSNCVT_FreeTextInTable(dt_Rsn, "FUMING SULFURIC ACID USED", "Reaction"))
                            {
                                GetParticipantsFromUserControlOnStageIndex(Convert.ToInt32(strStgIndex.Trim()), out dt_R, out dt_A, out dt_S, out dt_C);
                                if (!CheckRegNoInParticipantTables(8014957, dt_R, dt_A, dt_S, dt_C))
                                {
                                    blStatus = false;
                                    srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' fuming sulfuric acid used ', 8014957 should be used in the " + strStage;
                                }
                            }

                            //8014957 - OLEUM USED - (8014957 is for FUMING SULFURIC ACID USED and OLEUM USED) - new validation on 10th Aug 2012
                            if (CheckForRSNCVT_FreeTextInTable(dt_Rsn, "OLEUM USED", "Stage"))
                            {
                                string[] saStages = GetStagesOnFreeTextTerm(dt_Rsn, "OLEUM USED");
                                if (saStages != null)
                                {
                                    for (int i = 0; i < saStages.Length; i++)
                                    {
                                        GetParticipantsFromUserControlOnStageIndex(Convert.ToInt32(saStages[i].Trim()), out dt_R, out dt_A, out dt_S, out dt_C);

                                        if (!CheckRegNoInParticipantTables(8014957, dt_R, dt_A, dt_S, dt_C))
                                        {
                                            blStatus = false;
                                            srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' oleum used ', 8014957 should be used in the Stage " + saStages[i].Trim();
                                        }
                                    }
                                }
                            }
                            else if (CheckForRSNCVT_FreeTextInTable(dt_Rsn, "OLEUM USED", "Reaction"))
                            {
                                GetParticipantsFromUserControlOnStageIndex(Convert.ToInt32(strStgIndex.Trim()), out dt_R, out dt_A, out dt_S, out dt_C);
                                if (!CheckRegNoInParticipantTables(8014957, dt_R, dt_A, dt_S, dt_C))
                                {
                                    blStatus = false;
                                    srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' oleum used ', 8014957 should be used in the " + strStage;
                                }
                            }

                            //50000 - PARAFORMALDEHYDE USED
                            if (CheckForRSNCVT_FreeTextInTable(dt_Rsn, "PARAFORMALDEHYDE USED", "Stage"))
                            {
                                string[] saStages = GetStagesOnFreeTextTerm(dt_Rsn, "PARAFORMALDEHYDE USED");
                                if (saStages != null)
                                {
                                    for (int i = 0; i < saStages.Length; i++)
                                    {
                                        GetParticipantsFromUserControlOnStageIndex(Convert.ToInt32(saStages[i].Trim()), out dt_R, out dt_A, out dt_S, out dt_C);

                                        if (!CheckRegNoInParticipantTables(50000, dt_R, dt_A, dt_S, dt_C))
                                        {
                                            blStatus = false;
                                            srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' paraformaldehyde used ', 50000 (paraformaldehyde) should be used in the Stage " + saStages[i].Trim();
                                        }
                                    }
                                }
                                #region MyRegion
                                //blStatus_R = CheckForNrnRegInTable(dt_R, 50000);
                                //blStatus_A = CheckForNrnRegInTable(dt_A, 50000);
                                //blStatus_S = CheckForNrnRegInTable(dt_S, 50000);
                                //blStatus_C = CheckForNrnRegInTable(dt_C, 50000);

                                //if (!blStatus_R && !blStatus_A && !blStatus_S && !blStatus_C)
                                //{
                                //    blStatus = false;
                                //    srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' paraformaldehyde used ', 50000 (paraformaldehyde) should be used in the " + strStage;
                                //} 
                                #endregion
                            }
                            else if (CheckForRSNCVT_FreeTextInTable(dt_Rsn, "PARAFORMALDEHYDE USED", "Reaction"))
                            {
                                GetParticipantsFromUserControlOnStageIndex(Convert.ToInt32(strStgIndex.Trim()), out dt_R, out dt_A, out dt_S, out dt_C);
                                if (!CheckRegNoInParticipantTables(50000, dt_R, dt_A, dt_S, dt_C))
                                {
                                    blStatus = false;
                                    srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' paraformaldehyde used ', 50000 (paraformaldehyde) should be used in the " + strStage;
                                }
                            }


                            //7440020 - RANEY NICKEL USED
                            if (CheckForRSNCVT_FreeTextInTable(dt_Rsn, "RANEY NICKEL USED", "Stage"))
                            {
                                string[] saStages = GetStagesOnFreeTextTerm(dt_Rsn, "RANEY NICKEL USED");
                                if (saStages != null)
                                {
                                    for (int i = 0; i < saStages.Length; i++)
                                    {
                                        GetParticipantsFromUserControlOnStageIndex(Convert.ToInt32(saStages[i].Trim()), out dt_R, out dt_A, out dt_S, out dt_C);

                                        if (!CheckRegNoInParticipantTables(7440020, dt_R, dt_A, dt_S, dt_C))
                                        {
                                            blStatus = false;
                                            srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' Raney nickel used ', 7440020 should be used in the Stage " + saStages[i].Trim();
                                        }
                                    }
                                }
                                #region MyRegion
                                //blStatus_R = CheckForNrnRegInTable(dt_R, 7440020);
                                //blStatus_A = CheckForNrnRegInTable(dt_A, 7440020);
                                //blStatus_S = CheckForNrnRegInTable(dt_S, 7440020);
                                //blStatus_C = CheckForNrnRegInTable(dt_C, 7440020);

                                //if (!blStatus_R && !blStatus_A && !blStatus_S && !blStatus_C)
                                //{
                                //    blStatus = false;
                                //    srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' Raney nickel used ', 7440020 should be used in the " + strStage;
                                //} 
                                #endregion
                            }
                            else if (CheckForRSNCVT_FreeTextInTable(dt_Rsn, "RANEY NICKEL USED", "Reaction"))
                            {
                                GetParticipantsFromUserControlOnStageIndex(Convert.ToInt32(strStgIndex.Trim()), out dt_R, out dt_A, out dt_S, out dt_C);
                                if (!CheckRegNoInParticipantTables(7440020, dt_R, dt_A, dt_S, dt_C))
                                {
                                    blStatus = false;
                                    srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' Raney nickel used ', 7440020 should be used in the " + strStage;
                                }
                            }

                            //7440053 - LINDLAR'S CATALYST USED 
                            if (CheckForRSNCVT_FreeTextInTable(dt_Rsn, "LINDLAR'S CATALYST USED", "Stage"))
                            {
                                string[] saStages = GetStagesOnFreeTextTerm(dt_Rsn, "LINDLAR'S CATALYST USED");
                                if (saStages != null)
                                {
                                    for (int i = 0; i < saStages.Length; i++)
                                    {
                                        GetParticipantsFromUserControlOnStageIndex(Convert.ToInt32(saStages[i].Trim()), out dt_R, out dt_A, out dt_S, out dt_C);
                                        if (!CheckForNrnRegInTable(dt_C, 7440053))
                                        {
                                            blStatus = false;
                                            srrErrMsg = srrErrMsg.Trim() + "\r\n" + "For RSN FreeText is ' Lindlar's catalyst used ', pd(7440053) should be used in Catalyst in the Stage " + saStages[i].Trim();
                                        }
                                    }
                                }
                                #region MyRegion
                                //blStatus_C = CheckForNrnRegInTable(dt_C, 7440053);//Check in Catalyst table
                                //if (!blStatus_C)
                                //{
                                //    blStatus = false;
                                //    srrErrMsg = srrErrMsg.Trim() + "\r\n" + "For RSN FreeText is ' Lindlar's catalyst used ', pd(7440053) should be used in Catalyst in the " + strStage;
                                //} 
                                #endregion
                            }
                            else if (CheckForRSNCVT_FreeTextInTable(dt_Rsn, "LINDLAR'S CATALYST USED", "Reaction"))
                            {
                                GetParticipantsFromUserControlOnStageIndex(Convert.ToInt32(strStgIndex.Trim()), out dt_R, out dt_A, out dt_S, out dt_C);
                                if (!CheckForNrnRegInTable(dt_C, 7440053))
                                {
                                    blStatus = false;
                                    srrErrMsg = srrErrMsg.Trim() + "\r\n" + "For RSN FreeText is ' Lindlar's catalyst used ', pd(7440053) should be used in Catalyst in the " + strStage;
                                }
                            }

                            //7440064 - KARSTEDT'S CATALYST USED
                            if (CheckForRSNCVT_FreeTextInTable(dt_Rsn, "KARSTEDT'S CATALYST USED", "Stage"))
                            {
                                string[] saStages = GetStagesOnFreeTextTerm(dt_Rsn, "KARSTEDT'S CATALYST USED");
                                if (saStages != null)
                                {
                                    for (int i = 0; i < saStages.Length; i++)
                                    {
                                        GetParticipantsFromUserControlOnStageIndex(Convert.ToInt32(saStages[i].Trim()), out dt_R, out dt_A, out dt_S, out dt_C);
                                        if (!CheckForNrnRegInTable(dt_C, 7440064))
                                        {
                                            blStatus = false;
                                            srrErrMsg = srrErrMsg.Trim() + "\r\n" + "For RSN FreeText is ' Karstedt's catalyst used ', Pt(7440064) should be used in Catalyst in the Stage " + saStages[i].Trim();
                                        }
                                    }
                                }
                                #region MyRegion
                                //blStatus_C = CheckForNrnRegInTable(dt_C, 7440064);//Check in Catalyst table
                                //if (!blStatus_C)
                                //{
                                //    blStatus = false;
                                //    srrErrMsg = srrErrMsg.Trim() + "\r\n" + "For RSN FreeText is ' Karstedt's catalyst used ', Pt(7440064) should be used in Catalyst in the " + strStage;
                                //}   
                                #endregion
                            }
                            else if (CheckForRSNCVT_FreeTextInTable(dt_Rsn, "KARSTEDT'S CATALYST USED", "Reaction"))
                            {
                                GetParticipantsFromUserControlOnStageIndex(Convert.ToInt32(strStgIndex.Trim()), out dt_R, out dt_A, out dt_S, out dt_C);
                                if (!CheckForNrnRegInTable(dt_C, 7440064))
                                {
                                    blStatus = false;
                                    srrErrMsg = srrErrMsg.Trim() + "\r\n" + "For RSN FreeText is ' Karstedt's catalyst used ', Pt(7440064) should be used in Catalyst in the " + strStage;
                                }
                            }

                            //7732185(Water) - If Buffer is used in RSN, Solvent - Water should be there
                            if (CheckForRSNCVT_FreeTextInTable(dt_Rsn, "BUFFER", "Stage"))
                            {
                                string[] saStages = GetStagesOnFreeTextTerm(dt_Rsn, "BUFFER");
                                if (saStages != null)
                                {
                                    for (int i = 0; i < saStages.Length; i++)
                                    {
                                        GetParticipantsFromUserControlOnStageIndex(Convert.ToInt32(saStages[i].Trim()), out dt_R, out dt_A, out dt_S, out dt_C);
                                        if (!CheckForNrnRegInTable(dt_S, 7732185))
                                        {
                                            blStatus = false;
                                            srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' Buffer ', Water(7732185) should be used in Solvent in the Stage " + saStages[i].Trim();
                                        }
                                    }
                                }
                            }
                            else if (CheckForRSNCVT_FreeTextInTable(dt_Rsn, "BUFFER", "Reaction"))
                            {
                                 GetParticipantsFromUserControlOnStageIndex(Convert.ToInt32(strStgIndex.Trim()), out dt_R, out dt_A, out dt_S, out dt_C);
                                 if (!CheckForNrnRegInTable(dt_S, 7732185))
                                 {
                                     blStatus = false;
                                     srrErrMsg = srrErrMsg.Trim() + "\r\n" + "If RSN FreeText is ' Buffer ', Water(7732185) should be used in Solvent in the " + strStage;
                                 }
                            }

                            //Thermal - If Thermal is used in RSN, Check for RegNo in Solvent BoilingPoint table
                            if (CheckForRSNCVT_FreeTextInTable(dt_Rsn, "THERMAL", "Stage"))
                            {
                                string[] saStages = GetStagesOnFreeTextTerm(dt_Rsn, "THERMAL");
                                if (saStages != null)
                                {
                                    bool blSolvUsed = false;
                                    for (int i = 0; i < saStages.Length; i++)
                                    {
                                        GetParticipantsFromUserControlOnStageIndex(Convert.ToInt32(saStages[i].Trim()), out dt_R, out dt_A, out dt_S, out dt_C);

                                        blSolvUsed = false;
                                        if (dt_S != null)
                                        {
                                            for (int j = 0; j < dt_S.Rows.Count; j++)
                                            {
                                                int.TryParse(dt_S.Rows[j]["REG_NO"].ToString(), out intNrnReg);
                                                if (intNrnReg > 0)
                                                {
                                                    if (CheckRegNoInSolventBoilingPoitnsTable(intNrnReg))
                                                    {
                                                        blSolvUsed = true;
                                                    }
                                                }
                                            }
                                            if (!blSolvUsed)
                                            {
                                                blStatus = false;
                                                srrErrMsg = srrErrMsg.Trim() + "\r\n" + "No valid Solvent is there. RSN ' thermal ' is not allowed in the Stage " + saStages[i].Trim();
                                            }
                                        } 
                                    }
                                }
                            }
                            else if (CheckForRSNCVT_FreeTextInTable(dt_Rsn, "THERMAL", "Reaction"))//strFreeText == "THERMAL")
                            {
                                GetParticipantsFromUserControlOnStageIndex(Convert.ToInt32(strStgIndex.Trim()), out dt_R, out dt_A, out dt_S, out dt_C);
                                bool blSolvUsed = false;
                                if (dt_S != null)
                                {
                                    for (int j = 0; j < dt_S.Rows.Count; j++)
                                    {
                                        int.TryParse(dt_S.Rows[j]["REG_NO"].ToString(), out intNrnReg);
                                        if (intNrnReg > 0)
                                        {
                                            if (CheckRegNoInSolventBoilingPoitnsTable(intNrnReg))
                                            {
                                                blSolvUsed = true;
                                            }
                                        }
                                    }
                                    if (!blSolvUsed)
                                    {
                                        blStatus = false;
                                        srrErrMsg = srrErrMsg.Trim() + "\r\n" + "No valid Solvent is there. RSN ' thermal ' is not allowed in the " + strStage;
                                    }
                                }                                
                            }
                        }
                    }                    
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg_out = srrErrMsg;
            return blStatus;
        }

        private string[] GetStagesOnFreeTextTerm(DataTable rsndata, string rsn_freetext)
        {
            string[] saStages = null;
            try
            {
                if (rsndata != null && !string.IsNullOrEmpty(rsn_freetext))
                {
                    DataView dvRSN = rsndata.Copy().DefaultView;
                    dvRSN.RowFilter = "FREE_TEXT like '%" + rsn_freetext.Replace("'", "''") + "%'";
                    DataTable dtStages = dvRSN.ToTable();

                    if (dtStages != null)
                    {
                        if (dtStages.Rows.Count > 0)
                        {
                            DataTable dtFT_Stages = GetFreeText_StagesData(dtStages.Rows[0]["FREE_TEXT"].ToString());

                            if (dtFT_Stages != null)
                            {
                                if (dtFT_Stages.Rows.Count > 0)
                                {
                                    for (int i = 0; i < dtFT_Stages.Rows.Count; i++)
                                    {
                                        if (dtFT_Stages.Rows[i][0].ToString().Trim().ToUpper() == rsn_freetext)
                                        {
                                            string strStageInfo = dtFT_Stages.Rows[i][1].ToString().Trim();
                                            strStageInfo = strStageInfo.Replace("(stages", "");
                                            strStageInfo = strStageInfo.Replace("(stage", "");
                                            strStageInfo = strStageInfo.Replace(")", "");
                                            strStageInfo = strStageInfo.Replace(",", "~");
                                            strStageInfo = strStageInfo.Replace("-", "~");
                                            strStageInfo = strStageInfo.Replace("and", "~");

                                            string pattern = "~";
                                            Regex rgx = new Regex(pattern, RegexOptions.IgnoreCase);
                                            saStages = rgx.Split(strStageInfo.Trim());

                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return saStages;
        }

        private bool CheckRegNoInParticipantTables(int regno, DataTable reagentdata, DataTable agentdata, DataTable solventdata, DataTable catalystdata)
        {
            bool blStatus = true;
            try
            {
                if (regno > 0)
                {
                    bool blStatus_R = CheckForNrnRegInTable(reagentdata, regno);
                    bool blStatus_A = CheckForNrnRegInTable(agentdata, regno);
                    bool blStatus_S = CheckForNrnRegInTable(solventdata, regno);
                    bool blStatus_C = CheckForNrnRegInTable(catalystdata, regno);

                    if (!blStatus_R && !blStatus_A && !blStatus_S && !blStatus_C)
                    {
                        blStatus = false;                        
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckValidSolventsForThermal(string stageinfo, out string errstages_out)
        {
            bool blStatus = true;
            string strErrStages = "";
            try
            {
                if (!string.IsNullOrEmpty(stageinfo))
                {
                    string[] saStages = GetStageIndexesFromStageInfo(stageinfo);
                    if (saStages != null)
                    {
                        ucParticipants ucPartpnt = null;
                        DataTable dtStgSolvents = null;
                        int intNrnReg = 0;
                        string strStageIndx = "";
                        bool blSolvUsed = false;

                        for (int i = 0; i < saStages.Length; i++)
                        {
                            if (!string.IsNullOrEmpty(saStages[i].Trim()))
                            {
                                ucPartpnt = GetUserControlOnStageIndex(saStages[i].Trim());
                                if (ucPartpnt != null)
                                {
                                    strStageIndx = GetStageIndexFromStageName(ucPartpnt.StageName);

                                    dtStgSolvents = ucPartpnt.dtSolvent;

                                    if (dtStgSolvents != null)
                                    {
                                        blSolvUsed = false;

                                        for (int j = 0; j < dtStgSolvents.Rows.Count; j++)
                                        {
                                            int.TryParse(dtStgSolvents.Rows[j]["REG_NO"].ToString(), out intNrnReg);
                                            if (intNrnReg > 0)
                                            {
                                                if (CheckRegNoInSolventBoilingPoitnsTable(intNrnReg))
                                                {
                                                    blSolvUsed = true;
                                                }
                                            }
                                        }
                                        if (!blSolvUsed)
                                        {
                                            blStatus = false;
                                            strErrStages = strErrStages.Trim() + "\r\n" + "No valid Solvent is there. RSN ' thermal ' is not allowed in the Stage(s) " + saStages[i].Trim();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errstages_out = strErrStages;
            return blStatus;
        }

        private ucParticipants GetUserControlOnStageIndex(string stageindex)
        {
            ucParticipants ucPartpnt = null;
            try
            {
                if (!string.IsNullOrEmpty(stageindex) && tcStages != null)
                {
                    string strStgIndex = "";
                    ucParticipants objUcpartpnt = null;
                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        objUcpartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                        if (objUcpartpnt != null)
                        {
                            strStgIndex = GetStageIndexFromStageName(objUcpartpnt.StageName);

                            if (strStgIndex == stageindex)
                            {
                                ucPartpnt = objUcpartpnt;
                                return ucPartpnt;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return ucPartpnt;
        }

        private bool CheckRegNoInSolventBoilingPoitnsTable(int regno)
        {
            bool blStatus = false;
            try
            {
                if (GlobalVariables.Solvent_BPoints != null && regno > 0)
                {
                    DataView dvTemp = GlobalVariables.Solvent_BPoints.Copy().DefaultView;
                    dvTemp.RowFilter = "REG_NO = " + regno;
                    DataTable dtTemp = dvTemp.ToTable();
                    if (dtTemp != null && dtTemp.Rows.Count > 0)
                    {
                        blStatus = true;
                        return blStatus;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        //===========New Method===========================

        private string GetStageIndexFromStageName(string stagename)
        {
            string strStgIndx = "";
            try
            {
                if (!string.IsNullOrEmpty(stagename.Trim()))
                {
                    string[] saTemp = stagename.Trim().Split(' ');
                    if (saTemp != null)
                    {
                        if (saTemp.Length > 0)
                        {
                            strStgIndx = saTemp[1];
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strStgIndx;
        }
        
        private bool CheckForRSNTermInAllStagesRSN(DataTable dtrsn, string rsn_freetext,string stagename)
        {
            bool blStatus = false;
            try
            {
                //Check first in Current Stage RSN table
                if (dtrsn != null)
                {
                    if (dtrsn.Rows.Count > 0)
                    {
                        DataRow[] drArr_Fn = dtrsn.Select("FREE_TEXT like '%" + rsn_freetext.Replace("'", "''") + "%'");
                        if (drArr_Fn != null)
                        {
                            if (drArr_Fn.Length > 0)
                            {
                                blStatus = true;
                            }
                            else
                            {
                                DataRow[] drArr_Cvt = dtrsn.Select("CVT = '" + rsn_freetext.Replace("'", "''") + "'");
                                if (drArr_Cvt != null)
                                {
                                    if (drArr_Cvt.Length > 0)
                                    {
                                        blStatus = true;
                                    }
                                }
                            }
                        }                        
                    }
                }
                if (blStatus == false)//Else check in all other stages
                {
                    string strStgIndx = GetStageIndexFromStageName(stagename);

                    ucParticipants ucPartpnt = null;
                    DataTable dt_Rsn = null;

                    DataTable dtFT_Stages = null;

                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            if (stagename.ToUpper() != ucPartpnt.StageName.ToUpper())//Don't check in current stage
                            {                               
                                dt_Rsn = ucPartpnt.dtRSN.Copy();
                                if (dt_Rsn != null)
                                {
                                    for (int k = 0; k < dt_Rsn.Rows.Count; k++)
                                    {
                                        if (!string.IsNullOrEmpty(dt_Rsn.Rows[k]["FREE_TEXT"].ToString().Trim()))
                                        {
                                            dtFT_Stages = GetFreeText_StagesData(dt_Rsn.Rows[k]["FREE_TEXT"].ToString().Trim());

                                            if (dtFT_Stages != null)
                                            {
                                                for (int m = 0; m < dtFT_Stages.Rows.Count; m++)
                                                {
                                                    if (!string.IsNullOrEmpty(dtFT_Stages.Rows[m][1].ToString().Trim()))
                                                    {
                                                        if (dtFT_Stages.Rows[m][0].ToString().Trim().ToUpper() == rsn_freetext.Trim().ToUpper())
                                                        {
                                                            if (dtFT_Stages.Rows[m][1].ToString().Trim().ToUpper().Contains("(STAGES "))
                                                            {
                                                                if (dtFT_Stages.Rows[m][1].ToString().Trim().Contains(", " + strStgIndx) ||
                                                                    dtFT_Stages.Rows[m][1].ToString().Trim().ToUpper().Contains(" AND " + strStgIndx))
                                                                {
                                                                    blStatus = true;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        #region Main Code commented
                                        //string[] saStages_B = Regex.Split(dt_Rsn.Rows[k]["rsn_free_text"].ToString().Trim(), @"\)," , RegexOptions.IgnoreCase);

                                        //if (saStages_B != null)
                                        //{
                                        //    if (saStages_B.Length > 0)
                                        //    {
                                        //        for (int m = 0; m < saStages_B.Length; m++)
                                        //        {
                                        //            if (!string.IsNullOrEmpty(saStages_B[m].Trim()))
                                        //            {
                                        //                if (saStages_B[m].Trim().ToUpper().Contains(rsn_freetext.Replace("'", "''").ToUpper()))
                                        //                {
                                        //                    if (saStages_B[m].Trim().ToUpper().Contains("(STAGES "))
                                        //                    {
                                        //                        if (saStages_B[m].Trim().Contains(", " + strStgIndx) ||
                                        //                            saStages_B[m].Trim().ToUpper().Contains(" AND " + strStgIndx))
                                        //                        {
                                        //                            blStatus = true;
                                        //                        }
                                        //                    }
                                        //                }
                                        //            }
                                        //        }
                                        //    }
                                        //} 
                                        #endregion
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private DataTable GetFreeText_StagesData(string freetext)
        {
            DataTable dtFT_Stages = null;
            try
            {
                if (!string.IsNullOrEmpty(freetext.Trim()))
                {
                    string strFT = freetext.Trim();
                    strFT = strFT.Replace("),", ")`");

                    string[] splitter = { "`" };
                    string[] saValues = strFT.Split(splitter, StringSplitOptions.RemoveEmptyEntries);

                    dtFT_Stages = new DataTable();
                    dtFT_Stages.Columns.Add("FreeText");
                    dtFT_Stages.Columns.Add("StageInfo");

                    string strFreeText = "";
                    string strStageInfo = "";
                    DataRow dRow = null;

                    for (int i = 0; i < saValues.Length; i++)
                    {
                        if (saValues[i].Trim().ToUpper().Contains(" (STAGE "))
                        {
                            string pattern = @"\(stage ";
                            string replacement = @"~(stage ";
                            Regex rgx = new Regex(pattern, RegexOptions.IgnoreCase);
                            string result = rgx.Replace(saValues[i].Trim(), replacement);

                            string[] splter = { "~" };
                            string[] saFTVals = result.Split(splter, StringSplitOptions.RemoveEmptyEntries);

                            if (saFTVals != null)
                            {
                                if (saFTVals.Length > 0)
                                {
                                    strFreeText = saFTVals[0].Trim();
                                    strStageInfo = saFTVals[1].Trim();
                                }
                            }
                        }
                        else if (saValues[i].Trim().ToUpper().Contains(" (STAGES "))
                        {
                            string pattern = @"\(stages ";
                            string replacement = @"~(stages ";
                            Regex rgx = new Regex(pattern, RegexOptions.IgnoreCase);
                            string result = rgx.Replace(saValues[i].Trim(), replacement);

                            string[] splter = { "~" };
                            string[] saFTVals = result.Split(splter, StringSplitOptions.RemoveEmptyEntries);

                            if (saFTVals != null)
                            {
                                if (saFTVals.Length > 0)
                                {
                                    strFreeText = saFTVals[0].Trim();
                                    strStageInfo = saFTVals[1].Trim();
                                }
                            }
                        }

                        if (!string.IsNullOrEmpty(strFreeText))
                        {
                            dRow = dtFT_Stages.NewRow();

                            dRow["FreeText"] = strFreeText;
                            dRow["StageInfo"] = strStageInfo;

                            dtFT_Stages.Rows.Add(dRow);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtFT_Stages;
        }

        //================================================

        private bool CheckForConds_Pres_RSN_Validations(out string _errmsg)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (tcStages.TabCount > 0)
                {
                    ucParticipants ucPartpnt = null;
                    DataTable dtConds = null;
                    DataTable dtRSN = null;
                    int intStgIndx = 0;
                    string strStageName = "";

                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        intStgIndx = intStgIndx + 1;
                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            strStageName = ucPartpnt.StageName;
                            dtConds = ucPartpnt.dtConditions;
                            dtRSN = ucPartpnt.dtRSN;

                            if (dtConds != null)
                            {
                                if (dtConds.Rows.Count > 0)
                                {
                                    string[] splitter = { "a", "b", "s", "kp" };

                                    string[] splitter_D = { "]" };
                                    string[] pres_Direct = null;

                                    string strRngFrom = "";
                                    string strRngTo = "";

                                    for (int i = 0; i < dtConds.Rows.Count; i++)
                                    {
                                        if (!string.IsNullOrEmpty(dtConds.Rows[i]["PRESSURE"].ToString().Trim()))
                                        {
                                            switch (dtConds.Rows[i]["PRESSURE_TYPE"].ToString().Trim().ToUpper())
                                            {
                                                case "REGULAR":

                                                    if (!CheckPressureIsInGivenRange(dtConds.Rows[i]["PRESSURE"].ToString().Trim(), dtConds.Rows[i]["PRESSURE"].ToString().Trim(), strStageName, dtRSN, ref strErrMsg))
                                                    {
                                                        blStatus = false;
                                                    }
                                                    break;

                                                case "DIRECTIONAL":
                                                    
                                                    pres_Direct = dtConds.Rows[i]["PRESSURE"].ToString().Trim().Split(splitter_D, StringSplitOptions.RemoveEmptyEntries);

                                                    if (!CheckPressureIsInGivenRange(pres_Direct[0], dtConds.Rows[i]["PRESSURE"].ToString().Trim(), strStageName, dtRSN, ref strErrMsg))
                                                    {
                                                        blStatus = false;
                                                    }
                                                    else if (!CheckPressureIsInGivenRange(pres_Direct[1], dtConds.Rows[i]["PRESSURE"].ToString().Trim(), strStageName, dtRSN, ref strErrMsg))
                                                    {
                                                        blStatus = false;
                                                    }
                                                    break;

                                                case "RANGE":
                                                   
                                                    strRngFrom = GetRangeValuesFromString(dtConds.Rows[i]["PRESSURE"].ToString().Trim(), out strRngTo);

                                                    if (!CheckPressureIsInGivenRange(strRngFrom, dtConds.Rows[i]["PRESSURE"].ToString().Trim(), strStageName, dtRSN, ref strErrMsg))
                                                    {
                                                        blStatus = false;
                                                    }
                                                    else if (!CheckPressureIsInGivenRange(strRngTo, dtConds.Rows[i]["PRESSURE"].ToString().Trim(), strStageName, dtRSN, ref strErrMsg))
                                                    {
                                                        blStatus = false;
                                                    }
                                                    break;
                                            }
                                        }                              
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg;
            return blStatus;
        }

        private string GetRangeValuesFromString(string _rangetext, out string _rng_to_val)
        {
            string strFromVal = "";
            string strToVal = "";
            try
            {
                if (_rangetext.Trim() != "")
                {
                    char[] charArray = _rangetext.ToCharArray();
                    if (charArray != null)
                    {
                        if (charArray.Length > 0)
                        {
                            bool blRng = false;
                            for (int i = 0; i < charArray.Length; i++)
                            {
                                if (charArray[i] != '-' && i != 0 && blRng == false)
                                {
                                    strFromVal = strFromVal.Trim() + charArray[i].ToString().Trim();
                                }
                                else if (charArray[i] == '-' && i == 0)
                                {
                                    strFromVal = strFromVal.Trim() + charArray[i].ToString().Trim();
                                }
                                else if (charArray[i] == '-' && i != 0 && blRng == false)
                                {
                                    blRng = true;
                                }
                                else if (charArray[i] != '-' && blRng == false)
                                {
                                    strFromVal = strFromVal.Trim() + charArray[i].ToString().Trim();
                                }
                                else if (blRng)
                                {
                                    strToVal = strToVal.Trim() + charArray[i].ToString().Trim();
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _rng_to_val = strToVal;
            return strFromVal;
        }

        //New validation on 17th Nov 2015, 
        //Check High Pressure/Low Pressure in the reaction level first, If it is not there, then check in the Stage level
        private bool CheckForRSNTermInReactionLevel(string rsnterm)
        {
            bool blStatus = false;
            try
            {
                if (tcStages.TabPages.Count > 0)
                {
                    ucParticipants ucPartpnt = null;
                    ucPartpnt = (ucParticipants)tcStages.TabPages[0].Controls["ucParticipants"];
                    if (ucPartpnt != null)
                    {
                        DataTable dtRsn = ucPartpnt.dtRSN;
                        if (CheckForRSNCVT_FreeTextInTable(dtRsn, rsnterm, "Reaction"))
                        {
                            blStatus = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckPressureIsInGivenRange(string _presval, string _presval_orig, string _stage, DataTable _rsntbl, ref string _errmsg_out)
        {
            bool blStatus = true;
            try
            {
                string[] splitter = { "a", "b", "s", "kp" };
                if (_presval.Trim().Contains("b"))
                {
                    double dblPres = 0.0;
                    string strPresVal = _presval.Trim();

                    if (strPresVal.StartsWith(">"))
                    {
                        strPresVal = strPresVal.Replace(">", "");
                        strPresVal = strPresVal.Replace("b", "");

                        if (double.TryParse(strPresVal.Trim(), out dblPres))
                        {
                            if (dblPres >= 10)
                            {
                                //if (!CheckForRSN_CVT_Free_InTable(_rsntbl, "High Pressure"))
                                if (!CheckForRSNTermInAllStagesRSN(_rsntbl, "High Pressure", _stage))
                                {
                                    blStatus = false;
                                    _errmsg_out = _errmsg_out.Trim() + "\r\n" + "RSN CVT/Free should be 'high pressure' for the pressure value " + _presval_orig + " in the " + _stage + " of the Reation";
                                }
                            }
                        }
                    }
                    else if (strPresVal.StartsWith("<"))
                    {
                        strPresVal = strPresVal.Replace("<", "");
                        strPresVal = strPresVal.Replace("b", "");

                        if (double.TryParse(strPresVal.Trim(), out dblPres))
                        {
                            if (dblPres < 1)
                            {
                                //if (!CheckForRSN_CVT_Free_InTable(_rsntbl, "Low Pressure"))
                                if (!CheckForRSNTermInAllStagesRSN(_rsntbl, "Low Pressure", _stage))
                                {
                                    blStatus = false;
                                    _errmsg_out = _errmsg_out.Trim() + "\r\n" + "RSN CVT/Free should be 'Low Pressure' for the Pressure value " + _presval_orig + " in the " + _stage + " of the Reation";

                                }
                            }
                        }
                    }
                    else
                    {
                        strPresVal = strPresVal.Replace("b", "");

                        if (double.TryParse(strPresVal.Trim(), out dblPres))
                        {
                            if (dblPres >= 10)
                            {
                                //if (!CheckForRSN_CVT_Free_InTable(_rsntbl, "High Pressure"))
                                if (!CheckForRSNTermInAllStagesRSN(_rsntbl, "High Pressure", _stage))
                                {
                                    blStatus = false;
                                    _errmsg_out = _errmsg_out.Trim() + "\r\n" + "RSN CVT/Free should be 'High Pressure' for the Pressure value " + _presval_orig + " in the " + _stage + " of the Reation";

                                }
                            }
                            else if (dblPres < 1)
                            {
                                //if (!CheckForRSN_CVT_Free_InTable(_rsntbl, "Low Pressure"))
                                if (!CheckForRSNTermInAllStagesRSN(_rsntbl, "Low Pressure", _stage))
                                {
                                    blStatus = false;
                                    _errmsg_out = _errmsg_out.Trim() + "\r\n" + "RSN CVT/Free should be 'Low Pressure' for the Pressure value " + _presval_orig + " in the " + _stage + " of the Reation";

                                }
                            }
                        }
                    }
                }
                else if (_presval.Trim().Contains("s"))
                {
                    double dblPres = 0.0;
                    string strPresVal = _presval.Trim();

                    if (strPresVal.StartsWith(">"))
                    {
                        strPresVal = strPresVal.Replace(">", "");
                        strPresVal = strPresVal.Replace("s", "");

                        if (double.TryParse(strPresVal.Trim(), out dblPres))
                        {
                            if (dblPres >= 147)
                            {
                                //if (!CheckForRSN_CVT_Free_InTable(_rsntbl, "High Pressure"))
                                if (!CheckForRSNTermInAllStagesRSN(_rsntbl, "High Pressure", _stage))
                                {
                                    blStatus = false;
                                    _errmsg_out = _errmsg_out.Trim() + "\r\n" + "RSN CVT/Free should be 'High Pressure' for the Pressure value " + _presval_orig + " in the " + _stage + " of the Reation";

                                }
                            }
                        }
                    }
                    else if (strPresVal.StartsWith("<"))
                    {
                        strPresVal = strPresVal.Replace("<", "");
                        strPresVal = strPresVal.Replace("s", "");

                        if (double.TryParse(strPresVal.Trim(), out dblPres))
                        {
                            if (dblPres < 14.7)
                            {
                                //if (!CheckForRSN_CVT_Free_InTable(_rsntbl, "Low Pressure"))
                                if (!CheckForRSNTermInAllStagesRSN(_rsntbl, "Low Pressure", _stage))
                                {
                                    blStatus = false;
                                    _errmsg_out = _errmsg_out.Trim() + "\r\n" + "RSN CVT/Free should be 'Low Pressure' for the Pressure value " + _presval_orig + " in the " + _stage + " of the Reation";

                                }
                            }
                        }
                    }
                    else
                    {
                        strPresVal = strPresVal.Replace("s", "");

                        if (double.TryParse(strPresVal.Trim(), out dblPres))
                        {
                            if (dblPres >= 147)
                            {
                                //if (!CheckForRSN_CVT_Free_InTable(_rsntbl, "High Pressure"))
                                if (!CheckForRSNTermInAllStagesRSN(_rsntbl, "High Pressure", _stage))
                                {
                                    blStatus = false;
                                    _errmsg_out = _errmsg_out.Trim() + "\r\n" + "RSN CVT/Free should be 'High Pressure' for the Pressure value " + _presval_orig + " in the " + _stage + " of the Reation";

                                }
                            }
                            else if (dblPres < 14.7)
                            {
                                //if (!CheckForRSN_CVT_Free_InTable(_rsntbl, "Low Pressure"))
                                if (!CheckForRSNTermInAllStagesRSN(_rsntbl, "Low Pressure", _stage))
                                {
                                    blStatus = false;
                                    _errmsg_out = _errmsg_out.Trim() + "\r\n" + "RSN CVT/Free should be 'Low Pressure' for the Pressure value " + _presval_orig + " in the " + _stage + " of the Reation";

                                }
                            }

                        }
                    }
                }
                else if (_presval.Trim().Contains("kp"))
                {
                    double dblPres = 0.0;
                    string strPresVal = _presval.Trim();

                    if (strPresVal.StartsWith(">"))
                    {
                        strPresVal = strPresVal.Replace(">", "");
                        strPresVal = strPresVal.Replace("kp", "");

                        if (double.TryParse(strPresVal.Trim(), out dblPres))
                        {
                            if (dblPres >= 1010)
                            {
                                //if (!CheckForRSN_CVT_Free_InTable(_rsntbl, "High Pressure"))
                                if (!CheckForRSNTermInAllStagesRSN(_rsntbl, "High Pressure", _stage))
                                {
                                    blStatus = false;
                                    _errmsg_out = _errmsg_out.Trim() + "\r\n" + "RSN CVT/Free should be 'High Pressure' for the Pressure value " + _presval_orig + " in the " + _stage + " of the Reation";

                                }
                            }
                        }
                    }
                    else if (strPresVal.StartsWith("<"))
                    {
                        strPresVal = strPresVal.Replace("<", "");
                        strPresVal = strPresVal.Replace("kp", "");

                        if (double.TryParse(strPresVal.Trim(), out dblPres))
                        {
                            if (dblPres < 101.0)
                            {
                                //if (!CheckForRSN_CVT_Free_InTable(_rsntbl, "Low Pressure"))
                                if (!CheckForRSNTermInAllStagesRSN(_rsntbl, "Low Pressure", _stage))
                                {
                                    blStatus = false;
                                    _errmsg_out = _errmsg_out.Trim() + "\r\n" + "RSN CVT/Free should be 'Low Pressure' for the Pressure value " + _presval_orig + " in the " + _stage + " of the Reation";

                                }
                            }
                        }
                    }
                    else
                    {
                        strPresVal = strPresVal.Replace("kp", "");

                        if (double.TryParse(strPresVal.Trim(), out dblPres))
                        {
                            if (dblPres >= 1010)
                            {
                                //if (!CheckForRSN_CVT_Free_InTable(_rsntbl, "High Pressure"))
                                if (!CheckForRSNTermInAllStagesRSN(_rsntbl, "High Pressure", _stage))
                                {
                                    blStatus = false;
                                    _errmsg_out = _errmsg_out.Trim() + "\r\n" + "RSN CVT/Free should be 'High Pressure' for the Pressure value " + _presval_orig + " in the " + _stage + " of the Reation";

                                }
                            }
                            else if (dblPres < 101.0)
                            {
                                //if (!CheckForRSN_CVT_Free_InTable(_rsntbl, "Low Pressure"))
                                if (!CheckForRSNTermInAllStagesRSN(_rsntbl, "Low Pressure", _stage))
                                {
                                    blStatus = false;
                                    _errmsg_out = _errmsg_out.Trim() + "\r\n" + "RSN CVT/Free should be 'Low Pressure' for the Pressure value " + _presval_orig + " in the " + _stage + " of the Reation";

                                }
                            }
                        }
                    }
                }
                else//default is 'a'
                {
                    double dblPres = 0.0;

                    string strPresVal = _presval.Trim();

                    if (strPresVal.StartsWith(">"))
                    {
                        strPresVal = strPresVal.Replace(">", "");

                        if (double.TryParse(strPresVal.Trim(), out dblPres))
                        {
                            if (dblPres >= 10)
                            {
                                //if (!CheckForRSN_CVT_Free_InTable(_rsntbl, "High Pressure"))
                                if (!CheckForRSNTermInAllStagesRSN(_rsntbl, "High Pressure", _stage))
                                {
                                    blStatus = false;
                                    _errmsg_out = _errmsg_out.Trim() + "\r\n" + "RSN CVT/Free should be 'High Pressure' for the Pressure value " + _presval_orig + " in the " + _stage + " of the Reation";

                                }
                            }
                        }
                    }
                    else if (strPresVal.StartsWith("<"))
                    {
                        strPresVal = strPresVal.Replace("<", "");

                        if (double.TryParse(strPresVal.Trim(), out dblPres))
                        {
                            if (dblPres < 1)
                            {
                                //if (!CheckForRSN_CVT_Free_InTable(_rsntbl, "Low Pressure"))
                                if (!CheckForRSNTermInAllStagesRSN(_rsntbl, "Low Pressure", _stage))
                                {
                                    blStatus = false;
                                    _errmsg_out = _errmsg_out.Trim() + "\r\n" + "RSN CVT/Free should be 'Low Pressure' for the Pressure value " + _presval_orig + " in the " + _stage + " of the Reation";

                                }
                            }
                        }
                    }
                    else
                    {
                        if (double.TryParse(strPresVal.Trim(), out dblPres))
                        {
                            if (dblPres >= 10)
                            {
                                //if (!CheckForRSNTermInReactionLevel("High Pressure"))//New validation on 17th Nov 2015 -- to be implemented
                                //{
                                    if (!CheckForRSNTermInAllStagesRSN(_rsntbl, "High Pressure", _stage))
                                    {
                                        blStatus = false;
                                        _errmsg_out = _errmsg_out.Trim() + "\r\n" + "RSN CVT/Free should be 'High Pressure' for the Pressure value " + _presval_orig + " in the " + _stage + " of the Reation";
                                    }
                               // }
                            }
                            else if (dblPres < 1)
                            {
                                //if (!CheckForRSN_CVT_Free_InTable(_rsntbl, "Low Pressure"))
                                if (!CheckForRSNTermInAllStagesRSN(_rsntbl, "Low Pressure", _stage))
                                {
                                    blStatus = false;
                                    _errmsg_out = _errmsg_out.Trim() + "\r\n" + "RSN CVT/Free should be 'Low Pressure' for the Pressure value " + _presval_orig + " in the " + _stage + " of the Reation";

                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckForRSNCVT_FreeTextInTable(DataTable _rsntbl, string _rsnterm, string is_rxn_stage)
        {
            bool blStatus = false;
            try
            {
                if (_rsntbl != null)
                {
                    if (_rsntbl.Rows.Count > 0)
                    {
                        string strRSNTerm = _rsnterm.Trim().Replace("'", "''");
                       
                        //Reaction Level
                        DataRow[] drArr_Cvt = _rsntbl.Select("CVT = '" + strRSNTerm + "' and NOTE_LEVEL = '" + is_rxn_stage + "'");
                        if (drArr_Cvt != null)
                        {
                            if (drArr_Cvt.Length > 0)
                            {
                                blStatus = true;
                                return blStatus;
                            }
                        }

                        //Stage Level - new feature as on 16th March 2011
                        DataRow[] drArr_Free = _rsntbl.Select("FREE_TEXT like '%" + strRSNTerm + "%' and NOTE_LEVEL = '" + is_rxn_stage + "'");
                        if (drArr_Free != null)
                        {
                            if (drArr_Free.Length > 0)
                            {
                                if (_rsnterm.Trim().ToUpper() != "THERMAL")//For Thermal it's Equal Search else like search
                                {
                                    blStatus = true;
                                    return blStatus;
                                }
                                else
                                {
                                    for (int i = 0; i < drArr_Free.Length; i++)
                                    {
                                        if (!string.IsNullOrEmpty(drArr_Free[i]["FREE_TEXT"].ToString()))
                                        {
                                            DataTable dtFT_Stages = GetFreeText_StagesData(drArr_Free[i]["FREE_TEXT"].ToString());
                                            if (dtFT_Stages != null)
                                            {
                                                for (int j = 0; j < dtFT_Stages.Rows.Count; j++)
                                                {
                                                    if (dtFT_Stages.Rows[j][0].ToString().ToUpper() == _rsnterm.ToUpper())
                                                    {
                                                        blStatus = true;
                                                        return blStatus;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckForRSN_CVTInTable(DataTable _rsntbl,string fieldname, string _rsnterm)
        {
            bool blStatus = false;
            try
            {
                if (_rsntbl != null && _rsntbl.Rows.Count > 0)
                {
                    //New modification on 16th Feb 2016, Alternative preparation shown is moved to FREETEXT
                    //Reaction Level
                    //DataRow[] drArr_Cvt = _rsntbl.Select("CVT = '" + _rsnterm + "'");
                    DataRow[] drArr_Cvt = _rsntbl.Select(fieldname + " = '" + _rsnterm + "'");
                    if (drArr_Cvt != null && drArr_Cvt.Length > 0)
                    {
                        blStatus = true;
                        return blStatus;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckForConds_Validations(out string _errmsg)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                ucParticipants ucPartpnt = null;
                DataTable dtConds = null;
                int intStgIndx = 0;

                bool blvalid_c = false;
                bool blvalid_bracket = false;
                bool blvalid_range = false;

                foreach (TabPage tp in tcStages.TabPages)
                {
                    intStgIndx = intStgIndx + 1;
                    ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                    if (ucPartpnt != null)
                    {
                        dtConds = ucPartpnt.dtConditions;
                        if (dtConds != null)
                        {
                            if (dtConds.Rows.Count > 0)
                            {
                                for (int i = 0; i < dtConds.Rows.Count; i++)
                                {
                                    if (dtConds.Rows[i]["time"].ToString().Trim() == "" && dtConds.Rows[i]["temperature"].ToString().Trim() == ""
                                       && dtConds.Rows[i]["ph"].ToString().Trim() == "" && dtConds.Rows[i]["pressure"].ToString().Trim() == "")
                                    {
                                        blStatus = false;
                                        if (strErrMsg.Trim() == "")
                                        {
                                            strErrMsg = "Empty Conditions in the Stage" + intStgIndx + " of the Reation";
                                        }
                                        else
                                        {
                                            strErrMsg = strErrMsg + "\r\n" + "Empty Conditions in the Stage" + intStgIndx + " of the Reation";
                                        }
                                    }
                                    else if (dtConds.Rows[i]["time"].ToString().Trim() != "" && dtConds.Rows[i]["temperature"].ToString().Trim() == "")
                                    {
                                        blStatus = false;
                                        if (strErrMsg.Trim() == "")
                                        {
                                            strErrMsg = "Time corresponding Temperature is not there in the Stage" + intStgIndx + " of the Reaction";
                                        }
                                        else
                                        {
                                            strErrMsg = strErrMsg + "\r\n" + "Time corresponding Temperature is not there in the Stage" + intStgIndx + " of the Reaction";
                                        }
                                    }

                                    //Temperature Validation
                                    if (dtConds.Rows[i]["temperature"].ToString() != "")
                                    {
                                        if (dtConds.Rows[i]["temperature"].ToString() == "=" && i == 0 && intStgIndx == 1 && blvalid_c == false)
                                        {
                                            blStatus = false;
                                            if (strErrMsg.Trim() == "")
                                            {
                                                strErrMsg = "'=' is not allowed in the 1st sub-stage of the reaction";
                                            }
                                            else
                                            {
                                                strErrMsg = strErrMsg + "\r\n" + "'=' is not allowed in the 1st sub-stage of the reaction";
                                            }
                                        }
                                        else if (dtConds.Rows[i]["temperature"].ToString().Contains("=") && i == 0 && blvalid_c == true)
                                        {
                                            blStatus = false;
                                            if (strErrMsg.Trim() == "")
                                            {
                                                strErrMsg = "After TP is 'c' then = or ] is not allowed in the Stage" + intStgIndx + " of the reaction";
                                            }
                                            else
                                            {
                                                strErrMsg = strErrMsg + "\r\n" + "After TP is 'c' then = or ] is not allowed in the Stage" + intStgIndx + " of the reaction";
                                            }
                                        }
                                        else if ((dtConds.Rows[i]["temperature"].ToString().Contains("=") || dtConds.Rows[i]["temperature"].ToString().Contains("=]")) && i == 0 && blvalid_bracket == true)//New validation on 19th Jan 2011
                                        {
                                            blStatus = false;
                                            if (strErrMsg.Trim() == "")
                                            {
                                                strErrMsg = "After TP is ']' then = or ] is not allowed in the Stage" + intStgIndx + " of the reaction";
                                            }
                                            else
                                            {
                                                strErrMsg = strErrMsg + "\r\n" + "After TP is ']' then = or ] is not allowed in the Stage" + intStgIndx + " of the reaction";
                                            }
                                        }
                                        else if (dtConds.Rows[i]["temperature"].ToString().Contains("]") && i == 0 && blvalid_c == true)
                                        {
                                            blStatus = false;
                                            if (strErrMsg.Trim() == "")
                                            {
                                                strErrMsg = "After TP is 'c' then = or ] is not allowed in the Stage" + intStgIndx + " of the reaction";
                                            }
                                            else
                                            {
                                                strErrMsg = strErrMsg + "\r\n" + "After TP is 'c' then = or ] is not allowed in the Stage" + intStgIndx + " of the reaction";
                                            }
                                        }
                                        else if (dtConds.Rows[i]["temperature"].ToString().Contains("=") && i == 0 && blvalid_range == true)
                                        {
                                            blStatus = false;
                                            if (strErrMsg.Trim() == "")
                                            {
                                                strErrMsg = "= is not allowed in the Stage" + intStgIndx + " of the reaction";
                                            }
                                            else
                                            {
                                                strErrMsg = strErrMsg + "\r\n" + "= is not allowed in the Stage" + intStgIndx + " of the reaction";
                                            }
                                        }
                                        else if (dtConds.Rows[i]["temperature"].ToString().Trim().StartsWith("]") || dtConds.Rows[i]["temperature"].ToString().Trim().EndsWith("]"))
                                        {
                                            blStatus = false;
                                            if (strErrMsg.Trim() == "")
                                            {
                                                strErrMsg = "]  both sides of the directional bracket must contain value in the Stage" + intStgIndx + " of the reaction";
                                            }
                                            else
                                            {
                                                strErrMsg = strErrMsg + "\r\n" + "]  both sides of the directional bracket must contain value in the Stage" + intStgIndx + " of the reaction";
                                            }
                                        }
                                        else if (dtConds.Rows[i]["temperature"].ToString() == "c" && (i == dtConds.Rows.Count - 1))
                                        {
                                            blvalid_c = true;
                                        }
                                        else if (dtConds.Rows[i]["temperature"].ToString().Contains("]") && (i == dtConds.Rows.Count - 1))//New validation on 19th Jan 2011
                                        {
                                            blvalid_bracket = true;

                                            string[] splitter = { "]" };
                                            string[] strVals = dtConds.Rows[i]["temperature"].ToString().Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                                            if (strVals.Length == 2)
                                            {
                                                if (strVals[0] == strVals[1])
                                                {
                                                    blStatus = false;
                                                    if (strErrMsg.Trim() == "")
                                                    {
                                                        strErrMsg = dtConds.Rows[i]["temperature"].ToString().Trim() + "  is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                    }
                                                    else
                                                    {
                                                        strErrMsg = strErrMsg + "\r\n" + dtConds.Rows[i]["temperature"].ToString().Trim() + "  is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                    }
                                                }
                                                else if (strVals[1] == "=")
                                                {
                                                    blStatus = false;
                                                    if (strErrMsg.Trim() == "")
                                                    {
                                                        strErrMsg = dtConds.Rows[i]["temperature"].ToString().Trim() + "  is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                    }
                                                    else
                                                    {
                                                        strErrMsg = strErrMsg + "\r\n" + dtConds.Rows[i]["temperature"].ToString().Trim() + "  is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                    }
                                                }
                                                else if (strVals[0].Contains("c") || strVals[1].Contains("c"))
                                                {
                                                    blStatus = false;
                                                    if (strErrMsg.Trim() == "")
                                                    {
                                                        strErrMsg = "'c' should not allow directional changes in the Stage" + intStgIndx + " of the reaction";
                                                    }
                                                    else
                                                    {
                                                        strErrMsg = strErrMsg + "\r\n" + "'c' should not allow directional changes in the Stage" + intStgIndx + " of the reaction";
                                                    }
                                                }
                                            }
                                        }
                                        else if (dtConds.Rows[i]["temperature"].ToString().Contains("-") && (i == dtConds.Rows.Count - 1))//New validation on 19th Jan 2011
                                        {
                                            blvalid_range = true;
                                        }
                                        else if (dtConds.Rows[i]["temperature"].ToString().Contains("c") && dtConds.Rows[i]["temperature"].ToString() != "c")
                                        {
                                            blStatus = false;
                                            if (strErrMsg.Trim() == "")
                                            {
                                                strErrMsg = "'c' should not allow directional changes in the Stage" + intStgIndx + " of the reaction";
                                            }
                                            else
                                            {
                                                strErrMsg = strErrMsg + "\r\n" + "'c' should not allow directional changes in the Stage" + intStgIndx + " of the reaction";
                                            }
                                        }
                                        #region Code commented
                                        //else if (dtConds.Rows[i]["temperature"].ToString().Trim() == "]")
                                        //{
                                        //    blStatus = false;
                                        //    if (strErrMsg.Trim() == "")
                                        //    {
                                        //        strErrMsg = "] is not valid in the Stage" + intStgIndx + " of the Reaction ";
                                        //    }
                                        //    else
                                        //    {
                                        //        strErrMsg = strErrMsg + "\r\n" + "] is not valid in the Stage" + intStgIndx + " of the Reaction ";
                                        //    }
                                        //}
                                        //else if (dtConds.Rows[i]["temperature"].ToString().Trim() == "]=")
                                        //{
                                        //    blStatus = false;
                                        //    if (strErrMsg.Trim() == "")
                                        //    {
                                        //        strErrMsg = "]= is not valid in the Stage" + intStgIndx + " of the Reaction";
                                        //    }
                                        //    else
                                        //    {
                                        //        strErrMsg = strErrMsg + "\r\n" + "]= is not valid in the Stage" + intStgIndx + " of the Reaction";
                                        //    }
                                        //} 
                                        #endregion
                                        else if (dtConds.Rows[i]["temperature"].ToString().Trim() == "=")
                                        {
                                            if (i > 0)
                                            {
                                                if (dtConds.Rows[i - 1]["temperature"].ToString().Trim() == "c")
                                                {
                                                    blStatus = false;
                                                    if (strErrMsg.Trim() == "")
                                                    {
                                                        strErrMsg = "After TP is 'c' then = or ] is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                    }
                                                    else
                                                    {
                                                        strErrMsg = strErrMsg + "\r\n" + "After TP is 'c' then = or ] is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                    }
                                                }
                                            }
                                        }
                                        else if (dtConds.Rows[i]["temperature"].ToString().Trim().Contains("-"))//New validation as on 11th Jan 2011
                                        {
                                            if (i < (dtConds.Rows.Count - 1))
                                            {
                                                decimal decVal = 0;
                                                if (decimal.TryParse(dtConds.Rows[i]["temperature"].ToString(), out decVal))//Check if it is negative value
                                                {

                                                }
                                                else if (dtConds.Rows[i + 1]["temperature"].ToString().Trim().Contains("=]"))// || (dtConds.Rows[i + 1]["temperature"].ToString().Trim().Contains("-") && (dtConds.Rows[i + 1]["temperature"].ToString().Trim().Contains("]")))
                                                {
                                                    blStatus = false;
                                                    if (strErrMsg.Trim() == "")
                                                    {
                                                        strErrMsg = "After TP is '" + dtConds.Rows[i]["temperature"].ToString() + "' then '" + dtConds.Rows[i + 1]["temperature"].ToString().Trim() + "' is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                    }
                                                    else
                                                    {
                                                        strErrMsg = strErrMsg + "\r\n" + "After TP is '" + dtConds.Rows[i]["temperature"].ToString() + "' then '" + dtConds.Rows[i + 1]["temperature"].ToString().Trim() + "' is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                    }
                                                }
                                                else
                                                {
                                                    string[] splitter = { "-" };
                                                    string[] strVals = dtConds.Rows[i]["temperature"].ToString().Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                                                    if (strVals.Length == 2)
                                                    {
                                                        if (strVals[0] == strVals[1])
                                                        {
                                                            blStatus = false;
                                                            if (strErrMsg.Trim() == "")
                                                            {
                                                                strErrMsg = dtConds.Rows[i]["temperature"].ToString().Trim() + "  is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                            }
                                                            else
                                                            {
                                                                strErrMsg = strErrMsg + "\r\n" + dtConds.Rows[i]["temperature"].ToString().Trim() + "  is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                            }
                                                        }
                                                        else
                                                        {
                                                            if (dtConds.Rows[i + 1]["temperature"].ToString().Trim().Contains("=]")
                                                               || (dtConds.Rows[i + 1]["temperature"].ToString().Trim().Contains("=")))
                                                            {
                                                                blStatus = false;
                                                                if (strErrMsg.Trim() == "")
                                                                {
                                                                    strErrMsg = "After TP is '" + dtConds.Rows[i]["temperature"].ToString() + "' then '" + dtConds.Rows[i + 1]["temperature"].ToString().Trim() + "' is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                                }
                                                                else
                                                                {
                                                                    strErrMsg = strErrMsg + "\r\n" + "After TP is '" + dtConds.Rows[i]["temperature"].ToString() + "' then '" + dtConds.Rows[i + 1]["temperature"].ToString().Trim() + "' is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                string[] splitter = { "-" };
                                                string[] strVals = dtConds.Rows[i]["temperature"].ToString().Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                                                if (strVals.Length == 2)
                                                {
                                                    if (strVals[0] == strVals[1])
                                                    {
                                                        blStatus = false;
                                                        if (strErrMsg.Trim() == "")
                                                        {
                                                            strErrMsg = dtConds.Rows[i]["temperature"].ToString().Trim() + "  is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                        }
                                                        else
                                                        {
                                                            strErrMsg = strErrMsg + "\r\n" + dtConds.Rows[i]["temperature"].ToString().Trim() + "  is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        else if (dtConds.Rows[i]["temperature"].ToString().Trim().StartsWith("=]"))//New validation as on 11th Jan 2011
                                        {
                                            if (i < (dtConds.Rows.Count - 1))
                                            {
                                                if (dtConds.Rows[i + 1]["temperature"].ToString().Trim().Contains("=]")
                                                    || dtConds.Rows[i + 1]["temperature"].ToString().Trim() == "=")
                                                {
                                                    blStatus = false;
                                                    if (strErrMsg.Trim() == "")
                                                    {
                                                        strErrMsg = "After TP is '" + dtConds.Rows[i]["temperature"].ToString() + "' then '" + dtConds.Rows[i + 1]["temperature"].ToString().Trim() + "' is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                    }
                                                    else
                                                    {
                                                        strErrMsg = strErrMsg + "\r\n" + "After TP is '" + dtConds.Rows[i]["temperature"].ToString() + "' then '" + dtConds.Rows[i + 1]["temperature"].ToString().Trim() + "' is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                    }
                                                }
                                            }
                                        }
                                        else if (dtConds.Rows[i]["temperature"].ToString().Trim().Contains("]"))//New validation as on 17th Jan 2011
                                        {
                                            if (i < (dtConds.Rows.Count - 1))
                                            {
                                                if (dtConds.Rows[i + 1]["temperature"].ToString().Trim().Contains("=]")
                                                    || dtConds.Rows[i + 1]["temperature"].ToString().Trim() == "=")
                                                {
                                                    blStatus = false;
                                                    if (strErrMsg.Trim() == "")
                                                    {
                                                        strErrMsg = "After TP is '" + dtConds.Rows[i]["temperature"].ToString() + "' then '" + dtConds.Rows[i + 1]["temperature"].ToString().Trim() + "' is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                    }
                                                    else
                                                    {
                                                        strErrMsg = strErrMsg + "\r\n" + "After TP is '" + dtConds.Rows[i]["temperature"].ToString() + "' then '" + dtConds.Rows[i + 1]["temperature"].ToString().Trim() + "' is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                    }
                                                }
                                                else
                                                {
                                                    string[] splitter = { "]" };
                                                    string[] strVals = dtConds.Rows[i]["temperature"].ToString().Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                                                    if (strVals.Length == 2)
                                                    {
                                                        if (strVals[0] == strVals[1])
                                                        {
                                                            blStatus = false;
                                                            if (strErrMsg.Trim() == "")
                                                            {
                                                                strErrMsg = dtConds.Rows[i]["temperature"].ToString().Trim() + "  is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                            }
                                                            else
                                                            {
                                                                strErrMsg = strErrMsg + "\r\n" + dtConds.Rows[i]["temperature"].ToString().Trim() + "  is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                            }
                                                        }
                                                        else if (strVals[1] == "=")
                                                        {
                                                            blStatus = false;
                                                            if (strErrMsg.Trim() == "")
                                                            {
                                                                strErrMsg = dtConds.Rows[i]["temperature"].ToString().Trim() + "  is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                            }
                                                            else
                                                            {
                                                                strErrMsg = strErrMsg + "\r\n" + dtConds.Rows[i]["temperature"].ToString().Trim() + "  is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                string[] splitter = { "]" };
                                                string[] strVals = dtConds.Rows[i]["temperature"].ToString().Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                                                if (strVals.Length == 2)
                                                {
                                                    if (strVals[0] == strVals[1])
                                                    {
                                                        blStatus = false;
                                                        if (strErrMsg.Trim() == "")
                                                        {
                                                            strErrMsg = dtConds.Rows[i]["temperature"].ToString().Trim() + "  is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                        }
                                                        else
                                                        {
                                                            strErrMsg = strErrMsg + "\r\n" + dtConds.Rows[i]["temperature"].ToString().Trim() + "  is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                        }
                                                    }
                                                    else if (strVals[1] == "=")
                                                    {
                                                        blStatus = false;
                                                        if (strErrMsg.Trim() == "")
                                                        {
                                                            strErrMsg = dtConds.Rows[i]["temperature"].ToString().Trim() + "  is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                        }
                                                        else
                                                        {
                                                            strErrMsg = strErrMsg + "\r\n" + dtConds.Rows[i]["temperature"].ToString().Trim() + "  is not allowed in the Stage" + intStgIndx + " of the reaction";
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    //Pressure Validation
                                    if (dtConds.Rows[i]["pressure"].ToString().Trim() != ""
                                        && dtConds.Rows[i]["pressure"].ToString().Trim().Contains("-"))
                                    {
                                        if (!CheckForValidPressure_Time(dtConds.Rows[i]["pressure"].ToString().Trim()))
                                        {
                                            blStatus = false;
                                            if (strErrMsg.Trim() == "")
                                            {
                                                strErrMsg = "'" + dtConds.Rows[i]["pressure"].ToString().Trim() + "' is In-Valid Pressure units";
                                            }
                                            else
                                            {
                                                strErrMsg = strErrMsg + "\r\n" + "'" + dtConds.Rows[i]["pressure"].ToString().Trim() + "' is In-Valid Pressure units";
                                            }
                                        }
                                    }
                                    //Time Validation
                                    if (dtConds.Rows[i]["time"].ToString().Trim() != "")
                                    {
                                        if (dtConds.Rows[i]["time"].ToString().Trim().Contains("-"))
                                        {
                                            if (!CheckForValidPressure_Time(dtConds.Rows[i]["time"].ToString().Trim()))
                                            {
                                                blStatus = false;
                                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "'" + dtConds.Rows[i]["time"].ToString().Trim() + "' is In-Valid Time units";
                                            }
                                        }
                                        else if (dtConds.Rows[i]["time"].ToString().Trim().Contains("o") && (dtConds.Rows[i]["time"].ToString().Trim().Length > 1))//o is single value always
                                        {
                                            blStatus = false;
                                            if (strErrMsg.Trim() == "")
                                            {
                                                strErrMsg = "'" + dtConds.Rows[i]["time"].ToString().Trim() + "' is In-Valid Time units";
                                            }
                                            else
                                            {
                                                strErrMsg = strErrMsg + "\r\n" + "'" + dtConds.Rows[i]["time"].ToString().Trim() + "' is In-Valid Time units";
                                            }
                                        }
                                        else
                                        {
                                            Regex objAlpNumPatrn = new Regex("[^a-zA-Z0-9]");
                                            if (objAlpNumPatrn.IsMatch(dtConds.Rows[i]["time"].ToString().Trim()))
                                            {
                                                blStatus = false;
                                                if (strErrMsg.Trim() == "")
                                                {
                                                    strErrMsg = "'" + dtConds.Rows[i]["time"].ToString().Trim() + "' is In-Valid Time units";
                                                }
                                                else
                                                {
                                                    strErrMsg = strErrMsg + "\r\n" + "'" + dtConds.Rows[i]["time"].ToString().Trim() + "' is In-Valid Time units";
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg;
            return blStatus;
        }

        private bool CheckForValidPressure_Time(string _pres_time)
        {
            bool blStatus = false;
            try
            {
                string[] splitter = { "-" };
                string[] presVals = _pres_time.Split(splitter, StringSplitOptions.RemoveEmptyEntries);

                if (presVals != null && presVals.Length == 2)
                {
                    double val1 = 0;
                    double val2 = 0;
                    if (double.TryParse(presVals[0], out val1) &&
                        double.TryParse(presVals[1], out val2))
                    {
                        blStatus = true;
                    }
                    else if ((Char.Parse(presVals[0].Substring(presVals[0].Length - 1)) ==
                              Char.Parse(presVals[1].Substring(presVals[1].Length - 1)))
                              && double.TryParse(presVals[0].Substring(0, presVals[0].Length - 1), out val1)
                              && double.TryParse(presVals[1].Substring(0, presVals[1].Length - 1), out val1))
                    {
                        blStatus = true;
                    }
                    else if ((presVals[0].Substring(presVals[0].Length - 2) ==
                              presVals[1].Substring(presVals[1].Length - 2))
                              && double.TryParse(presVals[0].Substring(0, presVals[0].Length - 2), out val1)
                              && double.TryParse(presVals[1].Substring(0, presVals[1].Length - 2), out val1))
                    {
                        blStatus = true;
                    }
                    else
                    {
                        blStatus = false;
                        return blStatus;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckFor_Yield_Max_Allowed(string _yield)
        {
            bool blStatus = false;
            try
            {
                if (_yield.Trim() != "")
                {
                    int intYield = 0;
                    if (_yield.Trim().Contains(","))
                    {
                        string[] splitter = { "," };
                        string[] yieldArr = _yield.Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                        if (yieldArr != null)
                        {
                            for (int i = 0; i < yieldArr.Length; i++)
                            {
                                int.TryParse(yieldArr[i].Trim(), out intYield);
                                if (intYield <= 100)
                                {
                                    blStatus = false;
                                    return blStatus;
                                }
                                else
                                {
                                    blStatus = true;
                                }
                            }
                        }
                    }
                    else
                    {
                        intYield = 0;
                        int.TryParse(_yield, out intYield);
                        if (intYield <= 100)
                        {
                            blStatus = false;
                        }
                        else
                        {
                            blStatus = true;
                        }
                    }
                }
                return blStatus;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckFor_NRNNUM_In_Participant(int _num, int _ser9000, int _ser8500, int _ser8000, out string _errmsg)
        {
            try
            {
                if (tcStages.TabPages.Count > 0)
                {
                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        Control[] ucctl = tp.Controls.Find(Generic.GlobalVariables.UCControlName, true);
                        if (ucctl != null && ucctl.Length > 0)
                        {
                            ucParticipants ucpar = (ucParticipants)ucctl[0];
                            DataTable[] _dts = GetTablesfromUserControl(ucpar);
                            if (_dts != null && _dts.Length > 0)
                            {
                                for (int i = 0; i < _dts.Length; i++)
                                {
                                    if (_num > 0)
                                    {
                                        DataRow[] dtRowArr = _dts[i].Select("P_NUM = " + _num);
                                        if (dtRowArr.Length > 0)
                                        {
                                            _errmsg = "NUM already used in the " + _dts[i].TableName;
                                            return false;
                                        }
                                    }
                                    else if (_ser9000 > 0)
                                    {
                                        DataRow[] dtRowArr = _dts[i].Select("P_9000 = " + _ser9000);
                                        if (dtRowArr.Length > 0)
                                        {
                                            _errmsg = "9000 series value already used in the " + _dts[i].TableName;
                                            return false;
                                        }
                                    }
                                    else if (_ser8500 > 0)
                                    {
                                        DataRow[] dtRowArr = _dts[i].Select("P_8500 = " + _ser8500);
                                        if (dtRowArr.Length > 0)
                                        {
                                            _errmsg = "P_8500 already used in the " + _dts[i].TableName;
                                            return false;
                                        }
                                    }
                                    else if (_ser8000 > 0)
                                    {
                                        DataRow[] dtRowArr = _dts[i].Select("P_8000 = " + _num);
                                        if (dtRowArr.Length > 0)
                                        {
                                            _errmsg = "_ser8000 already used in the " + _dts[i].TableName;
                                            return false;
                                        }
                                    }
                                    else
                                    {
                                        _errmsg = "";
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = "";
            return false;
        }

        private bool CheckForEmptyReactantInReaction(out string _errmsg)//modified on 20Oct2011
        {
            bool blStatus = false;
            try
            {
                if (tcStages.TabPages.Count > 0)
                {
                    ucParticipants ucPartpnt = null;
                    DataTable dtblReactant = null;
                    int intCntr = 0;
                    bool blStauts_R = false;

                    if (tcStages.TabPages.Count == 1)
                    {
                        ucPartpnt = (ucParticipants)tcStages.TabPages[0].Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            dtblReactant = ucPartpnt.dtReactant != null ? ucPartpnt.dtReactant.Copy() : null;
                            if (dtblReactant != null)
                            {
                                if (dtblReactant.Rows.Count == 0)
                                {
                                    blStatus = true;
                                }
                            }
                            else
                            {
                                blStatus = true;
                            }
                        }
                    }
                    else
                    {
                        foreach (TabPage tp in tcStages.TabPages)
                        {
                            ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                            if (ucPartpnt != null)
                            {
                                dtblReactant = ucPartpnt.dtReactant != null ? ucPartpnt.dtReactant.Copy() : null;
                                if (dtblReactant != null)
                                {
                                    if (dtblReactant.Rows.Count == 0)
                                    {
                                        intCntr = intCntr + 1;
                                    }
                                    //else
                                    //{
                                    //    blStauts_R = CheckForEmptyRowsInTable(dtblReactant, "REACTANT");
                                    //    if (blStauts_R == true)
                                    //    {
                                    //        intCntr = intCntr + 1;
                                    //    }
                                    //}
                                }
                            }
                        }

                        if (intCntr == tcStages.TabPages.Count)//(intCntr == dtblReactant.Rows.Count) is a new condition on 13th Sep 2011
                        {
                            blStatus = true;
                        }
                    }
                }
                
                //Disable NewReaction button, if empty Reactant
                if (blStatus)
                {                    
                    btnAddRxn.Enabled = false;
                }
                else
                {
                    btnAddRxn.Enabled = true;
                }
                _errmsg = "Empty Reactant in the Reaction";
                return blStatus;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = "";
            return blStatus;
        }

        private bool CheckForDuplicateRSN_FreeTextTerms(out string _errmsg)//New feature as on 18th Feb 2011
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                if (tcStages.TabPages.Count > 0)
                {
                    ucParticipants ucPartpnt = null;
                    DataTable dtRSNTbl = null;
                    ArrayList alstRSN = new ArrayList();
                    string strStageName = "";
                    string[] splitter = { ")," };
                    string[] spl_stage = { "(stage" };

                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            dtRSNTbl = ucPartpnt.dtRSN;
                            strStageName = ucPartpnt.StageName;

                            if (dtRSNTbl != null && dtRSNTbl.Rows.Count > 0)
                            {
                                for (int i = 0; i < dtRSNTbl.Rows.Count; i++)
                                {
                                    if (dtRSNTbl.Rows[i]["RSN_FREE_TEXT"].ToString() != "")
                                    {
                                        string[] strArr_Temp = dtRSNTbl.Rows[i]["RSN_FREE_TEXT"].ToString().Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);

                                        if (strArr_Temp != null && strArr_Temp.Length > 0)
                                        {
                                            for (int j = 0; j < strArr_Temp.Length; j++)
                                            {
                                                string[] strArr_Free = strArr_Temp[j].Split(spl_stage, StringSplitOptions.RemoveEmptyEntries);
                                                if (strArr_Free != null && strArr_Free.Length > 0)
                                                {
                                                    if (strArr_Free[0].Trim().ToUpper() != "HIGH PRESSURE" &&
                                                       strArr_Free[0].Trim().ToUpper() != "LOW PRESSURE" &&
                                                       strArr_Free[0].Trim().ToUpper() != "THERMAL")//New condition on 28th Sep 2011 by Pradeep
                                                    {
                                                        if (!alstRSN.Contains(strArr_Free[0].Trim()))
                                                        {
                                                            alstRSN.Add(strArr_Free[0].Trim());
                                                        }
                                                        else
                                                        {
                                                            blStatus = true;
                                                            strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Duplicate RSN FreeText '" + strArr_Free[0].Trim() + "' in the " + strStageName;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg.Trim();
            return blStatus;
        }

        #region Solvent - Boiling Point Validation methods - New validation as on 22nd March 2011

        private bool CheckForSolventBoilingPointRangeValidation(out string _errmsg)
        {
            bool blStatus = true;
            string strErrMsg_Out = "";
            try
            {
                //Check if Reflux (x) is there Conditions. If Reflux is there, no need to check Boiling point
                if (!CheckForRefluxInAllStagesConditions())
                {  
                    //if (CheckForSingleSolventInStage(out strErrMsg))//Check for single solvent in the Stage
                    //{
                    //    blStatus = false;                        
                    //}

                    if (tcStages.TabPages.Count > 0)
                    {
                        ucParticipants ucPartpnt = null;
                        DataTable dtSolvTbl = null;
                        DataTable dtRSNTbl = null;
                        DataTable dtCondsTbl = null;

                        int intRegNo = 0;
                        string strStageName = "";
                        string strSolvent = "";
                        string strErrMsg = "";
                        string strStageIndx = "";

                        bool blIsThermal = false;
                        double bpCelc = 0.0;
                        double bpKelvin = 0.0;
                        double bpFHeit = 0.0;
                        double bpRankin = 0.0;

                        foreach (TabPage tp in tcStages.TabPages)
                        {
                            ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                            if (ucPartpnt != null)
                            {
                                strStageName = ucPartpnt.StageName;
                                strStageIndx = GetStageIndexFromStageName(strStageName);

                                dtSolvTbl = ucPartpnt.dtSolvent != null ? ucPartpnt.dtSolvent.Copy() : null;
                                dtRSNTbl = ucPartpnt.dtRSN != null ? ucPartpnt.dtRSN.Copy() : null;
                                dtCondsTbl = ucPartpnt.dtConditions != null ? ucPartpnt.dtConditions.Copy() : null;

                                if (dtSolvTbl != null && dtCondsTbl != null && dtRSNTbl != null)
                                {
                                    if (dtSolvTbl.Rows.Count == 1)
                                    {
                                        int.TryParse(dtSolvTbl.Rows[0]["REG_NO"].ToString(), out intRegNo);
                                        if (intRegNo > 0)
                                        {
                                            //Check of Thermal in RSN table                                           
                                            blIsThermal = CheckForThermalInAllStagesRSNTablesOnStage(dtRSNTbl, strStageIndx);

                                            if (blIsThermal && (dtCondsTbl.Rows.Count == 0))
                                            {
                                                blStatus = false;
                                                strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + "If 'thermal', boiling point should be there for Solvent: ' " + strSolvent + " ' in the " + strStageName;
                                            }
                                            else if (dtCondsTbl.Rows.Count > 0)
                                            {
                                                //Get Solvent Boiling Point in Celc, Kelvin,Fahrenheit and Rankine
                                                strSolvent = GetSolventBoilingPointsOnNrnReg(intRegNo, out bpCelc, out bpKelvin, out bpFHeit, out bpRankin);

                                                if (!string.IsNullOrEmpty(strSolvent.Trim()))
                                                {
                                                    if (!CheckSolventBPointInConditionsTable(dtCondsTbl, blIsThermal, bpCelc, bpKelvin, bpFHeit, bpRankin, strSolvent, strStageName, out strErrMsg))
                                                    {
                                                        blStatus = false;
                                                        strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + strErrMsg.Trim();
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }               
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg_Out.Trim();
            return blStatus;
        }

        private bool CheckForRefluxInAllStagesConditions()
        {
            bool blStatus = false;
            try
            {
                if (tcStages.TabPages.Count > 0)
                {
                    ucParticipants ucPartpnt = null;
                    DataTable dtCondsTbl = null;

                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            dtCondsTbl = ucPartpnt.dtConditions;
                            if (dtCondsTbl != null && dtCondsTbl.Rows.Count > 0)
                            {
                                for (int i = 0; i < dtCondsTbl.Rows.Count; i++)
                                {
                                    if (dtCondsTbl.Rows[i]["TEMPERATURE"].ToString() == "x") //Reflux (x)
                                    {
                                        blStatus = true;
                                        return blStatus;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        #region Method Not using
        //private bool CheckForSingleSolventInReaction(out string _errmsg_out)
        //{
        //    bool blStatus = false;
        //    string strErrMsg_Out = "";
        //    try
        //    {

        //        if (tbStages.TabPages.Count > 0)
        //        {
        //            ucParticipants ucPartpnt = null;
        //            DataTable dtSolvTbl = null;
        //            ArrayList alstNrnReg = new ArrayList();
        //            int intRegNo = 0;

        //            foreach (TabPage tp in tbStages.TabPages)
        //            {
        //                ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
        //                if (ucPartpnt != null)
        //                {
        //                    dtSolvTbl = ucPartpnt.dtSolvent;
        //                    if (dtSolvTbl != null)
        //                    {
        //                        if (dtSolvTbl.Rows.Count == 1)
        //                        {
        //                            int.TryParse(dtSolvTbl.Rows[0]["nrnreg"].ToString().Trim(), out intRegNo);
        //                            if (intRegNo > 0)
        //                            {
        //                                if (!alstNrnReg.Contains(intRegNo))
        //                                {
        //                                    alstNrnReg.Add(intRegNo);
        //                                }
        //                            }
        //                        }
        //                    }
        //                }
        //            }

        //            if (alstNrnReg != null)
        //            {
        //                if (alstNrnReg.Count == 1)
        //                {
        //                    string solv_NrnReg = alstNrnReg[0].ToString();
        //                    DataTable dtRSNTbl = null;
        //                    DataTable dtCondsTbl = null;

        //                    string strSolvent = "";
        //                    bool blIsThermal = false;
        //                    string strErrMsg = "";
        //                    double dblBPoint = 0.0;
        //                    string strStageName = "";

        //                    foreach (TabPage tp in tbStages.TabPages)
        //                    {
        //                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
        //                        if (ucPartpnt != null)
        //                        {
        //                            strStageName = ucPartpnt.StageName;

        //                            dtRSNTbl = ucPartpnt.dtRSN;
        //                            dtCondsTbl = ucPartpnt.dtConditions;

        //                            if (dtRSNTbl != null)
        //                            {
        //                                blIsThermal = CheckForThermalInRSNTable(dtRSNTbl);

        //                                int.TryParse(solv_NrnReg, out intRegNo);
        //                                if (intRegNo > 0)
        //                                {
        //                                    strSolvent = GetSolvent_BPoint_On_NrnReg(intRegNo, out dblBPoint);
        //                                    if (strSolvent.Trim() != "")
        //                                    {
        //                                        if (!CheckSolventBPoint_In_CondsTable(dtCondsTbl, blIsThermal, dblBPoint, strSolvent, strStageName, out strErrMsg))
        //                                        {
        //                                            blStatus = true;
        //                                            if (strErrMsg_Out.Trim() == "")
        //                                            {
        //                                                strErrMsg_Out = strErrMsg;
        //                                            }
        //                                            else
        //                                            {
        //                                                strErrMsg_Out = strErrMsg_Out + "\r\n" + strErrMsg;
        //                                            }
        //                                        }
        //                                    }
        //                                }
        //                            }
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    _errmsg_out = strErrMsg_Out;
        //    return blStatus;
        //} 
        #endregion

        #region Method Not using - Sealed_MW_AutoClaveInRSN
        //private bool CheckForSealed_MW_AutoClaveInRSN(DataTable _rsntbl)
        //{
        //    bool blStatus = false;
        //    try
        //    {
        //        if (_rsntbl != null)
        //        {
        //            if (_rsntbl.Rows.Count > 0)
        //            {
        //                for (int i = 0; i < _rsntbl.Rows.Count; i++)
        //                {
        //                    if (_rsntbl.Rows[i]["rsn_cvt"].ToString().Trim().Contains("microwave"))
        //                    {
        //                        blStatus = true;
        //                        return blStatus;
        //                    }
        //                    else if (_rsntbl.Rows[i]["rsn_free_text"].ToString().Trim().Contains("sealed")
        //                          || _rsntbl.Rows[i]["rsn_free_text"].ToString().Trim().Contains("microwave")
        //                          || _rsntbl.Rows[i]["rsn_free_text"].ToString().Trim().Contains("autoclave"))
        //                    {
        //                        blStatus = true;
        //                        return blStatus;
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return blStatus;
        //} 
        #endregion

        #region UnUsed Method
        //private bool CheckForSingleSolventInStage(out string _errmsg_out)
        //{
        //    bool blStatus = false;           
        //    string strErrMsg_Out = "";

        //    try
        //    {
        //        if (tbStages.TabPages.Count > 0)
        //        {                    
        //            ucParticipants ucPartpnt = null;
        //            DataTable dtSolvTbl = null;
        //            DataTable dtRSNTbl = null;
        //            DataTable dtCondsTbl = null;

        //            int intRegNo = 0;
        //            string strStageName = "";
        //            string strSolvent = "";
        //            string strErrMsg = "";

        //            bool blIsThermal = false;
        //            double bpCelc = 0.0;
        //            double bpKelvin = 0.0;
        //            double bpFHeit = 0.0;
        //            double bpRankin = 0.0;                    

        //            foreach (TabPage tp in tbStages.TabPages)
        //            {
        //                ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
        //                if (ucPartpnt != null)
        //                {
        //                    strStageName = ucPartpnt.StageName;

        //                    dtSolvTbl = ucPartpnt.dtSolvent;
        //                    dtRSNTbl = ucPartpnt.dtRSN;
        //                    dtCondsTbl = ucPartpnt.dtConditions;

        //                    if (dtSolvTbl != null && dtCondsTbl != null && dtRSNTbl != null)
        //                    {
        //                        if (dtSolvTbl.Rows.Count == 1)
        //                        {
        //                            int.TryParse(dtSolvTbl.Rows[0]["nrnreg"].ToString(), out intRegNo);
        //                            if (intRegNo > 0)
        //                            {
        //                                //Check Thermal is there or not in RSN table                                           
        //                                blIsThermal = CheckForThermalInAllStagesRSNTablesOnStage(dtRSNTbl, strStageName);

        //                                if (blIsThermal && (dtCondsTbl.Rows.Count == 0))
        //                                {
        //                                    blStatus = false;                                            
        //                                    strErrMsg_Out = strErrMsg_Out.Trim() + "\r\n" + "If 'thermal', boiling point should be there for Solvent: ' " + strSolvent + " ' in the " + strStageName;                                             
        //                                }
        //                                else if (dtCondsTbl.Rows.Count > 0)
        //                                {
        //                                    //Get Solvent Boiling Point in Celc, Kelvin,Fahrenheit and Rankine
        //                                    strSolvent = GetSolventBoilingPointsOnNrnReg(intRegNo, out bpCelc, out bpKelvin, out bpFHeit, out bpRankin);

        //                                    if (!string.IsNullOrEmpty(strSolvent.Trim()))
        //                                    {
        //                                        if (!CheckSolventBPointInConditionsTable(dtCondsTbl, blIsThermal, bpCelc, bpKelvin, bpFHeit, bpRankin, strSolvent, strStageName, out strErrMsg))
        //                                        {
        //                                            blStatus = true;
        //                                            strErrMsg_Out = strErrMsg_Out.Trim() + "\r\n" + strErrMsg.Trim();
        //                                        }
        //                                    }                                          
        //                                }                                       
        //                            }
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    _errmsg_out = strErrMsg_Out;
        //    return blStatus;
        //} 
        #endregion
       
        private string GetSolventBoilingPointsOnNrnReg(int regNo, out double _bp_celc, out double _bp_kelvin, out double _bp_fheit, out double _bp_rankin)
        {
            string strSolvent = "";
            double bpCelcs = 0.0;
            double bpKelvin = 0.0;
            double bpFHeit = 0.0;
            double bpRankin = 0.0;
            try
            {
                if (GlobalVariables.Solvent_BPoints != null)
                {
                    if (GlobalVariables.Solvent_BPoints.Rows.Count > 0)
                    {
                        DataRow[] drArr = GlobalVariables.Solvent_BPoints.Select("REG_NO = " + regNo);
                        if (drArr != null)
                        {
                            if (drArr.Length > 0)
                            {
                                strSolvent = drArr[0]["SOLVENT"].ToString();
                                double.TryParse(drArr[0]["UNIT_CELSIUS"].ToString(), out bpCelcs);
                                double.TryParse(drArr[0]["UNIT_KELVIN"].ToString(), out bpKelvin);
                                double.TryParse(drArr[0]["UNIT_FAHRENHEIT"].ToString(), out bpFHeit);
                                double.TryParse(drArr[0]["UNIT_RANKINE"].ToString(), out bpRankin);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _bp_celc = bpCelcs;
            _bp_kelvin = bpKelvin;
            _bp_fheit = bpFHeit;
            _bp_rankin = bpRankin;
            return strSolvent;
        }

        private bool CheckSolventBPointInConditionsTable(DataTable _dtconds, bool _isthermal, double solv_bp_c, double solv_bp_k, double solv_bp_fh, double solv_bp_r, string _solvent, string _stagename, out string _errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg_Out = "";
            try
            {
                string strErrMsg = "";

                double conds_MaxT_C = 0.0;
                double conds_MaxT_K = 0.0;
                double conds_MaxT_FH = 0.0;
                double conds_MaxT_R = 0.0;

                conds_MaxT_C = GetMaxTemperatureFromCondsTable(_dtconds, out conds_MaxT_K, out conds_MaxT_FH, out conds_MaxT_R);//Get Max in Kelvin,Fahrenheit,Rankine

                if (!CompareTemp_BPointAndThermal(conds_MaxT_C, conds_MaxT_K, conds_MaxT_FH, conds_MaxT_R, solv_bp_c, solv_bp_k, solv_bp_fh, solv_bp_r, _isthermal, _solvent, _stagename, out strErrMsg))
                {
                    blStatus = false;
                    strErrMsg_Out = strErrMsg_Out.Trim() + Environment.NewLine + strErrMsg.Trim();
                }

                #region Code commented on 26th May 2011
                //for (int i = 0; i < _dtconds.Rows.Count; i++)
                //{
                //    strTemp = _dtconds.Rows[i]["temperature"].ToString();
                //    if (!String.IsNullOrEmpty(strTemp))
                //    {
                //        //if Temperature is in f/k/r then no need to check this validation - modification on 19th May 2011
                //        if (!(strTemp.Contains("f") || strTemp.Contains("k") || strTemp.Contains("r")))
                //        {
                //            strTemp_Type = _dtconds.Rows[i]["temp_type"].ToString();

                //            if (strTemp_Type.Trim().ToUpper() == "REGULAR" || strTemp_Type.Trim().ToUpper() == "")
                //            {
                //                strTemp = GetTemperatureAndUnitsFromString(strTemp, out strT_Units);

                //                if (strTemp.Trim() != "")
                //                {
                //                    if (!CompareTemp_BPointAndThermal(strTemp.Trim(), _bpoint, _isthermal, _solvent, _stagename, out strErrMsg))
                //                    {
                //                        blStatus = false;
                //                        if (strErrMsg_Out.Trim() == "")
                //                        {
                //                            strErrMsg_Out = strErrMsg;
                //                        }
                //                        else
                //                        {
                //                            strErrMsg_Out = strErrMsg_Out + "\r\n" + strErrMsg;
                //                        }
                //                    }
                //                }
                //            }
                //            else if (strTemp_Type.Trim().ToUpper() == "RANGE")
                //            {
                //                string strRngFrom = "";
                //                string strRngTo = "";
                //                strRngFrom = GetRangeValuesFromString(strTemp, out strRngTo);

                //                string strTPUnits = "";
                //                string strTemp_From = GetTemperatureAndUnitsFromString(strRngFrom, out strTPUnits);
                //                string strTemp_To = GetTemperatureAndUnitsFromString(strRngTo, out strTPUnits);

                //                if (strTemp_From.Trim() != "")
                //                {
                //                    if (!CompareTemp_BPointAndThermal(strTemp_From.Trim(), _bpoint, _isthermal, _solvent, _stagename, out strErrMsg))
                //                    {
                //                        blStatus = false;
                //                        if (strErrMsg_Out.Trim() == "")
                //                        {
                //                            strErrMsg_Out = strErrMsg;
                //                        }
                //                        else
                //                        {
                //                            strErrMsg_Out = strErrMsg_Out + "\r\n" + strErrMsg;
                //                        }
                //                    }
                //                }
                //                if (!blStatus)
                //                {
                //                    if (strTemp_To.Trim() != "")
                //                    {
                //                        if (!CompareTemp_BPointAndThermal(strTemp_To.Trim(), _bpoint, _isthermal, _solvent, _stagename, out strErrMsg))
                //                        {
                //                            blStatus = false;
                //                            if (strErrMsg_Out.Trim() == "")
                //                            {
                //                                strErrMsg_Out = strErrMsg;
                //                            }
                //                            else
                //                            {
                //                                strErrMsg_Out = strErrMsg_Out + "\r\n" + strErrMsg;
                //                            }
                //                        }                                                
                //                    }
                //                }
                //            }
                //            else if (strTemp_Type.Trim().ToUpper() == "DIRECTIONAL")
                //            {
                //                string[] splitter = { "]" };
                //                string[] strTVals = strTemp.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                //                if (strTVals != null)
                //                {
                //                    if (strTVals.Length > 0)
                //                    {
                //                        string strTPUnits = "";
                //                        string strTemp_From = GetTemperatureAndUnitsFromString(strTVals[0], out strTPUnits);
                //                        string strTemp_To = GetTemperatureAndUnitsFromString(strTVals[1], out strTPUnits);

                //                        if (strTemp_From.Trim() != "")
                //                        {
                //                            if (!CompareTemp_BPointAndThermal(strTemp_From.Trim(), _bpoint, _isthermal, _solvent, _stagename, out strErrMsg))
                //                            {
                //                                blStatus = false;
                //                                if (strErrMsg_Out.Trim() == "")
                //                                {
                //                                    strErrMsg_Out = strErrMsg;
                //                                }
                //                                else
                //                                {
                //                                    strErrMsg_Out = strErrMsg_Out + "\r\n" + strErrMsg;
                //                                }
                //                            }
                //                        }
                //                        if (!blStatus)
                //                        {
                //                            if (strTemp_To.Trim() != "")
                //                            {
                //                                if (!CompareTemp_BPointAndThermal(strTemp_To.Trim(), _bpoint, _isthermal, _solvent, _stagename, out strErrMsg))
                //                                {
                //                                    blStatus = false;
                //                                    if (strErrMsg_Out.Trim() == "")
                //                                    {
                //                                        strErrMsg_Out = strErrMsg;
                //                                    }
                //                                    else
                //                                    {
                //                                        strErrMsg_Out = strErrMsg_Out + "\r\n" + strErrMsg;
                //                                    }
                //                                }                                                        
                //                            }
                //                        }
                //                    }
                //                }
                //            }
                //            else if (strTemp_Type.Trim().ToUpper() == "PLUS_MINUS")
                //            {
                //                string[] splitter = { "+/-" };
                //                string[] strVals = strTemp.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                //                if (strVals != null)
                //                {
                //                    if (strVals.Length > 0)
                //                    {
                //                        string strTPUnits = "";
                //                        string strTemp_From = GetTemperatureAndUnitsFromString(strVals[0], out strTPUnits);
                //                        string strTemp_To = GetTemperatureAndUnitsFromString(strVals[1], out strTPUnits);

                //                        if (strTemp_From.Trim() != "")
                //                        {
                //                            if (!CompareTemp_BPointAndThermal(strTemp_From.Trim(), _bpoint, _isthermal, _solvent, _stagename, out strErrMsg))
                //                            {
                //                                blStatus = false;
                //                                if (strErrMsg_Out.Trim() == "")
                //                                {
                //                                    strErrMsg_Out = strErrMsg;
                //                                }
                //                                else
                //                                {
                //                                    strErrMsg_Out = strErrMsg_Out + "\r\n" + strErrMsg;
                //                                }
                //                            }
                //                        }
                //                        if (!blStatus)
                //                        {
                //                            if (strTemp_To.Trim() != "")
                //                            {
                //                                if (!CompareTemp_BPointAndThermal(strTemp_To.Trim(), _bpoint, _isthermal, _solvent, _stagename, out strErrMsg))
                //                                {
                //                                    blStatus = false;
                //                                    if (strErrMsg_Out.Trim() == "")
                //                                    {
                //                                        strErrMsg_Out = strErrMsg;
                //                                    }
                //                                    else
                //                                    {
                //                                        strErrMsg_Out = strErrMsg_Out + "\r\n" + strErrMsg;
                //                                    }
                //                                }
                //                            }
                //                        }
                //                    }
                //                }
                //            }
                //        }
                //    }
                //} 
                #endregion                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg_out = strErrMsg_Out;
            return blStatus;
        }

        private bool CheckIf_F_K_R_UsedInConditions(DataTable _condstbl)
        {
            bool blStatus = false;
            try
            {
                if (_condstbl != null)
                {
                    if (_condstbl.Rows.Count > 0)
                    {
                        string strTemp = "";
                        for (int i = 0; i < _condstbl.Rows.Count; i++)
                        {
                            strTemp = _condstbl.Rows[i]["temperature"].ToString();
                            if (!String.IsNullOrEmpty(strTemp))
                            {
                                //if Temperature is in f/k/r then no need to check this validation - modification on 17th June 2011
                                if ((strTemp.Contains("f") || strTemp.Contains("k") || strTemp.Contains("r")))
                                {
                                    blStatus = true;
                                    return blStatus;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private double GetMaxTemperatureFromCondsTable(DataTable _condstbl, out double _maxt_kelvin, out double _maxt_fheit, out double _maxt_rankin)
        {
            double maxT_Celc = 0.0;
            double maxT_Kelvin = 0.0;
            double maxT_FHeit = 0.0;
            double maxT_Rankin = 0.0;
            try
            {
                if (_condstbl != null)
                {
                    if (_condstbl.Rows.Count > 0)
                    {
                        string strTemp = "";
                        string strTemp_Type = "";
                        string strT_Units = "";
                        double dblTemp = 0.0;

                        string strRngFrom = "";
                        string strRngTo = "";
                       
                        string strTemp_From = "";
                        string strTemp_To = "";

                        string[] strTVals = null;
                        string[] spl_PM = { "+/-" };
                        string[] spl_D = { "]" };

                        for (int i = 0; i < _condstbl.Rows.Count; i++)
                        {
                            strTemp = _condstbl.Rows[i]["temperature"].ToString();
                            if (!String.IsNullOrEmpty(strTemp))
                            {
                                strTemp_Type = _condstbl.Rows[i]["temp_type"].ToString();

                                if (strTemp_Type.Trim().ToUpper() == "REGULAR" || strTemp_Type.Trim().ToUpper() == "")
                                {
                                    strTemp = GetTemperatureAndUnitsFromString(strTemp, out strT_Units);
                                    if (strTemp.Trim() != "")
                                    {
                                        switch(strT_Units.Trim().ToUpper())
                                        {
                                            case "C":
                                                double.TryParse(strTemp.Trim(), out dblTemp);
                                                if (dblTemp > 0 && (dblTemp > maxT_Celc))
                                                {
                                                    maxT_Celc = dblTemp;
                                                }
                                                break;
                                            case "F":                                           
                                                double.TryParse(strTemp.Trim(), out dblTemp);
                                                if (dblTemp > 0 && (dblTemp > maxT_FHeit))
                                                {
                                                    maxT_FHeit = dblTemp;
                                                }
                                                break;
                                            case "K":                                           
                                                double.TryParse(strTemp.Trim(), out dblTemp);
                                                if (dblTemp > 0 && (dblTemp > maxT_Kelvin))
                                                {
                                                    maxT_Kelvin = dblTemp;
                                                }
                                                break;
                                            case "R":                                           
                                                 double.TryParse(strTemp.Trim(), out dblTemp);
                                                if (dblTemp > 0 && (dblTemp > maxT_Rankin))
                                                {
                                                    maxT_Rankin = dblTemp;
                                                }
                                                break;
                                        }                             
                                    }
                                }
                                else if (strTemp_Type.Trim().ToUpper() == "RANGE" || strTemp_Type.Trim().ToUpper() == "DIRECTIONAL" || strTemp_Type.Trim().ToUpper() == "PLUS_MINUS")
                                {
                                    if (strTemp_Type.Trim().ToUpper() == "RANGE")
                                    {
                                        strRngFrom = "";
                                        strRngTo = "";
                                        strRngFrom = GetRangeValuesFromString(strTemp, out strRngTo);

                                        strT_Units = "";
                                        strTemp_From = GetTemperatureAndUnitsFromString(strRngFrom, out strT_Units);
                                        strTemp_To = GetTemperatureAndUnitsFromString(strRngTo, out strT_Units);
                                    }
                                    else if (strTemp_Type.Trim().ToUpper() == "DIRECTIONAL")
                                    {
                                        strTVals = null;
                                        strTVals = strTemp.Split(spl_D, StringSplitOptions.RemoveEmptyEntries);
                                        if (strTVals != null)
                                        {
                                            if (strTVals.Length > 0)
                                            {
                                                strT_Units = "";
                                                strTemp_From = GetTemperatureAndUnitsFromString(strTVals[0], out strT_Units);
                                                strTemp_To = GetTemperatureAndUnitsFromString(strTVals[1], out strT_Units);
                                            }
                                        }
                                    }
                                    else if (strTemp_Type.Trim().ToUpper() == "PLUS_MINUS")
                                    {
                                        strTVals = null;
                                        strTVals = strTemp.Split(spl_PM, StringSplitOptions.RemoveEmptyEntries);
                                        if (strTVals != null)
                                        {
                                            if (strTVals.Length > 0)
                                            {
                                                strT_Units = "";
                                                strTemp_From = GetTemperatureAndUnitsFromString(strTVals[0], out strT_Units);
                                                strTemp_To = GetTemperatureAndUnitsFromString(strTVals[1], out strT_Units);
                                            }
                                        }
                                    }                                   

                                    switch (strT_Units.Trim().ToUpper())
                                    {
                                        case "C":

                                            double.TryParse(strTemp_From.Trim(), out dblTemp);
                                            if (dblTemp > 0 && (dblTemp > maxT_Celc))
                                            {
                                                maxT_Celc = dblTemp;
                                            }
                                            double.TryParse(strTemp_To.Trim(), out dblTemp);
                                            if (dblTemp > 0 && (dblTemp > maxT_Celc))
                                            {
                                                maxT_Celc = dblTemp;
                                            }
                                            break;
                                        case "K":

                                            double.TryParse(strTemp_From.Trim(), out dblTemp);
                                            if (dblTemp > 0 && (dblTemp > maxT_Kelvin))
                                            {
                                                maxT_Kelvin = dblTemp;
                                            }

                                            double.TryParse(strTemp_To.Trim(), out dblTemp);
                                            if (dblTemp > 0 && (dblTemp > maxT_Kelvin))
                                            {
                                                maxT_Kelvin = dblTemp;
                                            }
                                            break;
                                        case "F":

                                            double.TryParse(strTemp_From.Trim(), out dblTemp);
                                            if (dblTemp > 0 && (dblTemp > maxT_FHeit))
                                            {
                                                maxT_FHeit = dblTemp;
                                            }
                                            double.TryParse(strTemp_To.Trim(), out dblTemp);
                                            if (dblTemp > 0 && (dblTemp > maxT_FHeit))
                                            {
                                                maxT_FHeit = dblTemp;
                                            }
                                            break;

                                        case "R":

                                            double.TryParse(strTemp_From.Trim(), out dblTemp);
                                            if (dblTemp > 0 && (dblTemp > maxT_Rankin))
                                            {
                                                maxT_Rankin = dblTemp;
                                            }
                                            double.TryParse(strTemp_To.Trim(), out dblTemp);
                                            if (dblTemp > 0 && (dblTemp > maxT_Rankin))
                                            {
                                                maxT_Rankin = dblTemp;
                                            }
                                            break;
                                    }                                    
                                }
                                #region Code commented
                                //else if (strTemp_Type.Trim().ToUpper() == "DIRECTIONAL")
                                //{
                                //    strTVals = null;
                                //    strTVals = strTemp.Split(spl_D, StringSplitOptions.RemoveEmptyEntries);
                                //    if (strTVals != null)
                                //    {
                                //        if (strTVals.Length > 0)
                                //        {
                                //            strTPUnits = "";
                                //            strTemp_From = GetTemperatureAndUnitsFromString(strTVals[0], out strTPUnits);
                                //            strTemp_To = GetTemperatureAndUnitsFromString(strTVals[1], out strTPUnits);

                                //            switch (strT_Units.Trim().ToUpper())
                                //            {
                                //                case "C":

                                //                    double.TryParse(strTemp_From.Trim(), out dblTemp);
                                //                    if (dblTemp > 0 && (dblTemp > maxT_Celc))
                                //                    {
                                //                        maxT_Celc = dblTemp;
                                //                    }
                                //                    double.TryParse(strTemp_To.Trim(), out dblTemp);
                                //                    if (dblTemp > 0 && (dblTemp > maxT_Celc))
                                //                    {
                                //                        maxT_Celc = dblTemp;
                                //                    }
                                //                    break;
                                //                case "K":

                                //                    double.TryParse(strTemp_From.Trim(), out dblTemp);
                                //                    if (dblTemp > 0 && (dblTemp > maxT_Kelvin))
                                //                    {
                                //                        maxT_Kelvin = dblTemp;
                                //                    }

                                //                    double.TryParse(strTemp_To.Trim(), out dblTemp);
                                //                    if (dblTemp > 0 && (dblTemp > maxT_Kelvin))
                                //                    {
                                //                        maxT_Kelvin = dblTemp;
                                //                    }
                                //                    break;
                                //                case "F":

                                //                    double.TryParse(strTemp_From.Trim(), out dblTemp);
                                //                    if (dblTemp > 0 && (dblTemp > maxT_FHeit))
                                //                    {
                                //                        maxT_FHeit = dblTemp;
                                //                    }
                                //                    double.TryParse(strTemp_To.Trim(), out dblTemp);
                                //                    if (dblTemp > 0 && (dblTemp > maxT_FHeit))
                                //                    {
                                //                        maxT_FHeit = dblTemp;
                                //                    }
                                //                    break;

                                //                case "R":

                                //                    double.TryParse(strTemp_From.Trim(), out dblTemp);
                                //                    if (dblTemp > 0 && (dblTemp > maxT_Rankin))
                                //                    {
                                //                        maxT_Rankin = dblTemp;
                                //                    }
                                //                    double.TryParse(strTemp_To.Trim(), out dblTemp);
                                //                    if (dblTemp > 0 && (dblTemp > maxT_Rankin))
                                //                    {
                                //                        maxT_Rankin = dblTemp;
                                //                    }
                                //                    break;
                                //            }
                                //        }
                                //    }
                                //}
                                //else if (strTemp_Type.Trim().ToUpper() == "PLUS_MINUS")
                                //{
                                //    strTVals = null;
                                //    strTVals = strTemp.Split(spl_PM, StringSplitOptions.RemoveEmptyEntries);
                                //    if (strTVals != null)
                                //    {
                                //        if (strTVals.Length > 0)
                                //        {
                                //            strTPUnits = "";
                                //            strTemp_From = GetTemperatureAndUnitsFromString(strTVals[0], out strTPUnits);
                                //            strTemp_To = GetTemperatureAndUnitsFromString(strTVals[1], out strTPUnits);

                                //            switch (strT_Units.Trim().ToUpper())
                                //            {
                                //                case "C":

                                //                    double.TryParse(strTemp_From.Trim(), out dblTemp);
                                //                    if (dblTemp > 0 && (dblTemp > maxT_Celc))
                                //                    {
                                //                        maxT_Celc = dblTemp;
                                //                    }
                                //                    double.TryParse(strTemp_To.Trim(), out dblTemp);
                                //                    if (dblTemp > 0 && (dblTemp > maxT_Celc))
                                //                    {
                                //                        maxT_Celc = dblTemp;
                                //                    }
                                //                    break;
                                //                case "K":

                                //                    double.TryParse(strTemp_From.Trim(), out dblTemp);
                                //                    if (dblTemp > 0 && (dblTemp > maxT_Kelvin))
                                //                    {
                                //                        maxT_Kelvin = dblTemp;
                                //                    }

                                //                    double.TryParse(strTemp_To.Trim(), out dblTemp);
                                //                    if (dblTemp > 0 && (dblTemp > maxT_Kelvin))
                                //                    {
                                //                        maxT_Kelvin = dblTemp;
                                //                    }
                                //                    break;
                                //                case "F":

                                //                    double.TryParse(strTemp_From.Trim(), out dblTemp);
                                //                    if (dblTemp > 0 && (dblTemp > maxT_FHeit))
                                //                    {
                                //                        maxT_FHeit = dblTemp;
                                //                    }
                                //                    double.TryParse(strTemp_To.Trim(), out dblTemp);
                                //                    if (dblTemp > 0 && (dblTemp > maxT_FHeit))
                                //                    {
                                //                        maxT_FHeit = dblTemp;
                                //                    }
                                //                    break;

                                //                case "R":

                                //                    double.TryParse(strTemp_From.Trim(), out dblTemp);
                                //                    if (dblTemp > 0 && (dblTemp > maxT_Rankin))
                                //                    {
                                //                        maxT_Rankin = dblTemp;
                                //                    }
                                //                    double.TryParse(strTemp_To.Trim(), out dblTemp);
                                //                    if (dblTemp > 0 && (dblTemp > maxT_Rankin))
                                //                    {
                                //                        maxT_Rankin = dblTemp;
                                //                    }
                                //                    break;
                                //            }
                                //        }
                                //    }
                                //} 
                                #endregion
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _maxt_kelvin = maxT_Kelvin;
            _maxt_fheit = maxT_FHeit;
            _maxt_rankin = maxT_Rankin;
            return maxT_Celc;
        }

        private bool CompareTemp_BPointAndThermal(double conds_maxt_c, double conds_maxt_k, double conds_maxt_fh, double conds_maxt_r, double solv_bp_celc,double solv_bp_k,double solv_bp_fh,double solv_bp_r, bool is_thermal, string _solvent, string _stagename, out string _errmsg)
        {
            bool blStauts = true;
            string errorMsg = "";
            try
            {               
                double maxTemp_3 = 0.0;
                string maxType = "";

                double convTemp_C = conds_maxt_c;
                double convTemp_K = 0.0;
                double convTemp_FH = 0.0;
                double convTemp_R = 0.0;

                bool blThrmalStatus = false;

                //Convert Kelvin to Degrees  C = K - 273.15
                convTemp_K = conds_maxt_k - 273.15;

                //Convert Fahrenheit to Degrees   C = ( F - 32) / 1.8
                convTemp_FH = (conds_maxt_fh - 32) / 1.8;

                //Convert Rankine to Degrees   C = ( Ra - 32 - 459.67) / 1.8
                convTemp_R = (conds_maxt_r - 32 - 458.67) / 1.8;

                double[] dblTemps = { convTemp_C, convTemp_K, convTemp_FH, convTemp_R };
                string[] saTypes = { "C", "K", "FH", "R" };

                for (int i = 0; i < dblTemps.Length; i++)
                {
                    if (dblTemps[i] >= maxTemp_3)
                    {
                        maxTemp_3 = dblTemps[i];
                        maxType = saTypes[i].ToUpper();
                    }                   
                } 
                
                if (is_thermal)
                {
                    switch (maxType)
                    { 
                        case "C":
                            if (convTemp_C <= solv_bp_celc)
                            {
                                blStauts = false;
                                errorMsg = errorMsg.Trim() + Environment.NewLine + "Solvent '" + _solvent + "' Boiling Point is " + conds_maxt_c + "<= " + solv_bp_celc + " (deg C) in the " + _stagename;
                            }
                          break;

                        case "K":
                          if (convTemp_K <= solv_bp_celc)
                          {
                              blStauts = false;
                              errorMsg = errorMsg.Trim() + Environment.NewLine + "Solvent '" + _solvent + "' Boiling Point is " + conds_maxt_k + " <= " + solv_bp_k + " (Kelvin) in the " + _stagename;
                          }
                          break;

                        case "FH":
                          if (convTemp_FH <= solv_bp_celc)
                          {
                              blStauts = false;
                              errorMsg = errorMsg.Trim() + Environment.NewLine + "Solvent ' " + _solvent + " ' Boiling Point is " + conds_maxt_fh + " <= " + solv_bp_fh + " (Fahrenheit) in the " + _stagename;
                          }
                          break;

                        case "R":
                          if (convTemp_R <= solv_bp_celc)
                          {
                              blStauts = false;
                              errorMsg = errorMsg.Trim() + Environment.NewLine + "Solvent ' " + _solvent + " ' Boiling Point is " + conds_maxt_r + " <= " + solv_bp_r + " (Rankine) in the " + _stagename;
                          }
                          break;
                    }                  
                                        
                    #region Code Commented on 21 June 2011
                    //if (conds_maxt_c > 0)
                    //{
                    //    if (conds_maxt_c <= solv_bp_celc)
                    //    {
                    //        blStauts = false;
                    //        if (errorMsg.Trim() == "")
                    //        {
                    //            errorMsg = "Solvent '" + _solvent + "' Boiling Point is <= " + solv_bp_celc + " (deg C) in the " + _stagename;
                    //        }
                    //        else
                    //        {
                    //            errorMsg = errorMsg + "\r\n" + "Solvent ' " + _solvent + " ' Boiling Point is <= " + solv_bp_celc + " (deg C) in the " + _stagename;
                    //        }
                    //    }
                    //}
                    //if (conds_maxt_k > 0)
                    //{
                    //    if (conds_maxt_k <= solv_bp_k)
                    //    {
                    //        blStauts = false;
                    //        if (errorMsg.Trim() == "")
                    //        {
                    //            errorMsg = "Solvent '" + _solvent + "' Boiling Point is <= " + solv_bp_k + " (Kelvin) in the " + _stagename;
                    //        }
                    //        else
                    //        {
                    //            errorMsg = errorMsg + "\r\n" + "Solvent '" + _solvent + "' Boiling Point is <= " + solv_bp_k + " (Kelvin) in the " + _stagename;
                    //        }
                    //    }
                    //}
                    //if (conds_maxt_fh > 0)
                    //{
                    //    if (conds_maxt_fh <= solv_bp_fh)
                    //    {
                    //        blStauts = false;
                    //        if (errorMsg.Trim() == "")
                    //        {
                    //            errorMsg = "Solvent '" + _solvent + "' Boiling Point is <= " + solv_bp_fh + " (Fahrenheit) in the " + _stagename;
                    //        }
                    //        else
                    //        {
                    //            errorMsg = errorMsg + "\r\n" + "Solvent '" + _solvent + "' Boiling Point is <= " + solv_bp_fh + " (Fahrenheit) in the " + _stagename;
                    //        }
                    //    }
                    //}
                    //if (conds_maxt_r > 0)
                    //{
                    //    if (conds_maxt_r <= solv_bp_r)
                    //    {
                    //        blStauts = false;
                    //        if (errorMsg.Trim() == "")
                    //        {
                    //            errorMsg = "Solvent '" + _solvent + "' Boiling Point is <= " + solv_bp_r + " (Rankine) in the " + _stagename;
                    //        }
                    //        else
                    //        {
                    //            errorMsg = errorMsg + "\r\n" + "Solvent '" + _solvent + "' Boiling Point is <= " + solv_bp_r + " (Rankine) in the " + _stagename;
                    //        }
                    //    }
                    //} 
                    #endregion
                }
                else if (!is_thermal)
                {
                    switch (maxType)
                    { 
                        case "C":
                            if (convTemp_C > solv_bp_celc)
                            {
                                blThrmalStatus = false;
                                //New SolvoThermal/HYdroThermal Validation for Supervisor on 17th Nov 2011
                                if (GlobalVariables.RoleName.ToUpper() == RolesMaster.TOOL_MANAGER)
                                {
                                    DialogResult diaRes = MessageBox.Show("This could be 'Thermal' Reaction. Do you want to continue?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                                    if (diaRes == DialogResult.Yes)
                                    {
                                        blThrmalStatus = true;
                                    }
                                }

                                if (!blThrmalStatus)
                                {
                                    blStauts = false;
                                    errorMsg = errorMsg.Trim() + Environment.NewLine + "Solvent '" + _solvent + "' Boiling Point is " + conds_maxt_c + " > " + solv_bp_celc + " (deg C). RSN CVT/Free should be ' thermal ' in the " + _stagename;
                                }
                            }
                           break;

                        case "K":
                           if (convTemp_K > solv_bp_celc)
                           {
                               blThrmalStatus = false;
                               if (GlobalVariables.RoleName.ToUpper() == RolesMaster.TOOL_MANAGER)
                               {
                                   DialogResult diaRes = MessageBox.Show("This could be 'Thermal' Reaction. Do you want to continue?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                                   if (diaRes == DialogResult.Yes)
                                   {
                                       blThrmalStatus = true;
                                   }
                               }

                               if (!blThrmalStatus)
                               {
                                   blStauts = false;
                                   errorMsg = errorMsg.Trim() + Environment.NewLine + "Solvent '" + _solvent + "' Boiling Point is " + conds_maxt_k + " > " + solv_bp_k + " (Kelvin). RSN CVT/Free should be ' thermal ' in the " + _stagename;
                               }
                           }
                           break;

                        case "FH":
                           if (convTemp_FH > solv_bp_celc)
                           {
                               blThrmalStatus = false;
                               if (GlobalVariables.RoleName.ToUpper() == RolesMaster.TOOL_MANAGER)
                               {
                                   DialogResult diaRes = MessageBox.Show("This could be 'Thermal' Reaction. Do you want to continue?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                                   if (diaRes == DialogResult.Yes)
                                   {
                                       blThrmalStatus = true;
                                   }
                               }

                               if (!blThrmalStatus)
                               {
                                   blStauts = false;
                                   errorMsg = errorMsg.Trim() + Environment.NewLine + "Solvent '" + _solvent + "' Boiling Point is " + conds_maxt_fh + " > " + solv_bp_fh + " (Fahrenheit). RSN CVT/Free should be ' thermal ' in the " + _stagename;
                               }
                           }
                           break;

                        case "R":
                           if (convTemp_R > solv_bp_celc)
                           {
                               blThrmalStatus = false;
                               if (GlobalVariables.RoleName.ToUpper() == RolesMaster.TOOL_MANAGER)
                               {
                                   DialogResult diaRes = MessageBox.Show("This could be 'Thermal' Reaction. Do you want to continue?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                                   if (diaRes == DialogResult.Yes)
                                   {
                                       blThrmalStatus = true;
                                   }
                               }

                               if (!blThrmalStatus)
                               {
                                   blStauts = false;
                                   errorMsg = errorMsg.Trim() + Environment.NewLine + "Solvent '" + _solvent + "' Boiling Point is " + conds_maxt_r + " > " + solv_bp_r + " (Rankine). RSN CVT/Free should be ' thermal ' in the " + _stagename;
                               }
                           }
                           break;
                    }                  
                    #region Code Commented on 21June 2011
                    //if (conds_maxt_c > 0)
                    //{
                    //    if (conds_maxt_c > solv_bp_celc)
                    //    {
                    //        blStauts = false;
                    //        if (errorMsg.Trim() == "")
                    //        {
                    //            errorMsg = "Solvent '" + _solvent + "' Boiling Point is > " + solv_bp_celc + " (deg C). RSN CVT/Free should be ' thermal ' in the " + _stagename;
                    //        }
                    //        else
                    //        {
                    //            errorMsg = errorMsg + "\r\n" + "Solvent '" + _solvent + "' Boiling Point is > " + solv_bp_celc + " (deg C). RSN CVT/Free should be ' thermal ' in the " + _stagename;
                    //        }
                    //    }
                    //}
                    //if (conds_maxt_k > 0)
                    //{
                    //    if (conds_maxt_k > solv_bp_k)
                    //    {
                    //        blStauts = false;
                    //        if (errorMsg.Trim() == "")
                    //        {
                    //            errorMsg = "Solvent '" + _solvent + "' Boiling Point is > " + solv_bp_k + " (Kelvin). RSN CVT/Free should be ' thermal ' in the " + _stagename;
                    //        }
                    //        else
                    //        {
                    //            errorMsg = errorMsg + "\r\n" + "Solvent '" + _solvent + "' Boiling Point is > " + solv_bp_k + " (Kelvin). RSN CVT/Free should be ' thermal ' in the " + _stagename;
                    //        }
                    //    }
                    //}
                    //if (conds_maxt_fh > 0)
                    //{
                    //    if (conds_maxt_fh > solv_bp_fh)
                    //    {
                    //        blStauts = false;
                    //        if (errorMsg.Trim() == "")
                    //        {
                    //            errorMsg = "Solvent '" + _solvent + "' Boiling Point is > " + solv_bp_fh + " (Fahrenheit). RSN CVT/Free should be ' thermal ' in the " + _stagename;
                    //        }
                    //        else
                    //        {
                    //            errorMsg = errorMsg + "\r\n" + "Solvent '" + _solvent + "' Boiling Point is > " + solv_bp_fh + " (Fahrenheit). RSN CVT/Free should be ' thermal ' in the " + _stagename;
                    //        }
                    //    }
                    //}
                    //if (conds_maxt_r > 0)
                    //{
                    //    if (conds_maxt_r > solv_bp_r)
                    //    {
                    //        blStauts = false;
                    //        if (errorMsg.Trim() == "")
                    //        {
                    //            errorMsg = "Solvent '" + _solvent + "' Boiling Point is > " + solv_bp_r + " (Rankine). RSN CVT/Free should be ' thermal ' in the " + _stagename;
                    //        }
                    //        else
                    //        {
                    //            errorMsg = errorMsg + "\r\n" + "Solvent '" + _solvent + "' Boiling Point is > " + solv_bp_r + " (Rankine). RSN CVT/Free should be ' thermal ' in the " + _stagename;
                    //        }
                    //    }
                    //} 
                    #endregion
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = errorMsg.Trim();
            return blStauts;
        }

        private string GetTemperatureAndUnitsFromString(string _temp, out string _temp_units)
        {
            string strTemp = _temp;
            string strTempUnits = "c";
            try
            {
                strTempUnits = GetTempUnitsFromString(_temp);

                string[] splitter = { "f", "k", "r" };
                string[] strTempVals = strTemp.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                if (strTempVals != null)
                {
                    if (strTempVals.Length > 0)
                    {
                        strTemp = strTempVals[0];
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _temp_units = strTempUnits;
            return strTemp;
        }

        private string GetTempUnitsFromString(string _temp)
        {
            string strTPUnits = "c";
            try
            {
                if (_temp.Trim() != "")
                {
                    if (_temp.Trim().EndsWith("f"))
                    {
                        strTPUnits = "f";
                    }
                    else if (_temp.Trim().EndsWith("k"))
                    {
                        strTPUnits = "k";
                    }
                    else if (_temp.Trim().EndsWith("r"))
                    {
                        strTPUnits = "r";
                    }
                    return strTPUnits;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strTPUnits;
        }

        private bool CheckForThermalInAllStagesRSNTablesOnStage(DataTable rsntable,string stageindex)
        {
            bool blStatus = false;
            try
            {
                if (rsntable != null)
                {
                    if (rsntable.Rows.Count > 0)
                    {
                        string strFreeText = "";
                        for (int i = 0; i < rsntable.Rows.Count; i++)
                        {
                            if (rsntable.Rows[i]["CVT"].ToString().Trim().ToUpper().Contains("THERMAL"))
                            {
                                blStatus = true;
                                return blStatus;
                            }
                            else
                            {
                                strFreeText = "";
                                strFreeText = Regex.Replace(rsntable.Rows[i]["FREE_TEXT"].ToString().Trim(), @"\s+", " ");

                                if (strFreeText.ToUpper().Contains("THERMAL (STAGE") || strFreeText.ToUpper().Contains("THERMAL (STAGES"))
                                {
                                    blStatus = true;
                                    return blStatus;
                                }
                            }
                        }
                    }
                }
              
                if (tcStages.TabCount > 0)
                {
                    ucParticipants ucPartpnt = null;
                    DataTable dtRSN = null;
                    DataTable dtFT_StgInfo = null;                   
                    string[] saStages = null;

                    for (int i = 0; i < tcStages.TabPages.Count; i++)
                    {
                        ucPartpnt = (ucParticipants)tcStages.TabPages[i].Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            string strStageName = ucPartpnt.StageName;
                            string strStgIndx = GetStageIndexFromStageName(strStageName);

                            if (strStgIndx != stageindex)
                            {
                                dtRSN = ucPartpnt.dtRSN;
                                if (dtRSN != null)
                                {
                                    for (int j = 0; j < dtRSN.Rows.Count; j++)
                                    {
                                        if (!string.IsNullOrEmpty(dtRSN.Rows[j]["FREE_TEXT"].ToString()))
                                        {
                                            //Get Stage Info from FreeText
                                            dtFT_StgInfo = GetFreeText_StagesData(dtRSN.Rows[j]["FREE_TEXT"].ToString());

                                            //Check Stage and FreeText term in FreeText_Stages table
                                            blStatus = CheckFreeTextAndStageInTable(dtFT_StgInfo, "THERMAL", stageindex);
                                            if (blStatus)
                                            {
                                                return blStatus;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckFreeTextAndStageInTable(DataTable ft_stages, string freetext, string stageindx)
        {
            bool blStatus = false;
            try
            {
                if (ft_stages != null)
                {
                    string[] saStages = null;
                    for (int k = 0; k < ft_stages.Rows.Count; k++)
                    {
                        if (ft_stages.Rows[k][0].ToString().ToUpper() == freetext.ToUpper())
                        {
                            saStages = GetStageIndexesFromStageInfo(ft_stages.Rows[k][1].ToString());
                            if (saStages != null)
                            {
                                for (int m = 0; m < saStages.Length; m++)
                                {
                                    if (saStages[m].Trim() == stageindx)
                                    {
                                        blStatus = true;
                                        return blStatus;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private string[] GetStageIndexesFromStageInfo(string stageinfo)
        {
            string[] saStgIndexes = null;
            try
            {
                if (!string.IsNullOrEmpty(stageinfo))
                {
                    string[] splter = { "~" };
                    string strStgInfo = stageinfo.ToUpper().Trim().ToUpper().Replace("(STAGE ", "~");
                    strStgInfo = strStgInfo.ToUpper().Trim().Replace("(STAGES ", "~");
                    strStgInfo = strStgInfo.ToUpper().Trim().Replace("-", "~");
                    strStgInfo = strStgInfo.ToUpper().Trim().Replace(",", "~");
                    strStgInfo = strStgInfo.ToUpper().Trim().Replace(")", "~");
                    strStgInfo = strStgInfo.ToUpper().Trim().Replace("AND", "~");

                    saStgIndexes = strStgInfo.Trim().Split(splter, StringSplitOptions.RemoveEmptyEntries);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return saStgIndexes;
        }

        #endregion

        #region Yield - RSN Prophetic Validation Methods - New validation on 22nd March 2011

        private bool CheckForProphetic_YieldValidation(out string _errmsg)
        {
            bool blStatus = true;
            string ErrMsg = "";
            try
            {
                if (tcStages.TabPages.Count > 0)
                {
                    ucParticipants ucPartpnt = null;
                    DataTable dtRSNTbl = null;                   
                    bool blProphetic = false;

                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            dtRSNTbl = ucPartpnt.dtRSN != null ? ucPartpnt.dtRSN.Copy() : null;
                            blProphetic = CheckPropheticRxnInRSNTable(dtRSNTbl);
                            break;
                        }
                    }
                    if (blProphetic)
                    {
                        DataTable dtProduct = RxnProductsTbl != null ? RxnProductsTbl.Copy() : null;
                        if (CheckYieldInProductTable(dtProduct))
                        {
                            blStatus = false;
                            ErrMsg = "If ' Prophetic reaction ' Yield should not be there.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = ErrMsg;
            return blStatus;
        }

        private bool CheckPropheticRxnInRSNTable(DataTable _rsntbl)
        {
            bool blStatus = false;
            try
            {
                if (_rsntbl != null)
                {
                    if (_rsntbl.Rows.Count > 0)
                    {
                        DataRow[] drArr = _rsntbl.Select("FREE_TEXT = 'prophetic reaction'");
                        if (drArr != null)
                        {
                            if (drArr.Length > 0)
                            {
                                blStatus = true;
                                return blStatus;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckYieldInProductTable(DataTable _producttbl)
        {
            bool blStatus = false;
            try
            {
                if (_producttbl != null)
                {
                    if (_producttbl.Rows.Count > 0)
                    {
                        DataRow[] drArr = _producttbl.Select("yield <> ''");
                        if (drArr != null)
                        {
                            if (drArr.Length > 0)
                            {
                                blStatus = true;
                                return blStatus;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        #endregion

        #region Yield - Multiple products Yield ratio proportion validation - New validation on 20th March 2013
        
        //Multiple Products Yield ratio validation - New validation on 3rd April 2013
        private bool ValidateMultiProductYieldsRatio(out string _errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (RxnProductsTbl != null && RxnProductsTbl.Rows.Count > 0)
                {
                    DataTable dtProduct = RxnProductsTbl.Copy();

                    List<int> lstRatioVals = new List<int>();
                    List<int> lstLeftVals = new List<int>();
                    List<int> lstDistVals = new List<int>();
                    int intEmptyYldCnt = 0;

                    int intTempRatio = 0;
                    for (int i = 0; i < dtProduct.Rows.Count; i++)
                    {
                        if (!string.IsNullOrEmpty(dtProduct.Rows[i]["YIELD"].ToString()))
                        {
                            if (!dtProduct.Rows[i]["YIELD"].ToString().Trim().StartsWith(",") && !dtProduct.Rows[i]["YIELD"].ToString().Trim().EndsWith(","))
                            {
                                string[] splitter = { "," };
                                string[] saYieldVals = dtProduct.Rows[i]["YIELD"].ToString().Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                                if (saYieldVals != null && saYieldVals.Length == 2)
                                {
                                    int.TryParse(saYieldVals[0].Trim(), out intTempRatio);
                                    if (!lstLeftVals.Contains(intTempRatio))
                                    {
                                        lstLeftVals.Add(intTempRatio);
                                    }

                                    int.TryParse(saYieldVals[1].Trim(), out intTempRatio);
                                    lstRatioVals.Add(intTempRatio);
                                }
                            }
                            else
                            {
                                blStatus = false;
                                strErrMsg = strErrMsg.Trim() + "\r\n" + "In-valid Yield values.";
                            }
                        }
                        else
                        {
                            intEmptyYldCnt++;
                        }
                    }
                    //Check left side yield values are same   
                    if (lstLeftVals.Count > 1)
                    {
                        blStatus = false;
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Combined Yield values should be same.";
                    }

                    //Check Sum of Yield Ratio values are 100
                    if (lstRatioVals.Count > 0)
                    {
                        int intSumRaio = lstRatioVals.Sum();
                        if (intSumRaio != 100)
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim() + "\r\n" + "Sum of Yield ratio values should be 100.";
                        }
                        else if (!CheckAlmostEqualYieldRatiosAndRSNTerms(lstRatioVals, out strErrMsg))
                        {
                            blStatus = false;
                            strErrMsg = strErrMsg.Trim();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg_out = strErrMsg;
            return blStatus;
        }

        //New validation on 5th May 2013
        //50:50, 49:51, 48:52, 47:53, 46:54, if we use these yield ratio values in yield filed do not allow stereoselective or regioselecitve RSN CVT terms
        private bool CheckAlmostEqualYieldRatiosAndRSNTerms(List<int> ratiovals, out string errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                List<int> lst1 = new List<int>() { 50, 50 };
                List<int> lst2 = new List<int>() { 49, 51 };
                List<int> lst3 = new List<int>() { 48, 52 };
                List<int> lst4 = new List<int>() { 47, 53 };
                List<int> lst5 = new List<int>() { 46, 54 };

                if (ratiovals != null)
                {
                    List<int> lstRatioVals = ratiovals;
                    lstRatioVals.Sort();
                    if (lstRatioVals.SequenceEqual(lst1) || lstRatioVals.SequenceEqual(lst2) || lstRatioVals.SequenceEqual(lst3) || lstRatioVals.SequenceEqual(lst4) || lstRatioVals.SequenceEqual(lst5))
                    {
                        if (tcStages.TabPages.Count > 0)
                        {
                            ucParticipants ucPartpnt = null;
                            DataTable dtRSN = null;
                            string strStage = "";

                            foreach (TabPage tp in tcStages.TabPages)
                            {
                                ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                                if (ucPartpnt != null)
                                {
                                    strStage = ucPartpnt.StageName;
                                    dtRSN = ucPartpnt.dtRSN.Copy();

                                    if (CheckForRSNCVT_FreeTextInTable(dtRSN, "stereoselective", "Reaction") || CheckForRSNCVT_FreeTextInTable(dtRSN, "regioselective", "Reaction"))
                                    {
                                        strErrMsg = "stereoselective/regioselective is not a valid RSN term";
                                        blStatus = false;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg;
            return blStatus;
        }

        #endregion

        #region Journal - Prophetic Reaction validation

        private bool CheckForJournal_PropheticReactionValidation(out string errMsg)//New feature as on 24th May 2013
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                if (txtTANType.Text.ToUpper() == "JOURNAL")
                {
                    if (tcStages.TabPages.Count > 0)
                    {
                        ucParticipants ucPartpnt = null;
                        DataTable dtRSNTbl = null;
                        string strStageName = "";

                        foreach (TabPage tp in tcStages.TabPages)
                        {
                            ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                            if (ucPartpnt != null)
                            {
                                dtRSNTbl = ucPartpnt.dtRSN != null ? ucPartpnt.dtRSN.Copy() : null;
                                strStageName = ucPartpnt.StageName;

                                if (CheckForRSNTermInAllStagesRSN(dtRSNTbl, "PROPHETIC REACTION", strStageName))
                                {
                                    blStatus = true;
                                    strErrMsg = strErrMsg.Trim() + "\r\n" + "Prophetic Reaction can't be used when TAN type is Journal";
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsg = strErrMsg;
            return blStatus;
        }
        
        #endregion

        private bool CheckForDuplicateReactantsInTAN(out string _errmsg)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                //int intRxnNum = _RxnNum;
                //int intRxnSeq = Convert.ToInt32(lblRxnSeqVal.Text);
                //int intCntr = 0;

                //DataTable dtReactants = GetCurrentReactionReactantsFromAllStages();
                //ArrayList alstReact = GetReactantListFromTable(dtReactants);

                //if (alstReact != null && alstReact.Count > 0)
                //{                   
                //    DataTable dtRxnData = ReactDB.GetReactantsOnTAN_ID(TAN_ID);
                //    if (dtRxnData != null)
                //    {
                //        DataTable dtSEQ = dtRxnData.DefaultView.ToTable(true, "RXN_SEQ");
                //        if (dtSEQ != null && dtSEQ.Rows.Count > 0)
                //        {
                //            for (int sIndx = 0; sIndx < dtSEQ.Rows.Count; sIndx++)
                //            {
                //                DataView dvTemp = dtRxnData.DefaultView;
                //                dvTemp.RowFilter = "RXN_SEQ = " + dtSEQ.Rows[sIndx][0].ToString();
                //                DataTable dtRXN_NUM = dvTemp.ToTable();

                //                intCntr = 0;

                //                if (dtRXN_NUM != null && dtRXN_NUM.Rows.Count > 0)
                //                {
                //                    ArrayList alstR = GetReactantListFromTable(dtRXN_NUM);
                //                    if (alstR != null)
                //                    {
                //                        for (int j = 0; j < alstR.Count; j++)
                //                        {
                //                            if (alstReact.Contains(alstR[j]))
                //                            {
                //                                intCntr = intCntr + 1;
                //                            }
                //                        }
                //                        if (intCntr == alstR.Count && alstReact.Count == alstR.Count)
                //                        {
                //                            //Modification on 26th May 2011, Allow Supervisor to add duplicate Reactants
                //                            if (GlobalVariables.RoleName.ToUpper() == RolesMaster.TOOL_MANAGER)
                //                            {
                //                                string strMsg = "Reactants matching with RXNNUM: " + intRxnNum + " and RXNSEQ: " + dtSEQ.Rows[sIndx][0].ToString();
                //                                strMsg = strMsg + Environment.NewLine + "Do you want to continue?";

                //                                DialogResult diaRes = MessageBox.Show(strMsg, "", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                //                                if (diaRes == DialogResult.Yes)
                //                                {
                //                                    strErrMsg = "";
                //                                    blStatus = false;
                //                                }
                //                                else
                //                                {
                //                                    strErrMsg = "Reactants matching with RXNNUM: " + intRxnNum + " and RXNSEQ: " + dtSEQ.Rows[sIndx][0].ToString();
                //                                    blStatus = true;
                //                                }
                //                            }
                //                            else
                //                            {
                //                                strErrMsg = "Reactants matching with RXNNUM: " + intRxnNum + " and RXNSEQ: " + dtSEQ.Rows[sIndx][0].ToString();
                //                                blStatus = true;
                //                            }
                //                        }
                //                    }
                //                }
                //            }
                //        }
                //    }
                //}            
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg;
            return blStatus;
        }

        private bool CheckForDuplicateReactantsInTAN_New(out string _errmsg)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                //Get Current reaction Reactants from all the stages
                List<int> lstCurRxnReactants = GetCurrentReactionReactantsFromAllStages();
                
                //Get current reaction Products.
                List<int> lstCurRxnProducts = GetCurrentReactionProducts();
                
                int intRxnNum = _RxnNum;
                int intRxnSeq = Convert.ToInt32(lblRxnSeqVal.Text);
               
                if (lstCurRxnReactants.Any())
                {
                    DataTable dtOthRxnPartpnts = ReactDB.GetProduct_ParticipantsDataOnTAN(TAN_ID);//.GetReactantsOnTAN_ID(TAN_ID);
                    if (dtOthRxnPartpnts != null && dtOthRxnPartpnts.Rows.Count > 0)
                    {
                        //Get unique RXN_IDs from the participants table
                        DataTable uniqRxnIDs = dtOthRxnPartpnts.DefaultView.ToTable(true, new string[] { "RXN_ID" });
                        if (uniqRxnIDs != null && uniqRxnIDs.Rows.Count > 0)
                        {
                            DataView dvTemp;
                            List<int> lstOthRxnReacts = null;
                            List<int> lstOthRxnProds = null;
                            DataTable othRxnReacts = null;
                            DataTable othRxnProducts = null;

                            //For each reaction, check the duplicate reaction
                            foreach (DataRow dr in uniqRxnIDs.Rows)
                            {
                                if (dr["RXN_ID"].ToString() != reactionID.ToString())
                                {
                                    //Get other reaction Reactants
                                    dvTemp = dtOthRxnPartpnts.DefaultView;
                                    dvTemp.RowFilter = "RXN_ID = " + dr["RXN_ID"] + " AND PP_TYPE = 'REACTANT'";
                                    othRxnReacts = dvTemp.ToTable();
                                    if (othRxnReacts != null && othRxnReacts.Rows.Count > 0)
                                    {            

                                        //lstOthRxnReacts = (othRxnReacts.AsEnumerable().Select(r => r.Field<decimal>("SERIES_NUM")).ToList<decimal>()).Select(d => (int)d).ToList<int>();
                                        lstOthRxnReacts = (othRxnReacts.AsEnumerable().Select(r => string.IsNullOrEmpty(r.Field<decimal>("SERIES_NUM").ToString()) ? 0 : r.Field<decimal>("SERIES_NUM")).ToList<decimal>()).Select(d => (int)d).ToList<int>();
                                    }

                                    //Get other reaction Products
                                    dvTemp.RowFilter = "RXN_ID = " + dr["RXN_ID"] + " AND PP_TYPE = 'PRODUCT'";
                                    othRxnProducts = dvTemp.ToTable();
                                    if (othRxnProducts != null && othRxnProducts.Rows.Count > 0)
                                    {
                                        lstOthRxnProds = (othRxnProducts.AsEnumerable().Select(r => string.IsNullOrEmpty(r.Field<decimal>("SERIES_NUM").ToString()) ? 0 : r.Field<decimal>("SERIES_NUM")).ToList<decimal>()).Select(d => (int)d).ToList<int>();
                                    }

                                    bool reactantsEqual = lstCurRxnReactants.OrderBy(x => x).SequenceEqual(lstOthRxnReacts.OrderBy(x => x));
                                    bool productsEqual = lstCurRxnProducts.OrderBy(x => x).SequenceEqual(lstOthRxnProds.OrderBy(x => x));

                                    if (reactantsEqual && productsEqual)
                                    {
                                        string matchedRxn = "";
                                        DataTable matchedRxnData = ReactionsTbl.Select("RXN_ID = " + dr[0]).CopyToDataTable();
                                        if (matchedRxnData != null && matchedRxnData.Rows.Count > 0)
                                        {
                                            matchedRxn = "Rxn NUM: " + matchedRxnData.Rows[0]["RXN_NUM"] + " and Seq: " + matchedRxnData.Rows[0]["RXN_SEQ"];
                                        }

                                        //Modification on 26th May 2011, Allow Supervisor to add duplicate Reactants
                                        if (GlobalVariables.RoleName.ToUpper() == RolesMaster.TOOL_MANAGER)
                                        {

                                            string strMsg = "Duplicate reaction. Product and Reactants are matching with " + matchedRxn;
                                            strMsg = strMsg + Environment.NewLine + "Do you want to continue?";

                                            DialogResult diaRes = MessageBox.Show(strMsg, "", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                                            if (diaRes == DialogResult.Yes)
                                            {
                                                strErrMsg = "";
                                                blStatus = false;
                                            }
                                            else
                                            {
                                                strErrMsg = "Reactants matching with " + matchedRxn;
                                                blStatus = true;
                                            }
                                        }
                                        else
                                        {
                                            strErrMsg = "Reactants matching with " + matchedRxn;
                                            blStatus = true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg;
            return blStatus;
        }

        private ArrayList GetReactantListFromTable(DataTable _reactanttbl)
        {
            try
            {
                if (_reactanttbl != null && _reactanttbl.Rows.Count > 0)
                {
                    int intNUM = 0;

                    ArrayList alstReact = new ArrayList();

                    for (int i = 0; i < _reactanttbl.Rows.Count; i++)
                    {
                        intNUM = Convert.ToInt32(_reactanttbl.Rows[i]["SERIES_NUM"]);
                        if (intNUM > 0)
                        {
                            alstReact.Add(intNUM);
                        }
                    }
                    return alstReact;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return null;
        }

        private List<int> GetCurrentReactionReactantsFromAllStages()
        {
            List<int> lstReactants = new List<int>();
            try
            {
                if (tcStages.RowCount > 0)
                {                                       
                    ucParticipants ucParpnt = null;

                    int intNUM = 0;                    

                    for (int i = 0; i < tcStages.TabPages.Count; i++)
                    {
                        ucParpnt = (ucParticipants)tcStages.TabPages[i].Controls["ucParticipants"];
                        if (ucParpnt != null)
                        {
                            DataTable dtReact = ucParpnt.dtReactant;
                            if (dtReact != null && dtReact.Rows.Count > 0)
                            {
                                for (int rindx = 0; rindx < dtReact.Rows.Count; rindx++)
                                {
                                    int.TryParse(dtReact.Rows[rindx]["SERIES_NUM"].ToString(), out intNUM);                                    
                                    if (intNUM > 0)
                                    {
                                        lstReactants.Add(intNUM);                                        
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstReactants;
        }

        private List<int> GetCurrentReactionProducts()
        {
            List<int> lstProducts = new List<int>();
            try
            {
                if (RxnProductsTbl != null && RxnProductsTbl.Rows.Count > 0)
                {
                    lstProducts = ((from row in RxnProductsTbl.AsEnumerable()
                                   select row.Field<decimal>("SERIES_NUM")).ToList<decimal>()).Select(d => (int)d).ToList<int>(); 
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstProducts;
        }
        
        #region Empty Participants Code commented on 22nd Feb 2012, Don't delete
        //private bool CheckForEmptyParticipants(out string _errmsg)
        //{
        //    bool blStatus = false;
        //    string strErrMsg = "";
        //    try
        //    {
        //        if (tbStages.TabPages.Count > 0)
        //        {
        //            ucParticipants ucPartpnt = null;

        //            DataTable dtReactant = null;
        //            DataTable dtAgent = null;
        //            DataTable dtSolvent = null;
        //            DataTable dtCatalyst = null;
        //            DataTable dtRSN = null;
        //            DataTable dtConds = null;

        //            string strPartpnt = "";

        //            foreach (TabPage tp in tbStages.TabPages)
        //            {
        //                strPartpnt = "";

        //                ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
        //                if (ucPartpnt != null)
        //                {
        //                    dtReactant = ucPartpnt.dtReactant.Copy();
        //                    dtAgent = ucPartpnt.dtAgent.Copy();
        //                    dtSolvent = ucPartpnt.dtSolvent.Copy();
        //                    dtCatalyst = ucPartpnt.dtCatalyst.Copy();

        //                    dtRSN = ucPartpnt.dtRSN.Copy();
        //                    dtConds = ucPartpnt.dtConditions.Copy();

        //                    if (dtReactant != null && dtAgent != null && dtSolvent != null && dtCatalyst != null)
        //                    {
        //                        if (dtReactant.Rows.Count == 0 && dtAgent.Rows.Count == 0
        //                            && dtSolvent.Rows.Count == 0 && dtCatalyst.Rows.Count == 0
        //                            && dtRSN.Rows.Count == 0 && dtConds.Rows.Count == 0)
        //                        {
        //                            blStatus = true;
        //                            if (strErrMsg.Trim() == "")
        //                            {
        //                                strErrMsg = "Empty Participants in the " + tp.Text;
        //                            }
        //                            else
        //                            {
        //                                strErrMsg = strErrMsg + ", " + tp.Text;
        //                            }
        //                        }
        //                        else if (dtReactant.Rows.Count == 0 && dtAgent.Rows.Count == 0
        //                        && dtSolvent.Rows.Count == 0 && dtCatalyst.Rows.Count == 0
        //                        && dtRSN.Rows.Count == 0 && dtConds.Rows.Count > 0 && GlobalVariables.UserRole == "SUPERVISOR")//New validations as on 16th March 2011
        //                        {
        //                            blStatus = false;
        //                        }
        //                        else
        //                        {
        //                            bool blEmptyStg_RSN = CheckFor_EmptyStageRSNTermUsed(dtRSN);

        //                            bool blStatus_R = CheckForEmptyRowsInTable(dtReactant, "REACTANT");
        //                            bool blStatus_A = CheckForEmptyRowsInTable(dtAgent, "AGENT");
        //                            bool blStatus_S = CheckForEmptyRowsInTable(dtSolvent, "SOLVENT");
        //                            bool blStatus_C = CheckForEmptyRowsInTable(dtCatalyst, "CATALYST");

        //                            bool blStatus_final = false;

        //                            if (blEmptyStg_RSN == true)
        //                            {
        //                                if (blStatus_R == false && blStatus_A == false && blStatus_S == false && blStatus_C == false)
        //                                {
        //                                    blStatus_final = false;
        //                                }
        //                                else
        //                                {
        //                                    if (blStatus_R)
        //                                    {
        //                                        if (strPartpnt.Trim() == "")
        //                                        {
        //                                            strPartpnt = "REACTANT";
        //                                        }
        //                                        else
        //                                        {
        //                                            strPartpnt = strPartpnt + ",REACTANT";
        //                                        }
        //                                    }
        //                                    if (blStatus_A)
        //                                    {
        //                                        if (strPartpnt.Trim() == "")
        //                                        {
        //                                            strPartpnt = "AGENT";
        //                                        }
        //                                        else
        //                                        {
        //                                            strPartpnt = strPartpnt + ",AGENT";
        //                                        }
        //                                    }
        //                                    if (blStatus_S)
        //                                    {
        //                                        if (strPartpnt.Trim() == "")
        //                                        {
        //                                            strPartpnt = "SOLVENT";
        //                                        }
        //                                        else
        //                                        {
        //                                            strPartpnt = strPartpnt + ",SOLVENT";
        //                                        }
        //                                    }
        //                                    if (blStatus_C)
        //                                    {
        //                                        if (strPartpnt.Trim() == "")
        //                                        {
        //                                            strPartpnt = "CATALYST";
        //                                        }
        //                                        else
        //                                        {
        //                                            strPartpnt = strPartpnt + ",CATALYST";
        //                                        }
        //                                    }
        //                                    blStatus_final = true;
        //                                }
        //                            }
        //                            else if (blEmptyStg_RSN == false)
        //                            {
        //                                if (blStatus_R == true || blStatus_A == true || blStatus_S == true || blStatus_C == true)
        //                                {
        //                                    blStatus_final = true;

        //                                    if (blStatus_R)
        //                                    {
        //                                        if (strPartpnt.Trim() == "")
        //                                        {
        //                                            strPartpnt = "REACTANT";
        //                                        }
        //                                        else
        //                                        {
        //                                            strPartpnt = strPartpnt + ",REACTANT";
        //                                        }
        //                                    }
        //                                    if (blStatus_A)
        //                                    {
        //                                        if (strPartpnt.Trim() == "")
        //                                        {
        //                                            strPartpnt = "AGENT";
        //                                        }
        //                                        else
        //                                        {
        //                                            strPartpnt = strPartpnt + ",AGENT";
        //                                        }
        //                                    }
        //                                    if (blStatus_S)
        //                                    {
        //                                        if (strPartpnt.Trim() == "")
        //                                        {
        //                                            strPartpnt = "SOLVENT";
        //                                        }
        //                                        else
        //                                        {
        //                                            strPartpnt = strPartpnt + ",SOLVENT";
        //                                        }
        //                                    }
        //                                    if (blStatus_C)
        //                                    {
        //                                        if (strPartpnt.Trim() == "")
        //                                        {
        //                                            strPartpnt = "CATALYST";
        //                                        }
        //                                        else
        //                                        {
        //                                            strPartpnt = strPartpnt + ",CATALYST";
        //                                        }
        //                                    }
        //                                }
        //                                else if (blStatus_R == false && blStatus_A == false && blStatus_S == false && blStatus_C == false && dtRSN.Rows.Count == 0)
        //                                {
        //                                    blStatus_final = false;
        //                                }
        //                                else if (dtReactant.Rows.Count == 0 && dtAgent.Rows.Count == 0 && dtSolvent.Rows.Count == 0 && dtCatalyst.Rows.Count == 0 && dtRSN.Rows.Count > 0)
        //                                {
        //                                    blStatus_final = true;
        //                                }
        //                            }

        //                            if (blStatus_final)
        //                            {
        //                                blStatus = true;
        //                                if (strErrMsg.Trim() == "")
        //                                {
        //                                    if (strPartpnt.Trim() != "")
        //                                    {
        //                                        strErrMsg = "Empty Participants in the " + tp.Text + "(" + strPartpnt + ")";
        //                                    }
        //                                    else
        //                                    {
        //                                        strErrMsg = "Empty Participants in the " + tp.Text + strPartpnt;
        //                                    }
        //                                }
        //                                else
        //                                {
        //                                    if (strPartpnt.Trim() != "")
        //                                    {
        //                                        strErrMsg = strErrMsg + ", " + tp.Text + "(" + strPartpnt + ")";
        //                                    }
        //                                    else
        //                                    {
        //                                        strErrMsg = strErrMsg + ", " + tp.Text + strPartpnt;
        //                                    }
        //                                }
        //                            }
        //                        }
        //                    }
        //                }
        //            }

        //            if (blStatus)
        //            {
        //                //Disable NewReaction button
        //                btnAddRxn.Enabled = false;
        //            }
        //            else
        //            {
        //                btnAddRxn.Enabled = true;
        //            }

        //            _errmsg = strErrMsg + " of the Reaction";
        //            return blStatus;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    _errmsg = "";
        //    return blStatus;
        //} 
        #endregion

        private bool CheckForEmptyParticipants(out string _errmsg)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                if (tcStages.TabPages.Count > 0)
                {
                    ucParticipants ucPartpnt = null;

                    DataTable dtReactant = null;
                    DataTable dtAgent = null;
                    DataTable dtSolvent = null;
                    DataTable dtCatalyst = null;
                   
                    string strPartpnt = "";
                    string strTemp = "";

                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        strPartpnt = "";

                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            dtReactant = ucPartpnt.dtReactant != null ? ucPartpnt.dtReactant.Copy() : null;
                            dtAgent = ucPartpnt.dtAgent != null ?  ucPartpnt.dtAgent.Copy() : null;
                            dtSolvent = ucPartpnt.dtSolvent != null ? ucPartpnt.dtSolvent.Copy() : null;
                            dtCatalyst = ucPartpnt.dtCatalyst!= null ? ucPartpnt.dtCatalyst.Copy() : null;
                            
                            if (dtReactant != null && dtAgent != null && dtSolvent != null && dtCatalyst != null)
                            {
                                if (dtReactant.Rows.Count == 0 && dtAgent.Rows.Count == 0 &&
                                    dtSolvent.Rows.Count == 0 && dtCatalyst.Rows.Count == 0)// dtRSN.Rows.Count == 0 && dtConds.Rows.Count == 0)                                   
                                {
                                    blStatus = true;
                                    strErrMsg = strErrMsg.Trim() + "\r\n" + "Empty Participants in the " + tp.Text + " of the reaction";                                   
                                }
                                else
                                {
                                    strTemp = "";

                                    bool blStatus_R = CheckForEmptyRowsInTable(dtReactant, "REACTANT");
                                    bool blStatus_A = CheckForEmptyRowsInTable(dtAgent, "AGENT");
                                    bool blStatus_S = CheckForEmptyRowsInTable(dtSolvent, "SOLVENT");
                                    bool blStatus_C = CheckForEmptyRowsInTable(dtCatalyst, "CATALYST");

                                    if (blStatus_R)
                                    {
                                        strTemp = "REACTANT";
                                        blStatus = true;
                                    }
                                    if (blStatus_A)
                                    {
                                        strTemp = strTemp.Trim() + " " + "AGENT";
                                        blStatus = true;
                                    }
                                    if (blStatus_S)
                                    {
                                        strTemp = strTemp.Trim() + " " + "SOLVENT";
                                        blStatus = true;
                                    }
                                    if (blStatus_C)
                                    {
                                        strTemp = strTemp.Trim() + " " + "CATALYST";
                                        blStatus = true;
                                    }

                                    strTemp = strTemp.Trim().Replace(" ", ", ");

                                    if (!string.IsNullOrEmpty(strTemp))
                                    {
                                        strTemp = "Empty Participants in the " + tp.Text + " (" + strTemp + ") of the reaction";
                                        strErrMsg = strErrMsg.Trim() + "\r\n" + strTemp.Trim();                                        
                                    }
                                }
                            }
                        }
                    }

                    if (blStatus)
                    {
                        //Disable NewReaction button
                        btnAddRxn.Enabled = false;
                    }
                    else
                    {
                        btnAddRxn.Enabled = true;
                    }

                    _errmsg = strErrMsg.Trim();
                    return blStatus;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = "";
            return blStatus;
        }

        private bool CheckFor_EmptyStageRSNTermUsed(DataTable dtrsn)
        {
            bool blStatus = false;
            try
            {
                if (GlobalVariables.EmptyStage_RSNs != null )
                {
                    if (GlobalVariables.EmptyStage_RSNs.Rows.Count > 0)
                    {
                        if (dtrsn != null)
                        {
                            if (dtrsn.Rows.Count == 1)
                            {
                                for (int i = 0; i < GlobalVariables.EmptyStage_RSNs.Rows.Count; i++)
                                {
                                    if (dtrsn.Rows[0]["rsn_free_text"].ToString().ToUpper().Contains(GlobalVariables.EmptyStage_RSNs.Rows[i]["rsn_free_text"].ToString().Trim().ToUpper()))
                                    {
                                        blStatus = true;
                                        return blStatus;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckForEmptyRowsInTable(DataTable _dtpartpnt, string partpnt)
        {
            bool blStatus = false;
            try
            {
                if (_dtpartpnt != null && _dtpartpnt.Rows.Count > 0)
                {
                    //DataView dvNrnReg = _dtpartpnt.DefaultView;
                    //dvNrnReg.RowFilter = "REG_NO > 0";
                    //DataTable dtNrnReg = dvNrnReg.ToTable();

                    //DataView dv8000 = _dtpartpnt.DefaultView;
                    ////dv8000.RowFilter = "SERIES_8000 > 0";
                    //dv8000.RowFilter = "SERIES_NUM > 0";
                    //DataTable dt8000 = dv8000.ToTable();
                    //if (dtNrnReg != null && dt8000 != null)
                    //{
                    //    if ((dtNrnReg.Rows.Count + dt8000.Rows.Count) == _dtpartpnt.Rows.Count)
                    //    {
                    //        blStatus = false;
                    //        return blStatus;
                    //    }
                    //    else
                    //    {
                    //        blStatus = true;
                    //        return blStatus;
                    //    }
                    //}

                    DataView dv8000 = _dtpartpnt.DefaultView;
                    dv8000.RowFilter = "SERIES_NUM > 0";
                    DataTable dt8000 = dv8000.ToTable();
                    if (dt8000 != null)
                    {
                        if (dt8000.Rows.Count == _dtpartpnt.Rows.Count)
                        {
                            blStatus = false;
                            return blStatus;
                        }
                        else
                        {
                            blStatus = true;
                            return blStatus;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckRSNMaxLenghtValidation(out string _errmsg)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                if (tcStages.TabPages.Count > 0)
                {
                    ucParticipants ucPartpnt = null;                    
                    DataTable dtRSNTbl = null;
                   
                    int rsnLength = 0;

                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];

                        if (ucPartpnt != null)
                        {
                            dtRSNTbl = ucPartpnt.dtRSN != null ? ucPartpnt.dtRSN.Copy() : null;

                            if (dtRSNTbl != null && dtRSNTbl.Rows.Count > 0)
                            {
                                for (int i = 0; i < dtRSNTbl.Rows.Count; i++)
                                {
                                    rsnLength = rsnLength + dtRSNTbl.Rows[i]["CVT"].ToString().Length + dtRSNTbl.Rows[i]["FREE_TEXT"].ToString().Trim().Length;
                                }
                            }
                        }
                    }
                    
                    if (rsnLength > 500)
                    {
                        blStatus = true;
                        strErrMsg = "RSN length should be <= 500";
                    }                   
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg;
            return blStatus;
        }


        private bool CheckForRSN_Free_Stage_Validation(out string _errmsg)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                if (tcStages.TabPages.Count > 0)
                {
                    ucParticipants ucPartpnt = null;
                    string strStageName = "";
                    DataTable dtRSNTbl = null;
                    int intStage_ID = 0;
                    int intStageIndx = 0;
                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        intStageIndx = intStageIndx + 1;
                        strStageName = "";

                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            strStageName = ucPartpnt.StageName;
                            intStage_ID = ucPartpnt.RxnStageID;
                            dtRSNTbl = ucPartpnt.dtRSN != null ? ucPartpnt.dtRSN.Copy() : null;

                            if (dtRSNTbl != null && dtRSNTbl.Rows.Count > 0)
                            {
                                for (int i = 0; i < dtRSNTbl.Rows.Count; i++)
                                {
                                    if (intStage_ID.ToString() == dtRSNTbl.Rows[i]["RXN_STAGE_ID"].ToString())
                                    {
                                        if (dtRSNTbl.Rows[i]["CVT"].ToString().Trim() == "" && dtRSNTbl.Rows[i]["FREE_TEXT"].ToString().Trim() == "")
                                        {
                                            blStatus = true;
                                            strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Empty RSN in the " + strStageName + " of the Reaction";
                                        }
                                        else if (dtRSNTbl.Rows[i]["FREE_TEXT"].ToString().Trim() != "")
                                        {
                                            if (dtRSNTbl.Rows[i]["FREE_TEXT"].ToString().Trim().ToUpper().Contains("(STAGES ")
                                                && dtRSNTbl.Rows[i]["NOTE_LEVEL"].ToString().Trim().ToUpper() == "STAGE")
                                            {
                                                if (!dtRSNTbl.Rows[i]["FREE_TEXT"].ToString().Trim().ToUpper().Contains("(STAGES " + intStageIndx))
                                                {
                                                    blStatus = true;
                                                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "RSN 'FreeText' contains mismatched stage number in the " + strStageName;

                                                }
                                            }
                                            else if (dtRSNTbl.Rows[i]["FREE_TEXT"].ToString().Trim().ToUpper().Contains("(STAGE")
                                                && dtRSNTbl.Rows[i]["NOTE_LEVEL"].ToString().Trim().ToUpper() == "STAGE")
                                            {
                                                if (!dtRSNTbl.Rows[i]["FREE_TEXT"].ToString().Trim().ToUpper().Contains(strStageName.ToUpper()))
                                                {
                                                    blStatus = true;
                                                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "RSN 'FreeText' contains mismatched stage number in the " + strStageName;
                                                }

                                                #region MyRegion
                                                //else if (dtRSNTbl.Rows[i]["RSN_FREE_TEXT"].ToString().Trim().ToUpper().Contains(","))
                                                //{
                                                //    string[] split_comma = { "," };
                                                //    string[] split_name = { "(" + strStageName.ToLower() + ")" };
                                                //    string[] strRsnVals = dtRSNTbl.Rows[i]["RSN_FREE_TEXT"].ToString().Trim().Split(split_comma, StringSplitOptions.RemoveEmptyEntries);
                                                //    string[] strVals = dtRSNTbl.Rows[i]["RSN_FREE_TEXT"].ToString().Trim().Split(split_name, StringSplitOptions.RemoveEmptyEntries);
                                                //    if (strRsnVals != null && strVals != null)
                                                //    {
                                                //        if (strRsnVals.Length != strVals.Length)
                                                //        {
                                                //            blStatus = true;
                                                //            if (strErrMsg.Trim() == "")
                                                //            {
                                                //                strErrMsg = "Please enter stage information for each RSN term in the " + strStageName;
                                                //            }
                                                //            else
                                                //            {
                                                //                strErrMsg = strErrMsg + "\r\n" + "Please enter stage information for each RSN term in the " + strStageName;
                                                //            }
                                                //        }
                                                //    }
                                                //} 
                                                #endregion
                                            }
                                            else if (dtRSNTbl.Rows[i]["FREE_TEXT"].ToString().Trim().ToUpper().Contains("STAGE")
                                                && dtRSNTbl.Rows[i]["NOTE_LEVEL"].ToString().Trim().ToUpper() == "REACTION")
                                            {
                                                blStatus = true;
                                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Please check the RSN 'FreeText' at Reaction level in the " + strStageName;
                                            }
                                            else if (!dtRSNTbl.Rows[i]["FREE_TEXT"].ToString().Trim().ToUpper().Contains("STAGE")
                                                && dtRSNTbl.Rows[i]["NOTE_LEVEL"].ToString().Trim().ToUpper() == "STAGE")
                                            {
                                                blStatus = true;
                                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "No Stage number in the RSN 'FreeText' in the " + strStageName;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg;
            return blStatus;
        }

        private bool CheckAgent_9438_9068Validation(out string _errmsg)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                if (tcStages.TabPages.Count > 0)
                {
                    ucParticipants ucPartpnt = null;
                    string strStageName = "";
                    DataTable dtAgentTbl = null;
                    bool blVal_9438 = false;
                    bool blVal_9068 = false;

                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        strStageName = "";

                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            strStageName = ucPartpnt.StageName;
                            dtAgentTbl = ucPartpnt.dtAgent != null ? ucPartpnt.dtAgent.Copy() : null;
                            blVal_9438 = false;
                            blVal_9068 = false;

                            if (dtAgentTbl != null && dtAgentTbl.Rows.Count > 0)
                            {
                                for (int i = 0; i < dtAgentTbl.Rows.Count; i++)
                                {
                                    if (dtAgentTbl.Rows[i]["REG_NO"].ToString() == "108189")//9438
                                    {
                                        blVal_9438 = true;
                                    }
                                    else if (dtAgentTbl.Rows[i]["REG_NO"].ToString() == "109728")//9068
                                    {
                                        blVal_9068 = true;
                                    }
                                }

                                if (blVal_9068 && blVal_9438 && dtAgentTbl.Rows.Count == 2)
                                {
                                    blStatus = true;
                                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Please check for LDA preparation or not. If it is LDA preparation keep Agent as 9071 (4111540) in the " + strStageName;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg.Trim();
            return blStatus;
        }

        #region RSN(Buffer) - Solvent(Water) Validation Methods - New validation on 25th March 2011

        private bool CheckForBuffer_WaterSolvent_Validation(out string _errmsg)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                if (tcStages.TabPages.Count > 0)
                {
                    ucParticipants ucPartpnt = null;
                    string strStageName = "";
                    DataTable dtRSNTbl = null;
                    DataTable dtSolventTbl = null;

                    //Check if Buffer is used in the Reaction level
                    bool IsRxn_Buffer = CheckBufferUsedInReaction();

                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        strStageName = "";
                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];

                        if (ucPartpnt != null)
                        {
                            strStageName = ucPartpnt.StageName;
                            dtSolventTbl = ucPartpnt.dtSolvent != null ? ucPartpnt.dtSolvent.Copy() : null;
                            dtRSNTbl = ucPartpnt.dtRSN != null ? ucPartpnt.dtRSN.Copy() : null;

                            if (dtRSNTbl != null && dtRSNTbl.Rows.Count > 0)
                            {
                                for (int i = 0; i < dtRSNTbl.Rows.Count; i++)
                                {
                                    if (dtRSNTbl.Rows[i]["FREE_TEXT"].ToString().Trim() != "")
                                    {
                                        if (IsRxn_Buffer)//Reaction level
                                        {
                                            if (!CheckWaterInSolventTable(dtSolventTbl))
                                            {
                                                blStatus = true;
                                                strErrMsg = strErrMsg.Trim() + "\r\n" + "Solvent - H2O should be there if 'Buffer' is used in the RSN (Reaction level) and also check the 'pH' condition value in the " + strStageName;
                                            }
                                        }
                                        else if (dtRSNTbl.Rows[i]["FREE_TEXT"].ToString().ToUpper().Trim().Contains("BUFFER"))//Stage level
                                        {
                                            if (!CheckWaterInSolventTable(dtSolventTbl))
                                            {
                                                blStatus = true;
                                                strErrMsg = strErrMsg.Trim() + "\r\n" + "Solvent - H2O should be there if 'Buffer' is used in the RSN and also check the 'pH' condition value in the " + strStageName;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg;
            return blStatus;
        }

        private bool CheckBufferUsedInReaction()
        {
            bool blStatus = false;
            try
            {
                if (tcStages.TabPages.Count > 0)
                {
                    ucParticipants ucPartpnt = null;
                    DataTable dtRSNTbl = null;

                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];

                        if (ucPartpnt != null)
                        {
                            dtRSNTbl = ucPartpnt.dtRSN != null ? ucPartpnt.dtRSN.Copy() : null;
                            if (dtRSNTbl != null && dtRSNTbl.Rows.Count > 0)
                            {
                                DataRow[] drArr = dtRSNTbl.Select("FREE_TEXT like '%buffer%' and NOTE_LEVEL = 'Reaction'");
                                if (drArr != null && drArr.Length > 0)
                                {
                                    blStatus = true;
                                    return blStatus;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckWaterInSolventTable(DataTable _solventtbl)
        {
            bool blStatus = false;
            try
            {
                if (_solventtbl != null && _solventtbl.Rows.Count > 0)
                {
                    //Water(9000) - Nrnreg - 7732185

                    DataRow[] drArr = _solventtbl.Select("REG_NO = 7732185");
                    if (drArr != null && drArr.Length > 0)
                    {
                        blStatus = true;
                        return blStatus;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        #endregion

        private bool CheckForRSNFreeTextContainsCVT(out string _errmsg)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                if (tcStages.TabPages.Count > 0)
                {
                    ucParticipants ucPartpnt = null;
                    string strStageName = "";
                    DataTable dtRSNTbl = null;
                    string strCVT = "";

                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        strStageName = "";

                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            strStageName = ucPartpnt.StageName;
                            dtRSNTbl = ucPartpnt.dtRSN != null ? ucPartpnt.dtRSN.Copy() : null;

                            if (dtRSNTbl != null && dtRSNTbl.Rows.Count > 0)
                            {
                                for (int i = 0; i < dtRSNTbl.Rows.Count; i++)
                                {
                                    if (dtRSNTbl.Rows[i]["RSN_FREE_TEXT"].ToString().Trim() != "")
                                    {
                                        if (dtRSNTbl.Rows[i]["RSN_COMBINED"].ToString().Trim().ToUpper() == "REACTION")
                                        {
                                            strCVT = "";
                                            if (CheckFreeTextInCVTTable(dtRSNTbl.Rows[i]["RSN_FREE_TEXT"].ToString().Trim(), out strCVT))
                                            {
                                                blStatus = true;
                                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "FreeText contains CVT term ' " + strCVT + " ' in the " + strStageName;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg.Trim();
            return blStatus;
        }

        private bool CheckFreeTextInCVTTable(string _freetext, out string _cvtterm)
        {
            bool blStatus = false;
            _cvtterm = "";
            try
            {
                if (Generic.GlobalVariables.RSN_CVT_Tbl != null && Generic.GlobalVariables.RSN_CVT_Tbl.Rows.Count > 0)
                {
                    for (int i = 0; i < Generic.GlobalVariables.RSN_CVT_Tbl.Rows.Count; i++)
                    {
                        if (_freetext.Trim().Equals(Generic.GlobalVariables.RSN_CVT_Tbl.Rows[i]["cvt"].ToString().Trim(), StringComparison.OrdinalIgnoreCase))
                        {
                            blStatus = true;
                            _cvtterm = Generic.GlobalVariables.RSN_CVT_Tbl.Rows[i]["cvt"].ToString().Trim();
                            return blStatus;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        /// <summary>
        /// Modified on 20th June 2011
        /// </summary>
        /// <param name="_errmsg"></param>
        /// <returns></returns>
        private bool CheckForEmptySolventWhenGivenAgentUsed(out string _errmsg)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                if (tcStages.TabPages.Count > 0)
                {
                    ucParticipants ucPartpnt = null;                   
                    DataTable dtAgent = null;
                    DataTable dtSolvent = null;                    

                    ArrayList alstAgents = new ArrayList();
                    alstAgents.Add("9065");//NaHCO3 - 
                    alstAgents.Add("9066");//Na2CO3
                    alstAgents.Add("9075");//NH4OH
                    alstAgents.Add("9100");//Hcl
                    alstAgents.Add("9101");//H2SO4
                    alstAgents.Add("9266");//NH4Cl 

                    ArrayList alstNrnReg = new ArrayList();
                    alstNrnReg.Add("144558");//NaHCO3 - RegNo-144558 
                    alstNrnReg.Add("497198");//Na2CO3 - 497198
                    alstNrnReg.Add("1336216");//NH4OH - 1336216
                    alstNrnReg.Add("7647010");//Hcl - 7647010
                    alstNrnReg.Add("7664939");//H2SO4 - 7664939
                    alstNrnReg.Add("12125029");//NH4Cl  - 12125029

                    for (int i = 0; i < tcStages.TabPages.Count; i++)
                    {
                        TabPage tp = tcStages.TabPages[i];
                        if (tp != null)
                        {
                            ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                            if (ucPartpnt != null)
                            {
                                dtAgent = ucPartpnt.dtAgent != null ? ucPartpnt.dtAgent.Copy() : null;
                                dtSolvent = ucPartpnt.dtSolvent != null ?  ucPartpnt.dtSolvent.Copy() : null;
                           
                                if (dtAgent.Rows.Count == 1 && dtSolvent.Rows.Count == 0)
                                {
                                    if (dtAgent.Rows[0]["SER_TYPE"].ToString().Trim() == "9000")//9000 value exist
                                    {
                                        if (alstAgents.Contains(dtAgent.Rows[0]["SERIES_NUM"].ToString()))
                                        {
                                            if (!(dtAgent.Rows[0]["PP_NAME"].ToString().Trim().Contains("(Solid)") ||
                                                dtAgent.Rows[0]["PP_NAME"].ToString().Trim().Contains("(Gas)") ||
                                                (dtAgent.Rows[0]["PP_NAME"].ToString().Trim().Contains("(Conc.)"))))//new condition on 17th June 2011
                                            {
                                                blStatus = true;
                                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Solvent should be there for Agent " + dtAgent.Rows[0]["SERIES_NUM"].ToString() + " in the " + tp.Text + " of the Reaction";
                                            }
                                        }
                                    }
                                    else if (dtAgent.Rows[0]["SER_TYPE"].ToString().Trim() == "NUM")//From Num - Nrnreg case
                                    {
                                        if (alstNrnReg.Contains(dtAgent.Rows[0]["REG_NO"].ToString()))
                                        {
                                            if (GlobalVariables.RoleName.ToUpper() == "SUPERVISOR" || GlobalVariables.RoleName.ToUpper() == "QUALITY CHECK")
                                            {
                                                DialogResult diaRes = MessageBox.Show("Solvent should be there for Agent " + dtAgent.Rows[0]["SERIES_NUM"].ToString() + " in the " + tp.Text + " of the Reaction.\r\nDo you want to proceed?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                                                if (diaRes != DialogResult.Yes)
                                                {
                                                    blStatus = true;
                                                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Solvent should be there for Agent " + dtAgent.Rows[0]["SERIES_NUM"].ToString() + " in the " + tp.Text + " of the Reaction";
                                                }
                                            }
                                            else
                                            {
                                                blStatus = true;
                                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Solvent should be there for Agent " + dtAgent.Rows[0]["SERIES_NUM"].ToString() + " in the " + tp.Text + " of the Reaction";
                                            }
                                        }
                                    }                                
                                }                             
                            }                            
                        }
                    }                 
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg.Trim();
            return blStatus;
        }

        private bool ValidateUserInputs(out string _errmsg)
        {
            bool blStatus = true;
            string strErrMsg = "";

            try
            {
                //Get Product data from grid
                List<Product_ParticipantBO> lstProduct = GetProductDetailsFromProductGrid(reactionID);

                if (lstProduct != null && lstProduct.Count > 0)
                {
                    for (int i = 0; i < lstProduct.Count; i++)
                    {
                        if (CheckFor_Yield_Max_Allowed(lstProduct[i].Yield))
                        {
                            strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Yield should be less than 100%";
                            blStatus = false;
                        }
                    }
                }

                #region Old code commented
                //if (string.IsNullOrEmpty(txtShipmentName.Text.Trim()))
                //{
                //    strErrMsg = strErrMsg.Trim() + "\r\n" + "FileNum field can't be blank";
                //    blStatus = false;                   
                //}                
                //else if (string.IsNullOrEmpty(txtCAN.Text.Trim()))
                //{
                //    strErrMsg = strErrMsg.Trim() + "\r\n" + "CAN field can't be blank";
                //    blStatus = false;                   
                //}

                //else if (string.IsNullOrEmpty(txtTAN.Text.Trim()))
                //{
                //    strErrMsg = strErrMsg.Trim() + "\r\n" + "TAN field can't be blank";
                //    blStatus = false;                    
                //}
                //else if (!Validations.ValidateTANFormat(txtTAN.Text))
                //{
                //   strErrMsg = strErrMsg.Trim() + "\r\n" + "TAN format is not valid \r\nValid format is 12345678A";
                //    blStatus = false;                   
                //}
                //else if (string.IsNullOrEmpty(txtAnalyst.Text.Trim()))
                //{
                //    strErrMsg = strErrMsg.Trim() + "\r\n" + "Analyst field can't be blank";
                //    blStatus = false;                   
                //}
                //else if (txtAnalyst.Text.Length < 4)
                //{
                //    strErrMsg = strErrMsg.Trim() + "\r\n" + "Analyst field length should be 4-6";
                //    blStatus = false;                   
                //}
                //else if (string.IsNullOrEmpty(lblProdNum.Text.Trim()) && ReactionsTbl.Rows.Count > 0)
                //{
                //    strErrMsg = strErrMsg.Trim() + "\r\n" + "RXNNUM field can't be blank";
                //    blStatus = false;                   
                //}
                //else if (string.IsNullOrEmpty(lblRxnSeqVal.Text.Trim()) && ReactionsTbl.Rows.Count > 0)
                //{
                //    strErrMsg = strErrMsg.Trim() + "\r\n" + "RXNSEQ field can't be blank";
                //    blStatus = false;                   
                //}                
                //else
                //{
                //   strErrMsg = "";
                //   blStatus = true;                   
                //} 
                #endregion
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg;
            return blStatus;
        }

        #region KeyPress Events

        private void txtAnalyst_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (((e.KeyChar >= 48 && e.KeyChar <= 57) || e.KeyChar == 8) != true)
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtTAN_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (((e.KeyChar >= 48 && e.KeyChar <= 58) || e.KeyChar == 8 ||
                    (e.KeyChar >= 65 && e.KeyChar <= 90) ||
                    (e.KeyChar >= 97 && e.KeyChar <= 122)) != true)
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion        

        private void ChemRenditor_EditorReturned(object sender, MDL.Draw.Renditor.EditorReturnedEventArgs e)
        {
            //try
            //{
            //    if (molColumn == "P_MOL")
            //    {
            //        RxnProductsTbl.Rows[rowIndx]["P_MOL"] = (object)ChemRenditor.Image;
            //        RxnProductsTbl.Rows[rowIndx]["molecule_sketch"] = ChemRenditor.MolfileString;
            //    }
            //    else if (molColumn.ToUpper() == "SUBST_MOL")
            //    {
            //        RxnProductsTbl.Rows[rowIndx]["SUBST_MOL_IMAGE"] = (object)ChemRenditor.Image;
            //        RxnProductsTbl.Rows[rowIndx]["subst_molecule"] = ChemRenditor.MolfileString;
            //    }
            //}
            //catch (Exception ex)
            //{
            //    Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            //}
        }

        #region Add and Remove Stages

        private void addStageBeforeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                int intTbIndx = tcStages.SelectedIndex;
                if (intTbIndx > 0)
                {
                    AddNewReactionStage(intTbIndx, "BEFORE");
                }
                else
                {
                    MessageBox.Show("Stage can't be added before Stage 1", "Add Stage", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void addStageAfterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                int intTbIndx = tcStages.SelectedIndex;
                AddNewReactionStage(intTbIndx, "AFTER");
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void removeTabToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                RemoveReactionStage();
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog("removeTabToolStripMenuItem_Click " + ex.ToString());
            }
        }

        #endregion

        #region Navigation Events

        private void btnFirst_Click(object sender, EventArgs e)
        {
            try
            {
                string strErrMSg = "";
                string strErrSrc = "";
                blValidRxn = false;

                if (!SaveReactionData_New(out strErrMSg, out strErrSrc))
                {
                    if (strErrMSg.Trim() != "")
                    {
                        MessageBox.Show("Errors in the Reaction. Clear the below errors before moving to another reaction\r\n\r\n" + strErrMSg, strErrSrc, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    blValidRxn = true;

                    currRxnIndex = 1;
                    numGotoRecord.Value = currRxnIndex;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog("btnFirst_Click() " + ex.ToString());
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                string strErrMSg = "";
                string strErrSrc = "";
                blValidRxn = false;

                if (!SaveReactionData_New(out strErrMSg, out strErrSrc))
                {
                    if (strErrMSg.Trim() != "")
                    {
                        MessageBox.Show("Errors in the Reaction. Clear the below errors before moving to another reaction\r\n\r\n" + strErrMSg, strErrSrc, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    blValidRxn = true;

                    if (currRxnIndex < MaxRecCnt)
                    {
                        currRxnIndex = currRxnIndex + 1;
                    }
                    else if (currRxnIndex == MaxRecCnt)
                    {
                        currRxnIndex = MaxRecCnt;
                    }
                    numGotoRecord.Value = currRxnIndex;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog("btnNext_Click() " + ex.ToString());
            }
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            try
            {
                string strErrMSg = "";
                string strErrSrc = "";
                blValidRxn = false;

                if (!SaveReactionData_New(out strErrMSg, out strErrSrc))
                {
                    if (strErrMSg.Trim() != "")
                    {
                        MessageBox.Show("Errors in the Reaction. Clear the below errors before moving to another reaction\r\n\r\n" + strErrMSg, strErrSrc, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    blValidRxn = true;

                    currRxnIndex = MaxRecCnt;
                    numGotoRecord.Value = currRxnIndex;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog("btnLast_Click() " + ex.ToString());
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                string strErrMSg = "";
                string strErrSrc = "";
                blValidRxn = false;

                if (!SaveReactionData_New(out strErrMSg, out strErrSrc))
                {
                    if (strErrMSg.Trim() != "")
                    {
                        MessageBox.Show("Errors in the Reaction. Clear the below errors before moving to another reaction\r\n\r\n" + strErrMSg, strErrSrc, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    blValidRxn = true;

                    if (currRxnIndex <= MaxRecCnt && currRxnIndex > 1)
                    {
                        currRxnIndex = (currRxnIndex - 1);
                    }
                    numGotoRecord.Value = currRxnIndex;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog("btnPrevious_Click() " + ex.ToString());
            }
        }

        #endregion
        TreeNode tnSelected;
        private void SelectReactionNodeInTheTreeView(int curRecIndx)
        {
            try
            {
                if (curRecIndx > 0)
                {
                    //Select Node in the Reactions TreeView
                    foreach (TreeNode tn in tvReactions.Nodes[0].Nodes)
                    {
                        //tn.ImageIndex = 0;
                        tn.ForeColor = Color.Blue;
                    }
                    tnSelected = tvReactions.Nodes[0].Nodes[curRecIndx - 1];//currRxnIndex
                    tnSelected.ForeColor = Color.Red;
                    tnSelected.SelectedImageIndex = 2;
                    tvReactions.SelectedNode = tnSelected;        
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        bool blValidRxn = false;
        private void numGotoRecord_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (blValidRxn)
                {
                    if (numGotoRecord.Value > 0)
                    {
                        lblRxnSaveMsg.Text = "";

                        Cursor = Cursors.WaitCursor;

                        currRxnIndex = Convert.ToInt32(numGotoRecord.Value);
                       
                        SetReactionLabelsOnReactionIndex(Convert.ToInt32(currRxnIndex - 1));

                        //Select Reaction in the TreeView
                        SelectReactionNodeInTheTreeView(currRxnIndex);   

                        GetReactionPartpntsAndCreateStagesOnRxnID(reactionID);

                        //Show Total No.of Reactions with current Reaction index
                        lblRxnCnt.Text = currRxnIndex + " / " + numGotoRecord.Maximum.ToString();
                        lblRxnCnt.Refresh();

                        Cursor = Cursors.Default;
                    }
                    else
                    {
                        RxnProductsTbl = null;
                        dgvProduct.DataSource = null;
                        tcStages.TabPages.Clear();

                        //Show Total No.of Reactions with current Reaction index
                        lblRxnCnt.Text = currRxnIndex + " / " + numGotoRecord.Maximum.ToString();
                        lblRxnCnt.Refresh();

                        if (ReactionsTbl.Rows.Count == 0)
                        {
                            lblRxnCnt.Text = "0 / 0";
                            lblRxnCnt.Refresh();

                            lblProdNum.Text = "";
                            lblRxnSeqVal.Text = "";
                        }                       

                        Cursor = Cursors.Default;
                    }
                }
                else
                {
                    //Show Total No.of Reactions with current Reaction index
                    lblRxnCnt.Text = currRxnIndex + " / " + numGotoRecord.Maximum.ToString();
                    lblRxnCnt.Refresh();

                    if (ReactionsTbl.Rows.Count == 0)
                    {
                        lblRxnCnt.Text = "0 / 0";
                        lblRxnCnt.Refresh();

                        lblProdNum.Text = "";
                        lblRxnSeqVal.Text = "";
                    }   

                    Cursor = Cursors.Default;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void numGotoRecord_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                string strErrMSg = "";
                string strErrSrc = "";
                blValidRxn = false;

                if (!SaveReactionData_New(out strErrMSg, out strErrSrc))
                {
                    if (strErrMSg.Trim() != "")
                    {
                        MessageBox.Show("Errors in the Reaction. Clear the below errors before moving to another reaction\r\n\r\n" + strErrMSg, strErrSrc, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        e.Handled = true;
                    }
                }
                else
                {
                    blValidRxn = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        int int9000 = 0;
        int int8500 = 0;
        int intNum = 0;
        int int8000 = 0;
        int intNRNReg = 0;

        private void dgProduct_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dgvProduct.Columns[e.ColumnIndex].Name.ToUpper() == "P_NAME")
                {
                    int8000 = 0;
                    int.TryParse(dgvProduct.Rows[e.RowIndex].Cells["P_8000"].Value.ToString(), out int8000);
                    if (int8000 > 0)
                    {
                        dgvProduct.Columns["P_NAME"].ReadOnly = true;
                    }
                    else
                    {
                        int.TryParse(dgvProduct.Rows[e.RowIndex].Cells["P_NUM"].Value.ToString(), out intNum);
                        int.TryParse(dgvProduct.Rows[e.RowIndex].Cells["P_9000"].Value.ToString(), out int9000);
                        int.TryParse(dgvProduct.Rows[e.RowIndex].Cells["P_8500"].Value.ToString(), out int8500);

                        if (intNum > 0 || int9000 > 0 || int8500 > 0)
                        {
                            dgvProduct.Columns["P_NAME"].ReadOnly = true;
                        }
                        else
                        {
                            dgvProduct.Columns["P_NAME"].ReadOnly = false;
                        }
                    }
                }
                else if (dgvProduct.Columns[e.ColumnIndex].Name.ToUpper() == "P_NUM")
                {
                    if (dgvProduct.Rows[e.RowIndex].Cells["P_Num"].Value != null)
                    {
                        int8000 = 0;
                        int.TryParse(dgvProduct.Rows[e.RowIndex].Cells["P_8000"].Value.ToString(), out int8000);
                        if (int8000 > 0)
                        {
                            dgvProduct.Columns["P_Num"].ReadOnly = true;
                        }
                        else
                        {
                            int.TryParse(dgvProduct.Rows[e.RowIndex].Cells["P_9000"].Value.ToString(), out int9000);
                            int.TryParse(dgvProduct.Rows[e.RowIndex].Cells["P_8500"].Value.ToString(), out int8500);

                            if (int9000 > 0 || int8500 > 0)
                            {
                                dgvProduct.Columns["P_Num"].ReadOnly = true;
                            }
                            else
                            {
                                dgvProduct.Columns["P_Num"].ReadOnly = false;
                            }
                        }
                    }
                }                
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void SetSubstantcColumnValuesToNull(int rowindex)
        {
            try
            {
                dgvProduct.Rows[rowindex].Cells["P_8000"].Value = 0;

                dgvProduct.Rows[rowindex].Cells["SUBST_NUM"].Value = 0;
                dgvProduct.Rows[rowindex].Cells["SUBSTNAME"].Value = "";
                dgvProduct.Rows[rowindex].Cells["SUBSTLOC"].Value = "";
                dgvProduct.Rows[rowindex].Cells["SUBST_MOL_IMAGE"].Value = null;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        
                
        private bool ValidateP_8000Series(string strP_8000)
        {
            bool blStatus = false;
            try
            {
                if (strP_8000.Trim() != "")
                {
                    int int8000 = 0;
                    if (int.TryParse(strP_8000, out int8000))
                    {
                        if (int8000 > 8000 && int8000 < 8500)
                        {
                            blStatus = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }
               
        private void dgProduct_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                if (dgvProduct.CurrentCell.RowIndex == 0)//Disable first row to restrict editing
                {
                    dgvProduct.Rows[0].Cells["colProdNum"].ReadOnly = true;
                    //dgvProduct.Rows[0].Cells["P_9000"].ReadOnly = true;
                    //dgvProduct.Rows[0].Cells["P_8500"].ReadOnly = true;
                    //dgvProduct.Rows[0].Cells["P_8000"].ReadOnly = true;
                    dgvProduct.Rows[0].Cells["colProdName"].ReadOnly = true;                  
                }               
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgProduct_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvProduct.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvProduct.Font);

                if (dgvProduct.RowHeadersWidth < (int)(size.Width + 20)) dgvProduct.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        int intSelVal = 0;
        DataGridViewComboBoxEditingControl combo = null;

        string out_Reaction = "";
        string out_Location = "";
        string out_Partpnt = "";

        DataTable dtTemp = null;
        string strID = "";

        string subst_name = "";
        string subst_loc = "";
        string subst_mol = "";
        string author_name = "";
        string other_name = "";
        string strErrMsg = "";
              
        private bool CheckIfNUMUsedInParticipant(int _num, string _srcCol, out string _errmsg)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                if (tcStages.TabCount > 0)
                {
                    ucParticipants ucPartpnt = null;

                    DataTable dtReactant = null;
                    DataTable dtAgent = null;
                    DataTable dtSolvent = null;
                    DataTable dtCatalyst = null;
                    string strStageName = "";

                    for (int i = 0; i < tcStages.TabPages.Count; i++)
                    {
                        ucPartpnt = (ucParticipants)tcStages.TabPages[i].Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            strStageName = ucPartpnt.StageName;
                            dtReactant = ucPartpnt.dtReactant;
                            dtAgent = ucPartpnt.dtAgent;
                            dtSolvent = ucPartpnt.dtSolvent;
                            dtCatalyst = ucPartpnt.dtCatalyst;

                            if (CheckIfNumExistInTable(dtReactant, _srcCol, _num))
                            {
                                strErrMsg = _num + " already used in the REACTANT of " + strStageName;
                                blStatus = true;
                                _errmsg = strErrMsg;
                                return blStatus;
                            }
                            else
                            {
                                if (CheckIfNumExistInTable(dtAgent, _srcCol, _num))
                                {
                                    strErrMsg = _num + " already used in the AGENT of " + strStageName;
                                    blStatus = true;
                                    _errmsg = strErrMsg;
                                    return blStatus;
                                }
                                else
                                {
                                    if (CheckIfNumExistInTable(dtSolvent, _srcCol, _num))
                                    {
                                        strErrMsg = _num + " already used in the SOLVENT of " + strStageName;
                                        blStatus = true;
                                        _errmsg = strErrMsg;
                                        return blStatus;
                                    }
                                    else
                                    {
                                        if (CheckIfNumExistInTable(dtCatalyst, _srcCol, _num))
                                        {
                                            strErrMsg = _num + " already used in the CATALYST of " + strStageName;
                                            blStatus = true;
                                            _errmsg = strErrMsg;
                                            return blStatus;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg;
            return blStatus;
        }

        private bool CheckIfNumExistInTable(DataTable _dtpartpnt, string _srcCol, int _nrnnum)
        {
            bool blStatus = false;
            try
            {
                if (_dtpartpnt != null)
                {
                    if (_dtpartpnt.Rows.Count > 0)
                    {
                        DataRow[] dtRArr_R = null;
                        if (_srcCol.ToUpper() == "SERIES_NUM")
                        {
                            dtRArr_R = _dtpartpnt.Select("SERIES_NUM = " + _nrnnum);
                            if (dtRArr_R.Length > 0)
                            {
                                blStatus = true;
                            }
                        }
                        //else if (_srcCol.ToUpper() == "_9000")
                        //{
                        //    dtRArr_R = _dtpartpnt.Select("P_9000 = " + _nrnnum);
                        //    if (dtRArr_R.Length > 0)
                        //    {
                        //        blStatus = true;
                        //    }
                        //}
                        //else if (_srcCol.ToUpper() == "_8500")
                        //{
                        //    dtRArr_R = _dtpartpnt.Select("P_8500 = " + _nrnnum);
                        //    if (dtRArr_R.Length > 0)
                        //    {
                        //        blStatus = true;
                        //    }
                        //}
                        //else if (_srcCol.ToUpper() == "_8000")
                        //{
                        //    dtRArr_R = _dtpartpnt.Select("P_8000 = " + _nrnnum);
                        //    if (dtRArr_R.Length > 0)
                        //    {
                        //        blStatus = true;
                        //    }
                        //}
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private void CheckAndSetAutoComments()
        {
            try
            {
                if (!string.IsNullOrEmpty(TAN_Name))
                {
                    int _p8000 = 0;
                    int _p8500 = 0;
                    int _r8000 = 0;
                    int _r8500 = 0;
                    int int8000Len_P = 0;
                    int int8500Len_P = 0;
                    int int8000Len_R = 0;
                    int int8500Len_R = 0;

                    DataTable dt8000_8500 = ReactDB.Get8000And8500ValuesOnTAN_ID(TAN_ID);

                    if (dt8000_8500 != null && dt8000_8500.Rows.Count > 0)
                    {
                        //Series 8000 & 8500 in Product
                        int8000Len_P = Get8000_8500_Val_Length(dt8000_8500, "8000", "PRODUCT");
                        _p8000 = (int8000Len_P > 0) ? 8000 : 0;

                        int8500Len_P = Get8000_8500_Val_Length(dt8000_8500, "8500", "PRODUCT");
                        _p8500 = (int8500Len_P > 0) ? 8500 : 0;

                        //Series 8000 & 8500 in Reactant
                        int8000Len_R = Get8000_8500_Val_Length(dt8000_8500, "8000", "REACTANT");
                        _r8000 = (int8000Len_R > 0) ? 8000 : 0;

                        int8500Len_R = Get8000_8500_Val_Length(dt8000_8500, "8500", "REACTANT");
                        _r8500 = (int8500Len_R > 0) ? 8500 : 0;
                    }

                    //Series 8000 and 8500 Comments
                    string strComments = GenerateComments.GetComments_On_8000_8500(_p8000, _p8500, _r8000, _r8500);
                    DefaultComments = strComments;

                    //Plus_Minus Temperature Comments
                    DataTable dtTemprature = ReactDB.GetPlusOrMinusTemperatureData(TAN_ID);
                    TemperatureComments = Common.GenerateComments.GetCommentsOnTemperature(dtTemprature);

                    //Set Comments to Comments TextBox
                    SetCommentsToCommentsTextBox_New();
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        
        
        private int Get8000_8500_Val_Length(DataTable _dt8000_8500, string _srcCol, string prod_reactant)
        {
            int intLen = 0;
            try
            {
                if (_dt8000_8500 != null)
                {
                    DataRow[] dtRArr = _dt8000_8500.DefaultView.ToTable().Select("SER_TYPE = '" + _srcCol + "' and PP_TYPE = '" + prod_reactant + "'");
                    if (dtRArr != null)
                    {
                        if (dtRArr.Length > 0)
                        {
                            intLen = dtRArr.Length;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return intLen;
        }

        private bool Get8000Comb_SubstName_LocValues(int _num8000, out string o_substname, out string o_substloc)
        {
            bool blStatus = false;
            try
            {
                if (TAN_8000_CombTbl != null)
                {
                    if (TAN_8000_CombTbl.Rows.Count > 0)
                    {
                        DataTable dt8000_Comb = TAN_8000_CombTbl;

                        string strFilter = "ser8000 = " + _num8000;
                        DataRow[] dtRArr = dt8000_Comb.Select(strFilter);
                        if (dtRArr != null)
                        {
                            if (dtRArr.Length > 0)
                            {
                                o_substname = dtRArr[0]["subst_name"].ToString();
                                o_substloc = dtRArr[0]["subst_loc"].ToString();
                                blStatus = true;
                                return blStatus;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            o_substname = "";
            o_substloc = "";
            return blStatus;
        }
          
        private void TextBox_KeyPress(System.Object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            try
            {
                if (((e.KeyChar >= 48 && e.KeyChar <= 57) || e.KeyChar == 8 || e.KeyChar == 44) != true)
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        string molColumn = "";
        int rowIndx = 0;
        int intNrnReg = 0;
        int intNrnNUM = 0;

        private void dgvProduct_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex < 0 || e.ColumnIndex < 0)
                    return;

                molColumn = "";

                if (dgvProduct.Columns[e.ColumnIndex].Name.ToString().ToUpper() == "SUBST_MOL_IMAGE")
                {
                    if (RxnProductsTbl.Rows[e.RowIndex]["subst_molecule"] != null)
                    {
                        if (RxnProductsTbl.Rows[e.RowIndex]["subst_molecule"].ToString() != "")
                        {
                            frmSubstMolImg objSubstMolImg = new frmSubstMolImg();
                            objSubstMolImg.MolFile = RxnProductsTbl.Rows[e.RowIndex]["subst_molecule"].ToString();
                            objSubstMolImg.ShowDialog();
                        }
                    }
                }
                else if (dgvProduct.Columns[e.ColumnIndex].HeaderText.ToString().ToUpper() == "NUM")
                {
                    //int.TryParse(dgvProduct.Rows[e.RowIndex].Cells[colProdRegNo.Name].Value.ToString(), out intNrnReg);
                    //int.TryParse(dgvProduct.Rows[e.RowIndex].Cells[colProdNum.Name].Value.ToString(), out intNrnNUM);
                    //GetNUMInfoFromCGM(intNrnReg, intNrnNUM);

                    int serNumID = 0;
                    int.TryParse(dgvProduct.Rows[e.RowIndex].Cells[colProdSerNumID.Name].Value.ToString(), out serNumID);
                    string colSerType = dgvProduct.Rows[e.RowIndex].Cells[colProdNumType.Name].Value.ToString().ToUpper();
                    //Get Structure properties on SerNumID & SeriesType
                    ChemStructure objChemStruct = GetStructurePropertiesOnSeriesNumID(serNumID, colSerType);
                    if (objChemStruct != null)
                    {
                        BindStructurePropsToNumsInfo(objChemStruct);
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }


        private void GetNUMInfoFromCGM(int regNo, int nrnNUM)
        {
            try
            {
                if (regNo > 0 && nrnNUM > 0)
                {
                    frmNUMInfo objNumInfo = new frmNUMInfo();
                    objNumInfo.BindDataToStructurePanel(regNo, nrnNUM);
                    objNumInfo.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindStructurePropsToNumsInfo(ChemStructure chemStruct)
        {
            try
            {
                if (chemStruct != null)
                {
                    frmNUMInfo objNumInfo = new frmNUMInfo();
                    objNumInfo.BindStructureDataToPanel(chemStruct);
                    objNumInfo.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private ChemStructure GetStructurePropertiesOnSeriesNumID(int serNumID, string serNumType)
        {
            ChemStructure chemStruct = null;
            try
            {
                if (serNumID > 0 && !string.IsNullOrEmpty(serNumType))
                {
                    if (serNumType.ToUpper() == "NUM")
                    {
                        var rows = TANNUMsTbl.AsEnumerable().Where(r => r.Field<Int64>("TAN_NUM_ID") == serNumID);
                        if (rows != null)
                        {
                            if (rows.Count() > 0)
                            {
                                foreach (DataRow dr in rows)
                                {
                                    chemStruct = new ChemStructure();
                                    chemStruct.SeriesNum = dr["NUM"].ToString();
                                    chemStruct.RegNo = dr["REG_NO"].ToString();
                                    chemStruct.MolFormula = dr["FORMULA"].ToString();
                                    chemStruct.MolName = dr["IUPAC_NAME"].ToString();
                                    chemStruct.MolStructure = dr["MOL_FILE"].ToString();
                                    chemStruct.MolSynonym = dr["OTHER_NAMES"].ToString();
                                    chemStruct.MolHexArr = new string[] { dr["MOL_HEX_CODE"].ToString() };
                                    chemStruct.PeptideSeq = dr["PEPTIDE_SEQ"].ToString();
                                    chemStruct.NuclicAcidSeq = dr["NUCLIC_ACID_SEQ"].ToString();
                                    //chemStruct.AbsoluteStrereo = new string[] { dr["MOL_HEX_CODE"].ToString() }; 
                                }
                            }
                        }
                    }
                    else if (serNumType.ToUpper() == "9000")
                    {
                        var rows = GlobalVariables.Ser9000OrgRefData.AsEnumerable().Where(r => r.Field<string>("ORGREF_ID") == serNumID.ToString());
                        if (rows != null)
                        {
                            if (rows.Count() > 0)
                            {
                                foreach (DataRow dr in rows)
                                {
                                    chemStruct = new ChemStructure();
                                    chemStruct.SeriesNum = dr["NUM"].ToString();
                                    chemStruct.RegNo = dr["REG_NO"].ToString();
                                    chemStruct.MolName = dr["ORGREF_NAME"].ToString();
                                    chemStruct.MolStructure = dr["MOL_FILE"].ToString();
                                }
                            }
                        }
                    }
                    else if (serNumType.ToUpper() == "8500")
                    {
                        var rows = GlobalVariables.TAN_Series8500Data.AsEnumerable().Where(r => r.Field<string>("ORGREF_ID") == serNumID.ToString());
                        if (rows != null)
                        {
                            if (rows.Count() > 0)
                            {
                                foreach (DataRow dr in rows)
                                {
                                    chemStruct = new ChemStructure();
                                    chemStruct.SeriesNum = dr["SERIES_8500"].ToString();
                                    chemStruct.RegNo = dr["REG_NO"].ToString();
                                    chemStruct.MolName = dr["ORGREF_NAME"].ToString();
                                    chemStruct.MolStructure = dr["MOL_FILE"].ToString();
                                }
                            }
                        }
                    }
                    else if (serNumType.ToUpper() == "8000")
                    {
                        var rows = GlobalVariables.TAN_Series8000Data.AsEnumerable().Where(r => r.Field<Int64>("TS_ID") == serNumID);
                        if (rows != null)
                        {
                            if (rows.Count() > 0)
                            {
                                foreach (DataRow dr in rows)
                                {
                                    chemStruct = new ChemStructure();
                                    chemStruct.SeriesNum = dr["SERIES_8000"].ToString();
                                    chemStruct.MolName = dr["SUBST_NAME"].ToString();
                                    chemStruct.MolStructure = dr["SUBST_MOLECULE"].ToString();
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return chemStruct;
        }

        private void dgvProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                {
                    string strErrMsg = "";

                    if (e.RowIndex > 0)//Row at 0 position is ReadOnly
                    {
                        if (dgvProduct.Columns[e.ColumnIndex].HeaderText.ToString().ToUpper() == "NUM")
                        {
                            using (frmNUMs objNUMs = new frmNUMs())
                            {
                                objNUMs.TAN_NUMsTbl = TANNUMsTbl;
                                objNUMs.SrcParticipant = "PRODUCT";
                                if (objNUMs.ShowDialog(this) == DialogResult.OK)
                                {
                                    if (objNUMs.Sel_NUM > 0)
                                    {
                                        if (!CheckIfNUMUsedInParticipant(objNUMs.Sel_NUM, "SER_NUM", out strErrMsg))
                                        {
                                            dgvProduct.Rows[e.RowIndex].Cells[colProdNum.Name].Value = objNUMs.Sel_NUM;
                                            dgvProduct.Rows[e.RowIndex].Cells[colProdRegNo.Name].Value = objNUMs.Sel_RegNo;
                                            dgvProduct.Rows[e.RowIndex].Cells[colProdName.Name].Value = objNUMs.Sel_Name;
                                        }
                                        else
                                        {
                                            MessageBox.Show(strErrMsg, "", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                                            dgvProduct.Rows[e.RowIndex].Cells[colProdNum.Name].Value = 0;
                                            dgvProduct.Rows[e.RowIndex].Cells[colProdRegNo.Name].Value = 0;
                                            dgvProduct.Rows[e.RowIndex].Cells[colProdName.Name].Value = "";
                                        }
                                    }
                                    else
                                    {
                                        dgvProduct.Rows[e.RowIndex].Cells[colProdNum.Name].Value = 0;
                                        dgvProduct.Rows[e.RowIndex].Cells[colProdRegNo.Name].Value = 0;
                                        dgvProduct.Rows[e.RowIndex].Cells[colProdName.Name].Value = "";
                                    }
                                    dgvProduct.CommitEdit(DataGridViewDataErrorContexts.Commit);
                                }
                            }
                        }
                        else if (dgvProduct.Columns[e.ColumnIndex].Name.ToString().ToUpper() == "COLDELETEPROD")//Delete Participant
                        {
                            DialogResult diaRes = MessageBox.Show("Do you want to delete the selected Product?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                            if (diaRes == DialogResult.Yes)
                            {
                                int intRppID = Convert.ToInt32(dgvProduct.Rows[e.RowIndex].Cells[colRPPID.Name].Value);

                                if (intRppID > 0)
                                {
                                    if (ReactDB.DeleteReactionParticipant(intRppID, "PRODUCT"))
                                    {
                                        DeleteProductFromProductTable(e.RowIndex);

                                        //Update Default Comments and User comments Here
                                        CheckAndSetAutoComments();

                                        //Update TAN Comments - 11 Aug 2014
                                        TANCommentsBO tanComments = GetTANCommentsFromTable();
                                        if (tanComments != null)
                                        {
                                            if (ReactDB.UpdateCommentsOnTANID(tanComments))
                                            {
                                                TANCommentsData = ReactDB.GetTANCommentsOnTANID(TAN_ID);
                                            }
                                        }
                                       
                                        //Refresh Reactions table                                   
                                        ReactionsTbl = ReactDB.GetReactionsOnTANID(TAN_ID);

                                        //Refresh Reaction
                                        RefreshReactionView();
                                    }
                                    else
                                    {
                                        MessageBox.Show("Error in Product delete", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }
                                }
                            }
                        }
                    }

                    //RegNo Search
                     if (dgvProduct.Columns[e.ColumnIndex].HeaderText.ToString().ToUpper() == "REGNO")
                     {
                         if (dgvProduct.Rows[e.RowIndex].Cells[colProdRegNo.Name].Value != null)
                         {
                             int intRegNo = 0;
                             int.TryParse(dgvProduct.Rows[e.RowIndex].Cells[colProdRegNo.Name].Value.ToString(), out intRegNo);
                             if (intRegNo > 0)
                             {
                                 frmSrch_RegNo objSrchRegNo = new frmSrch_RegNo();
                                 objSrchRegNo.TAN_Name = txtTAN.Text.Trim();
                                 objSrchRegNo.TAN_ID = TAN_ID;
                                 objSrchRegNo.RegNo = intRegNo;
                                 objSrchRegNo.SeriesNumID = Convert.ToInt32(dgvProduct.Rows[e.RowIndex].Cells[colProdSerNumID.Name].Value);
                                 objSrchRegNo.SeriesType = dgvProduct.Rows[e.RowIndex].Cells[colProdNumType.Name].Value.ToString();
                                 objSrchRegNo.ShowDialog();
                             }
                         }
                    }
                    else if (dgvProduct.Columns[e.ColumnIndex].HeaderText.ToString().ToUpper() == "NAME")
                    {
                        if (!string.IsNullOrEmpty(dgvProduct.Rows[e.RowIndex].Cells[colProdName.Name].Value.ToString()))
                        {
                            frmSrch_RegNo objSrchRegNo = new frmSrch_RegNo();
                            objSrchRegNo.TAN_Name = txtTAN.Text.Trim();
                            objSrchRegNo.TAN_ID = TAN_ID;
                            objSrchRegNo.RegNo = 0;
                            objSrchRegNo.PP_Name = dgvProduct.Rows[e.RowIndex].Cells[colProdName.Name].Value.ToString();
                            objSrchRegNo.SeriesNumID = Convert.ToInt32(dgvProduct.Rows[e.RowIndex].Cells[colProdSerNumID.Name].Value);
                            objSrchRegNo.SeriesType = dgvProduct.Rows[e.RowIndex].Cells[colProdNumType.Name].Value.ToString();                           
                            objSrchRegNo.ShowDialog();
                        }
                    }  
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        

        private DataTable GetProductDataTableDefinition()
        {
            try
            {
                DataTable dtProd = new DataTable();
                dtProd.Columns.Add("RPP_ID", typeof(Int32));
                dtProd.Columns.Add("RXN_ID", typeof(Int32));
                dtProd.Columns.Add("PP_NAME", typeof(string));                
               
                dtProd.Columns.Add("YIELD", typeof(Int32));
                dtProd.Columns.Add("REG_NO", typeof(string));                
                dtProd.Columns.Add("SER_TYPE", typeof(string));

                dtProd.Columns.Add("SERIES_NUM", typeof(Int32));
                dtProd.Columns.Add("SERIES_NUM", typeof(Int32));
                dtProd.Columns.Add("SERIES_NUM", typeof(Int32));
                dtProd.Columns.Add("SERIES_NUM", typeof(Int32));

                //dtProd.Columns.Add("SERIES_9000", typeof(Int32));
                //dtProd.Columns.Add("SERIES_8500", typeof(Int32));
                //dtProd.Columns.Add("SERIES_8000", typeof(Int32));
                //dtProd.Columns.Add("Subst_num", typeof(Int32));
                //dtProd.Columns.Add("SUBST_NAME", typeof(string));
                //dtProd.Columns.Add("SUBST_LOC", typeof(string));
                //dtProd.Columns.Add("SUBST_AUTHOR_NAME", typeof(string));
                //dtProd.Columns.Add("SUBST_OTHER_NAME", typeof(string));
                //dtProd.Columns.Add("STRUCT_MOLFILE", typeof(object));
                //dtProd.Columns.Add("STRUCT_IMAGE", typeof(Image));

                dtProd.Columns.Add("DISPLAY_ORDER", typeof(Int32));
                //dtProd.Columns.Add("created_by", typeof(Int32));

                return dtProd;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return null;
        } 
      
        private void DeleteProductFromProductTable(int rowindex)
        {
            try
            {
                if (RxnProductsTbl != null)
                {
                    if (RxnProductsTbl.Rows.Count > 0)
                    {
                        RxnProductsTbl.Rows[rowindex].Delete();
                        RxnProductsTbl.AcceptChanges();
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private List<Product_ParticipantBO> GetProductDetailsFromProductGrid(int _rxnID)
        {
            List<Product_ParticipantBO> lstProduct = null;
            try
            {
                if (dgvProduct.Rows.Count > 0)
                {
                    lstProduct = new List<Product_ParticipantBO>();

                    DataTable dtProdDetails = (DataTable)dgvProduct.DataSource;
                    if (dtProdDetails != null)
                    {
                        int intP_Num = 0;
                        //int intP_9000 = 0;
                        //int intP_8500 = 0;
                        //int intP_8000 = 0;
                        //int intSubstNum = 0;

                        for (int i = 0; i < dtProdDetails.Rows.Count; i++)
                        {
                            Product_ParticipantBO objProd = new Product_ParticipantBO();

                            objProd.RPP_ID = Convert.ToInt32(dtProdDetails.Rows[i]["RPP_ID"].ToString());
                            objProd.RxnID = _rxnID;
                            objProd.RxnStageID = null;
                            //objProd.PP_Name = dtProdDetails.Rows[i]["PP_NAME"].ToString();

                            #region MyRegion
                            //objProd.MolSketch = dtProdDetails.Rows[i]["STRUCT_MOLFILE"].ToString();

                            //if (dtProdDetails.Rows[i]["STRUCT_IMAGE"] != null)
                            //{
                            //    if (dtProdDetails.Rows[i]["STRUCT_IMAGE"].ToString() != "")
                            //    {
                            //        //objProd.Mol_Image = ImageConversion.imageToByteArray((Image)dtProdDetails.Rows[i]["molecule_image"]);
                            //        objProd.Mol_Image = (byte[])dtProdDetails.Rows[i]["STRUCT_IMAGE"];
                            //    }
                            //    else
                            //    {
                            //        objProd.Mol_Image = null;
                            //    }
                            //}
                            //else
                            //{
                            //    objProd.Mol_Image = null; 
                            #endregion
                            //}

                            objProd.Yield = dtProdDetails.Rows[i]["YIELD"].ToString();

                            //objProd.RegNo = dtProdDetails.Rows[i]["REG_NO"] != null ? dtProdDetails.Rows[i]["REG_NO"].ToString() : "0";

                            int.TryParse(dtProdDetails.Rows[i]["SER_TAN_NUM_ID"].ToString(), out intP_Num);
                            objProd.SeriesNumID = intP_Num;

                            objProd.SeriesType = dtProdDetails.Rows[i]["SER_TYPE"].ToString();

                            #region MyRegion
                            //int.TryParse(dtProdDetails.Rows[i]["SERIES_9000"].ToString(), out intP_9000);
                            //objProd.Series9000 = intP_9000;

                            //int.TryParse(dtProdDetails.Rows[i]["SERIES_8500"].ToString(), out intP_8500);
                            //objProd.Series8500 = intP_8500;

                            //int.TryParse(dtProdDetails.Rows[i]["SERIES_8000"].ToString(), out intP_8000);
                            //objProd.Series8000 = intP_8000;

                            //int.TryParse(dtProdDetails.Rows[i]["SUBST_NUM"].ToString(), out intSubstNum);
                            //objProd.Subst_Num = intSubstNum;

                            //objProd.SubstName = dtProdDetails.Rows[i]["SUBST_NAME"].ToString();
                            //if (dtProdDetails.Rows[i]["STRUCT_IMAGE"] != null)
                            //{
                            //    if (dtProdDetails.Rows[i]["STRUCT_IMAGE"] != "")
                            //    {
                            //        objProd.SubstMolecule = dtProdDetails.Rows[i]["STRUCT_MOLFILE"];
                            //    }
                            //}
                            //objProd.SubstLocation = dtProdDetails.Rows[i]["SUBST_LOC"].ToString();
                            //objProd.SubstAuthorName = dtProdDetails.Rows[i]["SUBST_AUTHOR_NAME"].ToString();
                            //objProd.SubstOtherName = dtProdDetails.Rows[i]["SUBST_OTHER_NAME"].ToString(); 
                            #endregion

                            objProd.PPType = "PRODUCT";
                            objProd.UserID = GlobalVariables.URID;

                            lstProduct.Add(objProd);
                        }
                    }
                    return lstProduct;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstProduct;
        }

        private void btnAddRxn_Click(object sender, EventArgs e)
        {
            try
            {
                if (TAN_ID > 0)
                {
                    string strErrMSg = "";
                    string strErrSrc = "";
                    blValidRxn = false;

                    if (SaveReactionData_New(out strErrMSg, out strErrSrc))
                    {
                        blValidRxn = true;

                        #region MyRegion
                        //frmNewRxn_New objNewRxn = new frmNewRxn_New();
                        //objNewRxn.TAN_ID = TAN_ID;
                        //objNewRxn.TANID = TAN_Name;
                        //objNewRxn.CurrentRxnNUM = lblProdNum.Text.Trim();
                        //objNewRxn.CurrentRxnSeq = lblRxnSeqVal.Text.Trim();
                        //objNewRxn.RxnNum_SeqData = ReactionsTbl;
                        //objNewRxn.NUM_RegNoTbl = TANNUMsTbl;

                        //if (objNewRxn.ShowDialog() == DialogResult.OK)
                        //{
                        //    if (objNewRxn.NewRxnID > 0)
                        //    {
                        //        lblProdNum.Text = objNewRxn.RxnNum.ToString();
                        //        lblRxnSeqVal.Text = objNewRxn.RxnSeq.ToString();
                        //        reactionID = objNewRxn.NewRxnID;

                        //        ReactionsTbl = ReactDataAccess.GetReactionsOnTANID(TAN_ID);
                        //        MaxRecCnt = ReactionsTbl.Rows.Count;

                        //        //Disable UpDown buttons
                        //        numGotoRecord.Controls[0].Enabled = false;
                        //        numGotoRecord.Maximum = MaxRecCnt;
                        //        currRxnIndex = 1;
                        //        numGotoRecord.Minimum = 1;
                        //        numGotoRecord.Value = MaxRecCnt;

                        //        #region MyRegion
                        //        //_RxnNum = Convert.ToInt32(objNewRxn.RxnNum);

                        //        ////Add new Reaction to Reactions Table and set max reactions count
                        //        //AddNewRowToReactionsTable(objNewRxn.RxnNum, objNewRxn.RxnSeq, TAN_ID, reactionID, objNewRxn.DisplayOrder, objNewRxn.RxnRowIndx, objNewRxn.BeforeAfter);

                        //        ////Enable Navigation controls                            
                        //        //EnableNavigationControls();

                        //        //RxnProductsTbl = null;

                        //        //GetProductDetailsAndBindToGrid(objNewRxn.RxnNum);
                        //        //if (!objNewRxn.DuplicateRxn)
                        //        //{
                        //        //    AddStageonLoad();
                        //        //}

                        //        //MaxRecCnt = ReactionsTbl.Rows.Count;
                        //        //numGotoRecord.Maximum = MaxRecCnt;
                        //        //if (objNewRxn.BeforeAfter == "AFTER")
                        //        //{
                        //        //    currRecIndex = objNewRxn.RxnRowIndx + 2;
                        //        //}
                        //        //else if (objNewRxn.BeforeAfter == "BEFORE" || objNewRxn.BeforeAfter == "END")
                        //        //{
                        //        //    currRecIndex = objNewRxn.RxnRowIndx + 1;
                        //        //}

                        //        //numGotoRecord.Value = currRecIndex;
                        //        //if (numGotoRecord.Value == currRecIndex)
                        //        //{
                        //        //    numGotoRecord_ValueChanged(null, null);
                        //        //} 
                        //        #endregion

                        //        pnlProduct.Enabled = true;
                        //        tcStages.Enabled = true;

                        //        //Disable NewReaction button
                        //        btnAddRxn.Enabled = false;

                        //        //Check and set comments in the patent
                        //        CheckAndSetAutoComments();
                        //    }
                        //} 
                        #endregion

                        frmNUMs objNUMs = new frmNUMs();
                        objNUMs.TAN_NUMsTbl = TANNUMsTbl;
                        objNUMs.IsNewRxn = true;
                        objNUMs.TANReactionsData = ReactionsTbl;
                        objNUMs.CurrentRxnNUM = lblProdNum.Text.Trim();
                        objNUMs.CurrentRxnSeq = lblRxnSeqVal.Text.Trim();
                        objNUMs.CurrentRxnID =reactionID;
                        objNUMs.TAN_ID = TAN_ID;

                        if (objNUMs.ShowDialog() == DialogResult.OK)
                        {
                            if (objNUMs.NewRxnID > 0)
                            {
                                lblProdNum.Text = objNUMs.RxnNum.ToString();
                                lblRxnSeqVal.Text = objNUMs.RxnSeq.ToString();

                                reactionID = objNUMs.NewRxnID;

                                //Get All the reactions
                                ReactionsTbl = ReactDB.GetReactionsOnTANID(TAN_ID);

                                //Refresh Reactions Treeview
                                BindReactionsToTreeView(ReactionsTbl);

                                //Disable UpDown buttons
                                MaxRecCnt = ReactionsTbl.Rows.Count;
                                numGotoRecord.Controls[0].Enabled = false;
                                numGotoRecord.Maximum = MaxRecCnt;                               
                                numGotoRecord.Minimum = 1;
                                
                                //Get Display order/row index on RXN_ID
                                if (objNUMs.BeforeAfter == "AFTER")
                                {
                                    if (MaxRecCnt > 1)
                                    {
                                        currRxnIndex = objNUMs.RxnRowIndx + 2;
                                    }
                                    else
                                    {
                                        currRxnIndex = 1;
                                    }
                                }
                                else if (objNUMs.BeforeAfter == "BEFORE" || objNUMs.BeforeAfter == "END")
                                {
                                    currRxnIndex =  objNUMs.RxnRowIndx + 1;
                                }

                                if (numGotoRecord.Value == currRxnIndex)
                                {
                                    numGotoRecord.Value = currRxnIndex;
                                    numGotoRecord_ValueChanged(null, null);
                                }
                                else
                                {
                                    numGotoRecord.Value = currRxnIndex;
                                }

                                pnlProduct.Enabled = true;
                                tcStages.Enabled = true;

                                //Disable NewReaction button
                                btnAddRxn.Enabled = false;
                            }
                        }
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(strErrMSg.Trim()))
                        {
                            MessageBox.Show("Errors in the Reaction. Clear the below errors before creating another reaction\r\n\r\n" + strErrMSg, strErrSrc, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }                  

                    #region Code Commented
                    //if (txtRxnNum.Text.Trim() != "" && txtrxn_seq.Text.Trim() != "")
                    //{
                    //    DialogResult diaRes = MessageBox.Show("Do you want to create a new reaction?", "Create Reaction", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    //    if (diaRes == DialogResult.Yes)
                    //    {
                    //        int intRxnNum = Convert.ToInt32(txtRxnNum.Text.Trim());
                    //        int intRxnSeq = Convert.ToInt32(txtrxn_seq.Text.Trim());

                    //        if (intRxnNum > 0 && intRxnSeq > 0)
                    //        {
                    //            int intRxnID = CASRxnDataAccess.Insert_Get_NewReactionID(_intpatentID, intRxnNum, intRxnSeq);

                    //            if (intRxnID > 0)
                    //            {
                    //                _intReactionID = intRxnID;

                    //                _ProdDataTbl = null;

                    //                GetProductDetailsAndBindToGrid(intRxnNum);
                    //                AddStageonLoad();

                    //                pnlProduct.Enabled = true;
                    //                tbStages.Enabled = true;
                    //            }
                    //            else
                    //            {
                    //                MessageBox.Show("Duplicate Reaction", "Add Reaction", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //            }
                    //        }
                    //        else
                    //        {
                    //            MessageBox.Show("Input values should be > 0", "Add Reaction", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //        }
                    //    }
                    //}
                    //else
                    //{
                    //    MessageBox.Show("Please enter RXNNUM and RXNSEQ","Add Reaction",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    //} 
                    #endregion
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void AddNewRowToReactionsTable(int _rxnnum, int _rxnseq, int _patentid, int _reactionid, int _disporder, int _rxnrowindx, string _before_after)
        {
            try
            {
                if (ReactionsTbl == null)
                {
                    DataTable dtRxns = new DataTable();
                    dtRxns.Columns.Add("TAN_ID", typeof(Int32));
                    dtRxns.Columns.Add("RXN_NUM", typeof(Int32));
                    dtRxns.Columns.Add("RXN_SEQ", typeof(Int32));
                    dtRxns.Columns.Add("RXN_ID", typeof(Int32));
                    dtRxns.Columns.Add("DISPLAY_ORDER", typeof(Int32));
                    //dtRxns.Columns.Add("created_by", typeof(Int32));

                    ReactionsTbl = dtRxns;
                }

                DataTable dtReactions = ReactionsTbl;
                DataRow dRow = dtReactions.NewRow();
                dRow["TAN_ID"] = _patentid;
                dRow["RXN_NUM"] = _rxnnum;
                dRow["RXN_SEQ"] = _rxnseq;
                dRow["RXN_ID"] = _reactionid;
                //dRow["created_by"] = GlobalVariables.URID;
                //dtReactions.Rows.Add(dRow);

                if (_before_after == "BEFORE" || _before_after == "END")
                {
                    dRow["DISPLAY_ORDER"] = _disporder;
                    dtReactions.Rows.InsertAt(dRow, _rxnrowindx);

                    //Change Display order in Agent table
                    dtReactions = ChangeDisplayOrderInReactionsTable(dtReactions, _disporder + 1, _before_after);
                }
                else if (_before_after == "AFTER")
                {
                    dRow["DISPLAY_ORDER"] = _disporder + 1;
                    dtReactions.Rows.InsertAt(dRow, _rxnrowindx + 1);

                    //Change Display order in Agent table
                    dtReactions = ChangeDisplayOrderInReactionsTable(dtReactions, _disporder + 2, _before_after);
                }

                ReactionsTbl = dtReactions;

                //Bind Reactions to TreeView - New code on 16th June 2014
                BindReactionsToTreeView(ReactionsTbl);
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private DataTable ChangeDisplayOrderInReactionsTable(DataTable reactionstbl, int _rowindex, string _insOpt)
        {
            DataTable dtReactions = reactionstbl;
            try
            {
                if (dtReactions != null)
                {
                    if (dtReactions.Rows.Count > 0)
                    {
                        if (_insOpt == "BEFORE" || _insOpt == "AFTER" || _insOpt == "END")
                        {                            
                            for (int i = 0; i < dtReactions.Rows.Count; i++)
                            {
                                dtReactions.Rows[i]["DISPLAY_ORDER"] = i + 1;
                            }
                            dtReactions.AcceptChanges();                                                    
                        }
                        else if (_insOpt == "DELETE")
                        {                           
                            for (int i = 0; i < dtReactions.Rows.Count; i++)
                            {
                                dtReactions.Rows[i]["DISPLAY_ORDER"] = i + 1;
                            }
                            dtReactions.AcceptChanges();
                        }

                        DataView dvTemp = dtReactions.DefaultView;
                        dvTemp.Sort = "DISPLAY_ORDER asc";
                        dtReactions = dvTemp.ToTable();
                    }
                }
                return dtReactions;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtReactions;
        }

        private void DeleteRowFromReactionsTable(int _rxnnum, int _rxnseq)
        {
            try
            {
                if (ReactionsTbl != null)
                {
                    if (ReactionsTbl.Rows.Count > 0)
                    {
                        for (int i = 0; i < ReactionsTbl.Rows.Count; i++)
                        {
                            if (ReactionsTbl.Rows[i]["rxnnum"].ToString() == _rxnnum.ToString() &&
                                ReactionsTbl.Rows[i]["rxn_seq"].ToString() == _rxnseq.ToString())
                            {
                                ReactionsTbl.Rows[i].Delete();
                                ReactionsTbl.AcceptChanges();
                                return;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnDelReaction_Click(object sender, EventArgs e)
        {
            try
            {
                if (reactionID > 0)
                {
                    DialogResult diaRes = MessageBox.Show("Do you want to delete the reaction with RXNNUM: " + _RxnNum + " RXNSEQ: " + lblRxnSeqVal.Text.Trim() + " permanently?", "Delete Reaction", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (diaRes == DialogResult.Yes)
                    {
                        if (ReactDB.DeleteReaction(reactionID, TAN_ID, _RxnNum, Convert.ToInt32(lblRxnSeqVal.Text.Trim())))
                        {
                            reactionID = 0;//Reset ReactionID
                            
                            //Refresh Reactions Table after Reaction deleted
                            ReactionsTbl = ReactDB.GetReactionsOnTANID(TAN_ID);

                            //Re-Bind Reactions to TreeView
                            BindReactionsToTreeView(ReactionsTbl);

                            MaxRecCnt = ReactionsTbl.Rows.Count;
                            numGotoRecord.Maximum = MaxRecCnt;

                            if (currRxnIndex < MaxRecCnt && currRxnIndex > 1)
                            {
                                currRxnIndex = currRxnIndex - 1;
                            }
                            else if (currRxnIndex == MaxRecCnt && MaxRecCnt > 1)
                            {
                                currRxnIndex = currRxnIndex; //currRecIndex - 1;
                            }
                            else if (currRxnIndex < MaxRecCnt && currRxnIndex == 1)
                            {
                                currRxnIndex = currRxnIndex + 1;
                            }
                            else if (currRxnIndex > MaxRecCnt)//New condition on 13th Sep 2011
                            {
                                currRxnIndex = MaxRecCnt;
                            }

                            blValidRxn = true;
                            numGotoRecord.Value = currRxnIndex;  
                            btnAddRxn.Enabled = true;

                            //Check and Set/Re-Set Comments in Patent
                            CheckAndSetAutoComments();

                            MessageBox.Show("Reaction deleted successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Error in Delete Reaction", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        AutoCompleteStringCollection batch_TANS = null;
        public void AddBatch_TANSToCollection(DataTable _dtBatch_Tans)
        {
            try
            {
                if (_dtBatch_Tans != null)
                {
                    if (_dtBatch_Tans.Rows.Count > 0)
                    {
                        batch_TANS = new AutoCompleteStringCollection();
                        for (int i = 0; i < _dtBatch_Tans.Rows.Count; i++)
                        {
                            batch_TANS.Add(_dtBatch_Tans.Rows[i][0].ToString());
                        }
                        txtTAN.AutoCompleteCustomSource = batch_TANS;
                        txtTAN.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                        txtTAN.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }      
                
        private void Get_Assign_TAN_Nrn_To_Collection(string _tan)
        {
            try
            {
                if (_tan.Trim() != null && tan_nrnnumColl == null)
                {
                    DataTable dtNrnNums_Tan = ReactDB.Get_Batch_TAN_NRNNUM_REG_Details(_tan.Trim());
                    if (dtNrnNums_Tan != null)
                    {
                        if (dtNrnNums_Tan.Rows.Count > 0)
                        {
                            TANNUMsTbl = dtNrnNums_Tan;

                            AddTAN_NrnNumsToCollection(dtNrnNums_Tan);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        AutoCompleteStringCollection tan_nrnnumColl = null;
        public void AddTAN_NrnNumsToCollection(DataTable _dtTan_NrnNum)
        {
            try
            {
                if (_dtTan_NrnNum != null)
                {
                    if (_dtTan_NrnNum.Rows.Count > 0)
                    {
                        //Sort the table on nrnnum before adding to collection
                        DataView dtView = _dtTan_NrnNum.DefaultView;
                        dtView.Sort = "nrnnum asc";
                        _dtTan_NrnNum = dtView.ToTable();

                        tan_nrnnumColl = new AutoCompleteStringCollection();
                        for (int i = 0; i < _dtTan_NrnNum.Rows.Count; i++)
                        {
                            tan_nrnnumColl.Add(_dtTan_NrnNum.Rows[i]["nrnnum"].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnMng8500_Click(object sender, EventArgs e)
        {
            try
            {
                frmManage8500 obj8500 = new frmManage8500();
                obj8500.TAN_Ser8500Data = Generic.GlobalVariables.TAN_Series8500Data;
                obj8500.TAN_ID = TAN_ID;
                obj8500.TAN_Name = TAN_Name;
                obj8500.NUM_RegNoData = TANNUMsTbl;
                obj8500.RxnMain = this;

                if (obj8500.ShowDialog() != DialogResult.OK)
                {
                    Generic.GlobalVariables.TAN_Series8500Data = obj8500.TAN_Ser8500Data;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnMng8000_Click(object sender, EventArgs e)
        {
            try
            {
                using (frmManage8000 obj8000 = new frmManage8000())
                {
                    obj8000.TAN_Name = TAN_Name;
                    obj8000.TAN_ID = TAN_ID;
                    obj8000.Ser8000Data = Generic.GlobalVariables.TAN_Series8000Data;
                    obj8000.NUM_RegNoTbl = TANNUMsTbl;
                    obj8000.RxnMain = this;

                    if (obj8000.ShowDialog() != DialogResult.OK)
                    {
                        Generic.GlobalVariables.TAN_Series8000Data = obj8000.Ser8000Data;
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtcomments_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                // ;-59 not allowed
                if (e.KeyChar == 59)
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void lnkComments_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                #region Code commented
                //frmComments objCmnts = new frmComments();
                //objCmnts.DefaultComments = DefaultComments;
                //objCmnts.UserComments = UserComments;
                //objCmnts.TemperatureComments = TemprtureComments;

                //if (objCmnts.ShowDialog() == DialogResult.OK)
                //{                    
                //    UserComments = objCmnts.UserComments;                    

                //    //Set Comments to Comments TextBox
                //    SetCommentsToCommentsTextBox();
                //} 
                #endregion

                frmComments_New objCmnts = new frmComments_New();           
                //objCmnts.IsQueryTAN = IndxReactNarrDAL.CASRxnDataAccess.CheckIsQueryTAN(TAN_Name);
                objCmnts.CommentsData = TANCommentsData;
                if (objCmnts.ShowDialog() == DialogResult.OK)
                {
                    TANCommentsData = objCmnts.CommentsData;
                    TANComments_New = GetCommentsStringFromTable(objCmnts.CommentsData);                
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       

        private void btnProdForm_Click(object sender, EventArgs e)
        {
            try
            {              

                #region Old code commented
                //FormCollection frmColl = Application.OpenForms;
                //frmProdFormation objProdForm = null;

                //foreach (Form frm in frmColl)
                //{
                //    if (frm.Name.ToUpper() == "FRMPRODFORMATION")
                //    {
                //        objProdForm = (frmProdFormation)frm;
                //        objProdForm.Close();
                //        break;
                //    }
                //}
                //objProdForm = new frmProdFormation();
                //objProdForm.ProductTbl = GetProductsForReactionFormation(RxnProductsTbl, "PRODUCT");
                //objProdForm.ReactantTbl = GetReactantsForReactionFormation();
                //objProdForm.PartpntsTbl = GetParticipantsForReactionFormation();
                ////objProdForm.CGMDataTbl = GetCgmFileDataOnBatchName(txtShipmentName.Text.Trim());
                //objProdForm.RxnSNo = numGotoRecord.Value.ToString();
                //objProdForm.BindDataToReactionPanel_New();// BindDataToReactionPanel();
                //objProdForm.Show(); 
                #endregion

                RefreshReactionView();               
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        /// <summary>
        /// Refresh Reaction in the Reaction Viewer
        /// </summary>
        private void RefreshReactionView()
        {
            try
            {
                #region Old code commented
                //Cursor = Cursors.WaitCursor;

                //splContPartpnts_RxnView.Panel2.Controls.Clear();

                //ucGetReaction objGetRxn = null;
                //objGetRxn = new ucGetReaction();
                //objGetRxn.Dock = DockStyle.Fill;
                ////objGetRxn.SerialNo = RxnSNo;
                //objGetRxn.ProductTbl = GetProductsForReactionFormation(RxnProductsTbl, "PRODUCT");
                //objGetRxn.ProdNUM = GetProductNUMAndYieldFromTable(objGetRxn.ProductTbl);
                //objGetRxn.ReactantTbl = GetReactantsForReactionFormation();
                //objGetRxn.PartpntsTbl = GetParticipantsForReactionFormation();

                ////objGetRxn.GetReactionData_BindToPanel_New();
                //objGetRxn.GetReactionDataAndBindToPanel_IRN();
                //splContPartpnts_RxnView.Panel2.Controls.Add(objGetRxn);

                //Cursor = Cursors.Default; 
                #endregion

                try
                {
                    if (Properties.Settings.Default.ReactionView.ToUpper() == "FORM")
                    {
                        splContPartpnts_RxnView.Panel2.Controls.Clear();
                        splContPartpnts_RxnView.Panel2Collapsed = true;

                        FormCollection frmColl = Application.OpenForms;
                        frmProdFormation objProdForm = null;

                        //foreach (Form frm in frmColl)
                        //{
                        //    if (frm.Name.ToUpper() == "FRMPRODFORMATION")
                        //    {
                        //        objProdForm = (frmProdFormation)frm;
                        //        objProdForm.Close();
                        //        break;
                        //    }
                        //}
                        objProdForm = new frmProdFormation();
                        objProdForm.ProductTbl = GetProductsForReactionFormation(RxnProductsTbl, "PRODUCT");
                        objProdForm.ReactantTbl = GetReactantsForReactionFormation();
                        objProdForm.PartpntsTbl = GetParticipantsForReactionFormation();
                        //objProdForm.CGMDataTbl = GetCgmFileDataOnBatchName(txtShipmentName.Text.Trim());
                        objProdForm.RxnSNo = numGotoRecord.Value.ToString();
                        objProdForm.BindDataToReactionPanel_New();// BindDataToReactionPanel();
                        objProdForm.Show();

                    }
                    else if (Properties.Settings.Default.ReactionView.ToUpper() == "PANEL")
                    {
                        ShowReactionInSplitPanel();
                    }
                }
                catch (Exception ex)
                {
                    Generic.ErrorHandling.WriteErrorLog(ex.ToString());
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void ShowReactionInSplitPanel()
        {
            try
            {
                splContPartpnts_RxnView.Panel2.Controls.Clear();

                ucGetReaction objGetRxn = null;
                objGetRxn = new ucGetReaction();
                objGetRxn.Dock = DockStyle.Fill;
                //objGetRxn.SerialNo = RxnSNo;
                objGetRxn.ProductTbl = GetProductsForReactionFormation(RxnProductsTbl, "PRODUCT");
                objGetRxn.ProdNUM = GetProductNUMAndYieldFromTable(objGetRxn.ProductTbl);
                objGetRxn.ReactantTbl = GetReactantsForReactionFormation();
                objGetRxn.PartpntsTbl = GetParticipantsForReactionFormation();

                //objGetRxn.GetReactionData_BindToPanel_New();
                objGetRxn.GetReactionDataAndBindToPanel_IRN();
                splContPartpnts_RxnView.Panel2.Controls.Add(objGetRxn);

                splContPartpnts_RxnView.Panel2Collapsed = false;

                Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetProductNUMAndYieldFromTable(DataTable _prodtbl)
        {
            string strProd = "";
            try
            {
                if (_prodtbl != null)
                {
                    if (_prodtbl.Rows.Count > 0)
                    {
                        for (int i = 0; i < _prodtbl.Rows.Count; i++)
                        {
                            if (strProd.Trim() == "")
                            {
                                strProd = _prodtbl.Rows[i]["NUM"].ToString();
                            }
                            else
                            {
                                strProd = strProd + ", " + _prodtbl.Rows[i]["NUM"].ToString();
                            }
                            if (_prodtbl.Rows[i]["YIELD"].ToString() != "")
                            {
                                strProd = strProd + " (" + _prodtbl.Rows[i]["YIELD"].ToString() + "%)";
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strProd;
        }

        private DataTable GetCgmFileDataOnBatchName(string _batchname)
        {
            DataTable dtCGM = null;
            try
            {
                if (_batchname.Trim() != "")
                {
                    string strCgmPath = AppDomain.CurrentDomain.BaseDirectory + _batchname + ".cgm";
                    if (File.Exists(strCgmPath))
                    {
                        dtCGM = ReadCgm.GetCgmFileDataForProdFormation(strCgmPath);
                        if (dtCGM != null)
                        {
                            if (dtCGM.Rows.Count > 0)
                            {
                                return dtCGM;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtCGM;
        }        

        private DataTable GetProductsForReactionFormation(DataTable prod_react, string partpnttype)
        {
            DataTable dtProducts = null;
            try
            {
                if (prod_react != null)
                {
                    if (prod_react.Rows.Count > 0)
                    {
                        dtProducts = new DataTable();
                        dtProducts.Columns.Add("NUM", typeof(string));
                        dtProducts.Columns.Add("REG_NO", typeof(string));
                        dtProducts.Columns.Add("YIELD", typeof(string));
                        dtProducts.Columns.Add("STRUCTURE", typeof(object));

                        DataView dvTemp = prod_react.DefaultView;
                        if (partpnttype.ToUpper() == "PRODUCT")
                        {
                            dvTemp.RowFilter = "RXN_ID = " + reactionID + "";
                        }
                        else if (partpnttype.ToUpper() == "REACTANT")
                        {
                            dvTemp.RowFilter = "RXN_ID = " + reactionID + " and PP_TYPE = 'REACTANT'";
                            dvTemp.Sort = "RXN_STAGE_ID asc";
                        }
                        DataTable dtTemp = dvTemp.ToTable();

                        if (dtTemp != null)
                        {
                            if (dtTemp.Rows.Count > 0)
                            {
                                int intP_Num = 0;                                
                                int intRegNo = 0;
                                string strSeriesType = "";
                                DataRow dtRow = null;                               
                                string strYield = "";
                                int serNUMID = 0;

                                for (int i = 0; i < dtTemp.Rows.Count; i++)
                                {
                                    int.TryParse(dtTemp.Rows[i]["SER_TAN_NUM_ID"].ToString(), out serNUMID);

                                    int.TryParse(dtTemp.Rows[i]["SERIES_NUM"].ToString(), out intP_Num);                                   
                                    strYield = dtTemp.Rows[i]["YIELD"].ToString();
                                    int.TryParse(dtTemp.Rows[i]["REG_NO"].ToString(), out intRegNo);
                                    strSeriesType = dtTemp.Rows[i]["SER_TYPE"].ToString();

                                    if (strSeriesType == "NUM")
                                    {
                                        DataTable dtHexCodes = ReactDB.GetStructuresOnRegNo(serNUMID, intRegNo, "NUM");
                                        if (dtHexCodes != null)
                                        {
                                            if (dtHexCodes.Rows.Count > 0)
                                            {
                                                foreach (DataRow row in dtHexCodes.Rows)
                                                {
                                                    //dtRow = dtProducts.NewRow();
                                                    //dtRow["NUM"] = intP_Num;
                                                    //dtRow["REG_NO"] = intRegNo.ToString();
                                                    //dtRow["YIELD"] = strYield;

                                                    //Check if Mol Hex Code is available
                                                    if (!string.IsNullOrEmpty(row["MOL_HEX_CODE"].ToString()))
                                                    {
                                                        string[] MolHexCodes = row["MOL_HEX_CODE"].ToString().Trim().Split(new string[] { "<CSIM>" }, StringSplitOptions.RemoveEmptyEntries);

                                                        if (MolHexCodes != null && MolHexCodes.Length > 0)
                                                        {
                                                            for (int j = 0; j < MolHexCodes.Length; j++)
                                                            {
                                                                dtRow = dtProducts.NewRow();
                                                                dtRow["NUM"] = intP_Num;
                                                                dtRow["REG_NO"] = intRegNo.ToString();
                                                                dtRow["YIELD"] = strYield;
                                                                dtRow["STRUCTURE"] = HexCodeToStructureImage.GetChemImageOnHexCode(MolHexCodes[j].ToString(), intRegNo.ToString());

                                                                dtProducts.Rows.Add(dtRow);
                                                            }
                                                        }                                                       

                                                        //dtRow["STRUCTURE"] = HexCodeToStructureImage.GetChemImageOnHexCode(row["MOL_HEX_CODE"].ToString(), intRegNo.ToString());
                                                    }
                                                    else //NUMs are from Organic/Macro Indexing
                                                    {
                                                        dtRow = dtProducts.NewRow();
                                                        dtRow["NUM"] = intP_Num;
                                                        dtRow["REG_NO"] = intRegNo.ToString();
                                                        dtRow["YIELD"] = strYield;

                                                        //Get Structures from Database
                                                        DataTable dtStruct = ReactDB.GetStructuresOnRegNo(serNUMID, intRegNo, "NUM"); //ReactDB.GetStructureImageOnRegNo(TAN_ID, intRegNo);
                                                        if (dtStruct != null && dtStruct.Rows.Count > 0)
                                                        {
                                                            if (dtStruct.Rows[0]["MOL_IMAGE"] != null)
                                                            {
                                                                dtRow["STRUCTURE"] = dtStruct.Rows[0]["MOL_IMAGE"];
                                                            }
                                                            else if (!string.IsNullOrEmpty(dtStruct.Rows[0]["MOL_FILE"].ToString()))
                                                            {
                                                                dtRow["STRUCTURE"] = GetStructureFromMolFileString(dtStruct.Rows[0]["MOL_FILE"].ToString());
                                                            }
                                                        }

                                                        dtProducts.Rows.Add(dtRow);
                                                    }                                                   
                                                }
                                            }
                                            else //NUMs are from Organic/Macro Indexing
                                            {
                                                dtRow = dtProducts.NewRow();
                                                dtRow["NUM"] = intP_Num;
                                                dtRow["REG_NO"] = intRegNo.ToString();
                                                dtRow["YIELD"] = strYield;

                                                //Get Structures from Database
                                                DataTable dtStruct = ReactDB.GetStructuresOnRegNo(serNUMID, intRegNo, "NUM"); //ReactDB.GetStructureImageOnRegNo(TAN_ID, intRegNo);
                                                if (dtStruct != null && dtStruct.Rows.Count > 0)
                                                {
                                                    if (dtStruct.Rows[0]["MOL_IMAGE"] != null)
                                                    {
                                                        dtRow["STRUCTURE"] = dtStruct.Rows[0]["MOL_IMAGE"];
                                                    }
                                                    else if (!string.IsNullOrEmpty(dtStruct.Rows[0]["MOL_FILE"].ToString()))
                                                    {
                                                        dtRow["STRUCTURE"] = GetStructureFromMolFileString(dtStruct.Rows[0]["MOL_FILE"].ToString());
                                                    }
                                                }

                                                dtProducts.Rows.Add(dtRow);
                                            }                                           
                                        }                                       

                                        #region MyRegion
                                        //objStruct = 
                                        //if (objStruct == null)
                                        //{
                                        //    // objStruct = GetStructure from CGM
                                        //}
                                        //else if (objStruct.ToString() == "")
                                        //{
                                        //    objStruct = null;
                                        //}

                                        // dtRow["Structure"] = objStruct;
                                        //dtProducts.Rows.Add(dtRow); 
                                        #endregion
                                    }
                                    else if (strSeriesType == "9000")
                                    {
                                        DataTable dtStructures = ReactDB.GetStructuresOnRegNo(serNUMID, intRegNo, "9000"); //ReactDB.GetStructuresOnRegNo(serNUMID, intRegNo, "NUM");

                                        dtRow = dtProducts.NewRow();
                                        dtRow["NUM"] = intP_Num;
                                        dtRow["REG_NO"] = intRegNo.ToString();
                                        dtRow["YIELD"] = strYield;
                                        dtRow["STRUCTURE"] = GetStructureFromMolFileString(dtStructures.Rows[0]["MOL_FILE"].ToString()); 
                                        dtProducts.Rows.Add(dtRow);
                                    }
                                    else if (strSeriesType == "8500")
                                    {
                                        DataTable dtStructures = ReactDB.GetStructuresOnRegNo(serNUMID, intRegNo, "8500"); //ReactDB.GetStructuresOnRegNo(TAN_ID, intRegNo, "8500");

                                        dtRow = dtProducts.NewRow();
                                        dtRow["NUM"] = intP_Num;
                                        dtRow["REG_NO"] = intRegNo.ToString();
                                        dtRow["YIELD"] = strYield;
                                        dtRow["STRUCTURE"] = GetStructureFromMolFileString(dtStructures.Rows[0]["MOL_FILE"].ToString()); 
                                        dtProducts.Rows.Add(dtRow);
                                    }
                                    else if (strSeriesType == "8000")
                                    {
                                        dtRow = dtProducts.NewRow();
                                        dtRow["NUM"] = intP_Num;
                                        dtRow["REG_NO"] = intRegNo;// dtTemp.Rows[i]["nrnreg"].ToString();
                                        dtRow["YIELD"] = strYield;
                                        dtRow["STRUCTURE"] = GetStructureFromSeries8000Table(intP_Num);
                                        dtProducts.Rows.Add(dtRow);
                                    }
                                }
                                return dtProducts;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtProducts;
        }

        private DataTable GetReactantsForReactionFormation()
        {
            DataTable dtReacts = null;
            try
            {
                if (tcStages.TabPages.Count > 0)
                {
                    dtReacts = new DataTable();
                    dtReacts.Columns.Add("STAGE", typeof(string));
                    dtReacts.Columns.Add("NUM", typeof(string));
                    dtReacts.Columns.Add("REG_NO", typeof(string));
                    dtReacts.Columns.Add("STRUCTURE", typeof(object));

                    DataTable dtReact = null;
                    ucParticipants ucparpnt = null;

                    int intP_Num = 0;
                    int intRegNo = 0;
                    int intSerNUMID = 0;
                    string strSeriesType = "";
                    DataRow dtRow = null;

                    for (int i = 0; i < tcStages.TabPages.Count; i++)
                    {
                        ucparpnt = (ucParticipants)tcStages.TabPages[i].Controls["ucParticipants"];
                        if (ucparpnt != null)
                        {
                            dtReact = ucparpnt.dtReactant;
                            if (dtReact != null && dtReact.Rows.Count > 0)
                            {
                                for (int rIndx = 0; rIndx < dtReact.Rows.Count; rIndx++)
                                {
                                    int.TryParse(dtReact.Rows[rIndx]["SERIES_NUM"].ToString(), out intP_Num);
                                    int.TryParse(dtReact.Rows[rIndx]["SER_TAN_NUM_ID"].ToString(), out intSerNUMID);
                                    int.TryParse(dtReact.Rows[rIndx]["REG_NO"].ToString(), out intRegNo);
                                    strSeriesType = dtReact.Rows[rIndx]["SER_TYPE"].ToString();

                                    if (strSeriesType == "NUM")
                                    {
                                        #region Old code commented
                                        //dtRow = dtReacts.NewRow();
                                        //dtRow["STAGE"] = tbStages.TabPages[i].Text.ToString();
                                        //dtRow["NUM"] = intP_Num;
                                        //dtRow["REG_NO"] = dtReact.Rows[rIndx]["REG_NO"].ToString();
                                        //objStruct = null;// CASRxnDataAccess.GetStructuresOnRegNo(Convert.ToInt32(dtReact.Rows[rIndx]["REG_NO"]));
                                        //if (objStruct == null)
                                        //{
                                        //    // objStruct = GetStructure from CGM
                                        //}
                                        //dtRow["Structure"] = objStruct;
                                        //dtReacts.Rows.Add(dtRow); 
                                        #endregion

                                        DataTable dtHexCodes = ReactDB.GetStructuresOnRegNo(intSerNUMID, intRegNo, "NUM");
                                        if (dtHexCodes != null)
                                        {
                                            if (dtHexCodes.Rows.Count > 0)
                                            {
                                                foreach (DataRow row in dtHexCodes.Rows)
                                                {
                                                    //Check if Mol Hex Code is available
                                                    if (!string.IsNullOrEmpty(row["MOL_HEX_CODE"].ToString()))
                                                    {
                                                        string[] MolHexCodes = row["MOL_HEX_CODE"].ToString().Trim().Split(new string[] { "<CSIM>" }, StringSplitOptions.RemoveEmptyEntries);

                                                        if (MolHexCodes != null && MolHexCodes.Length > 0)
                                                        {
                                                            for (int j = 0; j < MolHexCodes.Length; j++)
                                                            {
                                                                dtRow = dtReacts.NewRow();
                                                                dtRow["NUM"] = intP_Num;
                                                                dtRow["STAGE"] = tcStages.TabPages[i].Text.ToString();
                                                                dtRow["REG_NO"] = intRegNo.ToString();
                                                                dtRow["STRUCTURE"] = HexCodeToStructureImage.GetChemImageOnHexCode(MolHexCodes[j].ToString(), intRegNo.ToString());

                                                                dtReacts.Rows.Add(dtRow);
                                                            }
                                                        }
                                                    }
                                                    else //NUMs are from Organic/Macro Indexing
                                                    {
                                                        dtRow = dtReacts.NewRow();
                                                        dtRow["NUM"] = intP_Num;
                                                        dtRow["STAGE"] = tcStages.TabPages[i].Text.ToString();
                                                        dtRow["REG_NO"] = intRegNo.ToString();

                                                        //Get Structures from Database
                                                        DataTable dtStruct = ReactDB.GetStructuresOnRegNo(intSerNUMID, intRegNo, "NUM"); //ReactDB.GetStructureImageOnRegNo(TAN_ID, intRegNo);
                                                        if (dtStruct != null && dtStruct.Rows.Count > 0)
                                                        {
                                                            if (dtStruct.Rows[0]["MOL_IMAGE"] != null)
                                                            {
                                                                dtRow["STRUCTURE"] = dtStruct.Rows[0]["MOL_IMAGE"];
                                                            }
                                                            else if (!string.IsNullOrEmpty(dtStruct.Rows[0]["MOL_FILE"].ToString()))
                                                            {
                                                                dtRow["STRUCTURE"] = GetStructureFromMolFileString(dtStruct.Rows[0]["MOL_FILE"].ToString());
                                                            }
                                                        }

                                                        dtReacts.Rows.Add(dtRow);
                                                    }
                                                }
                                            }
                                            else //NUMs are from Organic/Macro Indexing
                                            {
                                                dtRow = dtReacts.NewRow();
                                                dtRow["NUM"] = intP_Num;
                                                dtRow["REG_NO"] = intRegNo.ToString();

                                                //Get Structures from Database
                                                DataTable dtStruct = ReactDB.GetStructuresOnRegNo(intSerNUMID, intRegNo, "NUM"); //ReactDB.GetStructureImageOnRegNo(TAN_ID, intRegNo);
                                                if (dtStruct != null && dtStruct.Rows.Count > 0)
                                                {
                                                    if (dtStruct.Rows[0]["MOL_IMAGE"] != null)
                                                    {
                                                        dtRow["STRUCTURE"] = dtStruct.Rows[0]["MOL_IMAGE"];
                                                    }
                                                    else if (!string.IsNullOrEmpty(dtStruct.Rows[0]["MOL_FILE"].ToString()))
                                                    {
                                                        dtRow["STRUCTURE"] = GetStructureFromMolFileString(dtStruct.Rows[0]["MOL_FILE"].ToString());
                                                    }
                                                }

                                                dtReacts.Rows.Add(dtRow);
                                            }
                                        }

                                    }
                                    else if (strSeriesType == "9000")
                                    {
                                        DataTable dtMolFiles = ReactDB.GetStructuresOnRegNo(intSerNUMID, intRegNo, "9000"); //ReactDB.GetStructuresOnRegNo(TAN_ID, intRegNo, "9000");
                                        if (dtMolFiles != null && dtMolFiles.Rows.Count > 0)
                                        {
                                            dtRow = dtReacts.NewRow();
                                            dtRow["STAGE"] = tcStages.TabPages[i].Text.ToString();
                                            dtRow["NUM"] = intP_Num;
                                            dtRow["REG_NO"] = intRegNo.ToString();
                                            dtRow["STRUCTURE"] = GetStructureFromMolFileString(dtMolFiles.Rows[0]["MOL_FILE"].ToString());
                                            dtReacts.Rows.Add(dtRow);
                                        }
                                    }
                                    else if (strSeriesType == "8500")
                                    {
                                        DataTable dtMolFiles = ReactDB.GetStructuresOnRegNo(intSerNUMID, intRegNo, "8500"); //ReactDB.GetStructuresOnRegNo(TAN_ID, intRegNo, "8500");
                                        if (dtMolFiles != null && dtMolFiles.Rows.Count > 0)
                                        {
                                            dtRow = dtReacts.NewRow();
                                            dtRow["STAGE"] = tcStages.TabPages[i].Text.ToString();
                                            dtRow["NUM"] = intP_Num;
                                            dtRow["REG_NO"] = intRegNo.ToString();
                                            dtRow["STRUCTURE"] = GetStructureFromMolFileString(dtMolFiles.Rows[0]["MOL_FILE"].ToString());
                                            dtReacts.Rows.Add(dtRow);
                                        }
                                    }
                                    else if (strSeriesType == "8000")
                                    {
                                        dtRow = dtReacts.NewRow();
                                        dtRow["STAGE"] = tcStages.TabPages[i].Text.ToString();
                                        dtRow["NUM"] = intP_Num;
                                        dtRow["REG_NO"] = "";//dtReact.Rows[rIndx]["REG_NO"].ToString();
                                        dtRow["STRUCTURE"] = GetStructureFromSeries8000Table(intP_Num);
                                        dtReacts.Rows.Add(dtRow);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtReacts;
        }

        private DataTable GetParticipantsForReactionFormation()
        {
            DataTable dtPartpnts = null;
            try
            {
                if (tcStages.TabCount > 0)
                {
                    if (tcStages.TabPages.Count > 0)
                    {
                        dtPartpnts = new DataTable();
                        dtPartpnts.Columns.Add("Stage", typeof(string));
                        dtPartpnts.Columns.Add("Agents", typeof(string));
                        dtPartpnts.Columns.Add("Solvents", typeof(string));
                        dtPartpnts.Columns.Add("Catalysts", typeof(string));
                        dtPartpnts.Columns.Add("Temperature", typeof(string));
                        dtPartpnts.Columns.Add("Time", typeof(string));
                        dtPartpnts.Columns.Add("Pressure", typeof(string));
                        dtPartpnts.Columns.Add("pH", typeof(string));
                        dtPartpnts.Columns.Add("RSN_CVT", typeof(string));
                        dtPartpnts.Columns.Add("RSN_FT_Reaction", typeof(string));
                        dtPartpnts.Columns.Add("RSN_FT_Stage", typeof(string));

                        ucParticipants ucparpnt = null;
                        string strAgent = "";
                        string strSolvent = "";
                        string strCatalyst = "";
                        string strTemp = "";
                        string strTime = "";
                        string strPressure = "";
                        string strPh = "";
                        string strRSN_CVT = "";
                        string strRSN_FT_RXN = "";
                        string strRSN_FT_Stage = "";

                        for (int i = 0; i < tcStages.TabPages.Count; i++)
                        {
                            ucparpnt = (ucParticipants)tcStages.TabPages[i].Controls["ucParticipants"];
                            if (ucparpnt != null)
                            {
                                strAgent = GetParticipantStringFromTable(ucparpnt.dtAgent, "AGENT");
                                strSolvent = GetParticipantStringFromTable(ucparpnt.dtSolvent, "SOLVENT");
                                strCatalyst = GetParticipantStringFromTable(ucparpnt.dtCatalyst, "CATALYST");
                                strTemp = GetCondtionsStringFromTable(ucparpnt.dtConditions, out strTime, out strPressure, out strPh);
                                strRSN_CVT = GetRSNDetailsFromTable(ucparpnt.dtRSN, out strRSN_FT_RXN, out strRSN_FT_Stage);

                                DataRow dtRow = dtPartpnts.NewRow();
                                dtRow["Stage"] = tcStages.TabPages[i].Text.ToString();
                                dtRow["Agents"] = strAgent;
                                dtRow["Solvents"] = strSolvent;
                                dtRow["Catalysts"] = strCatalyst;
                                dtRow["Temperature"] = strTemp;
                                dtRow["Time"] = strTime;
                                dtRow["Pressure"] = strPressure;
                                dtRow["pH"] = strPh;
                                dtRow["RSN_CVT"] = strRSN_CVT;
                                dtRow["RSN_FT_Reaction"] = strRSN_FT_RXN;
                                dtRow["RSN_FT_Stage"] = strRSN_FT_Stage;
                                dtPartpnts.Rows.Add(dtRow);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtPartpnts;
        }

        private string GetParticipantStringFromTable(DataTable partpnttbl, string partpnt)
        {
            string strPartpnt = "";
            string strValue = "";
            try
            {
                string strTemp = "";
                if (partpnt == "AGENT")
                {
                    strTemp = "NO AGENT";
                }
                else if (partpnt == "SOLVENT")
                {
                    strTemp = "NO SOLVENT";
                }
                else if (partpnt == "CATALYST")
                {
                    strTemp = "NO CATALYST";
                }

                if (partpnttbl != null)
                {
                    if (partpnttbl.Rows.Count > 0)
                    {
                        for (int i = 0; i < partpnttbl.Rows.Count; i++)
                        {                            
                            if (!string.IsNullOrEmpty(partpnttbl.Rows[i]["PP_NAME"].ToString().Trim()))
                            {
                                if (partpnttbl.Rows[i]["PP_NAME"].ToString().Trim().ToUpper() != strTemp)
                                {
                                    strValue = "(" + partpnttbl.Rows[i]["SERIES_NUM"].ToString().Trim() + ") " + partpnttbl.Rows[i]["PP_NAME"].ToString().Trim();
                                }
                                //else if (partpnttbl.Rows[i]["PP_NAME"].ToString().Trim().ToUpper() == strTemp)
                                //{
                                //    if (partpnttbl.Rows[i]["SERIES_8000"].ToString().Trim() != "0")
                                //    {
                                //        strValue = partpnttbl.Rows[i]["SERIES_8000"].ToString().Trim();
                                //    }
                                //}
                            }
                            else if (partpnttbl.Rows[i]["SERIES_NUM"].ToString().Trim() != "" && partpnttbl.Rows[i]["SERIES_NUM"].ToString().Trim() != "0")
                            {
                                strValue = partpnttbl.Rows[i]["SERIES_NUM"].ToString().Trim();
                            }

                            if (!string.IsNullOrEmpty(strValue.Trim()))
                            {
                                strPartpnt = strPartpnt.Trim() == "" ? partpnt + "= " + strValue : strPartpnt.Trim() + ", " + strValue;
                            }

                            //if (strPartpnt.Trim() == "")
                            //{
                            //    if (strValue.Trim() != "")
                            //    {
                            //        strPartpnt = partpnt + "= " + strValue;
                            //        strValue = "";
                            //    }
                            //}
                            //else
                            //{
                            //    if (strValue.Trim() != "")
                            //    {
                            //        strPartpnt = strPartpnt + ", " + strValue;
                            //        strValue = "";
                            //    }
                            //}
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strPartpnt;
        }

        private string GetCondtionsStringFromTable(DataTable condstbl, out string time_out, out string pressure_out, out string ph_out)
        {
            string strTemp = "";
            string strTime = "";
            string strPressure = "";
            string strPH = "";

            try
            {
                if (condstbl != null)
                {
                    if (condstbl.Rows.Count > 0)
                    {
                        for (int i = 0; i < condstbl.Rows.Count; i++)
                        {
                            if (condstbl.Rows[i]["TEMPERATURE"].ToString().Trim() != "")
                            {
                                if (strTemp.Trim() == "")
                                {
                                    strTemp = "TP: " + condstbl.Rows[i]["TEMPERATURE"].ToString();
                                }
                                else
                                {
                                    strTemp = strTemp + "," + condstbl.Rows[i]["TEMPERATURE"].ToString();
                                }
                            }
                            if (condstbl.Rows[i]["RC_TIME"].ToString().Trim() != "")
                            {
                                if (strTime.Trim() == "")
                                {
                                    strTime = "TM: " + condstbl.Rows[i]["RC_TIME"].ToString();
                                }
                                else
                                {
                                    strTime = strTime + "," + condstbl.Rows[i]["RC_TIME"].ToString();
                                }
                            }
                            else
                            {
                                if (condstbl.Rows[i]["TEMPERATURE"].ToString().Trim() != "")
                                {
                                    if (strTime.Trim() == "")
                                    {
                                        strTime = "TM: ";
                                    }
                                    else
                                    {
                                        strTime = strTime + ",";
                                    }
                                }
                            }
                            if (condstbl.Rows[i]["PRESSURE"].ToString().Trim() != "")
                            {
                                if (strPressure.Trim() == "")
                                {
                                    strPressure = "PR: " + condstbl.Rows[i]["PRESSURE"].ToString();
                                }
                                else
                                {
                                    strPressure = strPressure + "," + condstbl.Rows[i]["PRESSURE"].ToString();
                                }
                            }
                            if (condstbl.Rows[i]["PH"].ToString().Trim() != "")
                            {
                                if (strPH.Trim() == "")
                                {
                                    strPH = "PH: " + condstbl.Rows[i]["PH"].ToString();
                                }
                                else
                                {
                                    strPH = strPH + "," + condstbl.Rows[i]["PH"].ToString();
                                }
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            time_out = strTime;
            pressure_out = strPressure;
            ph_out = strPH;
            return strTemp;
        }

        private string GetRSNDetailsFromTable(DataTable rsntbl, out string _freetext_rxn, out string _freetext_stage)
        {
            string strRSN_CVT = "";
            string strRSN_FT_Rxn = "";
            string strRSN_FT_Stage = "";
            string strValue = "";
            try
            {
                if (rsntbl != null)
                {
                    if (rsntbl.Rows.Count > 0)
                    {
                        for (int i = 0; i < rsntbl.Rows.Count; i++)
                        {
                            if (rsntbl.Rows[i]["CVT"].ToString().Trim() != "")
                            {
                                strValue = rsntbl.Rows[i]["CVT"].ToString().Trim();
                                if (strRSN_CVT.Trim() == "")
                                {
                                    strRSN_CVT = strValue;
                                }
                                else
                                {
                                    strRSN_CVT = strRSN_CVT + ", " + strValue;
                                }
                            }
                            if (rsntbl.Rows[i]["FREE_TEXT"].ToString().Trim() != "")
                            {
                                strValue = rsntbl.Rows[i]["FREE_TEXT"].ToString().Trim();
                                if (rsntbl.Rows[i]["NOTE_LEVEL"].ToString().Trim() == "Reaction")
                                {
                                    if (strRSN_FT_Rxn.Trim() == "")
                                    {
                                        strRSN_FT_Rxn = strValue;
                                    }
                                    else
                                    {
                                        strRSN_FT_Rxn = strRSN_FT_Rxn + ", " + strValue;
                                    }
                                }
                                else if (rsntbl.Rows[i]["NOTE_LEVEL"].ToString().Trim() == "Stage")
                                {
                                    if (strRSN_FT_Stage.Trim() == "")
                                    {
                                        strRSN_FT_Stage = strValue;
                                    }
                                    else
                                    {
                                        strRSN_FT_Stage = strRSN_FT_Stage + ", " + strValue;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _freetext_rxn = strRSN_FT_Rxn;
            _freetext_stage = strRSN_FT_Stage;
            return strRSN_CVT;
        }

        private object GetStructureFromSeries8000Table(int _ser8000val)
        {
            object objStruct = null;
            try
            {
                DataTable dtSer8000 = Generic.GlobalVariables.TAN_Series8000Data;
                if (dtSer8000 != null)
                {
                    if (dtSer8000.Rows.Count > 0)
                    {                       
                        DataRow[] dtRArr = dtSer8000.Select("SERIES_8000 = " + _ser8000val);
                        if (dtRArr != null && dtRArr.Length > 0)
                        {
                            if (dtRArr[0]["SUBST_MOLECULE"] != null)
                            {
                                if (GlobalVariables.ChemistryRenditor == null)
                                {
                                    GlobalVariables.ChemistryRenditor = new MDL.Draw.Renditor.Renditor();
                                }

                                GlobalVariables.ChemistryRenditor.MolfileString = "";
                                GlobalVariables.ChemistryRenditor.MolfileString = dtRArr[0]["SUBST_MOLECULE"].ToString();
                                objStruct = GlobalVariables.ChemistryRenditor.Image;
                            }
                            return objStruct;
                        }                     
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return objStruct;
        }

        private object GetStructureFromMolFileString(string molfile)
        {
            object objStruct = null;
            try
            {
                if (!string.IsNullOrEmpty(molfile))
                {
                    GlobalVariables.ChemistryRenditor.MolfileString = "";
                    GlobalVariables.ChemistryRenditor.MolfileString = molfile;

                    //ChemRenditor.MolfileString = "";
                    //ChemRenditor.MolfileString = molfile;
                    objStruct = GlobalVariables.ChemistryRenditor.Image;
                }
                return objStruct;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return objStruct;
        }

        private void btnNumSearch_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;
                
                FormCollection frmColl = Application.OpenForms;
                frmNUMSearch objNumSrch = null;
                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMNUMSEARCH")
                    {
                        objNumSrch = (frmNUMSearch)frm;
                        objNumSrch.Close();
                        break;
                    }
                }
                objNumSrch = new frmNUMSearch();
                objNumSrch.TAN = txtTAN.Text.Trim();
                objNumSrch.CAN = txtCAN.Text.Trim();
                objNumSrch.BatchName = txtShipmentName.Text.Trim();
                objNumSrch.TANNUMsData = TANNUMsTbl;
                objNumSrch.Show();
                
                Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        bool blFormClose = false;
        private void frmRxnEntryScreen_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (blFormClose == false)
                {                    
                    e.Cancel = true;
                    string strErrMSg = "";
                    string strErrSrc = "";
                    if (!SaveReactionData_New(out strErrMSg, out strErrSrc))
                    {
                        if (!string.IsNullOrEmpty(strErrMSg.Trim()))
                        {
                            MessageBox.Show("Errors in the Reaction. Clear the below errors before closing.\r\n\r\n" + strErrMSg, strErrSrc, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        blFormClose = true;
                        this.Close();
                    }                   
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnGetAllRxns_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;

                //if (TAN_ID > 0)
                //{
                //    string strErrMSg = "";
                //    string strErrSrc = "";
                //    blValidRxn = false;

                //    if (SaveReactionData(out strErrMSg, out strErrSrc))
                //    {
                //        blValidRxn = true;

                //        string strCgmPath = AppDomain.CurrentDomain.BaseDirectory + txtShipmentName.Text.Trim() + ".cgm";
                //        if (File.Exists(strCgmPath))
                //        {
                //            DialogResult diaRes = MessageBox.Show("This operation takes time. Do you want to continue?", "Get All Reactions", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                //            if (diaRes == DialogResult.Yes)
                //            {
                //                FormCollection frmColl = Application.OpenForms;
                //                frmGetAllRxns objGetAllRxns = null;
                //                foreach (Form frm in frmColl)
                //                {
                //                    if (frm.Name.ToUpper() == "FRMNUMSEARCH")
                //                    {
                //                        objGetAllRxns = (frmGetAllRxns)frm;
                //                        objGetAllRxns.Close();
                //                        break;
                //                    }
                //                }
                //                objGetAllRxns = new frmGetAllRxns();
                //                objGetAllRxns.TAN = txtTAN.Text.Trim();
                //                objGetAllRxns.CgmDataTbl = GetCgmFileDataOnBatchName(txtShipmentName.Text.Trim());
                //                objGetAllRxns.GetAllRxnsDataOnTAN_BindToControl();
                //                objGetAllRxns.MdiParent = this.MdiParent;
                //                objGetAllRxns.Show();
                //            }
                //        }
                //        else
                //        {
                //            MessageBox.Show(txtShipmentName.Text.Trim() + ".cgm file not found in the setup folder", "CGM not found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //        }
                //    }
                //    else
                //    {
                //        if (!string.IsNullOrEmpty(strErrMSg.Trim()))
                //        {
                //            MessageBox.Show("Errors in the Reaction. Clear the below errors before creating another reaction\r\n\r\n" + strErrMSg, strErrSrc, MessageBoxButtons.OK, MessageBoxIcon.Error);
                //        }
                //    }   
                //}
                Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnKeyWord_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(TANKeywords.Trim()))
                {
                    frmTAN_KeyWords objKWords = new frmTAN_KeyWords();
                    objKWords.KeyWords = TANKeywords;
                    objKWords.ShowDialog();
                }
                else
                {
                    MessageBox.Show("No Keyword found for this TAN", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       

        #region Comments related new methods - 17th Apr 2013

        private DataTable GetCommentsTableDefinition()
        {
            DataTable dtComments = new DataTable();
            dtComments.Columns.Add("TC_ID", typeof(Int32));
            dtComments.Columns.Add("TAN_COMMENT", typeof(string));
            dtComments.Columns.Add("COMMENT_TYPE", typeof(string));
            return dtComments;
        }

        private void SetCommentsToCommentsTextBox_New()
        {
            try
            {               
                //strTempComnts = !string.IsNullOrEmpty(TemprtureComments) ? "~~" + TemprtureComments.Trim() : "";
                //strUsrComnts = !string.IsNullOrEmpty(UserComments) ? "`" + UserComments.Trim() : "";

                //strTempComnts = "~~" + TemprtureComments.Trim();
                //strUsrComnts = "`" + UserComments.Trim();

                UpdateDefault_TemperatureCommentsInTable(DefaultComments, "DEFAULT");
                UpdateDefault_TemperatureCommentsInTable(TemperatureComments, "TEMPERATURE");

                //txtcomments.Text = strDefComnts.Trim() + strTempComnts.Trim() + strUsrComnts.Trim();
                //txtcomments.Text = GetCommentsStringFromTable(TANCommentsData);
                //TANComments_New = txtcomments.Text;//New code testing on 17th Apr 2013                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void UpdateDefault_TemperatureCommentsInTable(string comments, string commenttype)
        {
            try
            {
                if (!string.IsNullOrEmpty(commenttype.Trim()))
                {
                    if (TANCommentsData == null)
                    {
                        TANCommentsData = GetCommentsTableDefinition();                       
                    }
                    if (TANCommentsData.Rows.Count == 0)
                    {
                        if (!string.IsNullOrEmpty(comments))
                        {
                            DataRow dRow = TANCommentsData.NewRow();
                            dRow["TC_ID"] = 0;
                            dRow["TAN_COMMENT"] = comments.Trim();
                            dRow["COMMENT_TYPE"] = commenttype.Trim();
                            TANCommentsData.Rows.Add(dRow);
                        }
                    }
                    else
                    {
                        bool blCmntsUpdated = false;

                        for (int i = 0; i < TANCommentsData.Rows.Count; i++)
                        {
                            if (TANCommentsData.Rows[i]["COMMENT_TYPE"].ToString().ToUpper() == commenttype.Trim())
                            {
                                if (!string.IsNullOrEmpty(comments))
                                {
                                    TANCommentsData.Rows[i]["TAN_COMMENT"] = comments.Trim();
                                    TANCommentsData.AcceptChanges();
                                    blCmntsUpdated = true;
                                }
                                else //If empty comments, Delete the comments 
                                {
                                    TANCommentsData.Rows[i].Delete();
                                    TANCommentsData.AcceptChanges();
                                    blCmntsUpdated = true;
                                    break;
                                }
                            }
                        }
                        if (!blCmntsUpdated && !string.IsNullOrEmpty(comments))
                        {
                            DataRow dRow = TANCommentsData.NewRow();
                            dRow["TC_ID"] = 0;
                            dRow["TAN_COMMENT"] = comments.Trim();
                            dRow["COMMENT_TYPE"] = commenttype.Trim();
                            TANCommentsData.Rows.Add(dRow);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private string GetCommentsStringFromTable(DataTable commentsdata)
        {
            string strComments = "";
            try
            {
                if (commentsdata != null)
                {
                    if (commentsdata.Rows.Count > 0)
                    {
                        //Get CAS Consulted for Comments from Comments data
                        string strCASCmnts = GetCommentsFromCommentsData(commentsdata, "CAS", "~CE");
                        strCASCmnts = !string.IsNullOrEmpty(strCASCmnts.Trim()) ? "<CE>" + strCASCmnts.Trim() + "</CE>" : strCASCmnts.Trim();

                        //Get Author Error Comments from Comments data
                        string strAuthorCmnts = GetCommentsFromCommentsData(commentsdata, "AUTHOR", "~AE~");
                        strAuthorCmnts = !string.IsNullOrEmpty(strAuthorCmnts.Trim()) ? "<AE>" + strAuthorCmnts.Trim() + "</AE>" : strAuthorCmnts.Trim();

                        //Get Indexing Error Comments from Comments data
                        string strIndexingCmnts = GetCommentsFromCommentsData(commentsdata, "INDEXING", "~IE~");
                        strIndexingCmnts = !string.IsNullOrEmpty(strIndexingCmnts.Trim()) ? "<IE>" + strIndexingCmnts.Trim() + "</IE>" : strIndexingCmnts.Trim();

                        //Get Default Comments from Comments Data
                        string strDefaultCmnts = GetCommentsFromCommentsData(commentsdata, "DEFAULT", "~DC~");

                        //Get Temperature Comments from Comments Data
                        string strTempratureCmnts = GetCommentsFromCommentsData(commentsdata, "TEMPERATURE", "~TC~");

                        //Get Other Comments from Comments data
                        string strOtherCmnts = GetCommentsFromCommentsData(commentsdata, "OTHER", "~OE~");

                        strOtherCmnts = strDefaultCmnts + "~~" + strTempratureCmnts + "`" + strOtherCmnts;
                        strOtherCmnts = !string.IsNullOrEmpty(strOtherCmnts.Trim()) ? "<OE>" + strOtherCmnts.Trim() + "</OE>" : strOtherCmnts.Trim();

                        //Combine all the comments
                        strComments = strCASCmnts + strAuthorCmnts + strIndexingCmnts + strOtherCmnts;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strComments;
        }        

        private string GetCommentsFromCommentsData(DataTable commentsdata, string commentstype, string delimiter)
        {
            string strComments = "";
            try
            {
                if (commentsdata != null && !string.IsNullOrEmpty(commentstype) && !string.IsNullOrEmpty(delimiter))
                {
                    strComments = string.Join(delimiter, (from DataRow row in commentsdata.Rows
                                                          where (string)row["COMMENT_TYPE"] == commentstype
                                                          select (string)row["TAN_COMMENT"]).ToArray());
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strComments;
        }
       
        #endregion

        private void btnExportToPdf_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtTAN.Text.Trim()) && !string.IsNullOrEmpty(txtShipmentName.Text.Trim()))
                {
                    FolderBrowserDialog objFoldBrowse = new FolderBrowserDialog();
                    if (objFoldBrowse.ShowDialog() == DialogResult.OK)
                    {
                        Cursor = Cursors.WaitCursor;
                        
                        RxnsExportToPdf objRxnExport = new RxnsExportToPdf();
                        objRxnExport.TAN = txtTAN.Text.Trim();
                        objRxnExport.CAN = txtCAN.Text.Trim();
                        objRxnExport.TAN_ID = TAN_ID;                       
                        objRxnExport.BatchName = txtShipmentName.Text.Trim();
                        objRxnExport.OutputFolderPath = objFoldBrowse.SelectedPath;
                        objRxnExport.OutputFileName = objFoldBrowse.SelectedPath + "\\" + txtTAN.Text.Trim() + "_Rxns.pdf";

                        if (objRxnExport.ExportTANReactionsToPDF())
                        {
                            MessageBox.Show("Reactions exported to Pdf successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);

                            Cursor = Cursors.Default;

                            //Open Pdf
                            //string strFileName = objFoldBrowse.SelectedPath + "\\" + txtTAN.Text.Trim() + "_Reactions.pdf";
                            //File.Open(strFileName, FileMode.Open);
                            System.Diagnostics.Process.Start(objRxnExport.OutputFileName);

                           
                        }
                        else
                        {
                            Cursor = Cursors.Default;
                            MessageBox.Show("Error in Reactions export", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tvReactions_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            try
            {
                string strErrMSg = "";
                string strErrSrc = "";
                blValidRxn = false;

                if (!SaveReactionData_New(out strErrMSg, out strErrSrc))
                {
                    if (strErrMSg.Trim() != "")
                    {
                        MessageBox.Show("Errors in the Reaction. Clear the below errors before moving to another reaction\r\n\r\n" + strErrMSg, strErrSrc, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    if (e.Node.Index >= 0)
                    {
                        //foreach (TreeNode tn in tvReactions.Nodes[0].Nodes)
                        //{
                        //    tn.ImageIndex = 0;
                        //}
                        //e.Node.SelectedImageIndex = 1;

                        currRxnIndex = e.Node.Index + 1;

                        blValidRxn = true;

                        //if (currRecIndex < MaxRecCnt)
                        //{
                        //    currRecIndex = currRecIndex + 1;
                        //}
                        //else if (currRecIndex == MaxRecCnt)
                        //{
                        //    currRecIndex = MaxRecCnt;
                        //}
                        if (numGotoRecord.Value == currRxnIndex)
                        {
                            numGotoRecord.Value = currRxnIndex;
                            numGotoRecord_ValueChanged(null, null);
                        }
                        else
                        {
                            numGotoRecord.Value = currRxnIndex;
                        }           
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtSrchProduct_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == 13)
                {
                    // TreeNode[] node = tvReactions.Nodes.Find(txtSrchProduct.Text, true);

                    string strSrch = txtSrchProduct.Text.Trim();
                    if (!strSrch.Contains("-"))
                        strSrch = strSrch + "-1";

                    TreeNode tnode = tvReactions.Nodes[0].Nodes.OfType<TreeNode>()
                                 .FirstOrDefault(node => node.Name.Equals(strSrch));

                    if (tnode != null)
                    {                        
                        //tnode.SelectedImageIndex = 1;
                        //tvReactions.SelectedNode = tnode;

                        currRxnIndex = tnode.Index + 1;

                        blValidRxn = true;

                        numGotoRecord.Value = currRxnIndex;
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        //Show Context menu only in the tab header
        private void cntmnuTbStages_Opening(object sender, CancelEventArgs e)
        {
            try
            {
                Point p = this.tcStages.PointToClient(Cursor.Position);
                for (int i = 0; i < this.tcStages.TabCount; i++)
                {
                    Rectangle r = this.tcStages.GetTabRect(i);
                    if (r.Contains(p))
                    {
                        this.tcStages.SelectedIndex = i; // i is the index of tab under cursor
                        return;
                    }
                }
                e.Cancel = true;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       

        private void btnSrchNumSubst_Click(object sender, EventArgs e)
        {
            try
            {
                frmSrch_RegNo objSrchRegNo = new frmSrch_RegNo();
                objSrchRegNo.TAN_Name = txtTAN.Text.Trim();
                objSrchRegNo.TAN_ID = TAN_ID;                
                objSrchRegNo.ShowDialog();
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnTANComplete_Click(object sender, EventArgs e)
        {
            try
            {
                //Check for InComplete TANs
                if (CheckForInCompleteReactions())
                {
                    DialogResult diaRes = MessageBox.Show("Do you want to complete the TAN?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                    if (diaRes == DialogResult.Yes)
                    {
                        using (frmTaskComments taskComments = new frmTaskComments())
                        {
                            taskComments.TAN_Name = TAN_Name;
                            taskComments.TAN_Reactions = ReactionsTbl;
                            taskComments.TAN_ID = TAN_ID;
                            taskComments.TaskName = "TASK COMPLETE";
                            if (taskComments.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                            {
                                //Update Task Status and Close TAN
                                TaskStatus tskStatus = new TaskStatus();
                                tskStatus.TaskComments = taskComments.txtTaskComments.Text.Trim();
                                tskStatus.Task_ID = Task_ID;
                                //tskStatus.Role_ID = GlobalVariables.RoleID;
                                tskStatus.UR_ID = GlobalVariables.URID;
                                tskStatus.TaskAllocation_ID = TaskAlloc_ID;
                                tskStatus.TaskStatusName = "SET COMPLETE";
                                if (TaskManagementDB.UpdateUserTaskStatus(tskStatus))
                                {
                                    //Delete TAN Pdf
                                    DeleteTANPdfFile(TAN_Name);

                                    this.Close();
                                }
                                else
                                {
                                    MessageBox.Show("Error in TAN complete", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("TAN contains InComplete Reactions", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void DeleteTANPdfFile(string tan)
        {
            try
            {
                if (!string.IsNullOrEmpty(tan.Trim()))
                {
                    string strAppPath = Application.StartupPath.ToString();
                    string strPdfDirPath = strAppPath + "\\TAN_PDFs";

                    string strPdfPath = strPdfDirPath + "\\" + tan.Trim() + ".pdf";

                    if (File.Exists(strPdfPath))
                    {
                        string strAdobeTitle = "Adobe Reader - [" + tan.Trim() + ".pdf]";
                        string strAdbTitle = tan.Trim() + ".pdf";
                        string strFoxitTitle = tan.Trim() + ".pdf" + " - Foxit Reader - [" + tan.Trim() + ".pdf]";

                        Process[] procArr = Process.GetProcesses();
                        foreach (Process process in procArr)
                        {
                            string strPName = process.ProcessName;
                            if (strPName.CompareTo("AcroRd32") == 0 && process.MainWindowTitle == strAdobeTitle)
                            {
                                process.Kill();
                                break;
                            }
                            else if (strPName.CompareTo("AcroRd32") == 0 && process.MainWindowTitle == strAdbTitle)
                            {
                                process.Kill();
                                break;
                            }
                            else if (strPName.CompareTo("Foxit Reader") == 0 && process.MainWindowTitle == strFoxitTitle)
                            {
                                process.Kill();
                                break;
                            }
                        }

                        File.Delete(strPdfPath);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnRejectTAN_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult diaRes = MessageBox.Show("Do you want to reject the TAN?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (diaRes == DialogResult.Yes)
                {
                    using (frmTaskComments taskComments = new frmTaskComments())
                    {
                        taskComments.TAN_Name = TAN_Name;
                        taskComments.TAN_Reactions = ReactionsTbl;
                        taskComments.TAN_ID = TAN_ID;
                        taskComments.TaskName = "TASK REJECT";

                        if (taskComments.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                        {
                            //Update Task Status and Close TAN
                            TaskStatus tskStatus = new TaskStatus();
                            tskStatus.TaskComments = taskComments.txtTaskComments.Text.Trim();
                            tskStatus.Task_ID = Task_ID;
                            //tskStatus.Role_ID = GlobalVariables.RoleID;
                            tskStatus.UR_ID = GlobalVariables.URID;
                            tskStatus.TaskAllocation_ID = TaskAlloc_ID;
                            tskStatus.TaskStatusName = "SET REJECT";
                            if (TaskManagementDB.UpdateUserTaskStatus(tskStatus))
                            {
                                this.Close();
                            }
                            else
                            {
                                MessageBox.Show("Error in TAN reject", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void lnkProduct_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                if (dgvProduct.Rows.Count >= 1)//First Product should come from Add Reaction
                {
                    using (frmNUMs objNUMs = new frmNUMs())
                    {
                        objNUMs.TAN_NUMsTbl = TANNUMsTbl;
                        objNUMs.SrcParticipant = "PRODUCT";
                        if (objNUMs.ShowDialog(this) == DialogResult.OK)
                        {
                            if (objNUMs.Sel_NUM > 0)
                            {
                                //Get New participant ID
                                int intNewParpntID = ReactDB.GetReactionNewParticipantID("PRODUCT", reactionID, 0, dgvProduct.CurrentCell.RowIndex + 1, "AFTER", GlobalVariables.URID);

                                if (intNewParpntID > 0)
                                {
                                    DataRow dRow = RxnProductsTbl.NewRow();
                                    dRow["RPP_ID"] = intNewParpntID;
                                    dRow["RXN_ID"] = reactionID;

                                    dRow["SER_TAN_NUM_ID"] = objNUMs.Sel_Ser_NUM_ID;
                                    dRow["SERIES_NUM"] = objNUMs.Sel_NUM;
                                    dRow["REG_NO"] = objNUMs.Sel_RegNo.ToString();
                                    dRow["PP_NAME"] = objNUMs.Sel_Name.ToString();
                                    dRow["SER_TYPE"] = objNUMs.SeriesType;
                                    dRow["PP_TYPE"] = "PRODUCT";
                                    RxnProductsTbl.Rows.Add(dRow);

                                    BindProductDataToGrid(RxnProductsTbl);

                                    //12Aug2010
                                    //After binding DataBindings to Product grid save product details,because
                                    //if save button is not clicked after creating reaction P_NUM/P_8000/P_8500/P_9000
                                    //information will be lost.

                                    //Insert/Update Product Data
                                    List<Product_ParticipantBO> lstProduct = GetProductDetailsFromProductGrid(reactionID);
                                    if (lstProduct != null)
                                    {
                                        if (lstProduct.Count > 0)
                                        {
                                            for (int i = 0; i < lstProduct.Count; i++)
                                            {
                                                //CASRxnDataAccess.Insert_Update_ProductData(lstProduct[i].RPP_ID, reactionID, lstProduct[i]);
                                                ReactDB.UpdateProduct_ParticipantsData(lstProduct[i]);
                                            }
                                        }
                                    }  
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnIndexingNUMs_Click(object sender, EventArgs e)
        {
            try
            {
                using (frmStructureIndexing objStrIndexing = new frmStructureIndexing())
                {
                    objStrIndexing.TAN = TAN_Name;
                    objStrIndexing.TAN_ID = TAN_ID;
                    objStrIndexing.ShowDialog();

                    //Refresh TAN NUMs
                    TANNUMsTbl = OrganicIndexingDB.GetIndexingNUMsOnTANID(TAN_ID, "NUM_PAR");

                    //Refresh NUMs in each usercontrol
                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        if (tp != null)
                        {
                            Control[] ucctl = tp.Controls.Find(Generic.GlobalVariables.UCControlName, true);
                            if (ucctl != null)
                            {
                                if (ucctl.Length > 0)
                                {
                                    ucParticipants ucpar = (ucParticipants)ucctl[0];
                                    ucpar.NUM_RegNosTbl = TANNUMsTbl;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void frmReactCuration_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.ControlKey)
                {
                    btnSave_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #region New methods to handle arrays

        public Product_ParticipantsArr GetParticipantsDetailsFromControls()
        {
            Product_ParticipantsArr prodPartpnt = null;
            try
            {
                prodPartpnt = new Product_ParticipantsArr();
                prodPartpnt.ReactionID = reactionID;

                List<int> lstRppIDs = new List<int>();
                List<int?> lstRxnStageIDs = new List<int?>();
                List<int> lstSerNumIDs = new List<int>();
                List<string> lstYield = new List<string>();
                List<string> lstSerType = new List<string>();
                List<string> lstPPType = new List<string>();
                List<int> lstDisplayOrder = new List<int>();
                //Product Details
                if (dgvProduct.Rows.Count > 0)
                { 
                    //Product details
                    for (int i = 0; i < dgvProduct.Rows.Count; i++)
                    {
                        lstPPType.Add("PRODUCT");
                        lstRxnStageIDs.Add(null);
                        lstRppIDs.Add(Convert.ToInt32(dgvProduct.Rows[i].Cells[colRPPID.Name].Value));
                        lstSerNumIDs.Add(Convert.ToInt32(dgvProduct.Rows[i].Cells[colProdSerNumID.Name].Value));
                        lstSerType.Add(dgvProduct.Rows[i].Cells[colProdNumType.Name].Value.ToString());
                        lstYield.Add(dgvProduct.Rows[i].Cells[colProdYield.Name].Value.ToString());
                        lstDisplayOrder.Add(1 + 1);
                    }
                }

                //Participants details
                if (tcStages.TabPages.Count > 0)
                {                   
                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        Control[] ucctl = tp.Controls.Find(Generic.GlobalVariables.UCControlName, true);
                        if (ucctl != null)
                        {
                            if (ucctl.Length > 0)
                            {
                                ucParticipants ucpartpnt = (ucParticipants)ucctl[0];
                                if (ucpartpnt != null)
                                {
                                    DataTable[] _dts = GetTablesfromUserControl(ucpartpnt);
                                    List<Product_ParticipantBO> lstStgPartpnt = GetParticipantDetailsfromTable(_dts);

                                    foreach (Product_ParticipantBO objPartpnt in lstStgPartpnt)
                                    {
                                        lstYield.Add("");
                                        lstPPType.Add(objPartpnt.PPType);
                                        lstRxnStageIDs.Add(objPartpnt.RxnStageID);
                                        lstRppIDs.Add(objPartpnt.RPP_ID);
                                        lstSerNumIDs.Add(objPartpnt.SeriesNumID);
                                        lstSerType.Add(objPartpnt.SeriesType);
                                        lstDisplayOrder.Add(objPartpnt.DisplayOrder);
                                    }                                    
                                }
                            }
                        }
                    }
                }

                //Add objects to List
                prodPartpnt.PPType = lstPPType;
                prodPartpnt.RPP_ID = lstRppIDs;
                prodPartpnt.Yield = lstYield;
                prodPartpnt.RxnStageID = lstRxnStageIDs;
                prodPartpnt.SeriesNumID = lstSerNumIDs;
                prodPartpnt.SeriesType = lstSerType;
                prodPartpnt.DisplayOrder = lstDisplayOrder;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return prodPartpnt;
        }

        public RxnSearchNoteArr GetRSNDetailsFromControls()
        {
            RxnSearchNoteArr objRSN = null;            
            try
            {                
                //RSN details
                if (tcStages.TabPages.Count > 0)
                {
                    objRSN = new RxnSearchNoteArr();
                    
                    List<int> lstRsnIDs = new List<int>();
                    List<int> lstRxnStageIDs = new List<int>();                    
                    List<string> lstCVT = new List<string>();
                    List<string> lstFreeText = new List<string>();
                    List<string> lstNoteLevel = new List<string>();
                    List<int> lstDisplayOrder = new List<int>();  

                    ucParticipants ucpartpnt = null;
                    List<RxnSearchNoteBO> lstStageRSN = null;

                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        Control[] ucctl = tp.Controls.Find(Generic.GlobalVariables.UCControlName, true);
                        if (ucctl != null)
                        {
                            if (ucctl.Length > 0)
                            {
                                ucpartpnt = (ucParticipants)ucctl[0];
                                if (ucpartpnt != null)
                                {
                                    lstStageRSN = GetRSNDetailsFromTable(ucpartpnt.dtRSN);
                                    if (lstStageRSN != null)
                                    {
                                        foreach (RxnSearchNoteBO rsn in lstStageRSN)
                                        {
                                            lstRsnIDs.Add(rsn.RSN_ID);
                                            lstRxnStageIDs.Add(rsn.RXN_Stage_ID);
                                            lstCVT.Add(rsn.CVT);
                                            lstFreeText.Add(rsn.FreeText);
                                            lstNoteLevel.Add(rsn.NoteLevel);
                                            lstDisplayOrder.Add(rsn.DisplayOrder);
                                        }                             
                                    }
                                }
                            }
                        }
                    }

                    //Add objects to List
                    objRSN.RSN_ID = lstRsnIDs;
                    objRSN.RxnStageID = lstRxnStageIDs;
                    objRSN.CVT = lstCVT;
                    objRSN.FreeText = lstFreeText;
                    objRSN.NoteLevel = lstNoteLevel;
                    objRSN.DisplayOrder = lstDisplayOrder;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return objRSN;
        }

        public RxnConditionArr GetConditionDetailsFromControls()
        {
            RxnConditionArr objRxnCond = null;
            try
            {
                //Reaction Condition details
                if (tcStages.TabPages.Count > 0)
                {
                    objRxnCond = new RxnConditionArr();

                    List<int> lstRCIDs = new List<int>();
                    List<int> lstRxnStageIDs = new List<int>();

                    List<string> lstTemperature = new List<string>();
                    List<string> lstTempType = new List<string>();

                    List<string> lstTime = new List<string>();
                    List<string> lstTimeType = new List<string>();

                    List<string> lstPressure = new List<string>();
                    List<string> lstPresType = new List<string>();

                    List<string> lstPH = new List<string>();
                    List<string> lstPHType = new List<string>();

                    List<int> lstDisplayOrder = new List<int>();  

                    ucParticipants ucpartpnt = null;
                    List<RxnConditionBO> lstRxnConds = null;

                    foreach (TabPage tp in tcStages.TabPages)
                    {
                        Control[] ucctl = tp.Controls.Find(Generic.GlobalVariables.UCControlName, true);
                        if (ucctl != null && ucctl.Length > 0)
                        {
                            ucpartpnt = (ucParticipants)ucctl[0];
                            if (ucpartpnt != null)
                            {
                                lstRxnConds = GetRXNConditionDetailsFromTable(ucpartpnt.dtConditions);
                                if (lstRxnConds != null)
                                {
                                    foreach (RxnConditionBO rxnCond in lstRxnConds)
                                    {
                                        lstRCIDs.Add(rxnCond.RC_ID);
                                        lstRxnStageIDs.Add(rxnCond.Rxn_Stage_ID);

                                        lstTemperature.Add(rxnCond.Temperature);
                                        lstTempType.Add(rxnCond.TempType);

                                        lstTime.Add(rxnCond.Time);
                                        lstTimeType.Add(rxnCond.TimeType);

                                        lstPressure.Add(rxnCond.Pressure);
                                        lstPresType.Add(rxnCond.PressureType);

                                        lstPH.Add(rxnCond.pH);
                                        lstPHType.Add(rxnCond.PHType);

                                        lstDisplayOrder.Add(rxnCond.DisplayOrder);
                                    }
                                }
                            }
                        }
                    }

                    //Add objects to List
                    objRxnCond.RC_ID = lstRCIDs;
                    objRxnCond.RxnStageID = lstRxnStageIDs;
                    objRxnCond.Temperature = lstTemperature;
                    objRxnCond.TempType = lstTempType;
                    objRxnCond.Time = lstTime;
                    objRxnCond.TimeType = lstTimeType;
                    objRxnCond.Pressure = lstPressure;
                    objRxnCond.PressureType = lstPresType;
                    objRxnCond.pH = lstPH;
                    objRxnCond.PHType = lstPHType;
                    objRxnCond.DisplayOrder = lstDisplayOrder;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return objRxnCond;
        }

        /// <summary>
        /// Test method for saving data using arrays - 31st March 2014
        /// </summary>
        /// <param name="_errmsg_out"></param>
        /// <param name="_err_source"></param>
        /// <returns></returns>
        private bool SaveReactionData_New(out string _errmsg_out, out string _err_source)
        {
            bool blStatus = true;
            string strErrMsg = "";
            string strErrSrc = "";
            try
            {
                if (ValidateUserInputs(out strErrMsg))
                {                   
                    ReactionsBO objRxn = new ReactionsBO();
                    Product_ParticipantBO objProduct = new Product_ParticipantBO();

                    //Zero reactions comments
                    if (reactionID == 0)
                    {
                        DefaultComments = "No reactions in the article";

                        //Set Default Comments to TextBox                       
                        SetCommentsToCommentsTextBox_New();
                    }

                    if (TAN_ID > 0)
                    {
                        //Update TAN comments - New code on 17th June 2014
                        TANCommentsBO tanComments = GetTANCommentsFromTable();
                        if (tanComments != null)
                        {
                            if (ReactDB.UpdateCommentsOnTANID(tanComments))
                            {
                                TANCommentsData = ReactDB.GetTANCommentsOnTANID(TAN_ID);
                            }
                        }

                        if (reactionID > 0)
                        {
                            //Reaction details                   
                            objRxn.RXN_NUM = Convert.ToInt32(lblProdNum.Text);
                            objRxn.RXN_SEQ = Convert.ToInt32(lblRxnSeqVal.Text);
                            objRxn.RXN_ID = reactionID;
                            objRxn.TAN_ID = TAN_ID;
                            objRxn.UR_ID = GlobalVariables.URID;
                            objRxn.UserRole = GlobalVariables.RoleName.ToUpper();

                            //Show warning message if RXNSEQ is 2 and CVT is not there - new feature on 23rd Sep2010
                            if (objRxn.RXN_SEQ > 1)
                            {
                                //Check for CVT term 'alternative preparation shown' in Stage 1 RSN table. If not used show warning
                                if (!CheckForAlternativePrepShownInStage1_RSN_CVT())//New method on 12th Sep 2011
                                {
                                    MessageBox.Show("Check for RSN-CVT 'alternative preparation' related terms", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                            }

                            string strErrMSg = "";

                            //Validate all the participants values
                            if (CheckAndValidateAllValidations(out strErrMSg))
                            {
                                try
                                {
                                    //Get Product & Participants details
                                    Product_ParticipantsArr objProdPartpnts = GetParticipantsDetailsFromControls();
                                    if (objProdPartpnts != null && objProdPartpnts.RPP_ID.Count > 0)
                                    {
                                        //Update Participants in Database
                                        ReactDB.UpdateProduct_ParticipantsData_Array(objProdPartpnts);
                                    }
                                }
                                catch
                                { }

                                try
                                {
                                    //Get RSN details
                                    RxnSearchNoteArr objRSN = GetRSNDetailsFromControls();
                                    if (objRSN != null && objRSN.RSN_ID.Count > 0)
                                    {
                                        ReactDB.UpdateRSNData_Array(objRSN);
                                    }
                                }
                                catch
                                { }

                                try
                                {
                                    //Get Conditions details
                                    RxnConditionArr objConds = GetConditionDetailsFromControls();
                                    if (objConds != null && objConds.RC_ID.Count > 0)
                                    {
                                        ReactDB.UpdateConditionsData_Array(objConds);
                                    }
                                }
                                catch
                                { }

                                try
                                {
                                    //Update Reaction Completed status
                                    if (chkRxnComplete.Checked && chkRxnComplete.Enabled)
                                    {
                                        ReactDB.UpdateReactionStatusOnRole(objRxn);
                                    }
                                }
                                catch
                                { }
                            }
                            else
                            {
                                strErrMsg = strErrMSg;
                                strErrSrc = "In-Valid Data";
                                blStatus = false;

                                _errmsg_out = strErrMsg.Trim();
                                _err_source = strErrSrc;
                                return blStatus;
                            }

                            //Update Default Comments and User comments Here
                            CheckAndSetAutoComments();

                            try
                            {
                                //Update TAN Comments - 11 Aug 2014
                                tanComments = GetTANCommentsFromTable();
                                if (tanComments != null)
                                {
                                    if (ReactDB.UpdateCommentsOnTANID(tanComments))
                                    {
                                        TANCommentsData = ReactDB.GetTANCommentsOnTANID(TAN_ID);
                                    }
                                }
                            }
                            catch
                            { }

                            //Refresh Reaction table
                            ReactionsTbl = ReactDB.GetReactionsOnTANID(TAN_ID);

                            if (ReactionsTbl != null && ReactionsTbl.Rows.Count > 0)
                            {
                                EnableReactionNavigationControls();
                            }
                        }
                    }
                }
                else
                {
                    blStatus = false;
                    _errmsg_out = strErrMsg.Trim();
                    _err_source = "In-Valid Data";
                    return blStatus;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg_out = strErrMsg.Trim();
            _err_source = strErrSrc;
            return blStatus;
        }

        private void ShowAndAutoHideStatusLabelText(string labelText)
        {
            try
            {
                lblRxnSaveMsg.Text = labelText;

                var t = new System.Windows.Forms.Timer();

                t.Interval = 5000; // it will Tick for 5 seconds
                t.Tick += (s, k) =>
                {
                    lblRxnSaveMsg.Text = "";
                    t.Stop();
                };
                t.Start();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnSaveNew_Click(object sender, EventArgs e)
        {
            try
            {
                string strErrMsg_out = "";
                string ErrSource = "";
                if (SaveReactionData_New(out strErrMsg_out, out ErrSource))
                {
                    //Set label
                    //lblRxnSaveMsg.Text = "Reaction saved successfully";

                    ShowAndAutoHideStatusLabelText("Reaction saved successfully");

                    //Refresh Reactions table                                   
                    //ReactionsTbl = ReactDB.GetReactionsOnTANID(TAN_ID);

                    //Refresh Reaction
                    //RefreshReactionView();

                    //currRxnIndex = Convert.ToInt32(numGotoRecord.Value);
                    //SetReactionLabelsOnReactionIndex(Convert.ToInt32(currRxnIndex - 1));

                    if (Properties.Settings.Default.ReactionView.ToUpper() == "PANEL")
                    {
                        ShowReactionInSplitPanel();
                    }
                }
                else
                {
                    MessageBox.Show(strErrMsg_out, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                
                #region Old code commented
                //if (ValidateUserInputs(out strErrMsg_out))
                //{
                //    this.Cursor = Cursors.WaitCursor;

                //    TANInfoBO objPatent = new TANInfoBO();
                //    ReactionsBO objRxn = new ReactionsBO();
                //    Product_ParticipantBO objProduct = new Product_ParticipantBO();

                //    //Zero reactions comments
                //    if (reactionID == 0)
                //    {
                //        DefaultComments = "No reactions in the article";

                //        //Set Default Comments to TextBox                       
                //        SetCommentsToCommentsTextBox_New();
                //    }

                //    if (TAN_ID > 0)
                //    {
                //        //Update TAN comments - New code on 17th June 2014
                //        TANCommentsBO tanComments = GetTANCommentsFromTable();
                //        if (tanComments != null)
                //        {
                //            if (ReactDB.UpdateCommentsOnTANID(tanComments))
                //            {
                //                TANCommentsData = ReactDB.GetTANCommentsOnTANID(TAN_ID);
                //            }
                //        }

                //        if (reactionID > 0)
                //        {
                //            //Reactant details                   
                //            objRxn.RXN_NUM = Convert.ToInt32(lblProdNum.Text);
                //            objRxn.RXN_SEQ = Convert.ToInt32(lblRxnSeqVal.Text);
                //            objRxn.RXN_ID = reactionID;
                //            objRxn.TAN_ID = TAN_ID;
                //            objRxn.UR_ID = GlobalVariables.URID;
                //            objRxn.UserRole = GlobalVariables.RoleName.ToUpper();

                //            //Show warning message if RXNSEQ is 2 and CVT is not there - new feature on 23rd Sep2010
                //            if (objRxn.RXN_SEQ > 1)
                //            {
                //                //Check for CVT term 'alternative preparation shown' in Stage 1 RSN table. If not used show warning
                //                if (!CheckForAlternativePrepShownInStage1_RSN_CVT())//New method on 12th Sep 2011
                //                {
                //                    MessageBox.Show("Check for RSN-CVT 'alternative preparation' related terms", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //                }
                //            }

                //            string strErrMSg = "";

                //            //Validate all the participants values
                //            if (CheckAndValidateAllValidations(out strErrMSg))
                //            {
                //                //Get Product & Participants details
                //                Product_ParticipantsArr objProdPartpnts = GetParticipantsDetailsFromControls();
                //                if (objProdPartpnts != null && objProdPartpnts.RPP_ID.Count > 0)
                //                {
                //                    //Update Participants in Database
                //                    ReactDB.UpdateProduct_ParticipantsData_Array(objProdPartpnts);
                //                }

                //                //Get RSN details
                //                RxnSearchNoteArr objRSN = GetRSNDetailsFromControls();
                //                if (objRSN != null && objRSN.RSN_ID.Count > 0)
                //                {
                //                    ReactDB.UpdateRSNData_Array(objRSN);
                //                }

                //                //Get Conditions details
                //                RxnConditionArr objConds = GetConditionDetailsFromControls();
                //                if (objConds != null && objConds.RC_ID.Count > 0)
                //                {
                //                    ReactDB.UpdateConditionsData_Array(objConds);
                //                }

                //                //Update Reaction Completed status
                //                if (chkRxnComplete.Checked && chkRxnComplete.Enabled)
                //                {
                //                    ReactDB.UpdateReactionStatusOnRole(objRxn);
                //                }
                //            }
                //            else
                //            {
                //                MessageBox.Show(strErrMSg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                //                return;
                //            }

                //            //Update Default Comments and User comments Here
                //            CheckAndSetAutoComments();

                //            //Update TAN Comments - 11 Aug 2014
                //            tanComments = GetTANCommentsFromTable();
                //            if (tanComments != null)
                //            {
                //                if (ReactDB.UpdateCommentsOnTANID(tanComments))
                //                {
                //                    TANCommentsData = ReactDB.GetTANCommentsOnTANID(TAN_ID);
                //                }
                //            }


                //        }
                //    }
                //} 
                #endregion                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(" btnSave_Click " + ex.ToString());
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        #endregion

        private void btnNumsExportToPdf_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtTAN.Text.Trim()))
                {
                    FolderBrowserDialog objFoldBrowse = new FolderBrowserDialog();
                    if (objFoldBrowse.ShowDialog() == DialogResult.OK)
                    {
                        Cursor = Cursors.WaitCursor;

                        NumsExportToPdf numsExport = new NumsExportToPdf();

                        numsExport.TanNUMsData = TANNUMsTbl;
                        numsExport.TANDetails = TANDetailsData;
                        numsExport.PdfFilePath = objFoldBrowse.SelectedPath + "\\" + txtTAN.Text.Trim() + "_NUMs.pdf";
                        if (numsExport.ExportTanNUMsToPDF())
                        {
                            Cursor = Cursors.Default;
                            System.Diagnostics.Process.Start(numsExport.PdfFilePath);
                        }
                        else
                        {
                            Cursor = Cursors.Default;
                            MessageBox.Show("Error in NUMs export", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void chkSkipValidations_CheckStateChanged(object sender, EventArgs e)
        {
            try
            {
                GlobalVariables.SkipValidations = chkSkipValidations.Checked ? true : false;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
