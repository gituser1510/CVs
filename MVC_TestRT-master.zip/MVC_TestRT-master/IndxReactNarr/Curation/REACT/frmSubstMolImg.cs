﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;

namespace IndxReactNarr
{
    public partial class frmSubstMolImg : Form
    {
        public frmSubstMolImg()
        {
            InitializeComponent();
        }

        private string _molfile = null;
        public string MolFile
        {
            get
            {
                return _molfile;
            }
            set
            {
                _molfile = value;
                ChemRenditor.MolfileString = _molfile;
                pbMolImage.Image = (Image)ChemRenditor.Image;
            }
        }

        private void frmSubstMolImg_Load(object sender, EventArgs e)
        {
            //try
            //{
            //    if (MolImage != null)
            //    {
            //        pbMolImage.Image = MolImage;
            //    }
            //}
            //catch (Exception ex)
            //{
            //    ErrorHandling.WriteErrorLog(ex.ToString());
            //}
        }
    }
}
