﻿namespace IndxReactNarr
{
    partial class frmGetAllRxns
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.tlpnl_AllRxns = new System.Windows.Forms.TableLayoutPanel();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.lblRxnCnt = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlNavigCntrls = new System.Windows.Forms.Panel();
            this.numGotoRecord = new System.Windows.Forms.NumericUpDown();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnFirst = new System.Windows.Forms.Button();
            this.txtNUM = new System.Windows.Forms.TextBox();
            this.lblSrch = new System.Windows.Forms.Label();
            this.lblTAN = new System.Windows.Forms.Label();
            this.lblHdrTAN = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btnExport = new System.Windows.Forms.Button();
            this.pnlMain.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.pnlNavigCntrls.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numGotoRecord)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.tlpnl_AllRxns);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 32);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(930, 528);
            this.pnlMain.TabIndex = 0;
            // 
            // tlpnl_AllRxns
            // 
            this.tlpnl_AllRxns.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpnl_AllRxns.AutoScroll = true;
            this.tlpnl_AllRxns.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tlpnl_AllRxns.ColumnCount = 1;
            this.tlpnl_AllRxns.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpnl_AllRxns.Location = new System.Drawing.Point(0, 0);
            this.tlpnl_AllRxns.Name = "tlpnl_AllRxns";
            this.tlpnl_AllRxns.RowCount = 1;
            this.tlpnl_AllRxns.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpnl_AllRxns.Size = new System.Drawing.Size(930, 528);
            this.tlpnl_AllRxns.TabIndex = 0;
            this.tlpnl_AllRxns.TabStop = true;
            this.tlpnl_AllRxns.Layout += new System.Windows.Forms.LayoutEventHandler(this.tlpnl_AllRxns_Layout);
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.White;
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlTop.Controls.Add(this.btnExport);
            this.pnlTop.Controls.Add(this.lblRxnCnt);
            this.pnlTop.Controls.Add(this.label2);
            this.pnlTop.Controls.Add(this.pnlNavigCntrls);
            this.pnlTop.Controls.Add(this.txtNUM);
            this.pnlTop.Controls.Add(this.lblSrch);
            this.pnlTop.Controls.Add(this.lblTAN);
            this.pnlTop.Controls.Add(this.lblHdrTAN);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(930, 32);
            this.pnlTop.TabIndex = 1;
            // 
            // lblRxnCnt
            // 
            this.lblRxnCnt.AutoSize = true;
            this.lblRxnCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblRxnCnt.Location = new System.Drawing.Point(580, 5);
            this.lblRxnCnt.Name = "lblRxnCnt";
            this.lblRxnCnt.Size = new System.Drawing.Size(16, 17);
            this.lblRxnCnt.TabIndex = 47;
            this.lblRxnCnt.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(487, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 17);
            this.label2.TabIndex = 46;
            this.label2.Text = "No.of Pages: ";
            // 
            // pnlNavigCntrls
            // 
            this.pnlNavigCntrls.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.pnlNavigCntrls.Controls.Add(this.numGotoRecord);
            this.pnlNavigCntrls.Controls.Add(this.btnLast);
            this.pnlNavigCntrls.Controls.Add(this.btnNext);
            this.pnlNavigCntrls.Controls.Add(this.btnPrevious);
            this.pnlNavigCntrls.Controls.Add(this.btnFirst);
            this.pnlNavigCntrls.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlNavigCntrls.Location = new System.Drawing.Point(714, 0);
            this.pnlNavigCntrls.Name = "pnlNavigCntrls";
            this.pnlNavigCntrls.Size = new System.Drawing.Size(212, 28);
            this.pnlNavigCntrls.TabIndex = 45;
            // 
            // numGotoRecord
            // 
            this.numGotoRecord.InterceptArrowKeys = false;
            this.numGotoRecord.Location = new System.Drawing.Point(84, 2);
            this.numGotoRecord.Name = "numGotoRecord";
            this.numGotoRecord.Size = new System.Drawing.Size(42, 25);
            this.numGotoRecord.TabIndex = 43;
            this.toolTip1.SetToolTip(this.numGotoRecord, "Go to Page");
            this.numGotoRecord.ValueChanged += new System.EventHandler(this.numGotoRecord_ValueChanged);
            // 
            // btnLast
            // 
            this.btnLast.BackgroundImage = global::IndxReactNarr.Properties.Resources.resultset_last;
            this.btnLast.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnLast.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLast.Enabled = false;
            this.btnLast.Location = new System.Drawing.Point(173, 0);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(35, 27);
            this.btnLast.TabIndex = 38;
            this.toolTip1.SetToolTip(this.btnLast, "Last Page");
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnNext
            // 
            this.btnNext.BackgroundImage = global::IndxReactNarr.Properties.Resources.resultset_next;
            this.btnNext.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnNext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNext.Enabled = false;
            this.btnNext.Location = new System.Drawing.Point(133, 0);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(35, 27);
            this.btnNext.TabIndex = 37;
            this.toolTip1.SetToolTip(this.btnNext, "Next Page");
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.BackgroundImage = global::IndxReactNarr.Properties.Resources.resultset_previous;
            this.btnPrevious.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnPrevious.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPrevious.Enabled = false;
            this.btnPrevious.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrevious.Location = new System.Drawing.Point(43, 0);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(35, 27);
            this.btnPrevious.TabIndex = 36;
            this.toolTip1.SetToolTip(this.btnPrevious, "Previous Page");
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnFirst
            // 
            this.btnFirst.BackgroundImage = global::IndxReactNarr.Properties.Resources.resultset_first;
            this.btnFirst.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnFirst.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFirst.Enabled = false;
            this.btnFirst.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFirst.Location = new System.Drawing.Point(3, 0);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(35, 27);
            this.btnFirst.TabIndex = 35;
            this.toolTip1.SetToolTip(this.btnFirst, "First Page");
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // txtNUM
            // 
            this.txtNUM.BackColor = System.Drawing.Color.White;
            this.txtNUM.ForeColor = System.Drawing.Color.Blue;
            this.txtNUM.Location = new System.Drawing.Point(269, 1);
            this.txtNUM.Name = "txtNUM";
            this.txtNUM.Size = new System.Drawing.Size(93, 25);
            this.txtNUM.TabIndex = 8;
            this.txtNUM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNUM_KeyPress);
            // 
            // lblSrch
            // 
            this.lblSrch.AutoSize = true;
            this.lblSrch.Location = new System.Drawing.Point(167, 5);
            this.lblSrch.Name = "lblSrch";
            this.lblSrch.Size = new System.Drawing.Size(99, 17);
            this.lblSrch.TabIndex = 2;
            this.lblSrch.Text = "Search Product";
            // 
            // lblTAN
            // 
            this.lblTAN.AutoSize = true;
            this.lblTAN.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTAN.ForeColor = System.Drawing.Color.Blue;
            this.lblTAN.Location = new System.Drawing.Point(49, 5);
            this.lblTAN.Name = "lblTAN";
            this.lblTAN.Size = new System.Drawing.Size(40, 17);
            this.lblTAN.TabIndex = 1;
            this.lblTAN.Text = "TAN";
            // 
            // lblHdrTAN
            // 
            this.lblHdrTAN.AutoSize = true;
            this.lblHdrTAN.Location = new System.Drawing.Point(4, 5);
            this.lblHdrTAN.Name = "lblHdrTAN";
            this.lblHdrTAN.Size = new System.Drawing.Size(39, 17);
            this.lblHdrTAN.TabIndex = 0;
            this.lblHdrTAN.Text = "TAN";
            // 
            // btnExport
            // 
            this.btnExport.Location = new System.Drawing.Point(628, 2);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(75, 23);
            this.btnExport.TabIndex = 48;
            this.btnExport.Text = "Pdf";
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // frmGetAllRxns
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(930, 560);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlTop);
            this.DoubleBuffered = true;
            this.Name = "frmGetAllRxns";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Get All Reactions";
            this.Load += new System.EventHandler(this.frmGetAllRxns_Load);
            this.Enter += new System.EventHandler(this.frmGetAllRxns_Enter);
            this.pnlMain.ResumeLayout(false);
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlNavigCntrls.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numGotoRecord)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Label lblTAN;
        private System.Windows.Forms.Label lblHdrTAN;
        private System.Windows.Forms.Label lblSrch;
        private System.Windows.Forms.TextBox txtNUM;
        public System.Windows.Forms.TableLayoutPanel tlpnl_AllRxns;
        private System.Windows.Forms.Panel pnlNavigCntrls;
        public System.Windows.Forms.NumericUpDown numGotoRecord;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.Label lblRxnCnt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button btnExport;
    }
}