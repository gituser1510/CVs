﻿namespace IndxReactNarr
{
    partial class frmNUMInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ucNUMDtls = new IndxReactNarr.ucNUMDetails();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // ucNUMDtls
            // 
            this.ucNUMDtls.BackColor = System.Drawing.Color.White;
            this.ucNUMDtls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucNUMDtls.HexCodeArr = null;
            this.ucNUMDtls.IUPACName = "";
            this.ucNUMDtls.Location = new System.Drawing.Point(0, 0);
            this.ucNUMDtls.MolFormula = "";
            this.ucNUMDtls.MolFormulaArr = null;
            this.ucNUMDtls.Name = "ucNUMDtls";
            this.ucNUMDtls.NrnNum = "";
            this.ucNUMDtls.RegNo = "";
            this.ucNUMDtls.Size = new System.Drawing.Size(897, 403);
            this.ucNUMDtls.StereoChemArr = null;
            this.ucNUMDtls.Synonyms = "";
            this.ucNUMDtls.TabIndex = 0;
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.ucNUMDtls);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(897, 403);
            this.pnlMain.TabIndex = 1;
            // 
            // frmNUMInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(897, 403);
            this.Controls.Add(this.pnlMain);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmNUMInfo";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NUM Information";
            this.Load += new System.EventHandler(this.frmNUMInfo_Load);
            this.pnlMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private ucNUMDetails ucNUMDtls;
        private System.Windows.Forms.Panel pnlMain;
    }
}