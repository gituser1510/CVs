﻿namespace IndxReactNarr
{
    partial class frmMoveTanToBatch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlBody = new System.Windows.Forms.Panel();
            this.pnlBatch = new System.Windows.Forms.Panel();
            this.dgvSelectedTANs = new System.Windows.Forms.DataGridView();
            this.dgvAvailTANs = new System.Windows.Forms.DataGridView();
            this.lblSelTANCnt = new System.Windows.Forms.Label();
            this.lblSel_Cnt = new System.Windows.Forms.Label();
            this.lblAvlTANCnt = new System.Windows.Forms.Label();
            this.lblAvl_Cnt = new System.Windows.Forms.Label();
            this.lblSelTANs = new System.Windows.Forms.Label();
            this.lblAvailTANs = new System.Windows.Forms.Label();
            this.pnlButtons = new System.Windows.Forms.Panel();
            this.txtBatch_Final = new System.Windows.Forms.TextBox();
            this.cmbMovToBNo = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblAssTansFor = new System.Windows.Forms.Label();
            this.btnMove = new System.Windows.Forms.Button();
            this.btnDelOne = new System.Windows.Forms.Button();
            this.btnSelOne = new System.Windows.Forms.Button();
            this.pnlSrch = new System.Windows.Forms.Panel();
            this.lblTAN = new System.Windows.Forms.Label();
            this.txtTANSrch = new System.Windows.Forms.TextBox();
            this.lblBatch = new System.Windows.Forms.Label();
            this.cmbShip = new System.Windows.Forms.ComboBox();
            this.lblBNo = new System.Windows.Forms.Label();
            this.cmbBatchNo = new System.Windows.Forms.ComboBox();
            this.dgvMovedTANs = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTanID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTanName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colATanID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colATanName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colABatchNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colATanType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAReactCnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colATaskStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colsTanID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSTanName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSBatchNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colsTanType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSReactcnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTaskStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain.SuspendLayout();
            this.pnlBody.SuspendLayout();
            this.pnlBatch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSelectedTANs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAvailTANs)).BeginInit();
            this.pnlButtons.SuspendLayout();
            this.pnlSrch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMovedTANs)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.pnlBody);
            this.pnlMain.Controls.Add(this.dgvMovedTANs);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1005, 561);
            this.pnlMain.TabIndex = 0;
            // 
            // pnlBody
            // 
            this.pnlBody.Controls.Add(this.pnlBatch);
            this.pnlBody.Controls.Add(this.pnlSrch);
            this.pnlBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlBody.Location = new System.Drawing.Point(0, 0);
            this.pnlBody.Name = "pnlBody";
            this.pnlBody.Size = new System.Drawing.Size(1005, 394);
            this.pnlBody.TabIndex = 28;
            // 
            // pnlBatch
            // 
            this.pnlBatch.BackColor = System.Drawing.Color.White;
            this.pnlBatch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBatch.Controls.Add(this.dgvSelectedTANs);
            this.pnlBatch.Controls.Add(this.dgvAvailTANs);
            this.pnlBatch.Controls.Add(this.lblSelTANCnt);
            this.pnlBatch.Controls.Add(this.lblSel_Cnt);
            this.pnlBatch.Controls.Add(this.lblAvlTANCnt);
            this.pnlBatch.Controls.Add(this.lblAvl_Cnt);
            this.pnlBatch.Controls.Add(this.lblSelTANs);
            this.pnlBatch.Controls.Add(this.lblAvailTANs);
            this.pnlBatch.Controls.Add(this.pnlButtons);
            this.pnlBatch.Controls.Add(this.btnDelOne);
            this.pnlBatch.Controls.Add(this.btnSelOne);
            this.pnlBatch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlBatch.Location = new System.Drawing.Point(0, 34);
            this.pnlBatch.Name = "pnlBatch";
            this.pnlBatch.Size = new System.Drawing.Size(1005, 360);
            this.pnlBatch.TabIndex = 33;
            // 
            // dgvSelectedTANs
            // 
            this.dgvSelectedTANs.AllowUserToAddRows = false;
            this.dgvSelectedTANs.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvSelectedTANs.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSelectedTANs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSelectedTANs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSelectedTANs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colsTanID,
            this.colSTanName,
            this.colSBatchNo,
            this.colsTanType,
            this.colSReactcnt,
            this.colTaskStatus});
            this.dgvSelectedTANs.Location = new System.Drawing.Point(515, 22);
            this.dgvSelectedTANs.Name = "dgvSelectedTANs";
            this.dgvSelectedTANs.ReadOnly = true;
            this.dgvSelectedTANs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSelectedTANs.Size = new System.Drawing.Size(487, 299);
            this.dgvSelectedTANs.TabIndex = 45;
            this.dgvSelectedTANs.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvSelectedTANs_RowPostPaint);
            // 
            // dgvAvailTANs
            // 
            this.dgvAvailTANs.AllowUserToAddRows = false;
            this.dgvAvailTANs.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvAvailTANs.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvAvailTANs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAvailTANs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAvailTANs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colATanID,
            this.colATanName,
            this.colABatchNo,
            this.colATanType,
            this.colAReactCnt,
            this.colATaskStatus});
            this.dgvAvailTANs.Location = new System.Drawing.Point(0, 22);
            this.dgvAvailTANs.Name = "dgvAvailTANs";
            this.dgvAvailTANs.ReadOnly = true;
            this.dgvAvailTANs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAvailTANs.Size = new System.Drawing.Size(462, 299);
            this.dgvAvailTANs.TabIndex = 44;
            this.dgvAvailTANs.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvAvailTANs_RowPostPaint);
            // 
            // lblSelTANCnt
            // 
            this.lblSelTANCnt.AutoSize = true;
            this.lblSelTANCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelTANCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblSelTANCnt.Location = new System.Drawing.Point(648, 0);
            this.lblSelTANCnt.Name = "lblSelTANCnt";
            this.lblSelTANCnt.Size = new System.Drawing.Size(16, 17);
            this.lblSelTANCnt.TabIndex = 43;
            this.lblSelTANCnt.Text = "0";
            // 
            // lblSel_Cnt
            // 
            this.lblSel_Cnt.AutoSize = true;
            this.lblSel_Cnt.Location = new System.Drawing.Point(606, 1);
            this.lblSel_Cnt.Name = "lblSel_Cnt";
            this.lblSel_Cnt.Size = new System.Drawing.Size(50, 17);
            this.lblSel_Cnt.TabIndex = 42;
            this.lblSel_Cnt.Text = "Count: ";
            // 
            // lblAvlTANCnt
            // 
            this.lblAvlTANCnt.AutoSize = true;
            this.lblAvlTANCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAvlTANCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblAvlTANCnt.Location = new System.Drawing.Point(144, 2);
            this.lblAvlTANCnt.Name = "lblAvlTANCnt";
            this.lblAvlTANCnt.Size = new System.Drawing.Size(16, 17);
            this.lblAvlTANCnt.TabIndex = 41;
            this.lblAvlTANCnt.Text = "0";
            // 
            // lblAvl_Cnt
            // 
            this.lblAvl_Cnt.AutoSize = true;
            this.lblAvl_Cnt.Location = new System.Drawing.Point(100, 2);
            this.lblAvl_Cnt.Name = "lblAvl_Cnt";
            this.lblAvl_Cnt.Size = new System.Drawing.Size(50, 17);
            this.lblAvl_Cnt.TabIndex = 40;
            this.lblAvl_Cnt.Text = "Count: ";
            // 
            // lblSelTANs
            // 
            this.lblSelTANs.AutoSize = true;
            this.lblSelTANs.Location = new System.Drawing.Point(512, 2);
            this.lblSelTANs.Name = "lblSelTANs";
            this.lblSelTANs.Size = new System.Drawing.Size(98, 17);
            this.lblSelTANs.TabIndex = 39;
            this.lblSelTANs.Text = "Selected TANs";
            // 
            // lblAvailTANs
            // 
            this.lblAvailTANs.AutoSize = true;
            this.lblAvailTANs.Location = new System.Drawing.Point(2, 2);
            this.lblAvailTANs.Name = "lblAvailTANs";
            this.lblAvailTANs.Size = new System.Drawing.Size(102, 17);
            this.lblAvailTANs.TabIndex = 38;
            this.lblAvailTANs.Text = "Available TANs";
            // 
            // pnlButtons
            // 
            this.pnlButtons.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlButtons.Controls.Add(this.txtBatch_Final);
            this.pnlButtons.Controls.Add(this.cmbMovToBNo);
            this.pnlButtons.Controls.Add(this.label1);
            this.pnlButtons.Controls.Add(this.lblAssTansFor);
            this.pnlButtons.Controls.Add(this.btnMove);
            this.pnlButtons.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlButtons.Location = new System.Drawing.Point(0, 321);
            this.pnlButtons.Name = "pnlButtons";
            this.pnlButtons.Size = new System.Drawing.Size(1003, 37);
            this.pnlButtons.TabIndex = 37;
            // 
            // txtBatch_Final
            // 
            this.txtBatch_Final.BackColor = System.Drawing.Color.Bisque;
            this.txtBatch_Final.ForeColor = System.Drawing.Color.Blue;
            this.txtBatch_Final.Location = new System.Drawing.Point(63, 5);
            this.txtBatch_Final.Name = "txtBatch_Final";
            this.txtBatch_Final.ReadOnly = true;
            this.txtBatch_Final.Size = new System.Drawing.Size(184, 25);
            this.txtBatch_Final.TabIndex = 25;
            this.txtBatch_Final.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cmbMovToBNo
            // 
            this.cmbMovToBNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMovToBNo.FormattingEnabled = true;
            this.cmbMovToBNo.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cmbMovToBNo.Location = new System.Drawing.Point(357, 5);
            this.cmbMovToBNo.Name = "cmbMovToBNo";
            this.cmbMovToBNo.Size = new System.Drawing.Size(50, 25);
            this.cmbMovToBNo.TabIndex = 24;
            this.cmbMovToBNo.SelectionChangeCommitted += new System.EventHandler(this.cmbMovToBNo_SelectionChangeCommitted);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(248, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 17);
            this.label1.TabIndex = 23;
            this.label1.Text = "Dest.. Batch No.";
            // 
            // lblAssTansFor
            // 
            this.lblAssTansFor.AutoSize = true;
            this.lblAssTansFor.Location = new System.Drawing.Point(5, 9);
            this.lblAssTansFor.Name = "lblAssTansFor";
            this.lblAssTansFor.Size = new System.Drawing.Size(57, 17);
            this.lblAssTansFor.TabIndex = 4;
            this.lblAssTansFor.Text = "Move to";
            // 
            // btnMove
            // 
            this.btnMove.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMove.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnMove.Location = new System.Drawing.Point(909, 0);
            this.btnMove.Name = "btnMove";
            this.btnMove.Size = new System.Drawing.Size(90, 33);
            this.btnMove.TabIndex = 0;
            this.btnMove.Text = "Move";
            this.btnMove.UseVisualStyleBackColor = true;
            this.btnMove.Click += new System.EventHandler(this.btnMove_Click);
            // 
            // btnDelOne
            // 
            this.btnDelOne.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelOne.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelOne.Location = new System.Drawing.Point(468, 162);
            this.btnDelOne.Name = "btnDelOne";
            this.btnDelOne.Size = new System.Drawing.Size(41, 35);
            this.btnDelOne.TabIndex = 36;
            this.btnDelOne.Text = "<";
            this.btnDelOne.UseVisualStyleBackColor = true;
            this.btnDelOne.Click += new System.EventHandler(this.btnDelOne_Click);
            // 
            // btnSelOne
            // 
            this.btnSelOne.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSelOne.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelOne.Location = new System.Drawing.Point(468, 95);
            this.btnSelOne.Name = "btnSelOne";
            this.btnSelOne.Size = new System.Drawing.Size(41, 35);
            this.btnSelOne.TabIndex = 35;
            this.btnSelOne.Text = ">";
            this.btnSelOne.UseVisualStyleBackColor = true;
            this.btnSelOne.Click += new System.EventHandler(this.btnSelOne_Click);
            // 
            // pnlSrch
            // 
            this.pnlSrch.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pnlSrch.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlSrch.Controls.Add(this.lblTAN);
            this.pnlSrch.Controls.Add(this.txtTANSrch);
            this.pnlSrch.Controls.Add(this.lblBatch);
            this.pnlSrch.Controls.Add(this.cmbShip);
            this.pnlSrch.Controls.Add(this.lblBNo);
            this.pnlSrch.Controls.Add(this.cmbBatchNo);
            this.pnlSrch.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSrch.Location = new System.Drawing.Point(0, 0);
            this.pnlSrch.Name = "pnlSrch";
            this.pnlSrch.Size = new System.Drawing.Size(1005, 34);
            this.pnlSrch.TabIndex = 0;
            // 
            // lblTAN
            // 
            this.lblTAN.AutoSize = true;
            this.lblTAN.ForeColor = System.Drawing.Color.Blue;
            this.lblTAN.Location = new System.Drawing.Point(413, 6);
            this.lblTAN.Name = "lblTAN";
            this.lblTAN.Size = new System.Drawing.Size(83, 17);
            this.lblTAN.TabIndex = 40;
            this.lblTAN.Text = "TAN Search";
            // 
            // txtTANSrch
            // 
            this.txtTANSrch.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.txtTANSrch.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTANSrch.ForeColor = System.Drawing.Color.Blue;
            this.txtTANSrch.Location = new System.Drawing.Point(502, 3);
            this.txtTANSrch.Name = "txtTANSrch";
            this.txtTANSrch.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtTANSrch.Size = new System.Drawing.Size(497, 25);
            this.txtTANSrch.TabIndex = 39;
            this.txtTANSrch.TextChanged += new System.EventHandler(this.txtTANSrch_TextChanged);
            // 
            // lblBatch
            // 
            this.lblBatch.AutoSize = true;
            this.lblBatch.Location = new System.Drawing.Point(5, 7);
            this.lblBatch.Name = "lblBatch";
            this.lblBatch.Size = new System.Drawing.Size(62, 17);
            this.lblBatch.TabIndex = 35;
            this.lblBatch.Text = "Shipment";
            // 
            // cmbShip
            // 
            this.cmbShip.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbShip.FormattingEnabled = true;
            this.cmbShip.Items.AddRange(new object[] {
            "rxnfile.800002",
            "rxnfile.800003",
            "rxnfile.800004"});
            this.cmbShip.Location = new System.Drawing.Point(67, 3);
            this.cmbShip.Name = "cmbShip";
            this.cmbShip.Size = new System.Drawing.Size(181, 25);
            this.cmbShip.TabIndex = 36;
            this.cmbShip.SelectionChangeCommitted += new System.EventHandler(this.cmbShip_SelectionChangeCommitted);
            // 
            // lblBNo
            // 
            this.lblBNo.AutoSize = true;
            this.lblBNo.Location = new System.Drawing.Point(251, 6);
            this.lblBNo.Name = "lblBNo";
            this.lblBNo.Size = new System.Drawing.Size(110, 17);
            this.lblBNo.TabIndex = 37;
            this.lblBNo.Text = "Source Batch No";
            // 
            // cmbBatchNo
            // 
            this.cmbBatchNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBatchNo.FormattingEnabled = true;
            this.cmbBatchNo.Items.AddRange(new object[] {
            "",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cmbBatchNo.Location = new System.Drawing.Point(363, 2);
            this.cmbBatchNo.Name = "cmbBatchNo";
            this.cmbBatchNo.Size = new System.Drawing.Size(47, 25);
            this.cmbBatchNo.TabIndex = 38;
            this.cmbBatchNo.SelectionChangeCommitted += new System.EventHandler(this.cmbBatchNo_SelectionChangeCommitted);
            // 
            // dgvMovedTANs
            // 
            this.dgvMovedTANs.AllowUserToAddRows = false;
            this.dgvMovedTANs.AllowUserToDeleteRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.LemonChiffon;
            this.dgvMovedTANs.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvMovedTANs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvMovedTANs.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvMovedTANs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMovedTANs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTanID,
            this.colTanName});
            this.dgvMovedTANs.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvMovedTANs.Location = new System.Drawing.Point(0, 394);
            this.dgvMovedTANs.Name = "dgvMovedTANs";
            this.dgvMovedTANs.ReadOnly = true;
            this.dgvMovedTANs.Size = new System.Drawing.Size(1005, 167);
            this.dgvMovedTANs.TabIndex = 27;
            this.dgvMovedTANs.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvMovedTANs_RowPostPaint);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "TAN ID";
            this.dataGridViewTextBoxColumn1.HeaderText = "BT_ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Visible = false;
            this.dataGridViewTextBoxColumn1.Width = 50;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.DataPropertyName = "TAN NAME";
            this.dataGridViewTextBoxColumn2.FillWeight = 81.21828F;
            this.dataGridViewTextBoxColumn2.HeaderText = "BNo";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn3.DataPropertyName = "BATCH NO";
            this.dataGridViewTextBoxColumn3.FillWeight = 106.2606F;
            this.dataGridViewTextBoxColumn3.HeaderText = "TAN";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "TAN TYPE";
            this.dataGridViewTextBoxColumn4.FillWeight = 106.2606F;
            this.dataGridViewTextBoxColumn4.HeaderText = "DocClass";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 118;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "REACTION CNT";
            this.dataGridViewTextBoxColumn5.FillWeight = 106.2606F;
            this.dataGridViewTextBoxColumn5.HeaderText = "Priority";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 118;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn6.DataPropertyName = "TASK STATUS";
            this.dataGridViewTextBoxColumn6.HeaderText = "BT_ID";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Visible = false;
            this.dataGridViewTextBoxColumn6.Width = 20;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn7.DataPropertyName = "TAN ID";
            this.dataGridViewTextBoxColumn7.FillWeight = 81.21828F;
            this.dataGridViewTextBoxColumn7.HeaderText = "BNo";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Visible = false;
            this.dataGridViewTextBoxColumn7.Width = 85;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn8.DataPropertyName = "TAN NAME";
            this.dataGridViewTextBoxColumn8.FillWeight = 106.2606F;
            this.dataGridViewTextBoxColumn8.HeaderText = "TAN";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "BATCH NO";
            this.dataGridViewTextBoxColumn9.FillWeight = 106.2606F;
            this.dataGridViewTextBoxColumn9.HeaderText = "DocClass";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Width = 111;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "TAN TYPE";
            this.dataGridViewTextBoxColumn10.FillWeight = 106.2606F;
            this.dataGridViewTextBoxColumn10.HeaderText = "Priority";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Width = 112;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "REACTION CNT";
            this.dataGridViewTextBoxColumn11.FillWeight = 12.18246F;
            this.dataGridViewTextBoxColumn11.HeaderText = "ID";
            this.dataGridViewTextBoxColumn11.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Visible = false;
            this.dataGridViewTextBoxColumn11.Width = 61;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn12.DataPropertyName = "TASK STATUS";
            this.dataGridViewTextBoxColumn12.HeaderText = "TAN";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Visible = false;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "TAN ID";
            this.dataGridViewTextBoxColumn13.HeaderText = "TanID";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Visible = false;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn14.DataPropertyName = "TAN NAME";
            this.dataGridViewTextBoxColumn14.HeaderText = "Tan Name";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            // 
            // colTanID
            // 
            this.colTanID.DataPropertyName = "TAN_ID";
            this.colTanID.HeaderText = "TanID";
            this.colTanID.Name = "colTanID";
            this.colTanID.ReadOnly = true;
            this.colTanID.Visible = false;
            // 
            // colTanName
            // 
            this.colTanName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colTanName.DataPropertyName = "TAN_NAME";
            this.colTanName.HeaderText = "Tan Name";
            this.colTanName.Name = "colTanName";
            this.colTanName.ReadOnly = true;
            // 
            // colATanID
            // 
            this.colATanID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colATanID.DataPropertyName = "TAN_ID";
            this.colATanID.HeaderText = "TanID";
            this.colATanID.Name = "colATanID";
            this.colATanID.ReadOnly = true;
            this.colATanID.Visible = false;
            this.colATanID.Width = 20;
            // 
            // colATanName
            // 
            this.colATanName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colATanName.DataPropertyName = "TAN_NAME";
            this.colATanName.FillWeight = 28.90353F;
            this.colATanName.HeaderText = "Tan Name";
            this.colATanName.Name = "colATanName";
            this.colATanName.ReadOnly = true;
            // 
            // colABatchNo
            // 
            this.colABatchNo.DataPropertyName = "BATCH_NO";
            this.colABatchNo.FillWeight = 21.18372F;
            this.colABatchNo.HeaderText = "Batch No";
            this.colABatchNo.Name = "colABatchNo";
            this.colABatchNo.ReadOnly = true;
            this.colABatchNo.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // colATanType
            // 
            this.colATanType.DataPropertyName = "TAN_TYPE";
            this.colATanType.FillWeight = 21.19414F;
            this.colATanType.HeaderText = "Tan Type";
            this.colATanType.Name = "colATanType";
            this.colATanType.ReadOnly = true;
            // 
            // colAReactCnt
            // 
            this.colAReactCnt.DataPropertyName = "REACTION_CNT";
            this.colAReactCnt.FillWeight = 12.18246F;
            this.colAReactCnt.HeaderText = "React CNT";
            this.colAReactCnt.MinimumWidth = 10;
            this.colAReactCnt.Name = "colAReactCnt";
            this.colAReactCnt.ReadOnly = true;
            // 
            // colATaskStatus
            // 
            this.colATaskStatus.DataPropertyName = "TASK_STATUS";
            this.colATaskStatus.HeaderText = "Task Status";
            this.colATaskStatus.Name = "colATaskStatus";
            this.colATaskStatus.ReadOnly = true;
            this.colATaskStatus.Visible = false;
            // 
            // colsTanID
            // 
            this.colsTanID.DataPropertyName = "TAN_ID";
            this.colsTanID.HeaderText = "TanID";
            this.colsTanID.Name = "colsTanID";
            this.colsTanID.ReadOnly = true;
            this.colsTanID.Visible = false;
            // 
            // colSTanName
            // 
            this.colSTanName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colSTanName.DataPropertyName = "TAN_NAME";
            this.colSTanName.FillWeight = 23.03064F;
            this.colSTanName.HeaderText = "Tan Name";
            this.colSTanName.Name = "colSTanName";
            this.colSTanName.ReadOnly = true;
            // 
            // colSBatchNo
            // 
            this.colSBatchNo.DataPropertyName = "BATCH_NO";
            this.colSBatchNo.FillWeight = 15.3954F;
            this.colSBatchNo.HeaderText = "Batch No";
            this.colSBatchNo.MinimumWidth = 10;
            this.colSBatchNo.Name = "colSBatchNo";
            this.colSBatchNo.ReadOnly = true;
            // 
            // colsTanType
            // 
            this.colsTanType.DataPropertyName = "TAN_TYPE";
            this.colsTanType.FillWeight = 13.47578F;
            this.colsTanType.HeaderText = "Tan Type";
            this.colsTanType.Name = "colsTanType";
            this.colsTanType.ReadOnly = true;
            // 
            // colSReactcnt
            // 
            this.colSReactcnt.DataPropertyName = "REACTION_CNT";
            this.colSReactcnt.FillWeight = 8.756064F;
            this.colSReactcnt.HeaderText = "React CNT";
            this.colSReactcnt.MinimumWidth = 10;
            this.colSReactcnt.Name = "colSReactcnt";
            this.colSReactcnt.ReadOnly = true;
            // 
            // colTaskStatus
            // 
            this.colTaskStatus.DataPropertyName = "TASK_STATUS";
            this.colTaskStatus.HeaderText = "Task Status";
            this.colTaskStatus.Name = "colTaskStatus";
            this.colTaskStatus.ReadOnly = true;
            this.colTaskStatus.Visible = false;
            // 
            // frmMoveTanToBatch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1005, 561);
            this.Controls.Add(this.pnlMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmMoveTanToBatch";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Update Shipment TANs Batch No.";
            this.Load += new System.EventHandler(this.frmMoveTanToBatch_Load);
            this.pnlMain.ResumeLayout(false);
            this.pnlBody.ResumeLayout(false);
            this.pnlBatch.ResumeLayout(false);
            this.pnlBatch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSelectedTANs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAvailTANs)).EndInit();
            this.pnlButtons.ResumeLayout(false);
            this.pnlButtons.PerformLayout();
            this.pnlSrch.ResumeLayout(false);
            this.pnlSrch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMovedTANs)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.DataGridView dgvMovedTANs;
        private System.Windows.Forms.Panel pnlBody;
        private System.Windows.Forms.Panel pnlBatch;
        private System.Windows.Forms.DataGridView dgvSelectedTANs;
        private System.Windows.Forms.DataGridView dgvAvailTANs;
        private System.Windows.Forms.Label lblSelTANCnt;
        private System.Windows.Forms.Label lblSel_Cnt;
        private System.Windows.Forms.Label lblAvlTANCnt;
        private System.Windows.Forms.Label lblAvl_Cnt;
        private System.Windows.Forms.Label lblSelTANs;
        private System.Windows.Forms.Label lblAvailTANs;
        private System.Windows.Forms.Panel pnlButtons;
        private System.Windows.Forms.TextBox txtBatch_Final;
        private System.Windows.Forms.ComboBox cmbMovToBNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblAssTansFor;
        private System.Windows.Forms.Button btnMove;
        private System.Windows.Forms.Button btnDelOne;
        private System.Windows.Forms.Button btnSelOne;
        private System.Windows.Forms.Panel pnlSrch;
        private System.Windows.Forms.Label lblTAN;
        private System.Windows.Forms.TextBox txtTANSrch;
        private System.Windows.Forms.Label lblBatch;
        private System.Windows.Forms.ComboBox cmbShip;
        private System.Windows.Forms.Label lblBNo;
        private System.Windows.Forms.ComboBox cmbBatchNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTanID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTanName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn colsTanID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSTanName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSBatchNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colsTanType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSReactcnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTaskStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn colATanID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colATanName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colABatchNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colATanType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAReactCnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn colATaskStatus;

    }
}