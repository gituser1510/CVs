﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarrDAL;
using IndxReactNarr.Generic;
using IndxReactNarr.Common;
using System.Collections;

namespace IndxReactNarr
{
    public partial class frmMoveTanToBatch : Form
    {
        public frmMoveTanToBatch()
        {
            InitializeComponent();
        }

        #region Property Procedures

        private DataTable _dtavailtans = null;
        public DataTable AvailableTANsTbl
        {
            get
            {
                return _dtavailtans;
            }
            set
            {
                _dtavailtans = value;
            }
        }

        private DataTable _dtselectedtans = null;
        public DataTable SelectedTANsTbl
        {
            get
            {
                return _dtselectedtans;
            }
            set
            {
                _dtselectedtans = value;
            }
        }

        DataTable dtShipDtls = null;
        DataTable dtTanTypes = null;

        #endregion

        #region Public Variables

        ArrayList availTANList = new ArrayList();
        ArrayList selTANList = new ArrayList();
        DataTable dtselTans = null;

        #endregion

        #region Form Load
        private void frmMoveTanToBatch_Load(object sender, EventArgs e)
        {
            try
            {
                dtShipDtls = ReactDB.GetShipmentDetailsByAppName(GlobalVariables.ApplicationName, out dtTanTypes);

                if (dtShipDtls != null)
                {
                    if (dtShipDtls.Rows.Count > 0)
                    {
                        cmbShip.DataSource = dtShipDtls;
                        cmbShip.DisplayMember = "SHIPMENT_NAME";
                        cmbShip.ValueMember = "SHIPMENT_ID";
                        cmbShip.SelectedIndex = 0;

                        cmbBatchNo.SelectedIndex = 0;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        #endregion

        #region Button click

        private void btnMove_Click(object sender, EventArgs e)
        {
            string ErrMsg = string.Empty;
            try
            {
                if (ValidateUserInputs(out ErrMsg))
                {
                    List<int> liTanIDS = GetSelectedTanIDsFromGridview();

                    if (liTanIDS != null && liTanIDS.Count > 0)
                    {
                        DialogResult DR = MessageBox.Show("Do you Wish to Move TANs", "Move TAN To Batch", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                        if (DR == DialogResult.Yes)
                        {
                            if (ReactDB.MoveTansToAnotherBatch(liTanIDS, cmbMovToBNo.Text))
                            {
                                DialogResult Dr = MessageBox.Show("TANs Moved Successfully ", "Move TAN To Batch", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                if (Dr == DialogResult.OK)
                                {
                                    DataTable dtMovedTans = ShipmentMasterDB.GetTANsForExportOnApp_Shipment(GlobalVariables.ApplicationName, cmbShip.Text.Trim(), Convert.ToInt32(cmbMovToBNo.Text));
                                    dgvSelectedTANs.DataSource = null;
                                    BindMovedTANSToGrid(dtMovedTans);
                                }
                            }
                            else
                            {
                                MessageBox.Show("Error in Moving TANs ", "Move TAN To Batch", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show(ErrMsg, "Move TAN To Batch", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }


            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private bool ValidateUserInputs(out string ErrMsg)
        {
            string strErr = string.Empty;
            bool Status = true;

            try
            {
                if (dgvSelectedTANs == null || dgvSelectedTANs.Rows.Count == 0)
                {
                    Status = false;
                    strErr = strErr.Trim() + Environment.NewLine + "Please select the TANs";
                }
                if (cmbMovToBNo.SelectedIndex < 0)
                {
                    Status = false;
                    strErr = strErr.Trim() + Environment.NewLine + "Please select Destination Batch No to Move";
                }
                else if (cmbMovToBNo.Text.ToString() == cmbBatchNo.Text.ToString())
                {
                    Status = false;
                    strErr = strErr.Trim() + Environment.NewLine + "Source BatchNo and Destination BatchNo Shouldn't be Same";
                }

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            ErrMsg = strErr.Trim();
            return Status;
        }

        private void btnSelOne_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvAvailTANs.Rows.Count > 0)
                {
                    if (dgvAvailTANs.SelectedRows.Count > 0)
                    {
                        dtselTans = AvailableTANsTbl.Clone();

                        int rindex_out = 0;

                        DataGridViewSelectedRowCollection selRowColl = dgvAvailTANs.SelectedRows;
                        if (selRowColl != null)
                        {
                            if (selRowColl.Count > 0)
                            {
                                ArrayList alstRowIDs = new ArrayList();
                                ArrayList alstAvailIDs = new ArrayList();

                                for (int i = 0; i < selRowColl.Count; i++)
                                {
                                    dtselTans.ImportRow(GetSelectedRowFromMainTable(selRowColl[i].Cells[0].Value.ToString(), out rindex_out));
                                    alstAvailIDs.Add(selRowColl[i].Cells[0].Value.ToString());
                                    alstRowIDs.Add(rindex_out);
                                }

                                if (alstAvailIDs != null && alstAvailIDs.Count > 0)
                                {
                                    for (int i = 0; i < alstAvailIDs.Count; i++)
                                    {
                                        AvailableTANsTbl.AsEnumerable().Where(r => r.Field<Int64>("TAN_ID") == Convert.ToInt64(alstAvailIDs[i])).ToList().ForEach(row => row.Delete());
                                        AvailableTANsTbl.AcceptChanges();
                                    }

                                }
                            }
                        }

                        DataView dvTemp = dtselTans.DefaultView;
                        dvTemp.Sort = "TAN_ID asc";
                        dtselTans = dvTemp.ToTable();

                        if (SelectedTANsTbl == null)
                        {
                            SelectedTANsTbl = dtselTans.Clone();
                        }

                        foreach (DataRow DR in dtselTans.Rows)
                        {
                            SelectedTANsTbl.ImportRow(DR);
                        }

                        //Bind data to Selected TANs grid
                        BindDataToSelTANGrid(SelectedTANsTbl);

                        //Bind data to Available TANs grid
                        BindDataToAvailTANGrid(AvailableTANsTbl);

                        txtTANSrch.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnDelOne_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvSelectedTANs.Rows.Count > 0)
                {
                    if (dgvSelectedTANs.SelectedRows.Count > 0)
                    {
                        DataTable dtAvailTans = AvailableTANsTbl;
                        int selrowIndx = 0;

                        DataGridViewSelectedRowCollection selRowColl = dgvSelectedTANs.SelectedRows;
                        if (selRowColl != null)
                        {
                            if (selRowColl.Count > 0)
                            {
                                ArrayList alstRowIDs = new ArrayList();
                                ArrayList alstTanIDs = new ArrayList();

                                for (int i = 0; i < selRowColl.Count; i++)
                                {
                                    if (selRowColl[i].Cells[1].Value != null)
                                    {
                                        DataRow dRow = GetSelectedRowFromSelectedTANSTable(selRowColl[i].Cells[0].Value.ToString(), out selrowIndx);
                                        if (dRow != null)
                                        {
                                            alstTanIDs.Add(Convert.ToInt32(selRowColl[i].Cells[0].Value.ToString()));
                                            dtAvailTans.ImportRow(dRow);
                                            alstRowIDs.Add(selrowIndx);
                                        }
                                    }
                                }

                                DataView dvTemp = dtAvailTans.DefaultView;
                                dvTemp.Sort = "TAN_ID asc";
                                dtAvailTans = dvTemp.ToTable();

                                if (alstTanIDs != null && alstTanIDs.Count > 0)
                                {
                                    for (int i = 0; i < alstTanIDs.Count; i++)
                                    {
                                        SelectedTANsTbl.AsEnumerable().Where(r => r.Field<Int64>("TAN_ID") == Convert.ToInt64(alstTanIDs[i])).ToList().ForEach(row => row.Delete());
                                        SelectedTANsTbl.AcceptChanges();
                                    }
                                }
                            }
                        }

                        AvailableTANsTbl = dtAvailTans;

                        //Bind data to Available TANs grid
                        BindDataToAvailTANGrid(dtAvailTans);

                        //Bind data to Selected TANs grid
                        BindDataToSelTANGrid(SelectedTANsTbl);

                        txtTANSrch.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        #region Methods

        private List<int> GetSelectedTanIDsFromGridview()
        {
            List<int> liTemp = new List<int>();
            try
            {
                foreach (DataGridViewRow Dr in dgvSelectedTANs.Rows)
                {
                    liTemp.Add(Convert.ToInt32(Dr.Cells[0].Value.ToString()));
                }

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return liTemp;
        }

        private DataRow GetSelectedRowFromSelectedTANSTable(string _tannumber, out int _rowindex_out)
        {
            try
            {
                if (SelectedTANsTbl != null && SelectedTANsTbl.Rows.Count > 0)
                {
                    DataRow dtRow = null;
                    for (int i = 0; i < SelectedTANsTbl.Rows.Count; i++)
                    {
                        if (SelectedTANsTbl.Rows[i].RowState != DataRowState.Deleted)
                        {
                            if (SelectedTANsTbl.Rows[i]["TAN_ID"].ToString() == _tannumber)
                            {
                                dtRow = SelectedTANsTbl.Rows[i];
                                _rowindex_out = i;
                                return dtRow;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _rowindex_out = 0;
            return null;
        }

        private DataRow GetSelectedRowFromMainTable(string _tannumber, out int _rowindex_out)
        {
            try
            {
                if (AvailableTANsTbl != null)
                {
                    if (AvailableTANsTbl.Rows.Count > 0)
                    {
                        DataRow dtRow = null;
                        for (int i = 0; i < AvailableTANsTbl.Rows.Count; i++)
                        {
                            if (AvailableTANsTbl.Rows[i]["TAN_ID"].ToString() == _tannumber)
                            {
                                dtRow = AvailableTANsTbl.Rows[i];
                                _rowindex_out = i;
                                return dtRow;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _rowindex_out = 0;
            return null;
        }

        private string GetFilterCondition(string _query_tan)
        {
            string strFCond = "";
            try
            {
                if (_query_tan.Trim().Contains(";"))
                {
                    string[] splitter = { ";" };
                    string[] strArrTans = _query_tan.Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);

                    if (strArrTans != null)
                    {
                        if (strArrTans.Length > 0)
                        {
                            for (int i = 0; i < strArrTans.Length; i++)
                            {
                                if (i == 0)
                                {
                                    strFCond = "TAN_NAME Like '" + strArrTans[i] + "%' ";
                                }
                                else
                                {
                                    strFCond += " OR" + " TAN_NAME Like '" + strArrTans[i] + "%'";
                                }
                            }
                        }
                    }
                }
                else
                {
                    strFCond = "TAN_NAME Like '" + _query_tan.Trim() + "%'";
                }
                return strFCond;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strFCond;
        }

        private void GetTANsAndBindToGirdControls()
        {
            try
            {
                if (cmbShip.SelectedIndex >= 0 && cmbBatchNo.SelectedIndex >= 1)
                {
                    //Reset Available & Selected TANs if any existing TANs are there
                    AvailableTANsTbl = null;
                    SelectedTANsTbl = null;
                    dtselTans = null;

                    txtBatch_Final.Text = cmbShip.Text.ToString();

                    DataTable dtTANs = ShipmentMasterDB.GetTANsForExportOnApp_Shipment(GlobalVariables.ApplicationName, cmbShip.Text.Trim(), Convert.ToInt32(cmbBatchNo.Text));

                    if (dtTANs != null)
                    {
                        if (dtTANs.Rows.Count > 0)
                        {
                            AvailableTANsTbl = dtTANs;
                            BindDataToAvailTANGrid(dtTANs);
                        }
                        else
                        {
                            AvailableTANsTbl = null;
                            BindDataToAvailTANGrid(dtTANs);
                        }
                    }
                    else
                    {
                        AvailableTANsTbl = null;
                        BindDataToAvailTANGrid(dtTANs);
                    }

                    dgvSelectedTANs.DataSource = null;
                    dgvMovedTANs.DataSource = null;
                    lblSelTANCnt.Text = "0";

                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindDataToAvailTANGrid(DataTable _dtavailtans)
        {
            try
            {
                if (_dtavailtans != null)
                {
                    dgvAvailTANs.AutoGenerateColumns = false;
                    dgvAvailTANs.DataSource = _dtavailtans;

                    lblAvlTANCnt.Text = _dtavailtans.Rows.Count.ToString();
                }
                else
                {
                    dgvAvailTANs.DataSource = _dtavailtans;

                    lblAvlTANCnt.Text = "0";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindDataToSelTANGrid(DataTable _dtseltans)
        {
            try
            {
                if (_dtseltans != null)
                {
                    dgvSelectedTANs.AutoGenerateColumns = false;
                    dgvSelectedTANs.DataSource = _dtseltans;

                    lblSelTANCnt.Text = _dtseltans.Rows.Count.ToString();
                }
                else
                {
                    dgvSelectedTANs.DataSource = _dtseltans;

                    lblSelTANCnt.Text = "0";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindMovedTANSToGrid(DataTable dtMovedTans)
        {
            try
            {
                if (dtMovedTans != null)
                {
                    dgvMovedTANs.AutoGenerateColumns = false;
                    dgvMovedTANs.DataSource = dtMovedTans;

                }
                else
                {
                    dgvMovedTANs.DataSource = dtMovedTans;

                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        private void MoveTANsFromList()
        {
            //try
            //{
            //    if (txtTANs.Text.Trim() != "")
            //    {
            //        string[] splitter = { "," };
            //        string[] strArrTANs = txtTANs.Text.Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);
            //        if (strArrTANs != null)
            //        {
            //            if (strArrTANs.Length > 0)
            //            {
            //                for (int i = 0; i < strArrTANs.Length; i++)
            //                {
            //                    if (!CAS_Classes.DataConversions.IsValidTanNumber(strArrTANs[i].Trim()))
            //                    {
            //                        MessageBox.Show(strArrTANs[i] + " is not a valid TAN", "Move TAN", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //                        return;
            //                    }
            //                }

            //                DialogResult diaRes = MessageBox.Show("Do you want to move the selected TANs to Batch: " + cmbMovToBatch.SelectedValue.ToString() + " BatchNo: " + cmbMovToBNo.Text.ToString() + " ?",
            //                                              "Move TANs", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            //                if (diaRes == DialogResult.Yes)
            //                {
            //                    string[] strArrBNames = strArrTANs;
            //                    int[] intArrBNos = null;

            //                    if (CASRxnDataAccess.MoveTANsFromOneBatchToOther(strArrBNames, intArrBNos, strArrTANs,
            //                        cmbMovToBatch.SelectedValue.ToString(), Convert.ToInt32(cmbMovToBNo.Text.ToString()),GlobalVariables.URID))
            //                    {
            //                        MessageBox.Show("Moved TANs successfully", "Move TAN", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //                        txtTANs.Text = "";
            //                    }
            //                    else
            //                    {
            //                        MessageBox.Show("Error in moving TANs", "Move TAN", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //                    }
            //                }
            //            }
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    ErrorHandling.WriteErrorLog(ex.ToString());
            //}
        }

        #endregion

        #region Textchanged Event

        private void txtTANSrch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (AvailableTANsTbl != null)
                {
                    if (txtTANSrch.Text.Trim() != "")
                    {
                        string strFCond = GetFilterCondition(txtTANSrch.Text.Trim());

                        DataTable dtAllTANs = AvailableTANsTbl.Copy();
                        DataView dvTemp = dtAllTANs.DefaultView;
                        dvTemp.RowFilter = strFCond;
                        DataTable dtTANs = dvTemp.ToTable();
                        dgvAvailTANs.DataSource = dtTANs;
                    }
                    else
                    {
                        DataTable dtAllTANs = AvailableTANsTbl.Copy();
                        dgvAvailTANs.DataSource = dtAllTANs;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        #endregion

        #region Datagrid view RowPostPaint Events

        private void dgvMovedTANs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvMovedTANs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvMovedTANs.Font);

                if (dgvMovedTANs.RowHeadersWidth < (int)(size.Width + 20)) dgvMovedTANs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;

                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvSelectedTANs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvSelectedTANs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvSelectedTANs.Font);

                if (dgvSelectedTANs.RowHeadersWidth < (int)(size.Width + 20)) dgvSelectedTANs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;

                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvAvailTANs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvAvailTANs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvAvailTANs.Font);

                if (dgvAvailTANs.RowHeadersWidth < (int)(size.Width + 20)) dgvAvailTANs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;

                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        #endregion

        #region comboBox Events

        private void cmbShip_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                GetTANsAndBindToGirdControls();
                //cmbMovToBNo.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void cmbBatchNo_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                GetTANsAndBindToGirdControls();
                cmbMovToBNo.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void cmbMovToBNo_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                if (txtBatch_Final.Text.Trim() != "" && cmbMovToBNo.SelectedIndex >= 0)
                {
                    txtBatch_Final.Text = cmbShip.Text.ToString();

                    //GetBatchTansBindToBatchGrid(txtBatch_Final.Text.Trim(), intBatchNo);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        #region Commented

        //private void GetBatchTansBindToBatchGrid(string batchname, int batchno)
        //{
        //    try
        //    {
        //        if (batchname.Trim() != "" && batchno > 0)
        //        {
        //            txtBatch_Final.Text = cmbShip.SelectedItem.ToString();

        //            DataTable dtBatchTANs = null;// ReactDB.GetTANsOnBatchName_BNo(batchname.Trim(), batchno);
        //            if (dtBatchTANs != null)
        //            {
        //                dgvMovedTANs.AutoGenerateColumns = false;
        //                dgvMovedTANs.DataSource = dtBatchTANs;

        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}
        //private bool ValidateDocClassAndPriority(out string errmsg_out)
        //{
        //    bool blStatus = false;
        //    string strErrMsg = "";
        //    try
        //    {
        //        if (dgvAvailTANs.SelectedRows.Count > 0)
        //        {
        //            DataGridViewSelectedRowCollection selRowColl = dgvAvailTANs.SelectedRows;
        //            if (selRowColl != null)
        //            {
        //                if (selRowColl.Count > 0)
        //                {
        //                    List<string> lstDocClass = new List<string>();

        //                    for (int i = 0; i < selRowColl.Count; i++)
        //                    {
        //                        if (!lstDocClass.Contains(selRowColl[i].Cells["colDocClass_Avl"].Value.ToString()))
        //                        {
        //                            lstDocClass.Add(selRowColl[i].Cells["colDocClass_Avl"].Value.ToString());
        //                        }
        //                    }
        //                    if (lstDocClass.Count > 1)
        //                    {
        //                        blStatus = true;
        //                        strErrMsg = "Selected rows contain different doc_class types : " + string.Join(",", lstDocClass.ToArray());
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    errmsg_out = strErrMsg;
        //    return blStatus;
        //}
        //private void btnAppend_Click(object sender, EventArgs e)
        //{
        //    //try
        //    //{
        //    //    if (chklstAvailTANs.CheckedItems.Count > 0)
        //    //    {
        //    //        if (dtSelTANs == null)
        //    //        {
        //    //            dtSelTANs = new DataTable();
        //    //            dtSelTANs.Columns.Add("BatchName", typeof(string));
        //    //            dtSelTANs.Columns.Add("BatchNo", typeof(string));
        //    //            dtSelTANs.Columns.Add("TAN", typeof(string));
        //    //        }

        //    //        DataRow dtRow = null;

        //    //        for (int i = 0; i < chklstAvailTANs.CheckedItems.Count; i++)
        //    //        {
        //    //            dtRow = dtSelTANs.NewRow();
        //    //            dtRow["BatchName"] = cmbBatch.SelectedValue.ToString();
        //    //            dtRow["BatchNo"] = cmbBatchNo.Text.ToString();
        //    //            dtRow["TAN"] = chklstAvailTANs.CheckedItems[i].ToString();
        //    //            dtSelTANs.Rows.Add(dtRow);
        //    //        }

        //    //        dgSelTANs.DataSource = dtSelTANs;
        //    //    }
        //    //}
        //    //catch (Exception ex)
        //    //{
        //    //    ErrorHandling.WriteErrorLog(ex.ToString());
        //    //}
        //} 
        #endregion

    }
}
