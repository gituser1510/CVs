﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Common;
using IndxReactNarr.Generic;
using IndxReactNarrDAL;

namespace IndxReactNarr
{
    public partial class frmNUMs : Form
    {        
        public frmNUMs()
        {
            InitializeComponent();
        }
        
        #region Property Procedures

        public string SrcParticipant { get; set; }
        public string SrcStageName { get; set; }
        public DataTable SrcPartpntData { get; set; }
        public DataTable RctOrAgentData { get; set; } 

        public int Sel_NUM { get; set; }
        public int Sel_Ser_NUM_ID { get; set; }
        public int Sel_RegNo { get; set; }
        public string Sel_Name { get; set; }  
        public string SeriesType { get; set; }  
        public string SourceGrid { get; set; }

        public DataTable TAN_NUMsTbl { get; set; }  
        public DataTable OrgRef_Filtered { get; set; }
        public DataTable Ser8500_Filtered { get; set; }
        public DataTable Ser8000_Filtered { get; set; }
      
        //New Reaction related properties
        public int TAN_ID { get; set; }
        public DataTable TANReactionsData { get; set; }
        public bool DuplicateRxn  { get; set; }
        public string CurrentRxnNUM { get; set; }
        public string CurrentRxnSeq { get; set; }
        public int CurrentRxnID { get; set; }
        public bool IsNewRxn { get; set; }
        public int NewRxnID { get; set; }
        public int RxnNum { get; set; }
        public int RxnSeq { get; set; }
        public string BeforeAfter {get;set;}
        public int RxnRowIndx {get;set;}

        public DataTable TAN_NUMsTbl_Orig { get; set; }

        #endregion

        private void frmNUMs_Load(object sender, EventArgs e)
        {
            try
            {
                TAN_NUMsTbl_Orig = TAN_NUMsTbl;

                if (TAN_NUMsTbl_Orig != null && TAN_NUMsTbl_Orig.Rows.Count > 0)
                {
                    if (TAN_NUMsTbl_Orig.Columns["NUM"].DataType != System.Type.GetType("System.String") &&
                        TAN_NUMsTbl_Orig.Columns["REG_NO"].DataType != System.Type.GetType("System.String"))
                    {
                        DataView dvTemp = TAN_NUMsTbl_Orig.Copy().DefaultView;
                        dvTemp.Sort = "NUM ASC";
                        DataTable dtNUMs = dvTemp.ToTable();

                        DataTable dtGridData = TAN_NUMsTbl.Clone();
                        dtGridData.Columns["NUM"].DataType = System.Type.GetType("System.String");
                        dtGridData.Columns["REG_NO"].DataType = System.Type.GetType("System.String");

                        foreach (DataRow dr in dtNUMs.Rows)
                        {
                            dtGridData.ImportRow(dr);
                        }

                        TAN_NUMsTbl = dtGridData;
                    }
                }

                if (!string.IsNullOrEmpty(SeriesType))
                {
                    switch (SeriesType)
                    {
                        case "NUM":
                            rbnNUMs.Checked = true;
                            break;
                        case "9000":
                            rbnSer9000.Checked = true;
                            break;
                        case "8500":
                            rbnSer8500.Checked = true;
                            break;
                        case "8000":
                            rbnSer8000.Checked = true;
                            break;
                        default:
                            rbnNUMs.Checked = true;
                            break;
                    }
                }
                else//Default is NUMs
                {
                    rbnNUMs.Checked = true;
                }

                //If New Reaction, then visible Reaction panel                
                pnlNewRxn.Visible = IsNewRxn ? true : false;
                this.Text = IsNewRxn ? "Add New Reaction" : "Select Product/Participant";
                txtNUM_Insert.Text = IsNewRxn ? CurrentRxnNUM : "";
                txtNUM_Insert.Tag = CurrentRxnID;
                txtSeq_Insert.Text = IsNewRxn ? CurrentRxnSeq : "";


                //For Macro Indexing and Organic Indexing, only NUMs are available
                if (GlobalVariables.ApplicationName == Enums.ApplicationName.ORGANIC.ToString())
                {
                    rbnSer9000.Enabled = true;
                    rbnSer8500.Enabled = false;
                    rbnSer8000.Enabled = false;
                }
                else if (GlobalVariables.ApplicationName == Enums.ApplicationName.MACRO.ToString())
                {
                    rbnSer9000.Enabled = true;
                    rbnSer8500.Enabled = false;
                    rbnSer8000.Enabled = false;
                    rbnNUMs.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void txtNrnNUM_TextChanged(object sender, EventArgs e)
        {
            try
            {
                FilterDataAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtNUM_TextChanged(object sender, EventArgs e)
        {
            try
            {
                FilterDataAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtRegNo_TextChanged(object sender, EventArgs e)
        {
            try
            {
                FilterDataAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void FilterDataAndBindToGrid()
        {
            try
            {
                pbChemImg.Image = null;

                if (rbnNUMs.Checked)
                {
                    GetFilteredDataBindToGrid();
                }
                else if (rbnSer9000.Checked)
                {
                    GetFilteredDataBindSer9000ToGrid();
                }
                else if (rbnSer8500.Checked)
                {
                    GetFilteredDataBindToSer8500Grid();
                }
                else if (rbnSer8000.Checked)
                {
                    GetFilteredDataBindToSer8000Grid();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvNUMs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvNUMs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvNUMs.Font);

                if (dgvNUMs.RowHeadersWidth < (int)(size.Width + 20)) dgvNUMs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvNUMs_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex >= 0 && e.RowIndex >= 0)
                {
                    Sel_NUM = dgvNUMs.Rows[e.RowIndex].Cells[colNUM.Name].Value != null ? Convert.ToInt32(dgvNUMs.Rows[e.RowIndex].Cells[colNUM.Name].Value.ToString()) : 0;
                    Sel_Ser_NUM_ID = dgvNUMs.Rows[e.RowIndex].Cells[colNUM_ID.Name].Value != null ? Convert.ToInt32(dgvNUMs.Rows[e.RowIndex].Cells[colNUM_ID.Name].Value.ToString()) : 0;

                    if (!IsNewRxn) //Product/Participant adding
                    {
                        int selRegNo = 0;
                        if (dgvNUMs.Rows[e.RowIndex].Cells[colRegNo.Name].Value != null)
                        {
                            int.TryParse(dgvNUMs.Rows[e.RowIndex].Cells[colRegNo.Name].Value.ToString(), out selRegNo);
                        }

                        //if NUM is available in cgm file, get cgm NUM and ignore Ser 9000/8500 NUM
                        int cgmNo = 0;
                        string cgmCompName = "";
                        int cgmNumID = 0;
                        if (GetSer9000ReplaceNUMIfAvailableInCgmNUMsTable(selRegNo, out cgmNo, out cgmCompName, out cgmNumID))
                        {
                            Sel_NUM = cgmNo;
                            Sel_RegNo = selRegNo;
                            Sel_Name = cgmCompName;
                            SeriesType = "NUM";
                            Sel_Ser_NUM_ID = cgmNumID;
                        }
                        else
                        {  
                            Sel_RegNo = selRegNo;
                            Sel_Name = dgvNUMs.Rows[e.RowIndex].Cells[colName.Name].Value != null ? dgvNUMs.Rows[e.RowIndex].Cells[colName.Name].Value.ToString() : "";
                        }

                        //Validate NUM in Product and Participants - Product
                        //Validate all NUM validations - Participant
                        //Check if NUM already used in Product
                        //Check if Num already used in the Table
                        //Reactant Vs Agent Validataion. Value used in Reactant can't be used in Agent and Vice-Versa
                        //Check if NUM already used in any stage Reactant
                        //NUM used in Catalyst should not be in used anywhere in the Reaction
                        //(Value used in Catalyst Can't be used in anywhere in the Reaction, Except it can be used in the any stage Catalyst in the Reaction)

                        string strErrMsg = "";
                        string strPartpnt = SrcParticipant != null ? SrcParticipant : "";
                        if (ValidateAllNUMValidations(Sel_NUM, Sel_RegNo, strPartpnt, out strErrMsg))
                        {
                            DialogResult = DialogResult.OK;
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else //New Reaction
                    {                        
                        string strErrMsg = "";
                        if (ValidateProduct(Sel_NUM, out strErrMsg))
                        {
                            int rxnSeq_out = 0;
                            int intRxnID = 0;

                            int intRxnNUM_Insert = 0;
                            if (!string.IsNullOrEmpty(txtNUM_Insert.Text.Trim()))
                            {
                                int.TryParse(txtNUM_Insert.Text.ToString(), out intRxnNUM_Insert);
                            }

                            int intRxnSeq_Insert = 0;
                            if (!string.IsNullOrEmpty(txtSeq_Insert.Text.Trim()))
                            {
                                int.TryParse(txtSeq_Insert.Text.ToString(), out intRxnSeq_Insert);
                            }

                            int intRowIndx = 0;
                            int intDispOrder = GetDisplayOrderOnRxnNUM_RxnSeq(intRxnNUM_Insert, intRxnSeq_Insert, out intRowIndx);

                            intDispOrder = rbnAfter.Checked ? intDispOrder + 1 : intDispOrder;

                            string strBefore_After = rbnBefore.Checked ? "BEFORE" : "AFTER";
                                                       
                            //If No Reations are available
                            if (intRxnNUM_Insert == 0 && intRxnSeq_Insert == 0 && intDispOrder == 0)
                            {
                                strBefore_After = "END";
                            }

                            if (!chkDupRxn.Checked)//New Reaction
                            {
                                intRxnID = ReactDB.InsertAndGetNewReactionID(TAN_ID, Sel_NUM, intRxnNUM_Insert, intRxnSeq_Insert, intDispOrder, SeriesType, Sel_Ser_NUM_ID, GlobalVariables.URID);
                                if (intRxnID > 0)
                                {
                                    #region MyRegion
                                    //Code commented by Sairam on 25th June 2014, Don't delete
                                    //if (rxnSeq_out > 1)
                                    //{
                                    //    DialogResult diaRes = MessageBox.Show("Product NUM: " + intRxnNum + " Seq: " + rxnSeq_out + ". Do you want to continue?", "Add Reaction", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                    //    if (diaRes == DialogResult.Yes)
                                    //    {
                                    //        RxnNum = intRxnNum;
                                    //        RxnSeq = rxnSeq_out;
                                    //        NewRxnID = intRxnID;
                                    //        BeforeAfter = strBefore_After;
                                    //        DisplayOrder = intDispOrder;
                                    //        RxnRowIndx = intRowIndx;

                                    //        DialogResult = DialogResult.OK;
                                    //        this.Close();
                                    //    }
                                    //    else//If not Delete the newly created Reaction
                                    //    {
                                    //        CASRxnDataAccess.DeleteReaction(intRxnID, TAN_ID, intRxnNum, rxnSeq_out);
                                    //    }
                                    //}
                                    //else
                                    //{ 
                                    #endregion
                                    RxnNum = Sel_NUM;
                                    RxnSeq = rxnSeq_out == 0 ? 1 : rxnSeq_out;
                                    NewRxnID = intRxnID;
                                    BeforeAfter = strBefore_After;
                                    RxnRowIndx = intRowIndx;

                                    DialogResult = DialogResult.OK;
                                    this.Close();                                   
                                }
                                else
                                {
                                    MessageBox.Show("Duplicate Reaction", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                            }
                            else //Duplicate Reaction
                            {
                                //New display order
                                //intDispOrder = rbnAfter.Checked ? intDispOrder + 1 : intDispOrder;

                                if (txtNUM_Dup.Tag != null && txtNUM_Insert.Tag != null)
                                {
                                    string seriesType = SeriesType;
                                    int beforeafterRxnID = txtNUM_Insert.Tag != null ? Convert.ToInt32(txtNUM_Insert.Tag) : 0;
                                    int rxnID_Old = txtNUM_Dup.Tag != null ? Convert.ToInt32(txtNUM_Dup.Tag) : 0;

                                    int rxnSeq = 0;
                                    //if (Sel_NUM.ToString() != txtNUM_Dup.Text.Trim())//Duplicate with different Product NUM
                                    //{
                                    //    rxnSeq = 1;
                                    //}
                                    //else//Duplicate with same Product NUM
                                    //{
                                    //    rxnSeq = !string.IsNullOrEmpty(txtSeq_Dup.Text.Trim()) ? Convert.ToInt32(txtSeq_Dup.Text.Trim()) + 1 : 1;
                                    //}

                                    rxnSeq = GetNewSeqFromReactionsTable(Sel_NUM);
                                    
                                    string strMessage = "Product NUM: " + Sel_NUM + " Seq: " + rxnSeq + ".\r\nDo you want to duplicate with NUM: " + txtNUM_Dup.Text + " Seq: " + txtSeq_Dup.Text + "?";
                                    DialogResult diaRes = MessageBox.Show(strMessage, GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                    if (diaRes == DialogResult.Yes)
                                    {
                                        intRxnID = ReactDB.DuplicateReactionData(TAN_ID, rxnID_Old, Sel_NUM, rxnSeq, intDispOrder, seriesType, Sel_Ser_NUM_ID, GlobalVariables.URID, out rxnSeq_out);
                                        if (intRxnID > 0)
                                        {
                                            RxnNum = Sel_NUM;
                                            RxnSeq = rxnSeq;
                                            NewRxnID = intRxnID;
                                            BeforeAfter = strBefore_After;
                                            //DisplayOrder = intDispOrder;
                                            RxnRowIndx = intRowIndx;
                                            DuplicateRxn = true;

                                            DialogResult = DialogResult.OK;
                                            this.Close();
                                        }
                                        else
                                        {
                                            MessageBox.Show("Error in duplicating reaction", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private int GetNewSeqFromReactionsTable(int prodNUM)
        {
            int prodSeq = 1;
            try
            {
                if (prodNUM > 0 && TANReactionsData != null)
                {
                    if (TANReactionsData.Rows.Count > 0)
                    {
                        DataRow[] drProds = TANReactionsData.Select("RXN_NUM = " + prodNUM);
                        if (drProds != null && drProds.Count() > 0)
                        {
                            prodSeq = drProds.Count() + 1;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return prodSeq; 
        }

        private void dgvNUMs_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0 && dgvNUMs.DataSource != null)
                {
                    // renderer1.Visible = false;
                    //pbChemImg.Visible = false;

                    if (rbnNUMs.Checked)
                    {
                        string molHexCode = dgvNUMs.Rows[e.RowIndex].Cells[colMolHexCode.Name].Value != null ? dgvNUMs.Rows[e.RowIndex].Cells[colMolHexCode.Name].Value.ToString() : "";
                        if (!string.IsNullOrEmpty(molHexCode))
                        {
                            string strRegNo = dgvNUMs.Rows[e.RowIndex].Cells[colRegNo.Name].Value.ToString();
                            pbChemImg.Image = HexCodeToStructureImage.GetChemImageOnHexCode(molHexCode, strRegNo);
                            pbChemImg.Refresh();
                            // pbChemImg.Visible = true;
                        }
                        else if (dgvNUMs.Rows[e.RowIndex].Cells[colMolImage.Name].Value != null)
                        {
                            pbChemImg.Image = DataConversions.ByteArrayToImage(dgvNUMs.Rows[e.RowIndex].Cells[colMolImage.Name].Value as byte[]);
                            // pbChemImg.Visible = true;
                        }

                        string strMolFile = dgvNUMs.Rows[e.RowIndex].Cells[colMolFile.Name].Value != null ? dgvNUMs.Rows[e.RowIndex].Cells[colMolFile.Name].Value.ToString() : "";
                        if (!string.IsNullOrEmpty(strMolFile))
                        {
                            renderer1.MolfileString = strMolFile;
                            pbChemImg.Image = renderer1.Image;
                        }
                    }
                    else if (rbnSer9000.Checked || rbnSer8500.Checked || rbnSer8000.Checked)
                    {
                        string strMolFile = dgvNUMs.Rows[e.RowIndex].Cells[colMolFile.Name].Value != null ? dgvNUMs.Rows[e.RowIndex].Cells[colMolFile.Name].Value.ToString() : "";
                        renderer1.MolfileString = strMolFile;
                        pbChemImg.Image = renderer1.Image;
                    }
                }
                else
                {
                    pbChemImg.Image = null;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #region NUM Validations

        private bool ValidateAllNUMValidations(int num, int regNo, string srcPartpnt, out string errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            string strTempErrMsg = "";
            try
            {
                //Check if NUM already used in Product
                if (CheckForNumUsedInProduct(num))
                {
                    strErrMsg = strErrMsg.Trim() + "\r\n" + num + " already used in the PRODUCT";
                    blStatus = false;                    
                }

                //Check if Num already used in the Table
                if (CheckForNumUsedInSameParticipant(num))
                {
                    strErrMsg = strErrMsg.Trim() + "\r\n" + num + " already used in the same participant";
                    blStatus = false;  
                }

                //Reactant Vs Agent Validataion. Value used in Reactant can't be used in Agent and Vice-Versa
                if ((srcPartpnt.ToUpper() == Enums.ParticipantType.REACTANT.ToString() 
                    || srcPartpnt.ToUpper() == Enums.ParticipantType.AGENT.ToString())
                    && CheckForReactant_AgentValidation(num))
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + "\r\n" + num +" is not valid. Reactant can't be Agent and vice-versa";
                }

                //Check if NUM already used in any stage Reactant
                if (CheckForNumUsedInAnyStageReactant(num, out strTempErrMsg))
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + "\r\n" + strTempErrMsg.Trim();
                }

                //NUM used in Catalyst should not be in Anywhere in the Reaction
                if (CheckForCatalyst_Reactant_Solvent_Valdation(num, srcPartpnt, out strTempErrMsg))
                {
                    blStatus = false;
                    strErrMsg = strErrMsg.Trim() + "\r\n" + strTempErrMsg.Trim();
                } 
 
                //Code commented on 6th Apr 2015, moved to automatic cgm NUM extraction
                ////new validation on 7th July 2015
                ////Check NUM available in CGM table, sometimes series 9000/8500 NUMs will be given in the CGM file
                //if (CheckSeries9000RegNoInCgmNUMsTable(regNo) && (rbnSer9000.Checked || rbnSer8500.Checked))
                //{
                //    blStatus = false;
                //    strErrMsg = strErrMsg.Trim() + "\r\n" + "Reg.No available in the CGM NUMs";
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg.Trim();
            return blStatus;
        }
        
        private bool CheckSeries9000RegNoInCgmNUMsTable(int ser9000RegNo)
        {
            bool blStatus = false;
            try
            {
                if (ser9000RegNo > 0)
                {
                    if (TAN_NUMsTbl != null && TAN_NUMsTbl.Rows.Count > 0)
                    {
                        int tempCnt = TAN_NUMsTbl.Select("REG_NO = '" + ser9000RegNo + "'").Count();
                        if (tempCnt > 0)
                        {
                            blStatus = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }           
            return blStatus;
        }

        private bool CheckForNumUsedInProduct(int num)
        {
            bool blStatus = false;
            try
            {
                if (this.Owner != null)
                {
                    frmReactCuration rxnCur = this.Owner.ActiveControl as frmReactCuration;
                    if (rxnCur != null)
                    {
                        DataTable dtProduct = rxnCur.RxnProductsTbl;
                        if (dtProduct != null)
                        {
                            DataRow[] dtRowArr = null;
                            if (dtProduct.Rows.Count > 0)
                            {
                                dtRowArr = dtProduct.Select("SERIES_NUM = " + num);
                                if (dtRowArr.Length > 0)
                                {
                                    blStatus = true;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckForNumUsedInSameParticipant(int num)
        {
            bool blStatus = false;
            try
            {
                if (SrcPartpntData != null && !string.IsNullOrEmpty(SrcParticipant))
                {
                    DataRow[] dtRowArr = null;
                    if (SrcPartpntData.Rows.Count > 0)
                    {
                        dtRowArr = SrcPartpntData.Select("SERIES_NUM = " + num);
                        if (dtRowArr.Length > 0)
                        {
                            blStatus = true;                           
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckForReactant_AgentValidation(int num)
        {
            bool blStatus = false;
            try
            {
                if (RctOrAgentData != null && !string.IsNullOrEmpty(SrcParticipant))
                {
                    DataRow[] dtRowArr = null;
                    if (RctOrAgentData.Rows.Count > 0)
                    {
                        dtRowArr = RctOrAgentData.Select("SERIES_NUM = " + num);
                        if (dtRowArr.Length > 0)
                        {
                            blStatus = true;
                            return blStatus;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckForNumUsedInAnyStageReactant(int num, out string errMsg)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                if (this.Owner != null)
                {
                    frmReactCuration rxnCur = this.Owner.ActiveControl as frmReactCuration;
                    if (rxnCur != null)
                    {
                        TabControl tcStages = rxnCur.tcStages;
                        if (tcStages != null && tcStages.TabCount > 0)
                        {
                            ucParticipants ucPartpnt = null;
                            foreach (TabPage tp in tcStages.TabPages)
                            {
                                ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                                if (ucPartpnt != null)
                                {
                                    if (!string.IsNullOrEmpty(SrcStageName) && ucPartpnt.StageName.ToUpper() != SrcStageName.ToUpper())
                                    {
                                        DataTable dtRtant = ucPartpnt.dtReactant;
                                        if (dtRtant != null && dtRtant.Rows.Count > 0)
                                        {
                                            DataRow[] dtRArr = dtRtant.Select("SERIES_NUM = " + num);
                                            if (dtRArr != null && dtRArr.Length > 0)
                                            {
                                                //Don't allow Curator/Reviewer to add already used Reactant
                                                if (GlobalVariables.RoleName.Trim().ToUpper() == RolesMaster.ANALYST.ToUpper() ||
                                                    GlobalVariables.RoleName.Trim().ToUpper() == RolesMaster.REV_ANALYST.ToUpper())
                                                {
                                                    blStatus = true;
                                                    strErrMsg = num + " already used in the " + ucPartpnt.StageName + " - REACTANT of the Reaction";
                                                    errMsg = strErrMsg;
                                                }
                                                else if (GlobalVariables.RoleName.Trim().ToUpper() == RolesMaster.TOOL_MANAGER.ToUpper() || 
                                                         GlobalVariables.RoleName.Trim().ToUpper() == RolesMaster.QC_ANALYST.ToUpper() ||
                                                         GlobalVariables.RoleName.Trim().ToUpper() == RolesMaster.ADMIN.ToUpper())//Allow Supervisor to add already used Reactant
                                                {
                                                    DialogResult diaRes = MessageBox.Show(num + " already used in the " + ucPartpnt.StageName + " - REACTANT of the Reaction. Do you want to continue?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                                                    if (diaRes == DialogResult.Yes)
                                                    {
                                                        errMsg = strErrMsg;
                                                        return blStatus;
                                                    }
                                                    else
                                                    {
                                                        blStatus = true;
                                                        errMsg = strErrMsg;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsg = strErrMsg;
            return blStatus;
        }

        //Value used in Catalyst Can't be used in anywhere in the Reaction,
        //Except it can be used in the any stage Catalyst in the Reaction
        private bool CheckForCatalyst_Reactant_Solvent_Valdation(int num, string srcPartpnt, out string errmsg)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                if (this.Owner != null)
                {
                    frmReactCuration rxnCur = this.Owner.ActiveControl as frmReactCuration;
                    if (rxnCur != null)
                    {
                        TabControl tcStages = rxnCur.tcStages;
                        ucParticipants ucPartpnt = null;

                        if (tcStages != null)
                        {
                            DataTable dtRtant = null;
                            DataTable dtAgnt = null;
                            DataTable dtSvant = null;
                            DataTable dtCatlst = null;

                            foreach (TabPage tp in tcStages.TabPages)
                            {
                                ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                                if (ucPartpnt != null)
                                {
                                    dtRtant = ucPartpnt.dtReactant;
                                    dtAgnt = ucPartpnt.dtAgent;
                                    dtSvant = ucPartpnt.dtSolvent;
                                    dtCatlst = ucPartpnt.dtCatalyst;

                                    if (srcPartpnt.ToUpper() == Enums.ParticipantType.REACTANT.ToString() || 
                                        srcPartpnt.ToUpper() == Enums.ParticipantType.AGENT.ToString() || 
                                        srcPartpnt.ToUpper() == Enums.ParticipantType.SOLVENT.ToString())
                                    {
                                        if (dtCatlst != null)
                                        {
                                            if (dtCatlst.Rows.Count > 0)
                                            {
                                                DataRow[] dtRArr = dtCatlst.Select("SERIES_NUM = " + num);
                                                if (dtRArr != null)
                                                {
                                                    if (dtRArr.Length > 0)
                                                    {
                                                        //Don't allow Curator/Reviewer to add already used CATALYST
                                                        if (Generic.GlobalVariables.RoleName.Trim().ToUpper() == RolesMaster.ANALYST.ToUpper() || 
                                                            Generic.GlobalVariables.RoleName.Trim().ToUpper() == RolesMaster.REV_ANALYST.ToUpper())
                                                        {
                                                            blStatus = true;
                                                            strErrMsg = "already used in the " + ucPartpnt.StageName + " - CATALYST of the Reaction.\r\n\r\nValue used in CATALYST can't be used anywhere in the Reaction";
                                                            errmsg = strErrMsg;
                                                        }
                                                        else if (Generic.GlobalVariables.RoleName.Trim().ToUpper() == RolesMaster.TOOL_MANAGER.ToUpper()
                                                            || Generic.GlobalVariables.RoleName.Trim().ToUpper() == RolesMaster.QC_ANALYST.ToUpper())//Allow Supervisor to add already used Reactant
                                                        {
                                                            DialogResult diaRes = MessageBox.Show(num + " already used in the " + ucPartpnt.StageName + " - CATALYST of the Reaction. Do you want to continue?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                                                            if (diaRes == DialogResult.Yes)
                                                            {
                                                                errmsg = strErrMsg;
                                                            }
                                                            else
                                                            {
                                                                blStatus = true;
                                                                errmsg = strErrMsg;
                                                                return blStatus;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (srcPartpnt.ToUpper() == Enums.ParticipantType.CATALYST.ToString())
                                    {
                                        if (dtRtant != null)
                                        {
                                            if (dtRtant.Rows.Count > 0)
                                            {
                                                DataRow[] dtRArr = dtRtant.Select("SERIES_NUM = " + num);
                                                if (dtRArr != null)
                                                {
                                                    if (dtRArr.Length > 0)
                                                    {
                                                        //Don't allow Curator/Reviewer to add already used Reactant
                                                        if (Generic.GlobalVariables.RoleName.Trim().ToUpper() == RolesMaster.ANALYST.ToUpper()
                                                            || Generic.GlobalVariables.RoleName.Trim().ToUpper() == RolesMaster.REV_ANALYST.ToUpper())
                                                        {
                                                            blStatus = true;
                                                            strErrMsg = num + "already used in the " + ucPartpnt.StageName + " - REACTANT of the Reaction.\r\nValue used in CATALYST can't be used anywhere in the Reaction";
                                                            errmsg = strErrMsg;
                                                            return blStatus;
                                                        }
                                                        else if (Generic.GlobalVariables.RoleName.Trim().ToUpper() == RolesMaster.TOOL_MANAGER.ToUpper()
                                                            || Generic.GlobalVariables.RoleName.Trim().ToUpper() == RolesMaster.QC_ANALYST.ToUpper())//Allow Supervisor to add already used Reactant
                                                        {
                                                            DialogResult diaRes = MessageBox.Show(num + " already used in the " + ucPartpnt.StageName + " - REACTANT of the Reaction. Do you want to continue?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                                                            if (diaRes == DialogResult.Yes)
                                                            {
                                                                errmsg = strErrMsg;
                                                            }
                                                            else
                                                            {
                                                                blStatus = true;
                                                                errmsg = strErrMsg;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        if (dtAgnt != null)
                                        {
                                            if (dtAgnt.Rows.Count > 0)
                                            {
                                                DataRow[] dtRArr = dtAgnt.Select("SERIES_NUM = " + num);
                                                if (dtRArr != null)
                                                {
                                                    if (dtRArr.Length > 0)
                                                    {
                                                        //Don't allow Curator/Reviewer to add already used Reactant
                                                        if (Generic.GlobalVariables.RoleName.Trim().ToUpper() == RolesMaster.ANALYST.ToUpper()
                                                            || Generic.GlobalVariables.RoleName.Trim().ToUpper() == RolesMaster.REV_ANALYST.ToUpper())
                                                        {
                                                            blStatus = true;
                                                            strErrMsg = num + "already used in the " + ucPartpnt.StageName + " - AGENT of the Reaction.\r\n\r\nValue used in CATALYST can't be used anywhere in the Reaction";
                                                            errmsg = strErrMsg;
                                                            return blStatus;
                                                        }
                                                        else if (Generic.GlobalVariables.RoleName.Trim().ToUpper() == RolesMaster.TOOL_MANAGER.ToUpper()
                                                            || Generic.GlobalVariables.RoleName.Trim().ToUpper() == RolesMaster.QC_ANALYST.ToUpper())//Allow Supervisor to add already used Reactant
                                                        {
                                                            DialogResult diaRes = MessageBox.Show(num + " already used in the " + ucPartpnt.StageName + " - AGENT of the Reaction. Do you want to continue?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                                                            if (diaRes == DialogResult.Yes)
                                                            {
                                                                errmsg = strErrMsg;
                                                            }
                                                            else
                                                            {
                                                                blStatus = true;
                                                                errmsg = strErrMsg;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        if (dtSvant != null)
                                        {
                                            if (dtSvant.Rows.Count > 0)
                                            {
                                                DataRow[] dtRArr = dtSvant.Select("SERIES_NUM = " + num);
                                                if (dtRArr != null)
                                                {
                                                    if (dtRArr.Length > 0)
                                                    {
                                                        if (Generic.GlobalVariables.RoleName.Trim().ToUpper() == RolesMaster.ANALYST.ToUpper()
                                                            || Generic.GlobalVariables.RoleName.Trim().ToUpper() == RolesMaster.REV_ANALYST.ToUpper())
                                                        {
                                                            blStatus = true;
                                                            strErrMsg = num + "already used in the " + ucPartpnt.StageName + " - SOLVENT of the Reaction.\r\n\r\nValue used in CATALYST can't be used anywhere in the Reaction";
                                                            errmsg = strErrMsg;
                                                            return blStatus;
                                                        }
                                                        else if (Generic.GlobalVariables.RoleName.Trim().ToUpper() == RolesMaster.TOOL_MANAGER.ToUpper()
                                                            || Generic.GlobalVariables.RoleName.Trim().ToUpper() == RolesMaster.QC_ANALYST.ToUpper())//Allow Supervisor to add already used Reactant
                                                        {
                                                            DialogResult diaRes = MessageBox.Show(num + " already used in the " + ucPartpnt.StageName + " - SOLVENT of the Reaction. Do you want to continue?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                                                            if (diaRes == DialogResult.Yes)
                                                            {
                                                                errmsg = strErrMsg;
                                                            }
                                                            else
                                                            {
                                                                blStatus = true;
                                                                errmsg = strErrMsg;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg = strErrMsg;
            return blStatus;
        }

        #endregion

        private bool GetSer9000ReplaceNUMIfAvailableInCgmNUMsTable(int ser9000RegNo, out int cgmNUM_Out, out string compName_Out, out int serNUMID_Out)
        {
            bool blStatus = false;
            int cgmNo = 0;
            string compName = "";
            int serNUMID = 0;
            try
            {
                if (TAN_NUMsTbl != null && TAN_NUMsTbl.Rows.Count > 0 && ser9000RegNo > 0)
                {
                    DataRow[] drFiltData = TAN_NUMsTbl.Select("REG_NO = '" + ser9000RegNo + "'");
                    if (drFiltData != null && drFiltData.Length > 0)
                    {
                        if (drFiltData[0]["NUM"] != null && !string.IsNullOrEmpty(drFiltData[0]["NUM"].ToString()))
                        {
                            int.TryParse(drFiltData[0]["NUM"].ToString(), out cgmNo);
                        }

                        if (drFiltData[0]["TAN_NUM_ID"] != null && !string.IsNullOrEmpty(drFiltData[0]["TAN_NUM_ID"].ToString()))
                        {
                            int.TryParse(drFiltData[0]["TAN_NUM_ID"].ToString(), out serNUMID);
                        }                        

                        compName = drFiltData[0]["IUPAC_NAME"] != null ? drFiltData[0]["IUPAC_NAME"].ToString() : "";
                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            cgmNUM_Out = cgmNo;
            compName_Out = compName;
            serNUMID_Out = serNUMID;
            return blStatus;
        }

        #region NUM Series related methods

        private void GetNUMsDataBindToGrid()
        {
            try
            {
                if (TAN_NUMsTbl_Orig != null)
                {
                    SeriesType = "NUM";

                    //DataView dvTemp = TAN_NUMsTbl_Orig.Copy().DefaultView;
                    //dvTemp.Sort = "NUM ASC";
                    //DataTable dtNUMs = dvTemp.ToTable();

                    //DataTable dtGridData = TAN_NUMsTbl.Clone();
                    //dtGridData.Columns["NUM"].DataType = System.Type.GetType("System.String");
                    //dtGridData.Columns["REG_NO"].DataType = System.Type.GetType("System.String");

                    //foreach (DataRow dr in dtNUMs.Rows)
                    //{
                    //    dtGridData.ImportRow(dr);
                    //}                   
                    
                    //TAN_NUMsTbl = dtGridData;

                    //Bind data to ser8500 grid
                    BindNUMsDataToGrid(TAN_NUMsTbl);
                }
                else
                {
                    dgvNUMs.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindNUMsDataToGrid(DataTable _nrnnumtbl)
        {
            try
            {
                if (_nrnnumtbl != null)
                {
                    dgvNUMs.AutoGenerateColumns = false;
                    dgvNUMs.DataSource = _nrnnumtbl;

                    colNUM_ID.DataPropertyName = "TAN_NUM_ID";
                    colNUM.DataPropertyName = "NUM";
                    colRegNo.DataPropertyName = "REG_NO";
                    colRole.DataPropertyName = "NUM_ROLE";
                    colMolFile.DataPropertyName = "MOL_FILE";
                    colMolHexCode.DataPropertyName = "MOL_HEX_CODE";
                    colMolImage.DataPropertyName = "MOL_IMAGE";

                    //For Macro Indeixng and Organic Indexing, only PARs are available
                    if (GlobalVariables.ApplicationName == Enums.ApplicationName.MACRO.ToString() || GlobalVariables.ApplicationName == Enums.ApplicationName.ORGANIC.ToString())
                    {
                        colName.DataPropertyName = "PAR";
                        colRole.Visible = true;
                    }
                    else
                    {
                        colName.DataPropertyName = "IUPAC_NAME";
                        colRole.Visible = false;
                    }
                    
                }
            }
            catch (Exception ex)
            {

                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetFilterCondition()
        {
            string strFilerCond = "";
            try
            {
                if (!string.IsNullOrEmpty(txtNUM.Text.Trim()))
                {
                    if (rbnNUMs.Checked || rbnSer9000.Checked)
                    {
                        strFilerCond = "NUM like '" + txtNUM.Text.Trim() + "%'";
                    }
                    else if (rbnSer8500.Checked)
                    {
                        strFilerCond = "SERIES_8500 like '" + txtNUM.Text.Trim() + "%'";
                    }
                    else if (rbnSer8000.Checked)
                    {
                        strFilerCond = "SERIES_8000 like '" + txtNUM.Text.Trim() + "%'";
                    }
                    
                }

                if (!string.IsNullOrEmpty(txtRegNo.Text.Trim() ))
                {
                    if (string.IsNullOrEmpty(strFilerCond.Trim()))
                    {
                        strFilerCond = "REG_NO like '" + txtRegNo.Text.Trim() + "%'";
                    }
                    else
                    {
                        strFilerCond = strFilerCond + " and REG_NO like '" + txtRegNo.Text.Trim() + "%'";
                    }
                }
                if (!string.IsNullOrEmpty(txtName.Text.Trim()))
                {
                    string strColName ="";
                    if (GlobalVariables.ApplicationName == Enums.ApplicationName.MACRO.ToString() || GlobalVariables.ApplicationName == Enums.ApplicationName.ORGANIC.ToString())
                    {
                        if (rbnSer9000.Checked)
                        {
                            strColName = "ORGREF_NAME";
                        }
                        else
                        {
                            strColName = "PAR";
                        }
                    }
                    else if (GlobalVariables.ApplicationName == Enums.ApplicationName.REACT.ToString())
                    {
                        if (rbnSer9000.Checked || rbnSer8500.Checked)
                        {
                            strColName = "ORGREF_NAME";
                        }
                        else if(rbnNUMs.Checked)
                        {
                            strColName = "IUPAC_NAME";
                        }
                    }

                    if (string.IsNullOrEmpty(strFilerCond.Trim()))
                    {
                        strFilerCond = strColName + " like '" + DataConversions.EscapeSpecialCharsInFilterCondition(txtName.Text.Trim()) + "%'";
                    }
                    else
                    {
                        strFilerCond = strFilerCond + " and " + strColName + " like '" + DataConversions.EscapeSpecialCharsInFilterCondition(txtName.Text.Trim()) + "%'";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strFilerCond;
        }

        private void GetFilteredDataBindToGrid()
        {
            try
            {
                string strFiltCond = GetFilterCondition();
                if (!string.IsNullOrEmpty(strFiltCond.Trim()))
                {
                    DataView dtView = TAN_NUMsTbl.Copy().DefaultView;
                    dtView.RowFilter = strFiltCond;
                    DataTable dtGridData = dtView.ToTable();

                    //Bind data to NUMs grid
                    BindNUMsDataToGrid(dtGridData);
                }
                else
                {
                    //Bind data to NUMs grid
                    BindNUMsDataToGrid(TAN_NUMsTbl);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        #region Series 9000 related methods

        private void GetSer9000DataBindToGrid()
        {
            try
            {
                if (Generic.GlobalVariables.Ser9000OrgRefData != null)
                {
                    if (Generic.GlobalVariables.Ser9000OrgRefData.Rows.Count > 0)
                    {
                        DataTable dtOrgRef = new DataTable();

                        DataTable dtTemp = Generic.GlobalVariables.Ser9000OrgRefData.Copy();
                        DataView dvTemp = dtTemp.DefaultView;
                        string strRowFiler = "";

                        string srcGrid = !string.IsNullOrEmpty(SourceGrid) ? SourceGrid.Trim() : "";
                        if (srcGrid.ToUpper() == "SOLVENT")
                        {
                            strRowFiler = @"NUM >= 9000 and NUM <> 9101 and NUM <> 9107 and NUM <> 9100 and NUM <> 9066
                                           and NUM <> 9059 and NUM <> 9559 and NUM <> 9109 and NUM <> 9266
                                           and NUM <> 9065 and NUM <> 9060 and NUM <> 9104 and NUM <> 9306
                                           and NUM <> 9075 and NUM <> 9212 and NUM <> 9213";
                        }
                        else
                        {
                            strRowFiler = "NUM >= 9000";
                        }

                        dvTemp.RowFilter = strRowFiler;
                        dvTemp.Sort = "NUM asc";
                        dtTemp = dvTemp.ToTable();

                        dtOrgRef = dtTemp.Clone();
                        dtOrgRef.Columns["NUM"].DataType = System.Type.GetType("System.String");
                        dtOrgRef.Columns["REG_NO"].DataType = System.Type.GetType("System.String");

                        #region Code Commented
                        //if (_srcgrid == "S" && 
                        //        (Convert.ToInt32(strcoll[i]) == 9101 || Convert.ToInt32(strcoll[i]) == 9266
                        //        || Convert.ToInt32(strcoll[i]) == 9100 || Convert.ToInt32(strcoll[i]) == 9065
                        //        || Convert.ToInt32(strcoll[i]) == 9066 || Convert.ToInt32(strcoll[i]) == 9060
                        //        || Convert.ToInt32(strcoll[i]) == 9059 || Convert.ToInt32(strcoll[i]) == 9104
                        //        || Convert.ToInt32(strcoll[i]) == 9559 || Convert.ToInt32(strcoll[i]) == 9306
                        //        || Convert.ToInt32(strcoll[i]) == 9109 || Convert.ToInt32(strcoll[i]) == 9075
                        //        || Convert.ToInt32(strcoll[i]) == 9266))
                        //    { 
                        #endregion

                        foreach (DataRow dr in dtTemp.Rows)
                        {
                            dtOrgRef.ImportRow(dr);
                        }

                        OrgRef_Filtered = dtOrgRef;

                        //Bind data to Ser9000 grid
                        BindSeries9000DataToGrid(dtOrgRef);
                    }
                }
                else
                {
                    dgvNUMs.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindSeries9000DataToGrid(DataTable ser9000tbl)
        {
            try
            {
                if (ser9000tbl != null)
                {
                    dgvNUMs.AutoGenerateColumns = false;
                    dgvNUMs.DataSource = ser9000tbl;

                    colNUM_ID.DataPropertyName = "ORGREF_ID";
                    colNUM.DataPropertyName = "NUM";                    
                    colName.DataPropertyName = "ORGREF_NAME";
                    colRegNo.DataPropertyName = "REG_NO";
                    colMolFile.DataPropertyName = "MOL_FILE";                    
                    colRegNo.Visible = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
               
        private void GetFilteredDataBindSer9000ToGrid()
        {
            try
            {
                if (OrgRef_Filtered != null)
                {
                    string strFiltCond = GetFilterCondition();
                    if (strFiltCond.Trim() != "")
                    {
                        DataView dtView = new DataView(OrgRef_Filtered);
                        dtView.RowFilter = strFiltCond;
                        DataTable dtGridData = dtView.ToTable();

                        //Bind data to grid
                        BindSeries9000DataToGrid(dtGridData);
                    }
                    else
                    {
                        //Bind data to grid
                        BindSeries9000DataToGrid(OrgRef_Filtered);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        #region Series 8500 related methods

        private void GetSeries8500DataBindToGrid()
        {
            try
            {
                if (GlobalVariables.TAN_Series8500Data != null)
                {                 
                    DataTable dtGridData = GlobalVariables.TAN_Series8500Data.Clone();
                    dtGridData.Columns["SERIES_8500"].DataType = System.Type.GetType("System.String");
                    dtGridData.Columns["REG_NO"].DataType = System.Type.GetType("System.String");

                    foreach (DataRow dr in GlobalVariables.TAN_Series8500Data.Rows)
                    {
                        dtGridData.ImportRow(dr);
                    }
                   
                    Ser8500_Filtered = dtGridData;

                    //Bind data to ser8500 grid
                    BindSeries8500DataToGrid(dtGridData);                    
                }
                else
                {
                    dgvNUMs.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindSeries8500DataToGrid(DataTable _ser8500tbl)
        {
            try
            {
                if (_ser8500tbl != null)
                {
                    dgvNUMs.AutoGenerateColumns = false;
                    dgvNUMs.DataSource = _ser8500tbl;

                    colNUM_ID.DataPropertyName = "TS_ID";
                    colNUM.DataPropertyName = "SERIES_8500";                    
                    colName.DataPropertyName = _ser8500tbl.Columns.Contains("NAME") ?  "NAME" : "ORGREF_NAME";                    
                    colMolFile.DataPropertyName = "MOL_FILE";
                    colRegNo.DataPropertyName = "REG_NO";
                    colRegNo.Visible = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        
               
        private void GetFilteredDataBindToSer8500Grid()
        {
            try
            {
                string strFiltCond = GetFilterCondition();
                if (strFiltCond.Trim() != "")
                {
                    DataView dtView = new DataView(Ser8500_Filtered);
                    dtView.RowFilter = strFiltCond;
                    DataTable dtGridData = dtView.ToTable();

                    //Bind data to grid
                    BindSeries8500DataToGrid(dtGridData);
                }
                else
                {
                    //Bind data to grid
                    BindSeries8500DataToGrid(Ser8500_Filtered);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        #region Series 8000 related methods

        private void GetSeries8000DataAndBindToGrid()
        {
            try
            {
                if (IndxReactNarr.Generic.GlobalVariables.TAN_Series8000Data != null)
                {
                    DataTable dtTemp = GlobalVariables.TAN_Series8000Data;

                    DataTable dtGridData = dtTemp.Clone();
                    dtGridData.Columns["SERIES_8000"].DataType = System.Type.GetType("System.String");

                    foreach (DataRow dr in dtTemp.Rows)
                    {
                        dtGridData.ImportRow(dr);
                    }
                   
                    Ser8000_Filtered = dtGridData;

                    //Bind data to grid
                    BindSeries8000DataToGrid(dtGridData);
                }
                else
                {
                    dgvNUMs.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindSeries8000DataToGrid(DataTable ser8000data)
        {
            try
            {
                if (ser8000data != null)
                {
                    dgvNUMs.AutoGenerateColumns = false;
                    dgvNUMs.DataSource = ser8000data;

                    colNUM_ID.DataPropertyName = "TS_ID";
                    colNUM.DataPropertyName = "SERIES_8000";
                    colName.DataPropertyName = "SUBST_NAME";
                    colMolFile.DataPropertyName = "SUBST_MOLECULE";
                    colRegNo.Visible = false;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetFilteredDataBindToSer8000Grid()
        {
            try
            {
                string strFiltCond = GetFilterCondition();
                if (strFiltCond.Trim() != "")
                {
                    DataView dtView = new DataView(Ser8000_Filtered);
                    dtView.RowFilter = strFiltCond;
                    DataTable dtGridData = dtView.ToTable();

                    //Bind data to grid
                    BindSeries8000DataToGrid(dtGridData);
                }
                else
                {
                    //Bind data to grid
                    BindSeries8000DataToGrid(Ser8000_Filtered);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion
                       
        private void BindDataToGridOnSelectedOption(RadioButton selectedBtn)
        {
            try
            {
                if (selectedBtn != null)
                {
                    if (selectedBtn.Checked)
                    {
                        switch (selectedBtn.Text.ToUpper())
                        {
                            case "NUM":
                                SeriesType = "NUM";
                                GetNUMsDataBindToGrid();
                                break;
                            case "SERIES 9000":
                                SeriesType = "9000";
                                GetSer9000DataBindToGrid();
                                break;
                            case "SERIES 8500":
                                SeriesType = "8500";
                                GetSeries8500DataBindToGrid();
                                break;
                            case "SERIES 8000":
                                SeriesType = "8000";
                                GetSeries8000DataAndBindToGrid();
                                break;
                        }

                        txtNUM.Focus();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnNUM_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (sender != null)
                {
                    BindDataToGridOnSelectedOption(sender as RadioButton);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #region New Reaction related methods and events

        private void chkDupRxn_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                txtNUM_Dup.Text = "";
                txtSeq_Dup.Text = "";

                if (chkDupRxn.Checked)
                {
                    grpDupRxn.Enabled = true;
                }
                else
                {
                    grpDupRxn.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtNUM_Insert_Click(object sender, EventArgs e)
        {
            try
            {
                frmNUM_SEQ objNUMSeq = new frmNUM_SEQ();
                objNUMSeq.Num_Seq_Data = TANReactionsData;
                if (objNUMSeq.ShowDialog() == DialogResult.OK)
                {
                    txtNUM_Insert.Text = objNUMSeq.RxnNUM_Sel;
                    txtNUM_Insert.Tag = objNUMSeq.RxnID_Sel;
                    txtSeq_Insert.Text = objNUMSeq.RxnSeq_Sel;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtNUM_Dup_Click(object sender, EventArgs e)
        {
            try
            {
                if (TANReactionsData != null && TANReactionsData.Rows.Count > 0)
                {
                    frmNUM_SEQ objNUMSeq = new frmNUM_SEQ();
                    objNUMSeq.Num_Seq_Data = TANReactionsData;
                    if (objNUMSeq.ShowDialog() == DialogResult.OK)
                    {
                        txtNUM_Dup.Text = objNUMSeq.RxnNUM_Sel;
                        txtNUM_Dup.Tag = objNUMSeq.RxnID_Sel;
                        txtSeq_Dup.Text = objNUMSeq.RxnSeq_Sel;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private bool ValidateProduct(int selProdNum, out string errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (selProdNum > 0)
                {
                    if (rbnSer8500.Checked && CheckForSer8000_8500ValueInNUMsTable(selProdNum))
                    {
                        blStatus = false;
                        strErrMsg = selProdNum + " already exist in NUMs";
                    }
                    else if (rbnSer8000.Checked && CheckForSer8000_8500ValueInNUMsTable(selProdNum))
                    {
                        blStatus = false;
                        strErrMsg = selProdNum + " already exist in NUMs";
                    }
                }
                else
                {
                    blStatus = false;
                    strErrMsg = "NUM should be greater than Zero";
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg;
            return blStatus;
        }

        private bool CheckForSer8000_8500ValueInNUMsTable(int val_8000_8500)
        {
            bool blStatus = false;
            try
            {
                if (val_8000_8500 > 0)
                {
                    if (TAN_NUMsTbl != null && TAN_NUMsTbl.Rows.Count > 0)
                    {
                        DataRow[] dtRowArr = TAN_NUMsTbl.Select("NUM = " + val_8000_8500 + "");
                        if (dtRowArr != null)
                        {
                            if (dtRowArr.Length > 0)
                            {
                                blStatus = true;
                                return blStatus;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private int GetDisplayOrderOnRxnNUM_RxnSeq(int _rxnnum, int _rxnseq, out int _rowindex)
        {
            int intDispOrder = 0;
            int intRowIndx = 0;
            try
            {
                if (TANReactionsData != null && TANReactionsData.Rows.Count > 0)
                {
                    for (int i = 0; i < TANReactionsData.Rows.Count; i++)
                    {
                        if (Convert.ToInt32(TANReactionsData.Rows[i]["RXN_NUM"].ToString()) == _rxnnum
                            && Convert.ToInt32(TANReactionsData.Rows[i]["RXN_SEQ"].ToString()) == _rxnseq)
                        {
                            int.TryParse(TANReactionsData.Rows[i]["DISPLAY_ORDER"].ToString(), out intDispOrder);

                            intRowIndx = i;
                            _rowindex = intRowIndx;
                            return intDispOrder;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _rowindex = intRowIndx;
            return intDispOrder;
        }

        #endregion       

        private void dgvNUMs_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            // (No need to write anything in here)
            e.ThrowException = false;
        }      
       
    }
}
