﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;

namespace IndxReactNarr
{
    public partial class frm8500ValsExist : Form
    {
        public frm8500ValsExist()
        {
            InitializeComponent();
        }

        public DataTable ProdSavedSeries
        { get; set; }

        public DataTable PartpntSavedSeries
        { get; set; }

        private void frm8500ValsExist_Load(object sender, EventArgs e)
        {
            try
            {
                if (ProdSavedSeries != null)
                {
                    if (ProdSavedSeries.Rows.Count > 0)
                    {
                        dgvProduct.DataSource = ProdSavedSeries;
                        if (dgvProduct.Columns.Contains("PP_NAME"))
                        {
                            dgvProduct.Columns["PP_NAME"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                        }
                        //if (dgvProduct.Columns.Contains("subst_name"))
                        //{
                        //    dgvProduct.Columns["subst_name"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                        //}
                        //if (dgvProduct.Columns.Contains("subst_loc"))
                        //{
                        //    dgvProduct.Columns["subst_loc"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                        //}
                    }
                }

                if (PartpntSavedSeries != null)
                {
                    if (PartpntSavedSeries.Rows.Count > 0)
                    {
                        dgvPartpnt.DataSource = PartpntSavedSeries;
                        if (dgvPartpnt.Columns.Contains("PP_NAME"))
                        {
                            dgvPartpnt.Columns["PP_NAME"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                        }
                        //if (dgvPartpnt.Columns.Contains("subst_name"))
                        //{
                        //    dgvPartpnt.Columns["subst_name"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                        //}
                        //if (dgvPartpnt.Columns.Contains("subst_loc"))
                        //{
                        //    dgvPartpnt.Columns["subst_loc"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                        //}
                        if (dgvPartpnt.Columns.Contains("PP_TYPE"))
                        {
                            dgvPartpnt.Columns["PP_TYPE"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
