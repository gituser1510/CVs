﻿#region NameSpaces
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BLL;
using DAL;
using System.Text.RegularExpressions;
using System.Collections;
using IndxReactNarr.Generic;
#endregion NameSpaces

namespace IndxReactNarr
{
    public partial class frmRxnReport : Form
    {
        #region Constructor
        
        public frmRxnReport()
        {
            InitializeComponent();
        }
       
        #endregion      

        #region Public properties       

        private string _tan = "";
        public string TAN
        {
            get { return _tan; }
            set { _tan = value; }
        }

        #endregion
                
        public void GetUserAssignedTANsBindToControl()
        {
            try
            {            
                if (GlobalVariables.UserRole.ToUpper() == "CURATOR" || GlobalVariables.UserRole.ToUpper() == "REVIEWER")
                {
                    txtTan.Visible = false;
                    cmbTANs.Visible = true;

                    //Retrieve assigned TANs for the user based on userid,role
                    DataTable dtAssignedTans = CASRxnDataAccess.GetUserAssignedTANs(Generic.GlobalVariables.URID, Generic.GlobalVariables.UserRoleID);
                    if (dtAssignedTans != null)
                    {
                        if (dtAssignedTans.Rows.Count > 0)
                        {
                            cmbTANs.DataSource = dtAssignedTans;
                            cmbTANs.DisplayMember = dtAssignedTans.Columns["TAN"].ColumnName.ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public void LoadTANDetailsReport()
        {
            try
            {
                if (TAN.Trim() != "")
                {
                    txtTan.Text = TAN;
                    txtTan.ReadOnly = true;
                    txtTan.BackColor = Color.White;
                    txtTan.ForeColor = Color.Blue;
                    GetReportDataOnTANAndBindToGrid(TAN);                  
                }
            }
            catch (Exception ex)
            {
               ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        public void GetParticipantsCount()
        {
            try
            {
                DataSet ds_ct_participants = new DataSet();
                ds_ct_participants = DAL.CASRxnDataAccess.GetParticipantsCountOnTAN(TAN);

                if (ds_ct_participants.Tables[0].Rows.Count > 0)
                {
                    string temp_val = "";
                    foreach (DataRow dRow in ds_ct_participants.Tables[0].Rows)
                    {
                        temp_val = dRow[1].ToString();
                        if (temp_val == "AGENT")
                        {
                            lblAgCnt.Text = dRow[0].ToString();
                        }
                        else if (temp_val == "SOLVENT")
                        {
                            lblsolCnt.Text = dRow[0].ToString();
                        }
                        else if (temp_val == "REACTANT")
                        {
                            lblreactCnt.Text = dRow[0].ToString();
                        }
                        else if (temp_val == "CATALYST")
                        {
                            lblcatCnt.Text = dRow[0].ToString();
                        }
                    }
                }

                DataSet ds_product_count = new DataSet();
                ds_product_count = DAL.CASRxnDataAccess.GetProductCount(TAN);
                if (ds_product_count.Tables[0].Rows.Count > 0)
                {
                    lblprodCnt.Text = ds_product_count.Tables[0].Rows[0][0].ToString();
                }

                DataSet dsConds = new DataSet();
                dsConds = DAL.CASRxnDataAccess.GetRxnConditionsCountOnTAN(TAN);
                if (dsConds.Tables[0].Rows.Count > 0)
                {
                    lblTempCnt.Text = dsConds.Tables[0].Rows[0]["temperature"].ToString();
                    lblPrCnt.Text = dsConds.Tables[0].Rows[0]["pressure"].ToString();
                    lblPhCnt.Text = dsConds.Tables[0].Rows[0]["ph"].ToString();
                    lblTimeCnt.Text = dsConds.Tables[0].Rows[0]["tt"].ToString();
                }

                DataTable dtDist8000 = CASRxnDataAccess.GetDistinct8000OnTAN(TAN);
                if (dtDist8000 != null)
                {
                    if (dtDist8000.Rows.Count > 0)
                    {
                        lblDist8000.Text = dtDist8000.Rows[0][0].ToString();
                        lblRxn8000.Text = dtDist8000.Rows[0][1].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog("GetParticipantsCount " + ex.ToString());
            }
        }
        
        public void CountsOFReactionStageCounts(DataTable _dtreport)
        {
            try
            {               
                if (_dtreport != null)
                {
                    if (_dtreport.Rows.Count > 0)
                    {
                        DataTable dtRIds_Uniq = _dtreport.DefaultView.ToTable(true, "rxnnum");
                        if (dtRIds_Uniq != null)
                        {
                            if (dtRIds_Uniq.Rows.Count > 0)
                            {
                                lblrtct.Text = dtRIds_Uniq.Rows.Count.ToString();
                            }
                        }

                        DataTable dtStg_Uniq = _dtreport.DefaultView.ToTable(true, "id");
                        if (dtStg_Uniq != null)
                        {
                            if (dtStg_Uniq.Rows.Count > 0)
                            {
                                lblstct.Text = dtStg_Uniq.Rows.Count.ToString();
                            }
                        }                        
                    }
                }
            }
            catch (Exception ex)
            {
                IndxReactNarr.Generic.ErrorHandling.WriteErrorLog(" CountsOFParticipants " + ex.StackTrace.ToString());
            }
        }

        private DataTable CustomizeDataTableOnRxnID(DataTable _rxndatatbl)
        {
            DataTable dtCustRIds = new DataTable();
            try
            {
                if (_rxndatatbl != null)
                {
                    if (_rxndatatbl.Rows.Count > 0)
                    {
                        dtCustRIds.Columns.Add("S.No", typeof(string));
                        dtCustRIds.Columns.Add("RxnNum",typeof(string));
                        dtCustRIds.Columns.Add("Product(Yield)", typeof(string));
                        dtCustRIds.Columns.Add("Rxn Stage Id", typeof(string));
                        dtCustRIds.Columns.Add("Reactants", typeof(string));
                        dtCustRIds.Columns.Add("Agents", typeof(string));
                        dtCustRIds.Columns.Add("Catalyst", typeof(string));
                        dtCustRIds.Columns.Add("Solvent", typeof(string));
                        dtCustRIds.Columns.Add("Time", typeof(string));
                        dtCustRIds.Columns.Add("Temperature", typeof(string));
                        dtCustRIds.Columns.Add("Pressure", typeof(string));
                        dtCustRIds.Columns.Add("Ph", typeof(string));
                        dtCustRIds.Columns.Add("RSN_CVT", typeof(string));
                        dtCustRIds.Columns.Add("RSN_Free", typeof(string));

                        DataTable dtRIds_Uniq = _rxndatatbl.DefaultView.ToTable(true, "rxnnum");                      
                        if (dtRIds_Uniq != null)
                        {
                            if (dtRIds_Uniq.Rows.Count > 0)
                            {
                                string rxnNum = "";
                                int intRxnCnt = 0;
                                for (int i = 0; i < dtRIds_Uniq.Rows.Count; i++)
                                {
                                    rxnNum = dtRIds_Uniq.Rows[i]["rxnnum"].ToString();

                                    var query = (from r in _rxndatatbl.AsEnumerable()
                                                 where r.Field<string>("rxnnum") == rxnNum
                                                select r.Field<Int32>("id")).Distinct();                                   

                                    int cntr = 0;
                                    foreach (int rsid in query)
                                    {
                                        DataRow dtRow = dtCustRIds.NewRow();

                                        if (cntr == 0)
                                        {
                                            intRxnCnt++;
                                            dtRow["S.No"] = intRxnCnt.ToString();
                                            dtRow["RxnNum"] = rxnNum.ToString();

                                            dtRow["Product(Yield)"] = ReturnProductYield(_rxndatatbl, rxnNum, rsid);
                                        }
                                        cntr++;

                                        dtRow["Rxn Stage Id"] = rsid.ToString();                                        

                                        dtRow["Reactants"] = ReturnQueryValue(_rxndatatbl, rxnNum,rsid, "reactant");
                                        dtRow["Agents"] = ReturnQueryValue(_rxndatatbl, rxnNum,rsid, "agent");
                                        dtRow["Catalyst"] = ReturnQueryValue(_rxndatatbl, rxnNum,rsid, "catalyst");
                                        dtRow["Solvent"] = ReturnQueryValue(_rxndatatbl, rxnNum,rsid, "solvent");
                                        dtRow["Time"] = ReturnQueryValue(_rxndatatbl, rxnNum,rsid, "tt");
                                        dtRow["Temperature"] = ReturnQueryValue(_rxndatatbl, rxnNum,rsid, "temperature");
                                        dtRow["Pressure"] = ReturnQueryValue(_rxndatatbl, rxnNum,rsid, "pressure");
                                        dtRow["Ph"] = ReturnQueryValue(_rxndatatbl, rxnNum,rsid, "ph");
                                        dtRow["RSN_CVT"] = ReturnQueryValue(_rxndatatbl, rxnNum, rsid, "rsn_cvt");
                                        dtRow["RSN_Free"] = ReturnQueryValue(_rxndatatbl, rxnNum, rsid, "rsn_free_text");

                                        dtCustRIds.Rows.Add(dtRow);
                                    }
                                }
                                return dtCustRIds;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                IndxReactNarr.Generic.ErrorHandling.WriteErrorLog(" CustomizeDataTableOnRxnID " + ex.StackTrace.ToString());
            }
            return null;
        }

        private string ReturnProductYield(DataTable _dtrxntbl, string _rxnno, int _rxnstageid)
        {
            string strProd_Y = "";
            try
            {
                if (_dtrxntbl != null)
                {
                    if (_dtrxntbl.Rows.Count > 0)
                    {
                        DataRow[] dtRowArr = _dtrxntbl.Select("rxnnum = '" + _rxnno + "' and id = '" + _rxnstageid + "'");
                        if (dtRowArr != null)
                        {
                            if (dtRowArr.Length > 0)
                            {
                                for (int i = 0; i < dtRowArr.Length; i++)
                                {
                                    if (dtRowArr[i]["p_y"].ToString() != "0")
                                    {
                                        if (strProd_Y == "")
                                        {
                                            strProd_Y = dtRowArr[i]["p_y"].ToString();
                                        }
                                        else
                                        {
                                            strProd_Y = strProd_Y + "," + dtRowArr[i]["p_y"].ToString();
                                        }
                                    }
                                }                         
                                return strProd_Y;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strProd_Y;
        }

        private string ReturnQueryValue(DataTable _dtrxntbl,string _rxnno,int _rxnstageid,string _columnname)
        {
            string strResult = "";
            try
            {
                if (_dtrxntbl != null)
                {
                    if (_dtrxntbl.Rows.Count > 0)
                    {

                        ArrayList alstResVals = new ArrayList();

                        if (_dtrxntbl.Columns[_columnname].DataType.ToString() == "System.Decimal")
                        {
                           var query = (from r in _dtrxntbl.AsEnumerable()
                                        where r.Field<string>("rxnnum") == _rxnno
                                     && r.Field<Int32>("id") == _rxnstageid
                                     && r.Field<decimal?>(_columnname) != null
                                     select r.Field<decimal?>(_columnname)).Distinct();
                            
                           foreach (decimal s in query)
                           {
                               if (s > 0)
                               {
                                   if (!alstResVals.Contains(s.ToString()))
                                   {
                                       alstResVals.Add(s.ToString());
                                   }                                  
                               }
                           }
                           if (alstResVals != null)
                           {
                               if (alstResVals.Count > 0)
                               {
                                   for (int i = 0; i < alstResVals.Count; i++)
                                   {
                                       if (strResult == "")
                                       {
                                           strResult = alstResVals[i].ToString();
                                       }
                                       else
                                       {
                                           strResult = strResult + "\r\n" + alstResVals[i].ToString();
                                       }
                                   }
                               }
                           }

                        }
                        else if (_dtrxntbl.Columns[_columnname].DataType.ToString() == "System.String")
                        {
                            var query = (from r in _dtrxntbl.AsEnumerable()
                                         where r.Field<string>("rxnnum") == _rxnno
                                         && r.Field<Int32>("id") == _rxnstageid
                                         && r.Field<string>(_columnname) != null
                                         select r.Field<string>(_columnname));

                            foreach (string s in query)
                            {
                                if (s != "")
                                {
                                    if (!alstResVals.Contains(s.ToString()))
                                    {
                                        alstResVals.Add(s.ToString());
                                    } 
                                }
                            }

                            if (alstResVals != null)
                            {
                                if (alstResVals.Count > 0)
                                {
                                    for (int i = 0; i < alstResVals.Count; i++)
                                    {
                                        if (strResult == "")
                                        {
                                            strResult = alstResVals[i].ToString();
                                        }
                                        else
                                        {
                                            strResult = strResult + "\r\n" + alstResVals[i].ToString();
                                        }
                                    }
                                }
                            }
                        }                 
                                              
                    }
                }
                return strResult;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(" ReturnQueryValue " + ex.StackTrace.ToString());
            }
            return strResult;
        }

        private string ReturnStringFromList(ArrayList _vallist)
        {
            string strVals = "";
            try
            {
                foreach (string s in _vallist)
                {
                    if (strVals.Trim() == "")
                    {
                        strVals = s;
                    }
                    else
                    {
                        strVals = strVals + "," + s;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strVals;
        }

        private void ColorGridRowsOnRxnID()
        {
            try
            {         
                if (dgReportView.Rows.Count > 0)
                {
                    dgReportView.ReadOnly = false;
                    Color clr = Color.LightYellow;                   

                    for (int i = 0; i < dgReportView.Rows.Count; i++)
                    {
                        if (dgReportView.Rows[i].Cells[0].Value.ToString() != "")
                        {
                            if (i > 0 && dgReportView.Rows[i - 1].DefaultCellStyle.BackColor == Color.LightYellow)
                            {
                                clr = Color.LightSalmon;                                
                            }
                            else if (i > 0 && dgReportView.Rows[i - 1].DefaultCellStyle.BackColor == Color.LightSalmon)
                            {
                                clr = Color.LightYellow;                                
                            }                            
                            dgReportView.Rows[i].DefaultCellStyle.BackColor = clr;                             
                        }
                        else
                        {
                            dgReportView.Rows[i].DefaultCellStyle.BackColor = clr;
                        }
                    }                    
                    dgReportView.ReadOnly = true;
                    dgReportView.Refresh();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void DisableSort_Allow_Sizing_OnColumns()
        {
            try
            {
                if (dgReportView.Columns.Count > 0)
                {
                    for (int i = 0; i < dgReportView.Columns.Count; i++)
                    {
                        dgReportView.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
                        dgReportView.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                    }
                    dgReportView.Columns[0].Width = 40;//S.No column
                    dgReportView.Columns[1].Width = 65;//RxnNum Column
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void btnSearch_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            try
            {
                //Clear Status labels count, if any
                ClearStatusLabelsCount();                

                if (txtTan.Visible)
                {
                    if (txtTan.Text.Trim() == "" || txtTan.Text == null)
                    {
                        MessageBox.Show("TAN field can't be blank", "TAN Report View", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    else
                    {
                        if (Validatations.ValidateTANFormat(txtTan.Text.Trim()))
                        {
                            TAN = txtTan.Text.Trim();
                        }
                        else
                        {
                            MessageBox.Show("TAN format is not valid", "TAN Report View", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }
                    }
                }
                else if (cmbTANs.Visible)
                {
                    if (cmbTANs.SelectedItem != null)
                    {
                        if (cmbTANs.Text.ToString() != "")
                        {
                            TAN = cmbTANs.Text.ToString();
                        }
                    }
                }
                GetReportDataOnTANAndBindToGrid(TAN);               
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog("btnSearch_Click " + ex.ToString());
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        private void GetReportDataOnTANAndBindToGrid(string _tan)
        {
            try
            {
                //Get TAN Report data
                DataSet dsData = new DataSet();
                dsData = DAL.CASRxnDataAccess.GetTanReportData(_tan);

                if (dsData != null)
                {
                    if (dsData.Tables.Count > 0)
                    {
                        lblAnalystID.Text = dsData.Tables[0].Rows[0]["analyst"].ToString();
                        txtComments.Text = dsData.Tables[0].Rows[0]["comments"].ToString();

                        lblBatchName.Text = dsData.Tables[0].Rows[0]["filename"].ToString();
                        lblBatchNo.Text = dsData.Tables[0].Rows[0]["batchnum"].ToString();

                        //Customize the datatable on reactionid here               
                        DataTable dtCust = CustomizeDataTableOnRxnID(dsData.Tables[0]);
                        if (dtCust != null)
                        {
                            dgReportView.DataSource = dtCust;
                            dgReportView.Refresh();
                        }

                        //Color Datagrid Rows based on Rxn ID
                        ColorGridRowsOnRxnID();

                        //Get Participants Count on TAN
                        GetParticipantsCount();

                        //Get Reactions,Stages count on TAN
                        CountsOFReactionStageCounts(dsData.Tables[0]);

                        //Disable Sort on Grid Columns
                        DisableSort_Allow_Sizing_OnColumns();

                        //Hide Reaction Stage ID column
                        dgReportView.Columns["Rxn Stage ID"].Visible = false;                      
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog("btnSearch_Click " + ex.ToString());
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        private void ClearStatusLabelsCount()
        {
            try
            {
                lblrtct.Text = "0";
                lblstct.Text = "0";
                lblDist8000.Text = "0";
                lblRxn8000.Text = "0";
                lblprodCnt.Text = "0";
                lblreactCnt.Text = "0";
                lblcatCnt.Text = "0";
                lblsolCnt.Text = "0";
                lblAgCnt.Text = "0";
                lblTimeCnt.Text = "0";
                lblPrCnt.Text = "0";
                lblTempCnt.Text = "0";
                lblPhCnt.Text = "0";
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(" ColorGridRowsOnRxnID " + ex.StackTrace.ToString());
            }
        }

        private void frmRxnReport_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;
                ColorGridRowsOnRxnID();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(" frmRxnReport_Load " + ex.ToString());
            }
        }               
    }
}
