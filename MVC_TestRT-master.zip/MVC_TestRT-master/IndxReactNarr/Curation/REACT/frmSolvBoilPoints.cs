﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;

namespace IndxReactNarr
{
    public partial class frmSolvBoilPoints : Form
    {
        public frmSolvBoilPoints()
        {
            InitializeComponent();
        }

        private void frmSolvBoilPoints_Load(object sender, EventArgs e)
        {
            try
            {
                DataTable dtSolvBPs = IndxReactNarrDAL.ReactDB.GetSolventBoilingPoints();
                if (dtSolvBPs != null)
                {
                    dgvSolvBPs.AutoGenerateColumns = false;
                    dgvSolvBPs.DataSource = dtSolvBPs;

                    colSer9000.DataPropertyName = "SERIES9000";
                    colNrnReg.DataPropertyName = "REG_NO";
                    colSolvent.DataPropertyName = "SOLVENT";
                    colBP_C.DataPropertyName = "UNIT_CELSIUS";
                    colBP_K.DataPropertyName = "UNIT_KELVIN";
                    colBP_FH.DataPropertyName ="UNIT_FAHRENHEIT";
                    colBP_R.DataPropertyName = "UNIT_RANKINE";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvSolvBPs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvSolvBPs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvSolvBPs.Font);

                if (dgvSolvBPs.RowHeadersWidth < (int)(size.Width + 20)) dgvSolvBPs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       
    }
}
