﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//using DAL;
using System.IO;
using System.Text.RegularExpressions;

using CADViewLib;
using IndxReactNarr.Generic;
using System.Xml;

namespace IndxReactNarr
{
    public partial class frmProdFormation : Form
    {
        public frmProdFormation()
        {
            InitializeComponent();     
        }

        #region Property Procedures
        
        private DataTable _prodtbl = null;
        public DataTable ProductTbl
        {
            get
            { return _prodtbl; }
            set
            {
                _prodtbl = value;
            }
        }

        private DataTable _reactanttbl = null;
        public DataTable ReactantTbl
        {
            get
            { return _reactanttbl; }
            set
            {
                _reactanttbl = value;
            }
        }

        private DataTable _partpntstbl = null;
        public DataTable PartpntsTbl
        {
            get
            { return _partpntstbl; }
            set
            {
                _partpntstbl = value;
            }
        }

        private DataTable _cgmdatatbl = null;
        public DataTable CGMDataTbl
        {
            get
            { return _cgmdatatbl; }
            set
            {
                _cgmdatatbl = value;
            }
        }

        public string RxnSNo
        { get; set; }
        
        #endregion

        public void BindDataToReactionPanel_New()
        {
            try
            {      
                GlobalVariables.CGMTbl_ForRxns = CGMDataTbl;

                ucGetReaction objGetRxn = null;                
                objGetRxn = new ucGetReaction();
                objGetRxn.Dock = DockStyle.Fill;
                objGetRxn.SerialNo = RxnSNo;
                objGetRxn.ProductTbl = ProductTbl;

                objGetRxn.ProdNUM = GetProductNUMAndYieldFromTable(ProductTbl);        
                objGetRxn.ReactantTbl = ReactantTbl;
                objGetRxn.PartpntsTbl = PartpntsTbl;
                
                //objGetRxn.GetReactionData_BindToPanel_New();
                objGetRxn.GetReactionDataAndBindToPanel_IRN();
                pnlMain.Controls.Add(objGetRxn);

                #region Code Commented
                //dtPartpntTbl =   GetParticipantsDataOnRxnNUM(intRxnID);
                //dtCondsTbl = GetConditionsDataOnRxnNUM(intRxnID);
                //dtRsnTbl = GetRSNDataOnRxnNUM(intRxnID);
                //dtStagesTbl = GetStagesOnRxnNUM(intRxnID);
                //objGetRxn.PartpntsTbl = GetParticipants_For_ProdFormation(dtPartpntTbl, dtCondsTbl, dtRsnTbl, dtStagesTbl); 
                #endregion         
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetProductNUMAndYieldFromTable(DataTable _prodtbl)
        {
            string strProd = "";            
            try
            {
                if (_prodtbl != null && _prodtbl.Rows.Count > 0)
                {
                    for (int i = 0; i < _prodtbl.Rows.Count; i++)
                    {
                        if (string.IsNullOrEmpty(strProd.Trim()))
                        {
                            strProd = _prodtbl.Rows[i]["NUM"].ToString();
                        }
                        else
                        {
                            strProd = strProd + ", " + _prodtbl.Rows[i]["NUM"].ToString();
                        }

                        if (!string.IsNullOrEmpty(_prodtbl.Rows[i]["YIELD"].ToString().Trim()))
                        {
                            strProd = strProd + " (" + _prodtbl.Rows[i]["YIELD"].ToString().Trim() + "%)";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }            
            return strProd;
        }

        #region Code Commented
        //public void BindDataToReactionPanel()
        //{
        //    try
        //    {
        //        if (ReactantTbl != null)
        //        {
        //            if (ReactantTbl.Rows.Count > 0)
        //            {
        //                tlpnlProd.RowCount = 1;

        //                int intReactCnt = GetPanelControlsLength(ReactantTbl, "REACTANT");
        //                int intProdCnt = GetPanelControlsLength(ProductTbl, "PRODUCT");

        //                int intTotColCnt = intReactCnt + intProdCnt;
        //                tlpnlProd.ColumnCount = intTotColCnt;

        //                int colCnt = intTotColCnt;
        //                for (int i = 0; i < colCnt; i++)
        //                {
        //                    ColumnStyle cStyle = new ColumnStyle();
        //                    cStyle.SizeType = SizeType.AutoSize;
        //                    cStyle.Width = 70;

        //                    tlpnlProd.ColumnStyles.Add(cStyle);
        //                }

        //                ucProd_Reactant objUC = null;
        //                ucPlus objPlus = null;
        //                int colIndx = 0;
        //                for (int i = 0; i < ReactantTbl.Rows.Count; i++)
        //                {
        //                    if (ReactantTbl.Rows[i]["nrnreg"].ToString() != "")
        //                    {
        //                        object objStruct = ReactantTbl.Rows[i]["structure"].ToString();
        //                        if (objStruct.ToString() != "")
        //                        {
        //                            objUC = new ucProd_Reactant();
        //                            objUC.Dock = DockStyle.Fill;
        //                            objUC.NrnNum = ReactantTbl.Rows[i]["num"].ToString();
        //                            objUC.StageName = ReactantTbl.Rows[i]["Stage"].ToString();

        //                            ChemRenditor.MolfileString = objStruct.ToString();
        //                            objUC.ChemImage = ChemRenditor.Image;

        //                            if (tlpnlProd.Controls.Count > 0)
        //                            {
        //                                if (tlpnlProd.Controls[colIndx - 1].Name.ToUpper() != "UCPLUS")
        //                                {
        //                                    objPlus = new ucPlus();
        //                                    objPlus.Dock = DockStyle.Fill;

        //                                    tlpnlProd.Controls.Add(objPlus, colIndx, 0);
        //                                    tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
        //                                    tlpnlProd.ColumnStyles[colIndx].Width = 30;
        //                                    colIndx++;
        //                                }
        //                            }
        //                            tlpnlProd.Controls.Add(objUC, colIndx, 0);
        //                            tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
        //                            tlpnlProd.ColumnStyles[colIndx].Width = 290;
        //                            colIndx++;
        //                        }
        //                        else
        //                        {
        //                            int regno = Convert.ToInt32(ReactantTbl.Rows[i]["nrnreg"].ToString());
        //                            string[] strHexArr = GetHexCodeOnRegNo(regno);
        //                            if (strHexArr != null)
        //                            {
        //                                if (strHexArr.Length > 0)
        //                                {
        //                                    if (tlpnlProd.Controls.Count > 0 && i < ReactantTbl.Rows.Count)
        //                                    {
        //                                        if (tlpnlProd.Controls[colIndx - 1].Name.ToUpper() != "UCPLUS")
        //                                        {
        //                                            objPlus = new ucPlus();
        //                                            objPlus.Dock = DockStyle.Fill;

        //                                            tlpnlProd.Controls.Add(objPlus, colIndx, 0);
        //                                            tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
        //                                            tlpnlProd.ColumnStyles[colIndx].Width = 30;
        //                                            colIndx++;
        //                                        }
        //                                    }

        //                                    for (int hIndx = 0; hIndx < strHexArr.Length; hIndx++)
        //                                    {
        //                                        objUC = new ucProd_Reactant();
        //                                        objUC.Dock = DockStyle.Fill;
        //                                        objUC.StageName = ReactantTbl.Rows[i]["Stage"].ToString();
        //                                        objUC.NrnNum = ReactantTbl.Rows[i]["num"].ToString();
        //                                        objUC.ChemImage = GetChemImageOnHexCode(strHexArr[hIndx], regno.ToString());

        //                                        tlpnlProd.Controls.Add(objUC, colIndx, 0);
        //                                        tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
        //                                        tlpnlProd.ColumnStyles[colIndx].Width = 290;
        //                                        colIndx++;
        //                                    }
        //                                }
        //                            }
        //                            else //Hex array NULL for series 8500 RegNos
        //                            {
        //                                if (tlpnlProd.Controls.Count > 0 && i < ReactantTbl.Rows.Count)
        //                                {
        //                                    if (tlpnlProd.Controls[colIndx - 1].Name.ToUpper() != "UCPLUS")
        //                                    {
        //                                        objPlus = new ucPlus();
        //                                        objPlus.Dock = DockStyle.Fill;

        //                                        tlpnlProd.Controls.Add(objPlus, colIndx, 0);
        //                                        tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
        //                                        tlpnlProd.ColumnStyles[colIndx].Width = 30;
        //                                        colIndx++;
        //                                    }
        //                                }

        //                                objUC = new ucProd_Reactant();
        //                                objUC.Dock = DockStyle.Fill;
        //                                objUC.StageName = ReactantTbl.Rows[i]["Stage"].ToString();
        //                                objUC.NrnNum = ReactantTbl.Rows[i]["num"].ToString();
        //                                objUC.ChemImage = null;

        //                                tlpnlProd.Controls.Add(objUC, colIndx, 0);
        //                                tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
        //                                tlpnlProd.ColumnStyles[colIndx].Width = 290;
        //                                colIndx++;
        //                            }
        //                        }
        //                    }
        //                }

        //                //Arrow Control
        //                if (tlpnlProd.Controls.Count > 0)
        //                {
        //                    ucArrow objArrow = new ucArrow();
        //                    objArrow.Dock = DockStyle.Fill;
        //                    tlpnlProd.Controls.Add(objArrow, colIndx, 0);
        //                    tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
        //                    tlpnlProd.ColumnStyles[colIndx].Width = 90;
        //                    colIndx++;
        //                }
        //                //Product Control
        //                for (int i = 0; i < ProductTbl.Rows.Count; i++)
        //                {
        //                    if (ProductTbl.Rows[i]["nrnreg"].ToString() != "")
        //                    {
        //                        object objStruct = ProductTbl.Rows[i]["structure"].ToString();
        //                        if (objStruct.ToString() != "")
        //                        {
        //                            objUC = new ucProd_Reactant();
        //                            objUC.Dock = DockStyle.Fill;
        //                            objUC.NrnNum = ProductTbl.Rows[i]["num"].ToString();

        //                            ChemRenditor.MolfileString = objStruct.ToString();
        //                            objUC.ChemImage = ChemRenditor.Image;

        //                            tlpnlProd.Controls.Add(objUC, colIndx, 0);
        //                            tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
        //                            tlpnlProd.ColumnStyles[colIndx].Width = 290;
        //                            colIndx++;

        //                            if (colIndx <= colCnt - 2)
        //                            {
        //                                objPlus = new ucPlus();
        //                                objPlus.Dock = DockStyle.Fill;

        //                                tlpnlProd.Controls.Add(objPlus, colIndx, 0);
        //                                tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
        //                                tlpnlProd.ColumnStyles[colIndx].Width = 30;
        //                                colIndx++;
        //                            }
        //                        }
        //                        else
        //                        {
        //                            int regno = Convert.ToInt32(ProductTbl.Rows[i]["nrnreg"].ToString());
        //                            string[] strHexArr = GetHexCodeOnRegNo(regno);
        //                            if (strHexArr != null)
        //                            {
        //                                for (int hIndx = 0; hIndx < strHexArr.Length; hIndx++)
        //                                {
        //                                    objUC = new ucProd_Reactant();
        //                                    objUC.Dock = DockStyle.Fill;
        //                                    objUC.NrnNum = ProductTbl.Rows[i]["num"].ToString();
        //                                    objUC.ChemImage = GetChemImageOnHexCode(strHexArr[hIndx], regno.ToString());

        //                                    tlpnlProd.Controls.Add(objUC, colIndx, 0);
        //                                    tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
        //                                    tlpnlProd.ColumnStyles[colIndx].Width = 290;
        //                                    colIndx++;
        //                                }

        //                                if (i < ProductTbl.Rows.Count - 1)
        //                                {
        //                                    objPlus = new ucPlus();
        //                                    objPlus.Dock = DockStyle.Fill;
        //                                    tlpnlProd.Controls.Add(objPlus, colIndx, 0);
        //                                    tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
        //                                    tlpnlProd.ColumnStyles[colIndx].Width = 30;
        //                                    colIndx++;
        //                                }
        //                            }
        //                            else // Empty structure in cgm file
        //                            {
        //                                objUC = new ucProd_Reactant();
        //                                objUC.Dock = DockStyle.Fill;
        //                                objUC.NrnNum = ProductTbl.Rows[i]["num"].ToString();
        //                                objUC.ChemImage = null;

        //                                tlpnlProd.Controls.Add(objUC, colIndx, 0);
        //                                tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
        //                                tlpnlProd.ColumnStyles[colIndx].Width = 290;
        //                                colIndx++;
        //                            }
        //                        }
        //                    }
        //                }
        //            }
        //            else
        //            {
        //                tlpnlProd.Controls.Clear();
        //            }
        //        }

        //        //rtxtPartpnts.Text = GetParticipantsFromTable();
        //        //if (strRSN_CVT_Rxn.Trim() != "")
        //        //{
        //        //    string strFinalVal = rtxtPartpnts.Text.Trim() + Environment.NewLine + Environment.NewLine + "RSN REACTION:" + Environment.NewLine + "             " + strRSN_CVT_Rxn.Trim();
        //        //    rtxtPartpnts.Text = strFinalVal;
        //        //}
        //        //if (strRSN_FT_Rxn.Trim() != "")
        //        //{
        //        //    rtxtPartpnts.Text = rtxtPartpnts.Text.Trim() + Environment.NewLine + "           " + strRSN_FT_Rxn.Trim();
        //        //}                
        //        //if (strRSN_FT_Stage.Trim() != "")
        //        //{
        //        //    if (strRSN_FT_Rxn.Trim() == "")
        //        //    {
        //        //        rtxtPartpnts.Text = rtxtPartpnts.Text.Trim() + Environment.NewLine + Environment.NewLine + strRSN_FT_Stage.Trim();
        //        //    }
        //        //    else
        //        //    {
        //        //        rtxtPartpnts.Text = rtxtPartpnts.Text.Trim() + Environment.NewLine + strRSN_FT_Stage.Trim();
        //        //    }
        //        //}
        //        //ColourRrbText(rtxtPartpnts);

        //        DataTable dtTemp = new DataTable();
        //        dtTemp.Columns.Add("RSN", typeof(string));

        //        DataRow dtRow = dtTemp.NewRow();

        //        string strVal = GetParticipantsFromTable();
        //        if (strRSN_CVT_Rxn.Trim() != "")
        //        {
        //            string strFinalVal = strVal.Trim() + "``" + "RSN REACTION:" + Environment.NewLine + "             " + strRSN_CVT_Rxn.Trim();
        //            strVal = strFinalVal;
        //        }
        //        if (strRSN_FT_Rxn.Trim() != "")
        //        {
        //            strVal = strVal.Trim() + "`" + "           " + strRSN_FT_Rxn.Trim();
        //        }
        //        if (strRSN_FT_Stage.Trim() != "")
        //        {
        //            if (strRSN_FT_Rxn.Trim() == "")
        //            {
        //                strVal = strVal.Trim() + "`" + "`" + strRSN_FT_Stage.Trim();
        //            }
        //            else
        //            {
        //                strVal = strVal.Trim() + "`" + strRSN_FT_Stage.Trim();
        //            }
        //        }

        //        //dtRow[0] = strVal;
        //        //dtTemp.Rows.Add(dtRow);

        //        //Binding richTextBoxBinding = rtxtPartpnts.DataBindings.Add("Text", dtTemp, dtTemp.Columns[0].ColumnName.ToString());
        //        ColourRrbText(rtxtPartpnts);
        //        //richTextBoxBinding.Format -= richTextBoxBinding_Format;
        //        //richTextBoxBinding.Format += richTextBoxBinding_Format;
        //        ////richTextBoxBinding.Parse += richTextBoxBinding_Parse;


        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //} 
        #endregion

        private void richTextBoxBinding_Format(object sender, ConvertEventArgs e)
        {
            if (e.DesiredType != typeof(string))
                return; // this conversion only makes sense for strings

            if (e.Value != null)
            {
                //ColourRrbText(rtxtPartpnts);
                e.Value = e.Value.ToString().Replace("`", "\r\n");
            }
        }

        string strRSN_CVT_Rxn = "";
        string strRSN_FT_Rxn = "";
        string strRSN_FT_Stage = "";
        private string GetParticipantsFromTable()
        {
            string strPartpnt = "";
            try
            {
                if (PartpntsTbl != null)
                {
                    if (PartpntsTbl.Rows.Count > 0)
                    {                        
                        for (int i = 0; i < PartpntsTbl.Rows.Count; i++)
                        {
                            if (PartpntsTbl.Rows[i]["Agents"].ToString().Trim() != "" ||
                                PartpntsTbl.Rows[i]["Solvents"].ToString().Trim() != "" ||
                                PartpntsTbl.Rows[i]["Catalysts"].ToString().Trim() != "" ||
                                PartpntsTbl.Rows[i]["Temperature"].ToString().Trim() != "" ||
                                PartpntsTbl.Rows[i]["Time"].ToString().Trim() != "" ||
                                PartpntsTbl.Rows[i]["Pressure"].ToString().Trim() != "" ||
                                PartpntsTbl.Rows[i]["pH"].ToString().Trim() != "")
                            {
                                if (strPartpnt.Trim() == "")
                                {
                                    strPartpnt = PartpntsTbl.Rows[i]["Stage"].ToString() + " - ";
                                }
                                else
                                {
                                    strPartpnt = strPartpnt + "`" + PartpntsTbl.Rows[i]["Stage"].ToString() + " - ";
                                }

                                if (PartpntsTbl.Rows[i]["Agents"].ToString().Trim() != "")
                                {
                                    strPartpnt = strPartpnt.Trim() + "  " + PartpntsTbl.Rows[i]["Agents"].ToString().Trim();
                                }
                                if (PartpntsTbl.Rows[i]["Solvents"].ToString().Trim() != "")
                                {
                                    strPartpnt = strPartpnt.Trim() + "  " + PartpntsTbl.Rows[i]["Solvents"].ToString().Trim();
                                }
                                if (PartpntsTbl.Rows[i]["Catalysts"].ToString().Trim() != "")
                                {
                                    strPartpnt = strPartpnt.Trim() + "  " + PartpntsTbl.Rows[i]["Catalysts"].ToString().Trim();
                                }
                                if (PartpntsTbl.Rows[i]["Temperature"].ToString().Trim() != "")
                                {
                                    strPartpnt = strPartpnt.Trim() + "  " + PartpntsTbl.Rows[i]["Temperature"].ToString().Trim();
                                }
                                if (PartpntsTbl.Rows[i]["Time"].ToString().Trim() != "")
                                {
                                    strPartpnt = strPartpnt.Trim() + "  " + PartpntsTbl.Rows[i]["Time"].ToString().Trim();
                                }                                
                                if (PartpntsTbl.Rows[i]["Pressure"].ToString().Trim() != "")
                                {
                                    strPartpnt = strPartpnt.Trim() + "  " + PartpntsTbl.Rows[i]["Pressure"].ToString().Trim();
                                }
                                if (PartpntsTbl.Rows[i]["pH"].ToString().Trim() != "")
                                {
                                    strPartpnt = strPartpnt.Trim() + "  " + PartpntsTbl.Rows[i]["pH"].ToString().Trim();
                                }
                            }
                            else//No Agent/Solvent/Catalyst/Conditions are available
                            {
                                if (strPartpnt.Trim() == "")
                                {
                                    strPartpnt = PartpntsTbl.Rows[i]["Stage"].ToString() + " - ";
                                }
                                else
                                {
                                    strPartpnt = strPartpnt + "`" + PartpntsTbl.Rows[i]["Stage"].ToString() + " - ";
                                }

                                strPartpnt = strPartpnt + " No Agent / Catalyst / Solent / Conditions are available";
                            }

                            if (PartpntsTbl.Rows[i]["RSN_CVT"].ToString().Trim() != "")
                            {
                                if (strRSN_CVT_Rxn.Trim() == "")
                                {
                                    strRSN_CVT_Rxn = "CVT: " + PartpntsTbl.Rows[i]["RSN_CVT"].ToString().Trim();
                                }
                                else
                                {
                                    strRSN_CVT_Rxn = strRSN_CVT_Rxn + ", " + PartpntsTbl.Rows[i]["RSN_CVT"].ToString().Trim();
                                }
                            }
                            if (PartpntsTbl.Rows[i]["RSN_FT_Reaction"].ToString().Trim() != "")
                            {
                                if (strRSN_FT_Rxn.Trim() == "")
                                {
                                    strRSN_FT_Rxn = "FREE: " + PartpntsTbl.Rows[i]["RSN_FT_Reaction"].ToString().Trim();
                                }
                                else
                                {
                                    strRSN_FT_Rxn = strRSN_FT_Rxn + ", " + PartpntsTbl.Rows[i]["RSN_FT_Reaction"].ToString().Trim();
                                }
                            }
                            if (PartpntsTbl.Rows[i]["RSN_FT_Stage"].ToString().Trim() != "")
                            {
                                if (strRSN_FT_Stage.Trim() == "")
                                {
                                    strRSN_FT_Stage = "RSN STAGE: " + PartpntsTbl.Rows[i]["RSN_FT_Stage"].ToString().Trim();
                                }
                                else
                                {
                                    strRSN_FT_Stage = strRSN_FT_Stage + ", " + PartpntsTbl.Rows[i]["RSN_FT_Stage"].ToString().Trim();
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strPartpnt;
        }
                
        private int GetPanelControlsLength(DataTable dt_prod_react,string _srcgrid)
        {
            int intLen = 0;
            try
            {
                if (dt_prod_react != null)
                {
                    if (dt_prod_react.Rows.Count > 0)
                    {
                        DataTable dtCgm = CGMDataTbl.Copy();

                        for (int i = 0; i < dt_prod_react.Rows.Count; i++)
                        {
                            int intRegNo = Convert.ToInt32(dt_prod_react.Rows[i]["nrnreg"].ToString());
                            if (intRegNo > 0)
                            {
                                string strFCond = "<SUBSTANC><RN ID=" + "\"" + intRegNo + "\"" + ">*";
                                try
                                {
                                    DataTable dtoutput = dtCgm.AsEnumerable().Where(a => Regex.IsMatch(a[dtCgm.Columns[0].ColumnName].ToString(), strFCond)).CopyToDataTable();
                                    if (dtoutput != null)
                                    {
                                        if (dtoutput.Rows.Count > 0)
                                        {
                                            string cellValue = dtoutput.Rows[0][0].ToString();
                                            if (cellValue.Contains("<SIM>"))//Single structure
                                            {
                                                if (_srcgrid.ToUpper() == "REACTANT")
                                                {
                                                    intLen = intLen + 2;
                                                }
                                                else
                                                {
                                                    intLen = intLen + 1;
                                                }
                                            }
                                            else if (cellValue.Contains("<CSIM>"))//Multiple strucrures
                                            {
                                                string[] splitter = { "<CSIM>" };
                                                string[] strVals = cellValue.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                                                if (strVals != null)
                                                {
                                                    if (strVals.Length > 0)
                                                    {
                                                        if (i == 0 && dt_prod_react.Rows.Count > 1)
                                                        {
                                                            intLen = intLen + strVals.Length;
                                                        }
                                                        if (_srcgrid.ToUpper() == "REACTANT" && strVals.Length > 1)//New condition for multiple Reactants
                                                        {
                                                            intLen = intLen + strVals.Length;
                                                        }
                                                        else
                                                        {
                                                            intLen = intLen + (strVals.Length - 1);
                                                        }
                                                    }
                                                }
                                            }
                                            else //No Structure
                                            {
                                                if (_srcgrid.ToUpper() == "REACTANT")
                                                {
                                                    intLen = intLen + 2;
                                                }
                                                else
                                                {
                                                    intLen = intLen + 1;
                                                }
                                            }
                                        }
                                    }
                                }
                                catch//Exception for 8500 
                                {
                                    intLen = intLen + 2;
                                }
                            }
                            else
                            {
                                intLen = intLen + 2;
                            }
                        }
                        if (_srcgrid.ToUpper() == "PRODUCT" && dt_prod_react.Rows.Count > 1)
                        {
                            intLen = intLen + 1;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return intLen;
        }

        private string[] GetHexCodeOnRegNo(int _regno)
        {
            string[] strHexArr = null;
            try
            {
                if (CGMDataTbl != null)
                {
                    if (CGMDataTbl.Rows.Count > 0)
                    {
                        DataTable dtcdm = CGMDataTbl.Copy();
                        DataTable dt = new DataTable();

                        string strFCond = "<SUBSTANC><RN ID=" + "\"" + _regno + "\"" + ">*";
                        try
                        {
                            DataTable dtoutput = dtcdm.AsEnumerable().Where(a => Regex.IsMatch(a[dtcdm.Columns[0].ColumnName].ToString(), strFCond)).CopyToDataTable();
                            if (dtoutput != null)
                            {
                                if (dtoutput.Rows.Count > 0)
                                {
                                    string cellValue = dtoutput.Rows[0][0].ToString();
                                    if (cellValue.Contains("<SIM>"))//Single structure
                                    {
                                        string strSIM = cellValue.Substring(cellValue.IndexOf("<SIM>") + ("<SIM>".Length), ((cellValue.IndexOf("</SIM>") + 1) - cellValue.IndexOf("<SIM>")) - ("</SIM>".Length));
                                        strHexArr = new string[1];
                                        strHexArr[0] = strSIM;
                                        return strHexArr;
                                    }
                                    else if (cellValue.Contains("<CSIM>"))//Multiple strucrures
                                    {                                       
                                        object[] objArr = new object[1];
                                        string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";
                                        cellValue = strXml + "\r\n" + cellValue; 
                                        objArr[0] = cellValue;

                                        XmlDocument xDoc = new XmlDocument();
                                        xDoc.LoadXml(cellValue);

                                        XmlNodeList xNdLst= xDoc.SelectNodes("SUBSTANC/COMP/CSIM");
                                        if (xNdLst.Count > 0)
                                        {
                                            strHexArr = new string[xNdLst.Count];                                            
                                            for (int i = 0; i < xNdLst.Count; i++)
                                            {
                                                strHexArr[i] = xNdLst[i].InnerText;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        catch //Exception for series 8500 RegNos
                        {

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strHexArr;
        }
        
        private void ColourRrbText(RichTextBox rtb)
        {
            try
            {
                //Match m = Regex.Match(rtb.Text, "AGENT|SOLVENT|CATALYST", RegexOptions.Singleline);
                //if (m.Success)
                //{
                //    rtb.SelectionStart = m.Index;
                //    rtb.SelectionLength = m.Length;
                //    rtb.SelectionColor = Color.Green;
                //}

                Regex regEx_C = new Regex("TP:|TM:|PR:|PH:", RegexOptions.CultureInvariant);
                foreach (Match match in regEx_C.Matches(rtb.Text))
                {
                    rtb.Select(match.Index, match.Length);
                    rtb.SelectionColor = Color.Red;
                }

                Regex regEx_P = new Regex("AGENT|SOLVENT|CATALYST");
                foreach (Match match in regEx_P.Matches(rtb.Text))
                {
                    rtb.Select(match.Index, match.Length);
                    rtb.SelectionColor = Color.LimeGreen;
                }

                Regex regEx_R = new Regex("RSN REACTION|RSN STAGE");
                foreach (Match match in regEx_R.Matches(rtb.Text))
                {
                    rtb.Select(match.Index, match.Length);
                    rtb.SelectionColor = Color.DarkViolet;
                }

                Regex regEx_CVT = new Regex("CVT|FREE");
                foreach (Match match in regEx_CVT.Matches(rtb.Text))
                {
                    rtb.Select(match.Index, match.Length);
                    rtb.SelectionColor = Color.Magenta;
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }           
    }
}
