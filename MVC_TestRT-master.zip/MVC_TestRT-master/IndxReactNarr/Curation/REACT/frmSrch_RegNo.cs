﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using IndxReactNarrDAL;

namespace IndxReactNarr
{
    public partial class frmSrch_RegNo : Form
    {
        public frmSrch_RegNo()
        {
            InitializeComponent();
        }

        #region Property Procedures
        
        public int TAN_ID
        { get; set; }

        public int RegNo
        { get; set; }

        public string PP_Name
        { get; set; }

        public string TAN_Name
        { get; set; }

        public string SeriesType
        { get; set; }

        public int SeriesNumID
        { get; set; } 
        
        #endregion

        private void frmSrch_RegNo_Load(object sender, EventArgs e)
        {
            try
            {
                if (TAN_ID > 0)
                {
                    txtTAN.Text = TAN_Name;

                    if (SeriesNumID > 0)//Auto Search
                    {
                        Cursor = Cursors.WaitCursor;
                       
                        txtSubstName.Text = PP_Name;
                        txtRegNo.Text = RegNo > 0 ? RegNo.ToString() : "";
                       
                        DataTable dtSrchRes = ReactDB.GetRegNo_SubstNameSearchResults(TAN_ID, SeriesType, SeriesNumID);
                        BindSearchResultToGrid(dtSrchRes);

                        Cursor = Cursors.Default;
                    }
                    else
                    {
                        txtSubstName.ReadOnly = false;
                        txtRegNo.ReadOnly = false;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindSearchResultToGrid(DataTable srchResults)
        {
            try
            {
                if (srchResults != null)
                {
                    dgvSrchResult.AutoGenerateColumns = false;
                    dgvSrchResult.DataSource = srchResults;
                                        
                    colRxnSNo.DataPropertyName = "DISPLAY_ORDER";
                    colRxnNum.DataPropertyName = "RXN_NUM";
                    colRxnSeq.DataPropertyName = "RXN_SEQ";
                    colStage.DataPropertyName = "STAGE_NAME";
                    colPartpntType.DataPropertyName = "PP_TYPE";
                }
                else
                {
                    dgvSrchResult.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvSrchResult_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvSrchResult.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvSrchResult.Font);

                if (dgvSrchResult.RowHeadersWidth < (int)(size.Width + 20)) dgvSrchResult.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       

        private void txtRegNo_KeyDown(object sender, KeyEventArgs e)
        {
           try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    if (TAN_ID > 0)
                    {
                        int regNo = 0;
                        int.TryParse(txtRegNo.Text.ToString(), out regNo);                        

                        DataTable dtSrchRes = ReactDB.GetRegNoSubstNameSearchResults_Generic(TAN_ID, regNo, txtSubstName.Text.Trim());
                        BindSearchResultToGrid(dtSrchRes);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        
    }
}
