﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;

namespace IndxReactNarr
{
    public partial class frmCASREACTHelp : Form
    {
        public frmCASREACTHelp()
        {
            InitializeComponent();
        }

        #region Property Procedures

        public string InputManualPath
        {
            get;
            set;
        }
       
        public string CodingHintsPath
        {
            get;
            set;
        }
                
        public string ConditionsPath
        {
            get;
            set;
        }

        public string StructConvPath
        {
            get;
            set;
        }
        
        public string ProtUpdatesPath
        {
            get;
            set;
        }
        
        public string RSNPath
        {
            get;
            set;
        }
        
        public string AbstractsPath
        {
            get;
            set;
        }

        public string RoleIndPath
        {
            get;
            set;
        }
        
        public string IndxManualPath
        {
            get;
            set;
        }

        public string TitlePath
        {
            get;
            set;
        }

        public string StereoChemPath
        {
            get;
            set;
        }

        public int activeTab
        { get; set; } 
        
        #endregion

        private void frmCASREACTHelp_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public void LoadFileInControl()
        {
            try
            {        
                if (!string.IsNullOrEmpty(InputManualPath))
                {           
                    pdfCntrl_Input.Visible = true;
                    pdfCntrl_Input.IsAccessible = true;
                    pdfCntrl_Input.LoadFile(InputManualPath);
                    tbCntrl_Pdfs.TabPages["tpInputManual"].Show();
                }
               
                if (!string.IsNullOrEmpty(CodingHintsPath))
                {
                    pdfCntrl_CHints.Visible = true;
                    pdfCntrl_CHints.IsAccessible = true;
                    pdfCntrl_CHints.LoadFile(CodingHintsPath);
                    tbCntrl_Pdfs.TabPages["tpCodingHints"].Show();
                }
                
                if (!string.IsNullOrEmpty(ConditionsPath))
                {
                    pdfCntrl_Conds.Visible = true;
                    pdfCntrl_Conds.IsAccessible = true;
                    pdfCntrl_Conds.LoadFile(ConditionsPath);
                    tbCntrl_Pdfs.TabPages["tpGenRmdrs_Conds"].Show();                    
                }               
                
                if (!string.IsNullOrEmpty(ProtUpdatesPath))
                {
                    pdfCntrl_pUpdates.Visible = true;
                    pdfCntrl_pUpdates.IsAccessible = true;
                    pdfCntrl_pUpdates.LoadFile(ProtUpdatesPath);
                    tbCntrl_Pdfs.TabPages["tpProtocol_Updates"].Show();
                }              
                               
                if (!string.IsNullOrEmpty(RSNPath))
                {
                    pdfCntrl_RSNManual.Visible = true;
                    pdfCntrl_RSNManual.IsAccessible = true;
                    pdfCntrl_RSNManual.LoadFile(RSNPath);
                    tbCntrl_Pdfs.TabPages["tpRSNManual"].Show();
                }                

                //Indexing Manual
                if (!string.IsNullOrEmpty(IndxManualPath))
                {
                    axPdfIndxManual.Visible = true;
                    axPdfIndxManual.IsAccessible = true;
                    axPdfIndxManual.LoadFile(IndxManualPath);
                    tbCntrl_Pdfs.TabPages["tpIndxManual"].Show();
                }

                //Role Indicators
                if (!string.IsNullOrEmpty(RoleIndPath))
                {
                    axPdfRoleInd.Visible = true;
                    axPdfRoleInd.IsAccessible = true;
                    axPdfRoleInd.LoadFile(RoleIndPath);
                    tbCntrl_Pdfs.TabPages["tpRoleIndicators"].Show();
                }

                //Abstract
                if (!string.IsNullOrEmpty(AbstractsPath))
                {
                    axPdfAbstract.Visible = true;
                    axPdfAbstract.IsAccessible = true;
                    axPdfAbstract.LoadFile(AbstractsPath);
                    tbCntrl_Pdfs.TabPages["tpAbstract"].Show();
                }

                //Structure Conversions
                if (!string.IsNullOrEmpty(StructConvPath))
                {
                    axPdfStructConv.Visible = true;
                    axPdfStructConv.IsAccessible = true;
                    axPdfStructConv.LoadFile(StructConvPath);
                    tbCntrl_Pdfs.TabPages["tpStructConvensions"].Show();
                }

                //Title 
                if (!string.IsNullOrEmpty(TitlePath))
                {
                    axPdfTitle.Visible = true;
                    axPdfTitle.IsAccessible = true;
                    axPdfTitle.LoadFile(TitlePath);
                    tbCntrl_Pdfs.TabPages["tpTitle"].Show();
                }

                //StereoChemistry
                if (!string.IsNullOrEmpty(StereoChemPath))
                {
                    axPdfStereoChem.Visible = true;
                    axPdfStereoChem.IsAccessible = true;
                    axPdfStereoChem.LoadFile(StereoChemPath);
                    tbCntrl_Pdfs.TabPages["tpStereoChem"].Show();
                }

                tbCntrl_Pdfs.SelectedIndex = activeTab;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
