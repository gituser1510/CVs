﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarrDAL;
using IndxReactNarr.Common;
using IndxReactNarr.Generic;
using IndxReactNarrBll;

namespace IndxReactNarr
{
    public partial class frmManage8500 : Form
    {
        #region Constructor

        public frmManage8500()
        {
            InitializeComponent();
        }

        #endregion

        #region Property Procedures

        public DataTable TAN_Ser8500Data
        { get; set; }

        public DataTable NUM_RegNoData
        { get; set; }

        public int TAN_ID
        {
            get;
            set;
        }
        
        public string TAN_Name
        {
            get;
            set;
        }
        
        public frmReactCuration RxnMain
        {
            get;
            set;
        }

        public DataTable Ser8500Master { get; set; }

        #endregion
               
        DataTable dtGridData = null;
        string strNrnReg_Sel = "";
        string strName_Sel = "";
        int orgRefID_Sel = 0;
        int TS_ID = 0;
        
        private void frmManage8500_Load(object sender, EventArgs e)
        {
            try
            {
                //Bind Data to ComboBox Controls
                // BindDataToComboBoxControls(0,0,"");

                //Bind Data to Series 8500 Grid
                BindSeries8500DataToGrid();

                //Get Series 8500 OrgRef data Bind to Grid
                DataTable dtSer8500_OrgRef = GlobalVariables.Ser8500OrgrefData;//CASRxnDataAccess.GetOrgRefMasterDataOnNumType("8500");
                if (dtSer8500_OrgRef != null)
                {                  
                    DataTable dtSer8500OrgRef = dtSer8500_OrgRef.Clone();
                    dtSer8500OrgRef.Columns["REG_NO"].DataType = System.Type.GetType("System.String");
                    dtSer8500OrgRef.Columns["ORGREF_NAME"].DataType = System.Type.GetType("System.String");
                    //dtSer8500OrgRef.Columns["MOL_FILE"].DataType = System.Type.GetType("System.String");
                    //dtSer8500OrgRef.Columns["INCHI_KEY"].DataType = System.Type.GetType("System.String");

                    foreach (DataRow dr in dtSer8500_OrgRef.Rows)
                    {
                        dtSer8500OrgRef.ImportRow(dr);
                    }
                    Ser8500Master = dtSer8500OrgRef;
                    BindSer8500OrgRefDataToGrid(dtSer8500OrgRef);
                }                
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }     

        private void BindSeries8500DataToGrid()
        {
            try
            {
                if (TAN_Ser8500Data != null)
                {
                    DataView dtView = TAN_Ser8500Data.DefaultView;
                    //dtView.RowFilter = "tan = '" + TAN_ID + "'";
                    dtView.Sort = "TS_ID asc";
                    dtGridData = dtView.ToTable();// dtView.ToTable();

                    dg8500Series.AutoGenerateColumns = false;
                    dg8500Series.DataSource = dtGridData;

                    colTSID_Manage.DataPropertyName = "TS_ID";
                    colOrgRefID_Managed.DataPropertyName = "ORGREF_ID";
                    colSeries8500_Manage.DataPropertyName = "SERIES_8500";
                    coLRegNo_Manage.DataPropertyName = "REG_NO";
                    colName_Manage.DataPropertyName = "ORGREF_NAME";

                    if (dtGridData.Rows.Count > 0)
                    {
                        int intSer8500Cnt = 0;
                        int.TryParse(dtGridData.Rows[dtGridData.Rows.Count - 1]["SERIES_8500"].ToString(), out intSer8500Cnt);
                        if (intSer8500Cnt > 8500)
                        {
                            txtSeries8500.Text = (intSer8500Cnt + 1).ToString();
                        }
                    }
                    else
                    {
                        txtSeries8500.Text = "8501";
                    }
                }
                else
                {
                    txtSeries8500.Text = "8501";
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        

        private void BindSer8500OrgRefDataToGrid(DataTable ser8500Orgref)
        {
            try
            {
                if (ser8500Orgref != null)
                {
                    dgvSer8500_OrgRef.AutoGenerateColumns = false;
                    dgvSer8500_OrgRef.DataSource = ser8500Orgref;

                    colOrgRefID_OrgRef.DataPropertyName = "ORGREF_ID";
                    colRegNo_OrgRef.DataPropertyName = "REG_NO";
                    colName_OrgRef.DataPropertyName = "ORGREF_NAME";                    
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindSeries8500_OrgRefDataToControls(DataGridViewRow gridrow)
        {
            try
            {
                //Clear Control values before assiging new values
                ResetControlValues(this.Controls);

                if (gridrow != null)
                {
                    txtNrnReg.Text = gridrow.Cells[colRegNo_OrgRef.Name].Value.ToString();
                    txtName.Text = gridrow.Cells[colName_OrgRef.Name].Value.ToString();                   

                    strNrnReg_Sel = gridrow.Cells[colRegNo_OrgRef.Name].Value.ToString();
                    strName_Sel = gridrow.Cells[colName_OrgRef.Name].Value.ToString();
                    orgRefID_Sel = gridrow.Cells[colOrgRefID_OrgRef.Name].Value != null ? Convert.ToInt32(gridrow.Cells[colOrgRefID_OrgRef.Name].Value.ToString()) : 0; 

                    if (dtGridData.Rows.Count > 0)
                    {
                        //int intser8500val = 0;
                        //int.TryParse(dtGridData.Rows[dtGridData.Rows.Count - 1]["SERIES_8500"].ToString(), out intser8500val);
                        //if (intser8500val > 8500)
                        //{
                        //    txtSeries8500.Text = (intser8500val + 1).ToString();
                        //}
                    }
                    else
                    {
                        txtSeries8500.Text = "8501";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void ResetControlValues(Control.ControlCollection cntrlcoll)
        {
            try
            {   
                //foreach (Control ctrl in cntrlcoll)
                //{
                //    TextBox tb = ctrl as TextBox;                  
                //    Button btn = ctrl as Button;
                //    if (tb != null)
                //    {
                //        tb.Clear();
                //        if (tb.Name.ToUpper() == "TXTNRNREG")
                //        {
                //            tb.ReadOnly = false;
                //        }
                //    }                    
                //    else if (btn != null)
                //    {
                //        btn.Enabled = true;
                //    }
                //    else
                //    {
                //        ResetControlValues(ctrl.Controls);
                //    }
                //}

                txtName.Text = "";
                txtNrnReg.Text = "";
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private DataTable GetSortedNRNREG(IndxReactNarr.SortableBindingList<int> list)
        {
            DataTable dtNrnReg = null;
            try
            {
                if (list != null)
                {
                    if (list.Count > 0)
                    {
                        dtNrnReg = new DataTable();
                        dtNrnReg.Columns.Add("NrnReg",typeof(Int32));
                        DataRow dtRow = null;
                        for (int i = 0; i < list.Count; i++)
                        {
                            dtRow = dtNrnReg.NewRow();
                            dtRow["NrnReg"] = list[i];
                            dtNrnReg.Rows.Add(dtRow);
                        }
                        if (dtNrnReg != null)
                        {
                            if (dtNrnReg.Rows.Count > 0)
                            {
                                DataView dv = dtNrnReg.DefaultView;
                                dv.Sort = "NrnReg Asc";
                                dtNrnReg = dv.ToTable();
                            }
                        }
                        return dtNrnReg;
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtNrnReg;
        }
        
        private bool CheckRegNoInTAN_NUMsTable(string regNo, out string _num)
        {
            bool blStatus = false;            
            string strNUM = "";
            try
            {
                if (regNo != "" && NUM_RegNoData != null)
                {
                    if (NUM_RegNoData.Rows.Count > 0)
                    {
                        DataRow[] dtRowArr = NUM_RegNoData.Select("REG_NO = " + regNo + "");
                        if (dtRowArr != null)
                        {
                            if (dtRowArr.Length > 0)
                            {                               
                                strNUM = dtRowArr[0]["NUM"].ToString();
                                blStatus = true;
                            }
                            else
                            {
                                blStatus = false;
                            }
                        }
                        else
                        {
                            blStatus = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }           
            _num = strNUM;
            return blStatus;
        }

        private bool CheckForSer8500ValInNUMsTable(int ser8500val, int regno, out string errmsg_out)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                if (ser8500val > 0)
                {
                    if (NUM_RegNoData != null)
                    {
                        if (NUM_RegNoData.Rows.Count > 0)
                        {
                            DataRow[] dtRowArr = NUM_RegNoData.Select("NUM = " + ser8500val + "");
                            if (dtRowArr != null)
                            {
                                if (dtRowArr.Length > 0)
                                {
                                    blStatus = true;
                                    strErrMsg = ser8500val + " already exist in the table";                                    
                                }
                            }

                            DataRow[] dtRowArr_Reg = NUM_RegNoData.Select("REG_NO = " + regno + "");
                            if (dtRowArr_Reg != null)
                            {
                                if (dtRowArr_Reg.Length > 0)
                                {
                                    blStatus = true;
                                    strErrMsg = "Registry No. " + regno + " already exist in the NUMs table";
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg; 
            return blStatus;
        }

        private bool CheckForSer8500ValInTable(int tsid, int regNo, out string errmsg_out)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                if (TAN_Ser8500Data != null)
                {
                    if (TAN_Ser8500Data.Rows.Count > 0)
                    {
                        DataRow[] dtRowArr_Reg = TAN_Ser8500Data.Select("REG_NO = " + regNo + "");
                        if (dtRowArr_Reg != null)
                        {
                            if (dtRowArr_Reg.Length > 0 && tsid == 0)
                            {
                                blStatus = true;
                                strErrMsg = "Registry No. " + regNo + " already exist in the Managed 8500 series table";
                            }
                            else if (tsid > 0)
                            {
                                foreach (DataRow row in dtRowArr_Reg)
                                {
                                    if (row["TS_ID"] != null)
                                    {
                                        if (Convert.ToInt32(row["TS_ID"]) != tsid)
                                        {
                                            blStatus = true;
                                            strErrMsg = "Registry No. " + regNo + " already exist in the Managed 8500 series table";
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg;
            return blStatus;
        }       

        private void dg8500Series_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex < 0 || e.RowIndex < 0)
                {
                    return;
                }

                if (dg8500Series.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString().ToUpper() == "DELETE")
                {
                    DialogResult diaRes = MessageBox.Show("Do you want to delete?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (diaRes == DialogResult.Yes)
                    {
                        int int8500Val = Convert.ToInt32(dg8500Series.Rows[e.RowIndex].Cells[colSeries8500_Manage.Name].Value.ToString());
                        int intTSID = Convert.ToInt32(dg8500Series.Rows[e.RowIndex].Cells[colTSID_Manage.Name].Value.ToString());
                        int intOrgRefID = Convert.ToInt32(dg8500Series.Rows[e.RowIndex].Cells[colOrgRefID_Managed.Name].Value.ToString());

                        DataTable dtSaved8500 = ReactDB.GetSavedSeriesDataOnTANAndSeriesValue(TAN_ID, intTSID,int8500Val, 8500);
                        if (dtSaved8500 != null)
                        {
                            if (dtSaved8500.Rows.Count > 0)
                            {
                                frm8500ValsExist obj8500Vals = new frm8500ValsExist();

                                DataView dvTemp = dtSaved8500.Copy().DefaultView;
                                dvTemp.RowFilter = "PP_TYPE = 'PRODUCT'";
                                DataTable dtProduct = dvTemp.ToTable();
                                obj8500Vals.ProdSavedSeries = dtProduct;

                                //DataView dvTemp = dt8000_Saved.Copy().DefaultView;
                                dvTemp.RowFilter = "PP_TYPE <> 'PRODUCT'";
                                DataTable dtParticipant = dvTemp.ToTable();
                                obj8500Vals.PartpntSavedSeries = dtParticipant;

                                obj8500Vals.ShowDialog();
                            }
                            else
                            {
                                ManageSeries8500 objSer8500 = new ManageSeries8500();

                                objSer8500.Ser8500Val = int8500Val;//Convert.ToInt32(dtGridData.Rows[e.RowIndex]["SERIES_8500"].ToString());
                                objSer8500.TS_ID = intTSID;//Convert.ToInt32(dtGridData.Rows[e.RowIndex]["TS_ID"].ToString());
                                objSer8500.OrgRefID = intOrgRefID;// Convert.ToInt32(dtGridData.Rows[e.RowIndex]["ORGREF_ID"].ToString());
                                objSer8500.Option = "DELETE";
                                objSer8500.TAN_ID = TAN_ID;

                                //Delete series 8500 value from database
                                DataTable dtSer8500 = null;
                                if (ReactDB.UpdateSeries8500DetailsOnTAN(objSer8500, out dtSer8500))
                                {
                                    TAN_Ser8500Data = dtSer8500;

                                    //Delete8500ValFromTable(int8500Val.ToString(), TAN_Name);
                                    //dg8500Series.DataSource = null;

                                    //Bind data to Series 8500 Grid
                                    BindSeries8500DataToGrid();

                                    //Re-Bind data in ComboBoxes
                                    //BindDataToComboBoxControls(0, 0, "");
                                }
                            }
                        }                       
                    }
                }
                else if (dg8500Series.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString().ToUpper() == "EDIT")
                {
                    DialogResult diaRes = MessageBox.Show("Do you want to edit?",GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (diaRes == DialogResult.Yes)
                    {
                        int int8500Val = Convert.ToInt32(dg8500Series.Rows[e.RowIndex].Cells[colSeries8500_Manage.Name].Value.ToString());
                        TS_ID = Convert.ToInt32(dg8500Series.Rows[e.RowIndex].Cells[colTSID_Manage.Name].Value.ToString());
                        int intOrgRefID = Convert.ToInt32(dg8500Series.Rows[e.RowIndex].Cells[colOrgRefID_Managed.Name].Value.ToString());

                        string strName = dg8500Series.Rows[e.RowIndex].Cells[colName_Manage.Name].Value.ToString();
                        int intRegNoVal = Convert.ToInt32(dg8500Series.Rows[e.RowIndex].Cells[coLRegNo_Manage.Name].Value.ToString());

                        //int intS8500Val = Convert.ToInt32(dtGridData.Rows[e.RowIndex]["SERIES_8500"].ToString());
                        //int intRegNoVal = Convert.ToInt32(dtGridData.Rows[e.RowIndex]["REG_NO"].ToString());
                        //string strName = dtGridData.Rows[e.RowIndex]["ORGREF_NAME"].ToString();
                        //TS_ID = Convert.ToInt32(dtGridData.Rows[e.RowIndex][colTSID_Manage.Name].ToString());
                        //Re-Bind data in ComboBoxes
                        //BindDataToComboBoxControls(intS8500Val, intRegNoVal, strName);

                        txtSeries8500.Text = int8500Val.ToString();
                        

                        txtNrnReg.Text = intRegNoVal.ToString();
                        txtName.Text = strName;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void Delete8500ValFromTable(string _ser8500val,string _tan)
        {
            try
            {
                if (TAN_Ser8500Data != null)
                {
                    if (TAN_Ser8500Data.Rows.Count > 0)
                    {
                        for (int i = 0; i < TAN_Ser8500Data.Rows.Count; i++)
                        {
                            if (TAN_Ser8500Data.Rows[i]["ser8500"].ToString() == _ser8500val && TAN_Ser8500Data.Rows[i]["tan"].ToString() == _tan)
                            {
                                TAN_Ser8500Data.Rows[i].Delete();
                                TAN_Ser8500Data.AcceptChanges();
                                return;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtSeries8500.Text.Trim()) && !string.IsNullOrEmpty(strNrnReg_Sel.Trim()))
                {
                    int intSer8500 = 0;
                    int.TryParse(txtSeries8500.Text.ToString(), out intSer8500);

                    int inRegNo = 0;
                    int.TryParse(strNrnReg_Sel.Trim(), out inRegNo);

                    string strDesc = strName_Sel.Trim();

                    ManageSeries8500 objMngSer8500 = new ManageSeries8500();                    
                    objMngSer8500.TS_ID = TS_ID;
                    objMngSer8500.TAN_ID = TAN_ID;
                    objMngSer8500.OrgRefID = orgRefID_Sel;                   
                    objMngSer8500.Ser8500Val = intSer8500;
                    objMngSer8500.Option = TS_ID == 0 ? "INSERT" : "UPDATE";
                    
                    if (intSer8500 > 0 && inRegNo > 0)
                    {
                        string strErrMsg = "";
                        if (!CheckForSer8500ValInNUMsTable(intSer8500, inRegNo, out strErrMsg))//Check in the NUMs table
                        {
                            if (!CheckForSer8500ValInTable(TS_ID, inRegNo, out strErrMsg))
                            {
                                DataTable dtSer8500 = null;
                                if (ReactDB.UpdateSeries8500DetailsOnTAN(objMngSer8500, out dtSer8500))
                                {
                                    //Clear User Inputs
                                    ClearUserInputs();

                                    //Re-Bind data in ComboBoxes
                                    //BindDataToComboBoxControls(0, 0, "");
                                    TAN_Ser8500Data = dtSer8500;
                                    BindSeries8500DataToGrid();

                                    if (TS_ID > 0)
                                    {
                                        MessageBox.Show("Changes done successfully.To reflect the changes close and re-open the TAN", "Manage 8500 Series", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    }
                                    else
                                    {
                                        MessageBox.Show("Record saved successfully", "Manage 8000 Series", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    }

                                    //Reset TS_ID
                                    TS_ID = 0;
                                }
                            }
                            else
                            {
                                MessageBox.Show(strErrMsg, "Manage 8500 Series", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show(strErrMsg, "Manage 8500 Series", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
         
        private string ReplaceSpecialCharsinString(string value)
        {
            StringBuilder sb = new StringBuilder(value.Length);
            for (int i = 0; i < value.Length; i++)
            {
                char c = value[i];
                switch (c)
                {
                    case ']':
                    case '[':
                    case '%':
                    case '*':
                        sb.Append("[").Append(c).Append("]");
                        break;
                    case '\'':
                        sb.Append("''");
                        break;
                    default:
                        sb.Append(c);
                        break;
                }
            }
            return sb.ToString();
        }

        private void ClearUserInputs()
        {
            try
            {       
                txtNrnReg.Text = "";
                txtName.Text = "";

                orgRefID_Sel = 0;
                TS_ID = 0;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void UpdateRowInSer8500Table(string _tan,int _ser8500val, int _nrnreg, string _name)
        {
            try
            {
                if (TAN_Ser8500Data != null)
                {
                    if (TAN_Ser8500Data.Rows.Count > 0)
                    {
                        for (int i = 0; i < TAN_Ser8500Data.Rows.Count; i++)
                        {
                            if (TAN_Ser8500Data.Rows[i]["tan"].ToString() == _tan
                                && TAN_Ser8500Data.Rows[i]["ser8500"].ToString() == _ser8500val.ToString())
                            {
                                TAN_Ser8500Data.Rows[i]["NrnReg"] = _nrnreg;
                                TAN_Ser8500Data.Rows[i]["descriptor"] = _name;

                                break;
                            }
                        }
                        TAN_Ser8500Data.AcceptChanges();
                    }
                }

                if (dtGridData != null)
                {
                    if (dtGridData.Rows.Count > 0)
                    {
                        for (int i = 0; i < dtGridData.Rows.Count; i++)
                        {
                            if (dtGridData.Rows[i]["ser8500"].ToString() == _ser8500val.ToString())
                            {
                                dtGridData.Rows[i]["NrnReg"] = _nrnreg;
                                dtGridData.Rows[i]["descriptor"] = _name;
                                break;
                            }
                        }
                        dtGridData.AcceptChanges();
                    }
                }

                //Update Series 8500 value in the current reaction
                UpdateSer8500InCurrentReaction(_ser8500val.ToString(), _nrnreg, _name);
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void UpdateSer8500InCurrentReaction(string ser8500val, int nrnreg, string nameval)
        {
            try
            {
                if (ser8500val.Trim() != "")
                {
                    frmReactCuration objRxnMain = RxnMain;
                    if (objRxnMain != null)
                    {
                        //Update Product Table
                        DataTable dtProd = objRxnMain.RxnProductsTbl;
                        UpdateSer8500ValuesInTable(dtProd,ser8500val,nrnreg,nameval);

                        ucParticipants ucPartpnt = null;
                        for (int j = 0; j < objRxnMain.tcStages.TabCount; j++)
                        {
                            ucPartpnt = (ucParticipants)objRxnMain.tcStages.TabPages[j].Controls[0];
                            if (ucPartpnt != null)
                            {
                                //Update Reactant Table
                                DataTable dtReact = ucPartpnt.dtReactant;
                                UpdateSer8500ValuesInTable(dtReact, ser8500val,nrnreg,nameval);

                                //Update Agent Table
                                DataTable dtAgent = ucPartpnt.dtAgent;
                                UpdateSer8500ValuesInTable(dtAgent, ser8500val, nrnreg, nameval);

                                //Update Solvent Table
                                DataTable dtSolv = ucPartpnt.dtSolvent;
                                UpdateSer8500ValuesInTable(dtSolv, ser8500val, nrnreg, nameval);

                                //Update Catalyst Table
                                DataTable dtCatl = ucPartpnt.dtCatalyst;
                                UpdateSer8500ValuesInTable(dtCatl, ser8500val, nrnreg, nameval);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void UpdateSer8500ValuesInTable(DataTable partpnttbl, string ser8500val, int nrnreg, string nameval)
        {
            try
            {
                if (partpnttbl != null)
                {
                    for (int i = 0; i < partpnttbl.Rows.Count; i++)
                    {
                        if (partpnttbl.Rows[i]["p_8500"].ToString() == ser8500val)
                        {                        
                            partpnttbl.Rows[i]["nrnreg"] = nrnreg;
                            partpnttbl.Rows[i]["name"] = nameval;                         

                            partpnttbl.AcceptChanges();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #region GridView RowPostPaint Events

        private void dg8500Series_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dg8500Series.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dg8500Series.Font);

                if (dg8500Series.RowHeadersWidth < (int)(size.Width + 20)) dg8500Series.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgNumGrid_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgNumGrid.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgNumGrid.Font);

                if (dgNumGrid.RowHeadersWidth < (int)(size.Width + 20)) dgNumGrid.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvSer8500_OrgRef_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvSer8500_OrgRef.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvSer8500_OrgRef.Font);

                if (dgvSer8500_OrgRef.RowHeadersWidth < (int)(size.Width + 20)) dgvSer8500_OrgRef.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                //Re-Bind data in ComboBoxes
                //BindDataToComboBoxControls(0, 0, "");

                BindSer8500OrgRefDataToGrid(Ser8500Master.Copy());


                txtName.Text = "";
                txtNrnReg.Text = "";                

                strNrnReg_Sel = "";
                strName_Sel = "";

                TS_ID = 0;
                orgRefID_Sel = 0;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }            

        private void txtNrnReg_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (txtNrnReg.Text.Trim() != "")
                {
                    txtName.Text = "";

                    DataView dvTemp = Ser8500Master.Copy().DefaultView;
                    dvTemp.RowFilter = "REG_NO Like '" + txtNrnReg.Text.Trim() + "%' ";
                    DataTable dtSer8500_OrgRef = dvTemp.ToTable();
                    if (dtSer8500_OrgRef != null)
                    {
                        BindSer8500OrgRefDataToGrid(dtSer8500_OrgRef);
                    }
                }
                else
                {
                    BindSer8500OrgRefDataToGrid(Ser8500Master.Copy());
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtName_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (txtName.Text.Trim() != "")
                {
                    txtNrnReg.Text = "";

                    DataView dvTemp = Ser8500Master.Copy().DefaultView;
                    dvTemp.RowFilter = "ORGREF_NAME Like '" + DataConversions.EscapeSpecialCharsInFilterCondition(txtName.Text.Trim()) + "%' ";
                    DataTable dtSer8500_OrgRef = dvTemp.ToTable();
                    if (dtSer8500_OrgRef != null)
                    {
                        BindSer8500OrgRefDataToGrid(dtSer8500_OrgRef);
                    }
                }
                else
                {
                    BindSer8500OrgRefDataToGrid(Ser8500Master.Copy());
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       

        private void dgvSer8500_OrgRef_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    if (dgvSer8500_OrgRef.SelectedRows.Count > 0)
                    {
                        DataGridViewRow dgvRow = dgvSer8500_OrgRef.SelectedRows[0];
                        BindSeries8500_OrgRefDataToControls(dgvRow);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }                     
    }
}
