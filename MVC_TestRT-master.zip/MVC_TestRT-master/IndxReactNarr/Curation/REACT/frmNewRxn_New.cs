﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using IndxReactNarrDAL;

namespace IndxReactNarr
{
    public partial class frmNewRxn_New : Form
    {
        public frmNewRxn_New()
        {
            InitializeComponent();
        }

        #region Property Procedures
        
        public string TANID
        { get; set; }

        public int TAN_ID
        { get; set; }

        public int NewRxnID
        { get; set; }

        public int RxnNum
        { get; set; }

        public int RxnSeq
        { get; set; }

        public bool DuplicateRxn
        { get; set; }

        public string CurrentRxnNUM
        { get; set; }

        public string CurrentRxnSeq
        { get; set; }

        //public DataTable ReactionsTbl
        //{ get; set; }

        public DataTable NUM_RegNoTbl
        { get; set; }

        public DataTable RxnNum_SeqData
        { get; set; }

        public string BeforeAfter
        { get; set; }

        public int DisplayOrder
        { get; set; }

        public int RxnRowIndx
        { get; set; }

        public int SeriesNUM_ID { get; set; }
        public string SeriesType { get; set; } 
        #endregion

        private void frmNewRxn_New_Load(object sender, EventArgs e)
        {
            try
            {
                rbnNUMs.Checked = false;
                rbnSer8000.Checked = false;
                rbnSer8500.Checked = false;
                rbnSer9000.Checked = false;
                                
                //DataTable dtRxnNum_Seq = CASRxnDataAccess.Get_RxnNum_RxnSeq_On_PatentID(PatentID);
                //if (dtRxnNum_Seq != null)
                //{
                //    RxnNum_SeqData = dtRxnNum_Seq;
                //}

                txtNUM_Insert.Text = CurrentRxnNUM;
                txtSeq_Insert.Text = CurrentRxnSeq;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #region RadioButtons CheckedChanged Events

        private void Edit_NUM_9000_8500_8000Data(string seloption)
        {
            try
            {
                if (!string.IsNullOrEmpty(seloption))
                {
                    switch (seloption.ToUpper())
                    { 
                        case "NUM":
                            frmNUMs objNUMs = new frmNUMs();
                            objNUMs.TAN_NUMsTbl = NUM_RegNoTbl;
                            if (objNUMs.ShowDialog() == DialogResult.OK)
                            {
                                if (objNUMs.Sel_NUM > 0)
                                {
                                    txtRxnNum.Text = objNUMs.Sel_NUM.ToString();
                                    SeriesNUM_ID = objNUMs.Sel_Ser_NUM_ID;
                                    SeriesType = objNUMs.SeriesType;
                                }
                            }
                            break;

                        //case "9000":
                        //    frmSeries9000 obj9000 = new frmSeries9000();
                        //    obj9000.SrcGrid = "PRODUCT";
                        //    if (obj9000.ShowDialog() == DialogResult.OK)
                        //    {
                        //        if (obj9000.Sel_9000 > 0)
                        //        {
                        //            txtRxnNum.Text = obj9000.Sel_9000.ToString();
                        //        }
                        //    }
                        //    break;

                        //case "8500":
                        //    frmSeries8500 obj8500 = new frmSeries8500();
                        //    obj8500.TANID = TANID;
                        //    if (obj8500.ShowDialog() == DialogResult.OK)
                        //    {
                        //        if (obj8500.Sel_8500 > 0)
                        //        {
                        //            txtRxnNum.Text = obj8500.Sel_8500.ToString();
                        //        }
                        //    }
                        //    break;

                        //case "8000":
                        //    frmSeries8000 obj8000 = new frmSeries8000();
                        //    obj8000.TANID = TANID;
                        //    if (obj8000.ShowDialog() == DialogResult.OK)
                        //    {
                        //        if (obj8000.Sel_8000 > 0)
                        //        {
                        //            txtRxnNum.Text = obj8000.Sel_8000.ToString();
                        //        }
                        //    }
                        //    break;
                    }          
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnNUMs_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (rbnNUMs.Checked)
                {
                    Edit_NUM_9000_8500_8000Data("NUM");
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnSer9000_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (rbnSer9000.Checked)
                {
                    Edit_NUM_9000_8500_8000Data("9000");
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnSer8500_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (rbnSer8500.Checked)
                {
                    Edit_NUM_9000_8500_8000Data("8500");
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnSer8000_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (rbnSer8000.Checked)
                {
                    Edit_NUM_9000_8500_8000Data("8000");
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        private bool ValidateProduct(out string errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (!string.IsNullOrEmpty(txtRxnNum.Text.ToString().Trim()))
                {
                    int intProdNUM = 0;
                    int.TryParse(txtRxnNum.Text.ToString(), out intProdNUM);

                    if (intProdNUM > 0)
                    {
                        if (rbnSer8500.Checked && CheckForSer8000_8500ValueInNUMsTable(intProdNUM))
                        {
                            blStatus = false;
                            strErrMsg = intProdNUM + " already exist in NUMs";
                        }
                        else if (rbnSer8000.Checked && CheckForSer8000_8500ValueInNUMsTable(intProdNUM))
                        {
                            blStatus = false;
                            strErrMsg = intProdNUM + " already exist in NUMs";
                        }
                    }
                    else
                    {
                        blStatus = false;
                        strErrMsg = "NUM should be greater than Zero";
                    }
                }
                else
                {
                    blStatus = false;
                    strErrMsg = "Please enter Product";
                }      
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg;
            return blStatus;
        }

        private bool CheckForSer8000_8500ValueInNUMsTable(int val_8000_8500)
        {
            bool blStatus = false;
            try
            {
                if (val_8000_8500 > 0)
                {
                    if (NUM_RegNoTbl != null)
                    {
                        if (NUM_RegNoTbl.Rows.Count > 0)
                        {
                            DataRow[] dtRowArr = NUM_RegNoTbl.Select("nrnnum = " + val_8000_8500 + "");
                            if (dtRowArr != null)
                            {
                                if (dtRowArr.Length > 0)
                                {
                                    blStatus = true;
                                    return blStatus;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private int GetDisplayOrderOnRxnNUM_RxnSeq(int _rxnnum, int _rxnseq, out int _rowindex)
        {
            int intDispOrder = 0;
            int intRowIndx = 0;
            try
            {
                if (RxnNum_SeqData != null)
                {
                    if (RxnNum_SeqData.Rows.Count > 0)
                    {
                        for (int i = 0; i < RxnNum_SeqData.Rows.Count; i++)
                        {
                            if (Convert.ToInt32(RxnNum_SeqData.Rows[i]["RXN_NUM"].ToString()) == _rxnnum
                                && Convert.ToInt32(RxnNum_SeqData.Rows[i]["RXN_SEQ"].ToString()) == _rxnseq)
                            {
                                int.TryParse(RxnNum_SeqData.Rows[i]["DISPLAY_ORDER"].ToString(), out intDispOrder);

                                intRowIndx = i;
                                _rowindex = intRowIndx;
                                return intDispOrder;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _rowindex = intRowIndx;
            return intDispOrder;
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                string strErrMsg = "";
                if (ValidateProduct(out strErrMsg))
                {
                    if (TAN_ID > 0)
                    {                        
                        int intRxnNum_New = 0;
                        int.TryParse(txtRxnNum.Text.Trim(), out intRxnNum_New);

                        int rxnSeq_out = 0;
                        int intRxnID = 0;

                        int intRxnNUM_Insert = 0;
                        if (!string.IsNullOrEmpty(txtNUM_Insert.Text.Trim()))
                        {
                            int.TryParse(txtNUM_Insert.Text.ToString(), out intRxnNUM_Insert);
                        }
                        int intRxnSeq_Insert = 0;
                        if (!string.IsNullOrEmpty(txtSeq_Insert.Text.Trim()))
                        {
                            int.TryParse(txtSeq_Insert.Text.ToString(), out intRxnSeq_Insert);
                        }
                        int intRowIndx = 0;
                        int intDispOrder = GetDisplayOrderOnRxnNUM_RxnSeq(intRxnNUM_Insert, intRxnSeq_Insert, out intRowIndx);

                        string strBefore_After = "AFTER";
                        if (rbnBefore.Checked)
                        {
                            strBefore_After = "BEFORE";
                        }

                        //If No Reations are available
                        if (intRxnNUM_Insert == 0 && intRxnSeq_Insert == 0 && intDispOrder == 0)
                        {
                            strBefore_After = "END";
                        }
                                                
                        if (intRxnNum_New > 0)
                        {                           
                            if (!chkDupRxn.Checked)
                            {
                                intRxnID = ReactDB.InsertAndGetNewReactionID(TAN_ID, intRxnNum_New, intRxnNUM_Insert, intRxnSeq_Insert, intDispOrder, SeriesType,SeriesNUM_ID, GlobalVariables.URID);
                                if (intRxnID > 0)
                                {
                                    #region MyRegion
                                    //Code commented by Sairam on 25th June 2014, Don't delete
                                    //if (rxnSeq_out > 1)
                                    //{
                                    //    DialogResult diaRes = MessageBox.Show("Product NUM: " + intRxnNum + " Seq: " + rxnSeq_out + ". Do you want to continue?", "Add Reaction", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                    //    if (diaRes == DialogResult.Yes)
                                    //    {
                                    //        RxnNum = intRxnNum;
                                    //        RxnSeq = rxnSeq_out;
                                    //        NewRxnID = intRxnID;
                                    //        BeforeAfter = strBefore_After;
                                    //        DisplayOrder = intDispOrder;
                                    //        RxnRowIndx = intRowIndx;

                                    //        DialogResult = DialogResult.OK;
                                    //        this.Close();
                                    //    }
                                    //    else//If not Delete the newly created Reaction
                                    //    {
                                    //        CASRxnDataAccess.DeleteReaction(intRxnID, TAN_ID, intRxnNum, rxnSeq_out);
                                    //    }
                                    //}
                                    //else
                                    //{ 
                                    #endregion

                                    RxnNum = intRxnNum_New;
                                    RxnSeq = rxnSeq_out == 0 ? 1 : rxnSeq_out;
                                    NewRxnID = intRxnID;
                                    BeforeAfter = strBefore_After;
                                    DisplayOrder = intDispOrder;
                                    RxnRowIndx = intRowIndx;

                                    DialogResult = DialogResult.OK;
                                    this.Close();
                                    // }
                                }
                                else
                                {
                                    MessageBox.Show("Duplicate Reaction", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                            }
                            else
                            {
                                int intRxnNum_old = Convert.ToInt32(txtNUM_Dup.Text);
                                int intRxnSeq_old = Convert.ToInt32(txtSeq_Dup.Text);

                                int intTemp = 0;
                                if (rxnSeq_out == 0)
                                {
                                    intTemp = rxnSeq_out + 1;
                                }
                                else
                                {
                                    intTemp = rxnSeq_out;
                                }

                                string strMessage = "Product NUM: " + intRxnNum_New + " Seq: " + intTemp + ".\r\nDo you want to duplicate with NUM: " + intRxnNum_old + " Seq: " + intRxnSeq_old + "?";
                                DialogResult diaRes = MessageBox.Show(strMessage, GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                if (diaRes == DialogResult.Yes)
                                {
                                    intRxnID = 0;// ReactDB.DuplicateReactionData(TAN_ID, intRxnNum_old, intRxnNum_New, 1, intDispOrder, strBefore_After, GlobalVariables.URID, out rxnSeq_out);
                                    if (intRxnID > 0)
                                    {
                                        RxnNum = intRxnNum_New;
                                        RxnSeq = rxnSeq_out;
                                        NewRxnID = intRxnID;
                                        BeforeAfter = strBefore_After;
                                        DisplayOrder = intDispOrder;
                                        RxnRowIndx = intRowIndx;
                                        DuplicateRxn = true;

                                        DialogResult = DialogResult.OK;
                                        this.Close();
                                    }
                                    else
                                    {
                                        MessageBox.Show("Error in duplicating Reaction", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void chkDupRxn_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                txtNUM_Dup.Text = "";
                txtSeq_Dup.Text = "";

                if (chkDupRxn.Checked)
                {                    
                    grpDupRxn.Enabled = true;
                }
                else
                {                   
                    grpDupRxn.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtNUM_Insert_Click(object sender, EventArgs e)
        {
            try
            {
                frmNUM_SEQ objNUMSeq = new frmNUM_SEQ();
                objNUMSeq.Num_Seq_Data = RxnNum_SeqData;
                if (objNUMSeq.ShowDialog() == DialogResult.OK)
                {
                    txtNUM_Insert.Text = objNUMSeq.RxnNUM_Sel;
                    txtSeq_Insert.Text = objNUMSeq.RxnSeq_Sel;
                    txtNUM_Insert.Tag = objNUMSeq.RxnID_Sel;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtNUM_Dup_Click(object sender, EventArgs e)
        {
            try
            {
                frmNUM_SEQ objNUMSeq = new frmNUM_SEQ();
                objNUMSeq.Num_Seq_Data = RxnNum_SeqData;
                if (objNUMSeq.ShowDialog() == DialogResult.OK)
                {
                    txtNUM_Dup.Text = objNUMSeq.RxnNUM_Sel;
                    txtSeq_Dup.Text = objNUMSeq.RxnSeq_Sel;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                txtRxnNum.Text = "";

                rbnNUMs.Checked = false;
                rbnSer8000.Checked = false;
                rbnSer8500.Checked = false;
                rbnSer9000.Checked = false;

                rbnAfter.Checked = true;

                txtNUM_Insert.Text = CurrentRxnNUM;
                txtSeq_Insert.Text = CurrentRxnSeq;

                chkDupRxn.Checked = false;
                txtNUM_Dup.Text = "";
                txtSeq_Dup.Text = "";
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       
    }
}
