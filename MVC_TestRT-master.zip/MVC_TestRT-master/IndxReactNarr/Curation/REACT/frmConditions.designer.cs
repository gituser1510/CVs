﻿namespace IndxReactNarr
{
    partial class frmConditions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.grpTime = new System.Windows.Forms.GroupBox();
            this.cmbTime_InExact = new System.Windows.Forms.ComboBox();
            this.rbnTime_InExact = new System.Windows.Forms.RadioButton();
            this.rbnEqual_Time = new System.Windows.Forms.RadioButton();
            this.txtCustTime = new System.Windows.Forms.TextBox();
            this.rbnCustTime = new System.Windows.Forms.RadioButton();
            this.cmbTime = new System.Windows.Forms.ComboBox();
            this.cmbTime_Range = new System.Windows.Forms.ComboBox();
            this.txtTime_To = new System.Windows.Forms.TextBox();
            this.lblTime_range = new System.Windows.Forms.Label();
            this.txtTime_From = new System.Windows.Forms.TextBox();
            this.rbnTime_Range = new System.Windows.Forms.RadioButton();
            this.rbnTime = new System.Windows.Forms.RadioButton();
            this.rbnTime_None = new System.Windows.Forms.RadioButton();
            this.txtTime = new System.Windows.Forms.TextBox();
            this.rbnTime_OvrN = new System.Windows.Forms.RadioButton();
            this.grpPH = new System.Windows.Forms.GroupBox();
            this.rbnEqual_pH = new System.Windows.Forms.RadioButton();
            this.txtCustPH = new System.Windows.Forms.TextBox();
            this.rbnCustPH = new System.Windows.Forms.RadioButton();
            this.txtPH_To = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtPH_From = new System.Windows.Forms.TextBox();
            this.rbnPH_Range = new System.Windows.Forms.RadioButton();
            this.rbnPH = new System.Windows.Forms.RadioButton();
            this.rbnPH_None = new System.Windows.Forms.RadioButton();
            this.rbnpH_Nutral = new System.Windows.Forms.RadioButton();
            this.rbnpH_Basic = new System.Windows.Forms.RadioButton();
            this.txtPH = new System.Windows.Forms.TextBox();
            this.rbnpH_Acid = new System.Windows.Forms.RadioButton();
            this.grpPressure = new System.Windows.Forms.GroupBox();
            this.btnReset = new System.Windows.Forms.Button();
            this.rbnEqual_Pres = new System.Windows.Forms.RadioButton();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtCustPres = new System.Windows.Forms.TextBox();
            this.cmbPressure = new System.Windows.Forms.ComboBox();
            this.cmbPres_Direct = new System.Windows.Forms.ComboBox();
            this.txtPres_D_To = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtPres_D_From = new System.Windows.Forms.TextBox();
            this.rbnPres_Direct = new System.Windows.Forms.RadioButton();
            this.rbnPressure = new System.Windows.Forms.RadioButton();
            this.rbnPres_None = new System.Windows.Forms.RadioButton();
            this.cmbPres_Range = new System.Windows.Forms.ComboBox();
            this.txtPres_To = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPres_From = new System.Windows.Forms.TextBox();
            this.rbnPres_Range = new System.Windows.Forms.RadioButton();
            this.txtPressure = new System.Windows.Forms.TextBox();
            this.rbnCustPres = new System.Windows.Forms.RadioButton();
            this.grpTemprture = new System.Windows.Forms.GroupBox();
            this.cmbTemp_X_Ref = new System.Windows.Forms.ComboBox();
            this.cmbTemp_Ref_X = new System.Windows.Forms.ComboBox();
            this.cmbTemp_X_RTemp = new System.Windows.Forms.ComboBox();
            this.cmbTemp_RTemp_X = new System.Windows.Forms.ComboBox();
            this.cmbTemp_PM = new System.Windows.Forms.ComboBox();
            this.txtTemp_PM_To = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTemp_PM_From = new System.Windows.Forms.TextBox();
            this.rbnTemp_Plus_Minus = new System.Windows.Forms.RadioButton();
            this.cmbTemp_Range = new System.Windows.Forms.ComboBox();
            this.cmbTemp_Direct = new System.Windows.Forms.ComboBox();
            this.cmbTemp = new System.Windows.Forms.ComboBox();
            this.rbnLtn_RTemp = new System.Windows.Forms.RadioButton();
            this.rbnGrt_RTemp = new System.Windows.Forms.RadioButton();
            this.rbnTemp_None = new System.Windows.Forms.RadioButton();
            this.txtCustTemp = new System.Windows.Forms.TextBox();
            this.rbnCustomTemp = new System.Windows.Forms.RadioButton();
            this.txtTemp = new System.Windows.Forms.TextBox();
            this.rbnTemp = new System.Windows.Forms.RadioButton();
            this.txtRange_To = new System.Windows.Forms.TextBox();
            this.rbnRoomTemp = new System.Windows.Forms.RadioButton();
            this.rbnEqual_Temp = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.txtRange_From = new System.Windows.Forms.TextBox();
            this.rbnTemp_Range = new System.Windows.Forms.RadioButton();
            this.txtDirect_To = new System.Windows.Forms.TextBox();
            this.lblDirect = new System.Windows.Forms.Label();
            this.txtDirect_From = new System.Windows.Forms.TextBox();
            this.rbnDirectnal = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.txtX_Reflux = new System.Windows.Forms.TextBox();
            this.rbnX_Reflux = new System.Windows.Forms.RadioButton();
            this.txtReflux_X = new System.Windows.Forms.TextBox();
            this.rbnReflux_X = new System.Windows.Forms.RadioButton();
            this.lblX_RTemp = new System.Windows.Forms.Label();
            this.txtX_RTemp = new System.Windows.Forms.TextBox();
            this.rbnX_RTemp = new System.Windows.Forms.RadioButton();
            this.txtRTemp_X = new System.Windows.Forms.TextBox();
            this.rbnRTemp_X = new System.Windows.Forms.RadioButton();
            this.rbnReflx_RTemp = new System.Windows.Forms.RadioButton();
            this.rbnRTemp_Reflx = new System.Windows.Forms.RadioButton();
            this.rbnHeated = new System.Windows.Forms.RadioButton();
            this.rbnReflux = new System.Windows.Forms.RadioButton();
            this.rbnCool = new System.Windows.Forms.RadioButton();
            this.pnlGrid = new System.Windows.Forms.Panel();
            this.dgvConds = new System.Windows.Forms.DataGridView();
            this.colTemp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colpH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPressure = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTemp_Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPres_Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colpH_Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTime_Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdit = new System.Windows.Forms.DataGridViewLinkColumn();
            this.colDelete = new System.Windows.Forms.DataGridViewLinkColumn();
            this.lblStageName = new System.Windows.Forms.Label();
            this.pnlPrevStg = new System.Windows.Forms.Panel();
            this.lblPrevStage = new System.Windows.Forms.Label();
            this.dgvPrevConds = new System.Windows.Forms.DataGridView();
            this.colTemp_PrevStg = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTime_PrevStg = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPH_PrevStg = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPressure_PrevStg = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblPrevStg = new System.Windows.Forms.Label();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.pnlMain.SuspendLayout();
            this.grpTime.SuspendLayout();
            this.grpPH.SuspendLayout();
            this.grpPressure.SuspendLayout();
            this.grpTemprture.SuspendLayout();
            this.pnlGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvConds)).BeginInit();
            this.pnlPrevStg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrevConds)).BeginInit();
            this.pnlBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.grpTime);
            this.pnlMain.Controls.Add(this.grpPH);
            this.pnlMain.Controls.Add(this.grpPressure);
            this.pnlMain.Controls.Add(this.grpTemprture);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(816, 395);
            this.pnlMain.TabIndex = 0;
            // 
            // grpTime
            // 
            this.grpTime.Controls.Add(this.cmbTime_InExact);
            this.grpTime.Controls.Add(this.rbnTime_InExact);
            this.grpTime.Controls.Add(this.rbnEqual_Time);
            this.grpTime.Controls.Add(this.txtCustTime);
            this.grpTime.Controls.Add(this.rbnCustTime);
            this.grpTime.Controls.Add(this.cmbTime);
            this.grpTime.Controls.Add(this.cmbTime_Range);
            this.grpTime.Controls.Add(this.txtTime_To);
            this.grpTime.Controls.Add(this.lblTime_range);
            this.grpTime.Controls.Add(this.txtTime_From);
            this.grpTime.Controls.Add(this.rbnTime_Range);
            this.grpTime.Controls.Add(this.rbnTime);
            this.grpTime.Controls.Add(this.rbnTime_None);
            this.grpTime.Controls.Add(this.txtTime);
            this.grpTime.Controls.Add(this.rbnTime_OvrN);
            this.grpTime.Enabled = false;
            this.grpTime.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpTime.ForeColor = System.Drawing.Color.Red;
            this.grpTime.Location = new System.Drawing.Point(3, 173);
            this.grpTime.Name = "grpTime";
            this.grpTime.Size = new System.Drawing.Size(811, 73);
            this.grpTime.TabIndex = 4;
            this.grpTime.TabStop = false;
            this.grpTime.Text = "Time";
            // 
            // cmbTime_InExact
            // 
            this.cmbTime_InExact.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTime_InExact.Enabled = false;
            this.cmbTime_InExact.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTime_InExact.ForeColor = System.Drawing.Color.Black;
            this.cmbTime_InExact.FormattingEnabled = true;
            this.cmbTime_InExact.Items.AddRange(new object[] {
            "few minutes",
            "few hours",
            "few days",
            "couple of minutes",
            "couple of hours",
            "couple of days",
            "over the weekend"});
            this.cmbTime_InExact.Location = new System.Drawing.Point(325, 13);
            this.cmbTime_InExact.Name = "cmbTime_InExact";
            this.cmbTime_InExact.Size = new System.Drawing.Size(149, 25);
            this.cmbTime_InExact.TabIndex = 39;
            // 
            // rbnTime_InExact
            // 
            this.rbnTime_InExact.AutoSize = true;
            this.rbnTime_InExact.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnTime_InExact.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnTime_InExact.Location = new System.Drawing.Point(213, 15);
            this.rbnTime_InExact.Name = "rbnTime_InExact";
            this.rbnTime_InExact.Size = new System.Drawing.Size(105, 21);
            this.rbnTime_InExact.TabIndex = 38;
            this.rbnTime_InExact.TabStop = true;
            this.rbnTime_InExact.Text = "InExact Time";
            this.rbnTime_InExact.UseVisualStyleBackColor = true;
            this.rbnTime_InExact.CheckedChanged += new System.EventHandler(this.rbnTime_InExact_CheckedChanged);
            // 
            // rbnEqual_Time
            // 
            this.rbnEqual_Time.AutoSize = true;
            this.rbnEqual_Time.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnEqual_Time.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnEqual_Time.Location = new System.Drawing.Point(484, 17);
            this.rbnEqual_Time.Name = "rbnEqual_Time";
            this.rbnEqual_Time.Size = new System.Drawing.Size(34, 21);
            this.rbnEqual_Time.TabIndex = 40;
            this.rbnEqual_Time.TabStop = true;
            this.rbnEqual_Time.Text = "=";
            this.rbnEqual_Time.UseVisualStyleBackColor = true;
            this.rbnEqual_Time.CheckedChanged += new System.EventHandler(this.rbnEqual_Time_CheckedChanged);
            // 
            // txtCustTime
            // 
            this.txtCustTime.Enabled = false;
            this.txtCustTime.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustTime.Location = new System.Drawing.Point(630, 15);
            this.txtCustTime.Name = "txtCustTime";
            this.txtCustTime.Size = new System.Drawing.Size(88, 25);
            this.txtCustTime.TabIndex = 42;
            // 
            // rbnCustTime
            // 
            this.rbnCustTime.AutoSize = true;
            this.rbnCustTime.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnCustTime.Enabled = false;
            this.rbnCustTime.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnCustTime.Location = new System.Drawing.Point(556, 17);
            this.rbnCustTime.Name = "rbnCustTime";
            this.rbnCustTime.Size = new System.Drawing.Size(71, 21);
            this.rbnCustTime.TabIndex = 41;
            this.rbnCustTime.TabStop = true;
            this.rbnCustTime.Text = "Custom";
            this.rbnCustTime.UseVisualStyleBackColor = true;
            this.rbnCustTime.CheckedChanged += new System.EventHandler(this.rbnCustTime_CheckedChanged);
            // 
            // cmbTime
            // 
            this.cmbTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTime.Enabled = false;
            this.cmbTime.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTime.ForeColor = System.Drawing.Color.Black;
            this.cmbTime.FormattingEnabled = true;
            this.cmbTime.Items.AddRange(new object[] {
            "h",
            "m",
            "s",
            "d",
            "w",
            "mo",
            "ms"});
            this.cmbTime.Location = new System.Drawing.Point(123, 15);
            this.cmbTime.Name = "cmbTime";
            this.cmbTime.Size = new System.Drawing.Size(44, 25);
            this.cmbTime.TabIndex = 37;
            // 
            // cmbTime_Range
            // 
            this.cmbTime_Range.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTime_Range.Enabled = false;
            this.cmbTime_Range.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTime_Range.ForeColor = System.Drawing.Color.Black;
            this.cmbTime_Range.FormattingEnabled = true;
            this.cmbTime_Range.Items.AddRange(new object[] {
            "h",
            "m",
            "s",
            "d",
            "w",
            "mo",
            "ms"});
            this.cmbTime_Range.Location = new System.Drawing.Point(431, 43);
            this.cmbTime_Range.Name = "cmbTime_Range";
            this.cmbTime_Range.Size = new System.Drawing.Size(43, 25);
            this.cmbTime_Range.TabIndex = 48;
            // 
            // txtTime_To
            // 
            this.txtTime_To.Enabled = false;
            this.txtTime_To.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTime_To.Location = new System.Drawing.Point(385, 43);
            this.txtTime_To.Name = "txtTime_To";
            this.txtTime_To.Size = new System.Drawing.Size(43, 25);
            this.txtTime_To.TabIndex = 47;
            this.txtTime_To.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTime_Range_KeyPress);
            // 
            // lblTime_range
            // 
            this.lblTime_range.AutoSize = true;
            this.lblTime_range.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime_range.Location = new System.Drawing.Point(370, 47);
            this.lblTime_range.Name = "lblTime_range";
            this.lblTime_range.Size = new System.Drawing.Size(13, 18);
            this.lblTime_range.TabIndex = 34;
            this.lblTime_range.Text = "-";
            // 
            // txtTime_From
            // 
            this.txtTime_From.Enabled = false;
            this.txtTime_From.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTime_From.Location = new System.Drawing.Point(325, 43);
            this.txtTime_From.Name = "txtTime_From";
            this.txtTime_From.Size = new System.Drawing.Size(42, 25);
            this.txtTime_From.TabIndex = 46;
            this.txtTime_From.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTime_Range_KeyPress);
            // 
            // rbnTime_Range
            // 
            this.rbnTime_Range.AutoSize = true;
            this.rbnTime_Range.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnTime_Range.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnTime_Range.Location = new System.Drawing.Point(213, 45);
            this.rbnTime_Range.Name = "rbnTime_Range";
            this.rbnTime_Range.Size = new System.Drawing.Size(91, 21);
            this.rbnTime_Range.TabIndex = 45;
            this.rbnTime_Range.TabStop = true;
            this.rbnTime_Range.Text = "Range ( - )";
            this.rbnTime_Range.UseVisualStyleBackColor = true;
            this.rbnTime_Range.CheckedChanged += new System.EventHandler(this.rbnTime_Range_CheckedChanged);
            // 
            // rbnTime
            // 
            this.rbnTime.AutoSize = true;
            this.rbnTime.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnTime.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnTime.Location = new System.Drawing.Point(6, 17);
            this.rbnTime.Name = "rbnTime";
            this.rbnTime.Size = new System.Drawing.Size(55, 21);
            this.rbnTime.TabIndex = 35;
            this.rbnTime.TabStop = true;
            this.rbnTime.Text = "Time";
            this.rbnTime.UseVisualStyleBackColor = true;
            this.rbnTime.CheckedChanged += new System.EventHandler(this.rbnTime_CheckedChanged);
            // 
            // rbnTime_None
            // 
            this.rbnTime_None.AutoSize = true;
            this.rbnTime_None.Checked = true;
            this.rbnTime_None.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnTime_None.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnTime_None.Location = new System.Drawing.Point(734, 16);
            this.rbnTime_None.Name = "rbnTime_None";
            this.rbnTime_None.Size = new System.Drawing.Size(58, 21);
            this.rbnTime_None.TabIndex = 43;
            this.rbnTime_None.TabStop = true;
            this.rbnTime_None.Text = "None";
            this.rbnTime_None.UseVisualStyleBackColor = true;
            this.rbnTime_None.CheckedChanged += new System.EventHandler(this.rbnTime_None_CheckedChanged);
            // 
            // txtTime
            // 
            this.txtTime.Enabled = false;
            this.txtTime.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTime.Location = new System.Drawing.Point(69, 15);
            this.txtTime.Name = "txtTime";
            this.txtTime.Size = new System.Drawing.Size(51, 25);
            this.txtTime.TabIndex = 36;
            this.txtTime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTime_KeyPress);
            // 
            // rbnTime_OvrN
            // 
            this.rbnTime_OvrN.AutoSize = true;
            this.rbnTime_OvrN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnTime_OvrN.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnTime_OvrN.Location = new System.Drawing.Point(6, 45);
            this.rbnTime_OvrN.Name = "rbnTime_OvrN";
            this.rbnTime_OvrN.Size = new System.Drawing.Size(109, 21);
            this.rbnTime_OvrN.TabIndex = 44;
            this.rbnTime_OvrN.TabStop = true;
            this.rbnTime_OvrN.Text = "Over night (o)";
            this.rbnTime_OvrN.UseVisualStyleBackColor = false;
            this.rbnTime_OvrN.CheckedChanged += new System.EventHandler(this.rbnTime_OvrN_CheckedChanged);
            // 
            // grpPH
            // 
            this.grpPH.Controls.Add(this.rbnEqual_pH);
            this.grpPH.Controls.Add(this.txtCustPH);
            this.grpPH.Controls.Add(this.rbnCustPH);
            this.grpPH.Controls.Add(this.txtPH_To);
            this.grpPH.Controls.Add(this.label6);
            this.grpPH.Controls.Add(this.txtPH_From);
            this.grpPH.Controls.Add(this.rbnPH_Range);
            this.grpPH.Controls.Add(this.rbnPH);
            this.grpPH.Controls.Add(this.rbnPH_None);
            this.grpPH.Controls.Add(this.rbnpH_Nutral);
            this.grpPH.Controls.Add(this.rbnpH_Basic);
            this.grpPH.Controls.Add(this.txtPH);
            this.grpPH.Controls.Add(this.rbnpH_Acid);
            this.grpPH.Enabled = false;
            this.grpPH.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpPH.ForeColor = System.Drawing.Color.Blue;
            this.grpPH.Location = new System.Drawing.Point(3, 248);
            this.grpPH.Name = "grpPH";
            this.grpPH.Size = new System.Drawing.Size(811, 68);
            this.grpPH.TabIndex = 3;
            this.grpPH.TabStop = false;
            this.grpPH.Text = "pH";
            // 
            // rbnEqual_pH
            // 
            this.rbnEqual_pH.AutoSize = true;
            this.rbnEqual_pH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnEqual_pH.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnEqual_pH.Location = new System.Drawing.Point(484, 15);
            this.rbnEqual_pH.Name = "rbnEqual_pH";
            this.rbnEqual_pH.Size = new System.Drawing.Size(34, 21);
            this.rbnEqual_pH.TabIndex = 54;
            this.rbnEqual_pH.TabStop = true;
            this.rbnEqual_pH.Text = "=";
            this.rbnEqual_pH.UseVisualStyleBackColor = true;
            this.rbnEqual_pH.CheckedChanged += new System.EventHandler(this.rbnEqual_pH_CheckedChanged);
            // 
            // txtCustPH
            // 
            this.txtCustPH.Enabled = false;
            this.txtCustPH.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustPH.Location = new System.Drawing.Point(630, 14);
            this.txtCustPH.Name = "txtCustPH";
            this.txtCustPH.Size = new System.Drawing.Size(88, 25);
            this.txtCustPH.TabIndex = 56;
            // 
            // rbnCustPH
            // 
            this.rbnCustPH.AutoSize = true;
            this.rbnCustPH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnCustPH.Enabled = false;
            this.rbnCustPH.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnCustPH.Location = new System.Drawing.Point(556, 16);
            this.rbnCustPH.Name = "rbnCustPH";
            this.rbnCustPH.Size = new System.Drawing.Size(71, 21);
            this.rbnCustPH.TabIndex = 55;
            this.rbnCustPH.TabStop = true;
            this.rbnCustPH.Text = "Custom";
            this.rbnCustPH.UseVisualStyleBackColor = true;
            this.rbnCustPH.CheckedChanged += new System.EventHandler(this.rbnCustPH_CheckedChanged);
            // 
            // txtPH_To
            // 
            this.txtPH_To.Enabled = false;
            this.txtPH_To.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPH_To.Location = new System.Drawing.Point(386, 39);
            this.txtPH_To.Name = "txtPH_To";
            this.txtPH_To.Size = new System.Drawing.Size(42, 25);
            this.txtPH_To.TabIndex = 60;
            this.txtPH_To.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPH_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(370, 43);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(13, 18);
            this.label6.TabIndex = 38;
            this.label6.Text = "-";
            // 
            // txtPH_From
            // 
            this.txtPH_From.Enabled = false;
            this.txtPH_From.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPH_From.Location = new System.Drawing.Point(325, 39);
            this.txtPH_From.Name = "txtPH_From";
            this.txtPH_From.Size = new System.Drawing.Size(42, 25);
            this.txtPH_From.TabIndex = 59;
            this.txtPH_From.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPH_KeyPress);
            // 
            // rbnPH_Range
            // 
            this.rbnPH_Range.AutoSize = true;
            this.rbnPH_Range.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnPH_Range.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnPH_Range.Location = new System.Drawing.Point(213, 42);
            this.rbnPH_Range.Name = "rbnPH_Range";
            this.rbnPH_Range.Size = new System.Drawing.Size(91, 21);
            this.rbnPH_Range.TabIndex = 58;
            this.rbnPH_Range.TabStop = true;
            this.rbnPH_Range.Text = "Range ( - )";
            this.rbnPH_Range.UseVisualStyleBackColor = true;
            this.rbnPH_Range.CheckedChanged += new System.EventHandler(this.rbnPH_Range_CheckedChanged);
            // 
            // rbnPH
            // 
            this.rbnPH.AutoSize = true;
            this.rbnPH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnPH.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnPH.Location = new System.Drawing.Point(6, 16);
            this.rbnPH.Name = "rbnPH";
            this.rbnPH.Size = new System.Drawing.Size(44, 21);
            this.rbnPH.TabIndex = 49;
            this.rbnPH.TabStop = true;
            this.rbnPH.Text = "pH";
            this.rbnPH.UseVisualStyleBackColor = false;
            this.rbnPH.CheckedChanged += new System.EventHandler(this.rbnPH_CheckedChanged);
            // 
            // rbnPH_None
            // 
            this.rbnPH_None.AutoSize = true;
            this.rbnPH_None.Checked = true;
            this.rbnPH_None.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnPH_None.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnPH_None.Location = new System.Drawing.Point(734, 14);
            this.rbnPH_None.Name = "rbnPH_None";
            this.rbnPH_None.Size = new System.Drawing.Size(58, 21);
            this.rbnPH_None.TabIndex = 57;
            this.rbnPH_None.TabStop = true;
            this.rbnPH_None.Text = "None";
            this.rbnPH_None.UseVisualStyleBackColor = true;
            this.rbnPH_None.CheckedChanged += new System.EventHandler(this.rbnPH_None_CheckedChanged);
            // 
            // rbnpH_Nutral
            // 
            this.rbnpH_Nutral.AutoSize = true;
            this.rbnpH_Nutral.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnpH_Nutral.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnpH_Nutral.Location = new System.Drawing.Point(384, 14);
            this.rbnpH_Nutral.Name = "rbnpH_Nutral";
            this.rbnpH_Nutral.Size = new System.Drawing.Size(91, 21);
            this.rbnpH_Nutral.TabIndex = 53;
            this.rbnpH_Nutral.TabStop = true;
            this.rbnpH_Nutral.Text = "Neutral (n)";
            this.rbnpH_Nutral.UseVisualStyleBackColor = true;
            this.rbnpH_Nutral.CheckedChanged += new System.EventHandler(this.rbnpH_Nutral_CheckedChanged);
            // 
            // rbnpH_Basic
            // 
            this.rbnpH_Basic.AutoSize = true;
            this.rbnpH_Basic.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnpH_Basic.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnpH_Basic.Location = new System.Drawing.Point(299, 14);
            this.rbnpH_Basic.Name = "rbnpH_Basic";
            this.rbnpH_Basic.Size = new System.Drawing.Size(77, 21);
            this.rbnpH_Basic.TabIndex = 52;
            this.rbnpH_Basic.TabStop = true;
            this.rbnpH_Basic.Text = "Base (b)";
            this.rbnpH_Basic.UseVisualStyleBackColor = true;
            this.rbnpH_Basic.CheckedChanged += new System.EventHandler(this.rbnpH_Basic_CheckedChanged);
            // 
            // txtPH
            // 
            this.txtPH.Enabled = false;
            this.txtPH.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPH.Location = new System.Drawing.Point(69, 14);
            this.txtPH.Name = "txtPH";
            this.txtPH.Size = new System.Drawing.Size(51, 25);
            this.txtPH.TabIndex = 50;
            this.txtPH.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPH_KeyPress);
            // 
            // rbnpH_Acid
            // 
            this.rbnpH_Acid.AutoSize = true;
            this.rbnpH_Acid.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnpH_Acid.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnpH_Acid.Location = new System.Drawing.Point(213, 14);
            this.rbnpH_Acid.Name = "rbnpH_Acid";
            this.rbnpH_Acid.Size = new System.Drawing.Size(75, 21);
            this.rbnpH_Acid.TabIndex = 51;
            this.rbnpH_Acid.TabStop = true;
            this.rbnpH_Acid.Text = "Acid (a)";
            this.rbnpH_Acid.UseVisualStyleBackColor = true;
            this.rbnpH_Acid.CheckedChanged += new System.EventHandler(this.rbnpH_Acid_CheckedChanged);
            // 
            // grpPressure
            // 
            this.grpPressure.Controls.Add(this.btnReset);
            this.grpPressure.Controls.Add(this.rbnEqual_Pres);
            this.grpPressure.Controls.Add(this.btnAdd);
            this.grpPressure.Controls.Add(this.txtCustPres);
            this.grpPressure.Controls.Add(this.cmbPressure);
            this.grpPressure.Controls.Add(this.cmbPres_Direct);
            this.grpPressure.Controls.Add(this.txtPres_D_To);
            this.grpPressure.Controls.Add(this.label7);
            this.grpPressure.Controls.Add(this.txtPres_D_From);
            this.grpPressure.Controls.Add(this.rbnPres_Direct);
            this.grpPressure.Controls.Add(this.rbnPressure);
            this.grpPressure.Controls.Add(this.rbnPres_None);
            this.grpPressure.Controls.Add(this.cmbPres_Range);
            this.grpPressure.Controls.Add(this.txtPres_To);
            this.grpPressure.Controls.Add(this.label5);
            this.grpPressure.Controls.Add(this.txtPres_From);
            this.grpPressure.Controls.Add(this.rbnPres_Range);
            this.grpPressure.Controls.Add(this.txtPressure);
            this.grpPressure.Controls.Add(this.rbnCustPres);
            this.grpPressure.Enabled = false;
            this.grpPressure.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpPressure.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.grpPressure.Location = new System.Drawing.Point(3, 318);
            this.grpPressure.Name = "grpPressure";
            this.grpPressure.Size = new System.Drawing.Size(812, 75);
            this.grpPressure.TabIndex = 2;
            this.grpPressure.TabStop = false;
            this.grpPressure.Text = "Pressure";
            // 
            // btnReset
            // 
            this.btnReset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReset.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.ForeColor = System.Drawing.Color.Black;
            this.btnReset.Location = new System.Drawing.Point(666, 44);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(65, 28);
            this.btnReset.TabIndex = 77;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // rbnEqual_Pres
            // 
            this.rbnEqual_Pres.AutoSize = true;
            this.rbnEqual_Pres.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnEqual_Pres.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnEqual_Pres.Location = new System.Drawing.Point(484, 15);
            this.rbnEqual_Pres.Name = "rbnEqual_Pres";
            this.rbnEqual_Pres.Size = new System.Drawing.Size(34, 21);
            this.rbnEqual_Pres.TabIndex = 68;
            this.rbnEqual_Pres.TabStop = true;
            this.rbnEqual_Pres.Text = "=";
            this.rbnEqual_Pres.UseVisualStyleBackColor = true;
            this.rbnEqual_Pres.CheckedChanged += new System.EventHandler(this.rbnEqual_Pres_CheckedChanged);
            // 
            // btnAdd
            // 
            this.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdd.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.Color.Black;
            this.btnAdd.Location = new System.Drawing.Point(735, 44);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(71, 28);
            this.btnAdd.TabIndex = 76;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtCustPres
            // 
            this.txtCustPres.Enabled = false;
            this.txtCustPres.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustPres.Location = new System.Drawing.Point(630, 14);
            this.txtCustPres.Name = "txtCustPres";
            this.txtCustPres.Size = new System.Drawing.Size(88, 25);
            this.txtCustPres.TabIndex = 70;
            // 
            // cmbPressure
            // 
            this.cmbPressure.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPressure.Enabled = false;
            this.cmbPressure.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPressure.ForeColor = System.Drawing.Color.Black;
            this.cmbPressure.FormattingEnabled = true;
            this.cmbPressure.Items.AddRange(new object[] {
            "a",
            "b",
            "kb",
            "mb",
            "j",
            "m",
            "p",
            "kp",
            "mp",
            "gp",
            "hp",
            "s",
            "t",
            "kc"});
            this.cmbPressure.Location = new System.Drawing.Point(139, 14);
            this.cmbPressure.Name = "cmbPressure";
            this.cmbPressure.Size = new System.Drawing.Size(44, 25);
            this.cmbPressure.TabIndex = 63;
            // 
            // cmbPres_Direct
            // 
            this.cmbPres_Direct.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPres_Direct.Enabled = false;
            this.cmbPres_Direct.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPres_Direct.ForeColor = System.Drawing.Color.Black;
            this.cmbPres_Direct.FormattingEnabled = true;
            this.cmbPres_Direct.Items.AddRange(new object[] {
            "a",
            "b",
            "kb",
            "mb",
            "j",
            "m",
            "p",
            "kp",
            "mp",
            "gp",
            "hp",
            "s",
            "t",
            "kc"});
            this.cmbPres_Direct.Location = new System.Drawing.Point(431, 15);
            this.cmbPres_Direct.Name = "cmbPres_Direct";
            this.cmbPres_Direct.Size = new System.Drawing.Size(44, 25);
            this.cmbPres_Direct.TabIndex = 67;
            // 
            // txtPres_D_To
            // 
            this.txtPres_D_To.Enabled = false;
            this.txtPres_D_To.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPres_D_To.Location = new System.Drawing.Point(386, 15);
            this.txtPres_D_To.Name = "txtPres_D_To";
            this.txtPres_D_To.Size = new System.Drawing.Size(42, 25);
            this.txtPres_D_To.TabIndex = 66;
            this.txtPres_D_To.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPressure_Range_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(371, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(13, 17);
            this.label7.TabIndex = 46;
            this.label7.Text = "]";
            // 
            // txtPres_D_From
            // 
            this.txtPres_D_From.Enabled = false;
            this.txtPres_D_From.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPres_D_From.Location = new System.Drawing.Point(326, 15);
            this.txtPres_D_From.Name = "txtPres_D_From";
            this.txtPres_D_From.Size = new System.Drawing.Size(42, 25);
            this.txtPres_D_From.TabIndex = 65;
            this.txtPres_D_From.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPressure_Range_KeyPress);
            // 
            // rbnPres_Direct
            // 
            this.rbnPres_Direct.AutoSize = true;
            this.rbnPres_Direct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnPres_Direct.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnPres_Direct.Location = new System.Drawing.Point(213, 17);
            this.rbnPres_Direct.Name = "rbnPres_Direct";
            this.rbnPres_Direct.Size = new System.Drawing.Size(117, 21);
            this.rbnPres_Direct.TabIndex = 64;
            this.rbnPres_Direct.TabStop = true;
            this.rbnPres_Direct.Text = "Directional ( ] )";
            this.rbnPres_Direct.UseVisualStyleBackColor = true;
            this.rbnPres_Direct.CheckedChanged += new System.EventHandler(this.rbnPres_Direct_CheckedChanged);
            // 
            // rbnPressure
            // 
            this.rbnPressure.AutoSize = true;
            this.rbnPressure.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnPressure.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnPressure.Location = new System.Drawing.Point(6, 17);
            this.rbnPressure.Name = "rbnPressure";
            this.rbnPressure.Size = new System.Drawing.Size(78, 21);
            this.rbnPressure.TabIndex = 61;
            this.rbnPressure.TabStop = true;
            this.rbnPressure.Text = "Pressure";
            this.rbnPressure.UseVisualStyleBackColor = false;
            this.rbnPressure.CheckedChanged += new System.EventHandler(this.rbnPressure_CheckedChanged);
            // 
            // rbnPres_None
            // 
            this.rbnPres_None.AutoSize = true;
            this.rbnPres_None.Checked = true;
            this.rbnPres_None.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnPres_None.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnPres_None.Location = new System.Drawing.Point(734, 16);
            this.rbnPres_None.Name = "rbnPres_None";
            this.rbnPres_None.Size = new System.Drawing.Size(58, 21);
            this.rbnPres_None.TabIndex = 71;
            this.rbnPres_None.TabStop = true;
            this.rbnPres_None.Text = "None";
            this.rbnPres_None.UseVisualStyleBackColor = true;
            this.rbnPres_None.CheckedChanged += new System.EventHandler(this.rbnPres_None_CheckedChanged);
            // 
            // cmbPres_Range
            // 
            this.cmbPres_Range.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPres_Range.Enabled = false;
            this.cmbPres_Range.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPres_Range.ForeColor = System.Drawing.Color.Black;
            this.cmbPres_Range.FormattingEnabled = true;
            this.cmbPres_Range.Items.AddRange(new object[] {
            "a",
            "b",
            "kb",
            "mb",
            "j",
            "m",
            "p",
            "kp",
            "mp",
            "gp",
            "hp",
            "s",
            "t",
            "kc"});
            this.cmbPres_Range.Location = new System.Drawing.Point(431, 45);
            this.cmbPres_Range.Name = "cmbPres_Range";
            this.cmbPres_Range.Size = new System.Drawing.Size(44, 25);
            this.cmbPres_Range.TabIndex = 75;
            // 
            // txtPres_To
            // 
            this.txtPres_To.Enabled = false;
            this.txtPres_To.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPres_To.Location = new System.Drawing.Point(386, 45);
            this.txtPres_To.Name = "txtPres_To";
            this.txtPres_To.Size = new System.Drawing.Size(42, 25);
            this.txtPres_To.TabIndex = 74;
            this.txtPres_To.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPressure_Range_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(371, 48);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(13, 18);
            this.label5.TabIndex = 39;
            this.label5.Text = "-";
            // 
            // txtPres_From
            // 
            this.txtPres_From.Enabled = false;
            this.txtPres_From.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPres_From.Location = new System.Drawing.Point(326, 45);
            this.txtPres_From.Name = "txtPres_From";
            this.txtPres_From.Size = new System.Drawing.Size(42, 25);
            this.txtPres_From.TabIndex = 73;
            this.txtPres_From.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPressure_Range_KeyPress);
            // 
            // rbnPres_Range
            // 
            this.rbnPres_Range.AutoSize = true;
            this.rbnPres_Range.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnPres_Range.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnPres_Range.Location = new System.Drawing.Point(213, 47);
            this.rbnPres_Range.Name = "rbnPres_Range";
            this.rbnPres_Range.Size = new System.Drawing.Size(91, 21);
            this.rbnPres_Range.TabIndex = 72;
            this.rbnPres_Range.TabStop = true;
            this.rbnPres_Range.Text = "Range ( - )";
            this.rbnPres_Range.UseVisualStyleBackColor = true;
            this.rbnPres_Range.CheckedChanged += new System.EventHandler(this.rbnPres_Range_CheckedChanged);
            // 
            // txtPressure
            // 
            this.txtPressure.Enabled = false;
            this.txtPressure.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPressure.ForeColor = System.Drawing.Color.Black;
            this.txtPressure.Location = new System.Drawing.Point(84, 14);
            this.txtPressure.Name = "txtPressure";
            this.txtPressure.Size = new System.Drawing.Size(52, 25);
            this.txtPressure.TabIndex = 62;
            this.txtPressure.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPressure_KeyPress);
            // 
            // rbnCustPres
            // 
            this.rbnCustPres.AutoSize = true;
            this.rbnCustPres.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnCustPres.Enabled = false;
            this.rbnCustPres.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnCustPres.Location = new System.Drawing.Point(556, 16);
            this.rbnCustPres.Name = "rbnCustPres";
            this.rbnCustPres.Size = new System.Drawing.Size(71, 21);
            this.rbnCustPres.TabIndex = 69;
            this.rbnCustPres.TabStop = true;
            this.rbnCustPres.Text = "Custom";
            this.rbnCustPres.UseVisualStyleBackColor = true;
            this.rbnCustPres.CheckedChanged += new System.EventHandler(this.rbnCustPres_CheckedChanged);
            // 
            // grpTemprture
            // 
            this.grpTemprture.BackColor = System.Drawing.Color.Transparent;
            this.grpTemprture.Controls.Add(this.cmbTemp_X_Ref);
            this.grpTemprture.Controls.Add(this.cmbTemp_Ref_X);
            this.grpTemprture.Controls.Add(this.cmbTemp_X_RTemp);
            this.grpTemprture.Controls.Add(this.cmbTemp_RTemp_X);
            this.grpTemprture.Controls.Add(this.cmbTemp_PM);
            this.grpTemprture.Controls.Add(this.txtTemp_PM_To);
            this.grpTemprture.Controls.Add(this.label4);
            this.grpTemprture.Controls.Add(this.txtTemp_PM_From);
            this.grpTemprture.Controls.Add(this.rbnTemp_Plus_Minus);
            this.grpTemprture.Controls.Add(this.cmbTemp_Range);
            this.grpTemprture.Controls.Add(this.cmbTemp_Direct);
            this.grpTemprture.Controls.Add(this.cmbTemp);
            this.grpTemprture.Controls.Add(this.rbnLtn_RTemp);
            this.grpTemprture.Controls.Add(this.rbnGrt_RTemp);
            this.grpTemprture.Controls.Add(this.rbnTemp_None);
            this.grpTemprture.Controls.Add(this.txtCustTemp);
            this.grpTemprture.Controls.Add(this.rbnCustomTemp);
            this.grpTemprture.Controls.Add(this.txtTemp);
            this.grpTemprture.Controls.Add(this.rbnTemp);
            this.grpTemprture.Controls.Add(this.txtRange_To);
            this.grpTemprture.Controls.Add(this.rbnRoomTemp);
            this.grpTemprture.Controls.Add(this.rbnEqual_Temp);
            this.grpTemprture.Controls.Add(this.label3);
            this.grpTemprture.Controls.Add(this.txtRange_From);
            this.grpTemprture.Controls.Add(this.rbnTemp_Range);
            this.grpTemprture.Controls.Add(this.txtDirect_To);
            this.grpTemprture.Controls.Add(this.lblDirect);
            this.grpTemprture.Controls.Add(this.txtDirect_From);
            this.grpTemprture.Controls.Add(this.rbnDirectnal);
            this.grpTemprture.Controls.Add(this.label2);
            this.grpTemprture.Controls.Add(this.txtX_Reflux);
            this.grpTemprture.Controls.Add(this.rbnX_Reflux);
            this.grpTemprture.Controls.Add(this.txtReflux_X);
            this.grpTemprture.Controls.Add(this.rbnReflux_X);
            this.grpTemprture.Controls.Add(this.lblX_RTemp);
            this.grpTemprture.Controls.Add(this.txtX_RTemp);
            this.grpTemprture.Controls.Add(this.rbnX_RTemp);
            this.grpTemprture.Controls.Add(this.txtRTemp_X);
            this.grpTemprture.Controls.Add(this.rbnRTemp_X);
            this.grpTemprture.Controls.Add(this.rbnReflx_RTemp);
            this.grpTemprture.Controls.Add(this.rbnRTemp_Reflx);
            this.grpTemprture.Controls.Add(this.rbnHeated);
            this.grpTemprture.Controls.Add(this.rbnReflux);
            this.grpTemprture.Controls.Add(this.rbnCool);
            this.grpTemprture.Enabled = false;
            this.grpTemprture.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpTemprture.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.grpTemprture.Location = new System.Drawing.Point(3, 1);
            this.grpTemprture.Name = "grpTemprture";
            this.grpTemprture.Size = new System.Drawing.Size(811, 170);
            this.grpTemprture.TabIndex = 1;
            this.grpTemprture.TabStop = false;
            this.grpTemprture.Text = "Temperature";
            // 
            // cmbTemp_X_Ref
            // 
            this.cmbTemp_X_Ref.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTemp_X_Ref.Enabled = false;
            this.cmbTemp_X_Ref.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTemp_X_Ref.ForeColor = System.Drawing.Color.Black;
            this.cmbTemp_X_Ref.FormattingEnabled = true;
            this.cmbTemp_X_Ref.Items.AddRange(new object[] {
            "c",
            "f",
            "k",
            "r"});
            this.cmbTemp_X_Ref.Location = new System.Drawing.Point(715, 48);
            this.cmbTemp_X_Ref.Name = "cmbTemp_X_Ref";
            this.cmbTemp_X_Ref.Size = new System.Drawing.Size(32, 25);
            this.cmbTemp_X_Ref.TabIndex = 38;
            // 
            // cmbTemp_Ref_X
            // 
            this.cmbTemp_Ref_X.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTemp_Ref_X.Enabled = false;
            this.cmbTemp_Ref_X.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTemp_Ref_X.ForeColor = System.Drawing.Color.Black;
            this.cmbTemp_Ref_X.FormattingEnabled = true;
            this.cmbTemp_Ref_X.Items.AddRange(new object[] {
            "c",
            "f",
            "k",
            "r"});
            this.cmbTemp_Ref_X.Location = new System.Drawing.Point(607, 49);
            this.cmbTemp_Ref_X.Name = "cmbTemp_Ref_X";
            this.cmbTemp_Ref_X.Size = new System.Drawing.Size(32, 25);
            this.cmbTemp_Ref_X.TabIndex = 37;
            // 
            // cmbTemp_X_RTemp
            // 
            this.cmbTemp_X_RTemp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTemp_X_RTemp.Enabled = false;
            this.cmbTemp_X_RTemp.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTemp_X_RTemp.ForeColor = System.Drawing.Color.Black;
            this.cmbTemp_X_RTemp.FormattingEnabled = true;
            this.cmbTemp_X_RTemp.Items.AddRange(new object[] {
            "c",
            "f",
            "k",
            "r"});
            this.cmbTemp_X_RTemp.Location = new System.Drawing.Point(285, 77);
            this.cmbTemp_X_RTemp.Name = "cmbTemp_X_RTemp";
            this.cmbTemp_X_RTemp.Size = new System.Drawing.Size(32, 25);
            this.cmbTemp_X_RTemp.TabIndex = 36;
            // 
            // cmbTemp_RTemp_X
            // 
            this.cmbTemp_RTemp_X.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTemp_RTemp_X.Enabled = false;
            this.cmbTemp_RTemp_X.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTemp_RTemp_X.ForeColor = System.Drawing.Color.Black;
            this.cmbTemp_RTemp_X.FormattingEnabled = true;
            this.cmbTemp_RTemp_X.Items.AddRange(new object[] {
            "c",
            "f",
            "k",
            "r"});
            this.cmbTemp_RTemp_X.Location = new System.Drawing.Point(171, 77);
            this.cmbTemp_RTemp_X.Name = "cmbTemp_RTemp_X";
            this.cmbTemp_RTemp_X.Size = new System.Drawing.Size(32, 25);
            this.cmbTemp_RTemp_X.TabIndex = 35;
            // 
            // cmbTemp_PM
            // 
            this.cmbTemp_PM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTemp_PM.Enabled = false;
            this.cmbTemp_PM.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTemp_PM.ForeColor = System.Drawing.Color.Black;
            this.cmbTemp_PM.FormattingEnabled = true;
            this.cmbTemp_PM.Items.AddRange(new object[] {
            "c",
            "f",
            "k",
            "r"});
            this.cmbTemp_PM.Location = new System.Drawing.Point(641, 109);
            this.cmbTemp_PM.Name = "cmbTemp_PM";
            this.cmbTemp_PM.Size = new System.Drawing.Size(32, 25);
            this.cmbTemp_PM.TabIndex = 27;
            // 
            // txtTemp_PM_To
            // 
            this.txtTemp_PM_To.Enabled = false;
            this.txtTemp_PM_To.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTemp_PM_To.Location = new System.Drawing.Point(596, 109);
            this.txtTemp_PM_To.Name = "txtTemp_PM_To";
            this.txtTemp_PM_To.Size = new System.Drawing.Size(42, 25);
            this.txtTemp_PM_To.TabIndex = 26;
            this.txtTemp_PM_To.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTemp_Range_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(570, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 18);
            this.label4.TabIndex = 30;
            this.label4.Text = "+/-";
            // 
            // txtTemp_PM_From
            // 
            this.txtTemp_PM_From.Enabled = false;
            this.txtTemp_PM_From.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTemp_PM_From.Location = new System.Drawing.Point(526, 109);
            this.txtTemp_PM_From.Name = "txtTemp_PM_From";
            this.txtTemp_PM_From.Size = new System.Drawing.Size(42, 25);
            this.txtTemp_PM_From.TabIndex = 25;
            this.txtTemp_PM_From.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTemp_Range_KeyPress);
            // 
            // rbnTemp_Plus_Minus
            // 
            this.rbnTemp_Plus_Minus.AutoSize = true;
            this.rbnTemp_Plus_Minus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnTemp_Plus_Minus.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnTemp_Plus_Minus.Location = new System.Drawing.Point(483, 111);
            this.rbnTemp_Plus_Minus.Name = "rbnTemp_Plus_Minus";
            this.rbnTemp_Plus_Minus.Size = new System.Drawing.Size(43, 21);
            this.rbnTemp_Plus_Minus.TabIndex = 24;
            this.rbnTemp_Plus_Minus.TabStop = true;
            this.rbnTemp_Plus_Minus.Text = "+/-";
            this.rbnTemp_Plus_Minus.UseVisualStyleBackColor = true;
            this.rbnTemp_Plus_Minus.CheckedChanged += new System.EventHandler(this.rbnTemp_Plus_Minus_CheckedChanged);
            // 
            // cmbTemp_Range
            // 
            this.cmbTemp_Range.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTemp_Range.Enabled = false;
            this.cmbTemp_Range.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTemp_Range.ForeColor = System.Drawing.Color.Black;
            this.cmbTemp_Range.FormattingEnabled = true;
            this.cmbTemp_Range.Items.AddRange(new object[] {
            "c",
            "f",
            "k",
            "r"});
            this.cmbTemp_Range.Location = new System.Drawing.Point(431, 141);
            this.cmbTemp_Range.Name = "cmbTemp_Range";
            this.cmbTemp_Range.Size = new System.Drawing.Size(32, 25);
            this.cmbTemp_Range.TabIndex = 31;
            // 
            // cmbTemp_Direct
            // 
            this.cmbTemp_Direct.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTemp_Direct.Enabled = false;
            this.cmbTemp_Direct.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTemp_Direct.ForeColor = System.Drawing.Color.Black;
            this.cmbTemp_Direct.FormattingEnabled = true;
            this.cmbTemp_Direct.Items.AddRange(new object[] {
            "c",
            "f",
            "k",
            "r"});
            this.cmbTemp_Direct.Location = new System.Drawing.Point(431, 110);
            this.cmbTemp_Direct.Name = "cmbTemp_Direct";
            this.cmbTemp_Direct.Size = new System.Drawing.Size(32, 25);
            this.cmbTemp_Direct.TabIndex = 23;
            // 
            // cmbTemp
            // 
            this.cmbTemp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTemp.Enabled = false;
            this.cmbTemp.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTemp.ForeColor = System.Drawing.Color.Black;
            this.cmbTemp.FormattingEnabled = true;
            this.cmbTemp.Items.AddRange(new object[] {
            "c",
            "f",
            "k",
            "r"});
            this.cmbTemp.Location = new System.Drawing.Point(117, 21);
            this.cmbTemp.Name = "cmbTemp";
            this.cmbTemp.Size = new System.Drawing.Size(32, 25);
            this.cmbTemp.TabIndex = 3;
            // 
            // rbnLtn_RTemp
            // 
            this.rbnLtn_RTemp.AutoSize = true;
            this.rbnLtn_RTemp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnLtn_RTemp.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnLtn_RTemp.Location = new System.Drawing.Point(483, 78);
            this.rbnLtn_RTemp.Name = "rbnLtn_RTemp";
            this.rbnLtn_RTemp.Size = new System.Drawing.Size(110, 21);
            this.rbnLtn_RTemp.TabIndex = 18;
            this.rbnLtn_RTemp.TabStop = true;
            this.rbnLtn_RTemp.Text = "< Room Temp";
            this.rbnLtn_RTemp.UseVisualStyleBackColor = true;
            this.rbnLtn_RTemp.CheckedChanged += new System.EventHandler(this.rbnLtn_RTemp_CheckedChanged);
            // 
            // rbnGrt_RTemp
            // 
            this.rbnGrt_RTemp.AutoSize = true;
            this.rbnGrt_RTemp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnGrt_RTemp.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnGrt_RTemp.Location = new System.Drawing.Point(651, 78);
            this.rbnGrt_RTemp.Name = "rbnGrt_RTemp";
            this.rbnGrt_RTemp.Size = new System.Drawing.Size(110, 21);
            this.rbnGrt_RTemp.TabIndex = 19;
            this.rbnGrt_RTemp.TabStop = true;
            this.rbnGrt_RTemp.Text = "> Room Temp";
            this.rbnGrt_RTemp.UseVisualStyleBackColor = true;
            this.rbnGrt_RTemp.CheckedChanged += new System.EventHandler(this.rbnGrt_RTemp_CheckedChanged);
            // 
            // rbnTemp_None
            // 
            this.rbnTemp_None.AutoSize = true;
            this.rbnTemp_None.Checked = true;
            this.rbnTemp_None.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnTemp_None.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnTemp_None.Location = new System.Drawing.Point(734, 143);
            this.rbnTemp_None.Name = "rbnTemp_None";
            this.rbnTemp_None.Size = new System.Drawing.Size(58, 21);
            this.rbnTemp_None.TabIndex = 0;
            this.rbnTemp_None.TabStop = true;
            this.rbnTemp_None.Text = "None";
            this.rbnTemp_None.UseVisualStyleBackColor = true;
            this.rbnTemp_None.CheckedChanged += new System.EventHandler(this.rbnTemp_None_CheckedChanged);
            // 
            // txtCustTemp
            // 
            this.txtCustTemp.Enabled = false;
            this.txtCustTemp.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustTemp.Location = new System.Drawing.Point(630, 141);
            this.txtCustTemp.Name = "txtCustTemp";
            this.txtCustTemp.Size = new System.Drawing.Size(88, 25);
            this.txtCustTemp.TabIndex = 34;
            // 
            // rbnCustomTemp
            // 
            this.rbnCustomTemp.AutoSize = true;
            this.rbnCustomTemp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnCustomTemp.Enabled = false;
            this.rbnCustomTemp.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnCustomTemp.Location = new System.Drawing.Point(556, 143);
            this.rbnCustomTemp.Name = "rbnCustomTemp";
            this.rbnCustomTemp.Size = new System.Drawing.Size(71, 21);
            this.rbnCustomTemp.TabIndex = 33;
            this.rbnCustomTemp.TabStop = true;
            this.rbnCustomTemp.Text = "Custom";
            this.rbnCustomTemp.UseVisualStyleBackColor = true;
            this.rbnCustomTemp.CheckedChanged += new System.EventHandler(this.rbnCustomTemp_CheckedChanged);
            // 
            // txtTemp
            // 
            this.txtTemp.Enabled = false;
            this.txtTemp.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTemp.Location = new System.Drawing.Point(62, 21);
            this.txtTemp.Name = "txtTemp";
            this.txtTemp.Size = new System.Drawing.Size(52, 25);
            this.txtTemp.TabIndex = 2;
            this.txtTemp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTemp_KeyPress);
            // 
            // rbnTemp
            // 
            this.rbnTemp.AutoSize = true;
            this.rbnTemp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnTemp.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnTemp.Location = new System.Drawing.Point(6, 23);
            this.rbnTemp.Name = "rbnTemp";
            this.rbnTemp.Size = new System.Drawing.Size(59, 21);
            this.rbnTemp.TabIndex = 1;
            this.rbnTemp.TabStop = true;
            this.rbnTemp.Text = "Temp";
            this.rbnTemp.UseVisualStyleBackColor = false;
            this.rbnTemp.CheckedChanged += new System.EventHandler(this.rbnTemp_CheckedChanged);
            // 
            // txtRange_To
            // 
            this.txtRange_To.Enabled = false;
            this.txtRange_To.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRange_To.Location = new System.Drawing.Point(384, 141);
            this.txtRange_To.Name = "txtRange_To";
            this.txtRange_To.Size = new System.Drawing.Size(44, 25);
            this.txtRange_To.TabIndex = 30;
            this.txtRange_To.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTemp_Range_KeyPress);
            // 
            // rbnRoomTemp
            // 
            this.rbnRoomTemp.AutoSize = true;
            this.rbnRoomTemp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnRoomTemp.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnRoomTemp.Location = new System.Drawing.Point(213, 23);
            this.rbnRoomTemp.Name = "rbnRoomTemp";
            this.rbnRoomTemp.Size = new System.Drawing.Size(119, 21);
            this.rbnRoomTemp.TabIndex = 4;
            this.rbnRoomTemp.TabStop = true;
            this.rbnRoomTemp.Text = "Room Temp (a)";
            this.rbnRoomTemp.UseVisualStyleBackColor = true;
            this.rbnRoomTemp.CheckedChanged += new System.EventHandler(this.rbnRoomTemp_CheckedChanged);
            // 
            // rbnEqual_Temp
            // 
            this.rbnEqual_Temp.AutoSize = true;
            this.rbnEqual_Temp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnEqual_Temp.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnEqual_Temp.Location = new System.Drawing.Point(484, 143);
            this.rbnEqual_Temp.Name = "rbnEqual_Temp";
            this.rbnEqual_Temp.Size = new System.Drawing.Size(34, 21);
            this.rbnEqual_Temp.TabIndex = 32;
            this.rbnEqual_Temp.TabStop = true;
            this.rbnEqual_Temp.Text = "=";
            this.rbnEqual_Temp.UseVisualStyleBackColor = true;
            this.rbnEqual_Temp.CheckedChanged += new System.EventHandler(this.rbnEqual_Temp_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(369, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(13, 18);
            this.label3.TabIndex = 23;
            this.label3.Text = "-";
            // 
            // txtRange_From
            // 
            this.txtRange_From.Enabled = false;
            this.txtRange_From.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRange_From.Location = new System.Drawing.Point(325, 141);
            this.txtRange_From.Name = "txtRange_From";
            this.txtRange_From.Size = new System.Drawing.Size(42, 25);
            this.txtRange_From.TabIndex = 29;
            this.txtRange_From.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTemp_Range_KeyPress);
            // 
            // rbnTemp_Range
            // 
            this.rbnTemp_Range.AutoSize = true;
            this.rbnTemp_Range.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnTemp_Range.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnTemp_Range.Location = new System.Drawing.Point(213, 143);
            this.rbnTemp_Range.Name = "rbnTemp_Range";
            this.rbnTemp_Range.Size = new System.Drawing.Size(91, 21);
            this.rbnTemp_Range.TabIndex = 28;
            this.rbnTemp_Range.TabStop = true;
            this.rbnTemp_Range.Text = "Range ( - )";
            this.rbnTemp_Range.UseVisualStyleBackColor = true;
            this.rbnTemp_Range.CheckedChanged += new System.EventHandler(this.rbnTemp_Range_CheckedChanged);
            // 
            // txtDirect_To
            // 
            this.txtDirect_To.Enabled = false;
            this.txtDirect_To.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDirect_To.Location = new System.Drawing.Point(384, 110);
            this.txtDirect_To.Name = "txtDirect_To";
            this.txtDirect_To.Size = new System.Drawing.Size(44, 25);
            this.txtDirect_To.TabIndex = 22;
            this.txtDirect_To.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTemp_Range_KeyPress);
            // 
            // lblDirect
            // 
            this.lblDirect.AutoSize = true;
            this.lblDirect.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDirect.Location = new System.Drawing.Point(369, 112);
            this.lblDirect.Name = "lblDirect";
            this.lblDirect.Size = new System.Drawing.Size(13, 17);
            this.lblDirect.TabIndex = 19;
            this.lblDirect.Text = "]";
            // 
            // txtDirect_From
            // 
            this.txtDirect_From.Enabled = false;
            this.txtDirect_From.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDirect_From.Location = new System.Drawing.Point(325, 110);
            this.txtDirect_From.Name = "txtDirect_From";
            this.txtDirect_From.Size = new System.Drawing.Size(42, 25);
            this.txtDirect_From.TabIndex = 21;
            this.txtDirect_From.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTemp_Range_KeyPress);
            // 
            // rbnDirectnal
            // 
            this.rbnDirectnal.AutoSize = true;
            this.rbnDirectnal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnDirectnal.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnDirectnal.Location = new System.Drawing.Point(213, 111);
            this.rbnDirectnal.Name = "rbnDirectnal";
            this.rbnDirectnal.Size = new System.Drawing.Size(117, 21);
            this.rbnDirectnal.TabIndex = 20;
            this.rbnDirectnal.TabStop = true;
            this.rbnDirectnal.Text = "Directional ( ] )";
            this.rbnDirectnal.UseVisualStyleBackColor = true;
            this.rbnDirectnal.CheckedChanged += new System.EventHandler(this.rbnDirectnal_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(750, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 17);
            this.label2.TabIndex = 15;
            this.label2.Tag = "0";
            this.label2.Text = "to Reflux";
            // 
            // txtX_Reflux
            // 
            this.txtX_Reflux.Enabled = false;
            this.txtX_Reflux.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtX_Reflux.Location = new System.Drawing.Point(669, 48);
            this.txtX_Reflux.Name = "txtX_Reflux";
            this.txtX_Reflux.Size = new System.Drawing.Size(43, 25);
            this.txtX_Reflux.TabIndex = 13;
            this.txtX_Reflux.Tag = "0";
            this.txtX_Reflux.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTemp_Range_KeyPress);
            // 
            // rbnX_Reflux
            // 
            this.rbnX_Reflux.AutoSize = true;
            this.rbnX_Reflux.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnX_Reflux.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnX_Reflux.Location = new System.Drawing.Point(651, 55);
            this.rbnX_Reflux.Name = "rbnX_Reflux";
            this.rbnX_Reflux.Size = new System.Drawing.Size(14, 13);
            this.rbnX_Reflux.TabIndex = 12;
            this.rbnX_Reflux.TabStop = true;
            this.rbnX_Reflux.Tag = "0";
            this.rbnX_Reflux.UseVisualStyleBackColor = true;
            this.rbnX_Reflux.CheckedChanged += new System.EventHandler(this.rbnX_Reflux_CheckedChanged);
            // 
            // txtReflux_X
            // 
            this.txtReflux_X.Enabled = false;
            this.txtReflux_X.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReflux_X.Location = new System.Drawing.Point(561, 49);
            this.txtReflux_X.Name = "txtReflux_X";
            this.txtReflux_X.Size = new System.Drawing.Size(43, 25);
            this.txtReflux_X.TabIndex = 11;
            this.txtReflux_X.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTemp_Range_KeyPress);
            // 
            // rbnReflux_X
            // 
            this.rbnReflux_X.AutoSize = true;
            this.rbnReflux_X.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnReflux_X.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnReflux_X.Location = new System.Drawing.Point(483, 51);
            this.rbnReflux_X.Name = "rbnReflux_X";
            this.rbnReflux_X.Size = new System.Drawing.Size(80, 21);
            this.rbnReflux_X.TabIndex = 10;
            this.rbnReflux_X.TabStop = true;
            this.rbnReflux_X.Text = "Reflux to";
            this.rbnReflux_X.UseVisualStyleBackColor = true;
            this.rbnReflux_X.CheckedChanged += new System.EventHandler(this.rbnReflux_X_CheckedChanged);
            // 
            // lblX_RTemp
            // 
            this.lblX_RTemp.AutoSize = true;
            this.lblX_RTemp.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblX_RTemp.Location = new System.Drawing.Point(320, 80);
            this.lblX_RTemp.Name = "lblX_RTemp";
            this.lblX_RTemp.Size = new System.Drawing.Size(95, 17);
            this.lblX_RTemp.TabIndex = 10;
            this.lblX_RTemp.Tag = "0";
            this.lblX_RTemp.Text = "to Room Temp";
            // 
            // txtX_RTemp
            // 
            this.txtX_RTemp.Enabled = false;
            this.txtX_RTemp.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtX_RTemp.Location = new System.Drawing.Point(233, 77);
            this.txtX_RTemp.Name = "txtX_RTemp";
            this.txtX_RTemp.Size = new System.Drawing.Size(49, 25);
            this.txtX_RTemp.TabIndex = 17;
            this.txtX_RTemp.Tag = "0";
            this.txtX_RTemp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTemp_Range_KeyPress);
            // 
            // rbnX_RTemp
            // 
            this.rbnX_RTemp.AutoSize = true;
            this.rbnX_RTemp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnX_RTemp.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnX_RTemp.Location = new System.Drawing.Point(213, 82);
            this.rbnX_RTemp.Name = "rbnX_RTemp";
            this.rbnX_RTemp.Size = new System.Drawing.Size(14, 13);
            this.rbnX_RTemp.TabIndex = 16;
            this.rbnX_RTemp.TabStop = true;
            this.rbnX_RTemp.Tag = "0";
            this.rbnX_RTemp.UseVisualStyleBackColor = true;
            this.rbnX_RTemp.CheckedChanged += new System.EventHandler(this.rbnX_RTemp_CheckedChanged);
            // 
            // txtRTemp_X
            // 
            this.txtRTemp_X.Enabled = false;
            this.txtRTemp_X.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRTemp_X.Location = new System.Drawing.Point(119, 77);
            this.txtRTemp_X.Name = "txtRTemp_X";
            this.txtRTemp_X.Size = new System.Drawing.Size(49, 25);
            this.txtRTemp_X.TabIndex = 15;
            this.txtRTemp_X.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTemp_Range_KeyPress);
            // 
            // rbnRTemp_X
            // 
            this.rbnRTemp_X.AutoSize = true;
            this.rbnRTemp_X.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnRTemp_X.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnRTemp_X.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.rbnRTemp_X.Location = new System.Drawing.Point(6, 78);
            this.rbnRTemp_X.Name = "rbnRTemp_X";
            this.rbnRTemp_X.Size = new System.Drawing.Size(113, 21);
            this.rbnRTemp_X.TabIndex = 14;
            this.rbnRTemp_X.TabStop = true;
            this.rbnRTemp_X.Text = "Room Temp to";
            this.rbnRTemp_X.UseVisualStyleBackColor = false;
            this.rbnRTemp_X.CheckedChanged += new System.EventHandler(this.rbnRTemp_X_CheckedChanged);
            // 
            // rbnReflx_RTemp
            // 
            this.rbnReflx_RTemp.AutoSize = true;
            this.rbnReflx_RTemp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnReflx_RTemp.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnReflx_RTemp.Location = new System.Drawing.Point(213, 51);
            this.rbnReflx_RTemp.Name = "rbnReflx_RTemp";
            this.rbnReflx_RTemp.Size = new System.Drawing.Size(189, 21);
            this.rbnReflx_RTemp.TabIndex = 9;
            this.rbnReflx_RTemp.TabStop = true;
            this.rbnReflx_RTemp.Tag = "0";
            this.rbnReflx_RTemp.Text = "Reflux to Room Temp (x]a)";
            this.rbnReflx_RTemp.UseVisualStyleBackColor = true;
            this.rbnReflx_RTemp.CheckedChanged += new System.EventHandler(this.rbnReflx_RTemp_CheckedChanged);
            // 
            // rbnRTemp_Reflx
            // 
            this.rbnRTemp_Reflx.AutoSize = true;
            this.rbnRTemp_Reflx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnRTemp_Reflx.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnRTemp_Reflx.Location = new System.Drawing.Point(6, 50);
            this.rbnRTemp_Reflx.Name = "rbnRTemp_Reflx";
            this.rbnRTemp_Reflx.Size = new System.Drawing.Size(189, 21);
            this.rbnRTemp_Reflx.TabIndex = 8;
            this.rbnRTemp_Reflx.TabStop = true;
            this.rbnRTemp_Reflx.Text = "Room Temp to Reflux (a]x)";
            this.rbnRTemp_Reflx.UseVisualStyleBackColor = true;
            this.rbnRTemp_Reflx.CheckedChanged += new System.EventHandler(this.rbnRTemp_Reflx_CheckedChanged);
            // 
            // rbnHeated
            // 
            this.rbnHeated.AutoSize = true;
            this.rbnHeated.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnHeated.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnHeated.Location = new System.Drawing.Point(651, 23);
            this.rbnHeated.Name = "rbnHeated";
            this.rbnHeated.Size = new System.Drawing.Size(120, 21);
            this.rbnHeated.TabIndex = 7;
            this.rbnHeated.TabStop = true;
            this.rbnHeated.Text = "Heated (h or Δ)";
            this.rbnHeated.UseVisualStyleBackColor = true;
            this.rbnHeated.CheckedChanged += new System.EventHandler(this.rbnHeated_CheckedChanged);
            // 
            // rbnReflux
            // 
            this.rbnReflux.AutoSize = true;
            this.rbnReflux.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnReflux.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnReflux.Location = new System.Drawing.Point(345, 23);
            this.rbnReflux.Name = "rbnReflux";
            this.rbnReflux.Size = new System.Drawing.Size(127, 21);
            this.rbnReflux.TabIndex = 5;
            this.rbnReflux.TabStop = true;
            this.rbnReflux.Text = "Reflux/Boiled (x)";
            this.rbnReflux.UseVisualStyleBackColor = true;
            this.rbnReflux.CheckedChanged += new System.EventHandler(this.rbnReflux_CheckedChanged);
            // 
            // rbnCool
            // 
            this.rbnCool.AutoSize = true;
            this.rbnCool.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnCool.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnCool.Location = new System.Drawing.Point(483, 23);
            this.rbnCool.Name = "rbnCool";
            this.rbnCool.Size = new System.Drawing.Size(74, 21);
            this.rbnCool.TabIndex = 6;
            this.rbnCool.TabStop = true;
            this.rbnCool.Text = "Cool (c)";
            this.rbnCool.UseVisualStyleBackColor = true;
            this.rbnCool.CheckedChanged += new System.EventHandler(this.rbnCool_CheckedChanged);
            // 
            // pnlGrid
            // 
            this.pnlGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlGrid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlGrid.Controls.Add(this.dgvConds);
            this.pnlGrid.Controls.Add(this.lblStageName);
            this.pnlGrid.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlGrid.Location = new System.Drawing.Point(2, 394);
            this.pnlGrid.Name = "pnlGrid";
            this.pnlGrid.Size = new System.Drawing.Size(812, 146);
            this.pnlGrid.TabIndex = 1;
            // 
            // dgvConds
            // 
            this.dgvConds.AllowUserToAddRows = false;
            this.dgvConds.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvConds.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvConds.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvConds.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvConds.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTemp,
            this.colTime,
            this.colpH,
            this.colPressure,
            this.colTemp_Type,
            this.colPres_Type,
            this.colpH_Type,
            this.colTime_Type,
            this.colEdit,
            this.colDelete});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvConds.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgvConds.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvConds.Location = new System.Drawing.Point(0, 17);
            this.dgvConds.Name = "dgvConds";
            this.dgvConds.ReadOnly = true;
            this.dgvConds.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvConds.Size = new System.Drawing.Size(810, 127);
            this.dgvConds.TabIndex = 0;
            this.dgvConds.TabStop = false;
            this.dgvConds.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvConds_CellContentClick);
            this.dgvConds.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvConds_RowPostPaint);
            // 
            // colTemp
            // 
            this.colTemp.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colTemp.HeaderText = "Temperature";
            this.colTemp.Name = "colTemp";
            this.colTemp.ReadOnly = true;
            this.colTemp.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colTime
            // 
            this.colTime.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colTime.HeaderText = "Time";
            this.colTime.Name = "colTime";
            this.colTime.ReadOnly = true;
            this.colTime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colpH
            // 
            this.colpH.HeaderText = "pH";
            this.colpH.Name = "colpH";
            this.colpH.ReadOnly = true;
            this.colpH.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colPressure
            // 
            this.colPressure.HeaderText = "Pressure";
            this.colPressure.Name = "colPressure";
            this.colPressure.ReadOnly = true;
            this.colPressure.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colTemp_Type
            // 
            this.colTemp_Type.HeaderText = "Temp_Type";
            this.colTemp_Type.Name = "colTemp_Type";
            this.colTemp_Type.ReadOnly = true;
            this.colTemp_Type.Visible = false;
            // 
            // colPres_Type
            // 
            this.colPres_Type.HeaderText = "Pressure_Type";
            this.colPres_Type.Name = "colPres_Type";
            this.colPres_Type.ReadOnly = true;
            this.colPres_Type.Visible = false;
            // 
            // colpH_Type
            // 
            this.colpH_Type.HeaderText = "PH_Type";
            this.colpH_Type.Name = "colpH_Type";
            this.colpH_Type.ReadOnly = true;
            this.colpH_Type.Visible = false;
            // 
            // colTime_Type
            // 
            this.colTime_Type.HeaderText = "Time_Type";
            this.colTime_Type.Name = "colTime_Type";
            this.colTime_Type.ReadOnly = true;
            this.colTime_Type.Visible = false;
            // 
            // colEdit
            // 
            this.colEdit.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colEdit.DefaultCellStyle = dataGridViewCellStyle2;
            this.colEdit.HeaderText = "Edit";
            this.colEdit.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.colEdit.Name = "colEdit";
            this.colEdit.ReadOnly = true;
            this.colEdit.Text = "Edit";
            this.colEdit.TrackVisitedState = false;
            this.colEdit.UseColumnTextForLinkValue = true;
            // 
            // colDelete
            // 
            this.colDelete.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colDelete.DefaultCellStyle = dataGridViewCellStyle3;
            this.colDelete.HeaderText = "Delete";
            this.colDelete.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.colDelete.Name = "colDelete";
            this.colDelete.ReadOnly = true;
            this.colDelete.Text = "Delete";
            this.colDelete.TrackVisitedState = false;
            this.colDelete.UseColumnTextForLinkValue = true;
            // 
            // lblStageName
            // 
            this.lblStageName.AutoSize = true;
            this.lblStageName.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblStageName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStageName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblStageName.Location = new System.Drawing.Point(0, 0);
            this.lblStageName.Name = "lblStageName";
            this.lblStageName.Size = new System.Drawing.Size(31, 17);
            this.lblStageName.TabIndex = 17;
            this.lblStageName.Tag = "0";
            this.lblStageName.Text = "sdg";
            // 
            // pnlPrevStg
            // 
            this.pnlPrevStg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlPrevStg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlPrevStg.Controls.Add(this.lblPrevStage);
            this.pnlPrevStg.Controls.Add(this.dgvPrevConds);
            this.pnlPrevStg.Controls.Add(this.lblPrevStg);
            this.pnlPrevStg.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlPrevStg.Location = new System.Drawing.Point(2, 542);
            this.pnlPrevStg.Name = "pnlPrevStg";
            this.pnlPrevStg.Size = new System.Drawing.Size(812, 82);
            this.pnlPrevStg.TabIndex = 2;
            // 
            // lblPrevStage
            // 
            this.lblPrevStage.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPrevStage.AutoSize = true;
            this.lblPrevStage.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrevStage.ForeColor = System.Drawing.Color.Blue;
            this.lblPrevStage.Location = new System.Drawing.Point(195, 0);
            this.lblPrevStage.Name = "lblPrevStage";
            this.lblPrevStage.Size = new System.Drawing.Size(0, 17);
            this.lblPrevStage.TabIndex = 18;
            this.lblPrevStage.Tag = "0";
            // 
            // dgvPrevConds
            // 
            this.dgvPrevConds.AllowUserToAddRows = false;
            this.dgvPrevConds.AllowUserToDeleteRows = false;
            this.dgvPrevConds.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPrevConds.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPrevConds.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTemp_PrevStg,
            this.colTime_PrevStg,
            this.colPH_PrevStg,
            this.colPressure_PrevStg});
            this.dgvPrevConds.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvPrevConds.Location = new System.Drawing.Point(0, 17);
            this.dgvPrevConds.Name = "dgvPrevConds";
            this.dgvPrevConds.ReadOnly = true;
            this.dgvPrevConds.Size = new System.Drawing.Size(810, 63);
            this.dgvPrevConds.TabIndex = 0;
            this.dgvPrevConds.TabStop = false;
            // 
            // colTemp_PrevStg
            // 
            this.colTemp_PrevStg.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colTemp_PrevStg.HeaderText = "Temperature";
            this.colTemp_PrevStg.Name = "colTemp_PrevStg";
            this.colTemp_PrevStg.ReadOnly = true;
            this.colTemp_PrevStg.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colTime_PrevStg
            // 
            this.colTime_PrevStg.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colTime_PrevStg.HeaderText = "Time";
            this.colTime_PrevStg.Name = "colTime_PrevStg";
            this.colTime_PrevStg.ReadOnly = true;
            this.colTime_PrevStg.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colPH_PrevStg
            // 
            this.colPH_PrevStg.HeaderText = "pH";
            this.colPH_PrevStg.Name = "colPH_PrevStg";
            this.colPH_PrevStg.ReadOnly = true;
            this.colPH_PrevStg.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colPressure_PrevStg
            // 
            this.colPressure_PrevStg.HeaderText = "Pressure";
            this.colPressure_PrevStg.Name = "colPressure_PrevStg";
            this.colPressure_PrevStg.ReadOnly = true;
            this.colPressure_PrevStg.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // lblPrevStg
            // 
            this.lblPrevStg.AutoSize = true;
            this.lblPrevStg.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblPrevStg.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrevStg.ForeColor = System.Drawing.Color.Blue;
            this.lblPrevStg.Location = new System.Drawing.Point(0, 0);
            this.lblPrevStg.Name = "lblPrevStg";
            this.lblPrevStg.Size = new System.Drawing.Size(155, 17);
            this.lblPrevStg.TabIndex = 16;
            this.lblPrevStg.Tag = "0";
            this.lblPrevStg.Text = "Previous Stage Condition";
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlBottom.Controls.Add(this.btnSubmit);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlBottom.Location = new System.Drawing.Point(0, 625);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(816, 30);
            this.pnlBottom.TabIndex = 3;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSubmit.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnSubmit.Location = new System.Drawing.Point(712, 0);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(95, 27);
            this.btnSubmit.TabIndex = 77;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            // 
            // frmConditions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(816, 655);
            this.Controls.Add(this.pnlBottom);
            this.Controls.Add(this.pnlPrevStg);
            this.Controls.Add(this.pnlGrid);
            this.Controls.Add(this.pnlMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmConditions";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Conditions";
            this.Load += new System.EventHandler(this.frmConditions_Load);
            this.pnlMain.ResumeLayout(false);
            this.grpTime.ResumeLayout(false);
            this.grpTime.PerformLayout();
            this.grpPH.ResumeLayout(false);
            this.grpPH.PerformLayout();
            this.grpPressure.ResumeLayout(false);
            this.grpPressure.PerformLayout();
            this.grpTemprture.ResumeLayout(false);
            this.grpTemprture.PerformLayout();
            this.pnlGrid.ResumeLayout(false);
            this.pnlGrid.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvConds)).EndInit();
            this.pnlPrevStg.ResumeLayout(false);
            this.pnlPrevStg.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrevConds)).EndInit();
            this.pnlBottom.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.GroupBox grpTemprture;
        private System.Windows.Forms.RadioButton rbnRoomTemp;
        private System.Windows.Forms.RadioButton rbnCool;
        private System.Windows.Forms.RadioButton rbnHeated;
        private System.Windows.Forms.RadioButton rbnReflux;
        private System.Windows.Forms.RadioButton rbnReflx_RTemp;
        private System.Windows.Forms.RadioButton rbnRTemp_Reflx;
        private System.Windows.Forms.TextBox txtRTemp_X;
        private System.Windows.Forms.RadioButton rbnRTemp_X;
        private System.Windows.Forms.Label lblX_RTemp;
        private System.Windows.Forms.TextBox txtX_RTemp;
        private System.Windows.Forms.RadioButton rbnX_RTemp;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtX_Reflux;
        private System.Windows.Forms.RadioButton rbnX_Reflux;
        private System.Windows.Forms.TextBox txtReflux_X;
        private System.Windows.Forms.RadioButton rbnReflux_X;
        private System.Windows.Forms.RadioButton rbnDirectnal;
        private System.Windows.Forms.RadioButton rbnEqual_Temp;
        private System.Windows.Forms.TextBox txtDirect_To;
        private System.Windows.Forms.Label lblDirect;
        private System.Windows.Forms.TextBox txtDirect_From;
        private System.Windows.Forms.TextBox txtRange_To;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtRange_From;
        private System.Windows.Forms.RadioButton rbnTemp_Range;
        private System.Windows.Forms.TextBox txtTemp;
        private System.Windows.Forms.RadioButton rbnTemp;
        private System.Windows.Forms.TextBox txtCustTemp;
        private System.Windows.Forms.RadioButton rbnCustomTemp;
        private System.Windows.Forms.GroupBox grpPressure;
        private System.Windows.Forms.GroupBox grpTime;
        private System.Windows.Forms.GroupBox grpPH;
        private System.Windows.Forms.Panel pnlGrid;
        private System.Windows.Forms.DataGridView dgvConds;
        private System.Windows.Forms.TextBox txtTime;
        private System.Windows.Forms.RadioButton rbnTime_OvrN;
        private System.Windows.Forms.RadioButton rbnpH_Acid;
        private System.Windows.Forms.TextBox txtPH;
        private System.Windows.Forms.RadioButton rbnpH_Basic;
        private System.Windows.Forms.RadioButton rbnpH_Nutral;
        private System.Windows.Forms.TextBox txtPressure;
        private System.Windows.Forms.RadioButton rbnTemp_None;
        private System.Windows.Forms.RadioButton rbnTime_None;
        private System.Windows.Forms.RadioButton rbnPH_None;
        private System.Windows.Forms.RadioButton rbnLtn_RTemp;
        private System.Windows.Forms.RadioButton rbnGrt_RTemp;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.ComboBox cmbTemp;
        private System.Windows.Forms.Panel pnlPrevStg;
        private System.Windows.Forms.DataGridView dgvPrevConds;
        private System.Windows.Forms.Label lblPrevStg;
        private System.Windows.Forms.RadioButton rbnTime;
        private System.Windows.Forms.RadioButton rbnPH;
        private System.Windows.Forms.Label lblStageName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTemp_PrevStg;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTime_PrevStg;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPH_PrevStg;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPressure_PrevStg;
        private System.Windows.Forms.Label lblPrevStage;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.ComboBox cmbTime_Range;
        private System.Windows.Forms.TextBox txtTime_To;
        private System.Windows.Forms.Label lblTime_range;
        private System.Windows.Forms.TextBox txtTime_From;
        private System.Windows.Forms.RadioButton rbnTime_Range;
        private System.Windows.Forms.ComboBox cmbPres_Range;
        private System.Windows.Forms.TextBox txtPres_To;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtPres_From;
        private System.Windows.Forms.RadioButton rbnPres_Range;
        private System.Windows.Forms.RadioButton rbnPres_None;
        private System.Windows.Forms.RadioButton rbnPressure;
        private System.Windows.Forms.ComboBox cmbTime;
        private System.Windows.Forms.TextBox txtPH_To;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtPH_From;
        private System.Windows.Forms.RadioButton rbnPH_Range;
        private System.Windows.Forms.ComboBox cmbPres_Direct;
        private System.Windows.Forms.TextBox txtPres_D_To;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtPres_D_From;
        private System.Windows.Forms.RadioButton rbnPres_Direct;
        private System.Windows.Forms.ComboBox cmbPressure;
        private System.Windows.Forms.ComboBox cmbTemp_Range;
        private System.Windows.Forms.ComboBox cmbTemp_Direct;
        private System.Windows.Forms.TextBox txtCustTime;
        private System.Windows.Forms.RadioButton rbnCustTime;
        private System.Windows.Forms.RadioButton rbnCustPH;
        private System.Windows.Forms.TextBox txtCustPH;
        private System.Windows.Forms.TextBox txtCustPres;
        private System.Windows.Forms.RadioButton rbnCustPres;
        private System.Windows.Forms.ComboBox cmbTemp_PM;
        private System.Windows.Forms.TextBox txtTemp_PM_To;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTemp_PM_From;
        private System.Windows.Forms.RadioButton rbnTemp_Plus_Minus;
        private System.Windows.Forms.RadioButton rbnEqual_Time;
        private System.Windows.Forms.RadioButton rbnEqual_pH;
        private System.Windows.Forms.RadioButton rbnEqual_Pres;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTemp;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn colpH;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPressure;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTemp_Type;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPres_Type;
        private System.Windows.Forms.DataGridViewTextBoxColumn colpH_Type;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTime_Type;
        private System.Windows.Forms.DataGridViewLinkColumn colEdit;
        private System.Windows.Forms.DataGridViewLinkColumn colDelete;
        private System.Windows.Forms.ComboBox cmbTime_InExact;
        private System.Windows.Forms.RadioButton rbnTime_InExact;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.ComboBox cmbTemp_X_RTemp;
        private System.Windows.Forms.ComboBox cmbTemp_RTemp_X;
        private System.Windows.Forms.ComboBox cmbTemp_X_Ref;
        private System.Windows.Forms.ComboBox cmbTemp_Ref_X;
    }
}