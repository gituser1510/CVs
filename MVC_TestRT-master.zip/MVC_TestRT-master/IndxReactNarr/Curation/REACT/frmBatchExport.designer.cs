﻿namespace IndxReactNarr
{
    partial class frmBatchXml
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.splCont = new System.Windows.Forms.SplitContainer();
            this.pnlGrid = new System.Windows.Forms.Panel();
            this.chkSkipQcCheck = new System.Windows.Forms.CheckBox();
            this.pnlStatus = new System.Windows.Forms.Panel();
            this.lblFreezeTAN_Cnt = new System.Windows.Forms.Label();
            this.lblFreeze = new System.Windows.Forms.Label();
            this.lblReAssCur_Cnt = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblReAssRev_Cnt = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblReAssQC_Cnt = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblAssQC_Cnt = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblAssRev_Cnt = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblAssCur_Cnt = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblCur_Done_Cnt = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblRev_Done_Cnt = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblQC_Done_Cnt = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblSelTANCnt = new System.Windows.Forms.Label();
            this.lblSel_Cnt = new System.Windows.Forms.Label();
            this.lblSelTANs = new System.Windows.Forms.Label();
            this.lblAvlTANCnt = new System.Windows.Forms.Label();
            this.lblAvl_Cnt = new System.Windows.Forms.Label();
            this.lblAvailTANs = new System.Windows.Forms.Label();
            this.dgvSelectedTANs = new System.Windows.Forms.DataGridView();
            this.btnDelOne = new System.Windows.Forms.Button();
            this.btnSelOne = new System.Windows.Forms.Button();
            this.dgvAvailableTANs = new System.Windows.Forms.DataGridView();
            this.dgvXmlTANs = new System.Windows.Forms.DataGridView();
            this.pnlXML = new System.Windows.Forms.Panel();
            this.lblXmlTANCnt = new System.Windows.Forms.Label();
            this.lbl = new System.Windows.Forms.Label();
            this.btnAppend = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.lblTAN = new System.Windows.Forms.Label();
            this.txtTANSrch = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBNo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBatchName = new System.Windows.Forms.TextBox();
            this.btnGetTans = new System.Windows.Forms.Button();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.btnBrowsePdfFolder = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txtMarkupsPath = new System.Windows.Forms.TextBox();
            this.lblFileName = new System.Windows.Forms.Label();
            this.txtFileName = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtFilePath = new System.Windows.Forms.TextBox();
            this.btnXml = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTAN_ID_Sel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTAN_Sel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBNo_Sel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTANType_Sel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnCnt_Sel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colIsFreezed_Sel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTANStatus_Sel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDocClass_Sel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTANPriority_Sel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colQueryTAN_Sel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTAN_ID_Avail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTAN_Avail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBNo_Avail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTANType_Avail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnCnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colIsFreezed_Avail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTanStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDocClass_Avl = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTANPriority_Avl = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colQueryTAN_Avl = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTAN_ID_Xml = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTAN_Xml = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTANType_Xml = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnCnt_Xml = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBatch_Xml = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBNo_Xml = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTANStatus_Xml = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDocClass_Xml = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTANPriority_Xml = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colQueryTAN_Xml = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splCont)).BeginInit();
            this.splCont.Panel1.SuspendLayout();
            this.splCont.Panel2.SuspendLayout();
            this.splCont.SuspendLayout();
            this.pnlGrid.SuspendLayout();
            this.pnlStatus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSelectedTANs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAvailableTANs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvXmlTANs)).BeginInit();
            this.pnlXML.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.pnlBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.splCont);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1229, 644);
            this.pnlMain.TabIndex = 0;
            // 
            // splCont
            // 
            this.splCont.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splCont.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splCont.Location = new System.Drawing.Point(0, 31);
            this.splCont.Name = "splCont";
            this.splCont.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splCont.Panel1
            // 
            this.splCont.Panel1.Controls.Add(this.pnlGrid);
            // 
            // splCont.Panel2
            // 
            this.splCont.Panel2.Controls.Add(this.dgvXmlTANs);
            this.splCont.Panel2.Controls.Add(this.pnlXML);
            this.splCont.Size = new System.Drawing.Size(1229, 552);
            this.splCont.SplitterDistance = 351;
            this.splCont.SplitterWidth = 2;
            this.splCont.TabIndex = 13;
            // 
            // pnlGrid
            // 
            this.pnlGrid.Controls.Add(this.pnlStatus);
            this.pnlGrid.Controls.Add(this.lblSelTANCnt);
            this.pnlGrid.Controls.Add(this.lblSel_Cnt);
            this.pnlGrid.Controls.Add(this.lblSelTANs);
            this.pnlGrid.Controls.Add(this.lblAvlTANCnt);
            this.pnlGrid.Controls.Add(this.lblAvl_Cnt);
            this.pnlGrid.Controls.Add(this.lblAvailTANs);
            this.pnlGrid.Controls.Add(this.dgvSelectedTANs);
            this.pnlGrid.Controls.Add(this.btnDelOne);
            this.pnlGrid.Controls.Add(this.btnSelOne);
            this.pnlGrid.Controls.Add(this.dgvAvailableTANs);
            this.pnlGrid.Controls.Add(this.chkSkipQcCheck);
            this.pnlGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlGrid.Location = new System.Drawing.Point(0, 0);
            this.pnlGrid.Name = "pnlGrid";
            this.pnlGrid.Size = new System.Drawing.Size(1225, 347);
            this.pnlGrid.TabIndex = 9;
            // 
            // chkSkipQcCheck
            // 
            this.chkSkipQcCheck.AutoSize = true;
            this.chkSkipQcCheck.Location = new System.Drawing.Point(322, 4);
            this.chkSkipQcCheck.Name = "chkSkipQcCheck";
            this.chkSkipQcCheck.Size = new System.Drawing.Size(136, 21);
            this.chkSkipQcCheck.TabIndex = 36;
            this.chkSkipQcCheck.Text = "Skip QC validation";
            this.chkSkipQcCheck.UseVisualStyleBackColor = true;
            this.chkSkipQcCheck.Visible = false;
            // 
            // pnlStatus
            // 
            this.pnlStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlStatus.Controls.Add(this.lblFreezeTAN_Cnt);
            this.pnlStatus.Controls.Add(this.lblFreeze);
            this.pnlStatus.Controls.Add(this.lblReAssCur_Cnt);
            this.pnlStatus.Controls.Add(this.label14);
            this.pnlStatus.Controls.Add(this.lblReAssRev_Cnt);
            this.pnlStatus.Controls.Add(this.label13);
            this.pnlStatus.Controls.Add(this.lblReAssQC_Cnt);
            this.pnlStatus.Controls.Add(this.label12);
            this.pnlStatus.Controls.Add(this.lblAssQC_Cnt);
            this.pnlStatus.Controls.Add(this.label11);
            this.pnlStatus.Controls.Add(this.lblAssRev_Cnt);
            this.pnlStatus.Controls.Add(this.label10);
            this.pnlStatus.Controls.Add(this.lblAssCur_Cnt);
            this.pnlStatus.Controls.Add(this.label9);
            this.pnlStatus.Controls.Add(this.lblCur_Done_Cnt);
            this.pnlStatus.Controls.Add(this.label8);
            this.pnlStatus.Controls.Add(this.lblRev_Done_Cnt);
            this.pnlStatus.Controls.Add(this.label7);
            this.pnlStatus.Controls.Add(this.lblQC_Done_Cnt);
            this.pnlStatus.Controls.Add(this.label5);
            this.pnlStatus.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlStatus.Location = new System.Drawing.Point(0, 296);
            this.pnlStatus.Name = "pnlStatus";
            this.pnlStatus.Size = new System.Drawing.Size(1225, 51);
            this.pnlStatus.TabIndex = 35;
            // 
            // lblFreezeTAN_Cnt
            // 
            this.lblFreezeTAN_Cnt.AutoSize = true;
            this.lblFreezeTAN_Cnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFreezeTAN_Cnt.ForeColor = System.Drawing.Color.Red;
            this.lblFreezeTAN_Cnt.Location = new System.Drawing.Point(101, 27);
            this.lblFreezeTAN_Cnt.Name = "lblFreezeTAN_Cnt";
            this.lblFreezeTAN_Cnt.Size = new System.Drawing.Size(16, 17);
            this.lblFreezeTAN_Cnt.TabIndex = 54;
            this.lblFreezeTAN_Cnt.Text = "0";
            // 
            // lblFreeze
            // 
            this.lblFreeze.AutoSize = true;
            this.lblFreeze.Location = new System.Drawing.Point(2, 28);
            this.lblFreeze.Name = "lblFreeze";
            this.lblFreeze.Size = new System.Drawing.Size(98, 17);
            this.lblFreeze.TabIndex = 53;
            this.lblFreeze.Text = "Freezed TANs:";
            // 
            // lblReAssCur_Cnt
            // 
            this.lblReAssCur_Cnt.AutoSize = true;
            this.lblReAssCur_Cnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReAssCur_Cnt.ForeColor = System.Drawing.Color.Red;
            this.lblReAssCur_Cnt.Location = new System.Drawing.Point(1054, 28);
            this.lblReAssCur_Cnt.Name = "lblReAssCur_Cnt";
            this.lblReAssCur_Cnt.Size = new System.Drawing.Size(16, 17);
            this.lblReAssCur_Cnt.TabIndex = 52;
            this.lblReAssCur_Cnt.Text = "0";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(886, 29);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(162, 17);
            this.label14.TabIndex = 51;
            this.label14.Text = "Re-Assigned for Curation:";
            // 
            // lblReAssRev_Cnt
            // 
            this.lblReAssRev_Cnt.AutoSize = true;
            this.lblReAssRev_Cnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReAssRev_Cnt.ForeColor = System.Drawing.Color.Red;
            this.lblReAssRev_Cnt.Location = new System.Drawing.Point(848, 28);
            this.lblReAssRev_Cnt.Name = "lblReAssRev_Cnt";
            this.lblReAssRev_Cnt.Size = new System.Drawing.Size(16, 17);
            this.lblReAssRev_Cnt.TabIndex = 50;
            this.lblReAssRev_Cnt.Text = "0";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(689, 28);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(157, 17);
            this.label13.TabIndex = 49;
            this.label13.Text = "Re-Assigned for Review:";
            // 
            // lblReAssQC_Cnt
            // 
            this.lblReAssQC_Cnt.AutoSize = true;
            this.lblReAssQC_Cnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReAssQC_Cnt.ForeColor = System.Drawing.Color.Red;
            this.lblReAssQC_Cnt.Location = new System.Drawing.Point(644, 28);
            this.lblReAssQC_Cnt.Name = "lblReAssQC_Cnt";
            this.lblReAssQC_Cnt.Size = new System.Drawing.Size(16, 17);
            this.lblReAssQC_Cnt.TabIndex = 48;
            this.lblReAssQC_Cnt.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(505, 28);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(133, 17);
            this.label12.TabIndex = 47;
            this.label12.Text = "Re-Assigned for QC:";
            // 
            // lblAssQC_Cnt
            // 
            this.lblAssQC_Cnt.AutoSize = true;
            this.lblAssQC_Cnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAssQC_Cnt.ForeColor = System.Drawing.Color.Red;
            this.lblAssQC_Cnt.Location = new System.Drawing.Point(644, 3);
            this.lblAssQC_Cnt.Name = "lblAssQC_Cnt";
            this.lblAssQC_Cnt.Size = new System.Drawing.Size(16, 17);
            this.lblAssQC_Cnt.TabIndex = 46;
            this.lblAssQC_Cnt.Text = "0";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(527, 4);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(111, 17);
            this.label11.TabIndex = 45;
            this.label11.Text = "Assigned for QC:";
            // 
            // lblAssRev_Cnt
            // 
            this.lblAssRev_Cnt.AutoSize = true;
            this.lblAssRev_Cnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAssRev_Cnt.ForeColor = System.Drawing.Color.Red;
            this.lblAssRev_Cnt.Location = new System.Drawing.Point(847, 3);
            this.lblAssRev_Cnt.Name = "lblAssRev_Cnt";
            this.lblAssRev_Cnt.Size = new System.Drawing.Size(16, 17);
            this.lblAssRev_Cnt.TabIndex = 44;
            this.lblAssRev_Cnt.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(711, 5);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(135, 17);
            this.label10.TabIndex = 43;
            this.label10.Text = "Assigned for Review:";
            // 
            // lblAssCur_Cnt
            // 
            this.lblAssCur_Cnt.AutoSize = true;
            this.lblAssCur_Cnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAssCur_Cnt.ForeColor = System.Drawing.Color.Red;
            this.lblAssCur_Cnt.Location = new System.Drawing.Point(1054, 3);
            this.lblAssCur_Cnt.Name = "lblAssCur_Cnt";
            this.lblAssCur_Cnt.Size = new System.Drawing.Size(16, 17);
            this.lblAssCur_Cnt.TabIndex = 42;
            this.lblAssCur_Cnt.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(908, 6);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(140, 17);
            this.label9.TabIndex = 41;
            this.label9.Text = "Assigned for Curation:";
            // 
            // lblCur_Done_Cnt
            // 
            this.lblCur_Done_Cnt.AutoSize = true;
            this.lblCur_Done_Cnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCur_Done_Cnt.ForeColor = System.Drawing.Color.Red;
            this.lblCur_Done_Cnt.Location = new System.Drawing.Point(470, 3);
            this.lblCur_Done_Cnt.Name = "lblCur_Done_Cnt";
            this.lblCur_Done_Cnt.Size = new System.Drawing.Size(16, 17);
            this.lblCur_Done_Cnt.TabIndex = 40;
            this.lblCur_Done_Cnt.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(341, 4);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(128, 17);
            this.label8.TabIndex = 39;
            this.label8.Text = "Curation Completed:";
            // 
            // lblRev_Done_Cnt
            // 
            this.lblRev_Done_Cnt.AutoSize = true;
            this.lblRev_Done_Cnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRev_Done_Cnt.ForeColor = System.Drawing.Color.Red;
            this.lblRev_Done_Cnt.Location = new System.Drawing.Point(283, 3);
            this.lblRev_Done_Cnt.Name = "lblRev_Done_Cnt";
            this.lblRev_Done_Cnt.Size = new System.Drawing.Size(16, 17);
            this.lblRev_Done_Cnt.TabIndex = 38;
            this.lblRev_Done_Cnt.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(158, 4);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 17);
            this.label7.TabIndex = 37;
            this.label7.Text = "Review Completed:";
            // 
            // lblQC_Done_Cnt
            // 
            this.lblQC_Done_Cnt.AutoSize = true;
            this.lblQC_Done_Cnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQC_Done_Cnt.ForeColor = System.Drawing.Color.Red;
            this.lblQC_Done_Cnt.Location = new System.Drawing.Point(101, 3);
            this.lblQC_Done_Cnt.Name = "lblQC_Done_Cnt";
            this.lblQC_Done_Cnt.Size = new System.Drawing.Size(16, 17);
            this.lblQC_Done_Cnt.TabIndex = 36;
            this.lblQC_Done_Cnt.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(2, 4);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 17);
            this.label5.TabIndex = 30;
            this.label5.Text = "QC Completed:";
            // 
            // lblSelTANCnt
            // 
            this.lblSelTANCnt.AutoSize = true;
            this.lblSelTANCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelTANCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblSelTANCnt.Location = new System.Drawing.Point(809, 3);
            this.lblSelTANCnt.Name = "lblSelTANCnt";
            this.lblSelTANCnt.Size = new System.Drawing.Size(16, 17);
            this.lblSelTANCnt.TabIndex = 34;
            this.lblSelTANCnt.Text = "0";
            // 
            // lblSel_Cnt
            // 
            this.lblSel_Cnt.AutoSize = true;
            this.lblSel_Cnt.Location = new System.Drawing.Point(753, 4);
            this.lblSel_Cnt.Name = "lblSel_Cnt";
            this.lblSel_Cnt.Size = new System.Drawing.Size(50, 17);
            this.lblSel_Cnt.TabIndex = 33;
            this.lblSel_Cnt.Text = "Count: ";
            // 
            // lblSelTANs
            // 
            this.lblSelTANs.AutoSize = true;
            this.lblSelTANs.Location = new System.Drawing.Point(629, 4);
            this.lblSelTANs.Name = "lblSelTANs";
            this.lblSelTANs.Size = new System.Drawing.Size(98, 17);
            this.lblSelTANs.TabIndex = 32;
            this.lblSelTANs.Text = "Selected TANs";
            // 
            // lblAvlTANCnt
            // 
            this.lblAvlTANCnt.AutoSize = true;
            this.lblAvlTANCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAvlTANCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblAvlTANCnt.Location = new System.Drawing.Point(232, 3);
            this.lblAvlTANCnt.Name = "lblAvlTANCnt";
            this.lblAvlTANCnt.Size = new System.Drawing.Size(16, 17);
            this.lblAvlTANCnt.TabIndex = 31;
            this.lblAvlTANCnt.Text = "0";
            // 
            // lblAvl_Cnt
            // 
            this.lblAvl_Cnt.AutoSize = true;
            this.lblAvl_Cnt.Location = new System.Drawing.Point(176, 4);
            this.lblAvl_Cnt.Name = "lblAvl_Cnt";
            this.lblAvl_Cnt.Size = new System.Drawing.Size(50, 17);
            this.lblAvl_Cnt.TabIndex = 30;
            this.lblAvl_Cnt.Text = "Count: ";
            // 
            // lblAvailTANs
            // 
            this.lblAvailTANs.AutoSize = true;
            this.lblAvailTANs.Location = new System.Drawing.Point(3, 4);
            this.lblAvailTANs.Name = "lblAvailTANs";
            this.lblAvailTANs.Size = new System.Drawing.Size(102, 17);
            this.lblAvailTANs.TabIndex = 29;
            this.lblAvailTANs.Text = "Available TANs";
            // 
            // dgvSelectedTANs
            // 
            this.dgvSelectedTANs.AllowUserToAddRows = false;
            this.dgvSelectedTANs.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvSelectedTANs.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSelectedTANs.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvSelectedTANs.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvSelectedTANs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSelectedTANs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTAN_ID_Sel,
            this.colTAN_Sel,
            this.colBNo_Sel,
            this.colTANType_Sel,
            this.colRxnCnt_Sel,
            this.colIsFreezed_Sel,
            this.colTANStatus_Sel,
            this.colDocClass_Sel,
            this.colTANPriority_Sel,
            this.colQueryTAN_Sel});
            this.dgvSelectedTANs.Location = new System.Drawing.Point(631, 25);
            this.dgvSelectedTANs.Name = "dgvSelectedTANs";
            this.dgvSelectedTANs.ReadOnly = true;
            this.dgvSelectedTANs.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.dgvSelectedTANs.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvSelectedTANs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSelectedTANs.Size = new System.Drawing.Size(590, 268);
            this.dgvSelectedTANs.TabIndex = 12;
            this.dgvSelectedTANs.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvSelectedTANs_RowPostPaint);
            // 
            // btnDelOne
            // 
            this.btnDelOne.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelOne.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelOne.Location = new System.Drawing.Point(598, 147);
            this.btnDelOne.Name = "btnDelOne";
            this.btnDelOne.Size = new System.Drawing.Size(30, 41);
            this.btnDelOne.TabIndex = 11;
            this.btnDelOne.Text = "<";
            this.btnDelOne.UseVisualStyleBackColor = true;
            this.btnDelOne.Click += new System.EventHandler(this.btnDelOne_Click);
            // 
            // btnSelOne
            // 
            this.btnSelOne.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSelOne.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelOne.Location = new System.Drawing.Point(598, 96);
            this.btnSelOne.Name = "btnSelOne";
            this.btnSelOne.Size = new System.Drawing.Size(30, 40);
            this.btnSelOne.TabIndex = 10;
            this.btnSelOne.Text = ">";
            this.btnSelOne.UseVisualStyleBackColor = true;
            this.btnSelOne.Click += new System.EventHandler(this.btnSelOne_Click);
            // 
            // dgvAvailableTANs
            // 
            this.dgvAvailableTANs.AllowUserToAddRows = false;
            this.dgvAvailableTANs.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvAvailableTANs.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvAvailableTANs.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dgvAvailableTANs.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvAvailableTANs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAvailableTANs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTAN_ID_Avail,
            this.colTAN_Avail,
            this.colBNo_Avail,
            this.colTANType_Avail,
            this.colRxnCnt,
            this.colIsFreezed_Avail,
            this.colTanStatus,
            this.colDocClass_Avl,
            this.colTANPriority_Avl,
            this.colQueryTAN_Avl});
            this.dgvAvailableTANs.Location = new System.Drawing.Point(0, 24);
            this.dgvAvailableTANs.Name = "dgvAvailableTANs";
            this.dgvAvailableTANs.ReadOnly = true;
            this.dgvAvailableTANs.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.dgvAvailableTANs.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvAvailableTANs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAvailableTANs.Size = new System.Drawing.Size(592, 269);
            this.dgvAvailableTANs.TabIndex = 0;
            this.dgvAvailableTANs.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgTANs_RowPostPaint);
            // 
            // dgvXmlTANs
            // 
            this.dgvXmlTANs.AllowUserToAddRows = false;
            this.dgvXmlTANs.AllowUserToDeleteRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvXmlTANs.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvXmlTANs.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvXmlTANs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvXmlTANs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTAN_ID_Xml,
            this.colTAN_Xml,
            this.colTANType_Xml,
            this.colRxnCnt_Xml,
            this.colBatch_Xml,
            this.colBNo_Xml,
            this.colTANStatus_Xml,
            this.colDocClass_Xml,
            this.colTANPriority_Xml,
            this.colQueryTAN_Xml});
            this.dgvXmlTANs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvXmlTANs.Location = new System.Drawing.Point(0, 31);
            this.dgvXmlTANs.Name = "dgvXmlTANs";
            this.dgvXmlTANs.ReadOnly = true;
            this.dgvXmlTANs.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.dgvXmlTANs.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvXmlTANs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvXmlTANs.Size = new System.Drawing.Size(1225, 164);
            this.dgvXmlTANs.TabIndex = 1;
            this.dgvXmlTANs.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvXmlTANs_RowPostPaint);
            // 
            // pnlXML
            // 
            this.pnlXML.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlXML.Controls.Add(this.lblXmlTANCnt);
            this.pnlXML.Controls.Add(this.lbl);
            this.pnlXML.Controls.Add(this.btnAppend);
            this.pnlXML.Controls.Add(this.label4);
            this.pnlXML.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlXML.Location = new System.Drawing.Point(0, 0);
            this.pnlXML.Name = "pnlXML";
            this.pnlXML.Size = new System.Drawing.Size(1225, 31);
            this.pnlXML.TabIndex = 14;
            // 
            // lblXmlTANCnt
            // 
            this.lblXmlTANCnt.AutoSize = true;
            this.lblXmlTANCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblXmlTANCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblXmlTANCnt.Location = new System.Drawing.Point(287, 6);
            this.lblXmlTANCnt.Name = "lblXmlTANCnt";
            this.lblXmlTANCnt.Size = new System.Drawing.Size(16, 17);
            this.lblXmlTANCnt.TabIndex = 33;
            this.lblXmlTANCnt.Text = "0";
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Location = new System.Drawing.Point(231, 6);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(50, 17);
            this.lbl.TabIndex = 32;
            this.lbl.Text = "Count: ";
            // 
            // btnAppend
            // 
            this.btnAppend.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAppend.AutoSize = true;
            this.btnAppend.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAppend.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAppend.Location = new System.Drawing.Point(1147, 2);
            this.btnAppend.Name = "btnAppend";
            this.btnAppend.Size = new System.Drawing.Size(73, 25);
            this.btnAppend.TabIndex = 17;
            this.btnAppend.Text = "Append";
            this.btnAppend.UseVisualStyleBackColor = true;
            this.btnAppend.Click += new System.EventHandler(this.btnAppend_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(4, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(190, 17);
            this.label4.TabIndex = 14;
            this.label4.Text = "TANs for XML file generation:";
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.White;
            this.pnlTop.Controls.Add(this.lblTAN);
            this.pnlTop.Controls.Add(this.txtTANSrch);
            this.pnlTop.Controls.Add(this.label2);
            this.pnlTop.Controls.Add(this.txtBNo);
            this.pnlTop.Controls.Add(this.label1);
            this.pnlTop.Controls.Add(this.txtBatchName);
            this.pnlTop.Controls.Add(this.btnGetTans);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1229, 31);
            this.pnlTop.TabIndex = 12;
            // 
            // lblTAN
            // 
            this.lblTAN.AutoSize = true;
            this.lblTAN.ForeColor = System.Drawing.Color.Black;
            this.lblTAN.Location = new System.Drawing.Point(547, 7);
            this.lblTAN.Name = "lblTAN";
            this.lblTAN.Size = new System.Drawing.Size(83, 17);
            this.lblTAN.TabIndex = 26;
            this.lblTAN.Text = "TAN Search";
            // 
            // txtTANSrch
            // 
            this.txtTANSrch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTANSrch.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.txtTANSrch.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTANSrch.ForeColor = System.Drawing.Color.Blue;
            this.txtTANSrch.Location = new System.Drawing.Point(633, 3);
            this.txtTANSrch.Name = "txtTANSrch";
            this.txtTANSrch.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtTANSrch.Size = new System.Drawing.Size(590, 25);
            this.txtTANSrch.TabIndex = 25;
            this.txtTANSrch.TextChanged += new System.EventHandler(this.txtTANSrch_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(311, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "Batch No.";
            // 
            // txtBNo
            // 
            this.txtBNo.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBNo.ForeColor = System.Drawing.Color.Red;
            this.txtBNo.Location = new System.Drawing.Point(380, 5);
            this.txtBNo.Name = "txtBNo";
            this.txtBNo.Size = new System.Drawing.Size(40, 21);
            this.txtBNo.TabIndex = 10;
            this.txtBNo.Text = "1";
            this.txtBNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(2, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Shipment Name";
            // 
            // txtBatchName
            // 
            this.txtBatchName.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBatchName.ForeColor = System.Drawing.Color.Red;
            this.txtBatchName.Location = new System.Drawing.Point(107, 5);
            this.txtBatchName.Name = "txtBatchName";
            this.txtBatchName.Size = new System.Drawing.Size(199, 21);
            this.txtBatchName.TabIndex = 1;
            // 
            // btnGetTans
            // 
            this.btnGetTans.AutoSize = true;
            this.btnGetTans.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGetTans.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGetTans.Location = new System.Drawing.Point(430, 3);
            this.btnGetTans.Name = "btnGetTans";
            this.btnGetTans.Size = new System.Drawing.Size(80, 25);
            this.btnGetTans.TabIndex = 8;
            this.btnGetTans.Text = "Get";
            this.btnGetTans.UseVisualStyleBackColor = true;
            this.btnGetTans.Click += new System.EventHandler(this.btnGetTans_Click);
            // 
            // pnlBottom
            // 
            this.pnlBottom.BackColor = System.Drawing.Color.White;
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlBottom.Controls.Add(this.btnBrowsePdfFolder);
            this.pnlBottom.Controls.Add(this.label6);
            this.pnlBottom.Controls.Add(this.txtMarkupsPath);
            this.pnlBottom.Controls.Add(this.lblFileName);
            this.pnlBottom.Controls.Add(this.txtFileName);
            this.pnlBottom.Controls.Add(this.btnBrowse);
            this.pnlBottom.Controls.Add(this.label3);
            this.pnlBottom.Controls.Add(this.txtFilePath);
            this.pnlBottom.Controls.Add(this.btnXml);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 583);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(1229, 61);
            this.pnlBottom.TabIndex = 10;
            // 
            // btnBrowsePdfFolder
            // 
            this.btnBrowsePdfFolder.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowsePdfFolder.Location = new System.Drawing.Point(773, 30);
            this.btnBrowsePdfFolder.Name = "btnBrowsePdfFolder";
            this.btnBrowsePdfFolder.Size = new System.Drawing.Size(52, 24);
            this.btnBrowsePdfFolder.TabIndex = 24;
            this.btnBrowsePdfFolder.Text = "...";
            this.btnBrowsePdfFolder.UseVisualStyleBackColor = true;
            this.btnBrowsePdfFolder.Click += new System.EventHandler(this.btnBrowsePdfFolder_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(4, 32);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(123, 17);
            this.label6.TabIndex = 23;
            this.label6.Text = "Markup PDFs Path";
            // 
            // txtMarkupsPath
            // 
            this.txtMarkupsPath.BackColor = System.Drawing.Color.White;
            this.txtMarkupsPath.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMarkupsPath.ForeColor = System.Drawing.Color.Black;
            this.txtMarkupsPath.Location = new System.Drawing.Point(127, 30);
            this.txtMarkupsPath.Name = "txtMarkupsPath";
            this.txtMarkupsPath.ReadOnly = true;
            this.txtMarkupsPath.Size = new System.Drawing.Size(638, 21);
            this.txtMarkupsPath.TabIndex = 22;
            // 
            // lblFileName
            // 
            this.lblFileName.AutoSize = true;
            this.lblFileName.ForeColor = System.Drawing.Color.Black;
            this.lblFileName.Location = new System.Drawing.Point(4, 6);
            this.lblFileName.Name = "lblFileName";
            this.lblFileName.Size = new System.Drawing.Size(117, 17);
            this.lblFileName.TabIndex = 14;
            this.lblFileName.Text = " Output File Name";
            // 
            // txtFileName
            // 
            this.txtFileName.BackColor = System.Drawing.Color.White;
            this.txtFileName.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFileName.ForeColor = System.Drawing.Color.Black;
            this.txtFileName.Location = new System.Drawing.Point(127, 4);
            this.txtFileName.Name = "txtFileName";
            this.txtFileName.Size = new System.Drawing.Size(202, 21);
            this.txtFileName.TabIndex = 13;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowse.Location = new System.Drawing.Point(773, 3);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(52, 24);
            this.btnBrowse.TabIndex = 12;
            this.btnBrowse.Text = "...";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(348, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 17);
            this.label3.TabIndex = 11;
            this.label3.Text = "Output Folder Path";
            // 
            // txtFilePath
            // 
            this.txtFilePath.BackColor = System.Drawing.Color.White;
            this.txtFilePath.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFilePath.ForeColor = System.Drawing.Color.Black;
            this.txtFilePath.Location = new System.Drawing.Point(474, 4);
            this.txtFilePath.Name = "txtFilePath";
            this.txtFilePath.ReadOnly = true;
            this.txtFilePath.Size = new System.Drawing.Size(291, 21);
            this.txtFilePath.TabIndex = 10;
            // 
            // btnXml
            // 
            this.btnXml.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnXml.AutoSize = true;
            this.btnXml.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnXml.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXml.Location = new System.Drawing.Point(1148, 3);
            this.btnXml.Name = "btnXml";
            this.btnXml.Size = new System.Drawing.Size(73, 25);
            this.btnXml.TabIndex = 9;
            this.btnXml.Text = "Generate";
            this.btnXml.UseVisualStyleBackColor = true;
            this.btnXml.Click += new System.EventHandler(this.btnXml_Click);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn1.HeaderText = "TAN";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn2.FillWeight = 50F;
            this.dataGridViewTextBoxColumn2.HeaderText = "BNo";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Width = 40;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn3.FillWeight = 50F;
            this.dataGridViewTextBoxColumn3.HeaderText = "Type";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 60;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn4.FillWeight = 50F;
            this.dataGridViewTextBoxColumn4.HeaderText = "Rxns";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 40;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn5.FillWeight = 50F;
            this.dataGridViewTextBoxColumn5.HeaderText = "Freezed";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn5.Width = 40;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn6.HeaderText = "TANStatus";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn7.HeaderText = "DocClass";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 127;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn8.HeaderText = "Priority";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Width = 40;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn9.HeaderText = "TAN";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn9.Width = 40;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn10.FillWeight = 50F;
            this.dataGridViewTextBoxColumn10.HeaderText = "BNo";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Visible = false;
            this.dataGridViewTextBoxColumn10.Width = 40;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "Type";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Visible = false;
            this.dataGridViewTextBoxColumn11.Width = 60;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn12.FillWeight = 50F;
            this.dataGridViewTextBoxColumn12.HeaderText = "Rxns";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn12.Width = 40;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn13.FillWeight = 50F;
            this.dataGridViewTextBoxColumn13.HeaderText = "Freezed";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Width = 40;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn14.FillWeight = 50F;
            this.dataGridViewTextBoxColumn14.HeaderText = "TANStatus";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn15.FillWeight = 50F;
            this.dataGridViewTextBoxColumn15.HeaderText = "DocClass";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Width = 40;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn16.HeaderText = "Priority";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.Width = 40;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn17.HeaderText = "TAN";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn17.Width = 121;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn18.HeaderText = "Type";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            this.dataGridViewTextBoxColumn18.Width = 40;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn19.FillWeight = 50F;
            this.dataGridViewTextBoxColumn19.HeaderText = "RxnCount";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            this.dataGridViewTextBoxColumn19.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn19.Visible = false;
            this.dataGridViewTextBoxColumn19.Width = 70;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.FillWeight = 150F;
            this.dataGridViewTextBoxColumn20.HeaderText = "Batch";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn20.Width = 150;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.FillWeight = 50F;
            this.dataGridViewTextBoxColumn21.HeaderText = "BNo";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            this.dataGridViewTextBoxColumn21.Visible = false;
            this.dataGridViewTextBoxColumn21.Width = 60;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn22.FillWeight = 50F;
            this.dataGridViewTextBoxColumn22.HeaderText = "TAN Status";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            this.dataGridViewTextBoxColumn22.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.FillWeight = 150F;
            this.dataGridViewTextBoxColumn23.HeaderText = "Doc Class";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            this.dataGridViewTextBoxColumn23.Width = 150;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.FillWeight = 50F;
            this.dataGridViewTextBoxColumn24.HeaderText = "Priority";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            this.dataGridViewTextBoxColumn24.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn24.Width = 60;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn25.FillWeight = 150F;
            this.dataGridViewTextBoxColumn25.HeaderText = "TAN Status";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.FillWeight = 50F;
            this.dataGridViewTextBoxColumn26.HeaderText = "Doc Class";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.ReadOnly = true;
            this.dataGridViewTextBoxColumn26.Width = 60;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn27.HeaderText = "Priority";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.HeaderText = "Doc Class";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.HeaderText = "Priority";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.HeaderText = "QueryTAN";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            // 
            // colTAN_ID_Sel
            // 
            this.colTAN_ID_Sel.HeaderText = "TAN_ID";
            this.colTAN_ID_Sel.Name = "colTAN_ID_Sel";
            this.colTAN_ID_Sel.ReadOnly = true;
            this.colTAN_ID_Sel.Visible = false;
            // 
            // colTAN_Sel
            // 
            this.colTAN_Sel.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colTAN_Sel.HeaderText = "TAN";
            this.colTAN_Sel.Name = "colTAN_Sel";
            this.colTAN_Sel.ReadOnly = true;
            this.colTAN_Sel.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colBNo_Sel
            // 
            this.colBNo_Sel.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colBNo_Sel.FillWeight = 50F;
            this.colBNo_Sel.HeaderText = "BNo";
            this.colBNo_Sel.Name = "colBNo_Sel";
            this.colBNo_Sel.ReadOnly = true;
            this.colBNo_Sel.Width = 40;
            // 
            // colTANType_Sel
            // 
            this.colTANType_Sel.HeaderText = "Type";
            this.colTANType_Sel.Name = "colTANType_Sel";
            this.colTANType_Sel.ReadOnly = true;
            this.colTANType_Sel.Width = 60;
            // 
            // colRxnCnt_Sel
            // 
            this.colRxnCnt_Sel.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colRxnCnt_Sel.FillWeight = 50F;
            this.colRxnCnt_Sel.HeaderText = "Rxns";
            this.colRxnCnt_Sel.Name = "colRxnCnt_Sel";
            this.colRxnCnt_Sel.ReadOnly = true;
            this.colRxnCnt_Sel.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colRxnCnt_Sel.Width = 40;
            // 
            // colIsFreezed_Sel
            // 
            this.colIsFreezed_Sel.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colIsFreezed_Sel.HeaderText = "Freezed";
            this.colIsFreezed_Sel.Name = "colIsFreezed_Sel";
            this.colIsFreezed_Sel.ReadOnly = true;
            this.colIsFreezed_Sel.Width = 40;
            // 
            // colTANStatus_Sel
            // 
            this.colTANStatus_Sel.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colTANStatus_Sel.HeaderText = "TANStatus";
            this.colTANStatus_Sel.Name = "colTANStatus_Sel";
            this.colTANStatus_Sel.ReadOnly = true;
            // 
            // colDocClass_Sel
            // 
            this.colDocClass_Sel.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colDocClass_Sel.HeaderText = "DocClass";
            this.colDocClass_Sel.Name = "colDocClass_Sel";
            this.colDocClass_Sel.ReadOnly = true;
            // 
            // colTANPriority_Sel
            // 
            this.colTANPriority_Sel.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colTANPriority_Sel.HeaderText = "Priority";
            this.colTANPriority_Sel.Name = "colTANPriority_Sel";
            this.colTANPriority_Sel.ReadOnly = true;
            this.colTANPriority_Sel.Width = 40;
            // 
            // colQueryTAN_Sel
            // 
            this.colQueryTAN_Sel.HeaderText = "QueryTAN";
            this.colQueryTAN_Sel.Name = "colQueryTAN_Sel";
            this.colQueryTAN_Sel.ReadOnly = true;
            // 
            // colTAN_ID_Avail
            // 
            this.colTAN_ID_Avail.HeaderText = "TAN_ID";
            this.colTAN_ID_Avail.Name = "colTAN_ID_Avail";
            this.colTAN_ID_Avail.ReadOnly = true;
            this.colTAN_ID_Avail.Visible = false;
            // 
            // colTAN_Avail
            // 
            this.colTAN_Avail.HeaderText = "TAN";
            this.colTAN_Avail.Name = "colTAN_Avail";
            this.colTAN_Avail.ReadOnly = true;
            // 
            // colBNo_Avail
            // 
            this.colBNo_Avail.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colBNo_Avail.FillWeight = 50F;
            this.colBNo_Avail.HeaderText = "BNo";
            this.colBNo_Avail.Name = "colBNo_Avail";
            this.colBNo_Avail.ReadOnly = true;
            this.colBNo_Avail.Width = 40;
            // 
            // colTANType_Avail
            // 
            this.colTANType_Avail.HeaderText = "Type";
            this.colTANType_Avail.Name = "colTANType_Avail";
            this.colTANType_Avail.ReadOnly = true;
            this.colTANType_Avail.Width = 60;
            // 
            // colRxnCnt
            // 
            this.colRxnCnt.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colRxnCnt.FillWeight = 50F;
            this.colRxnCnt.HeaderText = "Rxns";
            this.colRxnCnt.Name = "colRxnCnt";
            this.colRxnCnt.ReadOnly = true;
            this.colRxnCnt.Width = 40;
            // 
            // colIsFreezed_Avail
            // 
            this.colIsFreezed_Avail.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colIsFreezed_Avail.HeaderText = "Freezed";
            this.colIsFreezed_Avail.Name = "colIsFreezed_Avail";
            this.colIsFreezed_Avail.ReadOnly = true;
            this.colIsFreezed_Avail.Width = 40;
            // 
            // colTanStatus
            // 
            this.colTanStatus.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colTanStatus.HeaderText = "TANStatus";
            this.colTanStatus.Name = "colTanStatus";
            this.colTanStatus.ReadOnly = true;
            // 
            // colDocClass_Avl
            // 
            this.colDocClass_Avl.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colDocClass_Avl.HeaderText = "DocClass";
            this.colDocClass_Avl.Name = "colDocClass_Avl";
            this.colDocClass_Avl.ReadOnly = true;
            // 
            // colTANPriority_Avl
            // 
            this.colTANPriority_Avl.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colTANPriority_Avl.HeaderText = "Priority";
            this.colTANPriority_Avl.Name = "colTANPriority_Avl";
            this.colTANPriority_Avl.ReadOnly = true;
            this.colTANPriority_Avl.Width = 40;
            // 
            // colQueryTAN_Avl
            // 
            this.colQueryTAN_Avl.HeaderText = "QueryTAN";
            this.colQueryTAN_Avl.Name = "colQueryTAN_Avl";
            this.colQueryTAN_Avl.ReadOnly = true;
            // 
            // colTAN_ID_Xml
            // 
            this.colTAN_ID_Xml.HeaderText = "TAN_ID";
            this.colTAN_ID_Xml.Name = "colTAN_ID_Xml";
            this.colTAN_ID_Xml.ReadOnly = true;
            this.colTAN_ID_Xml.Visible = false;
            // 
            // colTAN_Xml
            // 
            this.colTAN_Xml.HeaderText = "TAN";
            this.colTAN_Xml.Name = "colTAN_Xml";
            this.colTAN_Xml.ReadOnly = true;
            this.colTAN_Xml.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colTAN_Xml.Width = 121;
            // 
            // colTANType_Xml
            // 
            this.colTANType_Xml.HeaderText = "Type";
            this.colTANType_Xml.Name = "colTANType_Xml";
            this.colTANType_Xml.ReadOnly = true;
            // 
            // colRxnCnt_Xml
            // 
            this.colRxnCnt_Xml.FillWeight = 50F;
            this.colRxnCnt_Xml.HeaderText = "RxnCount";
            this.colRxnCnt_Xml.Name = "colRxnCnt_Xml";
            this.colRxnCnt_Xml.ReadOnly = true;
            this.colRxnCnt_Xml.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colRxnCnt_Xml.Width = 70;
            // 
            // colBatch_Xml
            // 
            this.colBatch_Xml.FillWeight = 150F;
            this.colBatch_Xml.HeaderText = "Batch";
            this.colBatch_Xml.Name = "colBatch_Xml";
            this.colBatch_Xml.ReadOnly = true;
            this.colBatch_Xml.Width = 150;
            // 
            // colBNo_Xml
            // 
            this.colBNo_Xml.FillWeight = 50F;
            this.colBNo_Xml.HeaderText = "BNo";
            this.colBNo_Xml.Name = "colBNo_Xml";
            this.colBNo_Xml.ReadOnly = true;
            this.colBNo_Xml.Width = 60;
            // 
            // colTANStatus_Xml
            // 
            this.colTANStatus_Xml.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colTANStatus_Xml.HeaderText = "TAN Status";
            this.colTANStatus_Xml.Name = "colTANStatus_Xml";
            this.colTANStatus_Xml.ReadOnly = true;
            // 
            // colDocClass_Xml
            // 
            this.colDocClass_Xml.HeaderText = "Doc Class";
            this.colDocClass_Xml.Name = "colDocClass_Xml";
            this.colDocClass_Xml.ReadOnly = true;
            // 
            // colTANPriority_Xml
            // 
            this.colTANPriority_Xml.HeaderText = "Priority";
            this.colTANPriority_Xml.Name = "colTANPriority_Xml";
            this.colTANPriority_Xml.ReadOnly = true;
            // 
            // colQueryTAN_Xml
            // 
            this.colQueryTAN_Xml.HeaderText = "QueryTAN";
            this.colQueryTAN_Xml.Name = "colQueryTAN_Xml";
            this.colQueryTAN_Xml.ReadOnly = true;
            // 
            // frmBatchXml
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1229, 644);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmBatchXml";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Batch XML";
            this.Load += new System.EventHandler(this.frmBatchXml_Load);
            this.pnlMain.ResumeLayout(false);
            this.splCont.Panel1.ResumeLayout(false);
            this.splCont.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splCont)).EndInit();
            this.splCont.ResumeLayout(false);
            this.pnlGrid.ResumeLayout(false);
            this.pnlGrid.PerformLayout();
            this.pnlStatus.ResumeLayout(false);
            this.pnlStatus.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSelectedTANs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAvailableTANs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvXmlTANs)).EndInit();
            this.pnlXML.ResumeLayout(false);
            this.pnlXML.PerformLayout();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBatchName;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Button btnXml;
        private System.Windows.Forms.Panel pnlGrid;
        private System.Windows.Forms.Button btnGetTans;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.DataGridView dgvAvailableTANs;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtFilePath;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBNo;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Label lblFileName;
        private System.Windows.Forms.TextBox txtFileName;
        private System.Windows.Forms.DataGridView dgvXmlTANs;
        private System.Windows.Forms.Button btnDelOne;
        private System.Windows.Forms.Button btnSelOne;
        private System.Windows.Forms.DataGridView dgvSelectedTANs;
        private System.Windows.Forms.Label lblAvlTANCnt;
        private System.Windows.Forms.Label lblAvl_Cnt;
        private System.Windows.Forms.Label lblAvailTANs;
        private System.Windows.Forms.Label lblSelTANCnt;
        private System.Windows.Forms.Label lblSel_Cnt;
        private System.Windows.Forms.Label lblSelTANs;
        private System.Windows.Forms.SplitContainer splCont;
        private System.Windows.Forms.Label lblTAN;
        private System.Windows.Forms.TextBox txtTANSrch;
        private System.Windows.Forms.Panel pnlXML;
        private System.Windows.Forms.Button btnAppend;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblXmlTANCnt;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.Panel pnlStatus;
        private System.Windows.Forms.Label lblQC_Done_Cnt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblCur_Done_Cnt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblRev_Done_Cnt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblAssQC_Cnt;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblAssRev_Cnt;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblAssCur_Cnt;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblReAssCur_Cnt;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblReAssRev_Cnt;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblReAssQC_Cnt;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblFreezeTAN_Cnt;
        private System.Windows.Forms.Label lblFreeze;
        private System.Windows.Forms.CheckBox chkSkipQcCheck;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.Button btnBrowsePdfFolder;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtMarkupsPath;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTAN_ID_Sel;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTAN_Sel;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBNo_Sel;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTANType_Sel;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnCnt_Sel;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIsFreezed_Sel;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTANStatus_Sel;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDocClass_Sel;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTANPriority_Sel;
        private System.Windows.Forms.DataGridViewTextBoxColumn colQueryTAN_Sel;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTAN_ID_Avail;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTAN_Avail;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBNo_Avail;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTANType_Avail;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnCnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIsFreezed_Avail;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTanStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDocClass_Avl;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTANPriority_Avl;
        private System.Windows.Forms.DataGridViewTextBoxColumn colQueryTAN_Avl;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTAN_ID_Xml;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTAN_Xml;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTANType_Xml;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnCnt_Xml;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBatch_Xml;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBNo_Xml;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTANStatus_Xml;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDocClass_Xml;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTANPriority_Xml;
        private System.Windows.Forms.DataGridViewTextBoxColumn colQueryTAN_Xml;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
    }
}