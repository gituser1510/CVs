﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using IndxReactNarr.Generic;
using Ionic.Zip;
using IndxReactNarr.Common;

namespace IndxReactNarr
{
    public partial class frmCreateMarkupFolder : Form
    {
        public frmCreateMarkupFolder()
        {
            InitializeComponent();
        }

        private void btnSelectFolder_Click(object sender, EventArgs e)
        {
            try
            {
                if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
                {
                    txtFolder.Text = folderBrowserDialog1.SelectedPath;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private bool GenerateTANwiseFolders(string outputFolderPath, string pdfFolderPath, string batchName)
        {
            bool blStatus = false;
            try
            {
                if (!string.IsNullOrEmpty(pdfFolderPath))
                {
                    if (Directory.Exists(pdfFolderPath))
                    {
                        //Get distinct TANs from the pdf folder
                        List<string> lstTANs = GetDistinctTANsFromFolder(pdfFolderPath);

                        if (lstTANs != null)
                        {
                            string mainFolder = "";
                            string subFolder = "";

                            //Declare Zip file name
                            using (ZipFile zip = new ZipFile())
                            {
                                foreach (string tan in lstTANs)
                                {
                                    //lstFolders.Items.Add(tan);
                                    //Application.DoEvents();

                                    mainFolder = outputFolderPath + "\\" + tan;
                                    subFolder = outputFolderPath + "\\" + tan + "\\markup";
                                    Directory.CreateDirectory(mainFolder);
                                    Directory.CreateDirectory(subFolder);

                                    //Get TAN markup files
                                    List<string> lstTANPdfs = GetTANFileNames(tan, pdfFolderPath);
                                    if (lstTANPdfs != null)
                                    {
                                        if (lstTANPdfs.Count > 0)
                                        {
                                            for (int i = 0; i < lstTANPdfs.Count; i++)
                                            {
                                                File.Move(lstTANPdfs[i], subFolder + "\\Markup " + (i + 1) + " - casreact.pdf");
                                            }
                                        }
                                    }

                                    zip.AddDirectory(mainFolder, tan);
                                }

                                zip.Save(outputFolderPath + "\\" + "rxnmarkup." + batchName + ".zip");
                                blStatus = true;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private List<string> GetDistinctTANsFromFolder(string pdfFolderPath)
        {
            List<string> lstTANs = null;
            try
            {
                if (!string.IsNullOrEmpty(pdfFolderPath))
                {
                    DirectoryInfo dirInfo = new DirectoryInfo(pdfFolderPath);
                    FileInfo[] faFiles = dirInfo.GetFiles();
                    if (faFiles != null)
                    {
                        lstTANs = new List<string>();
                        //Filename format is TAN_Markup_N.pdf
                        string strTAN = "";
                        foreach (FileInfo f in faFiles)
                        {
                            string[] saFileNames = f.Name.Split(new char[] { '_' });
                            if (saFileNames != null && saFileNames.Length > 0)
                            {
                                strTAN = saFileNames[0].Trim().ToUpper().Replace(".PDF", "");

                                if (!string.IsNullOrEmpty(strTAN) && Validations.ValidateTANFormat(strTAN))
                                {
                                    if (!lstTANs.Contains(strTAN))
                                    {
                                        lstTANs.Add(strTAN);
                                    }
                                }
                            }                        
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstTANs;
        }

        private List<string> GetTANFileNames(string tan, string pdfFolder)
        {
            List<string> lstTANFiles = null;
            try
            {
                if (!string.IsNullOrEmpty(tan) && !string.IsNullOrEmpty(pdfFolder))
                {
                    if (Directory.Exists(pdfFolder))
                    {
                        string[] tanPdfs = Directory.GetFiles(pdfFolder, tan + "*.pdf");
                        if (tanPdfs != null)
                        {
                            lstTANFiles = tanPdfs.ToList();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstTANFiles;
        }

        private bool DeleteOtherFilesAndFolders(string outputPath)
        {
            bool blStatus = false;
            try
            {
                if (!string.IsNullOrEmpty(outputPath))
                {
                    DirectoryInfo otherDirInfo = new DirectoryInfo(outputPath);
                    foreach (DirectoryInfo dir in otherDirInfo.GetDirectories())
                    {
                        dir.Delete(true);
                    }
                    blStatus = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtFolder.Text.Trim()) && !string.IsNullOrEmpty(txtBatchName.Text.Trim()))
                {
                    //Clear the list box first 
                    lstFolders.Items.Clear();

                    if (GenerateTANwiseFolders(txtFolder.Text.Trim(), txtFolder.Text.Trim(), txtBatchName.Text.Trim()))
                    {
                        DirectoryInfo dirInfo = new DirectoryInfo(txtFolder.Text.Trim());
                        var sorted = dirInfo.GetDirectories("*.*", SearchOption.TopDirectoryOnly);                       
                        lstFolders.Items.AddRange(sorted);

                        if (DeleteOtherFilesAndFolders(folderBrowserDialog1.SelectedPath))
                        {
                            MessageBox.Show("Zip file generated successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Error in Markup folders creation", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void frmCreateMarkupFolder_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }
    }
}
