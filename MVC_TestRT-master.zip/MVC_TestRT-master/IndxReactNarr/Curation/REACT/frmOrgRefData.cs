﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using IndxReactNarrDAL;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using IndxReactNarr.Common;

namespace IndxReactNarr
{
    public partial class frmOrgRefData : Form
    {
        public frmOrgRefData()
        {
            InitializeComponent();
        }

        public DataTable OrgRefData
        {
            get;
            set;
        }

        public string SourceForm { get; set; }

        private void frmOrgRefData_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;

                LoadOrgRefData();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void LoadOrgRefData()
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;
                this.Text = "OrgRef data";

                if (Generic.GlobalVariables.Ser9000OrgRefData != null && Generic.GlobalVariables.Ser9000OrgRefData.Rows.Count > 0)
                {
                    using (DataTable dtOrgRef = Generic.GlobalVariables.Ser9000OrgRefData.Clone())
                    {
                        dtOrgRef.Columns["NUM"].DataType = System.Type.GetType("System.String");
                        dtOrgRef.Columns["REG_NO"].DataType = System.Type.GetType("System.String");

                        foreach (DataRow dr in Generic.GlobalVariables.Ser9000OrgRefData.Rows)
                        {
                            dtOrgRef.ImportRow(dr);
                        }

                        if (Generic.GlobalVariables.Ser8500OrgrefData != null)
                        {
                            foreach (DataRow dr in Generic.GlobalVariables.Ser8500OrgrefData.Rows)
                            {
                                dtOrgRef.ImportRow(dr);
                            }
                        }

                        OrgRefData = dtOrgRef;

                        //Bind data to grid
                        BindOrgRefDataToGrid(OrgRefData);
                    }
                }
                
                //if (Generic.GlobalVariables.Ser8500OrgrefData != null)
                //{
                //    if (Generic.GlobalVariables.Ser8500OrgrefData.Rows.Count > 0)
                //    {
                //        using (DataTable dtOrgRef = Generic.GlobalVariables.Ser8500OrgrefData.Clone())
                //        {
                //            // dtOrgRef.Columns["NUM"].DataType = System.Type.GetType("System.String");
                //            dtOrgRef.Columns["REG_NO"].DataType = System.Type.GetType("System.String");

                //            foreach (DataRow dr in Generic.GlobalVariables.Ser8500OrgrefData.Rows)
                //            {
                //                dtOrgRef.ImportRow(dr);
                //            }
                //            OrgRefData = dtOrgRef;

                //            //Bind data to grid
                //            BindOrgRefDataToGrid(OrgRefData);

                //            colNUM.Visible = false;
                //        }
                //    }
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtNrnNum_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilteredDataBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtNrnReg_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilteredDataBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilteredDataBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgOrgRef_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvOrgRef.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvOrgRef.Font);

                if (dgvOrgRef.RowHeadersWidth < (int)(size.Width + 20)) dgvOrgRef.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void GetFilteredDataBindToGrid()
        {            
            try
            {
                string filterCond = "";
                if(!string.IsNullOrEmpty(txtNrnNum.Text.Trim()))
                {
                    filterCond = "NUM like '" + txtNrnNum.Text.Trim() + "%'";
                }
                if (!string.IsNullOrEmpty(txtNrnReg.Text.Trim()))
                {
                    filterCond = "REG_NO like '" + txtNrnReg.Text.Trim() + "%'";
                }
                if (!string.IsNullOrEmpty(txtName.Text.Trim()))
                {
                    filterCond = "ORGREF_NAME like '" + DataConversions.EscapeSpecialCharsInFilterCondition(txtName.Text.Trim()) + "%'";
                }

                if (!string.IsNullOrEmpty(filterCond) && OrgRefData != null && OrgRefData.Rows.Count > 0)
                {
                    using (DataView dtView = new DataView(OrgRefData))
                    {
                        dtView.RowFilter = filterCond;
                        BindOrgRefDataToGrid(dtView.ToTable());
                    }
                }
                else
                {
                    dgvOrgRef.DataSource = OrgRefData;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }            
        }

        private void BindOrgRefDataToGrid(DataTable orgRefData)
        {
            try
            {
                if (orgRefData != null)
                {
                    dgvOrgRef.AutoGenerateColumns = false;
                    dgvOrgRef.DataSource = orgRefData;

                    colNUM.DataPropertyName = "NUM";
                    colRegNo.DataPropertyName = "REG_NO";
                    colName.DataPropertyName = "ORGREF_NAME";
                    colMolFile.DataPropertyName = "MOL_FILE";
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvOrgRef_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                {
                    if (dgvOrgRef.Rows[e.RowIndex].Cells["colMolFile"].Value != null)
                    {
                        renderer1.MolfileString = dgvOrgRef.Rows[e.RowIndex].Cells["colMolFile"].Value.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
