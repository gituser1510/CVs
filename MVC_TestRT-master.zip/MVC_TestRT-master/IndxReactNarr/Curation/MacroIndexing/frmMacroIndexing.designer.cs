﻿namespace IndxReactNarr
{
    partial class frmMacroIndexing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMacroIndexing));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            MDL.Draw.Chemistry.Molecule molecule1 = new MDL.Draw.Chemistry.Molecule();
            MDL.Draw.Renderer.Preferences.DisplayPreferences displayPreferences1 = new MDL.Draw.Renderer.Preferences.DisplayPreferences();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.tcMain = new System.Windows.Forms.TabControl();
            this.tpArticleInfo = new System.Windows.Forms.TabPage();
            this.pnlArticleCntrls = new System.Windows.Forms.Panel();
            this.splContArticleInfo = new System.Windows.Forms.SplitContainer();
            this.pnlTANInfo = new System.Windows.Forms.Panel();
            this.txtComments = new System.Windows.Forms.TextBox();
            this.chkIncludeInREP = new System.Windows.Forms.CheckBox();
            this.lnkCrossRef = new System.Windows.Forms.LinkLabel();
            this.lnkSection = new System.Windows.Forms.LinkLabel();
            this.lblComments = new System.Windows.Forms.Label();
            this.chkQueryTAN = new System.Windows.Forms.CheckBox();
            this.chkReviewTAN = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lblAbstract = new System.Windows.Forms.Label();
            this.chkSPA_HDR = new System.Windows.Forms.CheckBox();
            this.txtCrossRefSections = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtTAN = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSection = new System.Windows.Forms.TextBox();
            this.lblTan = new System.Windows.Forms.Label();
            this.txtSubSection = new System.Windows.Forms.TextBox();
            this.dgvKeywords = new System.Windows.Forms.DataGridView();
            this.pnlSave = new System.Windows.Forms.Panel();
            this.btnXmlPreview = new System.Windows.Forms.Button();
            this.btnHideSplChars = new System.Windows.Forms.Button();
            this.btnExportToPdf = new System.Windows.Forms.Button();
            this.btnRejectTAN = new System.Windows.Forms.Button();
            this.btnTANComplete = new System.Windows.Forms.Button();
            this.btnExportSDF = new System.Windows.Forms.Button();
            this.btnDATPreview = new System.Windows.Forms.Button();
            this.btnSaveArticleInfo = new System.Windows.Forms.Button();
            this.pnlKeyword = new System.Windows.Forms.Panel();
            this.txtKeyword = new System.Windows.Forms.TextBox();
            this.lblKey = new System.Windows.Forms.Label();
            this.btnAddKey = new System.Windows.Forms.Button();
            this.tpNUM_PAR = new System.Windows.Forms.TabPage();
            this.splContNUMPAR = new System.Windows.Forms.SplitContainer();
            this.splContNUM = new System.Windows.Forms.SplitContainer();
            this.pnlNUMPAR = new System.Windows.Forms.Panel();
            this.cmbTANDocs_PAR = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.chkIsCrossRefTo = new System.Windows.Forms.CheckBox();
            this.txtCrossRefPolymer_NP = new System.Windows.Forms.TextBox();
            this.chkIsTradeNamePolymer_NP = new System.Windows.Forms.CheckBox();
            this.lnkRegNo = new System.Windows.Forms.LinkLabel();
            this.chkIsPolymer = new System.Windows.Forms.CheckBox();
            this.lblNumTMD = new System.Windows.Forms.Label();
            this.pnlButtons_NP = new System.Windows.Forms.Panel();
            this.btnSaveNUMPAR = new System.Windows.Forms.Button();
            this.btnResetNUMPAR = new System.Windows.Forms.Button();
            this.lblNotes = new System.Windows.Forms.Label();
            this.txtNUMNote = new System.Windows.Forms.TextBox();
            this.chkNoStructure = new System.Windows.Forms.CheckBox();
            this.lnkRoleNP = new System.Windows.Forms.LinkLabel();
            this.nudNUMPAR = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.txtRoleNP = new System.Windows.Forms.TextBox();
            this.txtRegistryNo = new System.Windows.Forms.TextBox();
            this.chkDPT_RS = new System.Windows.Forms.CheckBox();
            this.txtAMD = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtHMD_NP = new System.Windows.Forms.TextBox();
            this.dgvNUM_PAR = new System.Windows.Forms.DataGridView();
            this.splContStruct_Image = new System.Windows.Forms.SplitContainer();
            this.ChemRenditor = new MDL.Draw.Renditor.Renditor();
            this.label1 = new System.Windows.Forms.Label();
            this.pbStructureImage = new System.Windows.Forms.PictureBox();
            this.lblSDFHdr = new System.Windows.Forms.Label();
            this.pnlStructButtons = new System.Windows.Forms.Panel();
            this.btnCopyToImage = new System.Windows.Forms.Button();
            this.btnMolToImage = new System.Windows.Forms.Button();
            this.tpNUM_CTH = new System.Windows.Forms.TabPage();
            this.splContNUMCTH = new System.Windows.Forms.SplitContainer();
            this.pnlNUMCTH = new System.Windows.Forms.Panel();
            this.cmbTANDocs_CTH = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCrossRefPolymer_NC = new System.Windows.Forms.TextBox();
            this.chkIsTradeNamePolymer_NC = new System.Windows.Forms.CheckBox();
            this.chkRequireFileReview = new System.Windows.Forms.CheckBox();
            this.txtNUMCTH = new System.Windows.Forms.TextBox();
            this.pnlButtons_NC = new System.Windows.Forms.Panel();
            this.btnSaveNUMCTH = new System.Windows.Forms.Button();
            this.btnResetNUMCTH = new System.Windows.Forms.Button();
            this.lnkCTH = new System.Windows.Forms.LinkLabel();
            this.lblCTH_TMD = new System.Windows.Forms.Label();
            this.lblCTHType = new System.Windows.Forms.Label();
            this.rbnCTHCrystalStruct = new System.Windows.Forms.RadioButton();
            this.rbnCTHMolStruct = new System.Windows.Forms.RadioButton();
            this.rbnCTHGeneral = new System.Windows.Forms.RadioButton();
            this.lnkRoleNC = new System.Windows.Forms.LinkLabel();
            this.txtCTH = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtRoleNC = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtHMD_NC = new System.Windows.Forms.TextBox();
            this.dgvNUM_CTH = new System.Windows.Forms.DataGridView();
            this.rapidSpellAsYouType1 = new Keyoti.RapidSpell.RapidSpellAsYouType(this.components);
            this.lnkCrossRefTo_CTH = new System.Windows.Forms.LinkLabel();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewLinkColumn1 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn2 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn3 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn4 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn5 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewLinkColumn3 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn4 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn6 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn7 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewLinkColumn5 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn6 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.uchrtbTMD = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.uchrtbAbstract = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.uchrtbTitle = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.colTKID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colKeyWord = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colKeyWordsCnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colKeywordLen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEditKeyword = new System.Windows.Forms.DataGridViewLinkColumn();
            this.colDeleteKeyword = new System.Windows.Forms.DataGridViewLinkColumn();
            this.uchrtbSrcDocIndxTerm_PAR = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.uchrtbTMD_NP = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.uchrtbPAR_NP = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.colArticleNUMID_NP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNUM_NP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRegNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPAR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSrcDocIndexTerm_NP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colIndxTermSrcDocID_NP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colIndxTermSrcDocName_NP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colHMD_NP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAMD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRole_NP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTMD_Num = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDPT = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colNoStructure = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colPolymerStructure = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colTradeNamePolymer_NP = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colIsCrossReferred = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colCrossRefTo_NP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNote = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStructure = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStructureImage = new System.Windows.Forms.DataGridViewImageColumn();
            this.colEditNP = new System.Windows.Forms.DataGridViewLinkColumn();
            this.colDeleteNP = new System.Windows.Forms.DataGridViewLinkColumn();
            this.uchrtbSrcDocIndxTerm_CTH = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.uchrtbTMD_NC = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.colArticleNUMID_NC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNUM_NC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCTHClass = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCTH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCTHType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSrcDocIndexTerm_NC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colIndxTermSrcDocID_NC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colIndxTermSrcDocName_NC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTMD_CTH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colHMD_NC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRole_NC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRequireFileReview = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colTradeNamePolymer_NC = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colCrossRefTo_NC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdit_NC = new System.Windows.Forms.DataGridViewLinkColumn();
            this.colDelete_NC = new System.Windows.Forms.DataGridViewLinkColumn();
            this.ucSplCharsToolStrip_Indexing1 = new IndxReactNarr.UserControls.ucSplCharsToolStrip_Indexing();
            this.pnlMain.SuspendLayout();
            this.tcMain.SuspendLayout();
            this.tpArticleInfo.SuspendLayout();
            this.pnlArticleCntrls.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splContArticleInfo)).BeginInit();
            this.splContArticleInfo.Panel1.SuspendLayout();
            this.splContArticleInfo.Panel2.SuspendLayout();
            this.splContArticleInfo.SuspendLayout();
            this.pnlTANInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKeywords)).BeginInit();
            this.pnlSave.SuspendLayout();
            this.pnlKeyword.SuspendLayout();
            this.tpNUM_PAR.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splContNUMPAR)).BeginInit();
            this.splContNUMPAR.Panel1.SuspendLayout();
            this.splContNUMPAR.Panel2.SuspendLayout();
            this.splContNUMPAR.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splContNUM)).BeginInit();
            this.splContNUM.Panel1.SuspendLayout();
            this.splContNUM.Panel2.SuspendLayout();
            this.splContNUM.SuspendLayout();
            this.pnlNUMPAR.SuspendLayout();
            this.pnlButtons_NP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudNUMPAR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNUM_PAR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splContStruct_Image)).BeginInit();
            this.splContStruct_Image.Panel1.SuspendLayout();
            this.splContStruct_Image.Panel2.SuspendLayout();
            this.splContStruct_Image.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbStructureImage)).BeginInit();
            this.pnlStructButtons.SuspendLayout();
            this.tpNUM_CTH.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splContNUMCTH)).BeginInit();
            this.splContNUMCTH.Panel1.SuspendLayout();
            this.splContNUMCTH.Panel2.SuspendLayout();
            this.splContNUMCTH.SuspendLayout();
            this.pnlNUMCTH.SuspendLayout();
            this.pnlButtons_NC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNUM_CTH)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.tcMain);
            this.pnlMain.Controls.Add(this.ucSplCharsToolStrip_Indexing1);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1246, 565);
            this.pnlMain.TabIndex = 0;
            // 
            // tcMain
            // 
            this.tcMain.Controls.Add(this.tpArticleInfo);
            this.tcMain.Controls.Add(this.tpNUM_PAR);
            this.tcMain.Controls.Add(this.tpNUM_CTH);
            this.tcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcMain.Location = new System.Drawing.Point(0, 74);
            this.tcMain.Name = "tcMain";
            this.tcMain.SelectedIndex = 0;
            this.tcMain.Size = new System.Drawing.Size(1246, 491);
            this.tcMain.TabIndex = 1;
            this.tcMain.SelectedIndexChanged += new System.EventHandler(this.tcMain_SelectedIndexChanged);
            // 
            // tpArticleInfo
            // 
            this.tpArticleInfo.Controls.Add(this.pnlArticleCntrls);
            this.tpArticleInfo.Location = new System.Drawing.Point(4, 25);
            this.tpArticleInfo.Margin = new System.Windows.Forms.Padding(0);
            this.tpArticleInfo.Name = "tpArticleInfo";
            this.tpArticleInfo.Size = new System.Drawing.Size(1238, 462);
            this.tpArticleInfo.TabIndex = 2;
            this.tpArticleInfo.Text = "Article Info";
            this.tpArticleInfo.UseVisualStyleBackColor = true;
            // 
            // pnlArticleCntrls
            // 
            this.pnlArticleCntrls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlArticleCntrls.Controls.Add(this.splContArticleInfo);
            this.pnlArticleCntrls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlArticleCntrls.Location = new System.Drawing.Point(0, 0);
            this.pnlArticleCntrls.Name = "pnlArticleCntrls";
            this.pnlArticleCntrls.Size = new System.Drawing.Size(1238, 462);
            this.pnlArticleCntrls.TabIndex = 0;
            // 
            // splContArticleInfo
            // 
            this.splContArticleInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splContArticleInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContArticleInfo.Location = new System.Drawing.Point(0, 0);
            this.splContArticleInfo.Name = "splContArticleInfo";
            this.splContArticleInfo.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splContArticleInfo.Panel1
            // 
            this.splContArticleInfo.Panel1.Controls.Add(this.pnlTANInfo);
            // 
            // splContArticleInfo.Panel2
            // 
            this.splContArticleInfo.Panel2.Controls.Add(this.dgvKeywords);
            this.splContArticleInfo.Panel2.Controls.Add(this.pnlSave);
            this.splContArticleInfo.Panel2.Controls.Add(this.pnlKeyword);
            this.splContArticleInfo.Size = new System.Drawing.Size(1236, 460);
            this.splContArticleInfo.SplitterDistance = 266;
            this.splContArticleInfo.SplitterWidth = 3;
            this.splContArticleInfo.TabIndex = 229;
            // 
            // pnlTANInfo
            // 
            this.pnlTANInfo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlTANInfo.Controls.Add(this.txtComments);
            this.pnlTANInfo.Controls.Add(this.chkIncludeInREP);
            this.pnlTANInfo.Controls.Add(this.lnkCrossRef);
            this.pnlTANInfo.Controls.Add(this.uchrtbTMD);
            this.pnlTANInfo.Controls.Add(this.uchrtbAbstract);
            this.pnlTANInfo.Controls.Add(this.uchrtbTitle);
            this.pnlTANInfo.Controls.Add(this.lnkSection);
            this.pnlTANInfo.Controls.Add(this.lblComments);
            this.pnlTANInfo.Controls.Add(this.chkQueryTAN);
            this.pnlTANInfo.Controls.Add(this.chkReviewTAN);
            this.pnlTANInfo.Controls.Add(this.label5);
            this.pnlTANInfo.Controls.Add(this.lblAbstract);
            this.pnlTANInfo.Controls.Add(this.chkSPA_HDR);
            this.pnlTANInfo.Controls.Add(this.txtCrossRefSections);
            this.pnlTANInfo.Controls.Add(this.label7);
            this.pnlTANInfo.Controls.Add(this.txtTAN);
            this.pnlTANInfo.Controls.Add(this.label3);
            this.pnlTANInfo.Controls.Add(this.txtSection);
            this.pnlTANInfo.Controls.Add(this.lblTan);
            this.pnlTANInfo.Controls.Add(this.txtSubSection);
            this.pnlTANInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTANInfo.Location = new System.Drawing.Point(0, 0);
            this.pnlTANInfo.Name = "pnlTANInfo";
            this.pnlTANInfo.Size = new System.Drawing.Size(1234, 264);
            this.pnlTANInfo.TabIndex = 232;
            // 
            // txtComments
            // 
            this.txtComments.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtComments.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComments.ForeColor = System.Drawing.Color.Black;
            this.txtComments.Location = new System.Drawing.Point(975, 4);
            this.txtComments.Name = "txtComments";
            this.txtComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtComments.Size = new System.Drawing.Size(255, 21);
            this.txtComments.TabIndex = 6;
            // 
            // chkIncludeInREP
            // 
            this.chkIncludeInREP.AccessibleDescription = "0";
            this.chkIncludeInREP.AutoSize = true;
            this.chkIncludeInREP.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeInREP.Location = new System.Drawing.Point(800, 6);
            this.chkIncludeInREP.Name = "chkIncludeInREP";
            this.chkIncludeInREP.Size = new System.Drawing.Size(107, 19);
            this.chkIncludeInREP.TabIndex = 240;
            this.chkIncludeInREP.Text = "Include in REP";
            this.chkIncludeInREP.UseVisualStyleBackColor = true;
            // 
            // lnkCrossRef
            // 
            this.lnkCrossRef.AutoSize = true;
            this.lnkCrossRef.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lnkCrossRef.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkCrossRef.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkCrossRef.Location = new System.Drawing.Point(347, 6);
            this.lnkCrossRef.Name = "lnkCrossRef";
            this.lnkCrossRef.Size = new System.Drawing.Size(65, 16);
            this.lnkCrossRef.TabIndex = 239;
            this.lnkCrossRef.TabStop = true;
            this.lnkCrossRef.Text = "Cross Ref";
            this.lnkCrossRef.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkCrossRef_LinkClicked);
            // 
            // lnkSection
            // 
            this.lnkSection.AutoSize = true;
            this.lnkSection.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lnkSection.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkSection.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkSection.Location = new System.Drawing.Point(151, 6);
            this.lnkSection.Name = "lnkSection";
            this.lnkSection.Size = new System.Drawing.Size(52, 16);
            this.lnkSection.TabIndex = 233;
            this.lnkSection.TabStop = true;
            this.lnkSection.Text = "Section";
            this.lnkSection.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkSection_LinkClicked);
            // 
            // lblComments
            // 
            this.lblComments.AutoSize = true;
            this.lblComments.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComments.ForeColor = System.Drawing.Color.Black;
            this.lblComments.Location = new System.Drawing.Point(908, 6);
            this.lblComments.Name = "lblComments";
            this.lblComments.Size = new System.Drawing.Size(71, 16);
            this.lblComments.TabIndex = 226;
            this.lblComments.Text = "Comments";
            // 
            // chkQueryTAN
            // 
            this.chkQueryTAN.AccessibleDescription = "0";
            this.chkQueryTAN.AutoSize = true;
            this.chkQueryTAN.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkQueryTAN.Location = new System.Drawing.Point(712, 6);
            this.chkQueryTAN.Name = "chkQueryTAN";
            this.chkQueryTAN.Size = new System.Drawing.Size(83, 19);
            this.chkQueryTAN.TabIndex = 228;
            this.chkQueryTAN.Text = "Query TAN";
            this.chkQueryTAN.UseVisualStyleBackColor = true;
            // 
            // chkReviewTAN
            // 
            this.chkReviewTAN.AccessibleDescription = "0";
            this.chkReviewTAN.AutoSize = true;
            this.chkReviewTAN.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkReviewTAN.Location = new System.Drawing.Point(619, 6);
            this.chkReviewTAN.Name = "chkReviewTAN";
            this.chkReviewTAN.Size = new System.Drawing.Size(91, 19);
            this.chkReviewTAN.TabIndex = 227;
            this.chkReviewTAN.Text = "Review TAN";
            this.chkReviewTAN.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(2, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 16);
            this.label5.TabIndex = 216;
            this.label5.Text = "Title";
            // 
            // lblAbstract
            // 
            this.lblAbstract.AutoSize = true;
            this.lblAbstract.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAbstract.ForeColor = System.Drawing.Color.Black;
            this.lblAbstract.Location = new System.Drawing.Point(3, 119);
            this.lblAbstract.Name = "lblAbstract";
            this.lblAbstract.Size = new System.Drawing.Size(35, 16);
            this.lblAbstract.TabIndex = 218;
            this.lblAbstract.Text = "ABS";
            // 
            // chkSPA_HDR
            // 
            this.chkSPA_HDR.AccessibleDescription = "0";
            this.chkSPA_HDR.AutoSize = true;
            this.chkSPA_HDR.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkSPA_HDR.Location = new System.Drawing.Point(538, 6);
            this.chkSPA_HDR.Name = "chkSPA_HDR";
            this.chkSPA_HDR.Size = new System.Drawing.Size(78, 19);
            this.chkSPA_HDR.TabIndex = 5;
            this.chkSPA_HDR.Text = "SPA:HDR";
            this.chkSPA_HDR.UseVisualStyleBackColor = true;
            // 
            // txtCrossRefSections
            // 
            this.txtCrossRefSections.BackColor = System.Drawing.Color.White;
            this.txtCrossRefSections.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCrossRefSections.ForeColor = System.Drawing.Color.Blue;
            this.txtCrossRefSections.Location = new System.Drawing.Point(416, 4);
            this.txtCrossRefSections.MaxLength = 9;
            this.txtCrossRefSections.Name = "txtCrossRefSections";
            this.txtCrossRefSections.ReadOnly = true;
            this.txtCrossRefSections.Size = new System.Drawing.Size(117, 21);
            this.txtCrossRefSections.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(2, 78);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 16);
            this.label7.TabIndex = 220;
            this.label7.Text = "TMD";
            // 
            // txtTAN
            // 
            this.txtTAN.BackColor = System.Drawing.Color.White;
            this.txtTAN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTAN.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTAN.ForeColor = System.Drawing.Color.Blue;
            this.txtTAN.Location = new System.Drawing.Point(41, 4);
            this.txtTAN.MaxLength = 9;
            this.txtTAN.Name = "txtTAN";
            this.txtTAN.ReadOnly = true;
            this.txtTAN.Size = new System.Drawing.Size(103, 21);
            this.txtTAN.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(236, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 16);
            this.label3.TabIndex = 211;
            this.label3.Text = "Sub Section";
            // 
            // txtSection
            // 
            this.txtSection.BackColor = System.Drawing.Color.White;
            this.txtSection.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtSection.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSection.ForeColor = System.Drawing.Color.Blue;
            this.txtSection.Location = new System.Drawing.Point(206, 4);
            this.txtSection.MaxLength = 9;
            this.txtSection.Name = "txtSection";
            this.txtSection.ReadOnly = true;
            this.txtSection.Size = new System.Drawing.Size(25, 21);
            this.txtSection.TabIndex = 2;
            this.txtSection.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblTan
            // 
            this.lblTan.AutoSize = true;
            this.lblTan.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTan.ForeColor = System.Drawing.Color.Black;
            this.lblTan.Location = new System.Drawing.Point(9, 7);
            this.lblTan.Name = "lblTan";
            this.lblTan.Size = new System.Drawing.Size(29, 15);
            this.lblTan.TabIndex = 206;
            this.lblTan.Text = "TAN";
            // 
            // txtSubSection
            // 
            this.txtSubSection.BackColor = System.Drawing.Color.White;
            this.txtSubSection.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtSubSection.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSubSection.ForeColor = System.Drawing.Color.Blue;
            this.txtSubSection.Location = new System.Drawing.Point(318, 4);
            this.txtSubSection.MaxLength = 9;
            this.txtSubSection.Name = "txtSubSection";
            this.txtSubSection.Size = new System.Drawing.Size(25, 21);
            this.txtSubSection.TabIndex = 3;
            this.txtSubSection.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dgvKeywords
            // 
            this.dgvKeywords.AllowUserToAddRows = false;
            this.dgvKeywords.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.dgvKeywords.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvKeywords.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvKeywords.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKeywords.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTKID,
            this.colKeyWord,
            this.colKeyWordsCnt,
            this.colKeywordLen,
            this.colEditKeyword,
            this.colDeleteKeyword});
            this.dgvKeywords.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvKeywords.Location = new System.Drawing.Point(0, 31);
            this.dgvKeywords.Name = "dgvKeywords";
            this.dgvKeywords.ReadOnly = true;
            this.dgvKeywords.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Cornsilk;
            this.dgvKeywords.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvKeywords.RowTemplate.Height = 30;
            this.dgvKeywords.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvKeywords.Size = new System.Drawing.Size(1234, 127);
            this.dgvKeywords.TabIndex = 201;
            this.dgvKeywords.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvKeywords_CellContentClick);
            this.dgvKeywords.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvKeywords_RowPostPaint);
            // 
            // pnlSave
            // 
            this.pnlSave.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlSave.Controls.Add(this.btnXmlPreview);
            this.pnlSave.Controls.Add(this.btnHideSplChars);
            this.pnlSave.Controls.Add(this.btnExportToPdf);
            this.pnlSave.Controls.Add(this.btnRejectTAN);
            this.pnlSave.Controls.Add(this.btnTANComplete);
            this.pnlSave.Controls.Add(this.btnExportSDF);
            this.pnlSave.Controls.Add(this.btnDATPreview);
            this.pnlSave.Controls.Add(this.btnSaveArticleInfo);
            this.pnlSave.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlSave.Location = new System.Drawing.Point(0, 158);
            this.pnlSave.Name = "pnlSave";
            this.pnlSave.Size = new System.Drawing.Size(1234, 31);
            this.pnlSave.TabIndex = 228;
            // 
            // btnXmlPreview
            // 
            this.btnXmlPreview.Location = new System.Drawing.Point(316, 2);
            this.btnXmlPreview.Name = "btnXmlPreview";
            this.btnXmlPreview.Size = new System.Drawing.Size(90, 23);
            this.btnXmlPreview.TabIndex = 61;
            this.btnXmlPreview.Text = "Xml Preview";
            this.btnXmlPreview.UseVisualStyleBackColor = true;
            this.btnXmlPreview.Click += new System.EventHandler(this.btnXmlPreview_Click);
            // 
            // btnHideSplChars
            // 
            this.btnHideSplChars.Image = global::IndxReactNarr.Properties.Resources.control_panel;
            this.btnHideSplChars.Location = new System.Drawing.Point(274, 2);
            this.btnHideSplChars.Name = "btnHideSplChars";
            this.btnHideSplChars.Size = new System.Drawing.Size(30, 24);
            this.btnHideSplChars.TabIndex = 58;
            this.btnHideSplChars.UseVisualStyleBackColor = true;
            this.btnHideSplChars.Click += new System.EventHandler(this.btnHideSplChars_Click);
            // 
            // btnExportToPdf
            // 
            this.btnExportToPdf.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportToPdf.Image = ((System.Drawing.Image)(resources.GetObject("btnExportToPdf.Image")));
            this.btnExportToPdf.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExportToPdf.Location = new System.Drawing.Point(200, 2);
            this.btnExportToPdf.Name = "btnExportToPdf";
            this.btnExportToPdf.Size = new System.Drawing.Size(68, 24);
            this.btnExportToPdf.TabIndex = 57;
            this.btnExportToPdf.Text = "Export";
            this.btnExportToPdf.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExportToPdf.UseVisualStyleBackColor = true;
            this.btnExportToPdf.Click += new System.EventHandler(this.btnExportToPdf_Click);
            // 
            // btnRejectTAN
            // 
            this.btnRejectTAN.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRejectTAN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRejectTAN.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRejectTAN.ForeColor = System.Drawing.Color.Black;
            this.btnRejectTAN.Location = new System.Drawing.Point(939, 2);
            this.btnRejectTAN.Name = "btnRejectTAN";
            this.btnRejectTAN.Size = new System.Drawing.Size(93, 24);
            this.btnRejectTAN.TabIndex = 56;
            this.btnRejectTAN.Text = "TAN Reject";
            this.btnRejectTAN.UseVisualStyleBackColor = true;
            this.btnRejectTAN.Click += new System.EventHandler(this.btnRejectTAN_Click);
            // 
            // btnTANComplete
            // 
            this.btnTANComplete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTANComplete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTANComplete.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTANComplete.ForeColor = System.Drawing.Color.Black;
            this.btnTANComplete.Location = new System.Drawing.Point(1038, 2);
            this.btnTANComplete.Name = "btnTANComplete";
            this.btnTANComplete.Size = new System.Drawing.Size(107, 24);
            this.btnTANComplete.TabIndex = 54;
            this.btnTANComplete.Text = "TAN Complete";
            this.btnTANComplete.UseVisualStyleBackColor = true;
            this.btnTANComplete.Click += new System.EventHandler(this.btnTANComplete_Click);
            // 
            // btnExportSDF
            // 
            this.btnExportSDF.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExportSDF.Location = new System.Drawing.Point(102, 2);
            this.btnExportSDF.Name = "btnExportSDF";
            this.btnExportSDF.Size = new System.Drawing.Size(92, 24);
            this.btnExportSDF.TabIndex = 14;
            this.btnExportSDF.Text = "SDF Preview";
            this.btnExportSDF.UseVisualStyleBackColor = true;
            this.btnExportSDF.Click += new System.EventHandler(this.btnExportSDF_Click);
            // 
            // btnDATPreview
            // 
            this.btnDATPreview.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDATPreview.Location = new System.Drawing.Point(3, 2);
            this.btnDATPreview.Name = "btnDATPreview";
            this.btnDATPreview.Size = new System.Drawing.Size(92, 24);
            this.btnDATPreview.TabIndex = 13;
            this.btnDATPreview.Text = "DAT Preview";
            this.btnDATPreview.UseVisualStyleBackColor = true;
            this.btnDATPreview.Click += new System.EventHandler(this.btnDATPreview_Click);
            // 
            // btnSaveArticleInfo
            // 
            this.btnSaveArticleInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSaveArticleInfo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaveArticleInfo.Image = global::IndxReactNarr.Properties.Resources.save_1;
            this.btnSaveArticleInfo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSaveArticleInfo.Location = new System.Drawing.Point(1151, 2);
            this.btnSaveArticleInfo.Name = "btnSaveArticleInfo";
            this.btnSaveArticleInfo.Size = new System.Drawing.Size(75, 24);
            this.btnSaveArticleInfo.TabIndex = 15;
            this.btnSaveArticleInfo.Text = "Save";
            this.btnSaveArticleInfo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSaveArticleInfo.UseVisualStyleBackColor = true;
            this.btnSaveArticleInfo.Click += new System.EventHandler(this.btnSaveArticleInfo_Click);
            // 
            // pnlKeyword
            // 
            this.pnlKeyword.Controls.Add(this.txtKeyword);
            this.pnlKeyword.Controls.Add(this.lblKey);
            this.pnlKeyword.Controls.Add(this.btnAddKey);
            this.pnlKeyword.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlKeyword.Location = new System.Drawing.Point(0, 0);
            this.pnlKeyword.Name = "pnlKeyword";
            this.pnlKeyword.Size = new System.Drawing.Size(1234, 31);
            this.pnlKeyword.TabIndex = 223;
            // 
            // txtKeyword
            // 
            this.txtKeyword.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtKeyword.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKeyword.ForeColor = System.Drawing.Color.Black;
            this.txtKeyword.Location = new System.Drawing.Point(42, 5);
            this.txtKeyword.Multiline = true;
            this.txtKeyword.Name = "txtKeyword";
            this.txtKeyword.Size = new System.Drawing.Size(1131, 20);
            this.txtKeyword.TabIndex = 10;
            this.txtKeyword.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtKeyword_KeyPress);
            // 
            // lblKey
            // 
            this.lblKey.AutoSize = true;
            this.lblKey.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKey.ForeColor = System.Drawing.Color.Black;
            this.lblKey.Location = new System.Drawing.Point(6, 6);
            this.lblKey.Name = "lblKey";
            this.lblKey.Size = new System.Drawing.Size(31, 16);
            this.lblKey.TabIndex = 222;
            this.lblKey.Text = "Key";
            // 
            // btnAddKey
            // 
            this.btnAddKey.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddKey.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddKey.Location = new System.Drawing.Point(1179, 3);
            this.btnAddKey.Name = "btnAddKey";
            this.btnAddKey.Size = new System.Drawing.Size(50, 25);
            this.btnAddKey.TabIndex = 11;
            this.btnAddKey.Text = "Add";
            this.btnAddKey.UseVisualStyleBackColor = true;
            this.btnAddKey.Click += new System.EventHandler(this.btnAddKey_Click);
            // 
            // tpNUM_PAR
            // 
            this.tpNUM_PAR.Controls.Add(this.splContNUMPAR);
            this.tpNUM_PAR.Location = new System.Drawing.Point(4, 25);
            this.tpNUM_PAR.Margin = new System.Windows.Forms.Padding(0);
            this.tpNUM_PAR.Name = "tpNUM_PAR";
            this.tpNUM_PAR.Size = new System.Drawing.Size(1238, 462);
            this.tpNUM_PAR.TabIndex = 0;
            this.tpNUM_PAR.Text = "NUM-PAR";
            this.tpNUM_PAR.UseVisualStyleBackColor = true;
            // 
            // splContNUMPAR
            // 
            this.splContNUMPAR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContNUMPAR.Location = new System.Drawing.Point(0, 0);
            this.splContNUMPAR.Name = "splContNUMPAR";
            // 
            // splContNUMPAR.Panel1
            // 
            this.splContNUMPAR.Panel1.Controls.Add(this.splContNUM);
            // 
            // splContNUMPAR.Panel2
            // 
            this.splContNUMPAR.Panel2.Controls.Add(this.splContStruct_Image);
            this.splContNUMPAR.Panel2.Controls.Add(this.pnlStructButtons);
            this.splContNUMPAR.Size = new System.Drawing.Size(1238, 462);
            this.splContNUMPAR.SplitterDistance = 905;
            this.splContNUMPAR.SplitterWidth = 3;
            this.splContNUMPAR.TabIndex = 228;
            // 
            // splContNUM
            // 
            this.splContNUM.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContNUM.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splContNUM.Location = new System.Drawing.Point(0, 0);
            this.splContNUM.Name = "splContNUM";
            this.splContNUM.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splContNUM.Panel1
            // 
            this.splContNUM.Panel1.Controls.Add(this.pnlNUMPAR);
            // 
            // splContNUM.Panel2
            // 
            this.splContNUM.Panel2.Controls.Add(this.dgvNUM_PAR);
            this.splContNUM.Size = new System.Drawing.Size(905, 462);
            this.splContNUM.SplitterDistance = 299;
            this.splContNUM.TabIndex = 229;
            // 
            // pnlNUMPAR
            // 
            this.pnlNUMPAR.Controls.Add(this.cmbTANDocs_PAR);
            this.pnlNUMPAR.Controls.Add(this.label2);
            this.pnlNUMPAR.Controls.Add(this.uchrtbSrcDocIndxTerm_PAR);
            this.pnlNUMPAR.Controls.Add(this.label4);
            this.pnlNUMPAR.Controls.Add(this.chkIsCrossRefTo);
            this.pnlNUMPAR.Controls.Add(this.txtCrossRefPolymer_NP);
            this.pnlNUMPAR.Controls.Add(this.chkIsTradeNamePolymer_NP);
            this.pnlNUMPAR.Controls.Add(this.lnkRegNo);
            this.pnlNUMPAR.Controls.Add(this.chkIsPolymer);
            this.pnlNUMPAR.Controls.Add(this.uchrtbTMD_NP);
            this.pnlNUMPAR.Controls.Add(this.uchrtbPAR_NP);
            this.pnlNUMPAR.Controls.Add(this.lblNumTMD);
            this.pnlNUMPAR.Controls.Add(this.pnlButtons_NP);
            this.pnlNUMPAR.Controls.Add(this.lblNotes);
            this.pnlNUMPAR.Controls.Add(this.txtNUMNote);
            this.pnlNUMPAR.Controls.Add(this.chkNoStructure);
            this.pnlNUMPAR.Controls.Add(this.lnkRoleNP);
            this.pnlNUMPAR.Controls.Add(this.nudNUMPAR);
            this.pnlNUMPAR.Controls.Add(this.label9);
            this.pnlNUMPAR.Controls.Add(this.txtRoleNP);
            this.pnlNUMPAR.Controls.Add(this.txtRegistryNo);
            this.pnlNUMPAR.Controls.Add(this.chkDPT_RS);
            this.pnlNUMPAR.Controls.Add(this.txtAMD);
            this.pnlNUMPAR.Controls.Add(this.label11);
            this.pnlNUMPAR.Controls.Add(this.label13);
            this.pnlNUMPAR.Controls.Add(this.label12);
            this.pnlNUMPAR.Controls.Add(this.txtHMD_NP);
            this.pnlNUMPAR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlNUMPAR.Location = new System.Drawing.Point(0, 0);
            this.pnlNUMPAR.Name = "pnlNUMPAR";
            this.pnlNUMPAR.Size = new System.Drawing.Size(905, 299);
            this.pnlNUMPAR.TabIndex = 230;
            // 
            // cmbTANDocs_PAR
            // 
            this.cmbTANDocs_PAR.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbTANDocs_PAR.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTANDocs_PAR.FormattingEnabled = true;
            this.cmbTANDocs_PAR.Location = new System.Drawing.Point(680, 31);
            this.cmbTANDocs_PAR.Name = "cmbTANDocs_PAR";
            this.cmbTANDocs_PAR.Size = new System.Drawing.Size(221, 24);
            this.cmbTANDocs_PAR.TabIndex = 251;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(632, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 16);
            this.label2.TabIndex = 250;
            this.label2.Text = "Doc.ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(3, 34);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 16);
            this.label4.TabIndex = 252;
            this.label4.Text = "Src. Indx Term";
            // 
            // chkIsCrossRefTo
            // 
            this.chkIsCrossRefTo.AutoSize = true;
            this.chkIsCrossRefTo.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIsCrossRefTo.Location = new System.Drawing.Point(243, 245);
            this.chkIsCrossRefTo.Name = "chkIsCrossRefTo";
            this.chkIsCrossRefTo.Size = new System.Drawing.Size(136, 19);
            this.chkIsCrossRefTo.TabIndex = 248;
            this.chkIsCrossRefTo.Text = "Cross Reference To";
            this.chkIsCrossRefTo.UseVisualStyleBackColor = true;
            this.chkIsCrossRefTo.CheckStateChanged += new System.EventHandler(this.chkIsCrossRefTo_CheckStateChanged);
            // 
            // txtCrossRefPolymer_NP
            // 
            this.txtCrossRefPolymer_NP.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCrossRefPolymer_NP.Enabled = false;
            this.txtCrossRefPolymer_NP.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCrossRefPolymer_NP.ForeColor = System.Drawing.Color.Black;
            this.txtCrossRefPolymer_NP.Location = new System.Drawing.Point(381, 244);
            this.txtCrossRefPolymer_NP.Multiline = true;
            this.txtCrossRefPolymer_NP.Name = "txtCrossRefPolymer_NP";
            this.txtCrossRefPolymer_NP.Size = new System.Drawing.Size(521, 20);
            this.txtCrossRefPolymer_NP.TabIndex = 246;
            // 
            // chkIsTradeNamePolymer_NP
            // 
            this.chkIsTradeNamePolymer_NP.AutoSize = true;
            this.chkIsTradeNamePolymer_NP.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIsTradeNamePolymer_NP.Location = new System.Drawing.Point(64, 245);
            this.chkIsTradeNamePolymer_NP.Name = "chkIsTradeNamePolymer_NP";
            this.chkIsTradeNamePolymer_NP.Size = new System.Drawing.Size(143, 19);
            this.chkIsTradeNamePolymer_NP.TabIndex = 244;
            this.chkIsTradeNamePolymer_NP.Text = "Trade Name Polymer";
            this.chkIsTradeNamePolymer_NP.UseVisualStyleBackColor = true;
            // 
            // lnkRegNo
            // 
            this.lnkRegNo.AutoSize = true;
            this.lnkRegNo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lnkRegNo.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkRegNo.Location = new System.Drawing.Point(159, 6);
            this.lnkRegNo.Name = "lnkRegNo";
            this.lnkRegNo.Size = new System.Drawing.Size(51, 16);
            this.lnkRegNo.TabIndex = 243;
            this.lnkRegNo.TabStop = true;
            this.lnkRegNo.Text = "Reg.No";
            this.lnkRegNo.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkRegNo_LinkClicked);
            // 
            // chkIsPolymer
            // 
            this.chkIsPolymer.AutoSize = true;
            this.chkIsPolymer.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIsPolymer.Location = new System.Drawing.Point(616, 6);
            this.chkIsPolymer.Name = "chkIsPolymer";
            this.chkIsPolymer.Size = new System.Drawing.Size(123, 19);
            this.chkIsPolymer.TabIndex = 242;
            this.chkIsPolymer.Text = "Polymer Structure";
            this.chkIsPolymer.UseVisualStyleBackColor = true;
            // 
            // lblNumTMD
            // 
            this.lblNumTMD.AutoSize = true;
            this.lblNumTMD.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumTMD.ForeColor = System.Drawing.Color.Black;
            this.lblNumTMD.Location = new System.Drawing.Point(60, 157);
            this.lblNumTMD.Name = "lblNumTMD";
            this.lblNumTMD.Size = new System.Drawing.Size(35, 16);
            this.lblNumTMD.TabIndex = 237;
            this.lblNumTMD.Text = "TMD";
            // 
            // pnlButtons_NP
            // 
            this.pnlButtons_NP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlButtons_NP.Controls.Add(this.btnSaveNUMPAR);
            this.pnlButtons_NP.Controls.Add(this.btnResetNUMPAR);
            this.pnlButtons_NP.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlButtons_NP.Location = new System.Drawing.Point(0, 268);
            this.pnlButtons_NP.Name = "pnlButtons_NP";
            this.pnlButtons_NP.Size = new System.Drawing.Size(905, 31);
            this.pnlButtons_NP.TabIndex = 232;
            // 
            // btnSaveNUMPAR
            // 
            this.btnSaveNUMPAR.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSaveNUMPAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaveNUMPAR.Image = global::IndxReactNarr.Properties.Resources.save_1;
            this.btnSaveNUMPAR.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSaveNUMPAR.Location = new System.Drawing.Point(825, 0);
            this.btnSaveNUMPAR.Name = "btnSaveNUMPAR";
            this.btnSaveNUMPAR.Size = new System.Drawing.Size(75, 28);
            this.btnSaveNUMPAR.TabIndex = 25;
            this.btnSaveNUMPAR.Text = "Save";
            this.btnSaveNUMPAR.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSaveNUMPAR.UseVisualStyleBackColor = true;
            this.btnSaveNUMPAR.Click += new System.EventHandler(this.btnSaveNUMPAR_Click);
            // 
            // btnResetNUMPAR
            // 
            this.btnResetNUMPAR.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnResetNUMPAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnResetNUMPAR.Image = global::IndxReactNarr.Properties.Resources.refresh;
            this.btnResetNUMPAR.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnResetNUMPAR.Location = new System.Drawing.Point(740, 0);
            this.btnResetNUMPAR.Name = "btnResetNUMPAR";
            this.btnResetNUMPAR.Size = new System.Drawing.Size(75, 28);
            this.btnResetNUMPAR.TabIndex = 26;
            this.btnResetNUMPAR.Text = "Reset";
            this.btnResetNUMPAR.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnResetNUMPAR.UseVisualStyleBackColor = true;
            this.btnResetNUMPAR.Click += new System.EventHandler(this.btnResetNUMPAR_Click);
            // 
            // lblNotes
            // 
            this.lblNotes.AutoSize = true;
            this.lblNotes.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNotes.ForeColor = System.Drawing.Color.Black;
            this.lblNotes.Location = new System.Drawing.Point(60, 222);
            this.lblNotes.Name = "lblNotes";
            this.lblNotes.Size = new System.Drawing.Size(35, 16);
            this.lblNotes.TabIndex = 231;
            this.lblNotes.Text = "Note";
            // 
            // txtNUMNote
            // 
            this.txtNUMNote.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNUMNote.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNUMNote.ForeColor = System.Drawing.Color.Black;
            this.txtNUMNote.Location = new System.Drawing.Point(97, 220);
            this.txtNUMNote.Multiline = true;
            this.txtNUMNote.Name = "txtNUMNote";
            this.txtNUMNote.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtNUMNote.Size = new System.Drawing.Size(805, 20);
            this.txtNUMNote.TabIndex = 24;
            // 
            // chkNoStructure
            // 
            this.chkNoStructure.AutoSize = true;
            this.chkNoStructure.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkNoStructure.Location = new System.Drawing.Point(456, 6);
            this.chkNoStructure.Name = "chkNoStructure";
            this.chkNoStructure.Size = new System.Drawing.Size(145, 19);
            this.chkNoStructure.TabIndex = 19;
            this.chkNoStructure.Text = "No Structure Available";
            this.chkNoStructure.UseVisualStyleBackColor = true;
            this.chkNoStructure.CheckedChanged += new System.EventHandler(this.chkNoStructure_CheckedChanged);
            // 
            // lnkRoleNP
            // 
            this.lnkRoleNP.AutoSize = true;
            this.lnkRoleNP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lnkRoleNP.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkRoleNP.Location = new System.Drawing.Point(61, 198);
            this.lnkRoleNP.Name = "lnkRoleNP";
            this.lnkRoleNP.Size = new System.Drawing.Size(34, 16);
            this.lnkRoleNP.TabIndex = 23;
            this.lnkRoleNP.TabStop = true;
            this.lnkRoleNP.Text = "Role";
            this.lnkRoleNP.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkRoleNP_LinkClicked);
            // 
            // nudNUMPAR
            // 
            this.nudNUMPAR.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudNUMPAR.Location = new System.Drawing.Point(97, 4);
            this.nudNUMPAR.Maximum = new decimal(new int[] {
            799,
            0,
            0,
            0});
            this.nudNUMPAR.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudNUMPAR.Name = "nudNUMPAR";
            this.nudNUMPAR.Size = new System.Drawing.Size(54, 22);
            this.nudNUMPAR.TabIndex = 16;
            this.nudNUMPAR.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(55, 6);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(37, 16);
            this.label9.TabIndex = 204;
            this.label9.Text = "NUM";
            // 
            // txtRoleNP
            // 
            this.txtRoleNP.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRoleNP.BackColor = System.Drawing.Color.White;
            this.txtRoleNP.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRoleNP.ForeColor = System.Drawing.Color.Blue;
            this.txtRoleNP.Location = new System.Drawing.Point(97, 196);
            this.txtRoleNP.Multiline = true;
            this.txtRoleNP.Name = "txtRoleNP";
            this.txtRoleNP.ReadOnly = true;
            this.txtRoleNP.Size = new System.Drawing.Size(805, 20);
            this.txtRoleNP.TabIndex = 200;
            // 
            // txtRegistryNo
            // 
            this.txtRegistryNo.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRegistryNo.ForeColor = System.Drawing.Color.Black;
            this.txtRegistryNo.Location = new System.Drawing.Point(214, 4);
            this.txtRegistryNo.Name = "txtRegistryNo";
            this.txtRegistryNo.Size = new System.Drawing.Size(136, 21);
            this.txtRegistryNo.TabIndex = 17;
            // 
            // chkDPT_RS
            // 
            this.chkDPT_RS.AutoSize = true;
            this.chkDPT_RS.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDPT_RS.Location = new System.Drawing.Point(369, 6);
            this.chkDPT_RS.Name = "chkDPT_RS";
            this.chkDPT_RS.Size = new System.Drawing.Size(69, 19);
            this.chkDPT_RS.TabIndex = 18;
            this.chkDPT_RS.Text = "DPT:RS";
            this.chkDPT_RS.UseVisualStyleBackColor = true;
            // 
            // txtAMD
            // 
            this.txtAMD.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAMD.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAMD.ForeColor = System.Drawing.Color.Black;
            this.txtAMD.Location = new System.Drawing.Point(97, 130);
            this.txtAMD.Multiline = true;
            this.txtAMD.Name = "txtAMD";
            this.txtAMD.Size = new System.Drawing.Size(805, 20);
            this.txtAMD.TabIndex = 22;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(61, 67);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(34, 16);
            this.label11.TabIndex = 218;
            this.label11.Text = "PAR";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(58, 132);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(37, 16);
            this.label13.TabIndex = 222;
            this.label13.Text = "AMD";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(58, 108);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(37, 16);
            this.label12.TabIndex = 220;
            this.label12.Text = "HMD";
            // 
            // txtHMD_NP
            // 
            this.txtHMD_NP.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtHMD_NP.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHMD_NP.ForeColor = System.Drawing.Color.Black;
            this.txtHMD_NP.Location = new System.Drawing.Point(97, 106);
            this.txtHMD_NP.Multiline = true;
            this.txtHMD_NP.Name = "txtHMD_NP";
            this.txtHMD_NP.Size = new System.Drawing.Size(804, 20);
            this.txtHMD_NP.TabIndex = 21;
            // 
            // dgvNUM_PAR
            // 
            this.dgvNUM_PAR.AllowUserToAddRows = false;
            this.dgvNUM_PAR.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            this.dgvNUM_PAR.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvNUM_PAR.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvNUM_PAR.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNUM_PAR.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colArticleNUMID_NP,
            this.colNUM_NP,
            this.colRegNo,
            this.colPAR,
            this.colSrcDocIndexTerm_NP,
            this.colIndxTermSrcDocID_NP,
            this.colIndxTermSrcDocName_NP,
            this.colHMD_NP,
            this.colAMD,
            this.colRole_NP,
            this.colTMD_Num,
            this.colDPT,
            this.colNoStructure,
            this.colPolymerStructure,
            this.colTradeNamePolymer_NP,
            this.colIsCrossReferred,
            this.colCrossRefTo_NP,
            this.colNote,
            this.colStructure,
            this.colStructureImage,
            this.colEditNP,
            this.colDeleteNP});
            this.dgvNUM_PAR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvNUM_PAR.Location = new System.Drawing.Point(0, 0);
            this.dgvNUM_PAR.Name = "dgvNUM_PAR";
            this.dgvNUM_PAR.ReadOnly = true;
            this.dgvNUM_PAR.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvNUM_PAR.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvNUM_PAR.RowTemplate.Height = 30;
            this.dgvNUM_PAR.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvNUM_PAR.Size = new System.Drawing.Size(905, 159);
            this.dgvNUM_PAR.TabIndex = 225;
            this.dgvNUM_PAR.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNUM_PAR_CellContentClick);
            this.dgvNUM_PAR.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvNUM_PAR_RowPostPaint);
            // 
            // splContStruct_Image
            // 
            this.splContStruct_Image.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splContStruct_Image.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContStruct_Image.Location = new System.Drawing.Point(0, 33);
            this.splContStruct_Image.Name = "splContStruct_Image";
            this.splContStruct_Image.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splContStruct_Image.Panel1
            // 
            this.splContStruct_Image.Panel1.Controls.Add(this.ChemRenditor);
            this.splContStruct_Image.Panel1.Controls.Add(this.label1);
            // 
            // splContStruct_Image.Panel2
            // 
            this.splContStruct_Image.Panel2.Controls.Add(this.pbStructureImage);
            this.splContStruct_Image.Panel2.Controls.Add(this.lblSDFHdr);
            this.splContStruct_Image.Size = new System.Drawing.Size(330, 429);
            this.splContStruct_Image.SplitterDistance = 207;
            this.splContStruct_Image.TabIndex = 28;
            // 
            // ChemRenditor
            // 
            this.ChemRenditor.AutoSizeStructure = true;
            this.ChemRenditor.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.ChemRenditor.BinHexSketch = "01030004412400214372656174656420627920416363656C7279734472617720342E322E302E36303" +
    "502040000005805000000005905000000000B0B0005417269616C780000140200";
            this.ChemRenditor.ChimeString = null;
            this.ChemRenditor.ClearingEnabled = true;
            this.ChemRenditor.CopyingEnabled = true;
            this.ChemRenditor.DisplayOnEmpty = null;
            this.ChemRenditor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ChemRenditor.EditingEnabled = true;
            this.ChemRenditor.FileName = null;
            this.ChemRenditor.HighlightInfo = "";
            this.ChemRenditor.IsBitmapFromOLE = false;
            this.ChemRenditor.Location = new System.Drawing.Point(0, 24);
            molecule1.ArrowDir = MDL.Draw.ArrowDirType.No;
            molecule1.ArrowStyle = MDL.Draw.ArrowStyleType.Empty;
            molecule1.AtomValenceDisplay = true;
            molecule1.BaseFormBoxSetting = 0;
            molecule1.BondLineThickness = 0D;
            molecule1.CarbonLabelDisplay = false;
            molecule1.ChemLabelFont = null;
            molecule1.ChemLabelFontString = "(none)";
            molecule1.ColorAtomsByTypeInSketch = false;
            molecule1.ConfigLabelFont = null;
            molecule1.ConfigLabelFontString = "(none)";
            molecule1.ConvertRingBondIntoOneToMany = true;
            molecule1.Coords = null;
            molecule1.DashSpacing = 0.1D;
            molecule1.DisplaySinCys = false;
            molecule1.DisplaySulfurInCysSequence = false;
            molecule1.DoubleBondWidth = 0.18D;
            molecule1.FillColor = System.Drawing.Color.Empty;
            molecule1.FillStyle = MDL.Draw.ChemGraphicsObject.FillStyles.SOLID;
            molecule1.ForeColor = System.Drawing.Color.Empty;
            molecule1.ForeColorString = "";
            molecule1.ForSubsequenceQuery = false;
            molecule1.HighlightChildren = "";
            molecule1.HighlightColor = System.Drawing.Color.Blue;
            molecule1.HydrogenDisplayMode = MDL.Draw.Chemistry.Atom.HydrogenDisplayMode.Off;
            molecule1.Id = 506;
            molecule1.Initial = "";
            molecule1.IsAModel = false;
            molecule1.IsARotatedModel = false;
            molecule1.KeepRSLabelsInSketch = true;
            molecule1.LastModifyChemText = -1;
            molecule1.MaintainXMLChildOrderFlag = false;
            molecule1.MustPerceiveStereo = true;
            molecule1.PenColor = System.Drawing.Color.Empty;
            molecule1.PenStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            molecule1.PenStyleToken = 0;
            molecule1.PenWidth = ((byte)(0));
            molecule1.PenWidthUnit = MDL.Draw.ChemGraphicsObject.PenWidthUnits.Default;
            molecule1.RefId = 506;
            molecule1.Replaced = false;
            molecule1.RgroupCleeanUpNeeded = false;
            molecule1.RgroupLabelsPresentFlag = false;
            molecule1.RLabelAtAbsCenter = "R";
            molecule1.RLabelAtAndCenter = "R*";
            molecule1.RLabelAtOrCenter = "(R)";
            molecule1.ScaleLabelsToBondLength = false;
            molecule1.Selected = false;
            molecule1.SequenceDictionary = null;
            molecule1.SequenceNeedsRealign = false;
            molecule1.SequenceView = MDL.Draw.Chemistry.Molecule.SequenceViewEnum.None;
            molecule1.Size = 0;
            molecule1.SkcWritten = false;
            molecule1.SkNumber = ((short)(0));
            molecule1.SLabelAtAbsCenter = "S";
            molecule1.SLabelAtAndCenter = "S*";
            molecule1.SLabelAtOrCenter = "(S)";
            molecule1.StandardBondLength = 0D;
            molecule1.StereoChemistryMode = MDL.Draw.Chemistry.Molecule.StereoChemistryModeEnum.And;
            molecule1.TextBorder = 0.1D;
            molecule1.Transparent = false;
            molecule1.UndoableEditListener = null;
            molecule1.WedgeWidth = 0.1D;
            molecule1.ZLayer = -99507;
            this.ChemRenditor.Molecule = molecule1;
            this.ChemRenditor.MolfileString = "";
            this.ChemRenditor.Name = "ChemRenditor";
            this.ChemRenditor.OldScalingMode = MDL.Draw.Renderer.Preferences.StructureScalingMode.ScaleToFitBox;
            this.ChemRenditor.PastingEnabled = true;
            displayPreferences1.AtomAtomDisplayMode = MDL.Draw.Renderer.Preferences.AtomAtomMappingDisplayMode.On;
            this.ChemRenditor.Preferences = displayPreferences1;
            this.ChemRenditor.PreferencesFileName = "default.xml";
            this.ChemRenditor.RendererBorderStyle = System.Windows.Forms.ButtonBorderStyle.Inset;
            this.ChemRenditor.RenditorMolecule = molecule1;
            this.ChemRenditor.RenditorName = "Demo Renditor";
            this.ChemRenditor.Size = new System.Drawing.Size(328, 181);
            this.ChemRenditor.SketchString = "AQMABEEkACFDcmVhdGVkIGJ5IEFjY2VscnlzRHJhdyA0LjIuMC42MDUCBAAAAFgFAAAAAFkFAAAAAAsLA" +
    "AVBcmlhbHgAABQCAA==";
            this.ChemRenditor.SmilesString = "";
            this.ChemRenditor.TabIndex = 25;
            this.ChemRenditor.URLEncodedMolfileString = "";
            this.ChemRenditor.UseLocalXMLConfig = false;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.Info;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(328, 24);
            this.label1.TabIndex = 26;
            this.label1.Text = "Structure";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbStructureImage
            // 
            this.pbStructureImage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbStructureImage.Location = new System.Drawing.Point(0, 24);
            this.pbStructureImage.Name = "pbStructureImage";
            this.pbStructureImage.Size = new System.Drawing.Size(328, 192);
            this.pbStructureImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbStructureImage.TabIndex = 0;
            this.pbStructureImage.TabStop = false;
            this.pbStructureImage.Click += new System.EventHandler(this.pbStructureImage_Click);
            // 
            // lblSDFHdr
            // 
            this.lblSDFHdr.BackColor = System.Drawing.SystemColors.Info;
            this.lblSDFHdr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSDFHdr.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblSDFHdr.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSDFHdr.Location = new System.Drawing.Point(0, 0);
            this.lblSDFHdr.Name = "lblSDFHdr";
            this.lblSDFHdr.Size = new System.Drawing.Size(328, 24);
            this.lblSDFHdr.TabIndex = 1;
            this.lblSDFHdr.Text = "React Image";
            this.lblSDFHdr.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pnlStructButtons
            // 
            this.pnlStructButtons.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlStructButtons.Controls.Add(this.btnCopyToImage);
            this.pnlStructButtons.Controls.Add(this.btnMolToImage);
            this.pnlStructButtons.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlStructButtons.Location = new System.Drawing.Point(0, 0);
            this.pnlStructButtons.Name = "pnlStructButtons";
            this.pnlStructButtons.Size = new System.Drawing.Size(330, 33);
            this.pnlStructButtons.TabIndex = 27;
            // 
            // btnCopyToImage
            // 
            this.btnCopyToImage.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnCopyToImage.Location = new System.Drawing.Point(222, 0);
            this.btnCopyToImage.Name = "btnCopyToImage";
            this.btnCopyToImage.Size = new System.Drawing.Size(104, 29);
            this.btnCopyToImage.TabIndex = 27;
            this.btnCopyToImage.Text = "SDF Image";
            this.btnCopyToImage.UseVisualStyleBackColor = true;
            this.btnCopyToImage.Click += new System.EventHandler(this.btnCopyToImage_Click);
            // 
            // btnMolToImage
            // 
            this.btnMolToImage.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnMolToImage.Location = new System.Drawing.Point(0, 0);
            this.btnMolToImage.Name = "btnMolToImage";
            this.btnMolToImage.Size = new System.Drawing.Size(104, 29);
            this.btnMolToImage.TabIndex = 26;
            this.btnMolToImage.Text = "React Image";
            this.btnMolToImage.UseVisualStyleBackColor = true;
            this.btnMolToImage.Click += new System.EventHandler(this.btnMolToImage_Click);
            // 
            // tpNUM_CTH
            // 
            this.tpNUM_CTH.Controls.Add(this.splContNUMCTH);
            this.tpNUM_CTH.Location = new System.Drawing.Point(4, 25);
            this.tpNUM_CTH.Margin = new System.Windows.Forms.Padding(0);
            this.tpNUM_CTH.Name = "tpNUM_CTH";
            this.tpNUM_CTH.Size = new System.Drawing.Size(1238, 462);
            this.tpNUM_CTH.TabIndex = 1;
            this.tpNUM_CTH.Text = "NUM-CTH";
            this.tpNUM_CTH.UseVisualStyleBackColor = true;
            // 
            // splContNUMCTH
            // 
            this.splContNUMCTH.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContNUMCTH.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splContNUMCTH.Location = new System.Drawing.Point(0, 0);
            this.splContNUMCTH.Name = "splContNUMCTH";
            this.splContNUMCTH.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splContNUMCTH.Panel1
            // 
            this.splContNUMCTH.Panel1.Controls.Add(this.pnlNUMCTH);
            // 
            // splContNUMCTH.Panel2
            // 
            this.splContNUMCTH.Panel2.Controls.Add(this.dgvNUM_CTH);
            this.splContNUMCTH.Size = new System.Drawing.Size(1238, 462);
            this.splContNUMCTH.SplitterDistance = 229;
            this.splContNUMCTH.TabIndex = 230;
            // 
            // pnlNUMCTH
            // 
            this.pnlNUMCTH.Controls.Add(this.lnkCrossRefTo_CTH);
            this.pnlNUMCTH.Controls.Add(this.cmbTANDocs_CTH);
            this.pnlNUMCTH.Controls.Add(this.label6);
            this.pnlNUMCTH.Controls.Add(this.uchrtbSrcDocIndxTerm_CTH);
            this.pnlNUMCTH.Controls.Add(this.label8);
            this.pnlNUMCTH.Controls.Add(this.txtCrossRefPolymer_NC);
            this.pnlNUMCTH.Controls.Add(this.chkIsTradeNamePolymer_NC);
            this.pnlNUMCTH.Controls.Add(this.chkRequireFileReview);
            this.pnlNUMCTH.Controls.Add(this.txtNUMCTH);
            this.pnlNUMCTH.Controls.Add(this.uchrtbTMD_NC);
            this.pnlNUMCTH.Controls.Add(this.pnlButtons_NC);
            this.pnlNUMCTH.Controls.Add(this.lnkCTH);
            this.pnlNUMCTH.Controls.Add(this.lblCTH_TMD);
            this.pnlNUMCTH.Controls.Add(this.lblCTHType);
            this.pnlNUMCTH.Controls.Add(this.rbnCTHCrystalStruct);
            this.pnlNUMCTH.Controls.Add(this.rbnCTHMolStruct);
            this.pnlNUMCTH.Controls.Add(this.rbnCTHGeneral);
            this.pnlNUMCTH.Controls.Add(this.lnkRoleNC);
            this.pnlNUMCTH.Controls.Add(this.txtCTH);
            this.pnlNUMCTH.Controls.Add(this.label15);
            this.pnlNUMCTH.Controls.Add(this.txtRoleNC);
            this.pnlNUMCTH.Controls.Add(this.label20);
            this.pnlNUMCTH.Controls.Add(this.txtHMD_NC);
            this.pnlNUMCTH.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlNUMCTH.Location = new System.Drawing.Point(0, 0);
            this.pnlNUMCTH.Name = "pnlNUMCTH";
            this.pnlNUMCTH.Size = new System.Drawing.Size(1238, 229);
            this.pnlNUMCTH.TabIndex = 230;
            // 
            // cmbTANDocs_CTH
            // 
            this.cmbTANDocs_CTH.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbTANDocs_CTH.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTANDocs_CTH.FormattingEnabled = true;
            this.cmbTANDocs_CTH.Location = new System.Drawing.Point(986, 29);
            this.cmbTANDocs_CTH.Name = "cmbTANDocs_CTH";
            this.cmbTANDocs_CTH.Size = new System.Drawing.Size(243, 24);
            this.cmbTANDocs_CTH.TabIndex = 255;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(938, 33);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 16);
            this.label6.TabIndex = 254;
            this.label6.Text = "Doc.ID";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(3, 32);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 16);
            this.label8.TabIndex = 256;
            this.label8.Text = "Src. Indx Term";
            // 
            // txtCrossRefPolymer_NC
            // 
            this.txtCrossRefPolymer_NC.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCrossRefPolymer_NC.BackColor = System.Drawing.Color.White;
            this.txtCrossRefPolymer_NC.Enabled = false;
            this.txtCrossRefPolymer_NC.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCrossRefPolymer_NC.ForeColor = System.Drawing.Color.Black;
            this.txtCrossRefPolymer_NC.Location = new System.Drawing.Point(402, 174);
            this.txtCrossRefPolymer_NC.Multiline = true;
            this.txtCrossRefPolymer_NC.Name = "txtCrossRefPolymer_NC";
            this.txtCrossRefPolymer_NC.Size = new System.Drawing.Size(827, 20);
            this.txtCrossRefPolymer_NC.TabIndex = 249;
            // 
            // chkIsTradeNamePolymer_NC
            // 
            this.chkIsTradeNamePolymer_NC.AutoSize = true;
            this.chkIsTradeNamePolymer_NC.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIsTradeNamePolymer_NC.Location = new System.Drawing.Point(97, 176);
            this.chkIsTradeNamePolymer_NC.Name = "chkIsTradeNamePolymer_NC";
            this.chkIsTradeNamePolymer_NC.Size = new System.Drawing.Size(143, 19);
            this.chkIsTradeNamePolymer_NC.TabIndex = 248;
            this.chkIsTradeNamePolymer_NC.Text = "Trade Name Polymer";
            this.chkIsTradeNamePolymer_NC.UseVisualStyleBackColor = true;
            this.chkIsTradeNamePolymer_NC.CheckStateChanged += new System.EventHandler(this.chkIsTradeNamePolymer_NC_CheckStateChanged);
            // 
            // chkRequireFileReview
            // 
            this.chkRequireFileReview.AutoSize = true;
            this.chkRequireFileReview.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkRequireFileReview.Location = new System.Drawing.Point(461, 6);
            this.chkRequireFileReview.Name = "chkRequireFileReview";
            this.chkRequireFileReview.Size = new System.Drawing.Size(136, 19);
            this.chkRequireFileReview.TabIndex = 246;
            this.chkRequireFileReview.Text = "Require File Review";
            this.chkRequireFileReview.UseVisualStyleBackColor = true;
            // 
            // txtNUMCTH
            // 
            this.txtNUMCTH.BackColor = System.Drawing.Color.White;
            this.txtNUMCTH.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNUMCTH.Location = new System.Drawing.Point(1091, 4);
            this.txtNUMCTH.Name = "txtNUMCTH";
            this.txtNUMCTH.ReadOnly = true;
            this.txtNUMCTH.Size = new System.Drawing.Size(47, 22);
            this.txtNUMCTH.TabIndex = 242;
            this.txtNUMCTH.Text = "801";
            this.txtNUMCTH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtNUMCTH.Visible = false;
            // 
            // pnlButtons_NC
            // 
            this.pnlButtons_NC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlButtons_NC.Controls.Add(this.btnSaveNUMCTH);
            this.pnlButtons_NC.Controls.Add(this.btnResetNUMCTH);
            this.pnlButtons_NC.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlButtons_NC.Location = new System.Drawing.Point(0, 197);
            this.pnlButtons_NC.Name = "pnlButtons_NC";
            this.pnlButtons_NC.Size = new System.Drawing.Size(1238, 32);
            this.pnlButtons_NC.TabIndex = 237;
            // 
            // btnSaveNUMCTH
            // 
            this.btnSaveNUMCTH.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSaveNUMCTH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaveNUMCTH.Image = global::IndxReactNarr.Properties.Resources.save_1;
            this.btnSaveNUMCTH.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSaveNUMCTH.Location = new System.Drawing.Point(1153, 1);
            this.btnSaveNUMCTH.Name = "btnSaveNUMCTH";
            this.btnSaveNUMCTH.Size = new System.Drawing.Size(75, 28);
            this.btnSaveNUMCTH.TabIndex = 35;
            this.btnSaveNUMCTH.Text = "Save";
            this.btnSaveNUMCTH.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSaveNUMCTH.UseVisualStyleBackColor = true;
            this.btnSaveNUMCTH.Click += new System.EventHandler(this.btnSaveNUMCTH_Click);
            // 
            // btnResetNUMCTH
            // 
            this.btnResetNUMCTH.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnResetNUMCTH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnResetNUMCTH.Image = global::IndxReactNarr.Properties.Resources.refresh;
            this.btnResetNUMCTH.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnResetNUMCTH.Location = new System.Drawing.Point(1072, 1);
            this.btnResetNUMCTH.Name = "btnResetNUMCTH";
            this.btnResetNUMCTH.Size = new System.Drawing.Size(75, 28);
            this.btnResetNUMCTH.TabIndex = 36;
            this.btnResetNUMCTH.Text = "Reset";
            this.btnResetNUMCTH.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnResetNUMCTH.UseVisualStyleBackColor = true;
            this.btnResetNUMCTH.Click += new System.EventHandler(this.btnResetNUMCTH_Click);
            // 
            // lnkCTH
            // 
            this.lnkCTH.AutoSize = true;
            this.lnkCTH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lnkCTH.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkCTH.Location = new System.Drawing.Point(61, 63);
            this.lnkCTH.Name = "lnkCTH";
            this.lnkCTH.Size = new System.Drawing.Size(33, 16);
            this.lnkCTH.TabIndex = 236;
            this.lnkCTH.TabStop = true;
            this.lnkCTH.Text = "CTH";
            this.lnkCTH.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkCTH_LinkClicked);
            // 
            // lblCTH_TMD
            // 
            this.lblCTH_TMD.AutoSize = true;
            this.lblCTH_TMD.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCTH_TMD.ForeColor = System.Drawing.Color.Black;
            this.lblCTH_TMD.Location = new System.Drawing.Point(60, 88);
            this.lblCTH_TMD.Name = "lblCTH_TMD";
            this.lblCTH_TMD.Size = new System.Drawing.Size(35, 16);
            this.lblCTH_TMD.TabIndex = 235;
            this.lblCTH_TMD.Text = "TMD";
            // 
            // lblCTHType
            // 
            this.lblCTHType.AutoSize = true;
            this.lblCTHType.Location = new System.Drawing.Point(7, 7);
            this.lblCTHType.Name = "lblCTHType";
            this.lblCTHType.Size = new System.Drawing.Size(35, 16);
            this.lblCTHType.TabIndex = 233;
            this.lblCTHType.Text = "Type";
            // 
            // rbnCTHCrystalStruct
            // 
            this.rbnCTHCrystalStruct.AutoSize = true;
            this.rbnCTHCrystalStruct.Location = new System.Drawing.Point(282, 5);
            this.rbnCTHCrystalStruct.Name = "rbnCTHCrystalStruct";
            this.rbnCTHCrystalStruct.Size = new System.Drawing.Size(124, 20);
            this.rbnCTHCrystalStruct.TabIndex = 30;
            this.rbnCTHCrystalStruct.Text = "Crystal Structure";
            this.rbnCTHCrystalStruct.UseVisualStyleBackColor = true;
            this.rbnCTHCrystalStruct.CheckedChanged += new System.EventHandler(this.rbnCTHCrystalStruct_CheckedChanged);
            // 
            // rbnCTHMolStruct
            // 
            this.rbnCTHMolStruct.AutoSize = true;
            this.rbnCTHMolStruct.Location = new System.Drawing.Point(136, 5);
            this.rbnCTHMolStruct.Name = "rbnCTHMolStruct";
            this.rbnCTHMolStruct.Size = new System.Drawing.Size(135, 20);
            this.rbnCTHMolStruct.TabIndex = 29;
            this.rbnCTHMolStruct.Text = "Molecule Structure";
            this.rbnCTHMolStruct.UseVisualStyleBackColor = true;
            this.rbnCTHMolStruct.CheckedChanged += new System.EventHandler(this.rbnCTHMolStruct_CheckedChanged);
            // 
            // rbnCTHGeneral
            // 
            this.rbnCTHGeneral.AutoSize = true;
            this.rbnCTHGeneral.Checked = true;
            this.rbnCTHGeneral.Location = new System.Drawing.Point(49, 5);
            this.rbnCTHGeneral.Name = "rbnCTHGeneral";
            this.rbnCTHGeneral.Size = new System.Drawing.Size(71, 20);
            this.rbnCTHGeneral.TabIndex = 28;
            this.rbnCTHGeneral.TabStop = true;
            this.rbnCTHGeneral.Text = "General";
            this.rbnCTHGeneral.UseVisualStyleBackColor = true;
            this.rbnCTHGeneral.CheckedChanged += new System.EventHandler(this.rbnCTHGeneral_CheckedChanged);
            this.rbnCTHGeneral.MouseClick += new System.Windows.Forms.MouseEventHandler(this.rbnCTHGeneral_MouseClick);
            // 
            // lnkRoleNC
            // 
            this.lnkRoleNC.AutoSize = true;
            this.lnkRoleNC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lnkRoleNC.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkRoleNC.Location = new System.Drawing.Point(61, 153);
            this.lnkRoleNC.Name = "lnkRoleNC";
            this.lnkRoleNC.Size = new System.Drawing.Size(34, 16);
            this.lnkRoleNC.TabIndex = 34;
            this.lnkRoleNC.TabStop = true;
            this.lnkRoleNC.Text = "Role";
            this.lnkRoleNC.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkRoleNC_LinkClicked);
            // 
            // txtCTH
            // 
            this.txtCTH.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCTH.BackColor = System.Drawing.Color.White;
            this.txtCTH.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCTH.ForeColor = System.Drawing.Color.Black;
            this.txtCTH.Location = new System.Drawing.Point(97, 61);
            this.txtCTH.Multiline = true;
            this.txtCTH.Name = "txtCTH";
            this.txtCTH.ReadOnly = true;
            this.txtCTH.Size = new System.Drawing.Size(1132, 20);
            this.txtCTH.TabIndex = 31;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(1049, 7);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(37, 16);
            this.label15.TabIndex = 204;
            this.label15.Text = "NUM";
            this.label15.Visible = false;
            // 
            // txtRoleNC
            // 
            this.txtRoleNC.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRoleNC.BackColor = System.Drawing.Color.White;
            this.txtRoleNC.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRoleNC.ForeColor = System.Drawing.Color.Blue;
            this.txtRoleNC.Location = new System.Drawing.Point(97, 151);
            this.txtRoleNC.Multiline = true;
            this.txtRoleNC.Name = "txtRoleNC";
            this.txtRoleNC.ReadOnly = true;
            this.txtRoleNC.Size = new System.Drawing.Size(1132, 20);
            this.txtRoleNC.TabIndex = 223;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(58, 129);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(37, 16);
            this.label20.TabIndex = 220;
            this.label20.Text = "HMD";
            // 
            // txtHMD_NC
            // 
            this.txtHMD_NC.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtHMD_NC.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHMD_NC.ForeColor = System.Drawing.Color.Black;
            this.txtHMD_NC.Location = new System.Drawing.Point(97, 127);
            this.txtHMD_NC.Multiline = true;
            this.txtHMD_NC.Name = "txtHMD_NC";
            this.txtHMD_NC.Size = new System.Drawing.Size(1132, 20);
            this.txtHMD_NC.TabIndex = 33;
            // 
            // dgvNUM_CTH
            // 
            this.dgvNUM_CTH.AllowUserToAddRows = false;
            this.dgvNUM_CTH.AllowUserToDeleteRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            this.dgvNUM_CTH.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvNUM_CTH.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvNUM_CTH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNUM_CTH.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colArticleNUMID_NC,
            this.colNUM_NC,
            this.colCTHClass,
            this.colCTH,
            this.colCTHType,
            this.colSrcDocIndexTerm_NC,
            this.colIndxTermSrcDocID_NC,
            this.colIndxTermSrcDocName_NC,
            this.colTMD_CTH,
            this.colHMD_NC,
            this.colRole_NC,
            this.colRequireFileReview,
            this.colTradeNamePolymer_NC,
            this.colCrossRefTo_NC,
            this.colEdit_NC,
            this.colDelete_NC});
            this.dgvNUM_CTH.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvNUM_CTH.Location = new System.Drawing.Point(0, 0);
            this.dgvNUM_CTH.Name = "dgvNUM_CTH";
            this.dgvNUM_CTH.ReadOnly = true;
            this.dgvNUM_CTH.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvNUM_CTH.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvNUM_CTH.RowTemplate.Height = 30;
            this.dgvNUM_CTH.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvNUM_CTH.Size = new System.Drawing.Size(1238, 229);
            this.dgvNUM_CTH.TabIndex = 225;
            this.dgvNUM_CTH.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNUM_CTH_CellContentClick);
            this.dgvNUM_CTH.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvNUM_CTH_RowPostPaint);
            // 
            // rapidSpellAsYouType1
            // 
            this.rapidSpellAsYouType1.AddMenuText = "Add";
            this.rapidSpellAsYouType1.AllowAnyCase = false;
            this.rapidSpellAsYouType1.AllowMixedCase = false;
            this.rapidSpellAsYouType1.AutoCorrectEnabled = true;
            this.rapidSpellAsYouType1.CheckAsYouType = true;
            this.rapidSpellAsYouType1.CheckCompoundWords = false;
            this.rapidSpellAsYouType1.CheckDisabledTextBoxes = false;
            this.rapidSpellAsYouType1.CheckReadOnlyTextBoxes = false;
            this.rapidSpellAsYouType1.ConsiderationRange = 500;
            this.rapidSpellAsYouType1.ContextMenuStripEnabled = true;
            this.rapidSpellAsYouType1.DictFilePath = "";
            this.rapidSpellAsYouType1.FindCapitalizedSuggestions = false;
            this.rapidSpellAsYouType1.GUILanguage = Keyoti.RapidSpell.LanguageType.ENGLISH;
            this.rapidSpellAsYouType1.IgnoreAllMenuText = "Ignore All";
            this.rapidSpellAsYouType1.IgnoreCapitalizedWords = false;
            this.rapidSpellAsYouType1.IgnoreURLsAndEmailAddresses = true;
            this.rapidSpellAsYouType1.IgnoreWordsWithDigits = true;
            this.rapidSpellAsYouType1.IgnoreXML = false;
            this.rapidSpellAsYouType1.IncludeUserDictionaryInSuggestions = true;
            this.rapidSpellAsYouType1.LanguageParser = Keyoti.RapidSpell.LanguageType.ENGLISH;
            this.rapidSpellAsYouType1.LookIntoHyphenatedText = true;
            this.rapidSpellAsYouType1.OptionsEnabled = true;
            this.rapidSpellAsYouType1.OptionsFileName = "RapidSpell_UserSettings.xml";
            this.rapidSpellAsYouType1.OptionsStorageLocation = Keyoti.RapidSpell.Options.UserOptions.StorageType.IsolatedStorage;
            this.rapidSpellAsYouType1.RemoveDuplicateWordText = "Remove duplicate word";
            this.rapidSpellAsYouType1.SeparateHyphenWords = false;
            this.rapidSpellAsYouType1.ShowAddMenuOption = true;
            this.rapidSpellAsYouType1.ShowCutCopyPasteMenuOnTextBoxBase = true;
            this.rapidSpellAsYouType1.ShowSuggestionsContextMenu = true;
            this.rapidSpellAsYouType1.ShowSuggestionsWhenTextIsSelected = false;
            this.rapidSpellAsYouType1.SuggestionsMethod = Keyoti.RapidSpell.SuggestionsMethodType.HashingSuggestions;
            this.rapidSpellAsYouType1.SuggestSplitWords = true;
            this.rapidSpellAsYouType1.TextBoxBase = this.txtKeyword;
            this.rapidSpellAsYouType1.TextComponent = null;
            this.rapidSpellAsYouType1.UnderlineColor = System.Drawing.Color.Red;
            this.rapidSpellAsYouType1.UnderlineStyle = Keyoti.RapidSpell.UnderlineStyle.Wavy;
            this.rapidSpellAsYouType1.UpdateAllTextBoxes = true;
            this.rapidSpellAsYouType1.UserDictionaryFile = "";
            this.rapidSpellAsYouType1.V2Parser = true;
            this.rapidSpellAsYouType1.WarnDuplicates = true;
            // 
            // lnkCrossRefTo_CTH
            // 
            this.lnkCrossRefTo_CTH.AutoSize = true;
            this.lnkCrossRefTo_CTH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lnkCrossRefTo_CTH.Enabled = false;
            this.lnkCrossRefTo_CTH.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkCrossRefTo_CTH.Location = new System.Drawing.Point(278, 176);
            this.lnkCrossRefTo_CTH.Name = "lnkCrossRefTo_CTH";
            this.lnkCrossRefTo_CTH.Size = new System.Drawing.Size(121, 16);
            this.lnkCrossRefTo_CTH.TabIndex = 257;
            this.lnkCrossRefTo_CTH.TabStop = true;
            this.lnkCrossRefTo_CTH.Text = "Cross Reference To";
            this.lnkCrossRefTo_CTH.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkCrossRefTo_CTH_LinkClicked);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "TKID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.HeaderText = "Keyword";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "WordCount";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Length";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewLinkColumn1
            // 
            this.dataGridViewLinkColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewLinkColumn1.HeaderText = "Edit";
            this.dataGridViewLinkColumn1.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn1.Name = "dataGridViewLinkColumn1";
            this.dataGridViewLinkColumn1.ReadOnly = true;
            this.dataGridViewLinkColumn1.Text = "Edit";
            this.dataGridViewLinkColumn1.UseColumnTextForLinkValue = true;
            this.dataGridViewLinkColumn1.Width = 50;
            // 
            // dataGridViewLinkColumn2
            // 
            this.dataGridViewLinkColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewLinkColumn2.HeaderText = "Delete";
            this.dataGridViewLinkColumn2.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn2.Name = "dataGridViewLinkColumn2";
            this.dataGridViewLinkColumn2.ReadOnly = true;
            this.dataGridViewLinkColumn2.Text = "Delete";
            this.dataGridViewLinkColumn2.UseColumnTextForLinkValue = true;
            this.dataGridViewLinkColumn2.Width = 50;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "ArticleNUMID";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Visible = false;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn6.HeaderText = "NUM";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 50;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "Reg.No";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn8.HeaderText = "PAR";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn9.HeaderText = "HMD";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.HeaderText = "AMD";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Visible = false;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn11.HeaderText = "Role";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn12.HeaderText = "TMD";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Width = 50;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn13.HeaderText = "Note";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn14.HeaderText = "Structure";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.HeaderText = "NUMID";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Visible = false;
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewCheckBoxColumn1.FalseValue = "N";
            this.dataGridViewCheckBoxColumn1.HeaderText = "DPT:RS";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            this.dataGridViewCheckBoxColumn1.ReadOnly = true;
            this.dataGridViewCheckBoxColumn1.TrueValue = "Y";
            this.dataGridViewCheckBoxColumn1.Width = 55;
            // 
            // dataGridViewCheckBoxColumn2
            // 
            this.dataGridViewCheckBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewCheckBoxColumn2.FalseValue = "N";
            this.dataGridViewCheckBoxColumn2.HeaderText = "NoStructure";
            this.dataGridViewCheckBoxColumn2.Name = "dataGridViewCheckBoxColumn2";
            this.dataGridViewCheckBoxColumn2.ReadOnly = true;
            this.dataGridViewCheckBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewCheckBoxColumn2.TrueValue = "Y";
            this.dataGridViewCheckBoxColumn2.Width = 55;
            // 
            // dataGridViewCheckBoxColumn3
            // 
            this.dataGridViewCheckBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewCheckBoxColumn3.FalseValue = "N";
            this.dataGridViewCheckBoxColumn3.HeaderText = "IsPolymer";
            this.dataGridViewCheckBoxColumn3.Name = "dataGridViewCheckBoxColumn3";
            this.dataGridViewCheckBoxColumn3.ReadOnly = true;
            this.dataGridViewCheckBoxColumn3.TrueValue = "Y";
            this.dataGridViewCheckBoxColumn3.Width = 50;
            // 
            // dataGridViewCheckBoxColumn4
            // 
            this.dataGridViewCheckBoxColumn4.FalseValue = "N";
            this.dataGridViewCheckBoxColumn4.HeaderText = "TNP";
            this.dataGridViewCheckBoxColumn4.Name = "dataGridViewCheckBoxColumn4";
            this.dataGridViewCheckBoxColumn4.ReadOnly = true;
            this.dataGridViewCheckBoxColumn4.TrueValue = "Y";
            this.dataGridViewCheckBoxColumn4.Width = 40;
            // 
            // dataGridViewCheckBoxColumn5
            // 
            this.dataGridViewCheckBoxColumn5.FalseValue = "N";
            this.dataGridViewCheckBoxColumn5.HeaderText = "RFR";
            this.dataGridViewCheckBoxColumn5.Name = "dataGridViewCheckBoxColumn5";
            this.dataGridViewCheckBoxColumn5.ReadOnly = true;
            this.dataGridViewCheckBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewCheckBoxColumn5.TrueValue = "Y";
            this.dataGridViewCheckBoxColumn5.Width = 40;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn16.HeaderText = "NUM";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.Visible = false;
            this.dataGridViewTextBoxColumn16.Width = 60;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn17.HeaderText = "CTH";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.Visible = false;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn18.HeaderText = "CTH Type";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.HeaderText = "StructureImage";
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            this.dataGridViewImageColumn1.ReadOnly = true;
            this.dataGridViewImageColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewLinkColumn3
            // 
            this.dataGridViewLinkColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewLinkColumn3.HeaderText = "Edit";
            this.dataGridViewLinkColumn3.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn3.Name = "dataGridViewLinkColumn3";
            this.dataGridViewLinkColumn3.ReadOnly = true;
            this.dataGridViewLinkColumn3.Text = "Edit";
            this.dataGridViewLinkColumn3.UseColumnTextForLinkValue = true;
            this.dataGridViewLinkColumn3.Width = 60;
            // 
            // dataGridViewLinkColumn4
            // 
            this.dataGridViewLinkColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewLinkColumn4.HeaderText = "Delete";
            this.dataGridViewLinkColumn4.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn4.Name = "dataGridViewLinkColumn4";
            this.dataGridViewLinkColumn4.ReadOnly = true;
            this.dataGridViewLinkColumn4.Text = "Delete";
            this.dataGridViewLinkColumn4.UseColumnTextForLinkValue = true;
            this.dataGridViewLinkColumn4.Width = 60;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn19.HeaderText = "TMD";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            this.dataGridViewTextBoxColumn19.Visible = false;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn20.HeaderText = "HMD";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.Visible = false;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn21.HeaderText = "Role";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn22.HeaderText = "Role";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn23.HeaderText = "CrossRefTo";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            this.dataGridViewTextBoxColumn23.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn23.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.HeaderText = "CrossRefTo";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            this.dataGridViewTextBoxColumn24.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn24.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.HeaderText = "SrcDocID";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.ReadOnly = true;
            this.dataGridViewTextBoxColumn25.Visible = false;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.HeaderText = "SrcDocName";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn27.HeaderText = "TMD";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn28.HeaderText = "HMD";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            this.dataGridViewTextBoxColumn28.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn29.HeaderText = "Role";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            this.dataGridViewTextBoxColumn29.ReadOnly = true;
            // 
            // dataGridViewCheckBoxColumn6
            // 
            this.dataGridViewCheckBoxColumn6.FalseValue = "N";
            this.dataGridViewCheckBoxColumn6.HeaderText = "TNP";
            this.dataGridViewCheckBoxColumn6.Name = "dataGridViewCheckBoxColumn6";
            this.dataGridViewCheckBoxColumn6.ReadOnly = true;
            this.dataGridViewCheckBoxColumn6.TrueValue = "Y";
            this.dataGridViewCheckBoxColumn6.Width = 40;
            // 
            // dataGridViewCheckBoxColumn7
            // 
            this.dataGridViewCheckBoxColumn7.FalseValue = "N";
            this.dataGridViewCheckBoxColumn7.HeaderText = "TNP";
            this.dataGridViewCheckBoxColumn7.Name = "dataGridViewCheckBoxColumn7";
            this.dataGridViewCheckBoxColumn7.ReadOnly = true;
            this.dataGridViewCheckBoxColumn7.TrueValue = "Y";
            this.dataGridViewCheckBoxColumn7.Width = 40;
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.HeaderText = "CrossRefTo";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.ReadOnly = true;
            this.dataGridViewTextBoxColumn30.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn30.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewLinkColumn5
            // 
            this.dataGridViewLinkColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewLinkColumn5.HeaderText = "Edit";
            this.dataGridViewLinkColumn5.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn5.Name = "dataGridViewLinkColumn5";
            this.dataGridViewLinkColumn5.ReadOnly = true;
            this.dataGridViewLinkColumn5.Text = "Edit";
            this.dataGridViewLinkColumn5.UseColumnTextForLinkValue = true;
            this.dataGridViewLinkColumn5.Width = 60;
            // 
            // dataGridViewLinkColumn6
            // 
            this.dataGridViewLinkColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewLinkColumn6.HeaderText = "Delete";
            this.dataGridViewLinkColumn6.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn6.Name = "dataGridViewLinkColumn6";
            this.dataGridViewLinkColumn6.ReadOnly = true;
            this.dataGridViewLinkColumn6.Text = "Delete";
            this.dataGridViewLinkColumn6.UseColumnTextForLinkValue = true;
            this.dataGridViewLinkColumn6.Width = 60;
            // 
            // uchrtbTMD
            // 
            this.uchrtbTMD.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uchrtbTMD.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.uchrtbTMD.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uchrtbTMD.HighlightMaterials = false;
            this.uchrtbTMD.Location = new System.Drawing.Point(41, 74);
            this.uchrtbTMD.Name = "uchrtbTMD";
            this.uchrtbTMD.PreserveMultiLines = false;
            this.uchrtbTMD.Size = new System.Drawing.Size(1189, 39);
            this.uchrtbTMD.TabIndex = 238;
            // 
            // uchrtbAbstract
            // 
            this.uchrtbAbstract.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uchrtbAbstract.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.uchrtbAbstract.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uchrtbAbstract.HighlightMaterials = false;
            this.uchrtbAbstract.Location = new System.Drawing.Point(41, 115);
            this.uchrtbAbstract.Name = "uchrtbAbstract";
            this.uchrtbAbstract.PreserveMultiLines = true;
            this.uchrtbAbstract.Size = new System.Drawing.Size(1189, 148);
            this.uchrtbAbstract.TabIndex = 237;
            // 
            // uchrtbTitle
            // 
            this.uchrtbTitle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uchrtbTitle.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.uchrtbTitle.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uchrtbTitle.HighlightMaterials = false;
            this.uchrtbTitle.Location = new System.Drawing.Point(41, 28);
            this.uchrtbTitle.Name = "uchrtbTitle";
            this.uchrtbTitle.PreserveMultiLines = false;
            this.uchrtbTitle.Size = new System.Drawing.Size(1189, 44);
            this.uchrtbTitle.TabIndex = 236;
            // 
            // colTKID
            // 
            this.colTKID.HeaderText = "TKID";
            this.colTKID.Name = "colTKID";
            this.colTKID.ReadOnly = true;
            this.colTKID.Visible = false;
            // 
            // colKeyWord
            // 
            this.colKeyWord.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colKeyWord.HeaderText = "Keyword";
            this.colKeyWord.Name = "colKeyWord";
            this.colKeyWord.ReadOnly = true;
            // 
            // colKeyWordsCnt
            // 
            this.colKeyWordsCnt.HeaderText = "WordCount";
            this.colKeyWordsCnt.Name = "colKeyWordsCnt";
            this.colKeyWordsCnt.ReadOnly = true;
            // 
            // colKeywordLen
            // 
            this.colKeywordLen.HeaderText = "Length";
            this.colKeywordLen.Name = "colKeywordLen";
            this.colKeywordLen.ReadOnly = true;
            // 
            // colEditKeyword
            // 
            this.colEditKeyword.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colEditKeyword.HeaderText = "Edit";
            this.colEditKeyword.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.colEditKeyword.Name = "colEditKeyword";
            this.colEditKeyword.ReadOnly = true;
            this.colEditKeyword.Text = "Edit";
            this.colEditKeyword.UseColumnTextForLinkValue = true;
            this.colEditKeyword.Width = 50;
            // 
            // colDeleteKeyword
            // 
            this.colDeleteKeyword.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colDeleteKeyword.HeaderText = "Delete";
            this.colDeleteKeyword.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.colDeleteKeyword.Name = "colDeleteKeyword";
            this.colDeleteKeyword.ReadOnly = true;
            this.colDeleteKeyword.Text = "Delete";
            this.colDeleteKeyword.UseColumnTextForLinkValue = true;
            this.colDeleteKeyword.Width = 50;
            // 
            // uchrtbSrcDocIndxTerm_PAR
            // 
            this.uchrtbSrcDocIndxTerm_PAR.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.uchrtbSrcDocIndxTerm_PAR.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uchrtbSrcDocIndxTerm_PAR.HighlightMaterials = false;
            this.uchrtbSrcDocIndxTerm_PAR.Location = new System.Drawing.Point(97, 30);
            this.uchrtbSrcDocIndxTerm_PAR.Name = "uchrtbSrcDocIndxTerm_PAR";
            this.uchrtbSrcDocIndxTerm_PAR.PreserveMultiLines = false;
            this.uchrtbSrcDocIndxTerm_PAR.Size = new System.Drawing.Size(532, 31);
            this.uchrtbSrcDocIndxTerm_PAR.TabIndex = 249;
            // 
            // uchrtbTMD_NP
            // 
            this.uchrtbTMD_NP.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uchrtbTMD_NP.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.uchrtbTMD_NP.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uchrtbTMD_NP.HighlightMaterials = false;
            this.uchrtbTMD_NP.Location = new System.Drawing.Point(97, 153);
            this.uchrtbTMD_NP.Name = "uchrtbTMD_NP";
            this.uchrtbTMD_NP.PreserveMultiLines = false;
            this.uchrtbTMD_NP.Size = new System.Drawing.Size(804, 40);
            this.uchrtbTMD_NP.TabIndex = 241;
            // 
            // uchrtbPAR_NP
            // 
            this.uchrtbPAR_NP.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uchrtbPAR_NP.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.uchrtbPAR_NP.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uchrtbPAR_NP.HighlightMaterials = false;
            this.uchrtbPAR_NP.Location = new System.Drawing.Point(97, 63);
            this.uchrtbPAR_NP.Name = "uchrtbPAR_NP";
            this.uchrtbPAR_NP.PreserveMultiLines = false;
            this.uchrtbPAR_NP.Size = new System.Drawing.Size(804, 40);
            this.uchrtbPAR_NP.TabIndex = 240;
            // 
            // colArticleNUMID_NP
            // 
            this.colArticleNUMID_NP.HeaderText = "ArticleNUMID";
            this.colArticleNUMID_NP.Name = "colArticleNUMID_NP";
            this.colArticleNUMID_NP.ReadOnly = true;
            this.colArticleNUMID_NP.Visible = false;
            // 
            // colNUM_NP
            // 
            this.colNUM_NP.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colNUM_NP.HeaderText = "NUM";
            this.colNUM_NP.Name = "colNUM_NP";
            this.colNUM_NP.ReadOnly = true;
            this.colNUM_NP.Width = 50;
            // 
            // colRegNo
            // 
            this.colRegNo.HeaderText = "Reg.No";
            this.colRegNo.Name = "colRegNo";
            this.colRegNo.ReadOnly = true;
            // 
            // colPAR
            // 
            this.colPAR.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colPAR.HeaderText = "PAR";
            this.colPAR.Name = "colPAR";
            this.colPAR.ReadOnly = true;
            this.colPAR.Width = 50;
            // 
            // colSrcDocIndexTerm_NP
            // 
            this.colSrcDocIndexTerm_NP.HeaderText = "SrcDocIndexTerm";
            this.colSrcDocIndexTerm_NP.Name = "colSrcDocIndexTerm_NP";
            this.colSrcDocIndexTerm_NP.ReadOnly = true;
            // 
            // colIndxTermSrcDocID_NP
            // 
            this.colIndxTermSrcDocID_NP.HeaderText = "SrcDocID";
            this.colIndxTermSrcDocID_NP.Name = "colIndxTermSrcDocID_NP";
            this.colIndxTermSrcDocID_NP.ReadOnly = true;
            this.colIndxTermSrcDocID_NP.Visible = false;
            // 
            // colIndxTermSrcDocName_NP
            // 
            this.colIndxTermSrcDocName_NP.HeaderText = "SrcDocName";
            this.colIndxTermSrcDocName_NP.Name = "colIndxTermSrcDocName_NP";
            this.colIndxTermSrcDocName_NP.ReadOnly = true;
            // 
            // colHMD_NP
            // 
            this.colHMD_NP.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colHMD_NP.HeaderText = "HMD";
            this.colHMD_NP.Name = "colHMD_NP";
            this.colHMD_NP.ReadOnly = true;
            this.colHMD_NP.Width = 50;
            // 
            // colAMD
            // 
            this.colAMD.HeaderText = "AMD";
            this.colAMD.Name = "colAMD";
            this.colAMD.ReadOnly = true;
            // 
            // colRole_NP
            // 
            this.colRole_NP.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colRole_NP.HeaderText = "Role";
            this.colRole_NP.Name = "colRole_NP";
            this.colRole_NP.ReadOnly = true;
            this.colRole_NP.Width = 50;
            // 
            // colTMD_Num
            // 
            this.colTMD_Num.HeaderText = "TMD";
            this.colTMD_Num.Name = "colTMD_Num";
            this.colTMD_Num.ReadOnly = true;
            // 
            // colDPT
            // 
            this.colDPT.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colDPT.FalseValue = "N";
            this.colDPT.HeaderText = "DPT:RS";
            this.colDPT.Name = "colDPT";
            this.colDPT.ReadOnly = true;
            this.colDPT.TrueValue = "Y";
            this.colDPT.Width = 55;
            // 
            // colNoStructure
            // 
            this.colNoStructure.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colNoStructure.FalseValue = "N";
            this.colNoStructure.HeaderText = "NoStructure";
            this.colNoStructure.Name = "colNoStructure";
            this.colNoStructure.ReadOnly = true;
            this.colNoStructure.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colNoStructure.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colNoStructure.TrueValue = "Y";
            this.colNoStructure.Width = 55;
            // 
            // colPolymerStructure
            // 
            this.colPolymerStructure.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colPolymerStructure.FalseValue = "N";
            this.colPolymerStructure.HeaderText = "IsPolymer";
            this.colPolymerStructure.Name = "colPolymerStructure";
            this.colPolymerStructure.ReadOnly = true;
            this.colPolymerStructure.TrueValue = "Y";
            this.colPolymerStructure.Width = 50;
            // 
            // colTradeNamePolymer_NP
            // 
            this.colTradeNamePolymer_NP.FalseValue = "N";
            this.colTradeNamePolymer_NP.HeaderText = "TNP";
            this.colTradeNamePolymer_NP.Name = "colTradeNamePolymer_NP";
            this.colTradeNamePolymer_NP.ReadOnly = true;
            this.colTradeNamePolymer_NP.TrueValue = "Y";
            this.colTradeNamePolymer_NP.Width = 40;
            // 
            // colIsCrossReferred
            // 
            this.colIsCrossReferred.FalseValue = "N";
            this.colIsCrossReferred.HeaderText = "CR";
            this.colIsCrossReferred.Name = "colIsCrossReferred";
            this.colIsCrossReferred.ReadOnly = true;
            this.colIsCrossReferred.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colIsCrossReferred.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colIsCrossReferred.TrueValue = "Y";
            this.colIsCrossReferred.Width = 40;
            // 
            // colCrossRefTo_NP
            // 
            this.colCrossRefTo_NP.HeaderText = "CrossRefTo";
            this.colCrossRefTo_NP.Name = "colCrossRefTo_NP";
            this.colCrossRefTo_NP.ReadOnly = true;
            // 
            // colNote
            // 
            this.colNote.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colNote.HeaderText = "Note";
            this.colNote.Name = "colNote";
            this.colNote.ReadOnly = true;
            this.colNote.Width = 50;
            // 
            // colStructure
            // 
            this.colStructure.HeaderText = "Structure";
            this.colStructure.Name = "colStructure";
            this.colStructure.ReadOnly = true;
            // 
            // colStructureImage
            // 
            this.colStructureImage.HeaderText = "StructureImage";
            this.colStructureImage.Name = "colStructureImage";
            this.colStructureImage.ReadOnly = true;
            this.colStructureImage.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colEditNP
            // 
            this.colEditNP.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colEditNP.HeaderText = "Edit";
            this.colEditNP.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.colEditNP.Name = "colEditNP";
            this.colEditNP.ReadOnly = true;
            this.colEditNP.Text = "Edit";
            this.colEditNP.UseColumnTextForLinkValue = true;
            this.colEditNP.Width = 60;
            // 
            // colDeleteNP
            // 
            this.colDeleteNP.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colDeleteNP.HeaderText = "Delete";
            this.colDeleteNP.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.colDeleteNP.Name = "colDeleteNP";
            this.colDeleteNP.ReadOnly = true;
            this.colDeleteNP.Text = "Delete";
            this.colDeleteNP.UseColumnTextForLinkValue = true;
            this.colDeleteNP.Width = 60;
            // 
            // uchrtbSrcDocIndxTerm_CTH
            // 
            this.uchrtbSrcDocIndxTerm_CTH.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.uchrtbSrcDocIndxTerm_CTH.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uchrtbSrcDocIndxTerm_CTH.HighlightMaterials = false;
            this.uchrtbSrcDocIndxTerm_CTH.Location = new System.Drawing.Point(97, 28);
            this.uchrtbSrcDocIndxTerm_CTH.Name = "uchrtbSrcDocIndxTerm_CTH";
            this.uchrtbSrcDocIndxTerm_CTH.PreserveMultiLines = false;
            this.uchrtbSrcDocIndxTerm_CTH.Size = new System.Drawing.Size(835, 30);
            this.uchrtbSrcDocIndxTerm_CTH.TabIndex = 253;
            // 
            // uchrtbTMD_NC
            // 
            this.uchrtbTMD_NC.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uchrtbTMD_NC.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.uchrtbTMD_NC.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uchrtbTMD_NC.HighlightMaterials = false;
            this.uchrtbTMD_NC.Location = new System.Drawing.Point(97, 84);
            this.uchrtbTMD_NC.Name = "uchrtbTMD_NC";
            this.uchrtbTMD_NC.PreserveMultiLines = false;
            this.uchrtbTMD_NC.Size = new System.Drawing.Size(1132, 40);
            this.uchrtbTMD_NC.TabIndex = 241;
            // 
            // colArticleNUMID_NC
            // 
            this.colArticleNUMID_NC.HeaderText = "NUMID";
            this.colArticleNUMID_NC.Name = "colArticleNUMID_NC";
            this.colArticleNUMID_NC.ReadOnly = true;
            this.colArticleNUMID_NC.Visible = false;
            // 
            // colNUM_NC
            // 
            this.colNUM_NC.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colNUM_NC.HeaderText = "NUM";
            this.colNUM_NC.Name = "colNUM_NC";
            this.colNUM_NC.ReadOnly = true;
            this.colNUM_NC.Visible = false;
            this.colNUM_NC.Width = 60;
            // 
            // colCTHClass
            // 
            this.colCTHClass.HeaderText = "Class";
            this.colCTHClass.Name = "colCTHClass";
            this.colCTHClass.ReadOnly = true;
            // 
            // colCTH
            // 
            this.colCTH.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colCTH.HeaderText = "CTH";
            this.colCTH.Name = "colCTH";
            this.colCTH.ReadOnly = true;
            // 
            // colCTHType
            // 
            this.colCTHType.HeaderText = "CTH Type";
            this.colCTHType.Name = "colCTHType";
            this.colCTHType.ReadOnly = true;
            // 
            // colSrcDocIndexTerm_NC
            // 
            this.colSrcDocIndexTerm_NC.HeaderText = "SrcDocIndexTerm";
            this.colSrcDocIndexTerm_NC.Name = "colSrcDocIndexTerm_NC";
            this.colSrcDocIndexTerm_NC.ReadOnly = true;
            // 
            // colIndxTermSrcDocID_NC
            // 
            this.colIndxTermSrcDocID_NC.HeaderText = "SrcDocID";
            this.colIndxTermSrcDocID_NC.Name = "colIndxTermSrcDocID_NC";
            this.colIndxTermSrcDocID_NC.ReadOnly = true;
            this.colIndxTermSrcDocID_NC.Visible = false;
            // 
            // colIndxTermSrcDocName_NC
            // 
            this.colIndxTermSrcDocName_NC.HeaderText = "SrcDocName";
            this.colIndxTermSrcDocName_NC.Name = "colIndxTermSrcDocName_NC";
            this.colIndxTermSrcDocName_NC.ReadOnly = true;
            // 
            // colTMD_CTH
            // 
            this.colTMD_CTH.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colTMD_CTH.HeaderText = "TMD";
            this.colTMD_CTH.Name = "colTMD_CTH";
            this.colTMD_CTH.ReadOnly = true;
            // 
            // colHMD_NC
            // 
            this.colHMD_NC.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colHMD_NC.HeaderText = "HMD";
            this.colHMD_NC.Name = "colHMD_NC";
            this.colHMD_NC.ReadOnly = true;
            // 
            // colRole_NC
            // 
            this.colRole_NC.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colRole_NC.HeaderText = "Role";
            this.colRole_NC.Name = "colRole_NC";
            this.colRole_NC.ReadOnly = true;
            // 
            // colRequireFileReview
            // 
            this.colRequireFileReview.FalseValue = "N";
            this.colRequireFileReview.HeaderText = "RFR";
            this.colRequireFileReview.Name = "colRequireFileReview";
            this.colRequireFileReview.ReadOnly = true;
            this.colRequireFileReview.TrueValue = "Y";
            this.colRequireFileReview.Width = 40;
            // 
            // colTradeNamePolymer_NC
            // 
            this.colTradeNamePolymer_NC.FalseValue = "N";
            this.colTradeNamePolymer_NC.HeaderText = "TNP";
            this.colTradeNamePolymer_NC.Name = "colTradeNamePolymer_NC";
            this.colTradeNamePolymer_NC.ReadOnly = true;
            this.colTradeNamePolymer_NC.TrueValue = "Y";
            this.colTradeNamePolymer_NC.Width = 40;
            // 
            // colCrossRefTo_NC
            // 
            this.colCrossRefTo_NC.HeaderText = "CrossRefTo";
            this.colCrossRefTo_NC.Name = "colCrossRefTo_NC";
            this.colCrossRefTo_NC.ReadOnly = true;
            this.colCrossRefTo_NC.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colCrossRefTo_NC.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colEdit_NC
            // 
            this.colEdit_NC.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colEdit_NC.HeaderText = "Edit";
            this.colEdit_NC.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.colEdit_NC.Name = "colEdit_NC";
            this.colEdit_NC.ReadOnly = true;
            this.colEdit_NC.Text = "Edit";
            this.colEdit_NC.UseColumnTextForLinkValue = true;
            this.colEdit_NC.Width = 60;
            // 
            // colDelete_NC
            // 
            this.colDelete_NC.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colDelete_NC.HeaderText = "Delete";
            this.colDelete_NC.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.colDelete_NC.Name = "colDelete_NC";
            this.colDelete_NC.ReadOnly = true;
            this.colDelete_NC.Text = "Delete";
            this.colDelete_NC.UseColumnTextForLinkValue = true;
            this.colDelete_NC.Width = 60;
            // 
            // ucSplCharsToolStrip_Indexing1
            // 
            this.ucSplCharsToolStrip_Indexing1.BackColor = System.Drawing.Color.White;
            this.ucSplCharsToolStrip_Indexing1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ucSplCharsToolStrip_Indexing1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ucSplCharsToolStrip_Indexing1.Location = new System.Drawing.Point(0, 0);
            this.ucSplCharsToolStrip_Indexing1.Name = "ucSplCharsToolStrip_Indexing1";
            this.ucSplCharsToolStrip_Indexing1.Size = new System.Drawing.Size(1246, 74);
            this.ucSplCharsToolStrip_Indexing1.TabIndex = 2;
            // 
            // frmMacroIndexing
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1246, 565);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmMacroIndexing";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Macro Indexing";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmOrganicIndexing_FormClosing);
            this.Load += new System.EventHandler(this.frmOrganicIndexing_Load);
            this.pnlMain.ResumeLayout(false);
            this.tcMain.ResumeLayout(false);
            this.tpArticleInfo.ResumeLayout(false);
            this.pnlArticleCntrls.ResumeLayout(false);
            this.splContArticleInfo.Panel1.ResumeLayout(false);
            this.splContArticleInfo.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splContArticleInfo)).EndInit();
            this.splContArticleInfo.ResumeLayout(false);
            this.pnlTANInfo.ResumeLayout(false);
            this.pnlTANInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKeywords)).EndInit();
            this.pnlSave.ResumeLayout(false);
            this.pnlKeyword.ResumeLayout(false);
            this.pnlKeyword.PerformLayout();
            this.tpNUM_PAR.ResumeLayout(false);
            this.splContNUMPAR.Panel1.ResumeLayout(false);
            this.splContNUMPAR.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splContNUMPAR)).EndInit();
            this.splContNUMPAR.ResumeLayout(false);
            this.splContNUM.Panel1.ResumeLayout(false);
            this.splContNUM.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splContNUM)).EndInit();
            this.splContNUM.ResumeLayout(false);
            this.pnlNUMPAR.ResumeLayout(false);
            this.pnlNUMPAR.PerformLayout();
            this.pnlButtons_NP.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nudNUMPAR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNUM_PAR)).EndInit();
            this.splContStruct_Image.Panel1.ResumeLayout(false);
            this.splContStruct_Image.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splContStruct_Image)).EndInit();
            this.splContStruct_Image.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbStructureImage)).EndInit();
            this.pnlStructButtons.ResumeLayout(false);
            this.tpNUM_CTH.ResumeLayout(false);
            this.splContNUMCTH.Panel1.ResumeLayout(false);
            this.splContNUMCTH.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splContNUMCTH)).EndInit();
            this.splContNUMCTH.ResumeLayout(false);
            this.pnlNUMCTH.ResumeLayout(false);
            this.pnlNUMCTH.PerformLayout();
            this.pnlButtons_NC.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNUM_CTH)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlArticleCntrls;
        private System.Windows.Forms.TextBox txtTAN;
        private System.Windows.Forms.Label lblTan;
        private System.Windows.Forms.TextBox txtCrossRefSections;
        private System.Windows.Forms.TextBox txtSubSection;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSection;
        private System.Windows.Forms.CheckBox chkSPA_HDR;
        private System.Windows.Forms.Label lblAbstract;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblKey;
        private System.Windows.Forms.TextBox txtKeyword;
        private System.Windows.Forms.DataGridView dgvKeywords;
        private System.Windows.Forms.TabControl tcMain;
        private System.Windows.Forms.TabPage tpNUM_PAR;
        private System.Windows.Forms.TabPage tpNUM_CTH;
        private System.Windows.Forms.Button btnAddKey;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown nudNUMPAR;
        private System.Windows.Forms.TextBox txtRegistryNo;
        private System.Windows.Forms.CheckBox chkDPT_RS;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtAMD;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtHMD_NP;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtRoleNP;
        private System.Windows.Forms.Button btnSaveNUMPAR;
        private System.Windows.Forms.Button btnResetNUMPAR;
        private System.Windows.Forms.DataGridView dgvNUM_PAR;
        private System.Windows.Forms.SplitContainer splContNUM;
        private System.Windows.Forms.SplitContainer splContNUMPAR;
        private System.Windows.Forms.Panel pnlNUMPAR;
        private MDL.Draw.Renditor.Renditor ChemRenditor;
        private System.Windows.Forms.PictureBox pbStructureImage;
        private System.Windows.Forms.SplitContainer splContNUMCTH;
        private System.Windows.Forms.Panel pnlNUMCTH;
        private System.Windows.Forms.TextBox txtCTH;
        private System.Windows.Forms.Button btnSaveNUMCTH;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnResetNUMCTH;
        private System.Windows.Forms.TextBox txtRoleNC;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtHMD_NC;
        private System.Windows.Forms.DataGridView dgvNUM_CTH;
        private System.Windows.Forms.LinkLabel lnkRoleNP;
        private System.Windows.Forms.LinkLabel lnkRoleNC;
        private System.Windows.Forms.Label lblComments;
        private System.Windows.Forms.TextBox txtComments;
        private System.Windows.Forms.CheckBox chkNoStructure;
        private System.Windows.Forms.Label lblNotes;
        private System.Windows.Forms.TextBox txtNUMNote;
        private System.Windows.Forms.Panel pnlSave;
        private System.Windows.Forms.Button btnSaveArticleInfo;
        private System.Windows.Forms.Label lblCTHType;
        private System.Windows.Forms.RadioButton rbnCTHCrystalStruct;
        private System.Windows.Forms.RadioButton rbnCTHMolStruct;
        private System.Windows.Forms.RadioButton rbnCTHGeneral;
        private System.Windows.Forms.Label lblCTH_TMD;
        private System.Windows.Forms.Button btnDATPreview;
        private System.Windows.Forms.Button btnExportSDF;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTKID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colKeyWord;
        private System.Windows.Forms.DataGridViewTextBoxColumn colKeyWordsCnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn colKeywordLen;
        private System.Windows.Forms.DataGridViewLinkColumn colEditKeyword;
        private System.Windows.Forms.DataGridViewLinkColumn colDeleteKeyword;
        private System.Windows.Forms.Button btnMolToImage;
        private System.Windows.Forms.CheckBox chkReviewTAN;
        private System.Windows.Forms.CheckBox chkQueryTAN;
        private System.Windows.Forms.LinkLabel lnkCTH;
        private System.Windows.Forms.TabPage tpArticleInfo;
        private System.Windows.Forms.Panel pnlButtons_NP;
        private System.Windows.Forms.Panel pnlButtons_NC;
        private System.Windows.Forms.SplitContainer splContArticleInfo;
        private System.Windows.Forms.Panel pnlKeyword;
        private System.Windows.Forms.Panel pnlStructButtons;
        private System.Windows.Forms.Button btnCopyToImage;
        private System.Windows.Forms.SplitContainer splContStruct_Image;
        private System.Windows.Forms.Label lblSDFHdr;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblNumTMD;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewLinkColumn dataGridViewLinkColumn1;
        private System.Windows.Forms.DataGridViewLinkColumn dataGridViewLinkColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.DataGridViewLinkColumn dataGridViewLinkColumn3;
        private System.Windows.Forms.DataGridViewLinkColumn dataGridViewLinkColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewLinkColumn dataGridViewLinkColumn5;
        private System.Windows.Forms.DataGridViewLinkColumn dataGridViewLinkColumn6;
        private System.Windows.Forms.Panel pnlTANInfo;
        private System.Windows.Forms.LinkLabel lnkSection;
        private UserControls.ucHtmlRichText uchrtbTMD;
        private UserControls.ucHtmlRichText uchrtbAbstract;
        private UserControls.ucHtmlRichText uchrtbTitle;
        private UserControls.ucHtmlRichText uchrtbTMD_NP;
        private UserControls.ucHtmlRichText uchrtbPAR_NP;
        private UserControls.ucHtmlRichText uchrtbTMD_NC;
        private System.Windows.Forms.Button btnTANComplete;
        private System.Windows.Forms.Button btnRejectTAN;
        private System.Windows.Forms.Button btnExportToPdf;
        private System.Windows.Forms.TextBox txtNUMCTH;
        private System.Windows.Forms.LinkLabel lnkCrossRef;
        private System.Windows.Forms.Button btnHideSplChars;
        private System.Windows.Forms.CheckBox chkIsPolymer;
        private UserControls.ucSplCharsToolStrip_Indexing ucSplCharsToolStrip_Indexing1;
        private System.Windows.Forms.LinkLabel lnkRegNo;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn3;
        private System.Windows.Forms.CheckBox chkIsTradeNamePolymer_NP;
        private System.Windows.Forms.TextBox txtCrossRefPolymer_NP;
        private System.Windows.Forms.CheckBox chkRequireFileReview;
        private System.Windows.Forms.CheckBox chkIsTradeNamePolymer_NC;
        private System.Windows.Forms.TextBox txtCrossRefPolymer_NC;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn5;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.CheckBox chkIsCrossRefTo;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn7;
        private System.Windows.Forms.CheckBox chkIncludeInREP;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.Button btnXmlPreview;
        private System.Windows.Forms.ComboBox cmbTANDocs_PAR;
        private System.Windows.Forms.Label label2;
        private UserControls.ucHtmlRichText uchrtbSrcDocIndxTerm_PAR;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbTANDocs_CTH;
        private System.Windows.Forms.Label label6;
        private UserControls.ucHtmlRichText uchrtbSrcDocIndxTerm_CTH;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridViewTextBoxColumn colArticleNUMID_NP;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNUM_NP;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRegNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPAR;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSrcDocIndexTerm_NP;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIndxTermSrcDocID_NP;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIndxTermSrcDocName_NP;
        private System.Windows.Forms.DataGridViewTextBoxColumn colHMD_NP;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAMD;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRole_NP;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTMD_Num;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colDPT;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colNoStructure;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colPolymerStructure;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colTradeNamePolymer_NP;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colIsCrossReferred;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCrossRefTo_NP;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNote;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStructure;
        private System.Windows.Forms.DataGridViewImageColumn colStructureImage;
        private System.Windows.Forms.DataGridViewLinkColumn colEditNP;
        private System.Windows.Forms.DataGridViewLinkColumn colDeleteNP;
        private System.Windows.Forms.DataGridViewTextBoxColumn colArticleNUMID_NC;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNUM_NC;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCTHClass;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCTH;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCTHType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSrcDocIndexTerm_NC;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIndxTermSrcDocID_NC;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIndxTermSrcDocName_NC;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTMD_CTH;
        private System.Windows.Forms.DataGridViewTextBoxColumn colHMD_NC;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRole_NC;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colRequireFileReview;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colTradeNamePolymer_NC;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCrossRefTo_NC;
        private System.Windows.Forms.DataGridViewLinkColumn colEdit_NC;
        private System.Windows.Forms.DataGridViewLinkColumn colDelete_NC;
        private Keyoti.RapidSpell.RapidSpellAsYouType rapidSpellAsYouType1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.LinkLabel lnkCrossRefTo_CTH;
    }
}