﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using System.Text.RegularExpressions;
using IndxReactNarrBLL;
using IndxReactNarrDAL;
using System.IO;
using IndxReactNarr.Common;
using IndxReactNarr.Export;
using IndxReactNarr;
using System.Collections;
using HtmlRichText;
using SautinSoft;
using mshtml;
using IndxReactNarr.TaskManagement;
using IndxReactNarrBll;
using IndxReactNarr.PdfExport;
using System.Diagnostics;
using IndxReactNarr.Curation.OrgIndexing;

namespace IndxReactNarr
{
    public partial class frmMacroIndexing : Form
    {
        #region Constructor

        public frmMacroIndexing()
        {
            InitializeComponent();

            try
            {
                rapidSpellAsYouType1.DictFilePath = System.IO.Path.Combine(Application.StartupPath, "DICT-EN-US-USEnglish.dict");
                rapidSpellAsYouType1.RapidSpellChecker.ShareDictionary = true;
            }
            catch
            { }
        }
 
        #endregion

        #region Public Properties

        public int TAN_ID { get; set; }
        public string TAN_Name { get; set; }
        public DataTable TANCommentsTbl { get; set; } 
        public DataTable ArticleNUMs { get; set; }
        public DataTable TANInfoTbl { get; set; }
        public DataTable NUM_PAR_Data { get; set; }
        public DataTable NUM_CTH_Data { get; set; }
        public DataTable TANKeyWords { get; set; }
        public Hashtable SplCharRepData { get; set; }
        DataTable XmlConvData { get; set; }
        public int Task_ID { get; set; }
        public int TaskAlloc_ID { get; set; }

        public DataTable SectionMaster { get; set; }

        public DataTable TANDocuments { get; set; }   

        #endregion       

        //Html_RtfConversions htmlRtfConvs = new Html_RtfConversions();

        #region Page Load Event

        private void frmOrganicIndexing_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;
                
                HideRejectTANButtonOnUserRole(GlobalVariables.RoleName);

                if (TAN_ID > 0)
                {
                    //Special Chars Replacements
                    SplCharRepData = ucSplCharsToolStrip_Indexing1.GetHTMLReplacementsForSpecialCharsToolStripItems();
                                 
                    //Indexing Roles
                    if(GlobalVariables.IndexingRoles == null)
                       GlobalVariables.IndexingRoles = OrganicIndexingDB.GetIndexingRoleIndicators();

                    //Section Master
                    if(GlobalVariables.IndexingSections == null)
                        GlobalVariables.IndexingSections = OrganicIndexingDB.GetIndexingSectionMasterDetails();

                    //SubSections
                    if(GlobalVariables.IndexingSubSections == null)
                        GlobalVariables.IndexingSubSections = OrganicIndexingDB.GetIndexingSubSections();

                    //Concept Text Headings
                    if (GlobalVariables.ConceptTextHeadings == null)
                        GlobalVariables.ConceptTextHeadings = OrganicIndexingDB.GetIndexingConceptTextHeadings();

                    if (XmlConvData == null)
                        XmlConvData = ReactDB.GetXMLConvDetails();

                    //TAN Documents - for Xml export
                    TANDocuments = NarrativesDB.GetTANDocumentsOnTANID(TAN_ID);
                    BindTANDocumentsToComboBox(TANDocuments);

                    //Article Information
                    TANCommentsTbl = ReactDB.GetTANCommentsOnTANID(TAN_ID); 
                    TANInfoTbl = ReactDB.GetTANDetailsOnTANID(TAN_ID);
                    BindArticleInfoToControls(TANInfoTbl, TANCommentsTbl);

                    //Get Article NUMs
                    NUM_PAR_Data = OrganicIndexingDB.GetIndexingNUMsOnTANID(TAN_ID, "NUM_PAR");//GetIndexingArticleNUMs(TAN_Name, "NUM_PAR");
                    NUM_CTH_Data = OrganicIndexingDB.GetIndexingNUMsOnTANID(TAN_ID, "NUM_CTH");//GetIndexingArticleNUMs(TAN_Name, "NUM_CTH");
                   
                    //Bind NUMs info to PAR & CTH grids
                    BindDataToNUM_PARGrid(NUM_PAR_Data);
                    BindDataToNUM_CTHGrid(NUM_CTH_Data);                    
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        private void BindTANDocumentsToComboBox(DataTable tanDocuments)
        {
            try
            {
                if (tanDocuments != null)
                {
                    cmbTANDocs_PAR.DataSource = tanDocuments;
                    cmbTANDocs_PAR.ValueMember = "TAN_DOC_ID";
                    cmbTANDocs_PAR.DisplayMember = "FILE_NAME";

                    cmbTANDocs_CTH.DataSource = tanDocuments.Copy();
                    cmbTANDocs_CTH.ValueMember = "TAN_DOC_ID";
                    cmbTANDocs_CTH.DisplayMember = "FILE_NAME";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void HideRejectTANButtonOnUserRole(string userRole)
        {
            try
            {
                if (!string.IsNullOrEmpty(userRole))
                {
                    if (userRole.ToUpper() == "ANALYST" || userRole.ToUpper() == "ADMINISTRATOR" ||
                        userRole.ToUpper() == "TOOL MANAGER" || userRole.ToUpper() == "PROJECT MANAGER")
                    {
                        btnRejectTAN.Visible = false;
                    }
                    else//Reject only for Review Analyst and Quality Analyst
                    {
                        btnRejectTAN.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #region PictureBox Click Event

        private void pbStructureImage_Click(object sender, EventArgs e)
        {
            try
            {
                //System.Drawing.Image returnImage = null;
                if (Clipboard.ContainsImage())
                {
                    pbStructureImage.Image  = Clipboard.GetImage();

                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        #region Role link Click Events

        private void lnkRoleNP_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                frmEditIndexingRole objEditRole = new frmEditIndexingRole();                
                objEditRole.SelectedRoles = txtRoleNP.Text.Trim();
                if (objEditRole.ShowDialog() == DialogResult.OK)
                {
                    txtRoleNP.Text = objEditRole.SelectedRoles.Trim();                    
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void lnkRoleNC_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                frmEditIndexingRole objEditRole = new frmEditIndexingRole();                
                objEditRole.SelectedRoles = txtRoleNC.Text.Trim();
                if (objEditRole.ShowDialog() == DialogResult.OK)
                {
                    txtRoleNC.Text = objEditRole.SelectedRoles.Trim();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion
       
        #region Validation methods

        private bool ValidateSectionNo(string sectionNo,string sectionType, ref string errMsg)
        {
            bool blStatus = true;
            try
            {
                if (!string.IsNullOrEmpty(sectionNo))
                {
                    int secNo = 0;
                    if (!int.TryParse(sectionNo.Trim(), out secNo))//Check Numeric value
                    {
                        blStatus = false;
                        errMsg = errMsg + "\r\n" + sectionType + " should be number";
                    }
                    //else if (sectionNo.Trim().Length != 2)
                    //{
                    //    blStatus = false;
                    //    errMsg = errMsg + "\r\n" + sectionType + " length should be two digits";
                    //}                   
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool ValidateSectionGivenSections(string secNo, out string errMsg)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (!string.IsNullOrEmpty(secNo))
                {
                    //CAS should be queried if you encounter documents that belong in sections other than those listed below. 
                    //35. Chemistry of Synthetic High Polymers
                    //36. Physical Properties of Synthetic High Polymers
                    //37. Plastics Manufacture and Processing
                    //38. Plastics Fabrication and Uses 
                    //39. Synthetic Elastomers and Natural Rubber
                    //40. Textiles and Fibers 
                    //41. Dyes, Organic Pigments, Fluorescent Brighteners, and Photographic Sensitizers
                    //42. Coatings, Inks, and Related Products 
                    //43. Cellulose, Lignin, Paper, and Other Wood Products 
                    //44. Industrial Carbohydrates 
                    //45. Industrial Organic Chemicals, Leather, Fats, and Waxes 
                    //46. Surface-Active Agents and Detergents 

                    string[] saSections = new string[] { "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46" };
                    if (!saSections.Contains(secNo))
                    {
                        blStatus = false;
                        strErrMsg = "Section should be 35 - 46";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsg = strErrMsg;
            return blStatus;
        }

        private bool ValidateArticleInformation(ref string errMsg)
        {
            bool blStatus = true;
            try
            {
                string strErr = "";
                //Section validation
                if (string.IsNullOrEmpty(txtSection.Text.Trim()))
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "Section can't be null";
                }
                else
                {
                    strErr = "";
                    if (!ValidateSectionNo(txtSection.Text.Trim(), "Section", ref strErr))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + strErr;
                    }
                    if (!ValidateSectionGivenSections(txtSection.Text.Trim(), out strErr))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + strErr;
                    }
                }

                //Sub-Section validation
                if (!chkReviewTAN.Checked)//For Review TAN, no need to check the Sub-Section
                {
                    if (string.IsNullOrEmpty(txtSubSection.Text.Trim()))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "SubSection can't be null";
                    }
                    else if (!ValidateSectionNo(txtSubSection.Text.Trim(), "SubSection", ref strErr))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + strErr;
                    }
                }

                //Cross Reference validation
                if (!string.IsNullOrEmpty(txtCrossRefSections.Text.Trim()))
                {
                    string[] saCrossRef = txtCrossRefSections.Text.Trim().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                    if (saCrossRef != null)
                    {
                        if (saCrossRef.Length <= 6)
                        {
                            foreach (string crossRef in saCrossRef)
                            {
                                strErr = "";
                                if (!ValidateSectionNo(crossRef.Trim(), "Cross Ref.", ref strErr))
                                {
                                    blStatus = false;
                                    errMsg = errMsg.Trim() + "\r\n" + strErr;
                                }
                            }
                        }
                        else
                        {
                            blStatus = false;
                            errMsg = errMsg.Trim() + "\r\n" + "Cross Reference should be < 6 sections";
                        }
                    }
                }

                //Title Validation
                if (string.IsNullOrEmpty(uchrtbTitle.hrtbPara.Text.Trim()))
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "Title can't be null";
                }
                else if (uchrtbTitle.hrtbPara.Text.Trim().Length > 600)
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "Title length should be < 600 characters";
                }
                else if (Common.Validations.ValidateUnicodeCharactersInString(uchrtbTitle.hrtbPara.Text.Trim(), out strErr))//New validation on 10th Sep 2014
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "Title contains invalid characters " + strErr.Trim();
                }

                //Abstract Validation
                if (string.IsNullOrEmpty(uchrtbAbstract.hrtbPara.Text.Trim()))
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "Abstract can't be null";
                }
                else if (uchrtbAbstract.hrtbPara.Text.Trim().Length > 1500)
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "Abstract length should be < 1500 characters";
                }
                else if (Common.Validations.ValidateUnicodeCharactersInString(uchrtbAbstract.hrtbPara.Text.Trim(), out strErr))//New validation on 10th Sep 2014
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "Abstract contains invalid characters " + strErr.Trim();
                }
                                
                //TMD Validation
                if (string.IsNullOrEmpty(uchrtbTMD.hrtbPara.Text.Trim()))
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "TMD can't be null";
                }
                else if (uchrtbTMD.hrtbPara.Text.Trim().Length > 240)
                {
                    blStatus = false;
                    errMsg = errMsg + "\r\n" + "TMD length should be < 240 characters";
                }
                else if (Common.Validations.ValidateUnicodeCharactersInString(uchrtbTMD.hrtbPara.Text.Trim(), out strErr))//New validation on 10th Sep 2014
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "TMD contains invalid characters " + strErr.Trim();
                }
                else if (uchrtbTMD.hrtbPara.Text.Trim().ToUpper().StartsWith("A ") || uchrtbTMD.hrtbPara.Text.Trim().ToUpper().StartsWith("AN ") ||
                         uchrtbTMD.hrtbPara.Text.Trim().ToUpper().StartsWith("THE ") || uchrtbTMD.hrtbPara.Text.Trim().ToUpper().StartsWith("STUDY OF ") ||
                         uchrtbTMD.hrtbPara.Text.Trim().ToUpper().StartsWith("RESEARCH ON "))
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "TMD should not start with A / An / The / Study of / Research on";
                }

                //If Review TAN, First KEY should start with 'review' and each KEY should contain 'review' word.              
                if (chkReviewTAN.Checked) 
                {
                    strErr = "";
                    if (!ValidateReviewTANKeywords(ref strErr))
                    {
                        //Validate review in KEYs
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + strErr.Trim();
                    }

                    //All reviews are sectioned in section 35 to 46 with subsection of zero                    
                    if (!(Convert.ToInt32(txtSection.Text.Trim()) >= 35 && Convert.ToInt32(txtSection.Text.Trim()) <= 46))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "All reviews are sectioned in section 35 to 46";
                    }
                    else
                    {
                        int intSubSec = 0;
                        int.TryParse(txtSubSection.Text.Trim(), out intSubSec);

                        if (intSubSec != 0)
                        {
                            blStatus = false;
                            errMsg = errMsg.Trim() + "\r\n" + "All reviews subsection should be zero";
                        }
                    }
                }

                //Query TAN
                if (chkQueryTAN.Checked)
                {
                    //Nullify all validations
                    blStatus = true;
                    errMsg = "";

                    if (string.IsNullOrEmpty(txtComments.Text.Trim()))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "For query TAN, Comments are mandatory.";
                    }
                }

                //Either Query TAN or Review TAN can be selected
                if (chkQueryTAN.Checked && chkReviewTAN.Checked)
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "Both Review TAN & Query TAN can't be selected";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool ValidateNUM_PARInformation(ref string errMsg)
        {
            bool blStatus = true;
            try
            {
                string strErr = "";
                //Validate NUM
                if (nudNUMPAR.Value == 0)
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "NUM should be > 0";
                }
                else if (CheckForDuplicateNUM((int)nudNUMPAR.Value))
                {
                    //Check for duplicate NUM
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "Duplicate NUM";
                }
                
                //Validate PAR
                //if (string.IsNullOrEmpty(uchrtbPAR_NP.hrtbPara.Text.Trim())) //Allow PAR blank - 29th Dec 2014
                //{
                //    blStatus = false;
                //    errMsg = errMsg.Trim() + "\r\n" + "PAR can't be null";
                //}               
                if (!string.IsNullOrEmpty(uchrtbPAR_NP.hrtbPara.Text.Trim()))
                {
                    if (uchrtbPAR_NP.hrtbPara.Text.Trim().Length > 500)
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "PAR length should be < 500 characters";
                    }
                    int intPAR = 0;
                    if (int.TryParse(uchrtbPAR_NP.hrtbPara.Text.Trim(), out intPAR))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "PAR contains number";
                    }

                    //Check for duplicate PAR
                    if (CheckForDuplicatePAR(Html_RtfConversions.Instance.GetHTMLFromRTFString(uchrtbPAR_NP.hrtbPara.Rtf), txtAMD.Text.Trim()))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "Duplicate PAR";
                    }

                    if (Common.Validations.ValidateUnicodeCharactersInString(uchrtbPAR_NP.hrtbPara.Text.Trim(), out strErr))//New validation on 10th Sep 2014
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "PAR contains invalid characters " + strErr;
                    }
                }
                else //If PAR is blank, Note is mandatory - 29th Dec 2014
                {
                    if (string.IsNullOrEmpty(txtNUMNote.Text.Trim()))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "If PAR is null, Note is mandatory";
                    }
                }
                
                //Validate Role
                if (string.IsNullOrEmpty(txtRoleNP.Text.Trim()))
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "Role can't be null";
                }

                //Notes Validation
                if (txtNUMNote.Text.Trim().Length > 1500)
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "Note length should be < 1500 characters";
                }

                //AMD Validation
                if (txtAMD.Text.Trim().Length > 1500)
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "AMD length should be < 1500 characters";
                }

                ////HMD Validation
                //if (txtHMD_NP.Text.Trim().Length > 240)
                //{
                //    blStatus = false;
                //    errMsg = errMsg.Trim() + "\r\n" + "HMD length should be < 240 characters";
                //}
                ////TMD Validation
                //if (uchrtbTMD_NP.hrtbPara.Text.Trim().Length > 240)
                //{
                //    blStatus = false;
                //    errMsg = errMsg.Trim() + "\r\n" + "NUM-TMD length should be < 240 characters";
                //}
                
                //New validation on 20NOV2015
                //The total character count of HMD + TMD should not be more than 238, otherwise error message occurs.

                //New modification on 16DEC2015
                //Please include the following change in XML file from this point on: total character count of HMD + TMD should not be more than 210.

                if (!string.IsNullOrEmpty(uchrtbTMD_NP.hrtbPara.Text.Trim()))
                {
                    //Check HMD and NUM TMD combined length
                    if ((txtHMD_NP.Text.Trim().Length + uchrtbTMD_NP.hrtbPara.Text.Trim().Length) > 210)
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + Environment.NewLine + "HMD and NUM-TMD combined length should be <= 210 characters";
                    }
                }
                else
                {
                    //Check HMD and Article TMD combined length
                    if ((txtHMD_NP.Text.Trim().Length + uchrtbTMD.hrtbPara.Text.Trim().Length) > 210)
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + Environment.NewLine + "HMD and Article TMD combined length should be <= 210 characters";
                    }
                }

                if (Common.Validations.ValidateUnicodeCharactersInString(uchrtbTMD_NP.hrtbPara.Text.Trim(), out strErr))//New validation on 10th Sep 2014
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "TMD contains invalid characters " + strErr.Trim();
                }

                //Validate Registry No.
                if (!string.IsNullOrEmpty(txtRegistryNo.Text.Trim()))                
                {
                    int intRegNo = 0;
                    if(int.TryParse(txtRegistryNo.Text.Trim(), out intRegNo))
                    {
                        if (!ValidateRegistryNoCheckSUMValue(intRegNo))
                        {
                            blStatus = false;
                            errMsg = errMsg.Trim() + "\r\n" + "In-valid Registry No. CheckSum validation violated";
                        }
                        //else if (CheckForDuplicateRegNo(intRegNo))//Allow duplicate Reg.No - new validation on 11th March 2015
                        //{
                        //    //Check for duplicate Registry No.
                        //    blStatus = false;
                        //    errMsg = errMsg.Trim() + "\r\n" + "Duplicate Registry No.";
                        //}
                    }
                    else
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "Registry No. should be integer";
                    }                    
                }                
                
                //No Structure Validation
                if (chkNoStructure.Checked)
                {
                    if (string.IsNullOrEmpty(txtNUMNote.Text.Trim()))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "NUM Note is mandatory when NoStructure flag is set";
                    }

                    if (!string.IsNullOrEmpty(ChemRenditor.MolfileString) || pbStructureImage.Image != null || !string.IsNullOrEmpty(txtRegistryNo.Text.Trim()))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "Structure Molfile, Structure Image and RegistryNo should be null when NoStructure flag is set";
                    }
                }
                else 
                {
                    if (chkIsPolymer.Checked == false)
                    {
                        //New validation on 23DEC2015 - 
                        //In the first case of Trade-Name Non-Polymers
                        //Since the REG field is empty, it is asking for an SDF image or ‘No structure Available’ field to be flagged. But in cases when the structure is known (as it is registrable), no SDF image is required. In such cases we are unable to save the PAR.

                        //Validation commented on 23DEC2015
                        //if (string.IsNullOrEmpty(txtRegistryNo.Text.Trim()) && string.IsNullOrEmpty(ChemRenditor.MolfileString))
                        //{
                        //    blStatus = false;
                        //    errMsg = errMsg.Trim() + "\r\n" + "Structure is mandatory when Registry No. is not available";
                        //}
                        if (string.IsNullOrEmpty(txtRegistryNo.Text.Trim()) && string.IsNullOrEmpty(ChemRenditor.MolfileString) && pbStructureImage.Image == null)
                        {
                            blStatus = false;
                            errMsg = errMsg.Trim() + "\r\n" + "Structure is mandatory when Registry No. is not available";
                        }
                        else if (pbStructureImage.Image == null && (!string.IsNullOrEmpty(txtRegistryNo.Text.Trim()) && chkDPT_RS.Checked == false))//Validate Structure Image
                        {
                            blStatus = false;
                            errMsg = errMsg.Trim() + "\r\n" + "Structure Image is mandatory when Registry No. is available";
                        }
                    }
                }

                //New validation on 17th Sep 2014
                if (chkIsTradeNamePolymer_NP.Checked && !chkIsCrossRefTo.Checked)
                {
                    if (string.IsNullOrEmpty(txtNUMNote.Text.Trim()))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "Note is mandatory when Trade Name Polymer is checked";
                    }
                }

                //New validation on 18th Sep 2014
                if (chkIsCrossRefTo.Checked)
                {
                    if (string.IsNullOrEmpty(txtHMD_NP.Text.Trim()))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "HMD is mandatory when Trade Name Polymer is checked";
                    }

                    if (string.IsNullOrEmpty(txtCrossRefPolymer_NP.Text.Trim()))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "Cross Reference Name is mandatory when Trade Name Polymer is checked";
                    }

                    if (!chkIsTradeNamePolymer_NP.Checked)
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "Trade Name Polymer is mandatory when cross referenced";
                    }
                }

                ////Validate NUM sequence
                //string strErr = "";
                //if (!ValidateNUMsSequence(out strErr))
                //{
                //    blStatus = false;
                //    errMsg = errMsg.Trim() + "\r\n" + strErr.Trim();
                //}

                //Note field can contain Reg.No, If it is Reg.No validate CheckSum - New validation on 11th March 2015
                if (!string.IsNullOrEmpty(txtNUMNote.Text.Trim()))
                {
                    int tempNumNote = 0;
                    if (int.TryParse(txtNUMNote.Text.Trim(), out tempNumNote))
                    {
                        if (!ValidateRegistryNoCheckSUMValue(tempNumNote))
                        {
                            blStatus = false;
                            errMsg = errMsg.Trim() + "\r\n" + "In-valid Registry No. in the NUM Note";
                        }
                    }
                }

                //New Validation on 12th Dec 2015
                //Two PAR entries with same REG number should be saved only when one PAR is without AMD and the other one is with AMD 
                if (!string.IsNullOrEmpty(txtRegistryNo.Text) && !string.IsNullOrEmpty(uchrtbPAR_NP.hrtbPara.Text.Trim()))
                {
                    if (AllowPARsOnlyWithAndWithoutAMD(ref errMsg))
                    {
                        blStatus = false;
                    }
                }

                //New validation on 17th Dec 2015
                //If Reg.No is empty and Note contains Reg.No then PAR should not be NULL
                if (string.IsNullOrEmpty(txtRegistryNo.Text.Trim()) && !string.IsNullOrEmpty(txtNUMNote.Text.Trim()))
                {
                    int tempNumNote = 0;
                    if (int.TryParse(txtNUMNote.Text.Trim(), out tempNumNote) && ValidateRegistryNoCheckSUMValue(tempNumNote))
                    {
                        if (string.IsNullOrEmpty(uchrtbPAR_NP.hrtbPara.Text.Trim()))
                        {
                            blStatus = false;
                            errMsg = errMsg.Trim() + Environment.NewLine + "If Reg.No is Null and Note contains Reg.No then PAR is mandatory";
                        }
                    }
                }
                
                //PAR is disabled in SDF, PAR is showing to React team, so PAR is required. - 25NOV 2015
                //New validation on 24th Nov 2015
                //a chemical name should not be present in the PAR field if a mol file or registry number is returned for that index entry
                //if (!string.IsNullOrEmpty(ChemRenditor.MolfileString) && !string.IsNullOrEmpty(uchrtbPAR_NP.hrtbPara.Text.Trim()))
                //{
                //    blStatus = false;
                //    errMsg = errMsg.Trim() + Environment.NewLine + "PAR should be blank when Sdf Structure is available";
                //}

                if (TAN_ID >= 55635) //from rxnfile.980071 shipment onwards Xml delivery
                {
                    if (string.IsNullOrEmpty(uchrtbSrcDocIndxTerm_PAR.hrtbPara.Text.Trim()))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + Environment.NewLine + "Source document Index Term is mandatory";
                    }

                    if (cmbTANDocs_PAR.SelectedIndex < 0)
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + Environment.NewLine + "Index Term Source Doc.ID is mandatory";
                    }
                    else
                    {
                        if (!cmbTANDocs_PAR.Text.ToUpper().EndsWith(".PDF"))
                        {
                            blStatus = false;
                            errMsg = errMsg.Trim() + Environment.NewLine + "Index Term Source Doc.ID should be of Pdf type";
                        }
                    }
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool AllowPARsOnlyWithAndWithoutAMD(ref string str)
        {
            bool blStatus = false;
            IEnumerable<DataRow> temp;
            try
            {
                if (NUM_PAR_Data != null && NUM_PAR_Data.Rows.Count > 0)
                {
                    if (string.IsNullOrEmpty(txtAMD.Text.Trim()))
                    {
                        temp = from DR in NUM_PAR_Data.AsEnumerable()
                               where DR.Field<Int64?>("REG_NO") != null && DR.Field<Int64>("REG_NO") == Convert.ToInt64(txtRegistryNo.Text.Trim())
                               && DR.Field<string>("PAR") != null && DR.Field<string>("PAR") == uchrtbPAR_NP.hrtbPara.Text.Trim()
                               && DR.Field<Int64>("TAN_NUM_ID") != articleNUMID
                               && DR.Field<string>("AMD") == null
                               select DR;
                    }
                    else
                    {
                        temp = from DR in NUM_PAR_Data.AsEnumerable()
                               where DR.Field<Int64?>("REG_NO") != null && DR.Field<Int64>("REG_NO") == Convert.ToInt64(txtRegistryNo.Text.Trim())
                               && DR.Field<string>("PAR") != null && DR.Field<string>("PAR") == uchrtbPAR_NP.hrtbPara.Text.Trim()
                               && DR.Field<Int64>("TAN_NUM_ID") != articleNUMID
                               && DR.Field<string>("AMD") != null
                               select DR;

                    }

                    if ((temp != null && temp.Count() > 0 && articleNUMID == 0) || (temp != null && temp.Count() >= 1 && articleNUMID != 0))
                    {
                        blStatus = true;
                        str = str + Environment.NewLine + "Only one empty/non-empty AMD is allowed if PAR & RegNo are same";
                    }

                }

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool ValidateRegistryNoCheckSUMValue(int nrnreg)
        {
            bool blStatus = false;
            try
            {
                if (nrnreg > 0)
                {
                    int checkSumDigit = 0;
                    string strNrnReg = nrnreg.ToString();
                    checkSumDigit = Convert.ToInt16(strNrnReg[strNrnReg.Length - 1].ToString());

                    char[] caNrnReg = strNrnReg.ToCharArray();
                    if (caNrnReg != null)
                    {
                        if (caNrnReg.Length > 0)
                        {
                            int intSum = 0;
                            int intTemp = caNrnReg.Length - 1;
                            for (int i = 0; i < caNrnReg.Length - 1; i++)
                            {
                                intSum = intSum + (Convert.ToInt32(caNrnReg[i].ToString()) * intTemp);
                                intTemp = intTemp - 1;
                            }
                            int intReminder = 0;
                            Math.DivRem(intSum, 10, out intReminder);

                            if (checkSumDigit == intReminder)
                            {
                                blStatus = true;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool ValidateNUM_CTHInformation(ref string errMsg)
        {
            bool blStatus = true;
            try
            {
                string strErr = "";
                if (string.IsNullOrEmpty(txtCTH.Text.Trim()))
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "CTH can't be null";
                }
                else if (CheckForDuplicateCTH(txtCTH.Text.Trim()))
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "Duplicate CTH";
                }

                ////HMD Validation
                //if (txtHMD_NC.Text.Trim().Length > 240)
                //{
                //    blStatus = false;
                //    errMsg = errMsg.Trim() + "\r\n" + "HMD length should be < 240 characters";
                //}

                //New validation on 20NOV2015
                //The total character count of HMD + TMD should not be more than 238, otherwise error message occurs.

                //New modification on 16DEC2015
                //Please include the following change in XML file from this point on: total character count of HMD + TMD should not be more than 210.

                if (!string.IsNullOrEmpty(uchrtbTMD_NC.hrtbPara.Text.Trim()))
                {
                    //Check HMD and NUM TMD combined length
                    if ((txtHMD_NC.Text.Trim().Length + uchrtbTMD_NC.hrtbPara.Text.Trim().Length) > 210)
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + Environment.NewLine + "HMD and CTH-TMD combined length should be <= 210 characters";
                    }
                }
                else
                {
                    //Check HMD and Article TMD combined length
                    if ((txtHMD_NC.Text.Trim().Length + uchrtbTMD.hrtbPara.Text.Trim().Length) > 210)
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + Environment.NewLine + "HMD and Article TMD combined length should be <= 210 characters";
                    }
                }

                //CTH TMD validation
                if (rbnCTHCrystalStruct.Checked || rbnCTHMolStruct.Checked)
                {
                    if (string.IsNullOrEmpty(uchrtbTMD_NC.hrtbPara.Text.Trim()))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "CTH TMD is mandatory when CTH type is Molecule/Crystal structure";
                    }
                    else if (!uchrtbTMD_NC.hrtbPara.Text.Trim().ToUpper().StartsWith("OF "))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "CTH TMD should start with 'of' when CTH type is Molecule/Crystal structure";
                    }

                    if (Common.Validations.ValidateUnicodeCharactersInString(uchrtbTMD_NC.hrtbPara.Text.Trim(), out strErr))//New validation on 10th Sep 2014
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "TMD contains invalid characters " + strErr.Trim();
                    }
                }

                //New validation on 17th Sep 2014
                if (chkIsTradeNamePolymer_NC.Checked)
                {
                    if (string.IsNullOrEmpty(txtHMD_NC.Text.Trim()))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "HMD is mandatory when Trade Name Polymer is checked";
                    }      
                }

                if (TAN_ID >= 55635) //from rxnfile.980071 shipment onwards Xml delivery
                {
                    //New code on 14Sep 2015
                    //Validate Source document Index term and Index Term Document ID
                    if (string.IsNullOrEmpty(uchrtbSrcDocIndxTerm_CTH.hrtbPara.Text.Trim()))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + Environment.NewLine + "Source document Index Term is mandatory";
                    }

                    if (cmbTANDocs_CTH.SelectedIndex < 0)
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + Environment.NewLine + "Index Term Source Doc.ID is mandatory";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckForDuplicateNUM_RegNo(int num, string numType)
        {
            bool blStatus = false;
            try
            {
                if (num > 0 && !string.IsNullOrEmpty(numType))
                {
                    if (NUM_PAR_Data != null)
                    {
                        if (NUM_PAR_Data.Rows.Count > 0)
                        {
                            if (numType.ToUpper() == "NUM")
                            {
                                var rows = NUM_PAR_Data.AsEnumerable().Where(r => r.Field<Int16>("NUM") == num);
                                if (rows != null)
                                {
                                    if (rows.Count() > 0)
                                    {
                                        if (num != editNUM_NP && editNUM_NP > 0)
                                        {
                                            blStatus = true;
                                        }
                                        else if (editNUM_NP == 0)
                                        {
                                            blStatus = true;
                                        }
                                    }
                                }
                            }
                            else if (numType.ToUpper() == "REGISTRYNO")
                            {
                                #region Old code commented
                                //var rows = NUM_PAR_Data.AsEnumerable().Where(r => r.Field<Int32?>("nrnreg") == num);
                                //if (rows != null)
                                //{
                                //    //if (rows.Count() > 0 && editNUM_NP == 0)
                                //    //{
                                //    //    blStatus = true;
                                //    //}  
                                #endregion                               

                                for (int i = 0; i < NUM_PAR_Data.Rows.Count;i++ )
                                {
                                    if (NUM_PAR_Data.Rows[i]["REG_NO"] != null)
                                    {
                                        if (!string.IsNullOrEmpty(NUM_PAR_Data.Rows[i]["REG_NO"].ToString()))
                                        {
                                            if (Convert.ToInt32(NUM_PAR_Data.Rows[i]["REG_NO"]) == num)
                                            {
                                                if (editNUM_NP == 0)//new record
                                                {
                                                    blStatus = true;
                                                }
                                                else if (Convert.ToInt32(NUM_PAR_Data.Rows[i]["NUM"]) != nudNUMPAR.Value)
                                                {
                                                    blStatus = true;
                                                }                                                
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckForDuplicateCTH(string cth)
        {
            bool blStatus = false;
            try
            {
                if (!string.IsNullOrEmpty(cth) && NUM_CTH_Data != null)
                {
                    if (NUM_CTH_Data.Rows.Count > 0)
                    {
                        if (articleNUMID == 0)//New PAR
                        {
                            var rows = NUM_CTH_Data.AsEnumerable().Where(r => r.Field<string>("CTH") == cth);
                            if (rows != null)
                            {
                                if (rows.Count() > 0)
                                {
                                    blStatus = true;
                                }
                            }
                        }
                        else//Edited Record
                        {
                            EnumerableRowCollection<DataRow> rows = from row in NUM_CTH_Data.AsEnumerable()
                                                                    where row.Field<string>("CTH") == cth && row.Field<Int64>("TAN_NUM_ID") != articleNUMID
                                                                    select row;
                            if (rows != null)
                            {
                                if (rows.Count() > 0)
                                {
                                    blStatus = true;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckForDuplicatePAR(string parHtml, string amd)
        {
            bool blStatus = false;
            try
            {
                if (!string.IsNullOrEmpty(parHtml) && NUM_PAR_Data != null)
                {
                    if (NUM_PAR_Data.Rows.Count > 0)
                    {
                        if (articleNUMID == 0)//New PAR
                        {
                            var rows = NUM_PAR_Data.AsEnumerable().Where(r => r.Field<string>("PAR") == parHtml && r.Field<string>("AMD") == amd);
                            if (rows != null)
                            {
                                if (rows.Count() > 0)
                                {
                                    blStatus = true;
                                }
                            }
                        }
                        else//Edited Record
                        {
                            EnumerableRowCollection<DataRow> rows = from row in NUM_PAR_Data.AsEnumerable()
                                                                    where row.Field<string>("PAR") == parHtml && row.Field<string>("AMD") == amd && row.Field<Int64>("TAN_NUM_ID") != articleNUMID
                                                                    select row;
                            if (rows != null)
                            {
                                if (rows.Count() > 0)
                                {
                                    blStatus = true;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckForDuplicateNUM(int tanNum)
        {
            bool blStatus = false;
            try
            {
                if (tanNum > 0 && NUM_PAR_Data != null)
                {
                    if (NUM_PAR_Data.Rows.Count > 0)
                    {
                        if (articleNUMID == 0)//New NUM
                        {
                            var rows = NUM_PAR_Data.AsEnumerable().Where(r => r.Field<Int16>("NUM") == tanNum);
                            if (rows != null)
                            {
                                if (rows.Count() > 0)
                                {
                                    blStatus = true;
                                }
                            }
                        }
                        else//Edited Record
                        {
                            EnumerableRowCollection<DataRow> rows = from row in NUM_PAR_Data.AsEnumerable()
                                                                    where row.Field<Int16>("NUM") == tanNum && row.Field<Int64>("TAN_NUM_ID") != articleNUMID
                                                                    select row;
                            if (rows != null)
                            {
                                if (rows.Count() > 0)
                                {
                                    blStatus = true;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckForDuplicateRegNo(int regNo)
        {
            bool blStatus = false;
            try
            {
                if (regNo > 0 && NUM_PAR_Data != null)
                {
                    if (NUM_PAR_Data.Rows.Count > 0)
                    {
                        if (articleNUMID == 0)//New NUM
                        {
                            var rows = NUM_PAR_Data.AsEnumerable().Where(r => r.Field<Int64?>("REG_NO") == regNo);
                            if (rows != null)
                            {
                                if (rows.Count() > 0)
                                {
                                    blStatus = true;
                                }
                            }
                        }
                        else//Edited Record
                        {
                            EnumerableRowCollection<DataRow> rows = from row in NUM_PAR_Data.AsEnumerable()
                                                                    where row.Field<Int64?>("REG_NO") == regNo && row.Field<Int64>("TAN_NUM_ID") != articleNUMID
                                                                    select row;
                            if (rows != null)
                            {
                                if (rows.Count() > 0)
                                {
                                    blStatus = true;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckForDuplicateNUM_CTH(int num)
        {
            bool blStatus = false;
            try
            {
                if (num > 0)
                {
                    if (NUM_CTH_Data != null)
                    {
                        if (NUM_CTH_Data.Rows.Count > 0)
                        {
                            var rows = NUM_CTH_Data.AsEnumerable().Where(r => r.Field<int>("NUM") == num);
                            if (rows != null)
                            {
                                if (rows.Count() > 0)
                                {
                                    if (num != editNUM_NC && editNUM_NC > 0)
                                    {
                                        blStatus = true;
                                    }
                                    else if (editNUM_NC == 0)
                                    {
                                        blStatus = true;
                                    }
                                    //else if (editRowIndx_NC == 0)
                                    //{
                                    //    blStatus = true;
                                    //}
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool ValidateReviewTANKeywords(ref string errMsg)
        {
            bool blStatus = true;
            try
            {
                if (TANKeyWords != null)
                {
                    if (TANKeyWords.Rows.Count > 0)
                    {
                        for (int i = 0; i < TANKeyWords.Rows.Count; i++)
                        {
                            if (i == 0 && !TANKeyWords.Rows[i]["KEYWORD"].ToString().ToUpper().StartsWith("REVIEW"))
                            {
                                blStatus = false;
                                errMsg = errMsg.Trim() + "\r\n" + "For a review TAN, first Key should start with 'review' word";
                            }
                            else if (!TANKeyWords.Rows[i]["KEYWORD"].ToString().ToUpper().Contains("REVIEW"))
                            {
                                blStatus = false;
                                errMsg = errMsg.Trim() + "\r\n" + "For a review TAN, each Key should contain 'review' word";
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool ValidateNUMsSequence(out string errMsg)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                //Check missing NUMS
                if (dgvNUM_PAR.Rows.Count > 0)
                {
                    DataTable dtPARs = (DataTable)dgvNUM_PAR.DataSource;
                    if (dtPARs != null)
                    {
                        if (dtPARs.Rows.Count > 0)
                        {
                            if (Convert.ToInt32(dtPARs.Rows[dtPARs.Rows.Count - 1]["NUM"].ToString()) != dtPARs.Rows.Count)
                            {
                                blStatus = false;
                                strErrMsg = "Some NUM-PARs are missing";
                            }
                        }
                    }
                }

                ////Check missing NUMS
                //if (dgvNUM_CTH.Rows.Count > 0)
                //{
                //    DataTable dtCTHs = (DataTable)dgvNUM_CTH.DataSource;
                //    if (dtCTHs != null)
                //    {
                //        if (dtCTHs.Rows.Count > 0)
                //        {
                //            if (Convert.ToInt32(dtCTHs.Rows[dtCTHs.Rows.Count - 1]["nrnnum"].ToString()) != (800 + dtCTHs.Rows.Count))
                //            {
                //                blStatus = false;
                //                strErrMsg = strErrMsg.Trim() + "\r\n" + "Some NUM-CTHs are missing";
                //            }
                //        }
                //    }
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsg = strErrMsg;
            return blStatus;
        }

        public HtmlRichTextBox GetActiveControlFromForm()
        {
            HtmlRichTextBox hrtbActive = null;
            try
            {
                //Title
                if (uchrtbTitle.hrtbPara.Focused)
                {
                    hrtbActive = uchrtbTitle.hrtbPara;
                    return hrtbActive;
                }

                //TMD
                if (uchrtbTMD.hrtbPara.Focused)
                {
                    hrtbActive = uchrtbTMD.hrtbPara;
                    return hrtbActive;
                }

                //Abstract
                if (uchrtbAbstract.hrtbPara.Focused)
                {
                    hrtbActive = uchrtbAbstract.hrtbPara;
                    return hrtbActive;
                }

                //NP PAR
                if (uchrtbPAR_NP.hrtbPara.Focused)
                {
                    hrtbActive = uchrtbPAR_NP.hrtbPara;
                    return hrtbActive;
                }

                //NP TMD
                if (uchrtbTMD_NP.hrtbPara.Focused)
                {
                    hrtbActive = uchrtbTMD_NP.hrtbPara;
                    return hrtbActive;
                }

                //NC TMD
                if (uchrtbTMD_NC.hrtbPara.Focused)
                {
                    hrtbActive = uchrtbTMD_NC.hrtbPara;
                    return hrtbActive;
                }

                //Src Doc Index Term - PAR
                if (uchrtbSrcDocIndxTerm_PAR.hrtbPara.Focused)
                {
                    hrtbActive = uchrtbSrcDocIndxTerm_PAR.hrtbPara;
                    return hrtbActive;
                }

                //Src Doc Index Term - CTH
                if (uchrtbSrcDocIndxTerm_CTH.hrtbPara.Focused)
                {
                    hrtbActive = uchrtbSrcDocIndxTerm_CTH.hrtbPara;
                    return hrtbActive;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return hrtbActive;
        }

        #region Key validation methods

        private bool ValidateKey(string _key, out string _errmsg_out)
        {
            bool blStatus = true;
            string strErrMsg = "";

            try
            {
                if (!string.IsNullOrEmpty(_key.Trim()))
                {
                    ////Check Key has Spaces
                    //var regex = new Regex(@"\s");
                    //if (regex.IsMatch(_key.Trim()))
                    //{
                    //    strErrMsg = strErrMsg.Trim() + "\r\n" + "Key contains spaces";
                    //    blStatus = false;
                    //}

                    //Check for duplicate Key in the database
                    if (CheckForDuplicateKeyInKeysData(_key))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Duplicate Key";
                        blStatus = false;
                    }

                    //Key max length is 150 including 'KEY:: review '.So, only 144 characters are allowed
                    if (_key.Trim().Length > 144) //150 - 6 ('KEY:: ' length is 6)
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Only 144 characters allowed in a Key";
                        blStatus = false;
                    }
                    else if(_key.Trim().Split().Length > 9)
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Max of 9 words allowed in a Key";
                        blStatus = false;
                    }

                    //Check Key starts with Number                    
                    string str = _key.Substring(0, 1);
                    int intNum = 0;
                    if (int.TryParse(str, out intNum))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + "Key should not start with Number";
                        blStatus = false;
                    }

                    //Check Special Characters in Key
                    string errMsg = "";
                    if (CheckSpecialCharactersInKey(_key.Trim(), out errMsg))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + errMsg;
                        blStatus = false;
                    }

                    //Check Invalid terms in Key
                    if (CheckInvalidTermsInKey(_key.Trim(), out errMsg))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + errMsg;
                        blStatus = false;
                    }

                    //Check Invalid terms in Key
                    if (CheckGreekLettersInKey(_key.Trim(), out errMsg))
                    {
                        strErrMsg = strErrMsg.Trim() + "\r\n" + errMsg;
                        blStatus = false;
                    }
                }
                else
                {
                    strErrMsg = strErrMsg.Trim() + "\r\n" + "Key can't be null";
                    blStatus = false;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg_out = strErrMsg.Trim();
            return blStatus;
        }

        private bool CheckForDuplicateKeyInKeysData(string _key)
        {
            bool blStatus = false;
            try
            {
                if (!string.IsNullOrEmpty(_key) && TANKeyWords != null)
                {                   
                    //blStatus = TANKeyWords.AsEnumerable().Where(c => c.Field<string>("KEYWORD").ToUpper().Equals(_key.ToUpper())).Count() > 0;

                    if (editKeyRowIndx == 0)//New KEY
                    {
                        blStatus = TANKeyWords.AsEnumerable().Where(c => c.Field<string>("KEYWORD").ToUpper().Equals(_key.ToUpper())).Count() > 0;
                    }
                    else//Edited Record
                    {
                        for (int i = 0; i < TANKeyWords.Rows.Count; i++)
                        {
                            if (TANKeyWords.Rows[i]["KEYWORD"].ToString().ToUpper() == _key.ToUpper() && editKeyRowIndx != (i+1))
                            {
                                blStatus = true;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckInvalidTermsInKey(string _key, out string _errMsgOut)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                var invalidTerms = new[] { "MOUSE", "RAT ", "GUINEA PIG" };//"HUMAN"
                foreach (var invalidTerm in invalidTerms.Where(_key.ToUpper().Contains))
                {
                    strErrMsg = strErrMsg.Trim() + "\r\n" + string.Format("Key must not contain {0}", invalidTerm);
                    blStatus = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errMsgOut = strErrMsg;
            return blStatus;
        }

        private bool CheckSpecialCharactersInKey(string _key, out string _errMsgOut)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                var specialChars = new[] { '.', '\\', '/', ':', '*', '<', '>', '|', '#', '{', '}', '%', '~', '&', '-', '_', ',', '(', ')', '`', '+', '=' };
                foreach (var specialChar in specialChars.Where(_key.Contains))
                {
                    strErrMsg = strErrMsg.Trim() + "\r\n" + string.Format("Key should not contain '{0}'", specialChar);
                    blStatus = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errMsgOut = strErrMsg;
            return blStatus;
        }

        private bool CheckGreekLettersInKey(string _key, out string _errMsgOut)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                Regex objNotWholePattern = new Regex(@"[\p{IsGreekandCoptic}]");
                if (objNotWholePattern.IsMatch(_key))
                {
                    strErrMsg = "Key must not contain greek letters. Use english representation for greek letters i.e., alpha, beta etc.";
                    blStatus = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errMsgOut = strErrMsg;
            return blStatus;
        }
               
        #endregion

        #endregion

        #region Table definition methods

        private DataTable GetArticleNUMsTableDefinition()
        {
            DataTable dtNUMs = null;
            try
            {
                dtNUMs = new DataTable();
                dtNUMs.Columns.Add("article_num_id");
                dtNUMs.Columns.Add("patent_id");
                dtNUMs.Columns.Add("nrnnum", typeof(Int32));
                dtNUMs.Columns.Add("nrnreg");
                dtNUMs.Columns.Add("par", typeof(string));
                dtNUMs.Columns.Add("hmd", typeof(string));
                dtNUMs.Columns.Add("amd", typeof(string));
                dtNUMs.Columns.Add("num_role", typeof(string));
                dtNUMs.Columns.Add("dpt_rs");
                dtNUMs.Columns.Add("cth", typeof(string));
                dtNUMs.Columns.Add("num_type", typeof(string));
                dtNUMs.Columns.Add("struct_molfile", typeof(object));
                dtNUMs.Columns.Add("struct_image", typeof(Image));                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtNUMs;
        }

        private DataTable GetKeywordsTableDefinition()
        {
            DataTable dtKeywords = new DataTable();

            DataColumn colKey = new DataColumn("TK_ID");
            colKey.DataType = System.Type.GetType("System.Int32");
            colKey.AutoIncrement = true;
            colKey.AutoIncrementSeed = 1;

            dtKeywords.Columns.Add(colKey);
            dtKeywords.Columns.Add("KEYWORD");
            dtKeywords.Columns.Add("KEY_LENGTH");
            dtKeywords.Columns.Add("KEY_WORD_CNT");
            return dtKeywords;
        }

        private DataTable GetKeysPreviewTableDefinition()
        {
            DataTable dtKeysPrev = new DataTable();
            dtKeysPrev.Columns.Add("KEY");
            dtKeysPrev.Columns.Add("KEY_LENGTH");
            dtKeysPrev.Columns.Add("WORD_COUNT");
            return dtKeysPrev;
        }

        #endregion

        #region Keys related methods

        private DataTable GetKeyPreviewDataFromTable(DataTable keysdata)
        {
            DataTable dtKeysPrev = null;
            try
            {
                //Each KEY limit is 150 characters including 'KEY:: ', so only 144 characters are allowed
                //KEY:: review schizophrenia pathology acetylcholine receptor acetylcholinesterase
                if (keysdata != null)
                {
                    if (keysdata.Rows.Count > 0)
                    {
                        List<string> lstPreviewKeys = GetKeyPreviewListFromTable(keysdata);
                        if (lstPreviewKeys != null)
                        {
                            if (lstPreviewKeys.Count > 0)
                            {
                                dtKeysPrev = GetKeysPreviewTableDefinition();

                                for (int i = 0; i < lstPreviewKeys.Count; i++)
                                {
                                    DataRow dtRow = dtKeysPrev.NewRow();
                                    dtRow["KEY"] = lstPreviewKeys[i];
                                    dtRow["KEY_LENGTH"] = lstPreviewKeys[i].Length.ToString();
                                    dtRow["WORD_COUNT"] = (lstPreviewKeys[i].Split().Length - 1).ToString();
                                    dtKeysPrev.Rows.Add(dtRow);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtKeysPrev;
        }

        private List<string> GetKeyPreviewListFromTable(DataTable _keysdata)
        {
            List<string> lstKeysPreview = null;
            try
            {
                //Each KEY limit is 150 characters including 'KEY:: ', so only 144 characters are allowed
                //KEY:: review schizophrenia pathology acetylcholine receptor acetylcholinesterase
                if (_keysdata != null)
                {
                    if (_keysdata.Rows.Count > 0)
                    {
                        lstKeysPreview = new List<string>();

                        string strPreviewKey = "";
                        string strTempKey = "";
                        string strKeyword = "";

                        //Each KEY limit is 150 characters including 'KEY:: ', so only 144 characters are allowed
                        //If Review TAN 150 - 13 ('KEY:: review ' lenght is 13) 
                        //int keyMaxLength = _isReviewTAN == true ? 137 : 144;
                        int keyMaxLength = 150;// _isReviewTAN == true ? 137 : 144;

                        for (int i = 0; i < _keysdata.Rows.Count; i++)
                        {
                            if (_keysdata.Rows[i]["KEYWORD"] != null)
                            {
                                strKeyword = !string.IsNullOrEmpty(_keysdata.Rows[i]["KEYWORD"].ToString()) ? _keysdata.Rows[i]["KEYWORD"].ToString().Trim() : "";

                                if (!string.IsNullOrEmpty(strKeyword))
                                {                                    
                                    strTempKey = string.IsNullOrEmpty(strTempKey) ? "KEY:: " + strKeyword : strTempKey + " " + strKeyword;                                   

                                    if ((strTempKey.Length <= keyMaxLength) && (strTempKey.Split().Length <= 10))
                                    {
                                        if (strPreviewKey.Length <= keyMaxLength)
                                        {
                                            strPreviewKey = strTempKey;
                                        }
                                        else
                                        {
                                            lstKeysPreview.Add(strPreviewKey);

                                            strPreviewKey = strTempKey;
                                        }
                                    }
                                    else
                                    {
                                        if (strPreviewKey.Length <= keyMaxLength)
                                        {
                                            lstKeysPreview.Add(strPreviewKey);
                                        }                                       

                                        //Reset Key to New value                                       
                                        strTempKey = "KEY:: " + _keysdata.Rows[i]["KEYWORD"].ToString();                                        

                                        //new code on 27th Aug 2013
                                        strPreviewKey = strTempKey;
                                    }
                                }
                            }
                        }
                        if (!string.IsNullOrEmpty(strTempKey))
                        {
                            if (strTempKey.Length <= keyMaxLength)
                            {
                                lstKeysPreview.Add(strTempKey);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstKeysPreview;
        }

        private string GetKeywordsStringFromGrid()
        {
            string strKeyword = "";
            try
            {
                if (TANKeyWords != null)
                {
                    if (TANKeyWords.Rows.Count > 0)
                    {
                        string[] array = TANKeyWords
                                         .AsEnumerable()
                                         .Select(row => row.Field<string>("KEYWORD"))
                                         .ToArray();
                        if (array != null)
                        {
                            strKeyword = string.Join("``", array);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strKeyword;
        }

        #endregion
                      
        #region Methods for Bind data to Controls/Grids

        private DataTable GetKeysTableFromString(string keywords)
        {
            DataTable dtKeys = null;
            try
            {
                if (!string.IsNullOrEmpty(keywords.Trim()))
                {
                    string[] saKeys = keywords.Trim().Split(new string[] { "``" }, StringSplitOptions.RemoveEmptyEntries);
                    if (saKeys != null)
                    {
                        if (saKeys.Length > 0)
                        {
                            dtKeys = GetKeywordsTableDefinition();

                            foreach (string key in saKeys)
                            {
                                DataRow dtRow = dtKeys.NewRow();
                                dtRow["KEYWORD"] = key.Trim();
                                dtRow["KEY_LENGTH"] = key.Trim().Length.ToString();
                                dtRow["KEY_WORD_CNT"] = key.Trim().Split().Length.ToString();;
                                dtKeys.Rows.Add(dtRow);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtKeys;
        }

        private void BindArticleInfoToControls(DataTable tanData, DataTable tanComments)
        {
            try
            {
                if (tanData != null && tanData.Rows.Count > 0)
                {
                    txtTAN.Text = tanData.Rows[0]["TAN_NAME"].ToString();
                    TAN_Name = tanData.Rows[0]["TAN_NAME"].ToString();

                    txtSection.Text = tanData.Rows[0]["TAN_SECTION"].ToString();
                    if (!string.IsNullOrEmpty(tanData.Rows[0]["SUB_SECTION"].ToString()))
                    {
                        txtSubSection.Text = Convert.ToInt32(tanData.Rows[0]["SUB_SECTION"].ToString()).ToString("00");
                    }
                    txtCrossRefSections.Text = tanData.Rows[0]["CROSS_REFERENCE"].ToString();

                    uchrtbTMD.BindDataToControl(tanData.Rows[0]["TMD"].ToString());
                    uchrtbAbstract.BindDataToControl(tanData.Rows[0]["ABSTRACT"].ToString());
                    uchrtbTitle.BindDataToControl(tanData.Rows[0]["TITLE"].ToString());

                    txtComments.Text = GetMacroIndexingCommentsFromTable(tanComments);

                    chkSPA_HDR.Checked = tanData.Rows[0]["SPA_HDR"].ToString() == "Y" ? true : false;
                    chkReviewTAN.Checked = tanData.Rows[0]["REVIEW_TAN"].ToString() == "Y" ? true : false;
                    chkQueryTAN.Checked = tanData.Rows[0]["QUERY_TAN"].ToString() == "Y" ? true : false;

                    //Get Keys from string and bind to grid
                    TANKeyWords = GetKeysTableFromString(tanData.Rows[0]["KEYWORDS"].ToString());
                    BindTAN_KeysToGrid(TANKeyWords);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetMacroIndexingCommentsFromTable(DataTable tanComments)
        {
            string indxComments = "";
            try
            {
                if (tanComments != null)
                {
                    var rows = from r in tanComments.AsEnumerable()
                               where r.Field<string>("COMMENT_TYPE") == "MACRO_INDEXING"
                               select new
                               {
                                   idxComments = r.Field<string>("TAN_COMMENT")
                               };
                    if (rows != null)
                    {
                        foreach (var r in rows)
                        {
                            indxComments = r.idxComments;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return indxComments;
        }

        private void BindDataToNUM_PARGrid(DataTable numsData)
        {
            try
            {
                if (numsData != null)
                {
                    dgvNUM_PAR.AutoGenerateColumns = false;
                    dgvNUM_PAR.DataSource = numsData;

                    colArticleNUMID_NP.DataPropertyName = "TAN_NUM_ID";
                    colNUM_NP.DataPropertyName = "NUM";
                    colRegNo.DataPropertyName = "REG_NO";
                    colPAR.DataPropertyName = "PAR";
                    colRole_NP.DataPropertyName = "NUM_ROLE";
                    colStructureImage.DataPropertyName = "MOL_IMAGE";
                    colStructure.DataPropertyName = "MOL_FILE";
                    colPolymerStructure.DataPropertyName = "IS_POLYMER";
                    colHMD_NP.DataPropertyName = "HMD";
                    colTMD_Num.DataPropertyName = "NUM_TMD";
                    colNoStructure.DataPropertyName = "NO_STRUCT";
                    colNote.DataPropertyName = "NUM_NOTE";
                    colAMD.DataPropertyName = "AMD";
                    colDPT.DataPropertyName = "DPT_RS";
                    colTradeNamePolymer_NP.DataPropertyName = "IS_TRADE_NAME_POLYMER";
                    colIsCrossReferred.DataPropertyName = "IS_CROSS_REF";
                    colCrossRefTo_NP.DataPropertyName = "CROSS_REF_POLYMER";

                    colSrcDocIndexTerm_NP.DataPropertyName = "SOURCE_DOC_INDEX_TERM";
                    colIndxTermSrcDocName_NP.DataPropertyName = "FILE_NAME";                   
                    colIndxTermSrcDocID_NP.DataPropertyName = "TAN_DOC_ID";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindDataToNUM_CTHGrid(DataTable cthData)
        {
            try
            {
                if (cthData != null)
                {
                    txtNUMCTH.Text = cthData.Rows.Count == 0 ? "801" : (801 + cthData.Rows.Count).ToString();

                    dgvNUM_CTH.AutoGenerateColumns = false;
                    dgvNUM_CTH.DataSource = cthData;

                    colArticleNUMID_NC.DataPropertyName = "TAN_NUM_ID";
                    colNUM_NC.DataPropertyName = "NUM";            
                    colRole_NC.DataPropertyName = "NUM_ROLE";                   
                    colHMD_NC.DataPropertyName = "HMD";
                    colCTHClass.DataPropertyName = "CTH_CLASS";
                    colCTH.DataPropertyName = "CTH";
                    colCTHType.DataPropertyName = "CTH_TYPE";
                    colTMD_CTH.DataPropertyName = "NUM_TMD";

                    colRequireFileReview.DataPropertyName = "IS_REQ_FILE_REVIEW";
                    colTradeNamePolymer_NC.DataPropertyName = "IS_TRADE_NAME_POLYMER";
                    colCrossRefTo_NC.DataPropertyName = "CROSS_REF_POLYMER";

                    colSrcDocIndexTerm_NC.DataPropertyName = "SOURCE_DOC_INDEX_TERM";
                    colIndxTermSrcDocID_NC.DataPropertyName = "TAN_DOC_ID";
                    colIndxTermSrcDocName_NC.DataPropertyName = "FILE_NAME";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindTAN_KeysToGrid(DataTable _keysData)
        {
            try
            {
                if (_keysData != null)
                {
                    dgvKeywords.AutoGenerateColumns = false;
                    dgvKeywords.DataSource = _keysData;

                    colTKID.DataPropertyName = "TK_ID";
                    colKeyWord.DataPropertyName = "KEYWORD";
                    colKeywordLen.DataPropertyName = "KEY_LENGTH";
                    colKeyWordsCnt.DataPropertyName = "KEY_WORD_CNT";
                    
                    ////Hilight Capitalized words
                    //HilightCapitalizedWordinGrid("KEY", "colKey");                    
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
         
        int editNUM_NP = 0;
        int editNUM_NC = 0;
        private void BindGridRowDataToControls(DataGridViewRow gridRow, string rowType)
        {
            try
            {
                if (gridRow != null)
                {
                    if (gridRow.Cells.Count > 0)
                    {                        
                        if (rowType.ToUpper() == "NUM_PAR")
                        {
                            ResetNUMControls("NUM_PAR");

                            articleNUMID = gridRow.Cells[colArticleNUMID_NP.Name].Value != null ? Convert.ToInt32(gridRow.Cells[colArticleNUMID_NP.Name].Value) : 0;
                            nudNUMPAR.Value = gridRow.Cells[colNUM_NP.Name].Value != null ? Convert.ToInt32(gridRow.Cells[colNUM_NP.Name].Value) : 1;
                            editNUM_NP = (int)nudNUMPAR.Value;

                            txtRegistryNo.Text = gridRow.Cells[colRegNo.Name].Value != null ? gridRow.Cells[colRegNo.Name].Value.ToString() : "";
                            if (gridRow.Cells[colPAR.Name].Value != null)
                            {
                                uchrtbPAR_NP.BindDataToControl(gridRow.Cells[colPAR.Name].Value.ToString());

                                //hrtbPAR_NP.Rtf = htmlRtfConvs.GetRTFfromHTMLString(gridRow.Cells["colPAR"].Value.ToString());
                            }
                            txtHMD_NP.Text = gridRow.Cells[colHMD_NP.Name].Value != null ? gridRow.Cells[colHMD_NP.Name].Value.ToString() : "";
                            txtAMD.Text = gridRow.Cells[colAMD.Name].Value != null ? gridRow.Cells[colAMD.Name].Value.ToString() : "";

                            if (gridRow.Cells[colTMD_Num.Name].Value != null)
                            {
                                uchrtbTMD_NP.BindDataToControl(gridRow.Cells[colTMD_Num.Name].Value.ToString());                       
                            }

                            txtRoleNP.Text = gridRow.Cells[colRole_NP.Name].Value != null ? gridRow.Cells[colRole_NP.Name].Value.ToString() : "";
                            txtNUMNote.Text = gridRow.Cells[colNote.Name].Value != null ? gridRow.Cells[colNote.Name].Value.ToString() : "";
                            
                            if (gridRow.Cells[colDPT.Name].Value != null)
                            {
                                chkDPT_RS.Checked = gridRow.Cells[colDPT.Name].Value.ToString() == "Y" ? true : false;
                            }

                            if (gridRow.Cells[colSrcDocIndexTerm_NP.Name].Value != null)
                            {
                                uchrtbSrcDocIndxTerm_PAR.BindDataToControl(gridRow.Cells[colSrcDocIndexTerm_NP.Name].Value.ToString());
                            }

                            if (gridRow.Cells[colIndxTermSrcDocID_NP.Name].Value != null)
                            {
                                cmbTANDocs_PAR.SelectedValue = gridRow.Cells[colIndxTermSrcDocID_NP.Name].Value;
                            }

                            if (gridRow.Cells[colNoStructure.Name].Value != null)
                            {
                                chkNoStructure.Checked = gridRow.Cells[colNoStructure.Name].Value.ToString() == "Y" ? true : false;
                            }

                            if (gridRow.Cells[colPolymerStructure.Name].Value != null)
                            {
                                chkIsPolymer.Checked = gridRow.Cells[colPolymerStructure.Name].Value.ToString() == "Y" ? true : false;
                            }

                            if (gridRow.Cells[colTradeNamePolymer_NP.Name].Value != null)
                            {
                                chkIsTradeNamePolymer_NP.Checked = gridRow.Cells[colTradeNamePolymer_NP.Name].Value.ToString() == "Y" ? true : false;
                            }

                            if (gridRow.Cells[colIsCrossReferred.Name].Value != null) 
                            {
                                chkIsCrossRefTo.Checked = gridRow.Cells[colIsCrossReferred.Name].Value.ToString() == "Y" ? true : false;
                            }

                            txtCrossRefPolymer_NP.Text = gridRow.Cells[colCrossRefTo_NP.Name].Value != null ? gridRow.Cells[colCrossRefTo_NP.Name].Value.ToString() : "";

                            ChemRenditor.MolfileString = gridRow.Cells[colStructure.Name].Value != null ? gridRow.Cells[colStructure.Name].Value.ToString() : "";
                            if (gridRow.Cells[colStructureImage.Name].Value != null)
                            {
                                if (!string.IsNullOrEmpty(gridRow.Cells[colStructureImage.Name].Value.ToString()))
                                {
                                    pbStructureImage.Image = DataConversions.ByteArrayToImage((byte[])(gridRow.Cells[colStructureImage.Name].Value));
                                }
                            }
                        }
                        else if (rowType.ToUpper() == "NUM_CTH")
                        {
                            ResetNUMControls("NUM_CTH");

                            articleNUMID = gridRow.Cells[colArticleNUMID_NC.Name].Value != null ? Convert.ToInt32(gridRow.Cells[colArticleNUMID_NC.Name].Value) : 0;
                            txtNUMCTH.Text = gridRow.Cells[colNUM_NC.Name].Value != null ? gridRow.Cells[colNUM_NC.Name].Value.ToString() : "1";
                            editNUM_NC = Convert.ToInt32(txtNUMCTH.Text);

                            txtHMD_NC.Text = gridRow.Cells[colHMD_NC.Name].Value != null ? gridRow.Cells[colHMD_NC.Name].Value.ToString() : "";
                            txtCTH.Text = gridRow.Cells[colCTH.Name].Value != null ? gridRow.Cells[colCTH.Name].Value.ToString() : "";
                            txtRoleNC.Text = gridRow.Cells[colRole_NC.Name].Value != null ? gridRow.Cells[colRole_NC.Name].Value.ToString() : "";

                            if (gridRow.Cells[colRequireFileReview.Name].Value != null) 
                            {
                                chkRequireFileReview.Checked = gridRow.Cells[colRequireFileReview.Name].Value.ToString() == "Y" ? true : false;
                            }

                            if (gridRow.Cells[colTradeNamePolymer_NC.Name].Value != null)
                            {
                                chkIsTradeNamePolymer_NC.Checked = gridRow.Cells[colTradeNamePolymer_NC.Name].Value.ToString() == "Y" ? true : false;
                            }

                            if (gridRow.Cells[colSrcDocIndexTerm_NC.Name].Value != null)
                            {
                                uchrtbSrcDocIndxTerm_CTH.BindDataToControl(gridRow.Cells[colSrcDocIndexTerm_NC.Name].Value.ToString());
                            }

                            if (gridRow.Cells[colIndxTermSrcDocID_NC.Name].Value != null)
                            {
                                cmbTANDocs_CTH.SelectedValue = gridRow.Cells[colIndxTermSrcDocID_NC.Name].Value;
                            }

                            txtCrossRefPolymer_NC.Text = gridRow.Cells[colCrossRefTo_NC.Name].Value != null ? gridRow.Cells[colCrossRefTo_NC.Name].Value.ToString() : "";

                            if (gridRow.Cells[colCTHType.Name].Value != null)
                            {
                                if (gridRow.Cells[colCTHType.Name].Value.ToString().ToUpper() == "GENERAL")
                                {
                                    rbnCTHGeneral.Checked = true;
                                }
                                else if (gridRow.Cells[colCTHType.Name].Value.ToString().ToUpper() == "MOL_STRUCTURE")
                                {
                                    rbnCTHMolStruct.Checked = true;
                                }
                                else if (gridRow.Cells[colCTHType.Name].Value.ToString().ToUpper() == "CRYSTAL_STRUCTURE")
                                {
                                    rbnCTHCrystalStruct.Checked = true;
                                }
                                
                                if (gridRow.Cells[colTMD_CTH.Name].Value != null)
                                {
                                    if (!string.IsNullOrEmpty(gridRow.Cells[colTMD_CTH.Name].Value.ToString()))
                                    {
                                        uchrtbTMD_NC.hrtbPara.Enabled = true;
                                        uchrtbTMD_NC.BindDataToControl(gridRow.Cells[colTMD_CTH.Name].Value.ToString());
                                    }                                 
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        

        #endregion        
                    
        #region Button Click Events

        private void btnSaveArticleInfo_Click(object sender, EventArgs e)
        {
            try
            {
                string strErrMsg = "";
                if (ValidateArticleInformation(ref strErrMsg))
                {
                    IndexingTANInfo objArticleInfo = new IndexingTANInfo();
                    objArticleInfo.TAN_ID = TAN_ID;
                    objArticleInfo.TAN_Name = txtTAN.Text.Trim();
                    objArticleInfo.Section = Convert.ToInt32(txtSection.Text.Trim());
                    if (!string.IsNullOrEmpty(txtSubSection.Text.Trim()))
                    {
                        objArticleInfo.SubSection = Convert.ToInt32(txtSubSection.Text.Trim());
                    }


                    Html_RtfConversions.Instance.SplCharReplTbl = SplCharRepData;
                    string strTitle_Html = uchrtbTitle.GetHtmlStringFromControl();//Validations.RemoveInVisibleCharsDblSpaces(hrtbTitle.Text.Trim());

                    //string strTitle_Html = GetHTMLFromRTFString(hrtbTitle.Rtf);
                    objArticleInfo.CrossReference = Validations.RemoveInVisibleCharsDblSpaces(txtCrossRefSections.Text.Trim());
                    objArticleInfo.Title = uchrtbTitle.GetHtmlStringFromControl();// Validations.RemoveInVisibleCharsDblSpaces(hrtbTitle.Text.Trim());
                    objArticleInfo.Abstract = uchrtbAbstract.GetHtmlStringFromControl();// Validations.RemoveInVisibleCharsDblSpaces(hrtbAbstract.Text.Trim());
                    objArticleInfo.TMD = uchrtbTMD.GetHtmlStringFromControl(); //Validations.RemoveInVisibleCharsDblSpaces(hrtbTMD.Text.Trim());
                    objArticleInfo.Comments = Validations.RemoveInVisibleCharsDblSpaces(txtComments.Text.Trim());
                    objArticleInfo.CommentsType = "MACRO_INDEXING";
                    objArticleInfo.SpaHdr = chkSPA_HDR.Checked ? "Y" : "N";
                    objArticleInfo.ReviewTAN = chkReviewTAN.Checked ? "Y" : "N";
                    objArticleInfo.QueryTAN = chkQueryTAN.Checked ? "Y" : "N";
                    objArticleInfo.IncludeInREP = chkIncludeInREP.Checked ? "Y" : "N";
                    objArticleInfo.Keywords = GetKeywordsStringFromGrid();

                    if (IndxReactNarrDAL.OrganicIndexingDB.UpdateIndexingTANInfo(objArticleInfo))
                    {
                        MessageBox.Show("TAN information saved successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show(strErrMsg.Trim(), GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       

        int editKeyRowIndx = 0;
        private void btnAddKey_Click(object sender, EventArgs e)
        {
            try
            {
                string strErrMsg = "";
                if (ValidateKey(txtKeyword.Text.Trim(), out strErrMsg))
                {
                    string strKey = Validations.RemoveInVisibleCharsDblSpaces(txtKeyword.Text.Trim());//Regex.Replace(txtKeyword.Text.Trim(), @"\s+", " "); 
                    
                    if (editKeyRowIndx == 0)//New record
                    {
                        if (TANKeyWords == null)
                        {
                            TANKeyWords = GetKeywordsTableDefinition();
                        }
                        DataRow dtRow = TANKeyWords.NewRow();
                        dtRow["KEYWORD"] = strKey;
                        dtRow["KEY_LENGTH"] = strKey.Length.ToString();
                        dtRow["KEY_WORD_CNT"] = (strKey.Split().Length).ToString();
                       
                        TANKeyWords.Rows.Add(dtRow);
                    }
                    else//Edit record
                    {
                        TANKeyWords.Rows[editKeyRowIndx - 1]["KEYWORD"] = strKey;//Regex.Replace(txtKeyword.Text.Trim(), @"\s+", " ");
                        TANKeyWords.Rows[editKeyRowIndx - 1]["KEY_LENGTH"] = strKey.Length.ToString();
                        TANKeyWords.Rows[editKeyRowIndx - 1]["KEY_WORD_CNT"] = (strKey.Split().Length).ToString();// (strKey.Split().Length - 1).ToString();
                        TANKeyWords.AcceptChanges();
                    }

                    //Bind TAN Keywords to grid
                    BindTAN_KeysToGrid(TANKeyWords);

                    //Clear Key value
                    txtKeyword.Text = "";
                    editKeyRowIndx = 0;                   
                }
                else
                {
                    MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        int editRowIndx_NP = 0;
        int articleNUMID = 0;
        private void btnSaveNUMPAR_Click(object sender, EventArgs e)
        {
            try
            {
                string strErrMsg = "";
                if(ValidateNUM_PARInformation(ref strErrMsg))
                {
                    IndexingNUMInfo numInfo = GetPARNUMInfoFromControls();
                    if (numInfo != null)
                    {
                        if (OrganicIndexingDB.UpdateIndexingNUMInfo_XML(numInfo))
                        {
                            NUM_PAR_Data = OrganicIndexingDB.GetIndexingNUMsOnTANID(TAN_ID, "NUM_PAR");
                            articleNUMID = 0;

                            MessageBox.Show("NUM " + nudNUMPAR.Value.ToString() + " info saved successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);

                            ResetNUMControls("NUM_PAR");

                            //Bind NUMs info to PAR grid
                            BindDataToNUM_PARGrid(NUM_PAR_Data);
                        }
                        else
                        {
                            MessageBox.Show("Error in saving " + nudNUMPAR.Value.ToString() + " info", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    MessageBox.Show(strErrMsg.Trim(), GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private IndexingNUMInfo GetPARNUMInfoFromControls()
        {
            IndexingNUMInfo numInfo = null;
            try
            {
                numInfo = numInfo = new IndexingNUMInfo();
                numInfo.TAN_ID = TAN_ID;
                numInfo.TAN_NUM_ID = articleNUMID;
                numInfo.NUM = Convert.ToInt32(nudNUMPAR.Value.ToString());
                numInfo.NUMType = "NUM_PAR";
                numInfo.Option = articleNUMID == 0 ? "INSERT" : "UPDATE";
                if (!string.IsNullOrEmpty(txtRegistryNo.Text.Trim()))
                {
                    numInfo.Reg_No = Convert.ToInt32(txtRegistryNo.Text.Trim());
                }
                numInfo.PAR = uchrtbPAR_NP.GetHtmlStringFromControl();//Validations.RemoveInVisibleCharsDblSpaces(htmlRtfConvs.GetHTMLFromRTFString(hrtbPAR_NP.Rtf));
                numInfo.HMD = Validations.RemoveInVisibleCharsDblSpaces(txtHMD_NP.Text.Trim());
                numInfo.AMD = Validations.RemoveInVisibleCharsDblSpaces(txtAMD.Text.Trim());
                numInfo.NUM_TMD = uchrtbTMD_NP.GetHtmlStringFromControl();//Validations.RemoveInVisibleCharsDblSpaces(htmlRtfConvs.GetHTMLFromRTFString(hrtbTMD_NP.Rtf));
                numInfo.NUMRole = txtRoleNP.Text.Trim();
                numInfo.DPT_RS = chkDPT_RS.Checked ? "Y" : "N";
                numInfo.NoStructure = chkNoStructure.Checked ? "Y" : "N";
                numInfo.PolymerStructure = chkIsPolymer.Checked ? "Y" : "N";
                numInfo.IsTradeNamePolymer = chkIsTradeNamePolymer_NP.Checked ? "Y" : "N";
                numInfo.IsCrossReferred = chkIsCrossRefTo.Checked ? "Y" : "N";
                numInfo.IsFileReviewRequire = "N";
                numInfo.CrossReferenceTo = Validations.RemoveInVisibleCharsDblSpaces(txtCrossRefPolymer_NP.Text.Trim());
                numInfo.NUMNote = Validations.RemoveInVisibleCharsDblSpaces(txtNUMNote.Text.Trim());
                if (!string.IsNullOrEmpty(ChemRenditor.MolfileString))
                {
                    numInfo.StructureMolFile = ChemRenditor.MolfileString;
                    numInfo.StructureInchi = ChemistryOperations.GetStructureInchiKey(ChemRenditor.MolfileString);
                }
                numInfo.StructureImage = pbStructureImage.Image != null ? DataConversions.ImageToByteArray(pbStructureImage.Image) : null;
               
                numInfo.SrcDocIndexTerm = uchrtbSrcDocIndxTerm_PAR.GetHtmlStringFromControl();

                if (cmbTANDocs_PAR.SelectedItem != null)
                {
                    numInfo.IndexTermSrcDocID = Convert.ToInt32(cmbTANDocs_PAR.SelectedValue);
                }

                numInfo.URID = GlobalVariables.UserID;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return numInfo;
        }

        int editRowIndx_NC = 0;
        private void btnSaveNUMCTH_Click(object sender, EventArgs e)
        {
            try
            {
                string strErrMsg = "";
                if (ValidateNUM_CTHInformation(ref strErrMsg))
                {
                    IndexingNUMInfo numInfo = GetCTHNUMInfoFromControls();
                    if (numInfo != null)
                    {
                        if (OrganicIndexingDB.UpdateIndexingNUMInfo_XML(numInfo))
                        {
                            MessageBox.Show("CTH information saved successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);

                            //Refresh Article NUMs
                            NUM_CTH_Data = IndxReactNarrDAL.OrganicIndexingDB.GetIndexingNUMsOnTANID(TAN_ID, "NUM_CTH");
                            articleNUMID = 0;

                            //Reset control values
                            ResetNUMControls("NUM_CTH");

                            //Bind NUMs info to PAR grid
                            BindDataToNUM_CTHGrid(NUM_CTH_Data);
                        }
                        else
                        {
                            MessageBox.Show("Error in saving CTH information", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }    
                else
                {
                    MessageBox.Show(strErrMsg.Trim(), GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private IndexingNUMInfo GetCTHNUMInfoFromControls()
        {
            IndexingNUMInfo numInfo = null;
            try
            {
                numInfo = new IndexingNUMInfo();
                numInfo.TAN_ID = TAN_ID;
                numInfo.TAN_NUM_ID = articleNUMID;
                numInfo.NUM = Convert.ToInt32(txtNUMCTH.Text.ToString());
                numInfo.NUMType = "NUM_CTH";
                numInfo.Option = articleNUMID == 0 ? "INSERT" : "UPDATE";
                numInfo.CTH = Validations.RemoveInVisibleCharsDblSpaces(txtCTH.Text.Trim());
                numInfo.DPT_RS = "N";
                numInfo.NoStructure = "N";

                if (rbnCTHGeneral.Checked)
                {
                    numInfo.CTH_Type = "GENERAL";
                }
                else if (rbnCTHMolStruct.Checked)
                {
                    numInfo.CTH_Type = "MOL_STRUCTURE";
                }
                else if (rbnCTHCrystalStruct.Checked)
                {
                    numInfo.CTH_Type = "CRYSTAL_STRUCTURE";
                }
                numInfo.NUM_TMD = uchrtbTMD_NC.GetHtmlStringFromControl();
                numInfo.HMD = Validations.RemoveInVisibleCharsDblSpaces(txtHMD_NC.Text.Trim());
                numInfo.NUMRole = txtRoleNC.Text.Trim();
                numInfo.IsTradeNamePolymer = chkIsTradeNamePolymer_NC.Checked ? "Y" : "N";
                numInfo.IsFileReviewRequire = chkRequireFileReview.Checked ? "Y" : "N";
                numInfo.IsCrossReferred = "N";
                numInfo.CrossReferenceTo = Validations.RemoveInVisibleCharsDblSpaces(txtCrossRefPolymer_NC.Text.Trim());

                numInfo.SrcDocIndexTerm = uchrtbSrcDocIndxTerm_CTH.GetHtmlStringFromControl();

                if (cmbTANDocs_CTH.SelectedItem != null)
                {
                    numInfo.IndexTermSrcDocID = Convert.ToInt32(cmbTANDocs_CTH.SelectedValue);
                }

                numInfo.URID = GlobalVariables.UserID;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return numInfo;
        }

        private void btnExportSDF_Click(object sender, EventArgs e)
        {
            try
            {
                if (TAN_ID > 0)
                {
                    //Article NUMs for SDF                   
                    if (NUM_PAR_Data != null)
                    {
                        if (NUM_PAR_Data.Rows.Count > 0)
                        {
                            using (FolderBrowserDialog fldBrow = new FolderBrowserDialog())
                            {
                                if (fldBrow.ShowDialog() == DialogResult.OK)
                                {
                                    string strOutFilePath = fldBrow.SelectedPath + "\\" + txtTAN.Text.Trim() + "_sdf.txt";
                                    List<int> lstTANs = new List<int>();
                                    lstTANs.Add(TAN_ID);

                                    if (ExportToSDF.ExportTANNUMsToSDF(lstTANs, strOutFilePath))
                                    {
                                        MessageBox.Show("Exported to SD file successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);

                                        //Open SDF file
                                        System.Diagnostics.Process.Start(strOutFilePath);
                                    }
                                    else
                                    {
                                        MessageBox.Show("Error in SD file export", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("No NUMs available for SD file export", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        MessageBox.Show("No NUMs available for SD file export", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnDATPreview_Click(object sender, EventArgs e)
        {
            try
            {
                if (TAN_ID > 0)
                {
                    FolderBrowserDialog objFBD = new FolderBrowserDialog();
                    if (objFBD.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        Cursor = Cursors.WaitCursor;
                        
                        List<Int32> lstTAN = new List<Int32>();
                        lstTAN.Add(TAN_ID);
                        
                        string strDATFileName = objFBD.SelectedPath + "\\" + txtTAN.Text.Trim() + "_DAT.txt";
                        if (IndxReactNarr.Export.ExportMacroIndexing.ExportArticleNUMsToDATFile(lstTAN, strDATFileName))
                        {
                            Cursor = Cursors.Default;

                            //Validate DAT file for Non-Standard ASCII
                            string fileData = System.IO.File.ReadAllText(strDATFileName);
                            if (ValidateUniCodeChar.IsASCIIData(fileData))
                            {                               
                                MessageBox.Show("Exported to DAT file successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);

                                //Open DAT file
                                if (File.Exists(strDATFileName))
                                {
                                    System.Diagnostics.Process.Start(strDATFileName);
                                }
                            }
                            else
                            {
                                MessageBox.Show("DAT file contains Non-Standard ASCII characters", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }    
                        }
                        else
                        {
                            Cursor = Cursors.Default;
                            MessageBox.Show("Error in DAT file export", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Cursor = Cursors.Default;
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnMolToImage_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(ChemRenditor.MolfileString))
                {
                    pbStructureImage.Image = ChemRenditor.Image;
                    ChemRenditor.MolfileString = null;
                }
                else
                {
                    pbStructureImage.Image = null;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnCopyToImage_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(ChemRenditor.MolfileString))
                {
                    pbStructureImage.Image = ChemRenditor.Image;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtKeyword_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == 13)
                {
                    btnAddKey_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        #region Reset Methods for NUM controls

        private void ResetNUMControls(string numType)
        {
            try
            {
                if (!string.IsNullOrEmpty(numType))
                {
                    if (numType.ToUpper() == "NUM_PAR")
                    {
                        editRowIndx_NP = 0;
                        editNUM_NP = 0;
                        articleNUMID = 0;

                        nudNUMPAR.Value = 1;
                        txtRegistryNo.Clear();
                        uchrtbPAR_NP.hrtbPara.Clear();

                        uchrtbSrcDocIndxTerm_PAR.hrtbPara.Clear();
                        cmbTANDocs_PAR.SelectedIndex = -1;

                        txtHMD_NP.Clear();
                        txtAMD.Clear();
                        uchrtbTMD_NP.hrtbPara.Clear();
                        txtRoleNP.Clear();
                        txtNUMNote.Clear();
                        chkDPT_RS.Checked = false;
                        chkNoStructure.Checked = false;
                        chkIsPolymer.Checked = false;
                        chkIsTradeNamePolymer_NP.Checked = false;
                        chkIsCrossRefTo.Checked = false; 
                        txtCrossRefPolymer_NP.Clear();
                        ChemRenditor.MolfileString = null;
                        pbStructureImage.Image = null;

                        txtNUMNote.Enabled = true;
                    }
                    else if (numType.ToUpper() == "NUM_CTH")
                    {
                        editNUM_NC = 0;
                        editRowIndx_NC = 0;
                        articleNUMID = 0;

                        uchrtbSrcDocIndxTerm_CTH.hrtbPara.Clear();
                        cmbTANDocs_CTH.SelectedIndex = -1;

                        txtCTH.Clear();
                        txtHMD_NC.Clear();
                        txtRoleNC.Clear();
                        txtNUMCTH.Text = dgvNUM_CTH.Rows.Count == 0 ? "801" : (801 + dgvNUM_CTH.Rows.Count).ToString();

                        chkRequireFileReview.Checked = false;
                        chkIsTradeNamePolymer_NC.Checked = false;
                        txtCrossRefPolymer_NC.Clear();

                        rbnCTHGeneral.Checked = true;
                        uchrtbTMD_NC.hrtbPara.Clear();
                        uchrtbTMD_NC.hrtbPara.Enabled = false;               
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnResetNUMPAR_Click(object sender, EventArgs e)
        {
            try
            {
                ResetNUMControls("NUM_PAR");
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnResetNUMCTH_Click(object sender, EventArgs e)
        {
            try
            {
                ResetNUMControls("NUM_CTH");
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion
           
        #region Grid Cell Content Click Events

        private void dgvNUM_PAR_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                {
                    if (dgvNUM_PAR.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString().ToUpper() == "EDIT")
                    {
                        editRowIndx_NP = e.RowIndex + 1;
                        BindGridRowDataToControls(dgvNUM_PAR.Rows[e.RowIndex], "NUM_PAR");
                    }
                    else if (dgvNUM_PAR.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString().ToUpper() == "DELETE")
                    {
                        int selNUM = Convert.ToInt32(dgvNUM_PAR.Rows[e.RowIndex].Cells["colNUM_NP"].Value.ToString());
                        int articleNUMID = Convert.ToInt32(dgvNUM_PAR.Rows[e.RowIndex].Cells["colArticleNUMID_NP"].Value.ToString());

                        DialogResult diaRes = MessageBox.Show("Do you want to delete the selected PAR?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (diaRes == DialogResult.Yes)
                        {
                            IndexingNUMInfo numInfo = new IndexingNUMInfo();
                            numInfo.TAN_ID = TAN_ID;
                            numInfo.TAN_NUM_ID = articleNUMID;
                            numInfo.Option = "DELETE";                          
                            if (OrganicIndexingDB.UpdateIndexingNUMInfo(numInfo))
                            {
                                MessageBox.Show("NUM-PAR Deleted successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);

                                //Refresh Article NUMs
                                NUM_PAR_Data = OrganicIndexingDB.GetIndexingNUMsOnTANID(TAN_ID, "NUM_PAR");
                                articleNUMID = 0;

                                //Reset control values
                                ResetNUMControls("NUM_PAR");

                                //Bind NUMs info to PAR grid
                                BindDataToNUM_PARGrid(NUM_PAR_Data);
                            }
                            else
                            {
                                MessageBox.Show("Error in PAR delete", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void dgvNUM_CTH_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                {
                    if (dgvNUM_CTH.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString().ToUpper() == "EDIT")
                    {
                        editRowIndx_NC = e.RowIndex + 1;
                        BindGridRowDataToControls(dgvNUM_CTH.Rows[e.RowIndex], "NUM_CTH");
                    }
                    else if (dgvNUM_CTH.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString().ToUpper() == "DELETE")
                    {
                        int selNUM = Convert.ToInt32(dgvNUM_CTH.Rows[e.RowIndex].Cells["colNUM_NC"].Value.ToString());
                        int articleNUMID = Convert.ToInt32(dgvNUM_CTH.Rows[e.RowIndex].Cells["colArticleNUMID_NC"].Value.ToString());

                        DialogResult diaRes = MessageBox.Show("Do you want to delete the selected CTH?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (diaRes == DialogResult.Yes)
                        {
                            IndexingNUMInfo numInfo = new IndexingNUMInfo();
                            numInfo.TAN_ID = TAN_ID;
                            numInfo.TAN_NUM_ID = articleNUMID;
                            numInfo.Option = "DELETE";                           
                            if (OrganicIndexingDB.UpdateIndexingNUMInfo(numInfo))
                            {
                                MessageBox.Show("Deleted successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);

                                //Refresh Article NUMs
                                NUM_CTH_Data = IndxReactNarrDAL.OrganicIndexingDB.GetIndexingNUMsOnTANID(TAN_ID, "NUM_CTH");
                                articleNUMID = 0;

                                //Reset control values
                                ResetNUMControls("NUM_CTH");

                                //Bind NUMs info to PAR grid
                                BindDataToNUM_CTHGrid(NUM_CTH_Data);
                            }
                            else
                            {
                                MessageBox.Show("Error in deleting " + selNUM + " info", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
                
        private void dgvKeywords_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dgvKeywords.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString().ToUpper() == "EDIT")
                {
                    txtKeyword.Text = dgvKeywords.Rows[e.RowIndex].Cells["colKeyWord"].Value.ToString();
                    editKeyRowIndx = e.RowIndex + 1;
                }
                else if (dgvKeywords.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString().ToUpper() == "DELETE")
                {
                    DialogResult diaRes = MessageBox.Show("Do you want to delete the selected Key?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (diaRes == DialogResult.Yes)
                    {
                        TANKeyWords.Rows[e.RowIndex].Delete();
                        TANKeyWords.AcceptChanges();

                        //Bind TAN Keywords to grid
                        BindTAN_KeysToGrid(TANKeyWords);

                        //Clear Key value
                        txtKeyword.Text = "";
                        editKeyRowIndx = 0;                       
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }      

        #endregion
               
        #region DataGridView Row Postpaint Events

        private void dgvKeywords_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvKeywords.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvKeywords.Font);

                if (dgvKeywords.RowHeadersWidth < (int)(size.Width + 20)) dgvKeywords.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvNUM_PAR_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvNUM_PAR.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvNUM_PAR.Font);

                if (dgvNUM_PAR.RowHeadersWidth < (int)(size.Width + 20)) dgvNUM_PAR.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvNUM_CTH_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvNUM_CTH.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvNUM_CTH.Font);

                if (dgvNUM_CTH.RowHeadersWidth < (int)(size.Width + 20)) dgvNUM_CTH.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        #endregion        

        #region CTH Type RadioButton CheckedChanged Events

        private void rbnCTHMolStruct_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (rbnCTHMolStruct.Checked)
                {
                    txtCTH.Text = "molecular structure";
                    txtCTH.Enabled = false;
                    
                    uchrtbTMD_NC.hrtbPara.Enabled = true;
                    uchrtbTMD_NC.hrtbPara.Clear();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnCTHCrystalStruct_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (rbnCTHCrystalStruct.Checked)
                {
                    txtCTH.Text = "crystal structure";
                    txtCTH.Enabled = false;

                    uchrtbTMD_NC.hrtbPara.Enabled = true;
                    uchrtbTMD_NC.hrtbPara.Clear();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }  
      
        private void rbnCTHGeneral_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (rbnCTHGeneral.Checked)
                {
                    txtCTH.Enabled = true;
                    lnkCTH.Enabled = true;

                    uchrtbTMD_NC.hrtbPara.Enabled = false;
                    uchrtbTMD_NC.hrtbPara.Clear();
                }
                else
                {
                    lnkCTH.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnCTHGeneral_MouseClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (rbnCTHGeneral.Checked)
                {
                    txtCTH.Clear();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion                        

        #region CTH link Click Event

        private void lnkCTH_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                frmConceptTextHeadings objCTH = new frmConceptTextHeadings();
                objCTH.SelectedCTH = txtCTH.Text.Trim();
                if (objCTH.ShowDialog() == DialogResult.OK)
                {
                    txtCTH.Text = objCTH.SelectedCTH.Trim();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        private void chkNoStructure_CheckedChanged(object sender, EventArgs e)
        {
            //try
            //{
            //    if (chkNoStructure.Checked)
            //    {
            //        txtNUMNote.Enabled = false;
            //        txtNUMNote.Clear();
            //    }
            //    else
            //    {
            //        txtNUMNote.Enabled = true;
            //        txtNUMNote.Clear();
            //    }
            //}
            //catch (Exception ex)
            //{
            //    ErrorHandling.WriteErrorLog(ex.ToString());
            //}
        }

        #region Grid MouseMove Events

        //int OldRow = 0;
        //DataGridView.HitTestInfo hti;
        //private void dgvNUM_PAR_MouseMove(object sender, MouseEventArgs e)
        //{
        //    try
        //    {
        //        hti = dgvNUM_PAR.HitTest(e.X, e.Y);
        //        if (hti.RowIndex >= 0 && hti.RowIndex != OldRow)
        //        {
        //            dgvNUM_PAR.Rows[OldRow].Selected = false;
        //            dgvNUM_PAR.Rows[hti.RowIndex].Selected = true;
        //            OldRow = hti.RowIndex;
        //        }
        //    }
        //    catch (Exception ex)
        //    {                
        //       ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}

        //private void dgvNUM_CTH_MouseMove(object sender, MouseEventArgs e)
        //{
        //    try
        //    {
        //        hti = dgvNUM_CTH.HitTest(e.X, e.Y);
        //        if (hti.RowIndex >= 0 && hti.RowIndex != OldRow)
        //        {
        //            dgvNUM_CTH.Rows[OldRow].Selected = false;
        //            dgvNUM_CTH.Rows[hti.RowIndex].Selected = true;
        //            OldRow = hti.RowIndex;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}

        //private void dgvKeywords_MouseMove(object sender, MouseEventArgs e)
        //{
        //    try
        //    {
        //        hti = dgvKeywords.HitTest(e.X, e.Y);
        //        if (hti.RowIndex >= 0 && hti.RowIndex != OldRow)
        //        {
        //            dgvKeywords.Rows[OldRow].Selected = false;
        //            dgvKeywords.Rows[hti.RowIndex].Selected = true;
        //            OldRow = hti.RowIndex;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}

        #endregion

        #region Form Closing Event

        bool blFormClose = false;
        private void frmOrganicIndexing_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (blFormClose == false)
                {
                    e.Cancel = true;
                    string strErr = "";
                    if (!ValidateNUMsSequence(out strErr))
                    {
                        MessageBox.Show("Please clear the below errors\r\n" + strErr, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        blFormClose = true;
                        this.Close();
                    }
                }                               
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        private void lnkSection_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                using (frmSectionMaster secMaster = new frmSectionMaster())
                {
                    if (secMaster.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        txtSection.Text = secMaster.SelectedSection;
                        txtSubSection.Text = secMaster.SelectedSubSec;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnTANComplete_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult diaRes = MessageBox.Show("Do you want to complete the TAN?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (diaRes == DialogResult.Yes)
                {
                    using (frmTaskComments_Indexing taskComments = new frmTaskComments_Indexing())
                    {
                        taskComments.TAN_Name = TAN_Name;                      
                        taskComments.TAN_ID = TAN_ID;
                        taskComments.TaskName = "TASK COMPLETE";
                       
                        if (taskComments.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                        {
                            //Update Task Status and Close TAN
                            TaskStatus tskStatus = new TaskStatus();
                            tskStatus.TaskComments = taskComments.txtIndexingTaskComments.Text.Trim();
                            tskStatus.Task_ID = Task_ID;
                            //tskStatus.Role_ID = GlobalVariables.RoleID;
                            tskStatus.UR_ID = GlobalVariables.URID;
                            tskStatus.TaskAllocation_ID = TaskAlloc_ID;
                            tskStatus.TaskStatusName = "SET COMPLETE";
                            if (TaskManagementDB.UpdateUserTaskStatus(tskStatus))
                            {
                                this.Close();
                            }
                            else
                            {
                                MessageBox.Show("Error in TAN complete", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnRejectTAN_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult diaRes = MessageBox.Show("Do you want to reject the TAN?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (diaRes == DialogResult.Yes)
                {
                    using (frmTaskComments taskComments = new frmTaskComments())
                    {
                        taskComments.TAN_Name = TAN_Name;
                        taskComments.TAN_ID = TAN_ID;
                        taskComments.TaskName = "TASK REJECT";
                        if (taskComments.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                        {
                            //Update Task Status and Close TAN
                            TaskStatus tskStatus = new TaskStatus();
                            tskStatus.TaskComments = taskComments.txtTaskComments.Text.Trim();
                            tskStatus.Task_ID = Task_ID;
                            //tskStatus.Role_ID = GlobalVariables.RoleID;
                            tskStatus.UR_ID = GlobalVariables.URID;
                            tskStatus.TaskAllocation_ID = TaskAlloc_ID;
                            tskStatus.TaskStatusName = "SET REJECT";
                            if (TaskManagementDB.UpdateUserTaskStatus(tskStatus))
                            {
                                this.Close();
                            }
                            else
                            {
                                MessageBox.Show("Error in TAN reject", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnExportToPdf_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtTAN.Text))
                {
                    using (FolderBrowserDialog objFolDlg = new FolderBrowserDialog())
                    {
                        if (objFolDlg.ShowDialog() == DialogResult.OK)
                        {
                            Cursor = Cursors.WaitCursor;

                            string strPdfName = objFolDlg.SelectedPath + "\\" + txtTAN.Text + "_OrgIndexing.pdf";
                               
                            OrgIndxExportToPdf exportPdf = new OrgIndxExportToPdf();
                            if (exportPdf.ExportTANData(TANInfoTbl, NUM_PAR_Data, NUM_CTH_Data, strPdfName))
                            {
                                Process.Start(strPdfName);
                            }

                            Cursor = Cursors.Default;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void lnkCrossRef_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                using (frmCrossReference crossRef = new frmCrossReference())
                {
                    crossRef.SelCrossRefs = txtCrossRefSections.Text.Trim();
                    if (crossRef.ShowDialog() == DialogResult.OK)
                    {
                        txtCrossRefSections.Text = crossRef.SelCrossRefs.Trim();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnHideSplChars_Click(object sender, EventArgs e)
        {
            try
            {
                if (ucSplCharsToolStrip_Indexing1.Visible == true)
                {
                    ucSplCharsToolStrip_Indexing1.Visible = false;
                }
                else
                {
                    ucSplCharsToolStrip_Indexing1.Visible = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void lnkRegNo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                frmNUMs objNUMs = new frmNUMs();            
                objNUMs.SeriesType = "9000";               

                if (objNUMs.ShowDialog() == DialogResult.OK)
                {
                    if (objNUMs.Sel_NUM > 0)
                    {
                        txtRegistryNo.Text = objNUMs.Sel_RegNo.ToString();
                        uchrtbPAR_NP.hrtbPara.Text = objNUMs.Sel_Name;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void chkIsTradeNamePolymer_NC_CheckStateChanged(object sender, EventArgs e)
        {
            try
            {
                if (chkIsTradeNamePolymer_NC.Checked)
                {
                    lnkCrossRefTo_CTH.Enabled = true;
                    txtCrossRefPolymer_NC.Enabled = true;
                    txtCrossRefPolymer_NC.Text = "CTH";
                }
                else
                {
                    lnkCrossRefTo_CTH.Enabled = false;
                    txtCrossRefPolymer_NC.Enabled = false;
                    txtCrossRefPolymer_NC.Text = "";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
                
        private void chkIsCrossRefTo_CheckStateChanged(object sender, EventArgs e)
        {
            try
            {
                if (chkIsCrossRefTo.Checked)
                {                    
                    txtCrossRefPolymer_NP.Enabled = true;
                }
                else
                {                   
                    txtCrossRefPolymer_NP.Enabled = false;
                    txtCrossRefPolymer_NP.Text = "";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tcMain_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                articleNUMID = 0;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnXmlPreview_Click(object sender, EventArgs e)
        {
            try
            {
                if (TAN_ID > 0)
                {
                    using (FolderBrowserDialog objFBD = new FolderBrowserDialog())
                    {
                        if (objFBD.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                        {
                            Cursor = Cursors.WaitCursor;

                            List<Int32> lstTAN = new List<Int32>();
                            lstTAN.Add(TAN_ID);

                            int succTANCnt = IndxReactNarr.Export.MacroIndexing.ExportMacroIndexingToXml.ExportTANsToDocumentAndIdxXmlFiles(lstTAN, objFBD.SelectedPath);
                            if (succTANCnt == lstTAN.Count)
                            {
                                Cursor = Cursors.Default;
                                MessageBox.Show("Exported to Xml files successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else
                            {
                                Cursor = Cursors.Default;
                                MessageBox.Show("Error in Xml file export", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            #region MyRegion
                            //Article Info
                            //DataTable dtTANDetails = ReactDB.GetTANDetailsOnTANID(TAN_ID);
                            //if (IndxReactNarr.Export.OrganicIndexing.XmlDelivery.ExportOrgIndexingToXml.ExportArticleInfoToDocumentXml(dtTANDetails, objFBD.SelectedPath))
                            //{
                            //    Cursor = Cursors.Default;
                            //    MessageBox.Show("Exported to Xml file successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);

                            //    ////Open DAT file
                            //    //if (File.Exists(xmlFileName))
                            //    //{
                            //    //    System.Diagnostics.Process.Start(xmlFileName);
                            //    //}
                            //}
                            //else
                            //{
                            //    Cursor = Cursors.Default;
                            //    MessageBox.Show("Error in Xml file export", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            //} 
                            #endregion
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void lnkCrossRefTo_CTH_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                frmConceptTextHeadings objCTH = new frmConceptTextHeadings();
                objCTH.SelectedCTH = txtCrossRefPolymer_NC.Text.Trim();
                if (objCTH.ShowDialog() == DialogResult.OK)
                {
                    txtCrossRefPolymer_NC.Text = objCTH.SelectedCTH.Trim();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }                     
    }
}

