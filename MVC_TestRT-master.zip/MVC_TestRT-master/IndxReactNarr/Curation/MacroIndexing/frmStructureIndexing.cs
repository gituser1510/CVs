﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using System.Text.RegularExpressions;
using System.IO;
using IndxReactNarrDAL;
using IndxReactNarr.Common;
using IndxReactNarrBLL;
using IndxReactNarr.Export;

namespace IndxReactNarr
{
    public partial class frmStructureIndexing : Form
    {
        #region Constructor

        public frmStructureIndexing()
        {
            InitializeComponent();
        }
 
        #endregion

        #region Public Properties

        public int TAN_ID { get; set; }
        public string TAN { get; set; }
        public DataTable NUM_PAR_Data { get; set; }
        
        #endregion

        #region Page Load Event

        private void frmStructureIndexing_Load(object sender, EventArgs e)
        {
            try
            {               
                //Indexing Roles
                if (GlobalVariables.IndexingRoles == null)
                {
                    GlobalVariables.IndexingRoles = OrganicIndexingDB.GetIndexingRoleIndicators();
                }

                if (GlobalVariables.ApplicationName == Enums.ApplicationName.ORGANIC.ToString())
                {
                    chkIsPolymer.Visible = false;
                    chkIsTradeNamePolymer_NP.Visible = false;
                    chkIsCrossRefTo.Visible = false;
                    txtCrossRefPolymer_NP.Visible = false;
                }

                if (TAN_ID > 0 && !string.IsNullOrEmpty(TAN))
                {
                    //Get Article NUMs
                    NUM_PAR_Data = OrganicIndexingDB.GetIndexingNUMsOnTANID(TAN_ID, "NUM_PAR");

                    txtTAN.Text = TAN;
                    txtTAN.Enabled = false;

                    //Bind NUMs info to PAR grid
                    BindDataToNUM_PARGrid(NUM_PAR_Data);
                }

                if (!string.IsNullOrEmpty(GlobalVariables.RoleName))
                {
                    if ((GlobalVariables.RoleName.ToUpper() == "SUPERVISOR") || (GlobalVariables.RoleName.ToUpper() == "ADMINISTRATOR"))
                    {
                        colDeleteNP.Visible = true;
                    }
                    else
                    {
                        colDeleteNP.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        #region PictureBox Click Event

        private void pbStructureImage_Click(object sender, EventArgs e)
        {
            try
            {
                //System.Drawing.Image returnImage = null;
                if (Clipboard.ContainsImage())
                {
                    pbStructureImage.Image  = Clipboard.GetImage();

                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        #region Role link Click Events

        private void lnkRoleNP_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                frmEditIndexingRole objEditRole = new frmEditIndexingRole();                
                objEditRole.SelectedRoles = txtRoleNP.Text.Trim();
                if (objEditRole.ShowDialog() == DialogResult.OK)
                {
                    txtRoleNP.Text = objEditRole.SelectedRoles.Trim();                    
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        

        #endregion
       
        #region Validation methods

        private bool ValidateNUM_PARInformation(ref string errMsg)
        {
            bool blStatus = true;
            try
            {
                //if (articleNUMID == 0)
                //{
                //    blStatus = false;
                //    errMsg = errMsg.Trim() + "\r\n" + "User don't have permission to add new NUM. Only Edit permission is available.";
                //    return blStatus;
                //}

                string strErr = "";
                //Validate NUM
                if (nudNUMPAR.Value == 0)
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "NUM should be > 0";
                }
                else if (CheckForDuplicateNUM((int)nudNUMPAR.Value))
                {
                    //Check for duplicate NUM
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "Duplicate NUM";
                }                

                //Validate PAR
                if (string.IsNullOrEmpty(uchrtbPAR_NP.hrtbPara.Text.Trim()))
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "PAR can't be null";
                }
                else //if (!string.IsNullOrEmpty(txtPAR.Text.Trim()))
                {
                    if (uchrtbPAR_NP.hrtbPara.Text.Trim().Length > 500)
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "PAR length should be < 500 characters";
                    }
                    int intPAR = 0;
                    if (int.TryParse(uchrtbPAR_NP.hrtbPara.Text.Trim(), out intPAR))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "PAR contains number";
                    }

                    //Check for duplicate PAR
                    if (CheckForDuplicatePAR(Html_RtfConversions.Instance.GetHTMLFromRTFString(uchrtbPAR_NP.hrtbPara.Rtf), txtAMD.Text.Trim()))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "Duplicate PAR";
                    }

                    if (Common.Validations.ValidateUnicodeCharactersInString(uchrtbPAR_NP.hrtbPara.Text.Trim(), out strErr))//New validation on 10th Sep 2014
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "PAR contains invalid characters " + strErr;
                    }
                }

                //Validate Role
                if (string.IsNullOrEmpty(txtRoleNP.Text.Trim()))
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "Role can't be null";
                }

                //Notes Validation
                if (txtNUMNote.Text.Trim().Length > 1500)
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "Note length should be < 1500 characters";
                }

                //AMD Validation
                if (txtAMD.Text.Trim().Length > 1500)
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "AMD length should be < 1500 characters";
                }

                //HMD Validation
                if (txtHMD_NP.Text.Trim().Length > 240)
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "HMD length should be < 240 characters";
                }

                //TMD Validation
                if (uchrtbTMD_NP.hrtbPara.Text.Trim().Length > 240)
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "NUM-TMD length should be < 240 characters";
                }
                if (Common.Validations.ValidateUnicodeCharactersInString(uchrtbTMD_NP.hrtbPara.Text.Trim(), out strErr))//New validation on 10th Sep 2014
                {
                    blStatus = false;
                    errMsg = errMsg.Trim() + "\r\n" + "TMD contains invalid characters " + strErr.Trim();
                }

                //Validate Registry No.
                if (!string.IsNullOrEmpty(txtRegistryNo.Text.Trim()))
                {
                    int intRegNo = 0;
                    if (int.TryParse(txtRegistryNo.Text.Trim(), out intRegNo))
                    {
                        if (!ValidateRegistryNoCheckSUMValue(intRegNo))
                        {
                            blStatus = false;
                            errMsg = errMsg.Trim() + "\r\n" + "In-valid Registry No. CheckSum validation violated";
                        }
                        else if (CheckForDuplicateRegNo(intRegNo))
                        {
                            //Check for duplicate Registry No.
                            blStatus = false;
                            errMsg = errMsg.Trim() + "\r\n" + "Duplicate Registry No.";
                        }
                    }
                    else
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "Registry No. should be integer";
                    }
                }

                //No Structure Validation
                if (chkNoStructure.Checked)
                {
                    if (string.IsNullOrEmpty(txtNUMNote.Text.Trim()))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "NUM Note is mandatory when NoStructure flag is set";
                    }

                    if (!string.IsNullOrEmpty(ChemRenditor.MolfileString) || pbStructureImage.Image != null || !string.IsNullOrEmpty(txtRegistryNo.Text.Trim()))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "Structure Molfile, Structure Image and RegistryNo should be null when NoStructure flag is set";
                    }
                }
                else
                {
                    if (chkIsPolymer.Checked == false)
                    {
                        if (string.IsNullOrEmpty(txtRegistryNo.Text.Trim()) && string.IsNullOrEmpty(ChemRenditor.MolfileString))
                        {
                            blStatus = false;
                            errMsg = errMsg.Trim() + "\r\n" + "Structure is mandatory when Registry No. is not available";
                        }
                        else if (pbStructureImage.Image == null && (!string.IsNullOrEmpty(txtRegistryNo.Text.Trim()) && chkDPT_RS.Checked == false))//Validate Structure Image
                        {
                            blStatus = false;
                            errMsg = errMsg.Trim() + "\r\n" + "Structure Image is mandatory when Registry No. is available";
                        }
                    }
                }

                //New validation on 17th Sep 2014
                if (chkIsTradeNamePolymer_NP.Checked && !chkIsCrossRefTo.Checked)
                {
                    if (string.IsNullOrEmpty(txtNUMNote.Text.Trim()))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "Note is mandatory when Trade Name Polymer is checked";
                    }
                }

                //New validation on 18th Sep 2014
                if (chkIsCrossRefTo.Checked)
                {
                    if (string.IsNullOrEmpty(txtHMD_NP.Text.Trim()))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "HMD is mandatory when Trade Name Polymer is checked";
                    }

                    if (string.IsNullOrEmpty(txtCrossRefPolymer_NP.Text.Trim()))
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "Cross Reference Name is mandatory when Trade Name Polymer is checked";
                    }

                    if (!chkIsTradeNamePolymer_NP.Checked)
                    {
                        blStatus = false;
                        errMsg = errMsg.Trim() + "\r\n" + "Trade Name Polymer is mandatory when cross referenced";
                    }
                }

                ////Validate NUM sequence
                //string strErr = "";
                //if (!ValidateNUMsSequence(out strErr))
                //{
                //    blStatus = false;
                //    errMsg = errMsg.Trim() + "\r\n" + strErr.Trim();
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckForDuplicatePAR(string parHtml, string amd)
        {
            bool blStatus = false;
            try
            {
                if (!string.IsNullOrEmpty(parHtml) && NUM_PAR_Data != null)
                {
                    if (NUM_PAR_Data.Rows.Count > 0)
                    {
                        if (articleNUMID == 0)//New PAR
                        {
                            var rows = NUM_PAR_Data.AsEnumerable().Where(r => r.Field<string>("PAR") == parHtml && r.Field<string>("AMD") == amd);
                            if (rows != null)
                            {
                                if (rows.Count() > 0)
                                {
                                    blStatus = true;
                                }
                            }
                        }
                        else//Edited Record
                        {
                            EnumerableRowCollection<DataRow> rows = from row in NUM_PAR_Data.AsEnumerable()
                                                                    where row.Field<string>("PAR") == parHtml && row.Field<string>("AMD") == amd && row.Field<Int64>("TAN_NUM_ID") != articleNUMID
                                                                    select row;
                            if (rows != null)
                            {
                                if (rows.Count() > 0)
                                {
                                    blStatus = true;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckForDuplicateNUM(int tanNum)
        {
            bool blStatus = false;
            try
            {
                if (tanNum > 0 && NUM_PAR_Data != null)
                {
                    if (NUM_PAR_Data.Rows.Count > 0)
                    {
                        if (articleNUMID == 0)//New NUM
                        {
                            var rows = NUM_PAR_Data.AsEnumerable().Where(r => r.Field<Int16>("NUM") == tanNum);
                            if (rows != null)
                            {
                                if (rows.Count() > 0)
                                {
                                    blStatus = true;
                                }
                            }
                        }
                        else//Edited Record
                        {
                            EnumerableRowCollection<DataRow> rows = from row in NUM_PAR_Data.AsEnumerable()
                                                                    where row.Field<Int16>("NUM") == tanNum && row.Field<Int64>("TAN_NUM_ID") != articleNUMID
                                                                    select row;
                            if (rows != null)
                            {
                                if (rows.Count() > 0)
                                {
                                    blStatus = true;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckForDuplicateRegNo(int regNo)
        {
            bool blStatus = false;
            try
            {
                if (regNo > 0 && NUM_PAR_Data != null)
                {
                    if (NUM_PAR_Data.Rows.Count > 0)
                    {
                        if (articleNUMID == 0)//New NUM
                        {
                            var rows = NUM_PAR_Data.AsEnumerable().Where(r => r.Field<Int64?>("REG_NO") == regNo);
                            if (rows != null)
                            {
                                if (rows.Count() > 0)
                                {
                                    blStatus = true;
                                }
                            }
                        }
                        else//Edited Record
                        {
                            EnumerableRowCollection<DataRow> rows = from row in NUM_PAR_Data.AsEnumerable()
                                                                    where row.Field<Int64?>("REG_NO") == regNo && row.Field<Int64>("TAN_NUM_ID") != articleNUMID
                                                                    select row;
                            if (rows != null)
                            {
                                if (rows.Count() > 0)
                                {
                                    blStatus = true;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool ValidateRegistryNoCheckSUMValue(int nrnreg)
        {
            bool blStatus = false;
            try
            {
                if (nrnreg > 0)
                {
                    int checkSumDigit = 0;
                    string strNrnReg = nrnreg.ToString();
                    checkSumDigit = Convert.ToInt16(strNrnReg[strNrnReg.Length - 1].ToString());

                    char[] caNrnReg = strNrnReg.ToCharArray();
                    if (caNrnReg != null)
                    {
                        if (caNrnReg.Length > 0)
                        {
                            int intSum = 0;
                            int intTemp = caNrnReg.Length - 1;
                            for (int i = 0; i < caNrnReg.Length - 1; i++)
                            {
                                intSum = intSum + (Convert.ToInt32(caNrnReg[i].ToString()) * intTemp);
                                intTemp = intTemp - 1;
                            }
                            int intReminder = 0;
                            Math.DivRem(intSum, 10, out intReminder);

                            if (checkSumDigit == intReminder)
                            {
                                blStatus = true;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }
               
        private bool CheckForDuplicateNUM_RegNo(int num, string numType)
        {
            bool blStatus = false;
            try
            {
                if (num > 0 && !string.IsNullOrEmpty(numType))
                {
                    if (NUM_PAR_Data != null)
                    {
                        if (NUM_PAR_Data.Rows.Count > 0)
                        {
                            if (numType.ToUpper() == "NUM")
                            {
                                var rows = NUM_PAR_Data.AsEnumerable().Where(r => r.Field<int>("NUM") == num);
                                if (rows != null)
                                {
                                    if (rows.Count() > 0)
                                    {
                                        if (num != editNUM_NP && editNUM_NP > 0)
                                        {
                                            blStatus = true;
                                        }
                                        else if (editNUM_NP == 0)
                                        {
                                            blStatus = true;
                                        }
                                    }
                                }
                            }
                            else if (numType.ToUpper() == "REGISTRYNO")
                            {
                                #region Old code commented
                                //var rows = NUM_PAR_Data.AsEnumerable().Where(r => r.Field<Int32?>("nrnreg") == num);
                                //if (rows != null)
                                //{
                                //    //if (rows.Count() > 0 && editNUM_NP == 0)
                                //    //{
                                //    //    blStatus = true;
                                //    //}  
                                #endregion                               

                                for (int i = 0; i < NUM_PAR_Data.Rows.Count;i++ )
                                {
                                    if (NUM_PAR_Data.Rows[i]["REG_NO"] != null)
                                    {
                                        if (!string.IsNullOrEmpty(NUM_PAR_Data.Rows[i]["REG_NO"].ToString()))
                                        {
                                            if (Convert.ToInt32(NUM_PAR_Data.Rows[i]["REG_NO"]) == num)
                                            {
                                                if (editNUM_NP == 0)//new record
                                                {
                                                    blStatus = true;
                                                }
                                                else if (Convert.ToInt32(NUM_PAR_Data.Rows[i]["NUM"]) != nudNUMPAR.Value)
                                                {
                                                    blStatus = true;
                                                }                                                
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool ValidateNUMs_PARs(out string errMsg)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                //Check missing NUMS
                if (dgvNUM_PAR.Rows.Count > 0)
                {
                    DataTable dtPARs = (DataTable)dgvNUM_PAR.DataSource;
                    if (dtPARs != null)
                    {
                        if (dtPARs.Rows.Count > 0)
                        {
                            if (Convert.ToInt32(dtPARs.Rows[dtPARs.Rows.Count - 1]["NUM"].ToString()) != dtPARs.Rows.Count)
                            {
                                blStatus = false;
                                strErrMsg = "Some NUM-PARs are missing";
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsg = strErrMsg;
            return blStatus;
        }

        #endregion

        #region Table definition methods
               
        private DataTable GetKeywordsTableDefinition()
        {
            DataTable dtKeywords = new DataTable();

            DataColumn colKey = new DataColumn("TK_ID");
            colKey.DataType = System.Type.GetType("System.Int32");
            colKey.AutoIncrement = true;
            colKey.AutoIncrementSeed = 1;

            dtKeywords.Columns.Add(colKey);
            dtKeywords.Columns.Add("KEYWORD");
            dtKeywords.Columns.Add("KEY_LENGTH");
            dtKeywords.Columns.Add("KEY_WORD_CNT");
            return dtKeywords;
        }

        private DataTable GetKeysPreviewTableDefinition()
        {
            DataTable dtKeysPrev = new DataTable();
            dtKeysPrev.Columns.Add("KEY");
            dtKeysPrev.Columns.Add("KEY_LENGTH");
            dtKeysPrev.Columns.Add("WORD_COUNT");
            return dtKeysPrev;
        }

        #endregion

        #region Keys related methods

        private DataTable GetKeyPreviewDataFromTable(DataTable keysdata)
        {
            DataTable dtKeysPrev = null;
            try
            {
                //Each KEY limit is 150 characters including 'KEY:: ', so only 144 characters are allowed
                //KEY:: review schizophrenia pathology acetylcholine receptor acetylcholinesterase
                if (keysdata != null)
                {
                    if (keysdata.Rows.Count > 0)
                    {
                        List<string> lstPreviewKeys = GetKeyPreviewListFromTable(keysdata);
                        if (lstPreviewKeys != null)
                        {
                            if (lstPreviewKeys.Count > 0)
                            {
                                dtKeysPrev = GetKeysPreviewTableDefinition();

                                for (int i = 0; i < lstPreviewKeys.Count; i++)
                                {
                                    DataRow dtRow = dtKeysPrev.NewRow();
                                    dtRow["KEY"] = lstPreviewKeys[i];
                                    dtRow["KEY_LENGTH"] = lstPreviewKeys[i].Length.ToString();
                                    dtRow["WORD_COUNT"] = (lstPreviewKeys[i].Split().Length - 1).ToString();
                                    dtKeysPrev.Rows.Add(dtRow);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtKeysPrev;
        }

        private List<string> GetKeyPreviewListFromTable(DataTable _keysdata)
        {
            List<string> lstKeysPreview = null;
            try
            {
                //Each KEY limit is 150 characters including 'KEY:: ', so only 144 characters are allowed
                //KEY:: review schizophrenia pathology acetylcholine receptor acetylcholinesterase
                if (_keysdata != null)
                {
                    if (_keysdata.Rows.Count > 0)
                    {
                        lstKeysPreview = new List<string>();

                        string strPreviewKey = "";
                        string strTempKey = "";
                        string strKeyword = "";

                        //Each KEY limit is 150 characters including 'KEY:: ', so only 144 characters are allowed
                        //If Review TAN 150 - 13 ('KEY:: review ' lenght is 13) 
                        //int keyMaxLength = _isReviewTAN == true ? 137 : 144;
                        int keyMaxLength = 150;// _isReviewTAN == true ? 137 : 144;

                        for (int i = 0; i < _keysdata.Rows.Count; i++)
                        {
                            if (_keysdata.Rows[i]["KEYWORD"] != null)
                            {
                                strKeyword = !string.IsNullOrEmpty(_keysdata.Rows[i]["KEYWORD"].ToString()) ? _keysdata.Rows[i]["KEYWORD"].ToString().Trim() : "";

                                if (!string.IsNullOrEmpty(strKeyword))
                                {                                    
                                    strTempKey = string.IsNullOrEmpty(strTempKey) ? "KEY:: " + strKeyword : strTempKey + " " + strKeyword;                                   

                                    if ((strTempKey.Length <= keyMaxLength) && (strTempKey.Split().Length <= 10))
                                    {
                                        if (strPreviewKey.Length <= keyMaxLength)
                                        {
                                            strPreviewKey = strTempKey;
                                        }
                                        else
                                        {
                                            lstKeysPreview.Add(strPreviewKey);

                                            strPreviewKey = strTempKey;
                                        }
                                    }
                                    else
                                    {
                                        if (strPreviewKey.Length <= keyMaxLength)
                                        {
                                            lstKeysPreview.Add(strPreviewKey);
                                        }                                       

                                        //Reset Key to New value                                       
                                        strTempKey = "KEY:: " + _keysdata.Rows[i]["KEYWORD"].ToString();                                        

                                        //new code on 27th Aug 2013
                                        strPreviewKey = strTempKey;
                                    }
                                }
                            }
                        }
                        if (!string.IsNullOrEmpty(strTempKey))
                        {
                            if (strTempKey.Length <= keyMaxLength)
                            {
                                lstKeysPreview.Add(strTempKey);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstKeysPreview;
        }       

        #endregion

        #region Methods for Bind data to Controls/Grids

        private DataTable GetKeysTableFromString(string keywords)
        {
            DataTable dtKeys = null;
            try
            {
                if (!string.IsNullOrEmpty(keywords.Trim()))
                {
                    string[] saKeys = keywords.Trim().Split(new string[] { "``" }, StringSplitOptions.RemoveEmptyEntries);
                    if (saKeys != null)
                    {
                        if (saKeys.Length > 0)
                        {
                            dtKeys = GetKeywordsTableDefinition();

                            foreach (string key in saKeys)
                            {
                                DataRow dtRow = dtKeys.NewRow();
                                dtRow["KEYWORD"] = key.Trim();
                                dtRow["KEY_LENGTH"] = key.Trim().Length.ToString();
                                dtRow["KEY_WORD_CNT"] = key.Trim().Split().Length.ToString();;
                                dtKeys.Rows.Add(dtRow);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtKeys;
        }

        private void BindDataToNUM_PARGrid(DataTable numsData)
        {
            try
            {
                if (numsData != null)
                {
                    dgvNUM_PAR.AutoGenerateColumns = false;
                    dgvNUM_PAR.DataSource = numsData;

                    colArticleNUMID_NP.DataPropertyName = "TAN_NUM_ID";
                    colNUM_NP.DataPropertyName = "NUM";
                    colRegNo.DataPropertyName = "REG_NO";
                    colPAR.DataPropertyName = "PAR";
                    colRole_NP.DataPropertyName = "NUM_ROLE";
                    colStructureImage.DataPropertyName = "MOL_IMAGE";
                    colStructure.DataPropertyName = "MOL_FILE";
                    //colPolymerStructure.DataPropertyName = "IS_POLYMER";
                    colHMD_NP.DataPropertyName = "HMD";
                    //colTMD_Num.DataPropertyName = "NUM_TMD";
                    colNoStructure.DataPropertyName = "NO_STRUCT";
                    colNote.DataPropertyName = "NUM_NOTE";
                    colAMD.DataPropertyName = "AMD";
                    colDPT.DataPropertyName = "DPT_RS";
                    //colTradeNamePolymer_NP.DataPropertyName = "IS_TRADE_NAME_POLYMER";
                    //colIsCrossReferred.DataPropertyName = "IS_CROSS_REF";
                    //colCrossRefTo_NP.DataPropertyName = "CROSS_REF_POLYMER";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
                     
        int editNUM_NP = 0;
        int editNUM_NC = 0;
        private void BindGridRowDataToControls(DataGridViewRow gridRow, string rowType)
        {
            try
            {
                if (gridRow != null)
                {
                    if (gridRow.Cells.Count > 0)
                    {                        
                        if (rowType.ToUpper() == "NUM_PAR")
                        {
                            ResetNUMControls("NUM_PAR");

                            articleNUMID = gridRow.Cells["colArticleNUMID_NP"].Value != null ? Convert.ToInt32(gridRow.Cells["colArticleNUMID_NP"].Value) : 0;
                            nudNUMPAR.Value = gridRow.Cells["colNUM_NP"].Value != null ? Convert.ToInt32(gridRow.Cells["colNUM_NP"].Value) : 1;
                            editNUM_NP = (int)nudNUMPAR.Value;

                            txtRegistryNo.Text = gridRow.Cells["colRegNo"].Value != null ? gridRow.Cells["colRegNo"].Value.ToString() : "";
                            if (gridRow.Cells["colPAR"].Value != null)
                            {
                                uchrtbPAR_NP.BindDataToControl(gridRow.Cells["colPAR"].Value.ToString());                                
                            }
                            txtHMD_NP.Text = gridRow.Cells["colHMD_NP"].Value != null ? gridRow.Cells["colHMD_NP"].Value.ToString() : "";
                            txtAMD.Text = gridRow.Cells["colAMD"].Value != null ? gridRow.Cells["colAMD"].Value.ToString() : "";

                            if (gridRow.Cells["colTMD_Num"].Value != null)
                            {
                                uchrtbTMD_NP.BindDataToControl(gridRow.Cells["colTMD_Num"].Value.ToString());                                
                            }
                            txtRoleNP.Text = gridRow.Cells["colRole_NP"].Value != null ? gridRow.Cells["colRole_NP"].Value.ToString() : "";
                            txtNUMNote.Text = gridRow.Cells["colNote"].Value != null ? gridRow.Cells["colNote"].Value.ToString() : "";
                            if (gridRow.Cells["colDPT"].Value != null)
                            {
                                chkDPT_RS.Checked = gridRow.Cells["colDPT"].Value.ToString() == "Y" ? true : false;
                            }

                            if (gridRow.Cells["colNoStructure"].Value != null)
                            {
                                chkNoStructure.Checked = gridRow.Cells["colNoStructure"].Value.ToString() == "Y" ? true : false;
                            }

                            if (gridRow.Cells["colPolymerStructure"].Value != null)
                            {
                                chkIsPolymer.Checked = gridRow.Cells["colPolymerStructure"].Value.ToString() == "Y" ? true : false;
                            }

                            if (gridRow.Cells["colTradeNamePolymer_NP"].Value != null)
                            {
                                chkIsTradeNamePolymer_NP.Checked = gridRow.Cells["colTradeNamePolymer_NP"].Value.ToString() == "Y" ? true : false;
                            }

                            if (gridRow.Cells["colIsCrossReferred"].Value != null)
                            {
                                chkIsCrossRefTo.Checked = gridRow.Cells["colIsCrossReferred"].Value.ToString() == "Y" ? true : false;
                            }

                            txtCrossRefPolymer_NP.Text = gridRow.Cells["colCrossRefTo_NP"].Value != null ? gridRow.Cells["colCrossRefTo_NP"].Value.ToString() : "";

                            ChemRenditor.MolfileString = gridRow.Cells["colStructure"].Value != null ? gridRow.Cells["colStructure"].Value.ToString() : "";
                            if (gridRow.Cells["colStructureImage"].Value != null)
                            {
                                if (!string.IsNullOrEmpty(gridRow.Cells["colStructureImage"].Value.ToString()))
                                {
                                    pbStructureImage.Image = DataConversions.ByteArrayToImage((byte[])(gridRow.Cells["colStructureImage"].Value));
                                }
                            }
                        }                        
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        

        #endregion        
                    
        #region Button Click Events

        int editRowIndx_NP = 0;
        int articleNUMID = 0;
        private void btnSaveNUMPAR_Click(object sender, EventArgs e)
        {
            try
            {
                string strErrMsg = "";
                if (ValidateNUM_PARInformation(ref strErrMsg))
                {
                    IndexingNUMInfo numInfo = new IndexingNUMInfo();
                    numInfo.TAN_ID = TAN_ID;
                    numInfo.TAN_NUM_ID = articleNUMID;
                    numInfo.NUM = Convert.ToInt32(nudNUMPAR.Value.ToString());
                    numInfo.NUMType = "NUM_PAR";
                    numInfo.Option = articleNUMID == 0 ? "INSERT" : "UPDATE";
                    if (!string.IsNullOrEmpty(txtRegistryNo.Text.Trim()))
                    {
                        numInfo.Reg_No = Convert.ToInt32(txtRegistryNo.Text.Trim());
                    }
                    numInfo.PAR = uchrtbPAR_NP.GetHtmlStringFromControl();
                    numInfo.HMD = Validations.RemoveInVisibleCharsDblSpaces(txtHMD_NP.Text.Trim());
                    numInfo.AMD = Validations.RemoveInVisibleCharsDblSpaces(txtAMD.Text.Trim());
                    numInfo.NUM_TMD = uchrtbTMD_NP.GetHtmlStringFromControl();
                    numInfo.NUMRole = txtRoleNP.Text.Trim();
                    numInfo.DPT_RS = chkDPT_RS.Checked ? "Y" : "N";
                    numInfo.NoStructure = chkNoStructure.Checked ? "Y" : "N";
                    numInfo.PolymerStructure = chkIsPolymer.Checked ? "Y" : "N";
                    numInfo.IsTradeNamePolymer = chkIsTradeNamePolymer_NP.Checked ? "Y" : "N";
                    numInfo.IsCrossReferred = chkIsCrossRefTo.Checked ? "Y" : "N";
                    numInfo.IsFileReviewRequire = "N";
                    numInfo.CrossReferenceTo = Validations.RemoveInVisibleCharsDblSpaces(txtCrossRefPolymer_NP.Text.Trim());
                    numInfo.NUMNote = Validations.RemoveInVisibleCharsDblSpaces(txtNUMNote.Text.Trim());
                    if (!string.IsNullOrEmpty(ChemRenditor.MolfileString))
                    {
                        numInfo.StructureMolFile = ChemRenditor.MolfileString;
                        numInfo.StructureInchi = ChemistryOperations.GetStructureInchiKey(ChemRenditor.MolfileString);
                    }
                    numInfo.StructureImage = pbStructureImage.Image != null ? DataConversions.ImageToByteArray(pbStructureImage.Image) : null;
                    numInfo.URID = GlobalVariables.URID;

                    if (OrganicIndexingDB.UpdateIndexingNUMInfo(numInfo))
                    {
                        NUM_PAR_Data = OrganicIndexingDB.GetIndexingNUMsOnTANID(TAN_ID, "NUM_PAR");
                        articleNUMID = 0;

                        MessageBox.Show("NUM " + nudNUMPAR.Value.ToString() + " info saved successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);

                        ResetNUMControls("NUM_PAR");

                        //Bind NUMs info to PAR grid
                        BindDataToNUM_PARGrid(NUM_PAR_Data);
                    }
                    else
                    {
                        MessageBox.Show("Error in saving " + nudNUMPAR.Value.ToString() + " info", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show(strErrMsg.Trim(), GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void btnExportSDF_Click(object sender, EventArgs e)
        {
            try
            {
                if (TAN_ID > 0)
                {
                    //Article NUMs for SDF                   
                    if (NUM_PAR_Data != null)
                    {
                        if (NUM_PAR_Data.Rows.Count > 0)
                        {
                            using (FolderBrowserDialog fldBrow = new FolderBrowserDialog())
                            {
                                if (fldBrow.ShowDialog() == DialogResult.OK)
                                {
                                    string strOutFilePath = fldBrow.SelectedPath + "\\" + txtTAN.Text.Trim() + "_sdf.txt";
                                    List<int> lstTANs = new List<int>();
                                    lstTANs.Add(TAN_ID);

                                    if (ExportToSDF.ExportTANNUMsToSDF(lstTANs, strOutFilePath))
                                    {
                                        MessageBox.Show("Exported to SD file successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);

                                        //Open SDF file
                                        System.Diagnostics.Process.Start(strOutFilePath);
                                    }
                                    else
                                    {
                                        MessageBox.Show("Error in SD file export", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("No NUMs available for SD file export", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        MessageBox.Show("No NUMs available for SD file export", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void btnMolToImage_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(ChemRenditor.MolfileString))
                {
                    pbStructureImage.Image = ChemRenditor.Image;
                    ChemRenditor.MolfileString = null;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnCopyToImage_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(ChemRenditor.MolfileString))
                {
                    pbStructureImage.Image = ChemRenditor.Image;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnResetTAN_Click(object sender, EventArgs e)
        {
            try
            {
                txtTAN.Clear();
                txtTAN.Enabled = true;

                ResetNUMControls("NUM_PAR");

                dgvNUM_PAR.DataSource = null;
                NUM_PAR_Data = null;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnGetTAN_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtTAN.Text.Trim()))
                {
                    TAN = txtTAN.Text.Trim();
                    
                    //Check for TAN exist
                    DataTable dtTANDetails = ReactDB.GetTANDetailsOnTANID(TAN_ID);
                    if (dtTANDetails != null && dtTANDetails.Rows.Count > 0)
                    {
                        //TAN_ID = Convert.ToInt32(dtTANDetails.Rows[0]["TAN_ID"].ToString());

                        //Get Article NUMs
                        NUM_PAR_Data = OrganicIndexingDB.GetIndexingNUMsOnTANID(TAN_ID, "NUM_PAR");
                        if (NUM_PAR_Data != null)
                        {
                            txtTAN.Enabled = false;

                            //Bind NUMs info to PAR grid
                            BindDataToNUM_PARGrid(NUM_PAR_Data);
                        }
                    }
                    else
                    {
                        MessageBox.Show("TAN is not available", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        #region Reset Methods for NUM controls

        private void ResetNUMControls(string numType)
        {
            try
            {
                if (!string.IsNullOrEmpty(numType))
                {
                    if (numType.ToUpper() == "NUM_PAR")
                    {
                        editRowIndx_NP = 0;
                        editNUM_NP = 0;
                        articleNUMID = 0;

                        nudNUMPAR.Value = 1;
                        txtRegistryNo.Clear();
                        uchrtbPAR_NP.hrtbPara.Clear();
                        txtHMD_NP.Clear();
                        txtAMD.Clear();
                        uchrtbTMD_NP.hrtbPara.Clear();
                        txtRoleNP.Clear();
                        txtNUMNote.Clear();
                        chkDPT_RS.Checked = false;
                        chkNoStructure.Checked = false;
                        chkIsPolymer.Checked = false;
                        chkIsTradeNamePolymer_NP.Checked = false;
                        chkIsCrossRefTo.Checked = false;
                        txtCrossRefPolymer_NP.Clear();
                        ChemRenditor.MolfileString = null;
                        pbStructureImage.Image = null;

                        txtNUMNote.Enabled = true;
                    }                  
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnResetNUMPAR_Click(object sender, EventArgs e)
        {
            try
            {
                ResetNUMControls("NUM_PAR");
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnResetNUMCTH_Click(object sender, EventArgs e)
        {
            try
            {
                ResetNUMControls("NUM_CTH");
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion
           
        #region Grid Cell Content Click Events

        private void dgvNUM_PAR_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                {
                    if (dgvNUM_PAR.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString().ToUpper() == "EDIT")
                    {
                        editRowIndx_NP = e.RowIndex + 1;
                        BindGridRowDataToControls(dgvNUM_PAR.Rows[e.RowIndex], "NUM_PAR");
                    }
                    else if (dgvNUM_PAR.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString().ToUpper() == "DELETE")
                    {
                        int selNUM = Convert.ToInt32(dgvNUM_PAR.Rows[e.RowIndex].Cells["colNUM_NP"].Value.ToString());
                        int articleNUMID = Convert.ToInt32(dgvNUM_PAR.Rows[e.RowIndex].Cells["colArticleNUMID_NP"].Value.ToString());

                        DialogResult diaRes = MessageBox.Show("Do you want to delete the selected PAR?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (diaRes == DialogResult.Yes)
                        {
                            IndexingNUMInfo numInfo = new IndexingNUMInfo();
                            numInfo.TAN_ID = TAN_ID;
                            numInfo.TAN_NUM_ID = articleNUMID;
                            numInfo.Option = "DELETE";
                            if (OrganicIndexingDB.UpdateIndexingNUMInfo(numInfo))
                            {
                                MessageBox.Show("NUM-PAR Deleted successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);

                                //Refresh Article NUMs
                                NUM_PAR_Data = OrganicIndexingDB.GetIndexingNUMsOnTANID(TAN_ID, "NUM_PAR");
                                articleNUMID = 0;

                                //Reset control values
                                ResetNUMControls("NUM_PAR");

                                //Bind NUMs info to PAR grid
                                BindDataToNUM_PARGrid(NUM_PAR_Data);
                            }
                            else
                            {
                                MessageBox.Show("Error in PAR delete", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }  

        #endregion
               
        #region DataGridView Row Postpaint Events

        private void dgvNUM_PAR_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvNUM_PAR.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvNUM_PAR.Font);

                if (dgvNUM_PAR.RowHeadersWidth < (int)(size.Width + 20)) dgvNUM_PAR.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       
        
        #endregion      

        private void lnkRegNo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                frmNUMs objNUMs = new frmNUMs();
                objNUMs.SeriesType = "9000";

                if (objNUMs.ShowDialog() == DialogResult.OK)
                {
                    if (objNUMs.Sel_NUM > 0)
                    {
                        txtRegistryNo.Text = objNUMs.Sel_RegNo.ToString();
                        uchrtbPAR_NP.hrtbPara.Text = objNUMs.Sel_Name;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvNUM_PAR_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                {
                    BindGridRowDataToControls(dgvNUM_PAR.Rows[e.RowIndex], "NUM_PAR");

                    articleNUMID = 0;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
                                       
    }
}

