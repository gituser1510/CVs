﻿namespace IndxReactNarr
{
    partial class frmStructureIndexing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            MDL.Draw.Chemistry.Molecule molecule1 = new MDL.Draw.Chemistry.Molecule();
            MDL.Draw.Renderer.Preferences.DisplayPreferences displayPreferences1 = new MDL.Draw.Renderer.Preferences.DisplayPreferences();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.splContNUMPAR = new System.Windows.Forms.SplitContainer();
            this.splContNUM = new System.Windows.Forms.SplitContainer();
            this.pnlNUMPAR = new System.Windows.Forms.Panel();
            this.chkIsCrossRefTo = new System.Windows.Forms.CheckBox();
            this.txtCrossRefPolymer_NP = new System.Windows.Forms.TextBox();
            this.chkIsTradeNamePolymer_NP = new System.Windows.Forms.CheckBox();
            this.chkIsPolymer = new System.Windows.Forms.CheckBox();
            this.lblNumTMD = new System.Windows.Forms.Label();
            this.pnlButtons_NP = new System.Windows.Forms.Panel();
            this.btnSaveNUMPAR = new System.Windows.Forms.Button();
            this.btnResetNUMPAR = new System.Windows.Forms.Button();
            this.lblNotes = new System.Windows.Forms.Label();
            this.txtNUMNote = new System.Windows.Forms.TextBox();
            this.chkNoStructure = new System.Windows.Forms.CheckBox();
            this.lnkRoleNP = new System.Windows.Forms.LinkLabel();
            this.nudNUMPAR = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.txtRoleNP = new System.Windows.Forms.TextBox();
            this.txtRegistryNo = new System.Windows.Forms.TextBox();
            this.chkDPT_RS = new System.Windows.Forms.CheckBox();
            this.txtAMD = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtHMD_NP = new System.Windows.Forms.TextBox();
            this.dgvNUM_PAR = new System.Windows.Forms.DataGridView();
            this.splContStruct_Image = new System.Windows.Forms.SplitContainer();
            this.ChemRenditor = new MDL.Draw.Renditor.Renditor();
            this.label1 = new System.Windows.Forms.Label();
            this.pbStructureImage = new System.Windows.Forms.PictureBox();
            this.lblSDFHdr = new System.Windows.Forms.Label();
            this.pnlStructButtons = new System.Windows.Forms.Panel();
            this.btnCopyToImage = new System.Windows.Forms.Button();
            this.btnMolToImage = new System.Windows.Forms.Button();
            this.pnlTAN = new System.Windows.Forms.Panel();
            this.btnResetTAN = new System.Windows.Forms.Button();
            this.btnGetTAN = new System.Windows.Forms.Button();
            this.lblTAN = new System.Windows.Forms.Label();
            this.txtTAN = new System.Windows.Forms.TextBox();
            this.lnkRegNo = new System.Windows.Forms.LinkLabel();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn3 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn4 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn5 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewLinkColumn1 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn2 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.uchrtbTMD_NP = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.uchrtbPAR_NP = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.colArticleNUMID_NP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNUM_NP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRegNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPAR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colHMD_NP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAMD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRole_NP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTMD_Num = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDPT = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colNoStructure = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colPolymerStructure = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colTradeNamePolymer_NP = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colIsCrossReferred = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colCrossRefTo_NP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNote = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStructure = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStructureImage = new System.Windows.Forms.DataGridViewImageColumn();
            this.colEditNP = new System.Windows.Forms.DataGridViewLinkColumn();
            this.colDeleteNP = new System.Windows.Forms.DataGridViewLinkColumn();
            this.pnlMain.SuspendLayout();
            this.splContNUMPAR.Panel1.SuspendLayout();
            this.splContNUMPAR.Panel2.SuspendLayout();
            this.splContNUMPAR.SuspendLayout();
            this.splContNUM.Panel1.SuspendLayout();
            this.splContNUM.Panel2.SuspendLayout();
            this.splContNUM.SuspendLayout();
            this.pnlNUMPAR.SuspendLayout();
            this.pnlButtons_NP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudNUMPAR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNUM_PAR)).BeginInit();
            this.splContStruct_Image.Panel1.SuspendLayout();
            this.splContStruct_Image.Panel2.SuspendLayout();
            this.splContStruct_Image.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbStructureImage)).BeginInit();
            this.pnlStructButtons.SuspendLayout();
            this.pnlTAN.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.splContNUMPAR);
            this.pnlMain.Controls.Add(this.pnlTAN);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1246, 565);
            this.pnlMain.TabIndex = 0;
            // 
            // splContNUMPAR
            // 
            this.splContNUMPAR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContNUMPAR.Location = new System.Drawing.Point(0, 35);
            this.splContNUMPAR.Name = "splContNUMPAR";
            // 
            // splContNUMPAR.Panel1
            // 
            this.splContNUMPAR.Panel1.Controls.Add(this.splContNUM);
            // 
            // splContNUMPAR.Panel2
            // 
            this.splContNUMPAR.Panel2.Controls.Add(this.splContStruct_Image);
            this.splContNUMPAR.Panel2.Controls.Add(this.pnlStructButtons);
            this.splContNUMPAR.Size = new System.Drawing.Size(1246, 530);
            this.splContNUMPAR.SplitterDistance = 910;
            this.splContNUMPAR.SplitterWidth = 3;
            this.splContNUMPAR.TabIndex = 229;
            // 
            // splContNUM
            // 
            this.splContNUM.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splContNUM.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContNUM.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splContNUM.Location = new System.Drawing.Point(0, 0);
            this.splContNUM.Name = "splContNUM";
            this.splContNUM.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splContNUM.Panel1
            // 
            this.splContNUM.Panel1.Controls.Add(this.pnlNUMPAR);
            // 
            // splContNUM.Panel2
            // 
            this.splContNUM.Panel2.Controls.Add(this.dgvNUM_PAR);
            this.splContNUM.Size = new System.Drawing.Size(910, 530);
            this.splContNUM.SplitterDistance = 271;
            this.splContNUM.SplitterWidth = 3;
            this.splContNUM.TabIndex = 229;
            // 
            // pnlNUMPAR
            // 
            this.pnlNUMPAR.Controls.Add(this.lnkRegNo);
            this.pnlNUMPAR.Controls.Add(this.chkIsCrossRefTo);
            this.pnlNUMPAR.Controls.Add(this.txtCrossRefPolymer_NP);
            this.pnlNUMPAR.Controls.Add(this.chkIsTradeNamePolymer_NP);
            this.pnlNUMPAR.Controls.Add(this.chkIsPolymer);
            this.pnlNUMPAR.Controls.Add(this.uchrtbTMD_NP);
            this.pnlNUMPAR.Controls.Add(this.uchrtbPAR_NP);
            this.pnlNUMPAR.Controls.Add(this.lblNumTMD);
            this.pnlNUMPAR.Controls.Add(this.pnlButtons_NP);
            this.pnlNUMPAR.Controls.Add(this.lblNotes);
            this.pnlNUMPAR.Controls.Add(this.txtNUMNote);
            this.pnlNUMPAR.Controls.Add(this.chkNoStructure);
            this.pnlNUMPAR.Controls.Add(this.lnkRoleNP);
            this.pnlNUMPAR.Controls.Add(this.nudNUMPAR);
            this.pnlNUMPAR.Controls.Add(this.label9);
            this.pnlNUMPAR.Controls.Add(this.txtRoleNP);
            this.pnlNUMPAR.Controls.Add(this.txtRegistryNo);
            this.pnlNUMPAR.Controls.Add(this.chkDPT_RS);
            this.pnlNUMPAR.Controls.Add(this.txtAMD);
            this.pnlNUMPAR.Controls.Add(this.label11);
            this.pnlNUMPAR.Controls.Add(this.label13);
            this.pnlNUMPAR.Controls.Add(this.label12);
            this.pnlNUMPAR.Controls.Add(this.txtHMD_NP);
            this.pnlNUMPAR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlNUMPAR.Location = new System.Drawing.Point(0, 0);
            this.pnlNUMPAR.Name = "pnlNUMPAR";
            this.pnlNUMPAR.Size = new System.Drawing.Size(906, 267);
            this.pnlNUMPAR.TabIndex = 230;
            // 
            // chkIsCrossRefTo
            // 
            this.chkIsCrossRefTo.AutoSize = true;
            this.chkIsCrossRefTo.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIsCrossRefTo.Location = new System.Drawing.Point(222, 210);
            this.chkIsCrossRefTo.Name = "chkIsCrossRefTo";
            this.chkIsCrossRefTo.Size = new System.Drawing.Size(136, 19);
            this.chkIsCrossRefTo.TabIndex = 251;
            this.chkIsCrossRefTo.Text = "Cross Reference To";
            this.chkIsCrossRefTo.UseVisualStyleBackColor = true;
            // 
            // txtCrossRefPolymer_NP
            // 
            this.txtCrossRefPolymer_NP.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCrossRefPolymer_NP.Enabled = false;
            this.txtCrossRefPolymer_NP.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCrossRefPolymer_NP.ForeColor = System.Drawing.Color.Black;
            this.txtCrossRefPolymer_NP.Location = new System.Drawing.Point(359, 210);
            this.txtCrossRefPolymer_NP.Multiline = true;
            this.txtCrossRefPolymer_NP.Name = "txtCrossRefPolymer_NP";
            this.txtCrossRefPolymer_NP.Size = new System.Drawing.Size(542, 20);
            this.txtCrossRefPolymer_NP.TabIndex = 250;
            // 
            // chkIsTradeNamePolymer_NP
            // 
            this.chkIsTradeNamePolymer_NP.AutoSize = true;
            this.chkIsTradeNamePolymer_NP.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIsTradeNamePolymer_NP.Location = new System.Drawing.Point(48, 211);
            this.chkIsTradeNamePolymer_NP.Name = "chkIsTradeNamePolymer_NP";
            this.chkIsTradeNamePolymer_NP.Size = new System.Drawing.Size(143, 19);
            this.chkIsTradeNamePolymer_NP.TabIndex = 249;
            this.chkIsTradeNamePolymer_NP.Text = "Trade Name Polymer";
            this.chkIsTradeNamePolymer_NP.UseVisualStyleBackColor = true;
            // 
            // chkIsPolymer
            // 
            this.chkIsPolymer.AutoSize = true;
            this.chkIsPolymer.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIsPolymer.Location = new System.Drawing.Point(611, 6);
            this.chkIsPolymer.Name = "chkIsPolymer";
            this.chkIsPolymer.Size = new System.Drawing.Size(123, 19);
            this.chkIsPolymer.TabIndex = 243;
            this.chkIsPolymer.Text = "Polymer Structure";
            this.chkIsPolymer.UseVisualStyleBackColor = true;
            // 
            // lblNumTMD
            // 
            this.lblNumTMD.AutoSize = true;
            this.lblNumTMD.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumTMD.ForeColor = System.Drawing.Color.Black;
            this.lblNumTMD.Location = new System.Drawing.Point(7, 121);
            this.lblNumTMD.Name = "lblNumTMD";
            this.lblNumTMD.Size = new System.Drawing.Size(35, 16);
            this.lblNumTMD.TabIndex = 239;
            this.lblNumTMD.Text = "TMD";
            // 
            // pnlButtons_NP
            // 
            this.pnlButtons_NP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlButtons_NP.Controls.Add(this.btnSaveNUMPAR);
            this.pnlButtons_NP.Controls.Add(this.btnResetNUMPAR);
            this.pnlButtons_NP.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlButtons_NP.Location = new System.Drawing.Point(0, 233);
            this.pnlButtons_NP.Name = "pnlButtons_NP";
            this.pnlButtons_NP.Size = new System.Drawing.Size(906, 34);
            this.pnlButtons_NP.TabIndex = 232;
            // 
            // btnSaveNUMPAR
            // 
            this.btnSaveNUMPAR.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSaveNUMPAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaveNUMPAR.Location = new System.Drawing.Point(826, 2);
            this.btnSaveNUMPAR.Name = "btnSaveNUMPAR";
            this.btnSaveNUMPAR.Size = new System.Drawing.Size(75, 28);
            this.btnSaveNUMPAR.TabIndex = 25;
            this.btnSaveNUMPAR.Text = "Save";
            this.btnSaveNUMPAR.UseVisualStyleBackColor = true;
            this.btnSaveNUMPAR.Click += new System.EventHandler(this.btnSaveNUMPAR_Click);
            // 
            // btnResetNUMPAR
            // 
            this.btnResetNUMPAR.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnResetNUMPAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnResetNUMPAR.Location = new System.Drawing.Point(741, 2);
            this.btnResetNUMPAR.Name = "btnResetNUMPAR";
            this.btnResetNUMPAR.Size = new System.Drawing.Size(75, 28);
            this.btnResetNUMPAR.TabIndex = 26;
            this.btnResetNUMPAR.Text = "Reset";
            this.btnResetNUMPAR.UseVisualStyleBackColor = true;
            this.btnResetNUMPAR.Click += new System.EventHandler(this.btnResetNUMPAR_Click);
            // 
            // lblNotes
            // 
            this.lblNotes.AutoSize = true;
            this.lblNotes.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNotes.ForeColor = System.Drawing.Color.Black;
            this.lblNotes.Location = new System.Drawing.Point(7, 188);
            this.lblNotes.Name = "lblNotes";
            this.lblNotes.Size = new System.Drawing.Size(35, 16);
            this.lblNotes.TabIndex = 231;
            this.lblNotes.Text = "Note";
            // 
            // txtNUMNote
            // 
            this.txtNUMNote.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNUMNote.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNUMNote.ForeColor = System.Drawing.Color.Black;
            this.txtNUMNote.Location = new System.Drawing.Point(48, 186);
            this.txtNUMNote.Multiline = true;
            this.txtNUMNote.Name = "txtNUMNote";
            this.txtNUMNote.Size = new System.Drawing.Size(853, 20);
            this.txtNUMNote.TabIndex = 24;
            // 
            // chkNoStructure
            // 
            this.chkNoStructure.AutoSize = true;
            this.chkNoStructure.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkNoStructure.Location = new System.Drawing.Point(440, 7);
            this.chkNoStructure.Name = "chkNoStructure";
            this.chkNoStructure.Size = new System.Drawing.Size(145, 19);
            this.chkNoStructure.TabIndex = 19;
            this.chkNoStructure.Text = "No Structure Available";
            this.chkNoStructure.UseVisualStyleBackColor = true;
            // 
            // lnkRoleNP
            // 
            this.lnkRoleNP.AutoSize = true;
            this.lnkRoleNP.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkRoleNP.Location = new System.Drawing.Point(8, 164);
            this.lnkRoleNP.Name = "lnkRoleNP";
            this.lnkRoleNP.Size = new System.Drawing.Size(34, 16);
            this.lnkRoleNP.TabIndex = 23;
            this.lnkRoleNP.TabStop = true;
            this.lnkRoleNP.Text = "Role";
            this.lnkRoleNP.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkRoleNP_LinkClicked);
            // 
            // nudNUMPAR
            // 
            this.nudNUMPAR.Location = new System.Drawing.Point(49, 4);
            this.nudNUMPAR.Maximum = new decimal(new int[] {
            799,
            0,
            0,
            0});
            this.nudNUMPAR.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudNUMPAR.Name = "nudNUMPAR";
            this.nudNUMPAR.Size = new System.Drawing.Size(62, 22);
            this.nudNUMPAR.TabIndex = 16;
            this.nudNUMPAR.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(6, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(37, 16);
            this.label9.TabIndex = 204;
            this.label9.Text = "NUM";
            // 
            // txtRoleNP
            // 
            this.txtRoleNP.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRoleNP.BackColor = System.Drawing.Color.White;
            this.txtRoleNP.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRoleNP.ForeColor = System.Drawing.Color.Blue;
            this.txtRoleNP.Location = new System.Drawing.Point(48, 162);
            this.txtRoleNP.Multiline = true;
            this.txtRoleNP.Name = "txtRoleNP";
            this.txtRoleNP.ReadOnly = true;
            this.txtRoleNP.Size = new System.Drawing.Size(853, 20);
            this.txtRoleNP.TabIndex = 200;
            // 
            // txtRegistryNo
            // 
            this.txtRegistryNo.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRegistryNo.ForeColor = System.Drawing.Color.Black;
            this.txtRegistryNo.Location = new System.Drawing.Point(180, 5);
            this.txtRegistryNo.Name = "txtRegistryNo";
            this.txtRegistryNo.Size = new System.Drawing.Size(116, 21);
            this.txtRegistryNo.TabIndex = 17;
            // 
            // chkDPT_RS
            // 
            this.chkDPT_RS.AutoSize = true;
            this.chkDPT_RS.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDPT_RS.Location = new System.Drawing.Point(327, 7);
            this.chkDPT_RS.Name = "chkDPT_RS";
            this.chkDPT_RS.Size = new System.Drawing.Size(69, 19);
            this.chkDPT_RS.TabIndex = 18;
            this.chkDPT_RS.Text = "DPT:RS";
            this.chkDPT_RS.UseVisualStyleBackColor = true;
            // 
            // txtAMD
            // 
            this.txtAMD.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAMD.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAMD.ForeColor = System.Drawing.Color.Black;
            this.txtAMD.Location = new System.Drawing.Point(49, 96);
            this.txtAMD.Multiline = true;
            this.txtAMD.Name = "txtAMD";
            this.txtAMD.Size = new System.Drawing.Size(854, 20);
            this.txtAMD.TabIndex = 22;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(9, 32);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(34, 16);
            this.label11.TabIndex = 218;
            this.label11.Text = "PAR";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(6, 97);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(37, 16);
            this.label13.TabIndex = 222;
            this.label13.Text = "AMD";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(6, 73);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(37, 16);
            this.label12.TabIndex = 220;
            this.label12.Text = "HMD";
            // 
            // txtHMD_NP
            // 
            this.txtHMD_NP.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtHMD_NP.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHMD_NP.ForeColor = System.Drawing.Color.Black;
            this.txtHMD_NP.Location = new System.Drawing.Point(49, 72);
            this.txtHMD_NP.Multiline = true;
            this.txtHMD_NP.Name = "txtHMD_NP";
            this.txtHMD_NP.Size = new System.Drawing.Size(854, 20);
            this.txtHMD_NP.TabIndex = 21;
            // 
            // dgvNUM_PAR
            // 
            this.dgvNUM_PAR.AllowUserToAddRows = false;
            this.dgvNUM_PAR.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.dgvNUM_PAR.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvNUM_PAR.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvNUM_PAR.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNUM_PAR.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colArticleNUMID_NP,
            this.colNUM_NP,
            this.colRegNo,
            this.colPAR,
            this.colHMD_NP,
            this.colAMD,
            this.colRole_NP,
            this.colTMD_Num,
            this.colDPT,
            this.colNoStructure,
            this.colPolymerStructure,
            this.colTradeNamePolymer_NP,
            this.colIsCrossReferred,
            this.colCrossRefTo_NP,
            this.colNote,
            this.colStructure,
            this.colStructureImage,
            this.colEditNP,
            this.colDeleteNP});
            this.dgvNUM_PAR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvNUM_PAR.Location = new System.Drawing.Point(0, 0);
            this.dgvNUM_PAR.Name = "dgvNUM_PAR";
            this.dgvNUM_PAR.ReadOnly = true;
            this.dgvNUM_PAR.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvNUM_PAR.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvNUM_PAR.RowTemplate.Height = 30;
            this.dgvNUM_PAR.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvNUM_PAR.Size = new System.Drawing.Size(906, 252);
            this.dgvNUM_PAR.TabIndex = 226;
            this.dgvNUM_PAR.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNUM_PAR_CellContentClick);
            this.dgvNUM_PAR.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNUM_PAR_RowEnter);
            this.dgvNUM_PAR.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvNUM_PAR_RowPostPaint);
            // 
            // splContStruct_Image
            // 
            this.splContStruct_Image.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splContStruct_Image.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContStruct_Image.Location = new System.Drawing.Point(0, 33);
            this.splContStruct_Image.Name = "splContStruct_Image";
            this.splContStruct_Image.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splContStruct_Image.Panel1
            // 
            this.splContStruct_Image.Panel1.Controls.Add(this.ChemRenditor);
            this.splContStruct_Image.Panel1.Controls.Add(this.label1);
            // 
            // splContStruct_Image.Panel2
            // 
            this.splContStruct_Image.Panel2.Controls.Add(this.pbStructureImage);
            this.splContStruct_Image.Panel2.Controls.Add(this.lblSDFHdr);
            this.splContStruct_Image.Size = new System.Drawing.Size(333, 497);
            this.splContStruct_Image.SplitterDistance = 248;
            this.splContStruct_Image.TabIndex = 28;
            // 
            // ChemRenditor
            // 
            this.ChemRenditor.AutoSizeStructure = true;
            this.ChemRenditor.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.ChemRenditor.BinHexSketch = "010300044122001F4372656174656420627920416363656C7279734472617720342E312E312E34020" +
    "40000005805000000005905000000000B0B0005417269616C780000140200";
            this.ChemRenditor.ChimeString = null;
            this.ChemRenditor.ClearingEnabled = true;
            this.ChemRenditor.CopyingEnabled = true;
            this.ChemRenditor.DisplayOnEmpty = null;
            this.ChemRenditor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ChemRenditor.EditingEnabled = true;
            this.ChemRenditor.FileName = null;
            this.ChemRenditor.HighlightInfo = "";
            this.ChemRenditor.IsBitmapFromOLE = false;
            this.ChemRenditor.Location = new System.Drawing.Point(0, 24);
            molecule1.ArrowDir = MDL.Draw.ArrowDirType.No;
            molecule1.ArrowStyle = MDL.Draw.ArrowStyleType.Empty;
            molecule1.AtomValenceDisplay = true;
            molecule1.BaseFormBoxSetting = 0;
            molecule1.BondLineThickness = 0D;
            molecule1.CarbonLabelDisplay = false;
            molecule1.ChemLabelFont = null;
            molecule1.ChemLabelFontString = "(none)";
            molecule1.ColorAtomsByTypeInSketch = false;
            molecule1.ConfigLabelFont = null;
            molecule1.ConfigLabelFontString = "(none)";
            molecule1.ConvertRingBondIntoOneToMany = true;
            molecule1.Coords = null;
            molecule1.DashSpacing = 0.1D;
            molecule1.DisplaySinCys = false;
            molecule1.DisplaySulfurInCysSequence = false;
            molecule1.DoubleBondWidth = 0.18D;
            molecule1.FillColor = System.Drawing.Color.Empty;
            molecule1.FillStyle = MDL.Draw.ChemGraphicsObject.FillStyles.SOLID;
            molecule1.ForeColor = System.Drawing.Color.Empty;
            molecule1.ForeColorString = "";
            molecule1.ForSubsequenceQuery = false;
            molecule1.HighlightChildren = "";
            molecule1.HighlightColor = System.Drawing.Color.Blue;
            molecule1.HydrogenDisplayMode = MDL.Draw.Chemistry.Atom.HydrogenDisplayMode.Off;
            molecule1.Id = 926;
            molecule1.Initial = "";
            molecule1.IsAModel = false;
            molecule1.IsARotatedModel = false;
            molecule1.KeepRSLabelsInSketch = true;
            molecule1.LastModifyChemText = -1;
            molecule1.MaintainXMLChildOrderFlag = false;
            molecule1.MustPerceiveStereo = true;
            molecule1.PenColor = System.Drawing.Color.Empty;
            molecule1.PenStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            molecule1.PenStyleToken = 0;
            molecule1.PenWidth = ((byte)(0));
            molecule1.PenWidthUnit = MDL.Draw.ChemGraphicsObject.PenWidthUnits.Default;
            molecule1.RefId = 926;
            molecule1.Replaced = false;
            molecule1.RgroupCleeanUpNeeded = false;
            molecule1.RgroupLabelsPresentFlag = false;
            molecule1.RLabelAtAbsCenter = "R";
            molecule1.RLabelAtAndCenter = "R*";
            molecule1.RLabelAtOrCenter = "(R)";
            molecule1.ScaleLabelsToBondLength = false;
            molecule1.Selected = false;
            molecule1.SequenceDictionary = null;
            molecule1.SequenceNeedsRealign = false;
            molecule1.SequenceView = MDL.Draw.Chemistry.Molecule.SequenceViewEnum.None;
            molecule1.Size = 0;
            molecule1.SkcWritten = false;
            molecule1.SkNumber = ((short)(0));
            molecule1.SLabelAtAbsCenter = "S";
            molecule1.SLabelAtAndCenter = "S*";
            molecule1.SLabelAtOrCenter = "(S)";
            molecule1.StandardBondLength = 0D;
            molecule1.StereoChemistryMode = MDL.Draw.Chemistry.Molecule.StereoChemistryModeEnum.And;
            molecule1.TextBorder = 0.1D;
            molecule1.Transparent = false;
            molecule1.UndoableEditListener = null;
            molecule1.WedgeWidth = 0.1D;
            molecule1.ZLayer = -99095;
            this.ChemRenditor.Molecule = molecule1;
            this.ChemRenditor.MolfileString = "";
            this.ChemRenditor.Name = "ChemRenditor";
            this.ChemRenditor.OldScalingMode = MDL.Draw.Renderer.Preferences.StructureScalingMode.ScaleToFitBox;
            this.ChemRenditor.PastingEnabled = true;
            displayPreferences1.AtomAtomDisplayMode = MDL.Draw.Renderer.Preferences.AtomAtomMappingDisplayMode.On;
            this.ChemRenditor.Preferences = displayPreferences1;
            this.ChemRenditor.PreferencesFileName = "default.xml";
            this.ChemRenditor.RendererBorderStyle = System.Windows.Forms.ButtonBorderStyle.Inset;
            this.ChemRenditor.RenditorMolecule = molecule1;
            this.ChemRenditor.RenditorName = "Demo Renditor";
            this.ChemRenditor.Size = new System.Drawing.Size(331, 222);
            this.ChemRenditor.SketchString = "AQMABEEiAB9DcmVhdGVkIGJ5IEFjY2VscnlzRHJhdyA0LjEuMS40AgQAAABYBQAAAABZBQAAAAALCwAFQ" +
    "XJpYWx4AAAUAgA=";
            this.ChemRenditor.SmilesString = "";
            this.ChemRenditor.TabIndex = 25;
            this.ChemRenditor.URLEncodedMolfileString = "";
            this.ChemRenditor.UseLocalXMLConfig = false;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.Info;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(331, 24);
            this.label1.TabIndex = 26;
            this.label1.Text = "Structure";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbStructureImage
            // 
            this.pbStructureImage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbStructureImage.Location = new System.Drawing.Point(0, 24);
            this.pbStructureImage.Name = "pbStructureImage";
            this.pbStructureImage.Size = new System.Drawing.Size(331, 219);
            this.pbStructureImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbStructureImage.TabIndex = 0;
            this.pbStructureImage.TabStop = false;
            // 
            // lblSDFHdr
            // 
            this.lblSDFHdr.BackColor = System.Drawing.SystemColors.Info;
            this.lblSDFHdr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSDFHdr.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblSDFHdr.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSDFHdr.Location = new System.Drawing.Point(0, 0);
            this.lblSDFHdr.Name = "lblSDFHdr";
            this.lblSDFHdr.Size = new System.Drawing.Size(331, 24);
            this.lblSDFHdr.TabIndex = 1;
            this.lblSDFHdr.Text = "React Image";
            this.lblSDFHdr.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pnlStructButtons
            // 
            this.pnlStructButtons.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlStructButtons.Controls.Add(this.btnCopyToImage);
            this.pnlStructButtons.Controls.Add(this.btnMolToImage);
            this.pnlStructButtons.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlStructButtons.Location = new System.Drawing.Point(0, 0);
            this.pnlStructButtons.Name = "pnlStructButtons";
            this.pnlStructButtons.Size = new System.Drawing.Size(333, 33);
            this.pnlStructButtons.TabIndex = 27;
            // 
            // btnCopyToImage
            // 
            this.btnCopyToImage.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnCopyToImage.Location = new System.Drawing.Point(225, 0);
            this.btnCopyToImage.Name = "btnCopyToImage";
            this.btnCopyToImage.Size = new System.Drawing.Size(104, 29);
            this.btnCopyToImage.TabIndex = 27;
            this.btnCopyToImage.Text = "SDF Image";
            this.btnCopyToImage.UseVisualStyleBackColor = true;
            this.btnCopyToImage.Click += new System.EventHandler(this.btnCopyToImage_Click);
            // 
            // btnMolToImage
            // 
            this.btnMolToImage.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnMolToImage.Location = new System.Drawing.Point(0, 0);
            this.btnMolToImage.Name = "btnMolToImage";
            this.btnMolToImage.Size = new System.Drawing.Size(104, 29);
            this.btnMolToImage.TabIndex = 26;
            this.btnMolToImage.Text = "React Image";
            this.btnMolToImage.UseVisualStyleBackColor = true;
            this.btnMolToImage.Click += new System.EventHandler(this.btnMolToImage_Click);
            // 
            // pnlTAN
            // 
            this.pnlTAN.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pnlTAN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTAN.Controls.Add(this.btnResetTAN);
            this.pnlTAN.Controls.Add(this.btnGetTAN);
            this.pnlTAN.Controls.Add(this.lblTAN);
            this.pnlTAN.Controls.Add(this.txtTAN);
            this.pnlTAN.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTAN.Location = new System.Drawing.Point(0, 0);
            this.pnlTAN.Name = "pnlTAN";
            this.pnlTAN.Size = new System.Drawing.Size(1246, 35);
            this.pnlTAN.TabIndex = 230;
            // 
            // btnResetTAN
            // 
            this.btnResetTAN.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnResetTAN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnResetTAN.Location = new System.Drawing.Point(262, 3);
            this.btnResetTAN.Name = "btnResetTAN";
            this.btnResetTAN.Size = new System.Drawing.Size(75, 28);
            this.btnResetTAN.TabIndex = 236;
            this.btnResetTAN.Text = "Reset";
            this.btnResetTAN.UseVisualStyleBackColor = true;
            this.btnResetTAN.Click += new System.EventHandler(this.btnResetTAN_Click);
            // 
            // btnGetTAN
            // 
            this.btnGetTAN.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnGetTAN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGetTAN.Location = new System.Drawing.Point(171, 3);
            this.btnGetTAN.Name = "btnGetTAN";
            this.btnGetTAN.Size = new System.Drawing.Size(75, 28);
            this.btnGetTAN.TabIndex = 235;
            this.btnGetTAN.Text = "Get";
            this.btnGetTAN.UseVisualStyleBackColor = true;
            this.btnGetTAN.Click += new System.EventHandler(this.btnGetTAN_Click);
            // 
            // lblTAN
            // 
            this.lblTAN.AutoSize = true;
            this.lblTAN.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTAN.ForeColor = System.Drawing.Color.Black;
            this.lblTAN.Location = new System.Drawing.Point(11, 7);
            this.lblTAN.Name = "lblTAN";
            this.lblTAN.Size = new System.Drawing.Size(32, 16);
            this.lblTAN.TabIndex = 234;
            this.lblTAN.Text = "TAN";
            // 
            // txtTAN
            // 
            this.txtTAN.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTAN.ForeColor = System.Drawing.Color.Black;
            this.txtTAN.Location = new System.Drawing.Point(49, 5);
            this.txtTAN.Name = "txtTAN";
            this.txtTAN.Size = new System.Drawing.Size(116, 21);
            this.txtTAN.TabIndex = 233;
            // 
            // lnkRegNo
            // 
            this.lnkRegNo.AutoSize = true;
            this.lnkRegNo.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkRegNo.Location = new System.Drawing.Point(125, 7);
            this.lnkRegNo.Name = "lnkRegNo";
            this.lnkRegNo.Size = new System.Drawing.Size(51, 16);
            this.lnkRegNo.TabIndex = 252;
            this.lnkRegNo.TabStop = true;
            this.lnkRegNo.Text = "Reg.No";
            this.lnkRegNo.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkRegNo_LinkClicked);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "ArticleNUMID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn2.HeaderText = "NUM";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 50;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Reg.No";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn4.HeaderText = "PAR";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn5.HeaderText = "HMD";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "AMD";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn7.HeaderText = "Role";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "TMD";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewCheckBoxColumn1.FalseValue = "N";
            this.dataGridViewCheckBoxColumn1.HeaderText = "DPT:RS";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            this.dataGridViewCheckBoxColumn1.ReadOnly = true;
            this.dataGridViewCheckBoxColumn1.TrueValue = "Y";
            this.dataGridViewCheckBoxColumn1.Width = 55;
            // 
            // dataGridViewCheckBoxColumn2
            // 
            this.dataGridViewCheckBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewCheckBoxColumn2.FalseValue = "N";
            this.dataGridViewCheckBoxColumn2.HeaderText = "NoStructure";
            this.dataGridViewCheckBoxColumn2.Name = "dataGridViewCheckBoxColumn2";
            this.dataGridViewCheckBoxColumn2.ReadOnly = true;
            this.dataGridViewCheckBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewCheckBoxColumn2.TrueValue = "Y";
            this.dataGridViewCheckBoxColumn2.Width = 55;
            // 
            // dataGridViewCheckBoxColumn3
            // 
            this.dataGridViewCheckBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewCheckBoxColumn3.FalseValue = "N";
            this.dataGridViewCheckBoxColumn3.HeaderText = "IsPolymer";
            this.dataGridViewCheckBoxColumn3.Name = "dataGridViewCheckBoxColumn3";
            this.dataGridViewCheckBoxColumn3.ReadOnly = true;
            this.dataGridViewCheckBoxColumn3.TrueValue = "Y";
            this.dataGridViewCheckBoxColumn3.Width = 50;
            // 
            // dataGridViewCheckBoxColumn4
            // 
            this.dataGridViewCheckBoxColumn4.FalseValue = "N";
            this.dataGridViewCheckBoxColumn4.HeaderText = "TNP";
            this.dataGridViewCheckBoxColumn4.Name = "dataGridViewCheckBoxColumn4";
            this.dataGridViewCheckBoxColumn4.ReadOnly = true;
            this.dataGridViewCheckBoxColumn4.TrueValue = "Y";
            this.dataGridViewCheckBoxColumn4.Width = 40;
            // 
            // dataGridViewCheckBoxColumn5
            // 
            this.dataGridViewCheckBoxColumn5.FalseValue = "N";
            this.dataGridViewCheckBoxColumn5.HeaderText = "CR";
            this.dataGridViewCheckBoxColumn5.Name = "dataGridViewCheckBoxColumn5";
            this.dataGridViewCheckBoxColumn5.ReadOnly = true;
            this.dataGridViewCheckBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewCheckBoxColumn5.TrueValue = "Y";
            this.dataGridViewCheckBoxColumn5.Width = 40;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "CrossRefTo";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn10.HeaderText = "Note";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "Structure";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.HeaderText = "StructureImage";
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            this.dataGridViewImageColumn1.ReadOnly = true;
            this.dataGridViewImageColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewLinkColumn1
            // 
            this.dataGridViewLinkColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewLinkColumn1.HeaderText = "Edit";
            this.dataGridViewLinkColumn1.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn1.Name = "dataGridViewLinkColumn1";
            this.dataGridViewLinkColumn1.ReadOnly = true;
            this.dataGridViewLinkColumn1.Text = "Edit";
            this.dataGridViewLinkColumn1.UseColumnTextForLinkValue = true;
            this.dataGridViewLinkColumn1.Width = 60;
            // 
            // dataGridViewLinkColumn2
            // 
            this.dataGridViewLinkColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewLinkColumn2.HeaderText = "Delete";
            this.dataGridViewLinkColumn2.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn2.Name = "dataGridViewLinkColumn2";
            this.dataGridViewLinkColumn2.ReadOnly = true;
            this.dataGridViewLinkColumn2.Text = "Delete";
            this.dataGridViewLinkColumn2.UseColumnTextForLinkValue = true;
            this.dataGridViewLinkColumn2.Width = 60;
            // 
            // uchrtbTMD_NP
            // 
            this.uchrtbTMD_NP.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uchrtbTMD_NP.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.uchrtbTMD_NP.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uchrtbTMD_NP.Location = new System.Drawing.Point(49, 119);
            this.uchrtbTMD_NP.Name = "uchrtbTMD_NP";
            this.uchrtbTMD_NP.Size = new System.Drawing.Size(853, 40);
            this.uchrtbTMD_NP.TabIndex = 242;
            // 
            // uchrtbPAR_NP
            // 
            this.uchrtbPAR_NP.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uchrtbPAR_NP.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.uchrtbPAR_NP.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uchrtbPAR_NP.Location = new System.Drawing.Point(49, 29);
            this.uchrtbPAR_NP.Name = "uchrtbPAR_NP";
            this.uchrtbPAR_NP.Size = new System.Drawing.Size(855, 40);
            this.uchrtbPAR_NP.TabIndex = 241;
            // 
            // colArticleNUMID_NP
            // 
            this.colArticleNUMID_NP.HeaderText = "ArticleNUMID";
            this.colArticleNUMID_NP.Name = "colArticleNUMID_NP";
            this.colArticleNUMID_NP.ReadOnly = true;
            this.colArticleNUMID_NP.Visible = false;
            // 
            // colNUM_NP
            // 
            this.colNUM_NP.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colNUM_NP.HeaderText = "NUM";
            this.colNUM_NP.Name = "colNUM_NP";
            this.colNUM_NP.ReadOnly = true;
            this.colNUM_NP.Width = 50;
            // 
            // colRegNo
            // 
            this.colRegNo.HeaderText = "Reg.No";
            this.colRegNo.Name = "colRegNo";
            this.colRegNo.ReadOnly = true;
            // 
            // colPAR
            // 
            this.colPAR.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colPAR.HeaderText = "PAR";
            this.colPAR.Name = "colPAR";
            this.colPAR.ReadOnly = true;
            // 
            // colHMD_NP
            // 
            this.colHMD_NP.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colHMD_NP.HeaderText = "HMD";
            this.colHMD_NP.Name = "colHMD_NP";
            this.colHMD_NP.ReadOnly = true;
            // 
            // colAMD
            // 
            this.colAMD.HeaderText = "AMD";
            this.colAMD.Name = "colAMD";
            this.colAMD.ReadOnly = true;
            // 
            // colRole_NP
            // 
            this.colRole_NP.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colRole_NP.HeaderText = "Role";
            this.colRole_NP.Name = "colRole_NP";
            this.colRole_NP.ReadOnly = true;
            // 
            // colTMD_Num
            // 
            this.colTMD_Num.HeaderText = "TMD";
            this.colTMD_Num.Name = "colTMD_Num";
            this.colTMD_Num.ReadOnly = true;
            // 
            // colDPT
            // 
            this.colDPT.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colDPT.FalseValue = "N";
            this.colDPT.HeaderText = "DPT:RS";
            this.colDPT.Name = "colDPT";
            this.colDPT.ReadOnly = true;
            this.colDPT.TrueValue = "Y";
            this.colDPT.Width = 55;
            // 
            // colNoStructure
            // 
            this.colNoStructure.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colNoStructure.FalseValue = "N";
            this.colNoStructure.HeaderText = "NoStructure";
            this.colNoStructure.Name = "colNoStructure";
            this.colNoStructure.ReadOnly = true;
            this.colNoStructure.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colNoStructure.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colNoStructure.TrueValue = "Y";
            this.colNoStructure.Width = 55;
            // 
            // colPolymerStructure
            // 
            this.colPolymerStructure.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colPolymerStructure.FalseValue = "N";
            this.colPolymerStructure.HeaderText = "IsPolymer";
            this.colPolymerStructure.Name = "colPolymerStructure";
            this.colPolymerStructure.ReadOnly = true;
            this.colPolymerStructure.TrueValue = "Y";
            this.colPolymerStructure.Width = 50;
            // 
            // colTradeNamePolymer_NP
            // 
            this.colTradeNamePolymer_NP.FalseValue = "N";
            this.colTradeNamePolymer_NP.HeaderText = "TNP";
            this.colTradeNamePolymer_NP.Name = "colTradeNamePolymer_NP";
            this.colTradeNamePolymer_NP.ReadOnly = true;
            this.colTradeNamePolymer_NP.TrueValue = "Y";
            this.colTradeNamePolymer_NP.Width = 40;
            // 
            // colIsCrossReferred
            // 
            this.colIsCrossReferred.FalseValue = "N";
            this.colIsCrossReferred.HeaderText = "CR";
            this.colIsCrossReferred.Name = "colIsCrossReferred";
            this.colIsCrossReferred.ReadOnly = true;
            this.colIsCrossReferred.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colIsCrossReferred.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.colIsCrossReferred.TrueValue = "Y";
            this.colIsCrossReferred.Width = 40;
            // 
            // colCrossRefTo_NP
            // 
            this.colCrossRefTo_NP.HeaderText = "CrossRefTo";
            this.colCrossRefTo_NP.Name = "colCrossRefTo_NP";
            this.colCrossRefTo_NP.ReadOnly = true;
            // 
            // colNote
            // 
            this.colNote.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colNote.HeaderText = "Note";
            this.colNote.Name = "colNote";
            this.colNote.ReadOnly = true;
            // 
            // colStructure
            // 
            this.colStructure.HeaderText = "Structure";
            this.colStructure.Name = "colStructure";
            this.colStructure.ReadOnly = true;
            // 
            // colStructureImage
            // 
            this.colStructureImage.HeaderText = "StructureImage";
            this.colStructureImage.Name = "colStructureImage";
            this.colStructureImage.ReadOnly = true;
            this.colStructureImage.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colEditNP
            // 
            this.colEditNP.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colEditNP.HeaderText = "Edit";
            this.colEditNP.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.colEditNP.Name = "colEditNP";
            this.colEditNP.ReadOnly = true;
            this.colEditNP.Text = "Edit";
            this.colEditNP.UseColumnTextForLinkValue = true;
            this.colEditNP.Width = 60;
            // 
            // colDeleteNP
            // 
            this.colDeleteNP.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colDeleteNP.HeaderText = "Delete";
            this.colDeleteNP.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.colDeleteNP.Name = "colDeleteNP";
            this.colDeleteNP.ReadOnly = true;
            this.colDeleteNP.Text = "Delete";
            this.colDeleteNP.UseColumnTextForLinkValue = true;
            this.colDeleteNP.Width = 60;
            // 
            // frmStructureIndexing
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1246, 565);
            this.Controls.Add(this.pnlMain);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmStructureIndexing";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Structure Indexing";
            this.Load += new System.EventHandler(this.frmStructureIndexing_Load);
            this.pnlMain.ResumeLayout(false);
            this.splContNUMPAR.Panel1.ResumeLayout(false);
            this.splContNUMPAR.Panel2.ResumeLayout(false);
            this.splContNUMPAR.ResumeLayout(false);
            this.splContNUM.Panel1.ResumeLayout(false);
            this.splContNUM.Panel2.ResumeLayout(false);
            this.splContNUM.ResumeLayout(false);
            this.pnlNUMPAR.ResumeLayout(false);
            this.pnlNUMPAR.PerformLayout();
            this.pnlButtons_NP.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nudNUMPAR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNUM_PAR)).EndInit();
            this.splContStruct_Image.Panel1.ResumeLayout(false);
            this.splContStruct_Image.Panel2.ResumeLayout(false);
            this.splContStruct_Image.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbStructureImage)).EndInit();
            this.pnlStructButtons.ResumeLayout(false);
            this.pnlTAN.ResumeLayout(false);
            this.pnlTAN.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.SplitContainer splContNUMPAR;
        private System.Windows.Forms.SplitContainer splContNUM;
        private System.Windows.Forms.Panel pnlNUMPAR;
        private System.Windows.Forms.Panel pnlButtons_NP;
        private System.Windows.Forms.Button btnSaveNUMPAR;
        private System.Windows.Forms.Button btnResetNUMPAR;
        private System.Windows.Forms.Label lblNotes;
        private System.Windows.Forms.TextBox txtNUMNote;
        private System.Windows.Forms.CheckBox chkNoStructure;
        private System.Windows.Forms.LinkLabel lnkRoleNP;
        private System.Windows.Forms.NumericUpDown nudNUMPAR;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtRoleNP;
        private System.Windows.Forms.TextBox txtRegistryNo;
        private System.Windows.Forms.CheckBox chkDPT_RS;
        private System.Windows.Forms.TextBox txtAMD;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtHMD_NP;
        private System.Windows.Forms.SplitContainer splContStruct_Image;
        private MDL.Draw.Renditor.Renditor ChemRenditor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pbStructureImage;
        private System.Windows.Forms.Label lblSDFHdr;
        private System.Windows.Forms.Panel pnlStructButtons;
        private System.Windows.Forms.Button btnCopyToImage;
        private System.Windows.Forms.Button btnMolToImage;
        private System.Windows.Forms.Label lblTAN;
        private System.Windows.Forms.TextBox txtTAN;
        private System.Windows.Forms.Panel pnlTAN;
        private System.Windows.Forms.Button btnResetTAN;
        private System.Windows.Forms.Button btnGetTAN;
        private System.Windows.Forms.Label lblNumTMD;
        private UserControls.ucHtmlRichText uchrtbPAR_NP;
        private UserControls.ucHtmlRichText uchrtbTMD_NP;
        private System.Windows.Forms.CheckBox chkIsPolymer;
        private System.Windows.Forms.CheckBox chkIsCrossRefTo;
        private System.Windows.Forms.TextBox txtCrossRefPolymer_NP;
        private System.Windows.Forms.CheckBox chkIsTradeNamePolymer_NP;
        private System.Windows.Forms.DataGridView dgvNUM_PAR;
        private System.Windows.Forms.DataGridViewTextBoxColumn colArticleNUMID_NP;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNUM_NP;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRegNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPAR;
        private System.Windows.Forms.DataGridViewTextBoxColumn colHMD_NP;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAMD;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRole_NP;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTMD_Num;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colDPT;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colNoStructure;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colPolymerStructure;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colTradeNamePolymer_NP;
        private System.Windows.Forms.DataGridViewCheckBoxColumn colIsCrossReferred;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCrossRefTo_NP;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNote;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStructure;
        private System.Windows.Forms.DataGridViewImageColumn colStructureImage;
        private System.Windows.Forms.DataGridViewLinkColumn colEditNP;
        private System.Windows.Forms.DataGridViewLinkColumn colDeleteNP;
        private System.Windows.Forms.LinkLabel lnkRegNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn2;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn3;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn4;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.DataGridViewLinkColumn dataGridViewLinkColumn1;
        private System.Windows.Forms.DataGridViewLinkColumn dataGridViewLinkColumn2;
    }
}