﻿namespace IndxReactNarr.Curation.ExperimentalProcedures
{
    partial class frmReviewRxnFindings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvTANFindings = new System.Windows.Forms.DataGridView();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.btnFindReplace = new System.Windows.Forms.Button();
            this.pnlSelection = new System.Windows.Forms.Panel();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnGet = new System.Windows.Forms.Button();
            this.chklstRxns = new System.Windows.Forms.CheckedListBox();
            this.lblSecondaryReactions = new System.Windows.Forms.Label();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewRichTextBoxColumn1 = new DataGridViewRichTextBox.DataGridViewRichTextBoxColumn();
            this.colRxnID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRF_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNarID = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colRxnNUM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnSeq = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFindingType = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colRefCompound = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFindingValueHtml = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFindingValue = new DataGridViewRichTextBox.DataGridViewRichTextBoxColumn();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTANFindings)).BeginInit();
            this.pnlBottom.SuspendLayout();
            this.pnlSelection.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.dgvTANFindings);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Controls.Add(this.pnlSelection);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1188, 522);
            this.pnlMain.TabIndex = 0;
            // 
            // dgvTANFindings
            // 
            this.dgvTANFindings.AllowUserToAddRows = false;
            this.dgvTANFindings.AllowUserToDeleteRows = false;
            this.dgvTANFindings.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvTANFindings.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvTANFindings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTANFindings.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colRxnID,
            this.colRF_ID,
            this.colNarID,
            this.colRxnNUM,
            this.colRxnSeq,
            this.colFindingType,
            this.colRefCompound,
            this.colFindingValueHtml,
            this.colFindingValue});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTANFindings.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvTANFindings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTANFindings.Location = new System.Drawing.Point(0, 92);
            this.dgvTANFindings.Name = "dgvTANFindings";
            this.dgvTANFindings.ReadOnly = true;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTANFindings.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvTANFindings.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTANFindings.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTANFindings.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvTANFindings.Size = new System.Drawing.Size(1188, 399);
            this.dgvTANFindings.TabIndex = 2;
            this.dgvTANFindings.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgvTANFindings_DataBindingComplete);
            this.dgvTANFindings.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvTANFindings_EditingControlShowing);
            this.dgvTANFindings.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvTANFindings_RowPostPaint);
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom.Controls.Add(this.btnFindReplace);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 491);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(1188, 31);
            this.pnlBottom.TabIndex = 3;
            // 
            // btnFindReplace
            // 
            this.btnFindReplace.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnFindReplace.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFindReplace.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFindReplace.Location = new System.Drawing.Point(2, 3);
            this.btnFindReplace.Name = "btnFindReplace";
            this.btnFindReplace.Size = new System.Drawing.Size(94, 24);
            this.btnFindReplace.TabIndex = 67;
            this.btnFindReplace.TabStop = false;
            this.btnFindReplace.Text = "Find / Replace";
            this.btnFindReplace.UseVisualStyleBackColor = true;
            this.btnFindReplace.Visible = false;
            // 
            // pnlSelection
            // 
            this.pnlSelection.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlSelection.Controls.Add(this.btnReset);
            this.pnlSelection.Controls.Add(this.btnGet);
            this.pnlSelection.Controls.Add(this.chklstRxns);
            this.pnlSelection.Controls.Add(this.lblSecondaryReactions);
            this.pnlSelection.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSelection.Location = new System.Drawing.Point(0, 0);
            this.pnlSelection.Name = "pnlSelection";
            this.pnlSelection.Size = new System.Drawing.Size(1188, 92);
            this.pnlSelection.TabIndex = 1;
            // 
            // btnReset
            // 
            this.btnReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReset.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(1106, 59);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 25);
            this.btnReset.TabIndex = 64;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnGet
            // 
            this.btnGet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGet.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGet.Location = new System.Drawing.Point(1106, 3);
            this.btnGet.Name = "btnGet";
            this.btnGet.Size = new System.Drawing.Size(75, 25);
            this.btnGet.TabIndex = 63;
            this.btnGet.Text = "Get";
            this.btnGet.UseVisualStyleBackColor = true;
            this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
            // 
            // chklstRxns
            // 
            this.chklstRxns.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chklstRxns.CheckOnClick = true;
            this.chklstRxns.ColumnWidth = 200;
            this.chklstRxns.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chklstRxns.FormattingEnabled = true;
            this.chklstRxns.Location = new System.Drawing.Point(104, 3);
            this.chklstRxns.MultiColumn = true;
            this.chklstRxns.Name = "chklstRxns";
            this.chklstRxns.ScrollAlwaysVisible = true;
            this.chklstRxns.Size = new System.Drawing.Size(996, 84);
            this.chklstRxns.TabIndex = 62;
            this.chklstRxns.Tag = "";
            this.chklstRxns.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chklstRxns_ItemCheck);
            // 
            // lblSecondaryReactions
            // 
            this.lblSecondaryReactions.AutoSize = true;
            this.lblSecondaryReactions.BackColor = System.Drawing.Color.White;
            this.lblSecondaryReactions.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecondaryReactions.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblSecondaryReactions.Location = new System.Drawing.Point(1, 6);
            this.lblSecondaryReactions.Name = "lblSecondaryReactions";
            this.lblSecondaryReactions.Size = new System.Drawing.Size(100, 15);
            this.lblSecondaryReactions.TabIndex = 60;
            this.lblSecondaryReactions.Text = "Select Reactions";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "RXN_ID";
            this.dataGridViewTextBoxColumn1.HeaderText = "RxnID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "RF_ID";
            this.dataGridViewTextBoxColumn2.HeaderText = "RF_ID";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Visible = false;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "RXN_NUM";
            this.dataGridViewTextBoxColumn3.HeaderText = "Rxn";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "RXN_SEQ";
            this.dataGridViewTextBoxColumn4.HeaderText = "RxnSeq";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "FINDING_TYPE";
            this.dataGridViewTextBoxColumn5.HeaderText = "FindingType";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn5.Width = 140;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "REFERENCE_SUBSTANCE";
            this.dataGridViewTextBoxColumn6.HeaderText = "Ref.Comp";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn6.Width = 80;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "FINDING_VALUE";
            this.dataGridViewTextBoxColumn7.HeaderText = "FindingValueHtml";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Visible = false;
            // 
            // dataGridViewRichTextBoxColumn1
            // 
            this.dataGridViewRichTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewRichTextBoxColumn1.DataPropertyName = "FINDING_VALUE_RTF";
            this.dataGridViewRichTextBoxColumn1.HeaderText = "Value";
            this.dataGridViewRichTextBoxColumn1.Name = "dataGridViewRichTextBoxColumn1";
            this.dataGridViewRichTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colRxnID
            // 
            this.colRxnID.DataPropertyName = "RXN_ID";
            this.colRxnID.HeaderText = "RxnID";
            this.colRxnID.Name = "colRxnID";
            this.colRxnID.ReadOnly = true;
            this.colRxnID.Visible = false;
            // 
            // colRF_ID
            // 
            this.colRF_ID.DataPropertyName = "RF_ID";
            this.colRF_ID.HeaderText = "RF_ID";
            this.colRF_ID.Name = "colRF_ID";
            this.colRF_ID.ReadOnly = true;
            this.colRF_ID.Visible = false;
            // 
            // colNarID
            // 
            this.colNarID.DataPropertyName = "RXN_NAR_ID";
            this.colNarID.HeaderText = "NarID";
            this.colNarID.Name = "colNarID";
            this.colNarID.ReadOnly = true;
            this.colNarID.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colRxnNUM
            // 
            this.colRxnNUM.DataPropertyName = "RXN_NUM";
            this.colRxnNUM.HeaderText = "Rxn";
            this.colRxnNUM.Name = "colRxnNUM";
            this.colRxnNUM.ReadOnly = true;
            this.colRxnNUM.Width = 60;
            // 
            // colRxnSeq
            // 
            this.colRxnSeq.DataPropertyName = "RXN_SEQ";
            this.colRxnSeq.HeaderText = "RxnSeq";
            this.colRxnSeq.Name = "colRxnSeq";
            this.colRxnSeq.ReadOnly = true;
            this.colRxnSeq.Width = 60;
            // 
            // colFindingType
            // 
            this.colFindingType.DataPropertyName = "FINDING_TYPE";
            this.colFindingType.HeaderText = "FindingType";
            this.colFindingType.Name = "colFindingType";
            this.colFindingType.ReadOnly = true;
            this.colFindingType.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colFindingType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colFindingType.Width = 140;
            // 
            // colRefCompound
            // 
            this.colRefCompound.DataPropertyName = "REFERENCE_SUBSTANCE";
            this.colRefCompound.HeaderText = "Ref.Comp";
            this.colRefCompound.Name = "colRefCompound";
            this.colRefCompound.ReadOnly = true;
            this.colRefCompound.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colRefCompound.Width = 80;
            // 
            // colFindingValueHtml
            // 
            this.colFindingValueHtml.DataPropertyName = "FINDING_VALUE";
            this.colFindingValueHtml.HeaderText = "FindingValueHtml";
            this.colFindingValueHtml.Name = "colFindingValueHtml";
            this.colFindingValueHtml.ReadOnly = true;
            this.colFindingValueHtml.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colFindingValueHtml.Visible = false;
            // 
            // colFindingValue
            // 
            this.colFindingValue.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colFindingValue.DataPropertyName = "FINDING_VALUE_RTF";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.colFindingValue.DefaultCellStyle = dataGridViewCellStyle1;
            this.colFindingValue.HeaderText = "Value";
            this.colFindingValue.Name = "colFindingValue";
            this.colFindingValue.ReadOnly = true;
            this.colFindingValue.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colFindingValue.Width = 625;
            // 
            // frmReviewRxnFindings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1188, 522);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmReviewRxnFindings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Review Reaction Findings";
            this.Load += new System.EventHandler(this.frmReviewRxnFindings_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTANFindings)).EndInit();
            this.pnlBottom.ResumeLayout(false);
            this.pnlSelection.ResumeLayout(false);
            this.pnlSelection.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlSelection;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnGet;
        private System.Windows.Forms.CheckedListBox chklstRxns;
        private System.Windows.Forms.Label lblSecondaryReactions;
        private System.Windows.Forms.DataGridView dgvTANFindings;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private DataGridViewRichTextBox.DataGridViewRichTextBoxColumn dataGridViewRichTextBoxColumn1;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Button btnFindReplace;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRF_ID;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colNarID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnNUM;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnSeq;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colFindingType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRefCompound;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFindingValueHtml;
        private DataGridViewRichTextBox.DataGridViewRichTextBoxColumn colFindingValue;
    }
}