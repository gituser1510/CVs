﻿namespace IndxReactNarr.Curation.ExperimentalProcedures
{
    partial class frmFindingsMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvFindingsMaster = new System.Windows.Forms.DataGridView();
            this.lblFinignsLbl = new System.Windows.Forms.Label();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFindingTypeName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFindingTypeDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFindingsMaster)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.dgvFindingsMaster);
            this.pnlMain.Controls.Add(this.lblFinignsLbl);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(570, 358);
            this.pnlMain.TabIndex = 0;
            // 
            // dgvFindingsMaster
            // 
            this.dgvFindingsMaster.AllowUserToAddRows = false;
            this.dgvFindingsMaster.AllowUserToDeleteRows = false;
            this.dgvFindingsMaster.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvFindingsMaster.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvFindingsMaster.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFindingsMaster.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colFindingTypeName,
            this.colFindingTypeDesc});
            this.dgvFindingsMaster.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvFindingsMaster.Location = new System.Drawing.Point(0, 29);
            this.dgvFindingsMaster.Name = "dgvFindingsMaster";
            this.dgvFindingsMaster.ReadOnly = true;
            this.dgvFindingsMaster.Size = new System.Drawing.Size(570, 329);
            this.dgvFindingsMaster.TabIndex = 1;
            this.dgvFindingsMaster.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvFindingsMaster_RowPostPaint);
            // 
            // lblFinignsLbl
            // 
            this.lblFinignsLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFinignsLbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblFinignsLbl.Location = new System.Drawing.Point(0, 0);
            this.lblFinignsLbl.Name = "lblFinignsLbl";
            this.lblFinignsLbl.Size = new System.Drawing.Size(570, 29);
            this.lblFinignsLbl.TabIndex = 0;
            this.lblFinignsLbl.Text = "Finding Types";
            this.lblFinignsLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "FINDING_TYPE_NAME";
            this.dataGridViewTextBoxColumn1.HeaderText = "FindingType";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 262;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "FINDING_TYPE_DESC";
            this.dataGridViewTextBoxColumn2.HeaderText = "Description";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 262;
            // 
            // colFindingTypeName
            // 
            this.colFindingTypeName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colFindingTypeName.DataPropertyName = "FINDING_TYPE_NAME";
            this.colFindingTypeName.HeaderText = "FindingType";
            this.colFindingTypeName.Name = "colFindingTypeName";
            this.colFindingTypeName.ReadOnly = true;
            this.colFindingTypeName.Width = 170;
            // 
            // colFindingTypeDesc
            // 
            this.colFindingTypeDesc.DataPropertyName = "FINDING_TYPE_DESC";
            this.colFindingTypeDesc.HeaderText = "Description";
            this.colFindingTypeDesc.Name = "colFindingTypeDesc";
            this.colFindingTypeDesc.ReadOnly = true;
            // 
            // frmFindingsMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(570, 358);
            this.Controls.Add(this.pnlMain);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmFindingsMaster";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Finding Types";
            this.Load += new System.EventHandler(this.frmFindingsMaster_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvFindingsMaster)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Label lblFinignsLbl;
        private System.Windows.Forms.DataGridView dgvFindingsMaster;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFindingTypeName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFindingTypeDesc;
    }
}