﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarrDAL;
using IndxReactNarr.Generic;
using IndxReactNarrBll;

namespace IndxReactNarr.Curation.ExperimentalProcedures
{
    public partial class frmReviewShipmentTansPageLabel : Form
    {
        public frmReviewShipmentTansPageLabel()
        {
            InitializeComponent();
        }

        public DataTable TANsPageInfo { get; set; }
        public DataTable BatchTANs { get; set; }
        List<string> lstTans = null;
        List<int> lstTanIDs = null;

        private void frmReviewTanRxnFindings_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;
                txtShipmentName.Focus();

                //Get Shipment Names and Set Autofill
                GetShipmentNamesAndSetToUserNameTxtBox_AutoComplete();               
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetShipmentNamesAndSetToUserNameTxtBox_AutoComplete()
        {
            try
            {
                DataTable dtTanTypes = null;
                DataTable dtShipments = null;
                using (dtShipments = ReactDB.GetShipmentDetailsByAppName(GlobalVariables.ApplicationName, out dtTanTypes))//EXPPROCEDURES
                {
                    if (dtShipments != null && dtShipments.Rows.Count > 0)
                    {
                        AutoCompleteStringCollection shipmentColl = new AutoCompleteStringCollection();

                        for (int i = 0; i < dtShipments.Rows.Count; i++)
                        {
                            if (dtShipments.Rows[i][0] != null)
                            {
                                shipmentColl.Add(dtShipments.Rows[i]["SHIPMENT_NAME"].ToString());
                            }
                        }

                        txtShipmentName.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                        txtShipmentName.AutoCompleteSource = AutoCompleteSource.CustomSource;
                        txtShipmentName.AutoCompleteCustomSource = shipmentColl;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnGetList_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;

                if (!string.IsNullOrEmpty(txtShipmentName.Text.Trim()))
                {
                    ClearControlValues();

                    int intBNo = 0;
                    int.TryParse(txtBNo.Text.Trim(), out intBNo);

                    DataTable dtBatchTANS = ShipmentMasterDB.GetTANsForExportOnApp_Shipment(GlobalVariables.ApplicationName, txtShipmentName.Text.Trim(), intBNo);
                    if (dtBatchTANS != null)
                    {
                        BatchTANs = dtBatchTANS;
                        txtTANSrch.Text = "";
                        BindTANsToCheckBoxlistBox(dtBatchTANS);
                    }
                }

                Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void ClearControlValues()
        {
            try
            {
                TANsPageInfo = null;
                dgvRxnsPageInfo.DataSource = null;
                chklstTANs.DataSource = null;               
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindTANsToCheckBoxlistBox(DataTable dtBatchTANS)
        {
            try
            {
                lstTans = dtBatchTANS.Rows.Cast<DataRow>().Select(row => row["TAN_NAME"].ToString()).ToList();
                BindListToCheckListBox(lstTans);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindListToCheckListBox(List<string> lstTans)
        {
            try
            {
                chklstTANs.Items.Clear();
                chklstTANs.Items.Add("Select All");
                foreach (string Tan in lstTans)
                {
                    chklstTANs.Items.Add(Tan);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtTANSrch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (BatchTANs != null)
                {
                    if (!string.IsNullOrEmpty(txtTANSrch.Text.Trim()))
                    {
                        string strFCond = GetFilterCondition(txtTANSrch.Text.Trim());

                        DataTable dtAllTANs = BatchTANs.Copy();
                        DataView dvTemp = dtAllTANs.DefaultView;
                        dvTemp.RowFilter = strFCond;
                        DataTable dtTANs = dvTemp.ToTable();
                        BindTANsToCheckBoxlistBox(dtTANs);
                    }
                    else
                    {
                        DataTable dtAllTANs = BatchTANs.Copy();
                        BindTANsToCheckBoxlistBox(dtAllTANs);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetFilterCondition(string _query_tan)
        {
            string strFCond = "";
            try
            {
                if (_query_tan.Trim().Contains(";"))
                {
                    string[] splitter = { ";" };
                    string[] strArrTans = _query_tan.Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);

                    if (strArrTans != null)
                    {
                        if (strArrTans.Length > 0)
                        {
                            for (int i = 0; i < strArrTans.Length; i++)
                            {
                                if (i == 0)
                                {
                                    strFCond = "TAN_NAME Like '" + strArrTans[i] + "%' ";
                                }
                                else
                                {
                                    strFCond += " OR" + " TAN_NAME Like '" + strArrTans[i] + "%'";
                                }
                            }
                        }
                    }
                }
                else
                {
                    strFCond = "TAN_NAME Like '" + _query_tan.Trim() + "%'";
                }
                return strFCond;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strFCond;
        }

        private void chklstRxns_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            try
            {
                if (e.Index == 0 && e.NewValue == CheckState.Checked)
                {
                    SelectAllItems();

                }

                if (e.Index == 0 && e.NewValue == CheckState.Unchecked)
                {
                    DeSelectAllItems();

                }

                if (e.Index != 0 && e.NewValue == CheckState.Unchecked)
                {
                    chklstTANs.BeginUpdate();
                    chklstTANs.ItemCheck -= chklstRxns_ItemCheck;
                    chklstTANs.SetItemChecked(0, false);
                    chklstTANs.EndUpdate();
                    chklstTANs.ItemCheck += chklstRxns_ItemCheck;
                }

                if (e.Index != 0 && e.NewValue == CheckState.Checked && chklstTANs.CheckedItems.Count == chklstTANs.Items.Count - 2)
                {
                    chklstTANs.BeginUpdate();
                    chklstTANs.ItemCheck -= chklstRxns_ItemCheck;
                    chklstTANs.SetItemChecked(0, true);
                    chklstTANs.EndUpdate();
                    chklstTANs.ItemCheck += chklstRxns_ItemCheck;
                }

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void DeSelectAllItems()
        {
            try
            {
                chklstTANs.BeginUpdate();
                chklstTANs.ItemCheck -= chklstRxns_ItemCheck;
                for (int i = 0; i < this.chklstTANs.Items.Count; i++)
                {
                    this.chklstTANs.SetItemChecked(i, false);
                }
                chklstTANs.SetSelected(0, false);
                chklstTANs.EndUpdate();
                chklstTANs.ItemCheck += chklstRxns_ItemCheck;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void SelectAllItems()
        {
            try
            {
                chklstTANs.BeginUpdate();
                chklstTANs.ItemCheck -= chklstRxns_ItemCheck;
                for (int i = 0; i < this.chklstTANs.Items.Count; i++)
                {
                    this.chklstTANs.SetItemChecked(i, true);
                }
                chklstTANs.SetSelected(0, false);
                chklstTANs.EndUpdate();
                chklstTANs.ItemCheck += chklstRxns_ItemCheck;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            string strErrmsg = string.Empty;
            try
            {
                if (ValidUserInputs(out strErrmsg))
                {
                    GetSelectedTANsPageInfoAndBindToGrid();
                }
                else
                {
                    MessageBox.Show(strErrmsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetSelectedTANsPageInfoAndBindToGrid()
        {
            try
            {
                lstTanIDs = GetSelectedTanIDs();

                TANsPageInfo = NarrativesDB.GetReactionsPageInfoOnTanIDs(lstTanIDs);

                dgvRxnsPageInfo.AutoGenerateColumns = false;
                BindingSource bsTANFindings = new BindingSource(TANsPageInfo, null);
                dgvRxnsPageInfo.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                dgvRxnsPageInfo.DataSource = bsTANFindings;  
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private List<int> GetSelectedTanIDs()
        {
            lstTanIDs = new List<int>();
            int TAN_ID = 0;
            try
            {
                if (BatchTANs != null && BatchTANs.Rows.Count > 0)
                {
                    // Rxn id for secondary reaction
                    for (int i = 0; i < chklstTANs.CheckedItems.Count; i++)
                    {
                        if (chklstTANs.CheckedItems[i].ToString() != "Select All")
                        {
                            TAN_ID = (from DataRow dr in BatchTANs.Rows
                                      where Convert.ToString(dr["TAN_NAME"]) == chklstTANs.CheckedItems[i].ToString()
                                      select (Convert.ToInt32(dr["TAN_ID"]))).FirstOrDefault();

                            lstTanIDs.Add(TAN_ID);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstTanIDs;
        }

        private bool ValidUserInputs(out string strErrmsg)
        {
            bool status = true;
            string Err = string.Empty;

            try
            {
                if (chklstTANs.CheckedItems.Count == 0)
                {
                    status = false;
                    Err += "Please select reactions";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            strErrmsg = Err;
            return status;
        }

        private void dgvFindings_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();
                while (strRowNumber.Length < dgvRxnsPageInfo.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvRxnsPageInfo.Font);

                if (dgvRxnsPageInfo.RowHeadersWidth < (int)(size.Width + 20)) dgvRxnsPageInfo.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvFindings_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            try
            {
                for (int i = 0; i < this.dgvRxnsPageInfo.Rows.Count; i++)
                {
                    this.dgvRxnsPageInfo.AutoResizeRow(i, DataGridViewAutoSizeRowMode.AllCells);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                TANsPageInfo = null;
                dgvRxnsPageInfo.DataSource = null;
               
                lstEditedRowIDs.Clear();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }      

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                //dgvFindings.dir
                if (lstEditedRowIDs.Count > 0)
                {
                    RxnsPageInfo editedRxnsPageInfo = GetEditedRxnsPageInfoFromGrid(lstEditedRowIDs);
                    if (editedRxnsPageInfo != null)
                    {
                        DialogResult diaRes = MessageBox.Show("Do you want to update selected reactions page information?",GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (diaRes == System.Windows.Forms.DialogResult.Yes)
                        {
                            if (NarrativesDB.UpdateShipmentTANsPageInformation(editedRxnsPageInfo))
                            {
                                MessageBox.Show("Updated Reactions Page Info successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);

                                GetSelectedTANsPageInfoAndBindToGrid();

                                lstEditedRowIDs.Clear();
                            }
                            else
                            {
                                MessageBox.Show("Error in Reactions Page Info update", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private RxnsPageInfo GetEditedRxnsPageInfoFromGrid(List<int> updatedRowIDs)
        {
            RxnsPageInfo rxnsPageinfo = null;
            try
            {
                if (lstEditedRowIDs != null && lstEditedRowIDs.Count > 0)
                {
                    rxnsPageinfo = new RxnsPageInfo();

                    List<Int32> lstRxnIDs = new List<Int32>();
                    List<Int32> lstPageNo = new List<Int32>();
                    List<string> lstPageLabel = new List<string>();
                                     
                    DataGridViewRow gridRow = null;
                    int intPageNo = 0;
                   
                    for (int i = 0; i < lstEditedRowIDs.Count; i++)
                    {
                        intPageNo = 0;

                        gridRow = dgvRxnsPageInfo.Rows[lstEditedRowIDs[i]];
                        lstRxnIDs.Add(Convert.ToInt32(gridRow.Cells[colRxnID.Name].Value));
                        if (gridRow.Cells[colPageNo.Name].Value != null)
                        {
                            int.TryParse(gridRow.Cells[colPageNo.Name].Value.ToString(), out intPageNo);
                            lstPageNo.Add(intPageNo);
                        }

                        lstPageLabel.Add(Convert.ToString(gridRow.Cells[colPageLabel.Name].Value));                        
                    }

                    rxnsPageinfo.RxnIDs = lstRxnIDs;
                    rxnsPageinfo.PageNos = lstPageNo;
                    rxnsPageinfo.PageLabels = lstPageLabel;                    
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return rxnsPageinfo;
        }

        List<int> lstEditedRowIDs = new List<int>();
        private void dgvFindings_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                {
                    if (!lstEditedRowIDs.Contains(e.RowIndex))
                    {
                        lstEditedRowIDs.Add(e.RowIndex);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvRxnsPageInfo_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            try
            {
                e.ThrowException = false;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}

