﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;

namespace IndxReactNarr.Curation.ExperimentalProcedures
{
    public partial class frmAutoFindings_Test : Form
    {
        public frmAutoFindings_Test()
        {
            InitializeComponent();
        }

        public DataTable RxnAutoFindings { get; set; }

        private void frmAutoFindings_Test_Load(object sender, EventArgs e)
        {
            try
            { 
                if (RxnAutoFindings != null)
                {
                    dgvRxnFindings.AutoGenerateColumns = false;
                    dgvRxnFindings.DataSource = RxnAutoFindings;

                    colFindingType.DataPropertyName = "FINDING_TYPE";
                    colFindingValue.DataPropertyName = "FINDING_VALUE_RTF";
                    colRefCompound.DataPropertyName = "REFERENCE_SUBSTANCE";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
