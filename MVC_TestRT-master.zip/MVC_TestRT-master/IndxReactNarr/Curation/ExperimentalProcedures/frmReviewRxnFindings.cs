﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using IndxReactNarrDAL;

namespace IndxReactNarr.Curation.ExperimentalProcedures
{
    public partial class frmReviewRxnFindings : Form
    {
        public frmReviewRxnFindings()
        {
            InitializeComponent();
        }

        public DataTable TANReactions { get; set; }
        public DataTable TANFindings { get; set; }       

        List<string> lstRxnNames = null;
        List<int> lstRxnIds = null;

        private void frmReviewRxnFindings_Load(object sender, EventArgs e)
        {
            try
            {
               // this.WindowState = FormWindowState.Maximized;
                if (TANReactions != null && TANReactions.Rows.Count > 0)
                {
                    UpdateReactionsTableForLabels();

                    lstRxnNames = TANReactions.Rows.Cast<DataRow>().Select(row => row["RXN_NAR_ID"].ToString()).ToList();//GetReactionLabelsForAutoFill();//

                    BindListToCheckListBox(lstRxnNames);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            string strErrmsg = string.Empty;
            try
            {
                if (ValidUserInputs(out strErrmsg) && string.IsNullOrEmpty(strErrmsg))
                {
                    lstRxnIds = GetSelectedReactionIDs();

                    TANFindings = NarrativesDB.GetReactionFindingsOnReactionIDs(lstRxnIds);

                    UpdateRxnFindingsTableForLabels();

                    TANFindings = GetRxnFindingsWithRtfColumn(TANFindings);

                    dgvTANFindings.AutoGenerateColumns = false;
                    BindingSource bsTANFindings = new BindingSource(TANFindings, null);
                    dgvTANFindings.DataSource = bsTANFindings;

                    //dgvTANFindings.DataSource = null;
                    //dgvTANFindings.AutoGenerateColumns = false;
                    //dgvTANFindings.DataSource = TANFindings;

                    //Auto Resize rows
                    for (int i = 0; i < dgvTANFindings.Rows.Count; i++)
                    {
                        dgvTANFindings.AutoResizeRow(i, DataGridViewAutoSizeRowMode.AllCells);
                    }
                }
                else
                {
                    MessageBox.Show(strErrmsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void UpdateReactionsTableForLabels()
        {
            try
            {
                int analogRxnID = 0;
                string narID = "";
                if (TANReactions != null && TANReactions.Rows.Count > 0)
                {
                    for (int i = 0; i < TANReactions.Rows.Count; i++)
                    {
                        narID = TANReactions.Rows[i]["RXN_NAR_ID"].ToString();

                        if (TANReactions.Rows[i]["IS_ANALOGOUS"].ToString() == "Y")
                        {
                            if (!System.DBNull.Value.Equals(TANReactions.Rows[i]["ANALOGOUS_RXN_ID"]))
                            {
                                int.TryParse(TANReactions.Rows[i]["ANALOGOUS_RXN_ID"].ToString(), out analogRxnID);
                                if (analogRxnID > 0)
                                {
                                    var a = ((from row in TANReactions.AsEnumerable().Where(r => r.Field<Int64>("RXN_ID") == analogRxnID)
                                              select row.Field<string>("RXN_NAR_ID")).First());
                                    narID += " analogousTo=" + a;
                                }
                            }

                            TANReactions.Rows[i]["RXN_NAR_ID"] = narID;
                            TANReactions.AcceptChanges();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void UpdateRxnFindingsTableForLabels()
        {
            try
            {
                int analogRxnID = 0;
                string narID = "";
                if (TANFindings != null && TANFindings.Rows.Count > 0)
                {
                    for (int i = 0; i < TANFindings.Rows.Count; i++)
                    {
                        narID = TANFindings.Rows[i]["RXN_NAR_ID"].ToString();

                        if (TANFindings.Rows[i]["IS_ANALOGOUS"].ToString() == "Y")
                        {
                            if (!System.DBNull.Value.Equals(TANFindings.Rows[i]["ANALOGOUS_RXN_ID"]))
                            {
                                int.TryParse(TANFindings.Rows[i]["ANALOGOUS_RXN_ID"].ToString(), out analogRxnID);
                                if (analogRxnID > 0)
                                {
                                    var a = ((from row in TANFindings.AsEnumerable().Where(r => r.Field<Int64>("RXN_ID") == analogRxnID)
                                              select row.Field<string>("RXN_NAR_ID")).First());
                                    narID += " analogousTo=" + a;
                                }
                            }

                            TANFindings.Rows[i]["RXN_NAR_ID"] = narID;
                            TANFindings.AcceptChanges();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private bool ValidUserInputs(out string strErrmsg)
        {
            bool status = true;
            string Err = string.Empty;

            try
            {               
                if (chklstRxns.CheckedItems.Count == 0)
                {
                    status = false;
                    Err += "Please select reactions";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            strErrmsg = Err;
            return status;
        }

        private List<int> GetSelectedReactionIDs()
        {
            lstRxnIds = new List<int>();
            int Rxn_Id = 0;
            try
            {
                if (TANReactions != null && TANReactions.Rows.Count > 0)
                {                   
                    // Rxn id for secondary reaction
                    for (int i = 0; i < chklstRxns.CheckedItems.Count; i++)
                    {
                        if (chklstRxns.CheckedItems[i].ToString() != "Select All")
                        {
                            Rxn_Id = (from DataRow dr in TANReactions.Rows
                                      where Convert.ToString(dr["RXN_NAR_ID"]) == chklstRxns.CheckedItems[i].ToString()
                                      select (Convert.ToInt32(dr["RXN_ID"]))).FirstOrDefault();

                            lstRxnIds.Add(Rxn_Id);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstRxnIds;
        }

        private DataTable GetRxnFindingsWithRtfColumn(DataTable rxnFindings)
        {
            DataTable dtRxnFindings = null;
            try
            {
                if (rxnFindings != null)
                {
                    dtRxnFindings = rxnFindings.Copy();

                    if (!dtRxnFindings.Columns.Contains("FINDING_VALUE_RTF"))
                    {
                        dtRxnFindings.Columns.Add("FINDING_VALUE_RTF");
                    }

                    for (int i = 0; i < dtRxnFindings.Rows.Count; i++)
                    {
                        if (dtRxnFindings.Rows[i]["FINDING_VALUE"] != null)
                        {
                            dtRxnFindings.Rows[i]["FINDING_VALUE_RTF"] = Html_RtfConversions.Instance.GetRTFfromHTMLString(dtRxnFindings.Rows[i]["FINDING_VALUE"].ToString(), false);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtRxnFindings;
        }
               
        private void BindListToCheckListBox(List<string> Reactions)
        {
            try
            {
                chklstRxns.Items.Add("Select All");
                foreach (string RXN in Reactions)
                {
                    chklstRxns.Items.Add(RXN);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void chklstRxns_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            try
            {
                if (e.Index == 0 && e.NewValue == CheckState.Checked)
                {
                    SelectAllItems();

                }

                if (e.Index == 0 && e.NewValue == CheckState.Unchecked)
                {
                    DeSelectAllItems();

                }

                if (e.Index != 0 && e.NewValue == CheckState.Unchecked)
                {
                    chklstRxns.BeginUpdate();
                    chklstRxns.ItemCheck -= chklstRxns_ItemCheck;
                    chklstRxns.SetItemChecked(0, false);
                    chklstRxns.EndUpdate();
                    chklstRxns.ItemCheck += chklstRxns_ItemCheck;
                }

                if (e.Index != 0 && e.NewValue == CheckState.Checked && chklstRxns.CheckedItems.Count == chklstRxns.Items.Count - 2)
                {
                    chklstRxns.BeginUpdate();
                    chklstRxns.ItemCheck -= chklstRxns_ItemCheck;
                    chklstRxns.SetItemChecked(0, true);
                    chklstRxns.EndUpdate();
                    chklstRxns.ItemCheck += chklstRxns_ItemCheck;
                }

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void DeSelectAllItems()
        {
            try
            {
                chklstRxns.BeginUpdate();
                chklstRxns.ItemCheck -= chklstRxns_ItemCheck;
                for (int i = 0; i < this.chklstRxns.Items.Count; i++)
                {
                    this.chklstRxns.SetItemChecked(i, false);
                }
                chklstRxns.SetSelected(0, false);
                chklstRxns.EndUpdate();
                chklstRxns.ItemCheck += chklstRxns_ItemCheck;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void SelectAllItems()
        {
            try
            {
                chklstRxns.BeginUpdate();
                chklstRxns.ItemCheck -= chklstRxns_ItemCheck;
                for (int i = 0; i < this.chklstRxns.Items.Count; i++)
                {
                    this.chklstRxns.SetItemChecked(i, true);
                }
                chklstRxns.SetSelected(0, false);
                chklstRxns.EndUpdate();
                chklstRxns.ItemCheck += chklstRxns_ItemCheck;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvTANFindings_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            try
            {
                for (int i = 0; i < this.dgvTANFindings.Rows.Count; i++)
                {
                    this.dgvTANFindings.AutoResizeRow(i, DataGridViewAutoSizeRowMode.AllCells);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                TANFindings = null;
                dgvTANFindings.DataSource = null;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvTANFindings_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();
                while (strRowNumber.Length < dgvTANFindings.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvTANFindings.Font);

                if (dgvTANFindings.RowHeadersWidth < (int)(size.Width + 20)) dgvTANFindings.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvTANFindings_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {               
                
                HtmlRichText.HtmlRichTextBox TB = (HtmlRichText.HtmlRichTextBox)e.Control;
                TB.Multiline = true;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
