﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using IndxReactNarrDAL;
using IndxReactNarrBll;
using IndxReactNarr.PdfExport;
using System.Diagnostics;
using IndxReactNarr.TaskManagement;
using IndxReactNarr.Common;
using System.Threading;
using IndxReactNarr.Curation.ExperimentalProcedures;


namespace IndxReactNarr.Curation.Narratives
{
    public partial class frmExpProceduresCuration : Form
    {
        public frmExpProceduresCuration()
        {
            InitializeComponent();
        }

        #region Public Properties

        public int TAN_ID { get; set; }
        public int RXN_ID { get; set; }
        public int Task_ID { get; set; }
        public int TaskAlloc_ID { get; set; }

        public string ShipmentName { get; set; }
        public string TAN_Name { get; set; }
        public string TAN_Type { get; set; }
        public DataTable TANDetails { get; set; }
        public DataTable TAN_Documents { get; set; }
        public DataTable TAN_Reactions { get; set; }
        public DataTable TAN_Reactions_Pdf { get; set; }

        //For Find and Replace
        public DataTable TAN_Reactions_FR { get; set; }

        //TO Review reactions

        #endregion

        private void frmNarrCuration_New_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;

                this.KeyPreview = true;

                //Disable UpDown buttons
                numGotoRecord.Controls[0].Enabled = false;

                gdViewer.MouseMode = GdViewerPro4.ViewerMouseMode.MouseModeAreaSelection;

                pnlSplChars.Visible = false;
                ucSplCharsToolStrip_Indexing1.tsbConvFormula.Visible = true;

                HideButtonsOnUserRole(GlobalVariables.RoleName);

                //Bind finding types to combobox
                //ucExpProcCuration.cmbFindingType.DataSource = GlobalVariables.FindingTypesData;

                //ucExpProcCuration.cmbFindingType.DisplayMember = "FINDING_TYPE_NAME";
                //ucExpProcCuration.cmbFindingType.ValueMember = "FINDING_TYPE_NAME";

                if (TAN_ID > 0)
                {
                    TANDetails = IndxReactNarrDAL.ReactDB.GetTANDetailsOnTANID(TAN_ID);

                    //TAN Details
                    if (TANDetails != null && TANDetails.Rows.Count > 0)
                    {
                        txtTAN.Text = TANDetails.Rows[0]["TAN_NAME"].ToString();
                        txtCAN.Text = TANDetails.Rows[0]["CAN"].ToString();
                        txtDOI.Text = TANDetails.Rows[0]["DOI"].ToString();
                        txtTANType.Text = TANDetails.Rows[0]["TAN_TYPE"].ToString();

                        TAN_Name = TANDetails.Rows[0]["TAN_NAME"].ToString();
                        TAN_Type = TANDetails.Rows[0]["TAN_TYPE"].ToString();

                        if (TANDetails.Rows[0]["IS_EXP_PROCE_NAR"].ToString() == "Y")
                        {
                            chkSkipValidations.Visible = true;
                            chkSkipValidations.Enabled = true;

                            ucExpProcCuration.chkMappingUpdate.Visible = true;
                            ucExpProcCuration.chkMappingUpdate.Enabled = true;
                        }
                        else
                        {
                            ucExpProcCuration.chkMappingUpdate.Visible = false;
                            ucExpProcCuration.chkMappingUpdate.Enabled = false;
                        }
                    }

                    txtShipment.Text = !string.IsNullOrEmpty(ShipmentName) ? ShipmentName : GlobalVariables.ShipmentName;

                    //Get TAN Documents and bind to grid
                    TAN_Documents = NarrativesDB.GetTANDocumentsOnTANID(TAN_ID);
                    BindTanDocumentsToGrid();

                    //Get TAN Reactions and bind to TreeView                 
                    TAN_Reactions = NarrativesDB.GetTANReactionsOnTANID_ForTreeView(TAN_ID);
                    BindReactionsTreeView();

                    //Load TAN reactions for Find and Replace in background
                    LoadTANReactionsForFindReplaceAndPdfInBackGround();

                    //Set Progress/Completed Reactions label
                    lblRxnCountValue.Text = GetCompletedReactionsLabel();

                    //Set values to Reaction Usercontrol
                    ucExpProcCuration.TAN_Reactions = TAN_Reactions;
                    ucExpProcCuration.TAN_Documents = TAN_Documents;
                    ucExpProcCuration.TANType = TAN_Type;

                    ////Load 1st Reaction data
                    //tvReactions.SelectedNode = tvReactions.Nodes[0].Nodes[0];
                    //int rxnID = 0;
                    //int.TryParse(tvReactions.SelectedNode.Tag.ToString(), out rxnID);
                    //GetRxnDataAndBindToUserControl(rxnID);

                    ////Select Node in the TreeView
                    //SelectReactionNodeInTheTreeView(tvReactions.SelectedNode.Index);

                    blValidRxn = true;//Set to true in the Page load, check in Reaction navigation whether reaction is valid or not

                    MaxRecCnt = TAN_Reactions.Rows.Count;
                    numGotoRecord.Maximum = MaxRecCnt;
                    currRecIndex = 1;
                    numGotoRecord.Minimum = 1;
                    numGotoRecord.Value = currRecIndex;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void LoadTANReactionsForFindReplaceAndPdfInBackGround()
        {
            try
            {
                //Load TAN reactions for Find and Replace in background
                Thread trdDictionary = new Thread(delegate()
                {
                    TAN_Reactions_FR = NarrativesDB.GetTANReactionsOnTANID(TAN_ID);
                    TAN_Reactions_Pdf = NarrativesDB.GetTANReactionsForExportOnTANID(TAN_ID);
                });
                trdDictionary.IsBackground = true;
                trdDictionary.Start();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetCompletedReactionsLabel()
        {
            string complRxns = "";
            try
            {
                if (TAN_Reactions != null)
                {
                    if (TAN_Reactions.Rows.Count > 0)
                    {
                        if (GlobalVariables.RoleName.ToUpper() == "ANALYST")
                        {
                            var rows = from row in TAN_Reactions.AsEnumerable()
                                       where row.Field<Int64?>("CURATED_BY") == GlobalVariables.URID
                                       select row;

                            if (rows != null)
                            {
                                complRxns = rows.Count().ToString() + " / " + TAN_Reactions.Rows.Count.ToString();
                            }
                        }
                        else if (GlobalVariables.RoleName.ToUpper() == "REVIEW ANALYST")
                        {
                            var rows = from row in TAN_Reactions.AsEnumerable()
                                       where row.Field<Int64?>("REVIEWED_BY") == GlobalVariables.URID
                                       select row;

                            if (rows != null)
                            {
                                complRxns = rows.Count().ToString() + " / " + TAN_Reactions.Rows.Count.ToString();
                            }
                        }
                        else if (GlobalVariables.RoleName.ToUpper() == "QUALITY ANALYST")
                        {
                            var rows = from row in TAN_Reactions.AsEnumerable()
                                       where row.Field<Int64?>("QC_BY") == GlobalVariables.URID
                                       select row;

                            if (rows != null)
                            {
                                complRxns = rows.Count().ToString() + " / " + TAN_Reactions.Rows.Count.ToString();
                            }
                        }
                        else
                        {
                            complRxns = TAN_Reactions.Rows.Count.ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return complRxns;
        }

        private void HideButtonsOnUserRole(string userRole)
        {
            try
            {
                if (!string.IsNullOrEmpty(userRole))
                {
                    btnRejectTAN.Visible = false;
                    btnTANComplete.Visible = false;
                    chkRxnComplete.Visible = false;

                    if (userRole.ToUpper() == RolesMaster.ANALYST.ToUpper() || userRole.ToUpper() == RolesMaster.REV_ANALYST.ToUpper()
                        || userRole.ToUpper() == RolesMaster.QC_ANALYST.ToUpper())
                    {
                        btnRejectTAN.Visible = userRole.ToUpper() == RolesMaster.ANALYST.ToUpper() ? false : true;
                        btnTANComplete.Visible = true;
                        chkRxnComplete.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        /// <summary>
        /// Binds the tan documents to grid.
        /// </summary>
        private void BindTanDocumentsToGrid()
        {
            try
            {
                dgvTANDocuments.DataSource = null;
                if (TAN_Documents != null)
                {
                    dgvTANDocuments.AutoGenerateColumns = false;
                    dgvTANDocuments.DataSource = TAN_Documents;

                    colDocID.DataPropertyName = "TAN_DOC_ID";
                    colDocNo.DataPropertyName = "FILE_TYPE1";
                    colDocName.DataPropertyName = "FILE_NAME";
                    colDocPageSizeX.DataPropertyName = "PAGE_SIZE_X";
                    colDocPageSizeY.DataPropertyName = "PAGE_SIZE_Y";

                    colDocPageLabelBlank.DataPropertyName = "IS_PAGE_LABEL_BLANK";
                    colCombinedDoc.DataPropertyName = "IS_COMBINED_DOC";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        /// <summary>
        /// Add Reactions to TreeView
        /// </summary>
        private void BindReactionsTreeView()
        {
            try
            {
                if (TAN_Reactions != null)
                {
                    //Clear Nodes, if any
                    tvReactions.Nodes.Clear();

                    if (TAN_Reactions.Rows.Count > 0)
                    {
                        tvReactions.Nodes.Add(TAN_Name);

                        TreeNode tnRxn = null;

                        for (int i = 0; i < TAN_Reactions.Rows.Count; i++)
                        {
                            tnRxn = new TreeNode();
                            tnRxn.Tag = TAN_Reactions.Rows[i]["RXN_ID"].ToString();

                            string narID = TAN_Reactions.Rows[i]["RXN_NAR_ID"].ToString();
                            tnRxn.Name = TAN_Reactions.Rows[i]["RXN_NAR_ID"].ToString();

                            if (TAN_Reactions.Rows[i]["IS_ANALOGOUS"].ToString() == "Y")
                            {
                                if (!System.DBNull.Value.Equals(TAN_Reactions.Rows[i]["ANALOGOUS_RXN_ID"]))
                                {
                                    int analogRxnID = 0;
                                    int.TryParse(TAN_Reactions.Rows[i]["ANALOGOUS_RXN_ID"].ToString(), out analogRxnID);
                                    if (analogRxnID > 0)
                                    {
                                        var a = ((from row in TAN_Reactions.AsEnumerable().Where(r => r.Field<Int64>("RXN_ID") == analogRxnID)
                                                  select row.Field<string>("RXN_NAR_ID")).First());
                                        narID += " analogousTo=" + a;

                                    }
                                }
                            }

                            tnRxn.ToolTipText = TAN_Reactions.Rows[i]["RXN_NUM"].ToString() + "-" + TAN_Reactions.Rows[i]["RXN_SEQ"].ToString();
                            tnRxn.Text = narID;

                            if (GlobalVariables.RoleName.ToUpper() == RolesMaster.ANALYST.ToUpper())
                            {
                                //if (TAN_Reactions.Rows[i]["CURATED_BY"].ToString() == GlobalVariables.URID.ToString())
                                if (!string.IsNullOrEmpty(TAN_Reactions.Rows[i]["CURATED_BY"].ToString()))
                                {
                                    tnRxn.ImageIndex = 0;
                                }
                                else
                                {
                                    tnRxn.ImageIndex = 1;
                                }
                            }
                            if (GlobalVariables.RoleName.ToUpper() == "REVIEW ANALYST")
                            {
                                //if (TAN_Reactions.Rows[i]["REVIEWED_BY"].ToString() == GlobalVariables.URID.ToString())
                                if (!string.IsNullOrEmpty(TAN_Reactions.Rows[i]["REVIEWED_BY"].ToString()))
                                {
                                    tnRxn.ImageIndex = 0;
                                }
                                else
                                {
                                    tnRxn.ImageIndex = 1;
                                }
                            }
                            if (GlobalVariables.RoleName.ToUpper() == "QUALITY ANALYST")
                            {
                                //if (TAN_Reactions.Rows[i]["QC_BY"].ToString() == GlobalVariables.URID.ToString())
                                if (!string.IsNullOrEmpty(TAN_Reactions.Rows[i]["QC_BY"].ToString()))
                                {
                                    tnRxn.ImageIndex = 0;
                                }
                                else
                                {
                                    tnRxn.ImageIndex = 1;
                                }
                            }

                            tvReactions.Nodes[0].Nodes.Add(tnRxn);
                        }
                    }

                    tvReactions.ExpandAll();


                    //if (selectedNodeIndx >= 0)
                    //{
                    //    TreeNodeCollection nodes = tvReactions.Nodes[0].Nodes;
                    //    tvReactions.SelectedNode = nodes[selectedNodeIndx];                       
                    //    tvReactions.SelectedNode.EnsureVisible();
                    //}
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        /// <summary>
        /// Update Reactions to TreeView
        /// </summary>
        private void UpdateReactionsTreeViewOnRxnID(int reactionID)
        {
            try
            {
                if (tvReactions.Nodes[0].Nodes.Count > 0)
                {
                    using (DataTable curRxnData = NarrativesDB.GetReactionDataOnRxnID(reactionID))
                    {
                        if (curRxnData != null && curRxnData.Rows.Count > 0)
                        {
                            TreeNode trNode = GetReactionTreeNodeOnReactionID(curRxnData.Rows[0]["RXN_ID"].ToString());

                            // foreach (TreeNode tn in tvReactions.Nodes[0].Nodes)
                            // {
                            //   if (tn.Tag.ToString() == curRxnData.Rows[0]["RXN_ID"].ToString())
                            //  {
                            string narID = curRxnData.Rows[0]["RXN_NAR_ID"].ToString();

                            if (curRxnData.Rows[0]["IS_ANALOGOUS"].ToString() == "Y")
                            {
                                if (!System.DBNull.Value.Equals(curRxnData.Rows[0]["ANALOGOUS_RXN_ID"]))
                                {
                                    int analogRxnID = 0;
                                    int.TryParse(curRxnData.Rows[0]["ANALOGOUS_RXN_ID"].ToString(), out analogRxnID);
                                    if (analogRxnID > 0)
                                    {
                                        var a = ((from row in TAN_Reactions.AsEnumerable().Where(r => r.Field<Int64>("RXN_ID") == analogRxnID)
                                                  select row.Field<string>("RXN_NAR_ID")).First());
                                        narID += " analogousTo=" + a;
                                    }
                                }
                            }

                            trNode.ToolTipText = curRxnData.Rows[0]["RXN_NUM"].ToString() + "-" + curRxnData.Rows[0]["RXN_SEQ"].ToString();
                            trNode.Text = narID;

                            if (GlobalVariables.RoleName.ToUpper() == RolesMaster.ANALYST.ToUpper())
                            {
                                trNode.ImageIndex = !string.IsNullOrEmpty(curRxnData.Rows[0]["CURATED_BY"].ToString()) ? 0 : 1;
                            }
                            if (GlobalVariables.RoleName.ToUpper() == "REVIEW ANALYST")
                            {
                                trNode.ImageIndex = !string.IsNullOrEmpty(curRxnData.Rows[0]["REVIEWED_BY"].ToString()) ? 0 : 1;
                            }
                            if (GlobalVariables.RoleName.ToUpper() == "QUALITY ANALYST")
                            {
                                trNode.ImageIndex = !string.IsNullOrEmpty(curRxnData.Rows[0]["QC_BY"].ToString()) ? 0 : 1;
                            }
                            //      break;
                            //   }
                            // }

                            //Update Reaction in Reactions Table
                            UpdateReactionDataInReactionsTable(curRxnData.Rows[0], reactionID);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private TreeNode GetReactionTreeNodeOnReactionID(string rxnID)
        {
            TreeNode treeNode = null;
            try
            {
                foreach (TreeNode tn in tvReactions.Nodes[0].Nodes)
                {
                    if (tn.Tag.ToString() == rxnID)
                    {
                        treeNode = tn;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return treeNode;
        }

        private void UpdateReactionDataInReactionsTable(DataRow rxnDataRow, int reactionID)
        {
            try
            {
                if (rxnDataRow != null && TAN_Reactions != null)
                {
                    var rowsToUpdate = TAN_Reactions.AsEnumerable().Where(r => r.Field<Int64>("RXN_ID") == reactionID);

                    foreach (var row in rowsToUpdate)
                    {
                        row.SetField("TAN_ID", rxnDataRow["TAN_ID"]);
                        row.SetField("TAN_DOC_ID", rxnDataRow["TAN_DOC_ID"]);
                        row.SetField("RXN_NUM", rxnDataRow["RXN_NUM"]);
                        row.SetField("RXN_SEQ", rxnDataRow["RXN_SEQ"]);
                        row.SetField("RXN_NAR_ID", rxnDataRow["RXN_NAR_ID"]);
                        //row.SetField("PAGE_NO", rxnDataRow["PAGE_NO"]);
                        //row.SetField("PAGE_LABEL", rxnDataRow["PAGE_LABEL"]);
                        //row.SetField("PAGE_SIZE_X", rxnDataRow["PAGE_SIZE_X"]);
                        //row.SetField("PAGE_SIZE_Y", rxnDataRow["PAGE_SIZE_Y"]);
                        //row.SetField("OFFSET_X", rxnDataRow["OFFSET_X"]);
                        //row.SetField("OFFSET_Y", rxnDataRow["OFFSET_Y"]);
                        //row.SetField("TEXT_LINE", rxnDataRow["TEXT_LINE"]);
                        row.SetField("IS_ANALOGOUS", rxnDataRow["IS_ANALOGOUS"]);
                        row.SetField("ANALOGOUS_RXN_ID", rxnDataRow["ANALOGOUS_RXN_ID"]);
                        //row.SetField("IS_GENERAL_TYPICAL", rxnDataRow["IS_GENERAL_TYPICAL"]);
                        //row.SetField("NO_EXP_DETAILS", rxnDataRow["NO_EXP_DETAILS"]);
                        //row.SetField("IS_MISSING_RXN", rxnDataRow["IS_MISSING_RXN"]);
                        //row.SetField("PARA_TEXT", rxnDataRow["PARA_TEXT"]);
                        //row.SetField("DATA_TEXT", rxnDataRow["DATA_TEXT"]);
                        row.SetField("CURATED_BY", rxnDataRow["CURATED_BY"]);
                        row.SetField("REVIEWED_BY", rxnDataRow["REVIEWED_BY"]);
                        row.SetField("QC_BY", rxnDataRow["QC_BY"]);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        TreeNode tnSelected;
        private void SelectReactionNodeInTheTreeView(int curRecIndx)
        {
            try
            {
                if (curRecIndx >= 0 && tvReactions.Nodes[0].Nodes.Count > 0 && (curRecIndx < tvReactions.Nodes[0].Nodes.Count))
                {
                    tnSelected = null;

                    //Select Node in the Reactions TreeView
                    foreach (TreeNode tn in tvReactions.Nodes[0].Nodes)
                    {
                        // tn.ImageIndex = 0;
                        tn.ForeColor = Color.Blue;
                    }
                    tnSelected = tvReactions.Nodes[0].Nodes[curRecIndx];
                    tnSelected.ForeColor = Color.Red;
                    tnSelected.SelectedImageIndex = 2;
                    tvReactions.SelectedNode = tnSelected;
                    tvReactions.Nodes[0].Nodes[curRecIndx].ExpandAll();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        int selectedNodeIndx = 0;
        int selectedRxnID = 0;
        private void tvRxns_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            try
            {
                if (e.Node.Tag != null)
                {
                    string strErrMsg = "";
                    blValidRxn = false;

                    if (chkRxnComplete.Checked)
                    {
                        if (RXN_ID > 0 && !ucExpProcCuration.ValidateNarrReactionData(chkSkipValidations.Checked, out strErrMsg))
                        {
                            MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    blValidRxn = true;
                    selectedNodeIndx = e.Node.Index + 1;
                    numGotoRecord.Value = selectedNodeIndx;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tvReactions_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == (char)13)
                {
                    string strErrMsg = "";
                    blValidRxn = false;

                    if (chkRxnComplete.Checked)
                    {
                        if (RXN_ID > 0 && !ucExpProcCuration.ValidateNarrReactionData(chkSkipValidations.Checked, out strErrMsg))
                        {
                            MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    tn = tvReactions.SelectedNode;

                    if (tn != null)
                    {
                        selectedNodeIndx = tn.Index + 1;

                        if (selectedNodeIndx == numGotoRecord.Value)
                        {
                            numGotoRecord.Value = selectedNodeIndx;
                            numGotoRecord_ValueChanged(null, null);
                        }
                        else
                        {
                            numGotoRecord.Value = selectedNodeIndx;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void SaveCurrentReactionAndMoveToReaction(int newRxnID, int nodeIndex)
        {
            try
            {
                if (newRxnID > 0)
                {
                    NarrReactionsBO narRxnData = ucExpProcCuration.GetNarrReactionDataFromUserControl();
                    if (narRxnData != null)
                    {
                        narRxnData.IsRxnCompleted = chkRxnComplete.Checked ? "Y" : "N";

                        //Save Reaction data automatically
                        if (NarrativesDB.UpdateExperimentalProcReactionData(narRxnData))
                        {
                            //Update Reaction Findings
                            if (narRxnData.ReactionFindings != null)
                            {
                                NarrativesDB.UpdateReactionFindings(narRxnData.ReactionFindings);
                            }

                            //TAN_Reactions = IndxReactNarrDAL.NarrativesDB.GetTANReactionsOnTANID(TAN_ID);
                            //BindReactionsTreeView();
                            UpdateReactionsTreeViewOnRxnID(narRxnData.RXN_ID);

                            //Set values to Reaction Usercontrol
                            ucExpProcCuration.TAN_Reactions = TAN_Reactions;

                            //Refresh TAN Documents
                            TAN_Documents = NarrativesDB.GetTANDocumentsOnTANID(TAN_ID);
                            //BindTanDocumentsToGrid();

                            //Set values to Reaction Usercontrol
                            ucExpProcCuration.TAN_Reactions = TAN_Reactions;
                            ucExpProcCuration.TAN_Documents = TAN_Documents;

                            lblSaveStatus.Text = "";

                            //Get New Reaction Data and bind to usercontrol
                            GetRxnDataAndBindToUserControl(newRxnID);

                            //Select Node In The TreeView
                            SelectReactionNodeInTheTreeView(nodeIndex);
                        }
                    }
                    else
                    {
                        //Get New Reaction Data and bind to usercontrol
                        GetRxnDataAndBindToUserControl(newRxnID);

                        //Select Node In The TreeView
                        SelectReactionNodeInTheTreeView(nodeIndex);
                    }

                    narRxnData = null;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        DataTable rxnData = null;
        DataTable rxnSubstances = null;
        DataTable rxnFindings = null;
        private void GetRxnDataAndBindToUserControl(int rxnID)
        {
            try
            {
                if (rxnID > 0)
                {
                    RXN_ID = rxnID;

                    rxnData = NarrativesDB.GetReactionDataOnRxnID(rxnID);

                    //Reaction Substances
                    rxnSubstances = NarrativesDB.GetReactionSubstancesOnRxnID(rxnID);
                    BindReactionSubstancesToGridControls(rxnSubstances);

                    //Reaction Findings
                    rxnFindings = NarrativesDB.GetReactionFindingsOnRxnID(rxnID);

                    if (rxnData != null && rxnData.Rows.Count > 0)
                    {
                        #region MyRegion
                        //var rxnRow = rxnData.Rows[0];

                        //if (rxnRow != null)
                        //{
                        //    foreach (var r in rxnRow)
                        //    {
                        //        ucNarCuration1.Rxn_ID = rxnID;

                        //        ucNarCuration1.BindReactionDataToControls(r);

                        //        //Update Reaction Complete stautus
                        //        UpdateReactionCompleteCheckBoxStatus(r);
                        //    }
                        //} 
                        #endregion

                        ucExpProcCuration.Rxn_ID = rxnID;
                        ucExpProcCuration.BindReactionDataToControls(rxnData.Rows[0], rxnSubstances, rxnFindings);

                        //Update Reaction Complete stautus
                        UpdateReactionCompleteCheckBoxStatus(rxnData.Rows[0]);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindReactionSubstancesToGridControls(DataTable dtRxnSubstances)
        {
            try
            {
                var prodRows = dtRxnSubstances.AsEnumerable()
                                     .Where(r => r.Field<string>("SUBST_ROLE") == "product");
                DataTable dtProducts = prodRows.Any() ? prodRows.CopyToDataTable() : rxnSubstances.Clone();

                var otherRows = dtRxnSubstances.AsEnumerable()
                                     .Where(r => r.Field<string>("SUBST_ROLE") != "product");
                DataTable dtOtherPartpnts = otherRows.Any() ? otherRows.CopyToDataTable() : rxnSubstances.Clone();

                dgvRxnSubsts_Products.DataSource = null;
                dgvRxnSubsts_Products.AutoGenerateColumns = false;
                dgvRxnSubsts_Products.DataSource = dtProducts.Copy();

                dgvRxnSubsts_Other.DataSource = null;
                dgvRxnSubsts_Other.AutoGenerateColumns = false;
                dgvRxnSubsts_Other.DataSource = dtOtherPartpnts.Copy();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void UpdateReactionCompleteCheckBoxStatus(DataRow rxnRowData)
        {
            try
            {
                if (rxnRowData != null)
                {
                    chkRxnComplete.Checked = false;
                    chkRxnComplete.Enabled = true;

                    if (GlobalVariables.RoleName.ToUpper() == RolesMaster.ANALYST.ToUpper())
                    {
                        if (!string.IsNullOrEmpty(rxnRowData["CURATED_BY"].ToString()))
                        {
                            chkRxnComplete.Checked = true;
                            chkRxnComplete.Enabled = false;
                        }
                    }
                    else if (GlobalVariables.RoleName.ToUpper() == RolesMaster.REV_ANALYST.ToUpper())
                    {
                        if (!string.IsNullOrEmpty(rxnRowData["REVIEWED_BY"].ToString()))
                        {
                            chkRxnComplete.Checked = true;
                            chkRxnComplete.Enabled = false;
                        }
                    }
                    else if (GlobalVariables.RoleName.ToUpper() == RolesMaster.QC_ANALYST.ToUpper())
                    {
                        if (!string.IsNullOrEmpty(rxnRowData["QC_BY"].ToString()))
                        {
                            chkRxnComplete.Checked = true;
                            chkRxnComplete.Enabled = false;
                        }
                    }
                    else //All Other roles
                    {
                        chkRxnComplete.Checked = false;
                        chkRxnComplete.Enabled = false;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvTANDocuments_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    if (dgvTANDocuments.Rows[e.RowIndex].Cells[colDocID.Name].Value != null)
                    {
                        string docName = dgvTANDocuments.Rows[e.RowIndex].Cells[colDocName.Name].Value.ToString();
                        string fileExtn = System.IO.Path.GetExtension(docName);
                        fileExtn = fileExtn.Trim(new char[] { '.' });

                        if (!string.IsNullOrEmpty(fileExtn) && (fileExtn.ToUpper() == "DOC" || fileExtn.ToUpper() == "DOCX" || fileExtn.ToUpper() == "PDF"))
                        {
                            int intDocID = Convert.ToInt32(dgvTANDocuments.Rows[e.RowIndex].Cells[colDocID.Name].Value.ToString());
                            ucExpProcCuration.SetRxnDocRefFileName(intDocID);
                        }
                        else
                        {
                            MessageBox.Show("Only DOC and PDF types can be selected", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                //Validate Reaction Data
                if (chkRxnComplete.Checked)
                {
                    string strErrMsg = "";
                    if (!ucExpProcCuration.ValidateNarrReactionData(chkSkipValidations.Checked, out strErrMsg))
                    {
                        MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                //Save Reaction data
                NarrReactionsBO narRxnData = ucExpProcCuration.GetNarrReactionDataFromUserControl();

                if (narRxnData != null)
                {
                    //Reaction Complete Status
                    narRxnData.IsRxnCompleted = chkRxnComplete.Checked ? "Y" : "N";

                    //Update Reaction data
                    if (NarrativesDB.UpdateExperimentalProcReactionData(narRxnData))
                    {
                        //Update Reaction Findings
                        if (narRxnData.ReactionFindings != null)
                        {
                            NarrativesDB.UpdateReactionFindings(narRxnData.ReactionFindings);
                        }

                        //Refresh TAN Reactions
                        //TAN_Reactions = NarrativesDB.GetTANReactionsOnTANID(TAN_ID);
                        //BindReactionsTreeView();
                        UpdateReactionsTreeViewOnRxnID(narRxnData.RXN_ID);

                        //Refresh TAN Documents
                        TAN_Documents = NarrativesDB.GetTANDocumentsOnTANID(TAN_ID);

                        //Refresh TAN Reactions 
                        TAN_Reactions= NarrativesDB.GetTANReactionsOnTANID_ForTreeView(TAN_ID);

                        //Set values to Reaction Usercontrol
                        ucExpProcCuration.TAN_Reactions = TAN_Reactions;
                        ucExpProcCuration.TAN_Documents = TAN_Documents;

                        chkRxnComplete.Enabled = chkRxnComplete.Checked ? false : true;

                        SelectReactionNodeInTheTreeView(selectedNodeIndx - 1);

                        //Set Progress/Completed Reactions label
                        lblRxnCountValue.Text = GetCompletedReactionsLabel();

                        //Set Para and Data counts
                        ucExpProcCuration.SetPara_Data_ProcSteps_FindingsLabelsCount();

                        ShowAndAutoHideStatusLabelText("Reaction saved successfully");
                    }
                    else
                    {
                        ShowAndAutoHideStatusLabelText("Error in saving the reaction");
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void ShowAndAutoHideStatusLabelText(string labelText)
        {
            try
            {
                lblSaveStatus.Text = labelText;

                var t = new System.Windows.Forms.Timer();

                t.Interval = 5000; // it will Tick for 5 seconds
                t.Tick += (s, k) =>
                {
                    lblSaveStatus.Text = "";
                    t.Stop();
                };
                t.Start();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnBrowseCood_Click(object sender, EventArgs e)
        {
            try
            {
                using (OpenFileDialog ofd = new OpenFileDialog())
                {
                    ofd.Filter = "PDF files (*.pdf)|*.pdf";
                    if (ofd.ShowDialog() != DialogResult.Cancel)
                    {
                        try
                        {
                            txtbrowsecoordinates.Text = ofd.FileName;
                            gdViewer.DisplayFromFile(ofd.FileName);
                            gdViewer.SetZoomWidthControl();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Unable to open file", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private bool ValidatieReactionsCompleteStatus(out string ErrMsg)
        {
            bool blStatus = true;           
            string StrMsg = string.Empty;
            string Msg = string.Empty;
            try
            {
                if (TAN_Reactions != null && TAN_Reactions.Rows.Count > 0)
                {
                    DataTable dtTemp = null;

                    #region MyRegion
                    //if (GlobalVariables.RoleName.ToUpper() == RolesMaster.ANALYST.ToUpper())
                    //{
                    //    var rows = TAN_Reactions.AsEnumerable()
                    //                 .Where(r => r.Field<Int64?>("CURATED_BY") == GlobalVariables.URID);
                    //    dtTemp = rows.Any() ? rows.CopyToDataTable() : TAN_Reactions.Clone();
                    //}
                    //else if (GlobalVariables.RoleName.ToUpper() == RolesMaster.REV_ANALYST.ToUpper())
                    //{
                    //    var rows = TAN_Reactions.AsEnumerable()
                    //                     .Where(r => r.Field<Int64?>("REVIEWED_BY") == GlobalVariables.URID);
                    //    dtTemp = rows.Any() ? rows.CopyToDataTable() : TAN_Reactions.Clone();
                    //}
                    //else if (GlobalVariables.RoleName.ToUpper() == RolesMaster.QC_ANALYST.ToUpper())
                    //{
                    //    var rows = TAN_Reactions.AsEnumerable()
                    //                     .Where(r => r.Field<Int64?>("QC_BY") == GlobalVariables.URID);
                    //    dtTemp = rows.Any() ? rows.CopyToDataTable() : TAN_Reactions.Clone();
                    //} 
                    #endregion

                    if (GlobalVariables.RoleName.ToUpper() == RolesMaster.ANALYST.ToUpper())
                    {
                        var rows = TAN_Reactions.AsEnumerable()
                                     .Where(r => r.Field<Int64?>("CURATED_BY") == null);
                        dtTemp = rows.Any() ? rows.CopyToDataTable() : TAN_Reactions.Clone();
                    }
                    else if (GlobalVariables.RoleName.ToUpper() == RolesMaster.REV_ANALYST.ToUpper())
                    {
                        var rows = TAN_Reactions.AsEnumerable()
                                         .Where(r => r.Field<Int64?>("REVIEWED_BY") == null);
                        dtTemp = rows.Any() ? rows.CopyToDataTable() : TAN_Reactions.Clone();
                    }
                    else if (GlobalVariables.RoleName.ToUpper() == RolesMaster.QC_ANALYST.ToUpper())
                    {
                        var rows = TAN_Reactions.AsEnumerable()
                                         .Where(r => r.Field<Int64?>("QC_BY") == null);
                        dtTemp = rows.Any() ? rows.CopyToDataTable() : TAN_Reactions.Clone();
                    }

                    int rowCnt = dtTemp != null ? dtTemp.Rows.Count : 0;
                    if (rowCnt > 0)
                    {
                        blStatus = false;
                        StrMsg = StrMsg.Trim() + Environment.NewLine + "Some Reactions are not completed";
                    }

                    //New validation for checking Page label for all the reactions - 13th Oct 2015
                    //If DocRef is Doc 1 and is a main article (not combined document), then Page label is mandatory
                    //If DocRef <> Doc1, and Is_Page_Label_Blank is N, then Page label is mandatory

                    for (int i = 0; i < TAN_Reactions.Rows.Count; i++)
                    {
                        if (string.IsNullOrEmpty(TAN_Reactions.Rows[i]["PAGE_LABEL"].ToString()))
                        {
                            //Get document properties on TAN_DOC_ID
                            var rows = TAN_Documents.Select("TAN_DOC_ID = " + Convert.ToInt64(TAN_Reactions.Rows[i]["TAN_DOC_ID"].ToString()));

                            if (rows != null && rows[0]["IS_COMBINED_DOC"].ToString() == "N" &&
                               rows[0]["FILE_IDENTIFIER"].ToString().ToUpper() == "DOC1" && TAN_Reactions.Rows[i]["PAGE_LABEL"].ToString() == "")
                            {
                                StrMsg = StrMsg.Trim() + Environment.NewLine + "Page label is mandatory for " + TAN_Reactions.Rows[i]["RXN_NAR_ID"].ToString();
                                blStatus = false;
                            }
                            else if (rows != null && rows[0]["IS_PAGE_LABEL_BLANK"].ToString() == "N" &&
                               rows[0]["FILE_IDENTIFIER"].ToString().ToUpper() != "DOC1" && TAN_Reactions.Rows[i]["PAGE_LABEL"].ToString() == "")
                            {
                                StrMsg = StrMsg.Trim() + Environment.NewLine  + "Page label is mandatory for " + TAN_Reactions.Rows[i]["RXN_NAR_ID"].ToString();
                                blStatus = false;
                            }
                        }
                    }                    
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            ErrMsg = StrMsg.Trim();
            return blStatus;
        }

        #region GDViewer related Methods and Events

        double x = 0;
        double y = 0;

        private void gdViewer_ClickControl(object sender, EventArgs e)
        {
            try
            {
                if (gdViewer.MouseMode == GdViewerPro4.ViewerMouseMode.MouseModeAreaSelection)
                {
                    if (MessageBox.Show("X offset value '" + x.ToString("0.00") + "',Y Offset value '" + y.ToString("0.00") + "', Do you want to save these values in clipboard?", "CAS Narrative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {

                        Clipboard.Clear();
                        //MessageBox.Show("XY Coordinates saved into clipboard","CAS_Narrative-Tool",MessageBoxButtons.OK,MessageBoxIcon.Information);
                        Clipboard.SetData(DataFormats.Text, "XYOFFSETS : " + x.ToString("0.00") + ":" + y.ToString("0.00"));
                    }
                }

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void gdViewer_MouseMoveControl(object sender, AxGdViewerPro4.__GdViewer_MouseMoveControlEvent e)
        {
            try
            {
                x = Convert.ToDouble(gdViewer.GetMouseX()) / 199;
                y = Convert.ToDouble(gdViewer.GetMouseY()) / 199;

                lbPos.Text = "(" + x.ToString("0.00") + "," + y.ToString("0.00") + ")";
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void gdViewer_ZoomChange(object sender, EventArgs e)
        {
            try
            {
                txtZoom.Text = Convert.ToString(gdViewer.ZOOM * 100);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnZoomFit_Click(object sender, EventArgs e)
        {
            try
            {
                gdViewer.SetZoomFitControl();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnZoom100_Click(object sender, EventArgs e)
        {
            try
            {
                gdViewer.SetZoom100();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnZoomWidth_Click(object sender, EventArgs e)
        {
            try
            {
                gdViewer.SetZoomWidthControl();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnZoomOnArea_Click(object sender, EventArgs e)
        {
            try
            {
                gdViewer.MouseMode = GdViewerPro4.ViewerMouseMode.MouseModeAutoZoom;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btFirstpage_Click(object sender, EventArgs e)
        {
            try
            {
                gdViewer.DisplayFirstFrame();
                txtGoToPdfPage.Text = gdViewer.CurrentPage.ToString();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnLastpage_Click(object sender, EventArgs e)
        {
            try
            {
                gdViewer.DisplayLastFrame();
                txtGoToPdfPage.Text = gdViewer.CurrentPage.ToString();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnPreviousPage_Click(object sender, EventArgs e)
        {
            try
            {
                gdViewer.DisplayPreviousFrame();
                txtGoToPdfPage.Text = gdViewer.CurrentPage.ToString();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btNextPage_Click(object sender, EventArgs e)
        {
            try
            {
                gdViewer.DisplayNextFrame();
                txtGoToPdfPage.Text = gdViewer.CurrentPage.ToString();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btZoomIn_Click(object sender, EventArgs e)
        {
            gdViewer.ZoomIN();
        }

        private void btZoomOut_Click(object sender, EventArgs e)
        {
            gdViewer.ZoomOUT();
        }

        private void btnPageSize_Click(object sender, EventArgs e)
        {
            try
            {
                double height = Convert.ToDouble(gdViewer.ImageHeight) / 199;
                double Width = Convert.ToDouble(gdViewer.ImageWidth) / 199;
                height = height - 0.06;
                Width = Width - 0.04;
                if (height > 0 && Width > 0)
                {
                    if (MessageBox.Show("Page height '" + height.ToString("0.00") + "',Page width '" + Width.ToString("0.00") + "', Do you want to save these values in clipboard?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        Clipboard.Clear();
                        Clipboard.SetData(DataFormats.Text, "PAGESIZES : " + height.ToString("0.00") + ":" + Width.ToString("0.00"));
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtGoToPdfPage_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int intPageNo = 0;
                if (int.TryParse(txtGoToPdfPage.Text.Trim(), out intPageNo))
                {
                    if (intPageNo <= gdViewer.PageCount)
                    {
                        gdViewer.DisplayFrame(intPageNo);
                    }
                    else
                    {
                        MessageBox.Show("Given Page No. not found", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Page No.", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        private void btnExportToPdf_Click(object sender, EventArgs e)
        {
            try
            {
                using (FolderBrowserDialog objFolDlg = new FolderBrowserDialog())
                {
                    if (objFolDlg.ShowDialog() == DialogResult.OK)
                    {
                        Cursor = Cursors.WaitCursor;

                        string strPdfName = objFolDlg.SelectedPath + "\\" + txtTAN.Text + "_Reactions.pdf";

                        ExperimentalProceduresExportToPdf exportPdf = new ExperimentalProceduresExportToPdf();

                        TAN_Reactions_Pdf = NarrativesDB.GetTANReactionsForExportOnTANID(TAN_ID);
                        DataTable tanFindings = NarrativesDB.GetTANFindingsOnTANID(TAN_ID);

                        //DataTable dtTANReactions = IndxReactNarrDAL.NarrativesDB.GetTANReactionsForExportOnTANID(TAN_ID);
                        if (exportPdf.ExportTANData(TANDetails, TAN_Reactions_Pdf, tanFindings, strPdfName))
                        {
                            Cursor = Cursors.Default;
                            Process.Start(strPdfName);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Cursor = Cursors.Default;
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnTANComplete_Click(object sender, EventArgs e)
        {
            string ErrMsg = string.Empty;
            try
            {
                //Validate Reaction complete status
                if (ValidatieReactionsCompleteStatus(out ErrMsg))
                {
                    DialogResult diaRes = MessageBox.Show("Do you want to complete the TAN?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                    if (diaRes == DialogResult.Yes)
                    {
                        using (frmTaskComments taskComments = new frmTaskComments())
                        {
                            taskComments.TaskName = "TASK COMPLETE";
                            taskComments.TAN_ID = TAN_ID;

                            if (taskComments.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                            {
                                //Update Task Status and Close TAN
                                TaskStatus tskStatus = new TaskStatus();
                                tskStatus.TaskComments = taskComments.txtTaskComments.Text.Trim();
                                tskStatus.Task_ID = Task_ID;
                                //tskStatus.Role_ID = GlobalVariables.RoleID;
                                tskStatus.UR_ID = GlobalVariables.URID;
                                tskStatus.TaskAllocation_ID = TaskAlloc_ID;
                                tskStatus.TaskStatusName = "SET COMPLETE";
                                if (TaskManagementDB.UpdateUserTaskStatus(tskStatus))
                                {
                                    this.Close();
                                }
                                else
                                {
                                    MessageBox.Show("Error in TAN complete", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show(ErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnRejectTAN_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult diaRes = MessageBox.Show("Do you want to reject the TAN?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (diaRes == DialogResult.Yes)
                {
                    using (frmTaskComments taskComments = new frmTaskComments())
                    {
                        taskComments.TaskName = "TASK REJECT";
                        taskComments.TAN_ID = TAN_ID;
                        if (taskComments.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                        {
                            //Update Task Status and Close TAN
                            TaskStatus tskStatus = new TaskStatus();
                            tskStatus.TaskComments = taskComments.txtTaskComments.Text.Trim();
                            tskStatus.Task_ID = Task_ID;
                            //taskStatus.Role_ID = GlobalVariables.RoleID;
                            tskStatus.UR_ID = GlobalVariables.URID;
                            tskStatus.TaskAllocation_ID = TaskAlloc_ID;
                            tskStatus.TaskStatusName = "SET REJECT";
                            if (TaskManagementDB.UpdateUserTaskStatus(tskStatus))
                            {
                                this.Close();
                            }
                            else
                            {
                                MessageBox.Show("Error in TAN reject", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtSrchProduct_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == 13)
                {
                    // TreeNode[] node = tvReactions.Nodes.Find(txtSrchProduct.Text, true);

                    string strSrch = "nar" + " " + txtSrchProduct.Text.Trim();
                    //if (!strSrch.Contains("-"))
                    //strSrch = strSrch + "-1";

                    TreeNode tnode = tvReactions.Nodes[0].Nodes.OfType<TreeNode>()
                                 .FirstOrDefault(node => node.Name.Equals(strSrch));

                    if (tnode != null)
                    {
                        int rxnID = 0;
                        int.TryParse(tnode.Tag.ToString(), out rxnID);
                        SaveCurrentReactionAndMoveToReaction(rxnID, tnode.Index);
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnExportToExcel_Click(object sender, EventArgs e)
        {
            try
            {
                using (FolderBrowserDialog flgDlg = new FolderBrowserDialog())
                {
                    if (flgDlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        Cursor = Cursors.WaitCursor;

                        TAN_Reactions_FR = NarrativesDB.GetTANReactionsOnTANID(TAN_ID);
                        if (TAN_Reactions_FR != null && TAN_Reactions_FR.Rows.Count > 0)
                        {
                            string fileName = System.IO.Path.Combine(flgDlg.SelectedPath, txtTAN.Text.Trim() + ".xls");

                            if (NarrTextExcelExport.ExportExperimentalProcedureDataToExcelFile(txtTAN.Text, txtCAN.Text, TAN_Reactions_FR, TAN_Documents, fileName))
                            {
                                Cursor = Cursors.Default;
                                MessageBox.Show("Exported to excel file successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else
                            {
                                Cursor = Cursors.Default;
                                MessageBox.Show("Error in excel file export", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Cursor = Cursors.Default;
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnExportToText_Click(object sender, EventArgs e)
        {
            try
            {
                //Get TAN Reactions and bind to TreeView
                using (FolderBrowserDialog flgDlg = new FolderBrowserDialog())
                {
                    if (flgDlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        Cursor = Cursors.WaitCursor;

                        TAN_Reactions_FR = NarrativesDB.GetTANReactionsOnTANID(TAN_ID);
                        if (TAN_Reactions_FR != null && TAN_Reactions_FR.Rows.Count > 0)
                        {
                            string fileName = System.IO.Path.Combine(flgDlg.SelectedPath, txtTAN.Text.Trim() + ".txt");
                            if (NarrTextExcelExport.ExportExperimentalProcedureDataToTextFile(txtTAN.Text, txtCAN.Text, TAN_Reactions_FR, TAN_Documents, fileName))
                            {
                                Cursor = Cursors.Default;
                                MessageBox.Show("Exported to text file successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else
                            {
                                Cursor = Cursors.Default;
                                MessageBox.Show("Error in text file export", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Cursor = Cursors.Default;
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnFindReplace_Click(object sender, EventArgs e)
        {
            try
            {
                TAN_Reactions_FR = NarrativesDB.GetTANReactionsOnTANID(TAN_ID);
                if (TAN_Reactions_FR != null)
                {
                    frmFindAndReplace findReplace = new frmFindAndReplace();
                    findReplace.TAN_Reactions_FR = TAN_Reactions_FR;
                    findReplace.TAN_Findings_FR = NarrativesDB.GetTANFindingsOnTANID(TAN_ID);
                    findReplace.TAN_ID = TAN_ID;
                    findReplace.TAN_Name = TAN_Name;

                    if (findReplace.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        TAN_Reactions = IndxReactNarrDAL.NarrativesDB.GetTANReactionsOnTANID_ForTreeView(TAN_ID);

                        //Reload TAN Reactions in the background
                        TAN_Reactions_FR = null;
                        TAN_Reactions_Pdf = null;
                        LoadTANReactionsForFindReplaceAndPdfInBackGround();

                        //Set values to Reaction Usercontrol
                        ucExpProcCuration.TAN_Reactions = TAN_Reactions;

                        lblSaveStatus.Text = "";

                        GetRxnDataAndBindToUserControl(selectedRxnID);

                        //Refresh selected reaction                   
                        SelectReactionNodeInTheTreeView(selectedNodeIndx);
                    }
                }
                else
                {
                    MessageBox.Show("TAN Reactions loading in progress. Please try later.", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        TreeNode tn;
        private void frmNarrCuration_New_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Control && e.KeyCode == Keys.F)//Find and Replace shortcut
                {
                    btnFindReplace_Click(null, null);
                }
                else if (e.KeyData == (Keys.Control | Keys.S))//Save shortcut
                {
                    btnSave_Click(null, null);
                }
                else if (e.KeyData == (Keys.Control | Keys.Up))//Previous shortcut
                {
                    btnPrevious_Click(null, null);
                }
                else if (e.KeyData == (Keys.Control | Keys.Down))//Next shortcut
                {
                    btnNext_Click(null, null);
                }
                else if (e.KeyData == (Keys.Control | Keys.Left))//First shortcut
                {
                    btnFirst_Click(null, null);
                }
                else if (e.KeyData == (Keys.Control | Keys.Right))//Last shortcut
                {
                    btnLast_Click(null, null);
                }
                else if (e.KeyCode == Keys.Up)
                {
                    //selectedNodeIndx = selectedNodeIndx - 1;

                    //if (selectedNodeIndx < 0)
                    //{
                    //    selectedNodeIndx = 0;
                    //}

                    //if (selectedNodeIndx <= tvReactions.Nodes[0].Nodes.Count)
                    //{
                    //    tn = tvReactions.Nodes[0].Nodes[selectedNodeIndx];
                    //    if (tn != null)
                    //    {
                    //        int rxnID = 0;
                    //        int.TryParse(tn.Tag.ToString(), out rxnID);
                    //        selectedRxnID = rxnID;
                    //        SaveCurrentReactionAndMoveToReaction(rxnID, selectedNodeIndx);
                    //    }
                    //}
                }
                else if (e.KeyCode == Keys.Down)
                {
                    //selectedNodeIndx = selectedNodeIndx + 1;
                    //if (selectedNodeIndx > tvReactions.Nodes[0].Nodes.Count)
                    //{
                    //    selectedNodeIndx = tvReactions.Nodes[0].Nodes.Count - 1;
                    //}

                    //if (selectedNodeIndx < tvReactions.Nodes[0].Nodes.Count)
                    //{
                    //    tn = tvReactions.Nodes[0].Nodes[selectedNodeIndx];
                    //    if (tn != null)
                    //    {
                    //        int rxnID = 0;
                    //        int.TryParse(tn.Tag.ToString(), out rxnID);
                    //        selectedRxnID = rxnID;
                    //        SaveCurrentReactionAndMoveToReaction(rxnID, selectedNodeIndx);
                    //    }
                    //}
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnHideSplChars_Click(object sender, EventArgs e)
        {
            try
            {
                if (pnlSplChars.Visible == true)
                {
                    pnlSplChars.Visible = false;
                }
                else
                {
                    pnlSplChars.Visible = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnTANReport_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmTANReportView objTanReport = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMTANREPORTVIEW")
                    {
                        objTanReport = (frmTANReportView)frm;
                        blFrmOpen = true;
                        objTanReport.TAN_ID = TAN_ID;
                        objTanReport.TAN_Name = TAN_Name;
                        objTanReport.Show();
                        objTanReport.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objTanReport = new frmTANReportView();
                    objTanReport.TAN_ID = TAN_ID;
                    objTanReport.TAN_Name = TAN_Name;
                    objTanReport.MdiParent = this.Parent as Form;
                    objTanReport.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #region Reaction Navigation Button Events

        int currRecIndex = 0;
        int MaxRecCnt = 0;
        bool blValidRxn = false;

        private void numGotoRecord_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (blValidRxn)
                {
                    if (numGotoRecord.Value > 0)
                    {
                        Cursor = Cursors.WaitCursor;

                        currRecIndex = Convert.ToInt32(numGotoRecord.Value);
                        tn = tvReactions.Nodes[0].Nodes[currRecIndex - 1];
                        if (tn != null)
                        {
                            int rxnID = 0;
                            int.TryParse(tn.Tag.ToString(), out rxnID);
                            selectedRxnID = rxnID;
                            SaveCurrentReactionAndMoveToReaction(rxnID, currRecIndex - 1);
                        }
                        Cursor = Cursors.Default;
                    }
                }
                else
                {
                    //Show Total No.of Reactions with current Reaction index
                    lblRxnCountValue.Text = currRecIndex + " / " + numGotoRecord.Maximum.ToString();
                    lblRxnCountValue.Refresh();

                    if (TAN_Reactions.Rows.Count == 0)
                    {
                        lblRxnCountValue.Text = "0 / 0";
                        lblRxnCountValue.Refresh();
                    }

                    Cursor = Cursors.Default;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void numGotoRecord_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                string strErrMSg = "";
                blValidRxn = false;

                if (chkRxnComplete.Checked)
                {
                    if (RXN_ID > 0 && !ucExpProcCuration.ValidateNarrReactionData(chkSkipValidations.Checked, out strErrMSg))
                    {
                        if (!string.IsNullOrEmpty(strErrMSg.Trim()))
                        {
                            MessageBox.Show("Errors in the Reaction. Clear the below errors before moving to another reaction\r\n\r\n" + strErrMSg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            e.Handled = true;
                        }
                    }
                }

                blValidRxn = true;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            try
            {
                string strErrMsg = "";
                blValidRxn = false;

                if (chkRxnComplete.Checked)
                {
                    if (RXN_ID > 0 && !ucExpProcCuration.ValidateNarrReactionData(chkSkipValidations.Checked, out strErrMsg))
                    {
                        MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                blValidRxn = true;

                currRecIndex = 1;
                numGotoRecord.Value = currRecIndex;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                string strErrMsg = "";
                blValidRxn = false;

                if (chkRxnComplete.Checked)
                {
                    if (RXN_ID > 0 && !ucExpProcCuration.ValidateNarrReactionData(chkSkipValidations.Checked, out strErrMsg))
                    {
                        MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                blValidRxn = true;
                if (currRecIndex <= MaxRecCnt && currRecIndex > 1)
                {
                    currRecIndex = (currRecIndex - 1);
                }
                numGotoRecord.Value = currRecIndex;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                string strErrMsg = "";
                blValidRxn = false;

                if (chkRxnComplete.Checked)
                {
                    if (RXN_ID > 0 && !ucExpProcCuration.ValidateNarrReactionData(chkSkipValidations.Checked, out strErrMsg))
                    {
                        MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                blValidRxn = true;
                if (currRecIndex < MaxRecCnt)
                {
                    currRecIndex = currRecIndex + 1;
                }
                else if (currRecIndex == MaxRecCnt)
                {
                    currRecIndex = MaxRecCnt;
                }
                numGotoRecord.Value = currRecIndex;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            try
            {
                string strErrMsg = "";
                blValidRxn = false;

                if (chkRxnComplete.Checked)
                {
                    if (RXN_ID > 0 && !ucExpProcCuration.ValidateNarrReactionData(chkSkipValidations.Checked, out strErrMsg))
                    {
                        MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;                        
                    }
                }

                blValidRxn = true;

                currRecIndex = MaxRecCnt;
                numGotoRecord.Value = currRecIndex;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        private void frmExpProceduresCuration_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                if ((GlobalVariables.RoleName == "ANALYST" || GlobalVariables.RoleName == "REVIEW ANALYST" || GlobalVariables.RoleName == "QUALITY ANALYST") &&
                     this.ParentForm != null)
                {
                    using (frmMDIMain frm = this.ParentForm as frmMDIMain)
                    {
                        if (frm != null)
                        {
                            frm.loadTANtoolStripMenuItem_Click(null, null);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnReviewRXN_Click(object sender, EventArgs e)
        {
            try
            {
                //using (frmReviewProcSteps objReviewProcSteps = new frmReviewProcSteps())
                //{
                //    objReviewProcSteps.TANReactions = TAN_Reactions.Copy();
                //    if (objReviewProcSteps.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                //    {
                //        //Get New Reaction Data and bind to usercontrol
                //        GetRxnDataAndBindToUserControl(RXN_ID);
                //    }
                //}

                frmReviewProcSteps objReviewProcSteps = null;

                bool frmOpen = false;
                FormCollection frmColl = Application.OpenForms;
                foreach (Form objfrm in frmColl)
                {
                    if (objfrm.Name.ToUpper() == "FRMREVIEWPROCSTEPS")
                    {
                        objReviewProcSteps = (frmReviewProcSteps)objfrm;
                        objReviewProcSteps.TANReactions = TAN_Reactions.Copy();
                        objReviewProcSteps.TAN_ID = TAN_ID;
                        objReviewProcSteps.TAN_Name = TAN_Name;
                        objReviewProcSteps.WindowState = FormWindowState.Maximized;
                        objReviewProcSteps.Show();
                        frmOpen = true;
                        break;
                    }
                }
                if (!frmOpen)
                {
                    objReviewProcSteps = new frmReviewProcSteps();
                    objReviewProcSteps.FormClosed += new FormClosedEventHandler(frm2_FormClosed);
                    objReviewProcSteps.TANReactions = TAN_Reactions.Copy();
                    objReviewProcSteps.TAN_ID = TAN_ID;
                    objReviewProcSteps.TAN_Name = TAN_Name;
                    objReviewProcSteps.Show(this);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void frm2_FormClosed(object sender, FormClosedEventArgs e)
        {

            try
            {
                //Get New Reaction Data and bind to usercontrol
                GetRxnDataAndBindToUserControl(RXN_ID);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnReveiwTANFindings_Click(object sender, EventArgs e)
        {
            try
            {
                //using (frmReviewRxnFindings objReviewFindings = new frmReviewRxnFindings())
                //{
                //    objReviewFindings.TANReactions = TAN_Reactions.Copy();
                //    if (objReviewFindings.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                //    {
                //        //Get New Reaction Data and bind to usercontrol
                //        GetRxnDataAndBindToUserControl(RXN_ID);
                //    }
                //}

                frmReviewRxnFindings objReviewFindings = null;

                bool frmOpen = false;
                FormCollection frmColl = Application.OpenForms;
                foreach (Form objfrm in frmColl)
                {
                    if (objfrm.Name.ToUpper() == "FRMREVIEWRXNFINDINGS")
                    {
                        objReviewFindings = (frmReviewRxnFindings)objfrm;
                        objReviewFindings.TANReactions = TAN_Reactions.Copy();
                        objReviewFindings.WindowState = FormWindowState.Maximized;
                        objReviewFindings.Show();
                        frmOpen = true;
                        break;
                    }
                }
                if (!frmOpen)
                {
                    objReviewFindings = new frmReviewRxnFindings();
                    objReviewFindings.FormClosed += new FormClosedEventHandler(frm2_FormClosed);
                    objReviewFindings.TANReactions = TAN_Reactions.Copy();
                    objReviewFindings.Show(this);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        bool blFormClose = false;
        private void frmExpProceduresCuration_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (blFormClose == false)
                {
                    e.Cancel = true;

                    //Validate Reaction Data
                    if (chkRxnComplete.Checked)
                    {
                        string strErrMsg = "";
                        if (!ucExpProcCuration.ValidateNarrReactionData(chkSkipValidations.Checked, out strErrMsg))
                        {
                            MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    //Save Reaction data
                    NarrReactionsBO narRxnData = ucExpProcCuration.GetNarrReactionDataFromUserControl();
                    if (narRxnData != null)
                    {
                        //Reaction Complete Status
                        narRxnData.IsRxnCompleted = chkRxnComplete.Checked ? "Y" : "N";

                        //Update Reaction data
                        if (NarrativesDB.UpdateExperimentalProcReactionData(narRxnData))
                        {
                            //Update Reaction Findings
                            if (narRxnData.ReactionFindings != null)
                            {
                                NarrativesDB.UpdateReactionFindings(narRxnData.ReactionFindings);
                            }
                        }
                    }

                    blFormClose = true;
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvRxnSubsts_Products_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dgvRxnSubsts_Products.Rows.Count > 0)
                {
                    if (dgvRxnSubsts_Products.Rows.Count > 1)
                    {
                        if (dgvRxnSubsts_Products.SelectedRows.Count == 1)
                        {
                            ucExpProcCuration.SelectedCompound = dgvRxnSubsts_Products.SelectedRows[0].Cells[colSubstID_Prod.Name].Value.ToString();
                        }
                    }
                    else if (dgvRxnSubsts_Products.Rows.Count == 1)
                    {
                        ucExpProcCuration.SelectedCompound = dgvRxnSubsts_Products.Rows[0].Cells[colSubstID_Prod.Name].Value.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsMnuItemPageLabelBlank_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvTANDocuments.Rows.Count > 0)
                {
                    if (dgvTANDocuments.SelectedRows.Count == 1)
                    {
                        if (dgvTANDocuments.SelectedRows[0].Cells[colDocNo.Name].Value.ToString() != "doc 1")
                        {
                            DialogResult diaRes = MessageBox.Show("Do you want to set Pagel Label blank for the selected document?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            if (diaRes == System.Windows.Forms.DialogResult.Yes)
                            {
                                //Update TAN document Page Label blank and refresh TAN Documents
                                int tanDocID = Convert.ToInt32(dgvTANDocuments.SelectedRows[0].Cells[colDocID.Name].Value.ToString());
                                if (NarrativesDB.UpdateTANDocumentPageLabelBlank(TAN_ID, tanDocID, 'Y'))
                                {
                                    //Get TAN Documents and bind to grid
                                    TAN_Documents = NarrativesDB.GetTANDocumentsOnTANID(TAN_ID);
                                    BindTanDocumentsToGrid();

                                    ucExpProcCuration.TAN_Documents = TAN_Documents;

                                    //Refresh reaction data
                                    //Get Reaction Data and bind to usercontrol
                                    GetRxnDataAndBindToUserControl(RXN_ID);
                                }
                            }
                        }
                        else
                        {
                            string Msg = "Invalid in setting page label as blank for " + dgvTANDocuments.SelectedRows[0].Cells[colDocNo.Name].Value.ToString();
                            MessageBox.Show(Msg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void resetPageLabelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvTANDocuments.Rows.Count > 0)
                {
                    if (dgvTANDocuments.SelectedRows.Count == 1)
                    {
                        if (dgvTANDocuments.SelectedRows[0].Cells[colDocNo.Name].Value.ToString() != "doc 1")
                        {
                            DialogResult diaRes = MessageBox.Show("Do you want to reset Pagel Label blank for the selected document?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            if (diaRes == System.Windows.Forms.DialogResult.Yes)
                            {
                                //First save reaction data before reset
                                ucExpProcCuration.chkEmptyPgLabel.Checked = false;
                                SaveExistingReactionData();

                                //Update TAN document Page Label blank and refresh TAN Documents
                                int tanDocID = Convert.ToInt32(dgvTANDocuments.SelectedRows[0].Cells[colDocID.Name].Value.ToString());
                                if (NarrativesDB.UpdateTANDocumentPageLabelBlank(TAN_ID, tanDocID, 'N'))
                                {
                                    //Get TAN Documents and bind to grid
                                    TAN_Documents = NarrativesDB.GetTANDocumentsOnTANID(TAN_ID);
                                    BindTanDocumentsToGrid();

                                    ucExpProcCuration.TAN_Documents = TAN_Documents;

                                    //Refresh reaction data
                                    //Get Reaction Data and bind to usercontrol
                                    GetRxnDataAndBindToUserControl(RXN_ID);
                                }
                            }
                        }
                        else
                        {
                            string Msg = "Invalid in Re-setting page label as blank for " + dgvTANDocuments.SelectedRows[0].Cells[colDocNo.Name].Value.ToString();
                            MessageBox.Show(Msg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void setCombinedDocumentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvTANDocuments.Rows.Count > 0)
                {
                    if (dgvTANDocuments.SelectedRows.Count == 1)
                    {
                        if (dgvTANDocuments.SelectedRows[0].Cells[colDocNo.Name].Value.ToString() == "doc 1")
                        {
                            DialogResult diaRes = MessageBox.Show("Do you want to set selected document as Combined document?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            if (diaRes == System.Windows.Forms.DialogResult.Yes)
                            {
                                //Update TAN document Page Label blank and refresh TAN Documents
                                int tanDocID = Convert.ToInt32(dgvTANDocuments.SelectedRows[0].Cells[colDocID.Name].Value.ToString());
                                if (NarrativesDB.UpdateCommbinedDocStatus(TAN_ID, tanDocID, 'Y'))
                                {
                                    //Get TAN Documents and bind to grid
                                    TAN_Documents = NarrativesDB.GetTANDocumentsOnTANID(TAN_ID);
                                    BindTanDocumentsToGrid();

                                    ucExpProcCuration.TAN_Documents = TAN_Documents;

                                    //Refresh reaction data
                                    //Get Reaction Data and bind to usercontrol
                                    GetRxnDataAndBindToUserControl(RXN_ID);
                                }
                            }
                        }
                        else
                        {
                            string Msg = dgvTANDocuments.SelectedRows[0].Cells[colDocNo.Name].Value.ToString() + " is invalid to set as combined document";
                            MessageBox.Show(Msg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void resetCombinedDocumentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvTANDocuments.Rows.Count > 0)
                {
                    if (dgvTANDocuments.SelectedRows.Count == 1)
                    {
                        if (dgvTANDocuments.SelectedRows[0].Cells[colDocNo.Name].Value.ToString() == "doc 1")
                        {
                            DialogResult diaRes = MessageBox.Show("Do you want to set selected document as Combined document?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            if (diaRes == System.Windows.Forms.DialogResult.Yes)
                            {
                                //First save reaction data before reset
                                ucExpProcCuration.chkEmptyPgLabel.Checked = false;
                                SaveExistingReactionData();
                               
                                //Update TAN document Page Label blank and refresh TAN Documents
                                int tanDocID = Convert.ToInt32(dgvTANDocuments.SelectedRows[0].Cells[colDocID.Name].Value.ToString());
                                if (NarrativesDB.UpdateCommbinedDocStatus(TAN_ID, tanDocID, 'N'))
                                {
                                    //Get TAN Documents and bind to grid
                                    TAN_Documents = NarrativesDB.GetTANDocumentsOnTANID(TAN_ID);
                                    BindTanDocumentsToGrid();

                                    ucExpProcCuration.TAN_Documents = TAN_Documents;

                                    //Refresh reaction data
                                    //Get Reaction Data and bind to usercontrol
                                    GetRxnDataAndBindToUserControl(RXN_ID);
                                }
                            }
                        }
                        else
                        {
                            string Msg = dgvTANDocuments.SelectedRows[0].Cells[colDocNo.Name].Value.ToString() + " is invalid to Reset as combined document";
                            MessageBox.Show(Msg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void SaveExistingReactionData()
        {
            try
            {
                NarrReactionsBO narRxnData = ucExpProcCuration.GetNarrReactionDataFromUserControl();
                if (narRxnData != null)
                {
                    narRxnData.IsRxnCompleted = chkRxnComplete.Checked ? "Y" : "N";
                    //Save Reaction data automatically
                    if (NarrativesDB.UpdateExperimentalProcReactionData(narRxnData))
                    {
                        //Update Reaction Findings
                        if (narRxnData.ReactionFindings != null)
                        {
                            NarrativesDB.UpdateReactionFindings(narRxnData.ReactionFindings);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
