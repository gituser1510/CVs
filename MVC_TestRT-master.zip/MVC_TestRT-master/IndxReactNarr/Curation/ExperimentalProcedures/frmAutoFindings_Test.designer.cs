﻿namespace IndxReactNarr.Curation.ExperimentalProcedures
{
    partial class frmAutoFindings_Test
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvRxnFindings = new System.Windows.Forms.DataGridView();
            this.colFindingType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRefCompound = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFindingValue = new DataGridViewRichTextBox.DataGridViewRichTextBoxColumn();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRxnFindings)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.dgvRxnFindings);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(826, 410);
            this.pnlMain.TabIndex = 0;
            // 
            // dgvRxnFindings
            // 
            this.dgvRxnFindings.AllowUserToAddRows = false;
            this.dgvRxnFindings.AllowUserToDeleteRows = false;
            this.dgvRxnFindings.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvRxnFindings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRxnFindings.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colFindingType,
            this.colRefCompound,
            this.colFindingValue});
            this.dgvRxnFindings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvRxnFindings.Location = new System.Drawing.Point(0, 0);
            this.dgvRxnFindings.Name = "dgvRxnFindings";
            this.dgvRxnFindings.ReadOnly = true;
            this.dgvRxnFindings.RowTemplate.Height = 60;
            this.dgvRxnFindings.Size = new System.Drawing.Size(826, 410);
            this.dgvRxnFindings.TabIndex = 0;
            // 
            // colFindingType
            // 
            this.colFindingType.HeaderText = "FindingType";
            this.colFindingType.Name = "colFindingType";
            this.colFindingType.ReadOnly = true;
            // 
            // colRefCompound
            // 
            this.colRefCompound.HeaderText = "RefCompound";
            this.colRefCompound.Name = "colRefCompound";
            this.colRefCompound.ReadOnly = true;
            // 
            // colFindingValue
            // 
            this.colFindingValue.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colFindingValue.HeaderText = "FindingValue";
            this.colFindingValue.Name = "colFindingValue";
            this.colFindingValue.ReadOnly = true;
            // 
            // frmAutoFindings_Test
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(826, 410);
            this.Controls.Add(this.pnlMain);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAutoFindings_Test";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reaction Auto Findings Testing";
            this.Load += new System.EventHandler(this.frmAutoFindings_Test_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRxnFindings)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.DataGridView dgvRxnFindings;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFindingType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRefCompound;
        private DataGridViewRichTextBox.DataGridViewRichTextBoxColumn colFindingValue;
    }
}