﻿namespace IndxReactNarr.Curation.ExperimentalProcedures
{
    partial class frmReviewTanRxnFindings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlBody = new System.Windows.Forms.Panel();
            this.spltgrid = new System.Windows.Forms.SplitContainer();
            this.pnlSelection = new System.Windows.Forms.Panel();
            this.pnlchcklst = new System.Windows.Forms.Panel();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnGet = new System.Windows.Forms.Button();
            this.chklstTANs = new System.Windows.Forms.CheckedListBox();
            this.lblSecondaryReactions = new System.Windows.Forms.Label();
            this.pnlsrch = new System.Windows.Forms.Panel();
            this.lblTAN = new System.Windows.Forms.Label();
            this.txtTANSrch = new System.Windows.Forms.TextBox();
            this.dgvFindings = new System.Windows.Forms.DataGridView();
            this.colTanID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTanName = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colRxnID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnNUM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnSeq = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnNarID = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colFindingType = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colFindingID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRefSub = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFindingVal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uchrtbPreview = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.btnGetList = new System.Windows.Forms.Button();
            this.lblBNo = new System.Windows.Forms.Label();
            this.txtBNo = new System.Windows.Forms.TextBox();
            this.lblBatch = new System.Windows.Forms.Label();
            this.txtShipmentName = new System.Windows.Forms.TextBox();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewAutoFilterTextBoxColumn1 = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.pnlMain.SuspendLayout();
            this.pnlBody.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spltgrid)).BeginInit();
            this.spltgrid.Panel1.SuspendLayout();
            this.spltgrid.Panel2.SuspendLayout();
            this.spltgrid.SuspendLayout();
            this.pnlSelection.SuspendLayout();
            this.pnlchcklst.SuspendLayout();
            this.pnlsrch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFindings)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.pnlBody);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1020, 650);
            this.pnlMain.TabIndex = 0;
            // 
            // pnlBody
            // 
            this.pnlBody.Controls.Add(this.spltgrid);
            this.pnlBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlBody.Location = new System.Drawing.Point(0, 37);
            this.pnlBody.Name = "pnlBody";
            this.pnlBody.Size = new System.Drawing.Size(1020, 613);
            this.pnlBody.TabIndex = 1;
            // 
            // spltgrid
            // 
            this.spltgrid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.spltgrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spltgrid.Location = new System.Drawing.Point(0, 0);
            this.spltgrid.Name = "spltgrid";
            this.spltgrid.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spltgrid.Panel1
            // 
            this.spltgrid.Panel1.Controls.Add(this.pnlSelection);
            // 
            // spltgrid.Panel2
            // 
            this.spltgrid.Panel2.Controls.Add(this.dgvFindings);
            this.spltgrid.Panel2.Controls.Add(this.uchrtbPreview);
            this.spltgrid.Size = new System.Drawing.Size(1020, 613);
            this.spltgrid.SplitterDistance = 125;
            this.spltgrid.TabIndex = 0;
            // 
            // pnlSelection
            // 
            this.pnlSelection.BackColor = System.Drawing.Color.White;
            this.pnlSelection.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlSelection.Controls.Add(this.pnlchcklst);
            this.pnlSelection.Controls.Add(this.pnlsrch);
            this.pnlSelection.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSelection.Location = new System.Drawing.Point(0, 0);
            this.pnlSelection.Name = "pnlSelection";
            this.pnlSelection.Size = new System.Drawing.Size(1018, 151);
            this.pnlSelection.TabIndex = 2;
            // 
            // pnlchcklst
            // 
            this.pnlchcklst.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlchcklst.Controls.Add(this.btnUpdate);
            this.pnlchcklst.Controls.Add(this.btnReset);
            this.pnlchcklst.Controls.Add(this.btnGet);
            this.pnlchcklst.Controls.Add(this.chklstTANs);
            this.pnlchcklst.Controls.Add(this.lblSecondaryReactions);
            this.pnlchcklst.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlchcklst.Location = new System.Drawing.Point(0, 30);
            this.pnlchcklst.Name = "pnlchcklst";
            this.pnlchcklst.Size = new System.Drawing.Size(1014, 117);
            this.pnlchcklst.TabIndex = 1;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdate.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.Location = new System.Drawing.Point(933, 62);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 25);
            this.btnUpdate.TabIndex = 69;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnReset
            // 
            this.btnReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReset.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(933, 32);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 25);
            this.btnReset.TabIndex = 68;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnGet
            // 
            this.btnGet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGet.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGet.Location = new System.Drawing.Point(933, 4);
            this.btnGet.Name = "btnGet";
            this.btnGet.Size = new System.Drawing.Size(75, 25);
            this.btnGet.TabIndex = 67;
            this.btnGet.Text = "Get";
            this.btnGet.UseVisualStyleBackColor = true;
            this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
            // 
            // chklstTANs
            // 
            this.chklstTANs.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chklstTANs.CheckOnClick = true;
            this.chklstTANs.ColumnWidth = 110;
            this.chklstTANs.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chklstTANs.FormattingEnabled = true;
            this.chklstTANs.Location = new System.Drawing.Point(108, 4);
            this.chklstTANs.MultiColumn = true;
            this.chklstTANs.Name = "chklstTANs";
            this.chklstTANs.ScrollAlwaysVisible = true;
            this.chklstTANs.Size = new System.Drawing.Size(819, 84);
            this.chklstTANs.TabIndex = 66;
            this.chklstTANs.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chklstRxns_ItemCheck);
            // 
            // lblSecondaryReactions
            // 
            this.lblSecondaryReactions.AutoSize = true;
            this.lblSecondaryReactions.BackColor = System.Drawing.Color.White;
            this.lblSecondaryReactions.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecondaryReactions.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblSecondaryReactions.Location = new System.Drawing.Point(20, 8);
            this.lblSecondaryReactions.Name = "lblSecondaryReactions";
            this.lblSecondaryReactions.Size = new System.Drawing.Size(84, 17);
            this.lblSecondaryReactions.TabIndex = 65;
            this.lblSecondaryReactions.Text = "Select TANs";
            // 
            // pnlsrch
            // 
            this.pnlsrch.Controls.Add(this.lblTAN);
            this.pnlsrch.Controls.Add(this.txtTANSrch);
            this.pnlsrch.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlsrch.Location = new System.Drawing.Point(0, 0);
            this.pnlsrch.Name = "pnlsrch";
            this.pnlsrch.Size = new System.Drawing.Size(1014, 30);
            this.pnlsrch.TabIndex = 0;
            // 
            // lblTAN
            // 
            this.lblTAN.AutoSize = true;
            this.lblTAN.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTAN.Location = new System.Drawing.Point(21, 6);
            this.lblTAN.Name = "lblTAN";
            this.lblTAN.Size = new System.Drawing.Size(83, 17);
            this.lblTAN.TabIndex = 12;
            this.lblTAN.Text = "TAN Search";
            // 
            // txtTANSrch
            // 
            this.txtTANSrch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTANSrch.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.txtTANSrch.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTANSrch.ForeColor = System.Drawing.Color.Blue;
            this.txtTANSrch.Location = new System.Drawing.Point(108, 2);
            this.txtTANSrch.Name = "txtTANSrch";
            this.txtTANSrch.Size = new System.Drawing.Size(903, 25);
            this.txtTANSrch.TabIndex = 11;
            this.txtTANSrch.TextChanged += new System.EventHandler(this.txtTANSrch_TextChanged);
            // 
            // dgvFindings
            // 
            this.dgvFindings.AllowUserToAddRows = false;
            this.dgvFindings.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LemonChiffon;
            this.dgvFindings.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvFindings.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvFindings.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            this.dgvFindings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFindings.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTanID,
            this.colTanName,
            this.colRxnID,
            this.colRxnNUM,
            this.colRxnSeq,
            this.colRxnNarID,
            this.colFindingType,
            this.colFindingID,
            this.colRefSub,
            this.colFindingVal});
            this.dgvFindings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvFindings.Location = new System.Drawing.Point(0, 0);
            this.dgvFindings.Name = "dgvFindings";
            this.dgvFindings.Size = new System.Drawing.Size(1018, 413);
            this.dgvFindings.TabIndex = 0;
            this.dgvFindings.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvFindings_CellEndEdit);
            this.dgvFindings.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgvFindings_DataBindingComplete);
            this.dgvFindings.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgvFindings_DataError);
            this.dgvFindings.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvFindings_RowEnter);
            this.dgvFindings.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvFindings_RowPostPaint);
            // 
            // colTanID
            // 
            this.colTanID.DataPropertyName = "TAN_ID";
            this.colTanID.HeaderText = "TanID";
            this.colTanID.Name = "colTanID";
            this.colTanID.Visible = false;
            // 
            // colTanName
            // 
            this.colTanName.DataPropertyName = "TAN_NAME";
            this.colTanName.HeaderText = "TanName";
            this.colTanName.Name = "colTanName";
            this.colTanName.ReadOnly = true;
            this.colTanName.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colRxnID
            // 
            this.colRxnID.DataPropertyName = "RXN_ID";
            this.colRxnID.HeaderText = "RxnID";
            this.colRxnID.Name = "colRxnID";
            this.colRxnID.ReadOnly = true;
            this.colRxnID.Visible = false;
            // 
            // colRxnNUM
            // 
            this.colRxnNUM.DataPropertyName = "RXN_NUM";
            this.colRxnNUM.HeaderText = "NUM";
            this.colRxnNUM.Name = "colRxnNUM";
            this.colRxnNUM.ReadOnly = true;
            this.colRxnNUM.Width = 50;
            // 
            // colRxnSeq
            // 
            this.colRxnSeq.DataPropertyName = "RXN_SEQ";
            this.colRxnSeq.HeaderText = "Seq";
            this.colRxnSeq.Name = "colRxnSeq";
            this.colRxnSeq.ReadOnly = true;
            this.colRxnSeq.Width = 50;
            // 
            // colRxnNarID
            // 
            this.colRxnNarID.DataPropertyName = "RXN_NAR_ID";
            this.colRxnNarID.HeaderText = "NAR";
            this.colRxnNarID.Name = "colRxnNarID";
            this.colRxnNarID.ReadOnly = true;
            this.colRxnNarID.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colFindingType
            // 
            this.colFindingType.DataPropertyName = "FINDING_TYPE";
            this.colFindingType.HeaderText = "FindingType";
            this.colFindingType.Name = "colFindingType";
            this.colFindingType.ReadOnly = true;
            // 
            // colFindingID
            // 
            this.colFindingID.DataPropertyName = "RF_ID";
            this.colFindingID.HeaderText = "FindingID";
            this.colFindingID.Name = "colFindingID";
            this.colFindingID.ReadOnly = true;
            this.colFindingID.Visible = false;
            // 
            // colRefSub
            // 
            this.colRefSub.DataPropertyName = "REFERENCE_SUBSTANCE";
            this.colRefSub.HeaderText = "Ref Comp";
            this.colRefSub.Name = "colRefSub";
            this.colRefSub.ReadOnly = true;
            this.colRefSub.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colFindingVal
            // 
            this.colFindingVal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colFindingVal.DataPropertyName = "FINDING_VALUE";
            this.colFindingVal.HeaderText = "Value";
            this.colFindingVal.Name = "colFindingVal";
            // 
            // uchrtbPreview
            // 
            this.uchrtbPreview.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.uchrtbPreview.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.uchrtbPreview.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uchrtbPreview.HighlightMaterials = false;
            this.uchrtbPreview.Location = new System.Drawing.Point(0, 413);
            this.uchrtbPreview.Name = "uchrtbPreview";
            this.uchrtbPreview.PreserveMultiLines = false;
            this.uchrtbPreview.Size = new System.Drawing.Size(1018, 69);
            this.uchrtbPreview.TabIndex = 1;
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.White;
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlTop.Controls.Add(this.btnGetList);
            this.pnlTop.Controls.Add(this.lblBNo);
            this.pnlTop.Controls.Add(this.txtBNo);
            this.pnlTop.Controls.Add(this.lblBatch);
            this.pnlTop.Controls.Add(this.txtShipmentName);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1020, 37);
            this.pnlTop.TabIndex = 0;
            // 
            // btnGetList
            // 
            this.btnGetList.AutoSize = true;
            this.btnGetList.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGetList.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnGetList.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGetList.Location = new System.Drawing.Point(417, 5);
            this.btnGetList.Name = "btnGetList";
            this.btnGetList.Size = new System.Drawing.Size(94, 25);
            this.btnGetList.TabIndex = 13;
            this.btnGetList.Text = "Get List";
            this.btnGetList.UseVisualStyleBackColor = true;
            this.btnGetList.Click += new System.EventHandler(this.btnGetList_Click);
            // 
            // lblBNo
            // 
            this.lblBNo.AutoSize = true;
            this.lblBNo.Location = new System.Drawing.Point(293, 9);
            this.lblBNo.Name = "lblBNo";
            this.lblBNo.Size = new System.Drawing.Size(69, 17);
            this.lblBNo.TabIndex = 14;
            this.lblBNo.Text = "Batch No.";
            // 
            // txtBNo
            // 
            this.txtBNo.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBNo.ForeColor = System.Drawing.Color.Blue;
            this.txtBNo.Location = new System.Drawing.Point(363, 5);
            this.txtBNo.Name = "txtBNo";
            this.txtBNo.Size = new System.Drawing.Size(36, 25);
            this.txtBNo.TabIndex = 12;
            this.txtBNo.Text = "1";
            this.txtBNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblBatch
            // 
            this.lblBatch.AutoSize = true;
            this.lblBatch.Location = new System.Drawing.Point(5, 9);
            this.lblBatch.Name = "lblBatch";
            this.lblBatch.Size = new System.Drawing.Size(102, 17);
            this.lblBatch.TabIndex = 11;
            this.lblBatch.Text = "Shipment Name";
            // 
            // txtShipmentName
            // 
            this.txtShipmentName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShipmentName.ForeColor = System.Drawing.Color.Blue;
            this.txtShipmentName.Location = new System.Drawing.Point(111, 5);
            this.txtShipmentName.Name = "txtShipmentName";
            this.txtShipmentName.Size = new System.Drawing.Size(169, 25);
            this.txtShipmentName.TabIndex = 9;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "TAN_ID";
            this.dataGridViewTextBoxColumn1.HeaderText = "TanID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.DataPropertyName = "TAN_NAME";
            this.dataGridViewTextBoxColumn2.HeaderText = "TanName";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "RXN_ID";
            this.dataGridViewTextBoxColumn3.HeaderText = "RxnID";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Visible = false;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "RXN_SEQ";
            this.dataGridViewTextBoxColumn4.HeaderText = "RxnSeq";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "RXN_NAR_ID";
            this.dataGridViewTextBoxColumn5.HeaderText = "NAR";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn6.DataPropertyName = "FINDING_VALUE";
            this.dataGridViewTextBoxColumn6.HeaderText = "FindingVal";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewAutoFilterTextBoxColumn1
            // 
            this.dataGridViewAutoFilterTextBoxColumn1.DataPropertyName = "FINDING_TYPE";
            this.dataGridViewAutoFilterTextBoxColumn1.HeaderText = "FindingType";
            this.dataGridViewAutoFilterTextBoxColumn1.Name = "dataGridViewAutoFilterTextBoxColumn1";
            // 
            // frmReviewTanRxnFindings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1020, 650);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmReviewTanRxnFindings";
            this.Text = "Review Tan Rxn Findings";
            this.Load += new System.EventHandler(this.frmReviewTanRxnFindings_Load);
            this.pnlMain.ResumeLayout(false);
            this.pnlBody.ResumeLayout(false);
            this.spltgrid.Panel1.ResumeLayout(false);
            this.spltgrid.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spltgrid)).EndInit();
            this.spltgrid.ResumeLayout(false);
            this.pnlSelection.ResumeLayout(false);
            this.pnlchcklst.ResumeLayout(false);
            this.pnlchcklst.PerformLayout();
            this.pnlsrch.ResumeLayout(false);
            this.pnlsrch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFindings)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Label lblBatch;
        private System.Windows.Forms.TextBox txtShipmentName;
        private System.Windows.Forms.Panel pnlBody;
        private System.Windows.Forms.SplitContainer spltgrid;
        private System.Windows.Forms.DataGridView dgvFindings;
        private System.Windows.Forms.Panel pnlSelection;
        private System.Windows.Forms.Button btnGetList;
        private System.Windows.Forms.Label lblBNo;
        private System.Windows.Forms.TextBox txtBNo;
        private System.Windows.Forms.Panel pnlchcklst;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnGet;
        private System.Windows.Forms.CheckedListBox chklstTANs;
        private System.Windows.Forms.Label lblSecondaryReactions;
        private System.Windows.Forms.Panel pnlsrch;
        private System.Windows.Forms.Label lblTAN;
        private System.Windows.Forms.TextBox txtTANSrch;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn dataGridViewAutoFilterTextBoxColumn1;
        private UserControls.ucHtmlRichText uchrtbPreview;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTanID;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colTanName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnNUM;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnSeq;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colRxnNarID;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colFindingType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFindingID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRefSub;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFindingVal;
    }
}