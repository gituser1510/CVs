﻿namespace IndxReactNarr.Curation.ExperimentalProcedures
{
    partial class frmReviewProcSteps
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlSelection = new System.Windows.Forms.Panel();
            this.chkShowAnalogousRxns = new System.Windows.Forms.CheckBox();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnGet = new System.Windows.Forms.Button();
            this.chklstSecondaryReact = new System.Windows.Forms.CheckedListBox();
            this.txtMainReaction = new System.Windows.Forms.TextBox();
            this.lblSecondaryReactions = new System.Windows.Forms.Label();
            this.lblMainReaction = new System.Windows.Forms.Label();
            this.spltProcSteps = new System.Windows.Forms.SplitContainer();
            this.pnlMainRxn = new System.Windows.Forms.Panel();
            this.lblMainRxnStep = new System.Windows.Forms.Label();
            this.flpnlProcSteps = new System.Windows.Forms.FlowLayoutPanel();
            this.lblOthRxns = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.txtQuickFind = new System.Windows.Forms.TextBox();
            this.btnFindReplace = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlSelection.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spltProcSteps)).BeginInit();
            this.spltProcSteps.Panel1.SuspendLayout();
            this.spltProcSteps.Panel2.SuspendLayout();
            this.spltProcSteps.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.pnlBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlSelection
            // 
            this.pnlSelection.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlSelection.Controls.Add(this.chkShowAnalogousRxns);
            this.pnlSelection.Controls.Add(this.btnReset);
            this.pnlSelection.Controls.Add(this.btnGet);
            this.pnlSelection.Controls.Add(this.chklstSecondaryReact);
            this.pnlSelection.Controls.Add(this.txtMainReaction);
            this.pnlSelection.Controls.Add(this.lblSecondaryReactions);
            this.pnlSelection.Controls.Add(this.lblMainReaction);
            this.pnlSelection.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSelection.Location = new System.Drawing.Point(0, 0);
            this.pnlSelection.Name = "pnlSelection";
            this.pnlSelection.Size = new System.Drawing.Size(1183, 133);
            this.pnlSelection.TabIndex = 0;
            // 
            // chkShowAnalogousRxns
            // 
            this.chkShowAnalogousRxns.AutoSize = true;
            this.chkShowAnalogousRxns.Location = new System.Drawing.Point(380, 4);
            this.chkShowAnalogousRxns.Name = "chkShowAnalogousRxns";
            this.chkShowAnalogousRxns.Size = new System.Drawing.Size(305, 21);
            this.chkShowAnalogousRxns.TabIndex = 65;
            this.chkShowAnalogousRxns.Text = "Show only analogous reactions to main reaction";
            this.chkShowAnalogousRxns.UseVisualStyleBackColor = true;
            this.chkShowAnalogousRxns.CheckStateChanged += new System.EventHandler(this.chkShowAnalogousRxns_CheckStateChanged);
            // 
            // btnReset
            // 
            this.btnReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReset.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(1101, 68);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 25);
            this.btnReset.TabIndex = 64;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnGet
            // 
            this.btnGet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGet.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGet.Location = new System.Drawing.Point(1101, 28);
            this.btnGet.Name = "btnGet";
            this.btnGet.Size = new System.Drawing.Size(75, 25);
            this.btnGet.TabIndex = 63;
            this.btnGet.Text = "Get";
            this.btnGet.UseVisualStyleBackColor = true;
            this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
            // 
            // chklstSecondaryReact
            // 
            this.chklstSecondaryReact.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chklstSecondaryReact.CheckOnClick = true;
            this.chklstSecondaryReact.ColumnWidth = 200;
            this.chklstSecondaryReact.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chklstSecondaryReact.FormattingEnabled = true;
            this.chklstSecondaryReact.Location = new System.Drawing.Point(131, 29);
            this.chklstSecondaryReact.MultiColumn = true;
            this.chklstSecondaryReact.Name = "chklstSecondaryReact";
            this.chklstSecondaryReact.ScrollAlwaysVisible = true;
            this.chklstSecondaryReact.Size = new System.Drawing.Size(964, 100);
            this.chklstSecondaryReact.TabIndex = 62;
            this.chklstSecondaryReact.Tag = "";
            this.chklstSecondaryReact.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chklstSecondaryReact_ItemCheck);
            // 
            // txtMainReaction
            // 
            this.txtMainReaction.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMainReaction.Location = new System.Drawing.Point(131, 4);
            this.txtMainReaction.Name = "txtMainReaction";
            this.txtMainReaction.Size = new System.Drawing.Size(240, 21);
            this.txtMainReaction.TabIndex = 61;
            this.txtMainReaction.TextChanged += new System.EventHandler(this.txtMainReaction_TextChanged);
            // 
            // lblSecondaryReactions
            // 
            this.lblSecondaryReactions.AutoSize = true;
            this.lblSecondaryReactions.BackColor = System.Drawing.Color.White;
            this.lblSecondaryReactions.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecondaryReactions.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblSecondaryReactions.Location = new System.Drawing.Point(1, 31);
            this.lblSecondaryReactions.Name = "lblSecondaryReactions";
            this.lblSecondaryReactions.Size = new System.Drawing.Size(124, 15);
            this.lblSecondaryReactions.TabIndex = 60;
            this.lblSecondaryReactions.Text = "Secondary Reactions";
            // 
            // lblMainReaction
            // 
            this.lblMainReaction.AutoSize = true;
            this.lblMainReaction.BackColor = System.Drawing.Color.White;
            this.lblMainReaction.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMainReaction.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblMainReaction.Location = new System.Drawing.Point(40, 7);
            this.lblMainReaction.Name = "lblMainReaction";
            this.lblMainReaction.Size = new System.Drawing.Size(85, 15);
            this.lblMainReaction.TabIndex = 59;
            this.lblMainReaction.Text = "Main Reaction";
            // 
            // spltProcSteps
            // 
            this.spltProcSteps.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.spltProcSteps.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spltProcSteps.Location = new System.Drawing.Point(0, 133);
            this.spltProcSteps.Name = "spltProcSteps";
            this.spltProcSteps.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spltProcSteps.Panel1
            // 
            this.spltProcSteps.Panel1.Controls.Add(this.pnlMainRxn);
            this.spltProcSteps.Panel1.Controls.Add(this.lblMainRxnStep);
            // 
            // spltProcSteps.Panel2
            // 
            this.spltProcSteps.Panel2.Controls.Add(this.flpnlProcSteps);
            this.spltProcSteps.Panel2.Controls.Add(this.lblOthRxns);
            this.spltProcSteps.Size = new System.Drawing.Size(1183, 395);
            this.spltProcSteps.SplitterDistance = 132;
            this.spltProcSteps.TabIndex = 1;
            // 
            // pnlMainRxn
            // 
            this.pnlMainRxn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlMainRxn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMainRxn.Location = new System.Drawing.Point(0, 23);
            this.pnlMainRxn.Name = "pnlMainRxn";
            this.pnlMainRxn.Size = new System.Drawing.Size(1181, 107);
            this.pnlMainRxn.TabIndex = 2;
            // 
            // lblMainRxnStep
            // 
            this.lblMainRxnStep.BackColor = System.Drawing.Color.AliceBlue;
            this.lblMainRxnStep.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblMainRxnStep.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblMainRxnStep.Location = new System.Drawing.Point(0, 0);
            this.lblMainRxnStep.Name = "lblMainRxnStep";
            this.lblMainRxnStep.Size = new System.Drawing.Size(1181, 23);
            this.lblMainRxnStep.TabIndex = 1;
            this.lblMainRxnStep.Text = "Main Reaction";
            this.lblMainRxnStep.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // flpnlProcSteps
            // 
            this.flpnlProcSteps.AutoScroll = true;
            this.flpnlProcSteps.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flpnlProcSteps.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flpnlProcSteps.Location = new System.Drawing.Point(0, 23);
            this.flpnlProcSteps.Name = "flpnlProcSteps";
            this.flpnlProcSteps.Size = new System.Drawing.Size(1181, 234);
            this.flpnlProcSteps.TabIndex = 0;
            this.flpnlProcSteps.SizeChanged += new System.EventHandler(this.flpnlProcSteps_SizeChanged);
            // 
            // lblOthRxns
            // 
            this.lblOthRxns.BackColor = System.Drawing.Color.AliceBlue;
            this.lblOthRxns.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOthRxns.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblOthRxns.Location = new System.Drawing.Point(0, 0);
            this.lblOthRxns.Name = "lblOthRxns";
            this.lblOthRxns.Size = new System.Drawing.Size(1181, 23);
            this.lblOthRxns.TabIndex = 2;
            this.lblOthRxns.Text = "Other Reactions";
            this.lblOthRxns.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Image = global::IndxReactNarr.Properties.Resources.save_1;
            this.btnSave.Location = new System.Drawing.Point(1101, 1);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 25);
            this.btnSave.TabIndex = 64;
            this.btnSave.Text = "  Save";
            this.btnSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.spltProcSteps);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Controls.Add(this.pnlSelection);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1183, 559);
            this.pnlMain.TabIndex = 2;
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlBottom.Controls.Add(this.label1);
            this.pnlBottom.Controls.Add(this.txtQuickFind);
            this.pnlBottom.Controls.Add(this.btnFindReplace);
            this.pnlBottom.Controls.Add(this.btnClose);
            this.pnlBottom.Controls.Add(this.btnSave);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 528);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(1183, 31);
            this.pnlBottom.TabIndex = 2;
            // 
            // txtQuickFind
            // 
            this.txtQuickFind.BackColor = System.Drawing.SystemColors.Info;
            this.txtQuickFind.Location = new System.Drawing.Point(185, 1);
            this.txtQuickFind.Name = "txtQuickFind";
            this.txtQuickFind.Size = new System.Drawing.Size(391, 25);
            this.txtQuickFind.TabIndex = 67;
            this.txtQuickFind.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQuickFind_KeyPress);
            // 
            // btnFindReplace
            // 
            this.btnFindReplace.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnFindReplace.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFindReplace.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFindReplace.Location = new System.Drawing.Point(3, 2);
            this.btnFindReplace.Name = "btnFindReplace";
            this.btnFindReplace.Size = new System.Drawing.Size(94, 24);
            this.btnFindReplace.TabIndex = 66;
            this.btnFindReplace.TabStop = false;
            this.btnFindReplace.Text = "Find / Replace";
            this.btnFindReplace.UseVisualStyleBackColor = true;
            this.btnFindReplace.Click += new System.EventHandler(this.btnFindReplace_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnClose.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(1020, 1);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 25);
            this.btnClose.TabIndex = 65;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(109, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 17);
            this.label1.TabIndex = 69;
            this.label1.Text = "Quick Find";
            // 
            // frmReviewProcSteps
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1183, 559);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmReviewProcSteps";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Review Procedure Steps";
            this.Load += new System.EventHandler(this.frmReviewProcSteps_Load);
            this.pnlSelection.ResumeLayout(false);
            this.pnlSelection.PerformLayout();
            this.spltProcSteps.Panel1.ResumeLayout(false);
            this.spltProcSteps.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spltProcSteps)).EndInit();
            this.spltProcSteps.ResumeLayout(false);
            this.pnlMain.ResumeLayout(false);
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlSelection;
        private System.Windows.Forms.SplitContainer spltProcSteps;
        private System.Windows.Forms.Label lblSecondaryReactions;
        private System.Windows.Forms.Label lblMainReaction;
        private System.Windows.Forms.Button btnGet;
        private System.Windows.Forms.CheckedListBox chklstSecondaryReact;
        private System.Windows.Forms.TextBox txtMainReaction;
        private System.Windows.Forms.FlowLayoutPanel flpnlProcSteps;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label lblMainRxnStep;
        private System.Windows.Forms.Label lblOthRxns;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Panel pnlMainRxn;
        private System.Windows.Forms.Button btnFindReplace;
        private System.Windows.Forms.CheckBox chkShowAnalogousRxns;
        private System.Windows.Forms.TextBox txtQuickFind;
        private System.Windows.Forms.Label label1;

    }
}