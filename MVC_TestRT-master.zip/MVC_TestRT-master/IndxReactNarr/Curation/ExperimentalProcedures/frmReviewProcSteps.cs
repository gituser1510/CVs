﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using IndxReactNarrDAL;
using IndxReactNarr.UserControls;
using System.Collections;
using IndxReactNarr.Curation.Narratives;

namespace IndxReactNarr.Curation.ExperimentalProcedures
{
    public partial class frmReviewProcSteps : Form
    {
        #region Constructor
        public frmReviewProcSteps()
        {
            InitializeComponent();
        }
        #endregion

        #region Public Properties

        public DataTable TANReactions { get; set; }
        public Int32 TAN_ID { get; set; }
        public string TAN_Name { get; set; }

        AutoCompleteStringCollection afcDistVals = null;

        List<string> lstRxnNames = null;
        List<int> lstRxnIds = null;
        List<string> lstProcSteps = new List<string>();
        List<string> lstAllRxnNames = null;

        public DataTable RxnsProcStepsData { get; set; }

        #endregion

        private void frmReviewProcSteps_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;
                if (TANReactions != null && TANReactions.Rows.Count > 0)
                {
                    UpdateReactionsTableForLabels();

                    lstAllRxnNames = TANReactions.Rows.Cast<DataRow>().Select(row => row["RXN_NAR_ID"].ToString()).ToList();
                    lstRxnNames = lstAllRxnNames;

                    BindListToAutoCompleteTextBox();
                    BindListToListToCheckListBox(lstRxnNames);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void UpdateReactionsTableForLabels()
        {           
            try
            {
                int analogRxnID = 0;
                string narID = "";
                if (TANReactions != null && TANReactions.Rows.Count > 0)
                {                   
                    for (int i = 0; i < TANReactions.Rows.Count; i++)
                    {
                        narID = TANReactions.Rows[i]["RXN_NAR_ID"].ToString();

                        if (TANReactions.Rows[i]["IS_ANALOGOUS"].ToString() == "Y")
                        {
                            if (!System.DBNull.Value.Equals(TANReactions.Rows[i]["ANALOGOUS_RXN_ID"]))
                            {
                                int.TryParse(TANReactions.Rows[i]["ANALOGOUS_RXN_ID"].ToString(), out analogRxnID);
                                if (analogRxnID > 0)
                                {
                                    var a = ((from row in TANReactions.AsEnumerable().Where(r => r.Field<Int64>("RXN_ID") == analogRxnID)
                                              select row.Field<string>("RXN_NAR_ID")).First());
                                    narID += " analogousTo=" + a;
                                }
                            }

                            TANReactions.Rows[i]["RXN_NAR_ID"] = narID;
                            TANReactions.AcceptChanges();
                        }                        
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }          
        }
      
        private void BindListToListToCheckListBox(List<string> Reactions)
        {
            try
            {
                chklstSecondaryReact.Items.Add("Select All");
                foreach (string RXN in Reactions)
                {
                    chklstSecondaryReact.Items.Add(RXN);                    
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindListToAutoCompleteTextBox()
        {
            try
            {
                if (lstRxnNames.Any())
                {
                    afcDistVals = new AutoCompleteStringCollection();
                    afcDistVals.AddRange(lstRxnNames.ToArray());
                    txtMainReaction.AutoCompleteCustomSource = null;
                    txtMainReaction.AutoCompleteCustomSource = afcDistVals;
                    txtMainReaction.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    txtMainReaction.AutoCompleteSource = AutoCompleteSource.CustomSource;
                }

            }

            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtMainReaction_TextChanged(object sender, EventArgs e)
        {
            try
            {
                chklstSecondaryReact.Items.Clear();
                BindListToListToCheckListBox(lstRxnNames);

                if (!string.IsNullOrEmpty(txtMainReaction.Text) && lstRxnNames.Contains(txtMainReaction.Text))
                {
                    chklstSecondaryReact.Items.Remove(txtMainReaction.Text);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void chklstSecondaryReact_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            try
            {
                if (e.Index == 0 && e.NewValue == CheckState.Checked)
                {
                    SelectAllItems();

                }

                if (e.Index == 0 && e.NewValue == CheckState.Unchecked)
                {
                    DeSelectAllItems();

                }

                if (e.Index != 0 && e.NewValue == CheckState.Unchecked)
                {
                    chklstSecondaryReact.BeginUpdate();
                    chklstSecondaryReact.ItemCheck -= chklstSecondaryReact_ItemCheck;
                    chklstSecondaryReact.SetItemChecked(0, false);
                    chklstSecondaryReact.EndUpdate();
                    chklstSecondaryReact.ItemCheck += chklstSecondaryReact_ItemCheck;
                }

                if (e.Index != 0 && e.NewValue == CheckState.Checked && chklstSecondaryReact.CheckedItems.Count == chklstSecondaryReact.Items.Count - 2)
                {
                    chklstSecondaryReact.BeginUpdate();
                    chklstSecondaryReact.ItemCheck -= chklstSecondaryReact_ItemCheck;
                    chklstSecondaryReact.SetItemChecked(0, true);
                    chklstSecondaryReact.EndUpdate();
                    chklstSecondaryReact.ItemCheck += chklstSecondaryReact_ItemCheck;
                }

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void DeSelectAllItems()
        {
            try
            {
                chklstSecondaryReact.BeginUpdate();
                chklstSecondaryReact.ItemCheck -= chklstSecondaryReact_ItemCheck;
                for (int i = 0; i < this.chklstSecondaryReact.Items.Count; i++)
                {
                    this.chklstSecondaryReact.SetItemChecked(i, false);
                }
                chklstSecondaryReact.SetSelected(0, false);
                chklstSecondaryReact.EndUpdate();
                chklstSecondaryReact.ItemCheck += chklstSecondaryReact_ItemCheck;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void SelectAllItems()
        {
            try
            {
                chklstSecondaryReact.BeginUpdate();
                chklstSecondaryReact.ItemCheck -= chklstSecondaryReact_ItemCheck;
                for (int i = 0; i < this.chklstSecondaryReact.Items.Count; i++)
                {
                    this.chklstSecondaryReact.SetItemChecked(i, true);
                }
                chklstSecondaryReact.SetSelected(0, false);
                chklstSecondaryReact.EndUpdate();
                chklstSecondaryReact.ItemCheck += chklstSecondaryReact_ItemCheck;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            string strErrmsg = string.Empty;
            try
            {
                if (ValidUserInputs(out strErrmsg) && string.IsNullOrEmpty(strErrmsg))
                {
                    lstRxnIds = GetSelectedReactionIDs();

                    //DataTable DtProcedureSteps = NarrativesDB.GetProcedureStepsOnReactionIDs(lstRxnIds);
                    //BindProcedureStepsToControls(DtProcedureSteps);

                    DataSet dsProcSteps = NarrativesDB.GetProcedureStepsAndSubstancesOnReactionIDs(lstRxnIds);
                    BindProcedureStepsToControls_New(dsProcSteps);
                }
                else
                {
                    MessageBox.Show(strErrmsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindProcedureStepsToControls(DataTable DtProcedure_Steps)
        {
            try
            {
                if (DtProcedure_Steps != null && DtProcedure_Steps.Rows.Count > 0)
                {
                    //clear controls that bind to flowpanel
                    flpnlProcSteps.Controls.Clear();

                    ucProcedureStepsForUpdate objucProcStepsForUpdate;

                    DataView dv = DtProcedure_Steps.AsDataView();
                    dv.RowFilter = "RXN_NAR_ID=" + "'" + txtMainReaction.Text + "'";
                    DataTable dtTemp = dv.ToTable();
                    
                    //Main Reaction
                    ucProcedureStepsForUpdate ucProcStepsForMainRxn;
                    if (dtTemp != null && dtTemp.Rows.Count > 0)
                    {
                        ucProcStepsForMainRxn = new ucProcedureStepsForUpdate();
                        ucProcStepsForMainRxn.lblNarID.Text = GetNarIDLabelOnRxnID(Convert.ToInt32(dtTemp.Rows[0]["RXN_ID"].ToString()), DtProcedure_Steps);
                        ucProcStepsForMainRxn.RxnID = Convert.ToInt32(dtTemp.Rows[0]["RXN_ID"].ToString());
                        ucProcStepsForMainRxn.RxnSubstances = null;
                        ucProcStepsForMainRxn.uchrtbProcedureSteps.BindDataToControl(dtTemp.Rows[0]["PROCEDURE_TEXT"].ToString());
                        ucProcStepsForMainRxn.Dock = DockStyle.Fill;

                        //spltProcSteps.Panel1.Controls.Add(ucProcStepsForMainRxn);
                        pnlMainRxn.Controls.Add(ucProcStepsForMainRxn);
                    }

                    //Other selected reactions
                    for (int i = 0; i < DtProcedure_Steps.Rows.Count; i++)
                    {
                        if (DtProcedure_Steps.Rows[i]["RXN_NAR_ID"].ToString() != txtMainReaction.Text)
                        {
                            objucProcStepsForUpdate = new ucProcedureStepsForUpdate();
                            objucProcStepsForUpdate.lblNarID.Text = GetNarIDLabelOnRxnID(Convert.ToInt32(DtProcedure_Steps.Rows[i]["RXN_ID"].ToString()), DtProcedure_Steps);
                            objucProcStepsForUpdate.RxnID = Convert.ToInt32(DtProcedure_Steps.Rows[i]["RXN_ID"].ToString());
                            objucProcStepsForUpdate.RxnSubstances = null;
                            objucProcStepsForUpdate.uchrtbProcedureSteps.BindDataToControl(DtProcedure_Steps.Rows[i]["PROCEDURE_TEXT"].ToString());
                            flpnlProcSteps.Controls.Add(objucProcStepsForUpdate);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindProcedureStepsToControls_New(DataSet procedureSteps)
        {
            try
            {
                if (procedureSteps != null)
                {
                    if (procedureSteps.Tables.Count > 0)
                    {
                        DataTable dtProcSteps = procedureSteps.Tables[0];
                        DataTable dtSubstances = procedureSteps.Tables[1];

                        RxnsProcStepsData = dtProcSteps;

                        //clear controls that bind to flowpanel                       
                        while (flpnlProcSteps.Controls.Count > 0)
                        {
                            var controltoremove = flpnlProcSteps.Controls[0];
                            flpnlProcSteps.Controls.Remove(controltoremove);
                            controltoremove.Dispose();
                        }

                        while (pnlMainRxn.Controls.Count > 0)
                        {
                            var controltoremove = pnlMainRxn.Controls[0];
                            pnlMainRxn.Controls.Remove(controltoremove);
                            controltoremove.Dispose();                            
                        }

                        //flpnlProcSteps.Controls.Clear();
                        //pnlMainRxn.Controls.Clear();

                        ucProcedureStepsForUpdate objucProcStepsForUpdate;

                        DataView dv = dtProcSteps.AsDataView();
                        dv.RowFilter = "RXN_NAR_ID=" + "'" + txtMainReaction.Text + "'";
                        DataTable dtTemp = dv.ToTable();
                                               
                        //Main Reaction
                        ucProcedureStepsForUpdate ucProcStepsForMainRxn;
                        if (dtTemp != null && dtTemp.Rows.Count > 0)
                        {
                            ucProcStepsForMainRxn = new ucProcedureStepsForUpdate();
                            ucProcStepsForMainRxn.lblNarID.Text = GetNarIDLabelOnRxnID(Convert.ToInt32(dtTemp.Rows[0]["RXN_ID"].ToString()), dtProcSteps);
                            ucProcStepsForMainRxn.RxnID = Convert.ToInt32(dtTemp.Rows[0]["RXN_ID"].ToString());
                            ucProcStepsForMainRxn.RxnSubstances = dtSubstances.Select("RXN_ID = " + Convert.ToInt32(dtTemp.Rows[0]["RXN_ID"].ToString())).CopyToDataTable();
                            ucProcStepsForMainRxn.ProcedureStepsValue = dtTemp.Rows[0]["PROCEDURE_TEXT"].ToString();
                            ucProcStepsForMainRxn.BindProcedureStepsDataToControls();

                            ucProcStepsForMainRxn.Dock = DockStyle.Fill;

                            //spltProcSteps.Panel1.Controls.Add(ucProcStepsForMainRxn);
                            pnlMainRxn.Controls.Add(ucProcStepsForMainRxn);
                        }

                        //Other selected reactions
                        for (int i = 0; i < dtProcSteps.Rows.Count; i++)
                        {
                            if (dtProcSteps.Rows[i]["RXN_NAR_ID"].ToString() != txtMainReaction.Text)
                            {
                                objucProcStepsForUpdate = new ucProcedureStepsForUpdate();
                                objucProcStepsForUpdate.lblNarID.Text = GetNarIDLabelOnRxnID(Convert.ToInt32(dtProcSteps.Rows[i]["RXN_ID"].ToString()), dtProcSteps);
                                objucProcStepsForUpdate.RxnID = Convert.ToInt32(dtProcSteps.Rows[i]["RXN_ID"].ToString());
                                objucProcStepsForUpdate.RxnSubstances = dtSubstances.Select("RXN_ID = " + Convert.ToInt32(dtProcSteps.Rows[i]["RXN_ID"].ToString())).CopyToDataTable();
                                objucProcStepsForUpdate.ProcedureStepsValue = dtProcSteps.Rows[i]["PROCEDURE_TEXT"].ToString();
                                objucProcStepsForUpdate.BindProcedureStepsDataToControls();
                                flpnlProcSteps.Controls.Add(objucProcStepsForUpdate);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetNarIDLabelOnRxnID(int rxnID, DataTable procStepRxns)
        {
            string narIdLabel = "";
            try
            {
                int analogRxnID = 0;
                for (int i = 0; i < procStepRxns.Rows.Count; i++)
                {
                    if (Convert.ToInt32(procStepRxns.Rows[i]["RXN_ID"]) == rxnID)
                    {
                        narIdLabel = procStepRxns.Rows[i]["RXN_NAR_ID"].ToString();

                        if (procStepRxns.Rows[i]["IS_ANALOGOUS"].ToString() == "Y")
                        {
                            if (!System.DBNull.Value.Equals(procStepRxns.Rows[i]["ANALOGOUS_RXN_ID"]))
                            {
                                int.TryParse(procStepRxns.Rows[i]["ANALOGOUS_RXN_ID"].ToString(), out analogRxnID);
                                if (analogRxnID > 0)
                                {
                                    var a = ((from row in TANReactions.AsEnumerable().Where(r => r.Field<Int64>("RXN_ID") == analogRxnID)
                                              select row.Field<string>("RXN_NAR_ID")).First());
                                    narIdLabel += " analogousTo=" + a;
                                }
                            }
                        }
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return narIdLabel;
        }

        private List<int> GetSelectedReactionIDs()
        {
            lstRxnIds = new List<int>();
            int Rxn_Id = 0;
            try
            {
                if (TANReactions != null && TANReactions.Rows.Count > 0)
                {
                    // Rxn id for main reaction
                    Rxn_Id = (from DataRow dr in TANReactions.Rows
                              where Convert.ToString(dr["RXN_NAR_ID"]) == txtMainReaction.Text
                              select (Convert.ToInt32(dr["RXN_ID"]))).FirstOrDefault();

                    lstRxnIds.Add(Rxn_Id);
                    
                    // Rxn id for secondary reaction
                    for (int i = 0; i < chklstSecondaryReact.CheckedItems.Count; i++)
                    {
                        if (chklstSecondaryReact.CheckedItems[i].ToString() != "Select All")
                        {
                            Rxn_Id = (from DataRow dr in TANReactions.Rows
                                      where Convert.ToString(dr["RXN_NAR_ID"]) == chklstSecondaryReact.CheckedItems[i].ToString()
                                      select (Convert.ToInt32(dr["RXN_ID"]))).FirstOrDefault();

                            lstRxnIds.Add(Rxn_Id);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstRxnIds;
        }

        private bool ValidUserInputs(out string strErrmsg)
        {
            bool status = true;
            string Err = string.Empty;

            try
            {
                if (string.IsNullOrEmpty(txtMainReaction.Text.Trim()))
                {
                    status = false;
                    Err += "Main Reaction Shouldn't be empty\r\n";
                }
                else if (!lstAllRxnNames.Contains(txtMainReaction.Text.Trim()))
                {
                    status = false;
                    Err += "Invalid Main Reaction \r\n";
                }

                if (chklstSecondaryReact.CheckedItems.Count == 0)
                {
                    status = false;
                    Err += "Please Select Sec. Reaction  \r\n";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            strErrmsg = Err;
            return status;

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string strErrmsg = string.Empty;
                if (ValidUserInputs(out strErrmsg) && string.IsNullOrEmpty(strErrmsg))
                {
                    lstProcSteps = GetUpdatedProcedureSteps(out lstRxnIds, out strErrmsg);

                    if (string.IsNullOrEmpty(strErrmsg))
                    {
                        if (NarrativesDB.UpdateReactionsProcedureSteps(lstRxnIds, lstProcSteps))
                        {
                            MessageBox.Show("Procedure Steps saved sucessfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Error in saving Other reactions procedure steps", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show(strErrmsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show(strErrmsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private List<string> GetUpdatedProcedureSteps(out List<int> liRxn_Ids, out string Errmsg)
        {
            List<string> liTempProcedure = new List<string>();
            List<int> liTempRxn_Ids = new List<int>();
            string msg = string.Empty;
            ucProcedureStepsForUpdate ucPsu = null;

            try
            {
                //Main reaction procedure steps
                if (pnlMainRxn.Controls.Count > 0)
                {
                    //ucPsu = spltProcSteps.Panel1.Controls[1] as ucProcedureStepsForUpdate;
                    ucPsu = pnlMainRxn.Controls[0] as ucProcedureStepsForUpdate;
                    if (ucPsu != null)
                    {
                        liTempProcedure.Add(ucPsu.uchrtbProcedureSteps.GetHtmlStringFromControl());
                        liTempRxn_Ids.Add(ucPsu.RxnID);
                    }
                }

                //Other reactions procedure steps
                if (flpnlProcSteps.Controls.Count > 0)
                {
                    for (int i = 0; i < flpnlProcSteps.Controls.Count; i++)
                    {
                        ucPsu = flpnlProcSteps.Controls[i] as ucProcedureStepsForUpdate;
                        if (ucPsu != null)
                        {
                            liTempProcedure.Add(ucPsu.uchrtbProcedureSteps.GetHtmlStringFromControl());
                            liTempRxn_Ids.Add(ucPsu.RxnID);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            finally
            {
                ucPsu = null;
            }

            liRxn_Ids = liTempRxn_Ids;
            Errmsg = msg;
            return liTempProcedure;
        }

        private void flpnlProcSteps_SizeChanged(object sender, EventArgs e)
        {
            try
            {
                if (flpnlProcSteps != null)
                {
                    if (flpnlProcSteps.Controls.Count > 0)
                    {
                        ucProcedureStepsForUpdate ucHB = null;
                        for (int i = 0; i < flpnlProcSteps.Controls.Count; i++)
                        {
                            ucHB = flpnlProcSteps.Controls[i] as ucProcedureStepsForUpdate;
                            if (ucHB != null)
                            {
                                ucHB.Width = flpnlProcSteps.Width - 28;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                //spltProcSteps.Panel1.Controls.Clear();
                pnlMainRxn.Controls.Clear();
                if (flpnlProcSteps.Controls.Count > 0)
                {
                    flpnlProcSteps.Controls.Clear();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {           
            this.Close();
        }

        private void btnFindReplace_Click(object sender, EventArgs e)
        {
            try
            {
                //frmFindAndReplace findReplace = new frmFindAndReplace();
                //findReplace.TAN_Reactions_FR = RxnsProcStepsData;
                //findReplace.TAN_ID = TAN_ID;
                //findReplace.TAN_Name = TAN_Name;

                //if (findReplace.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                //{
                //    DataSet dsProcSteps = NarrativesDB.GetProcedureStepsAndSubstancesOnReactionIDs(lstRxnIds);
                //    BindProcedureStepsToControls_New(dsProcSteps);
                //}

                frmFindAndReplace findReplace = null;

                bool frmOpen = false;
                FormCollection frmColl = Application.OpenForms;
                foreach (Form objfrm in frmColl)
                {
                    if (objfrm.Name.ToUpper() == "FRMFINDANDREPLACE")
                    {
                        findReplace = (frmFindAndReplace)objfrm;
                        findReplace.TAN_Reactions_FR = RxnsProcStepsData;
                        findReplace.TAN_ID = TAN_ID;
                        findReplace.TAN_Name = TAN_Name;
                        findReplace.WindowState = FormWindowState.Maximized;
                        findReplace.Show();
                        frmOpen = true;
                        break;
                    }
                }
                if (!frmOpen)
                {
                    findReplace = new frmFindAndReplace();
                    findReplace.FormClosed -= new FormClosedEventHandler(findReplace_FormClosed);
                    findReplace.FormClosed += new FormClosedEventHandler(findReplace_FormClosed);
                    findReplace.TAN_Reactions_FR = RxnsProcStepsData;
                    findReplace.TAN_ID = TAN_ID;
                    findReplace.TAN_Name = TAN_Name;
                    findReplace.Show(this);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void findReplace_FormClosed(object sender, FormClosedEventArgs e)
        {

            try
            {
                DataSet dsProcSteps = NarrativesDB.GetProcedureStepsAndSubstancesOnReactionIDs(lstRxnIds);
                BindProcedureStepsToControls_New(dsProcSteps);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void chkShowAnalogousRxns_CheckStateChanged(object sender, EventArgs e)
        {
            try
            {
                if (chkShowAnalogousRxns.Checked)
                {
                    chklstSecondaryReact.Items.Clear();

                    int mainRxnID = 0;

                    //Rxn id for main reaction
                    mainRxnID = (from DataRow dr in TANReactions.Rows
                              where Convert.ToString(dr["RXN_NAR_ID"]) == txtMainReaction.Text
                              select (Convert.ToInt32(dr["RXN_ID"]))).FirstOrDefault();

                    DataRow[] arAnalogous = TANReactions.Select("IS_ANALOGOUS = 'Y' and ANALOGOUS_RXN_ID = " + mainRxnID);
                    if (arAnalogous != null && arAnalogous.Count() > 0)
                    {
                        DataTable dtAnalogousRxns = arAnalogous.CopyToDataTable();
                        lstRxnNames = dtAnalogousRxns.Rows.Cast<DataRow>().Select(row => row["RXN_NAR_ID"].ToString()).ToList();

                        BindListToListToCheckListBox(lstRxnNames);
                    }
                }
                else
                {
                    chklstSecondaryReact.Items.Clear();

                    lstRxnNames = TANReactions.Rows.Cast<DataRow>().Select(row => row["RXN_NAR_ID"].ToString()).ToList();

                    BindListToListToCheckListBox(lstRxnNames);

                    if (!string.IsNullOrEmpty(txtMainReaction.Text) && lstRxnNames.Contains(txtMainReaction.Text))
                    {
                        chklstSecondaryReact.Items.Remove(txtMainReaction.Text);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
                
        private void txtQuickFind_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == 13)
                {
                    ucProcedureStepsForUpdate ucHB = null;
                    if (pnlMainRxn.Controls.Count > 0)
                    {
                        ucHB = pnlMainRxn.Controls[0] as ucProcedureStepsForUpdate;
                        if (ucHB != null)
                        {
                            ucHB.uchrtbProcedureSteps.HighLightSpecialWordsInText_QuickFind(txtQuickFind.Text.Trim());
                        }
                    }

                    if (flpnlProcSteps.Controls.Count > 0)
                    {
                        for (int i = 0; i < flpnlProcSteps.Controls.Count; i++)
                        {
                            ucHB = flpnlProcSteps.Controls[i] as ucProcedureStepsForUpdate;
                            if (ucHB != null)
                            {
                                ucHB.uchrtbProcedureSteps.HighLightSpecialWordsInText_QuickFind(txtQuickFind.Text.Trim());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}