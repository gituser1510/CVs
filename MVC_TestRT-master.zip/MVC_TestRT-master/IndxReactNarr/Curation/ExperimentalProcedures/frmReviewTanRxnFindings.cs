﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarrDAL;
using IndxReactNarr.Generic;
using IndxReactNarrBll;

namespace IndxReactNarr.Curation.ExperimentalProcedures
{
    public partial class frmReviewTanRxnFindings : Form
    {
        public frmReviewTanRxnFindings()
        {
            InitializeComponent();
        }

        public DataTable TANFindings { get; set; }
        public DataTable BatchTANs { get; set; }
        List<string> lstTans = null;
        List<int> lstTanIDs = null;

        private void frmReviewTanRxnFindings_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;
                txtShipmentName.Focus();

                //Get Shipment Names and Set Autofill
                GetShipmentNamesAndSetToUserNameTxtBox_AutoComplete();

                uchrtbPreview.hrtbPara.ReadOnly = true;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetShipmentNamesAndSetToUserNameTxtBox_AutoComplete()
        {
            try
            {
                DataTable dtTanTypes = null;
                DataTable dtShipments = null;
                using (dtShipments = ReactDB.GetShipmentDetailsByAppName(GlobalVariables.ApplicationName, out dtTanTypes))//EXPPROCEDURES
                {
                    if (dtShipments != null && dtShipments.Rows.Count > 0)
                    {
                        AutoCompleteStringCollection shipmentColl = new AutoCompleteStringCollection();

                        for (int i = 0; i < dtShipments.Rows.Count; i++)
                        {
                            if (dtShipments.Rows[i][0] != null)
                            {
                                shipmentColl.Add(dtShipments.Rows[i]["SHIPMENT_NAME"].ToString());
                            }
                        }

                        txtShipmentName.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                        txtShipmentName.AutoCompleteSource = AutoCompleteSource.CustomSource;
                        txtShipmentName.AutoCompleteCustomSource = shipmentColl;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnGetList_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;

                if (!string.IsNullOrEmpty(txtShipmentName.Text.Trim()))
                {
                    ClearControlValues();

                    int intBNo = 0;
                    int.TryParse(txtBNo.Text.Trim(), out intBNo);

                    DataTable dtBatchTANS = ShipmentMasterDB.GetTANsForExportOnApp_Shipment(GlobalVariables.ApplicationName, txtShipmentName.Text.Trim(), intBNo);
                    if (dtBatchTANS != null)
                    {
                        BatchTANs = dtBatchTANS;
                        txtTANSrch.Text = "";
                        BindTANsToCheckBoxlistBox(dtBatchTANS);
                    }
                }

                Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void ClearControlValues()
        {
            try
            {
                TANFindings = null;
                dgvFindings.DataSource = null;
                chklstTANs.DataSource = null;
                uchrtbPreview.hrtbPara.Clear();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindTANsToCheckBoxlistBox(DataTable dtBatchTANS)
        {
            try
            {
                lstTans = dtBatchTANS.Rows.Cast<DataRow>().Select(row => row["TAN_NAME"].ToString()).ToList();
                BindListToCheckListBox(lstTans);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindListToCheckListBox(List<string> lstTans)
        {
            try
            {
                chklstTANs.Items.Clear();
                chklstTANs.Items.Add("Select All");
                foreach (string Tan in lstTans)
                {
                    chklstTANs.Items.Add(Tan);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtTANSrch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (BatchTANs != null)
                {
                    if (!string.IsNullOrEmpty(txtTANSrch.Text.Trim()))
                    {
                        string strFCond = GetFilterCondition(txtTANSrch.Text.Trim());

                        DataTable dtAllTANs = BatchTANs.Copy();
                        DataView dvTemp = dtAllTANs.DefaultView;
                        dvTemp.RowFilter = strFCond;
                        DataTable dtTANs = dvTemp.ToTable();
                        BindTANsToCheckBoxlistBox(dtTANs);
                    }
                    else
                    {
                        DataTable dtAllTANs = BatchTANs.Copy();
                        BindTANsToCheckBoxlistBox(dtAllTANs);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetFilterCondition(string _query_tan)
        {
            string strFCond = "";
            try
            {
                if (_query_tan.Trim().Contains(";"))
                {
                    string[] splitter = { ";" };
                    string[] strArrTans = _query_tan.Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);

                    if (strArrTans != null)
                    {
                        if (strArrTans.Length > 0)
                        {
                            for (int i = 0; i < strArrTans.Length; i++)
                            {
                                if (i == 0)
                                {
                                    strFCond = "TAN_NAME Like '" + strArrTans[i] + "%' ";
                                }
                                else
                                {
                                    strFCond += " OR" + " TAN_NAME Like '" + strArrTans[i] + "%'";
                                }
                            }
                        }
                    }
                }
                else
                {
                    strFCond = "TAN_NAME Like '" + _query_tan.Trim() + "%'";
                }
                return strFCond;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strFCond;
        }

        private void chklstRxns_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            try
            {
                if (e.Index == 0 && e.NewValue == CheckState.Checked)
                {
                    SelectAllItems();

                }

                if (e.Index == 0 && e.NewValue == CheckState.Unchecked)
                {
                    DeSelectAllItems();

                }

                if (e.Index != 0 && e.NewValue == CheckState.Unchecked)
                {
                    chklstTANs.BeginUpdate();
                    chklstTANs.ItemCheck -= chklstRxns_ItemCheck;
                    chklstTANs.SetItemChecked(0, false);
                    chklstTANs.EndUpdate();
                    chklstTANs.ItemCheck += chklstRxns_ItemCheck;
                }

                if (e.Index != 0 && e.NewValue == CheckState.Checked && chklstTANs.CheckedItems.Count == chklstTANs.Items.Count - 2)
                {
                    chklstTANs.BeginUpdate();
                    chklstTANs.ItemCheck -= chklstRxns_ItemCheck;
                    chklstTANs.SetItemChecked(0, true);
                    chklstTANs.EndUpdate();
                    chklstTANs.ItemCheck += chklstRxns_ItemCheck;
                }

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void DeSelectAllItems()
        {
            try
            {
                chklstTANs.BeginUpdate();
                chklstTANs.ItemCheck -= chklstRxns_ItemCheck;
                for (int i = 0; i < this.chklstTANs.Items.Count; i++)
                {
                    this.chklstTANs.SetItemChecked(i, false);
                }
                chklstTANs.SetSelected(0, false);
                chklstTANs.EndUpdate();
                chklstTANs.ItemCheck += chklstRxns_ItemCheck;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void SelectAllItems()
        {
            try
            {
                chklstTANs.BeginUpdate();
                chklstTANs.ItemCheck -= chklstRxns_ItemCheck;
                for (int i = 0; i < this.chklstTANs.Items.Count; i++)
                {
                    this.chklstTANs.SetItemChecked(i, true);
                }
                chklstTANs.SetSelected(0, false);
                chklstTANs.EndUpdate();
                chklstTANs.ItemCheck += chklstRxns_ItemCheck;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            string strErrmsg = string.Empty;
            try
            {
                if (ValidUserInputs(out strErrmsg))
                {
                    GetSelectedTANsFindingsAndBindToGrid();
                }
                else
                {
                    MessageBox.Show(strErrmsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetSelectedTANsFindingsAndBindToGrid()
        {
            try
            {
                lstTanIDs = GetSelectedTanIDs();

                TANFindings = NarrativesDB.GetReactionFindingsOnTanIDs(lstTanIDs);

                dgvFindings.AutoGenerateColumns = false;
                BindingSource bsTANFindings = new BindingSource(TANFindings, null);
                dgvFindings.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                dgvFindings.DataSource = bsTANFindings;  
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private List<int> GetSelectedTanIDs()
        {
            lstTanIDs = new List<int>();
            int TAN_ID = 0;
            try
            {
                if (BatchTANs != null && BatchTANs.Rows.Count > 0)
                {
                    // Rxn id for secondary reaction
                    for (int i = 0; i < chklstTANs.CheckedItems.Count; i++)
                    {
                        if (chklstTANs.CheckedItems[i].ToString() != "Select All")
                        {
                            TAN_ID = (from DataRow dr in BatchTANs.Rows
                                      where Convert.ToString(dr["TAN_NAME"]) == chklstTANs.CheckedItems[i].ToString()
                                      select (Convert.ToInt32(dr["TAN_ID"]))).FirstOrDefault();

                            lstTanIDs.Add(TAN_ID);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstTanIDs;
        }

        private bool ValidUserInputs(out string strErrmsg)
        {
            bool status = true;
            string Err = string.Empty;

            try
            {
                if (chklstTANs.CheckedItems.Count == 0)
                {
                    status = false;
                    Err += "Please select reactions";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            strErrmsg = Err;
            return status;
        }

        private void dgvFindings_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();
                while (strRowNumber.Length < dgvFindings.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvFindings.Font);

                if (dgvFindings.RowHeadersWidth < (int)(size.Width + 20)) dgvFindings.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvFindings_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            try
            {
                for (int i = 0; i < this.dgvFindings.Rows.Count; i++)
                {
                    this.dgvFindings.AutoResizeRow(i, DataGridViewAutoSizeRowMode.AllCells);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                TANFindings = null;
                dgvFindings.DataSource = null;
                uchrtbPreview.hrtbPara.Clear();
                lstEditedRowIDs.Clear();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvFindings_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                {
                    if (dgvFindings.Rows[e.RowIndex].Cells[colFindingVal.Name].Value != null)
                    {
                        uchrtbPreview.BindDataToControl(dgvFindings.Rows[e.RowIndex].Cells[colFindingVal.Name].Value.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                //dgvFindings.dir
                if (lstEditedRowIDs.Count > 0)
                {
                    RxnFindings editedFindings = GetEditedRxnFindingsFromGrid(lstEditedRowIDs);
                    if (editedFindings != null)
                    {
                        if (NarrativesDB.UpdateShipmentTANsReactionFindings(editedFindings))
                        {
                            MessageBox.Show("Updated Reaction Findings successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);

                            GetSelectedTANsFindingsAndBindToGrid();
                        }
                        else
                        {
                            MessageBox.Show("Error in Reaction Findings update", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private RxnFindings GetEditedRxnFindingsFromGrid(List<int> updatedRowIDs)
        {
            RxnFindings rxnFinding = null;
            try
            {
                if (lstEditedRowIDs != null && lstEditedRowIDs.Count > 0)
                {
                    rxnFinding = new RxnFindings();

                    List<Int32> lstRxnIDs = new List<Int32>();
                    List<Int32> lstFindingIDs = new List<Int32>();
                    List<string> lstFindingType = new List<string>();
                    List<string> lstFindingValue = new List<string>();
                    List<string> lstRefComp = new List<string>();
                   
                    DataGridViewRow gridRow = null;

                    for (int i = 0; i < lstEditedRowIDs.Count; i++)
                    {
                        gridRow = dgvFindings.Rows[lstEditedRowIDs[i]];
                        lstRxnIDs.Add(Convert.ToInt32(gridRow.Cells[colRxnID.Name].Value));
                        lstFindingIDs.Add(Convert.ToInt32(gridRow.Cells[colFindingID.Name].Value));

                        lstFindingType.Add(gridRow.Cells[colFindingType.Name].Value.ToString());
                        lstFindingValue.Add(gridRow.Cells[colFindingVal.Name].Value.ToString());
                        lstRefComp.Add(gridRow.Cells[colRefSub.Name].Value.ToString());
                    }

                    rxnFinding.RxnIDs = lstRxnIDs;
                    rxnFinding.FindingIDs = lstFindingIDs;
                    rxnFinding.FindingTypes = lstFindingType;
                    rxnFinding.FindingValues = lstFindingValue;
                    rxnFinding.RefCompounds = lstRefComp;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return rxnFinding;
        }

        List<int> lstEditedRowIDs = new List<int>();
        private void dgvFindings_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                {
                    if (!lstEditedRowIDs.Contains(e.RowIndex))
                    {
                        lstEditedRowIDs.Add(e.RowIndex);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvFindings_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            try
            {
                e.ThrowException = false;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}

