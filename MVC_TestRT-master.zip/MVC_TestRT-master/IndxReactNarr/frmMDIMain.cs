﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using IndxReactNarr;
using IndxReactNarrDAL;
using IndxReactNarr.UserManagement;
using IndxReactNarr.TaskManagement;
using System.IO;
using IndxReactNarrBLL;
using IndxReactNarr.Curation.Narratives;
using IndxReactNarr.Common;
using IndxReactNarr.Reports;
using IndxReactNarr.IndexingImport;
using IndxReactNarr.OtherForms;
using System.Threading;
using IndxReactNarr.XmlValidation;
using IndxReactNarr.Curation.ExperimentalProcedures;
using System.Reflection;

//using CASRxnTool.Generic;
//using CASRxnTool.CAS_XML;
//using DAL;
//using BLL;
//using CASRxnTool.Reports;
//using SearchPdf;
//using System.IO;
//using CASRxnTool.TaskManagement;
//using CASRxnTool.CAS_Classes;
//using ImageToPdf_ITextSharp;
//using CASRxnTool.IndexingImport;

#endregion Namespaces

namespace IndxReactNarr
{
    public partial class frmMDIMain : Form
    {
        
        #region Constructor

        public frmMDIMain()
        {
            InitializeComponent();
        }

        #endregion

        #region Property prodecures

        public string SelectedTAN
        {
            get;
            set;
        }

        public string BatchName
        {
            get;
            set;
        }

        public string BatchNo
        {
            get;
            set;
        }

        public int AnalystId
        { get; set; }

        #endregion

        private bool CheckFormOpen(string frmName)
        {
            bool fOpen = false;
            try
            {
                FormCollection collForms = Application.OpenForms;
                foreach (Form frmChk in collForms)
                {
                    if (frmChk.Name.ToUpper() == frmName.ToUpper())
                    {
                        fOpen = true;
                    }
                }
                return fOpen;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return fOpen;
        }

        private void DisableMenu_SubMenuItems()
        {
            try
            { 
                newTANToolStripMenuItem.Enabled = false;
                newTANToolStripMenuItem.Visible = false;
                loadTANtoolStripMenuItem.Enabled = false;
                loadTANtoolStripMenuItem.Visible = false;

                logOffToolStripMenuItem.Enabled = false;
                IndexingTSMenuItem.Enabled = false;

                //Search Menu
                searchMenu.Enabled = false;
                //Search Menu Sub-Menu Items
                //Visible = false
                listOfTANsToolStripMenuItem.Visible = false;
                tANSearchToolStripMenuItem.Visible = false;
                nUMSearchToolStripMenuItem.Visible = false;
                //Enabled = false
                listOfTANsToolStripMenuItem.Enabled = false;                
                tANSearchToolStripMenuItem.Enabled = false;                
                nUMSearchToolStripMenuItem.Enabled = false;
                
                //Export Menu
                exportMenu.Enabled = false;
                //Search Menu Sub-Menu Items
                //Visible = false
                exporttoXMLToolStripMenuItem.Visible = false;
                toBatchXMLToolStripMenuItem.Visible = false;
                //Enabled = false
                exporttoXMLToolStripMenuItem.Enabled = false;
                toBatchXMLToolStripMenuItem.Enabled = false;
                
                //Validate Menu
                validateMenu.Enabled = false;
                //Validate Menu Sub-Menu Items
                //Visible = false
                validateXMLToolStripMenuItem.Visible = false;               
                rSDToolStripMenuItem.Visible = false;
                //Enabled = false
                validateXMLToolStripMenuItem.Enabled = false;               
                rSDToolStripMenuItem.Enabled = false;

                //Reports Menu
                reportMenu.Enabled = false;
                reportMenu.Visible = false;
                //Reports Menu Sub-Menu Items
                //Visible = false
                //shipmentReportToolStripMenuItem.Visible = false;
                errorSummaryReportToolStripMenuItem.Visible = false;
                tANStatusReportToolStripMenuItem.Visible = false;
                //batchTANStatusReportTSMnuItem.Visible = false;
                errorLogReportToolStripMenuItem.Visible = false;
                userTANErrorLogReportToolStripMenuItem.Visible = false;
                dailyStatusReportToolStripMenuItem.Visible = false;
                monthlyReportToolStripMenuItem.Visible = false;
                shipmentTanNUMsForPDfExportToolStripMenuItem.Visible = false;
                userErrorsReportTSMenuItem.Visible = false;
                xmlDeliveryReportTSMenuItem.Visible = false;
                userProductivityReportTSMenuItem.Visible = false;
                
                //Enabled = false
                //shipmentReportToolStripMenuItem.Enabled = false;
                errorSummaryReportToolStripMenuItem.Enabled = false;
                tANStatusReportToolStripMenuItem.Enabled = false;
                //batchTANStatusReportTSMnuItem.Enabled = false;
                errorLogReportToolStripMenuItem.Enabled = false;
                userTANErrorLogReportToolStripMenuItem.Enabled = false;
                dailyStatusReportToolStripMenuItem.Enabled = false;
                monthlyReportToolStripMenuItem.Enabled = false;
                shipmentTanNUMsForPDfExportToolStripMenuItem.Enabled = false;
                userErrorsReportTSMenuItem.Enabled = false;
                xmlDeliveryReportTSMenuItem.Enabled = false;
                userProductivityReportTSMenuItem.Enabled = false;

                //Batch Menu
                batchMenu.Enabled = false;
                batchMenu.Visible = false;
                //Batch Menu Sub-Menu Items
                //Visible = false
                insertBatchToolStripMenuItem.Visible = false;
                distributeBatchToolStripMenuItem.Visible = false;
                moveToBatchToolStripMenuItem.Visible = false;
                keywordSearchToolStripMenuItem.Visible = false;
                //Enabled = false
                insertBatchToolStripMenuItem.Enabled = false;
                distributeBatchToolStripMenuItem.Enabled = false;
                moveToBatchToolStripMenuItem.Enabled = false;
                keywordSearchToolStripMenuItem.Enabled = false;

                //Task Menu
                taskMenu.Enabled = false;
                taskMenu.Visible = false;
                //Task Menu Sub-Menu Items
                //Visible = false
                assignmentToolStripMenuItem.Visible = false;
                //Enabled = false
                assignmentToolStripMenuItem.Enabled = false;

                //Advanced Menu
                advancedMenu.Enabled = false;
                //Advanced Menu Sub-Menu Items
                //Visible = false
                extractRSNToolStripMenuItem.Visible = false;
                duplicateTANToolStripMenuItem.Visible = false;
                finalCheckToolStripMenuItem.Visible = false;
                orgRefToolStripMenuItem.Visible = false;
                rSNFreeDictionaryToolStripMenuItem.Visible = false;
                solventBoilingPointToolStripMenuItem.Visible = false;
                series8500RegNosToolStripMenuItem.Visible = false;
                clientFeedbackToolStripMenuItem.Visible = false;
                sendMailToUsersToolStripMenuItem.Visible = false;
                imageToPDFConvTSMnuItem.Visible = false;
                //Enabled = false
                extractRSNToolStripMenuItem.Enabled = false;
                duplicateTANToolStripMenuItem.Enabled = false;
                finalCheckToolStripMenuItem.Enabled = false;
                orgRefToolStripMenuItem.Enabled = false;
                rSNFreeDictionaryToolStripMenuItem.Enabled = false;
                solventBoilingPointToolStripMenuItem.Enabled = false;
                series8500RegNosToolStripMenuItem.Enabled = false;
                clientFeedbackToolStripMenuItem.Enabled = false;
                sendMailToUsersToolStripMenuItem.Enabled = false;
                imageToPDFConvTSMnuItem.Enabled = false;

                //User Menu
                userPrefsMenu.Enabled = false;
                //User Menu Sub-Menu Items
                //Visible = false
                //changePasswordToolStripMenuItem.Visible = false;
                userAccountsToolStripMenuItem.Visible = false;
                //Enabled = false
                //changePasswordToolStripMenuItem.Enabled = false;
                userAccountsToolStripMenuItem.Enabled = false;

                //scifinder Menu 
                //scifinderMenu.Visible = false;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void EnableMenu_SubMenuItems(string userrole)
        {
            try
            {
                //newTANToolStripMenuItem.Enabled = true; - Removed the feature

                logintoolStripMenuItem.Enabled = false;

                if (userrole.Trim().ToUpper() == RolesMaster.PM.ToUpper())
                {
                    //Search Menu
                    searchMenu.Enabled = true;
                    //Search Menu Sub-Menu Items
                    //Visible = true
                    listOfTANsToolStripMenuItem.Visible = true;
                    tANSearchToolStripMenuItem.Visible = true;
                    nUMSearchToolStripMenuItem.Visible = true;
                    //Enabled = true
                    listOfTANsToolStripMenuItem.Enabled = true;
                    tANSearchToolStripMenuItem.Enabled = true;
                    nUMSearchToolStripMenuItem.Enabled = true;

                    //Export Menu
                    exportMenu.Enabled = true;
                    //Search Menu Sub-Menu Items
                    //Visible = true
                    exporttoXMLToolStripMenuItem.Visible = true;
                    toBatchXMLToolStripMenuItem.Visible = true;
                    //Enabled = true
                    exporttoXMLToolStripMenuItem.Enabled = true;
                    toBatchXMLToolStripMenuItem.Enabled = true;
                                       
                    //Validate Menu
                    validateMenu.Enabled = true;
                    //Validate Menu Sub-Menu Items
                    //Visible = true
                    validateXMLToolStripMenuItem.Visible = true;                    
                    rSDToolStripMenuItem.Visible = true;
                    //Enabled = true
                    validateXMLToolStripMenuItem.Enabled = true;                   
                    rSDToolStripMenuItem.Enabled = true;

                    //Reports Menu
                    reportMenu.Enabled = true;
                    reportMenu.Visible = true;
                   
                    //Reports Menu Sub-Menu Items
                    //Visible = true
                    //shipmentReportToolStripMenuItem.Visible = true;
                    multiShipmentsStatusReportTSMenuItem.Visible = true;
                    multiShipmentsStatusReportTSMenuItem.Enabled = true;
                    errorSummaryReportToolStripMenuItem.Visible = true;
                    tANStatusReportToolStripMenuItem.Visible = true;
                    //batchTANStatusReportTSMnuItem.Visible = true;
                    errorLogReportToolStripMenuItem.Visible = true;
                    userTANErrorLogReportToolStripMenuItem.Visible = true;
                    dailyStatusReportToolStripMenuItem.Visible = true;
                    monthlyReportToolStripMenuItem.Visible = true;
                    userErrorsReportTSMenuItem.Visible = true;
                    userProductivityReportTSMenuItem.Visible = true;
                   
                    //Enabled = true
                    //shipmentReportToolStripMenuItem.Enabled = true;
                    errorSummaryReportToolStripMenuItem.Enabled = true;
                    tANStatusReportToolStripMenuItem.Enabled = true;
                    //batchTANStatusReportTSMnuItem.Enabled = true;
                    errorLogReportToolStripMenuItem.Enabled = true;
                    userTANErrorLogReportToolStripMenuItem.Enabled = true;
                    dailyStatusReportToolStripMenuItem.Enabled = true;
                    monthlyReportToolStripMenuItem.Enabled = true;
                    userErrorsReportTSMenuItem.Enabled = true;
                    userProductivityReportTSMenuItem.Enabled = true;

                    //Batch Menu
                    //batchMenu.Enabled = true;
                    //batchMenu.Visible = true;

                    ////Batch Menu Sub-Menu Items
                    ////Visible = true
                    //insertBatchToolStripMenuItem.Visible = true;
                    //distributeBatchToolStripMenuItem.Enabled = true;
                    //distributeBatchToolStripMenuItem.Visible = true;
                    
                    //moveToBatchToolStripMenuItem.Visible = true;
                    //keywordSearchToolStripMenuItem.Visible = true;
                    //Enabled = true
                    //insertBatchToolStripMenuItem.Enabled = true;
                    //distributeBatchToolStripMenuItem.Enabled = true;
                    //moveToBatchToolStripMenuItem.Enabled = true;
                    //keywordSearchToolStripMenuItem.Enabled = true;

                    ////Task Menu
                    //taskMenu.Enabled = true;
                    //taskMenu.Visible = true;
                    ////Task Menu Sub-Menu Items
                    //assignmentToolStripMenuItem.Visible = true;
                    //assignmentToolStripMenuItem.Enabled = true;

                    //Advanced Menu
                    advancedMenu.Enabled = true;
                    //Advanced Menu Sub-Menu Items
                    //Visible = true 
                    extractRSNToolStripMenuItem.Visible = true;
                    duplicateTANToolStripMenuItem.Visible = true;
                    finalCheckToolStripMenuItem.Visible = true;
                    orgRefToolStripMenuItem.Visible = true;
                    rSNFreeDictionaryToolStripMenuItem.Visible = true;
                    solventBoilingPointToolStripMenuItem.Visible = true;
                    series8500RegNosToolStripMenuItem.Visible = true;
                    cTHReferenceTSMenuItem.Visible = true;

                    //Enabled = true
                    extractRSNToolStripMenuItem.Enabled = true;
                    duplicateTANToolStripMenuItem.Enabled = true;
                    finalCheckToolStripMenuItem.Enabled = true;
                    orgRefToolStripMenuItem.Enabled = true;
                    rSNFreeDictionaryToolStripMenuItem.Enabled = true;
                    solventBoilingPointToolStripMenuItem.Enabled = true;
                    series8500RegNosToolStripMenuItem.Enabled = true;
                    clientFeedbackToolStripMenuItem.Enabled = true;
                    cTHReferenceTSMenuItem.Enabled = true;
                    //User Menu
                    userPrefsMenu.Enabled = true;
                    //User Menu Sub-Menu Items
                    //Visible = true
                    //changePasswordToolStripMenuItem.Visible  = true;
                    //userAccountsToolStripMenuItem.Visible = true;
                    //Enabled = true
                    //changePasswordToolStripMenuItem.Enabled = true;
                    //userAccountsToolStripMenuItem.Enabled = true;
                }
                else if (userrole.Trim().ToUpper() == RolesMaster.TOOL_MANAGER.ToUpper())
                {
                    loadTANtoolStripMenuItem.Visible = true;
                    loadTANtoolStripMenuItem.Enabled = true;
                    IndexingTSMenuItem.Enabled = true;

                    //Search Menu
                    searchMenu.Enabled = true;
                    //Search Menu Sub-Menu Items
                    //Visible = true
                    listOfTANsToolStripMenuItem.Visible = true;
                    tANSearchToolStripMenuItem.Visible = true;
                    nUMSearchToolStripMenuItem.Visible = true;
                    //Enabled = true
                    listOfTANsToolStripMenuItem.Enabled = true;
                    tANSearchToolStripMenuItem.Enabled = true;
                    nUMSearchToolStripMenuItem.Enabled = true;

                    //Export Menu
                    exportMenu.Enabled = true;
                    //Search Menu Sub-Menu Items
                    //Visible = true
                    exporttoXMLToolStripMenuItem.Visible = true;
                    toBatchXMLToolStripMenuItem.Visible = true;
                    //Enabled = true
                    exporttoXMLToolStripMenuItem.Enabled = true;
                    toBatchXMLToolStripMenuItem.Enabled = true;
                                       
                    //Validate Menu
                    validateMenu.Enabled = true;
                    //Validate Menu Sub-Menu Items
                    //Visible = true
                    validateXMLToolStripMenuItem.Visible = true;                   
                    rSDToolStripMenuItem.Visible = true;
                    //Enabled = true
                    validateXMLToolStripMenuItem.Enabled = true;                    
                    rSDToolStripMenuItem.Enabled = true;

                    //Reports Menu
                    reportMenu.Enabled = true;
                    reportMenu.Visible = true;
                    //Reports Menu Sub-Menu Items
                    //Visible = true
                    //shipmentReportToolStripMenuItem.Visible = true;
                    multiShipmentsStatusReportTSMenuItem.Visible = true;
                    multiShipmentsStatusReportTSMenuItem.Enabled = true;
                    errorSummaryReportToolStripMenuItem.Visible = true;
                    tANStatusReportToolStripMenuItem.Visible = true;
                    //batchTANStatusReportTSMnuItem.Visible = true;
                    errorLogReportToolStripMenuItem.Visible = true;
                    userTANErrorLogReportToolStripMenuItem.Visible = true;
                    dailyStatusReportToolStripMenuItem.Visible = true;
                    monthlyReportToolStripMenuItem.Visible = true;
                    shipmentTanNUMsForPDfExportToolStripMenuItem.Visible = true;
                    userErrorsReportTSMenuItem.Visible = true;
                    userProductivityReportTSMenuItem.Visible = true;
                    //Enabled = true
                    //shipmentReportToolStripMenuItem.Enabled = true;
                    errorSummaryReportToolStripMenuItem.Enabled = true;
                    tANStatusReportToolStripMenuItem.Enabled = true;
                    //batchTANStatusReportTSMnuItem.Enabled = true;
                    errorLogReportToolStripMenuItem.Enabled = true;
                    userTANErrorLogReportToolStripMenuItem.Enabled = true;
                    dailyStatusReportToolStripMenuItem.Enabled = true;
                    monthlyReportToolStripMenuItem.Enabled = true;
                    shipmentTanNUMsForPDfExportToolStripMenuItem.Enabled = true;
                    userErrorsReportTSMenuItem.Enabled = true;
                    userProductivityReportTSMenuItem.Enabled = true;

                    //Batch Menu
                    batchMenu.Enabled = true;
                    batchMenu.Visible = true;
                    //Batch Menu Sub-Menu Items
                    //Visible = true
                    //insertBatchToolStripMenuItem.Visible = true;
                    //distributeBatchToolStripMenuItem.Visible = true;
                    moveToBatchToolStripMenuItem.Visible = true;
                    keywordSearchToolStripMenuItem.Visible = true;
                    //Enabled = true
                    //insertBatchToolStripMenuItem.Enabled = true;
                    //distributeBatchToolStripMenuItem.Enabled = true;
                    moveToBatchToolStripMenuItem.Enabled = true;
                    keywordSearchToolStripMenuItem.Enabled = true;

                    //Task Menu
                    taskMenu.Enabled = true;
                    taskMenu.Visible = true;
                    //Task Menu Sub-Menu Items
                    assignmentToolStripMenuItem.Visible = true;
                    assignmentToolStripMenuItem.Enabled = true;

                    //Advanced Menu
                    advancedMenu.Enabled = true;
                    //Advanced Menu Sub-Menu Items
                    //Visible = true 
                    extractRSNToolStripMenuItem.Visible = true;
                    duplicateTANToolStripMenuItem.Visible = true;
                    finalCheckToolStripMenuItem.Visible = true;
                    orgRefToolStripMenuItem.Visible = true;
                    rSNFreeDictionaryToolStripMenuItem.Visible = true;
                    solventBoilingPointToolStripMenuItem.Visible = true;
                    series8500RegNosToolStripMenuItem.Visible = true;
                    clientFeedbackToolStripMenuItem.Visible = true;
                    sendMailToUsersToolStripMenuItem.Visible = true;
                    imageToPDFConvTSMnuItem.Visible = true;

                    //Enabled = true
                    extractRSNToolStripMenuItem.Enabled = true;
                    duplicateTANToolStripMenuItem.Enabled = true;
                    finalCheckToolStripMenuItem.Enabled = true;
                    orgRefToolStripMenuItem.Enabled = true;
                    rSNFreeDictionaryToolStripMenuItem.Enabled = true;
                    solventBoilingPointToolStripMenuItem.Enabled = true;
                    series8500RegNosToolStripMenuItem.Enabled = true;
                    clientFeedbackToolStripMenuItem.Enabled = true;
                    sendMailToUsersToolStripMenuItem.Enabled = true;
                    imageToPDFConvTSMnuItem.Enabled = true;
                    cTHReferenceTSMenuItem.Enabled = true;

                    //User Menu
                    userPrefsMenu.Enabled = true;
                    //User Menu Sub-Menu Items                    
                    teamStructureTSMenuItem.Visible = true;
                    teamStructureTSMenuItem.Enabled = true;                   

                }
                else if (userrole.Trim().ToUpper() == RolesMaster.QC_ANALYST.ToUpper())
                {
                    loadTANtoolStripMenuItem.Visible = true;
                    loadTANtoolStripMenuItem.Enabled = true;
                    IndexingTSMenuItem.Enabled = true;

                    //Search Menu
                    searchMenu.Enabled = true;
                        listOfTANsToolStripMenuItem.Visible = true;
                        listOfTANsToolStripMenuItem.Enabled = true;
                        //Search Menu Sub-Menu Items   
                        tANSearchToolStripMenuItem.Visible = true;
                        nUMSearchToolStripMenuItem.Visible = true;
                        tANSearchToolStripMenuItem.Enabled = true;
                        nUMSearchToolStripMenuItem.Enabled = true;

                    //Export Menu
                    exportMenu.Enabled = true;
                        //Search Menu Sub-Menu Items
                        exporttoXMLToolStripMenuItem.Visible = true;
                        exporttoXMLToolStripMenuItem.Enabled = true;                       

                    //Validate Menu
                    validateMenu.Enabled = true;
                        //Validate Menu Sub-Menu Items
                       validateXMLToolStripMenuItem.Visible = true;                      
                       rSDToolStripMenuItem.Visible = true;
                       validateXMLToolStripMenuItem.Enabled = true;                                  
                       rSDToolStripMenuItem.Enabled = true;

                   //Report Menu
                   reportMenu.Enabled = true;
                   reportMenu.Visible = true;
                       //Reports Menu Sub-Menu Items                                            
                       dailyStatusReportToolStripMenuItem.Visible = true;
                       dailyStatusReportToolStripMenuItem.Enabled = true;
                       monthlyReportToolStripMenuItem.Visible = true;
                       monthlyReportToolStripMenuItem.Enabled = true;

                       //Advanced Menu
                    advancedMenu.Enabled = true;
                        //Advanced Menu Sub-Menu Items  
                        orgRefToolStripMenuItem.Visible = true;
                        solventBoilingPointToolStripMenuItem.Visible = true; 
                        orgRefToolStripMenuItem.Enabled = true;                        
                        solventBoilingPointToolStripMenuItem.Enabled = true;
                        cTHReferenceTSMenuItem.Enabled = true; 

                    //User Menu
                    //userPrefsMenu.Enabled = true;
                        //User Menu Sub-Menu Items
                        //changePasswordToolStripMenuItem.Visible = true;
                        //changePasswordToolStripMenuItem.Enabled = true;                    
                }
                else if (userrole.Trim().ToUpper() == RolesMaster.ADMIN.ToUpper())
                {
                    IndexingTSMenuItem.Enabled = true;

                    //Search Menu
                    searchMenu.Enabled = true;
                    //Search Menu Sub-Menu Items
                    //Visible = true
                    listOfTANsToolStripMenuItem.Visible = true;
                    tANSearchToolStripMenuItem.Visible = true;
                    nUMSearchToolStripMenuItem.Visible = true;
                    //Enabled = true
                    listOfTANsToolStripMenuItem.Enabled = true;
                    tANSearchToolStripMenuItem.Enabled = true;
                    nUMSearchToolStripMenuItem.Enabled = true;

                    //Export Menu
                    exportMenu.Enabled = true;
                    //Search Menu Sub-Menu Items
                    //Visible = true
                    exporttoXMLToolStripMenuItem.Visible = true;
                    toBatchXMLToolStripMenuItem.Visible = true;
                    //Enabled = true
                    exporttoXMLToolStripMenuItem.Enabled = true;
                    toBatchXMLToolStripMenuItem.Enabled = true;
                                        
                    //Validate Menu
                    validateMenu.Enabled = true;
                    //Validate Menu Sub-Menu Items
                    //Visible = true
                    validateXMLToolStripMenuItem.Visible = true;                    
                    rSDToolStripMenuItem.Visible = true;
                    //Enabled = true
                    validateXMLToolStripMenuItem.Enabled = true;                   
                    rSDToolStripMenuItem.Enabled = true;

                    //Reports Menu
                    reportMenu.Enabled = true;
                    reportMenu.Visible = true;
                    //Reports Menu Sub-Menu Items
                    //Visible = true
                    //shipmentReportToolStripMenuItem.Visible = true;
                    multiShipmentsStatusReportTSMenuItem.Visible = true;
                    multiShipmentsStatusReportTSMenuItem.Enabled = true;
                    errorSummaryReportToolStripMenuItem.Visible = true;
                    tANStatusReportToolStripMenuItem.Visible = true;
                    //batchTANStatusReportTSMnuItem.Visible = true;
                    errorLogReportToolStripMenuItem.Visible = true;
                    userTANErrorLogReportToolStripMenuItem.Visible = true;
                    dailyStatusReportToolStripMenuItem.Visible = true;
                    monthlyReportToolStripMenuItem.Visible = true;
                    shipmentTanNUMsForPDfExportToolStripMenuItem.Visible = true;
                    userErrorsReportTSMenuItem.Visible = true;
                    userProductivityReportTSMenuItem.Visible = true;
                    //Enabled = true
                    //shipmentReportToolStripMenuItem.Enabled = true;
                    errorSummaryReportToolStripMenuItem.Enabled = true;
                    tANStatusReportToolStripMenuItem.Enabled = true;
                    //batchTANStatusReportTSMnuItem.Enabled = true;
                    errorLogReportToolStripMenuItem.Enabled = true;
                    userTANErrorLogReportToolStripMenuItem.Enabled = true;
                    dailyStatusReportToolStripMenuItem.Enabled = true;
                    monthlyReportToolStripMenuItem.Enabled = true;
                    shipmentTanNUMsForPDfExportToolStripMenuItem.Enabled = true;
                    userErrorsReportTSMenuItem.Enabled = true;
                    userProductivityReportTSMenuItem.Enabled = true;

                    //Batch Menu
                    batchMenu.Enabled = true;
                    batchMenu.Visible = true;
                    //Batch Menu Sub-Menu Items
                    //Visible = true
                    insertBatchToolStripMenuItem.Visible = true;
                    distributeBatchToolStripMenuItem.Visible = true;
                    moveToBatchToolStripMenuItem.Visible = true;
                    keywordSearchToolStripMenuItem.Visible = true;
                    //Enabled = true
                    insertBatchToolStripMenuItem.Enabled = true;
                    distributeBatchToolStripMenuItem.Enabled = true;
                    moveToBatchToolStripMenuItem.Enabled = true;
                    keywordSearchToolStripMenuItem.Enabled = true;

                    //Task Menu
                    taskMenu.Enabled = true;
                    //Task Menu Sub-Menu Items
                    assignmentToolStripMenuItem.Visible = true;
                    assignmentToolStripMenuItem.Enabled = true;

                    //Advanced Menu
                    advancedMenu.Enabled = true;
                    //Advanced Menu Sub-Menu Items
                    //Visible = true 
                    extractRSNToolStripMenuItem.Visible = true;
                    duplicateTANToolStripMenuItem.Visible = true;
                    finalCheckToolStripMenuItem.Visible = true;
                    orgRefToolStripMenuItem.Visible = true;
                    rSNFreeDictionaryToolStripMenuItem.Visible = true;
                    solventBoilingPointToolStripMenuItem.Visible = true;
                    series8500RegNosToolStripMenuItem.Visible = true;
                    clientFeedbackToolStripMenuItem.Visible = true;
                    sendMailToUsersToolStripMenuItem.Visible = true;
                    imageToPDFConvTSMnuItem.Visible = true;

                    //Enabled = true
                    extractRSNToolStripMenuItem.Enabled = true;
                    duplicateTANToolStripMenuItem.Enabled = true;
                    finalCheckToolStripMenuItem.Enabled = true;
                    orgRefToolStripMenuItem.Enabled = true;
                    rSNFreeDictionaryToolStripMenuItem.Enabled = true;
                    solventBoilingPointToolStripMenuItem.Enabled = true;
                    series8500RegNosToolStripMenuItem.Enabled = true;
                    clientFeedbackToolStripMenuItem.Enabled = true;
                    sendMailToUsersToolStripMenuItem.Enabled = true;
                    imageToPDFConvTSMnuItem.Enabled = true;
                    cTHReferenceTSMenuItem.Enabled = true;
                    //User Menu
                    userPrefsMenu.Enabled = true;
                    //User Menu Sub-Menu Items
                    //Visible = true
                    //changePasswordToolStripMenuItem.Visible = true;
                    userAccountsToolStripMenuItem.Visible = true;
                    //Enabled = true
                    //changePasswordToolStripMenuItem.Enabled = true;
                    userAccountsToolStripMenuItem.Enabled = true;
                }
                else if (userrole.Trim().ToUpper() == RolesMaster.ANALYST.ToUpper() || userrole.Trim().ToUpper() == RolesMaster.REV_ANALYST.ToUpper())
                {
                    loadTANtoolStripMenuItem.Visible = true;
                    loadTANtoolStripMenuItem.Enabled = true;

                    if (GlobalVariables.ApplicationName == Enums.ApplicationName.MACRO.ToString() || GlobalVariables.ApplicationName == Enums.ApplicationName.ORGANIC.ToString())
                    {
                        IndexingTSMenuItem.Enabled = true;
                    }
                    else
                    {
                        IndexingTSMenuItem.Enabled = false;
                    }

                    //Search Menu
                    searchMenu.Enabled = true;
                    //Search Menu Sub-Menu Items 
                    tANSearchToolStripMenuItem.Visible = true;
                    nUMSearchToolStripMenuItem.Visible = true;
                    tANSearchToolStripMenuItem.Enabled = true;
                    nUMSearchToolStripMenuItem.Enabled = true;

                    //Export Menu
                    exportMenu.Enabled = true;
                    //Search Menu Sub-Menu Items
                    exporttoXMLToolStripMenuItem.Visible = true; 
                    exporttoXMLToolStripMenuItem.Enabled = true;                    

                    //Validate Menu
                    validateMenu.Enabled = true;
                    //Validate Menu Sub-Menu Items
                    validateXMLToolStripMenuItem.Visible = true;                   
                    rSDToolStripMenuItem.Visible = true; 
                    validateXMLToolStripMenuItem.Enabled = true;                   
                    rSDToolStripMenuItem.Enabled = true;

                    //Report Menu
                    reportMenu.Enabled = true;
                    reportMenu.Visible = true;
                    //Reports Menu Sub-Menu Items                                            
                    dailyStatusReportToolStripMenuItem.Visible = true;
                    dailyStatusReportToolStripMenuItem.Enabled = true;
                    monthlyReportToolStripMenuItem.Visible = true;
                    monthlyReportToolStripMenuItem.Enabled = true;

                    //Advanced Menu
                    advancedMenu.Enabled = true;
                    //Advanced Menu Sub-Menu Items  
                    orgRefToolStripMenuItem.Visible = true;
                    solventBoilingPointToolStripMenuItem.Visible = true; 
                    orgRefToolStripMenuItem.Enabled = true;                   
                    solventBoilingPointToolStripMenuItem.Enabled = true;
                    cTHReferenceTSMenuItem.Enabled = true;
                    //User Menu
                    //userPrefsMenu.Enabled = true;
                    //User Menu Sub-Menu Items
                    //changePasswordToolStripMenuItem.Visible = true; 
                    //changePasswordToolStripMenuItem.Enabled = true;                   
                }
            }
            catch (Exception ex)
            {
               ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                 DialogResult diaRes = MessageBox.Show("Do you want to exit?",GlobalVariables.MessageCaption,MessageBoxButtons.YesNo,MessageBoxIcon.Question);
                 if (diaRes == DialogResult.Yes)
                 {
                     ApplicationOperationTracking.LogOperation(exitToolStripMenuItem.Text);
                     this.Close();
                 }
            }
            catch (Exception ex)
            {
               ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void aboutIRNToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                frmAbout frmAbt = new frmAbout();
                frmAbt.ShowDialog();
            }
            catch (Exception ex)
            {
               ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void frmMDIMain_Load(object sender, EventArgs e)
        {
            try
            {
                //Set ChemAxon License
                ChemistryOperations.SetChemaxonLicenseFilePath(AppDomain.CurrentDomain.BaseDirectory + "license.cxl");//AppDomain.CurrentDomain.BaseDirectory 

                this.Text = "CAS-IRN   " + Assembly.GetExecutingAssembly().GetName().Version.ToString();

                //Disable all menu items in page load
                DisableMenu_SubMenuItems();

                #region MyRegion
                ////Get OrGrefData from Database and assign to Global DataTable
                //if (GlobalVariables.OrGrefTbl == null)
                //{
                //    GlobalVariables.OrGrefTbl = ReactDataAccess.GetOrgRefMasterDataOnNumType(9000);                    
                //}

                ////Get RSN CVT and Save in Global Datatable
                //DataTable dtRSNCvt = ReactDataAccess.GetRsnCVTDetails();
                //if (dtRSNCvt != null)
                //{
                //    GlobalVariables.RSN_CVT_Tbl = dtRSNCvt;
                //}

                ////Get Stage level FreeText and Save in Global DataTable
                //DataTable dtFreeText_Stage = ReactDataAccess.GetStagelLevelRSN_FreeText_Details();
                //if (dtFreeText_Stage != null)
                //{
                //    GlobalVariables.RSN_StageFreeTextTbl = dtFreeText_Stage;
                //}

                ////Get RSN FreeText and Save in Global Datatable
                //DataTable dtRSNFText = ReactDataAccess.GetRSNFreeTextDetails();
                //if (dtRSNFText != null)
                //{
                //    GlobalVariables.RSN_FreeText_Tbl = dtRSNFText;
                //}

                ////Get Empty Stage RSN terms and save in Global Data Table
                //DataTable dtRSNFreeText = ReactDataAccess.GetEmptyStageRSNTerms();
                //if (dtRSNFreeText != null)
                //{
                //    GlobalVariables.EmptyStage_RSNs = dtRSNFreeText;
                //}

                ////Get Solvent Boiling Points and save in Global Data Table
                //DataTable dtSolv_BP = ReactDataAccess.GetSolventBoilingPoints();
                //if (dtSolv_BP != null)
                //{
                //    GlobalVariables.Solvent_BPoints = dtSolv_BP;
                //}                             
                #endregion
                          
                //Open Login form
                logintoolStripMenuItem_Click(null, null);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void LoadMasterTablesOnApplication(string appName)
        {
            try
            {
                if (!string.IsNullOrEmpty(appName))
                {
                    if (appName.ToUpper() == Enums.ApplicationName.REACT.ToString() || appName.ToUpper() == Enums.ApplicationName.ORGANIC.ToString()
                        || appName.ToUpper() == Enums.ApplicationName.MACRO.ToString())
                    {
                        //Get Series 9000 OrGrefData from Database and assign to Global DataTable
                        if (Generic.GlobalVariables.Ser9000OrgRefData == null)
                        {
                            //DataTable dtSer9000 = ReactDB.GetOrgRefMasterDataOnNumType(9000);
                            //DataSet dsSerTemp = new DataSet("Series9000");
                            //dsSerTemp.Tables.Add(dtSer9000);
                            //dsSerTemp.WriteXml(System.IO.Path.Combine(Application.StartupPath, "OrgRef9000.xml"));

                            Thread trdDictionary = new Thread(delegate()
                            {
                                if (File.Exists(System.IO.Path.Combine(Application.StartupPath, "OrgRef9000.xml")))
                                {
                                    DataSet dsSer9000 = new DataSet("Series9000");
                                    dsSer9000.ReadXml(System.IO.Path.Combine(Application.StartupPath, "OrgRef9000.xml"));
                                    GlobalVariables.Ser9000OrgRefData = dsSer9000.Tables[0];
                                }
                            });

                            trdDictionary.IsBackground = true;
                            trdDictionary.Start();

                        }

                        //Get Series 8500 OrGrefData from Database and assign to Global DataTable
                        if (Generic.GlobalVariables.Ser8500OrgrefData == null)
                        {
                            //DataTable dtSer8500 = ReactDB.GetOrgRefMasterDataOnNumType(8500);
                            //DataSet dsSerTemp = new DataSet("Series8500");
                            //dsSerTemp.Tables.Add(dtSer8500);
                           // dsSerTemp.WriteXml(System.IO.Path.Combine(Application.StartupPath, "OrgRef8500.xml"));

                            Thread trdDictionary = new Thread(delegate()
                            {
                                if (File.Exists(System.IO.Path.Combine(Application.StartupPath, "OrgRef8500.xml")))
                                {
                                    DataSet dsSer8500 = new DataSet("Series8500");
                                    dsSer8500.ReadXml(System.IO.Path.Combine(Application.StartupPath, "OrgRef8500.xml"));
                                    GlobalVariables.Ser8500OrgrefData = dsSer8500.Tables[0];
                                }
                            });

                            trdDictionary.IsBackground = true;
                            trdDictionary.Start();

                        }

                        //Get RSN CVT and Save in Global Datatable          
                        if (Generic.GlobalVariables.RSN_CVT_Tbl == null)
                        {
                            Generic.GlobalVariables.RSN_CVT_Tbl = ReactDB.GetRsnCVT_FreeTextOnType("CVT");
                        }

                        //Get Stage level FreeText and Save in Global DataTable           
                        if (Generic.GlobalVariables.RSN_StageFreeTextTbl == null)
                        {
                            Generic.GlobalVariables.RSN_StageFreeTextTbl = ReactDB.GetRsnCVT_FreeTextOnType("STAGE");
                        }

                        //Get RSN FreeText and Save in Global Datatable                 
                        if (Generic.GlobalVariables.RSN_FreeText_Tbl == null)
                        {
                            Generic.GlobalVariables.RSN_FreeText_Tbl = ReactDB.GetRsnCVT_FreeTextOnType("FREETEXT");
                        }

                        ////Get Empty Stage RSN terms and save in Global Data Table
                        //DataTable dtRSNFreeText = CASRxnDataAccess.GetEmptyStageRSNTerms();
                        //if (dtRSNFreeText != null)
                        //{
                        //    Generic.GlobalVariables.EmptyStage_RSNs = dtRSNFreeText;
                        //}

                        //Get Solvent Boiling Points and save in Global Data Table               
                        if (Generic.GlobalVariables.Solvent_BPoints == null)
                        {
                            Generic.GlobalVariables.Solvent_BPoints = ReactDB.GetSolventBoilingPoints();
                        }

                        //Xml Conversions 
                        if (Generic.GlobalVariables.XMLConvTbl == null)
                        {
                            GlobalVariables.XMLConvTbl = IndxReactNarrDAL.ReactDB.GetXMLConvDetails();
                        }

                        if (appName.ToUpper() == Enums.ApplicationName.ORGANIC.ToString() || appName.ToUpper() == Enums.ApplicationName.MACRO.ToString())
                        {
                            //Indexing Roles
                            if (GlobalVariables.IndexingRoles == null)
                                GlobalVariables.IndexingRoles = OrganicIndexingDB.GetIndexingRoleIndicators();

                            //Section Master
                            if (GlobalVariables.IndexingSections == null)
                                GlobalVariables.IndexingSections = OrganicIndexingDB.GetIndexingSectionMasterDetails();

                            //SubSections
                            if (GlobalVariables.IndexingSubSections == null)
                                GlobalVariables.IndexingSubSections = OrganicIndexingDB.GetIndexingSubSections();

                            //Concept Text Headings
                            if (GlobalVariables.ConceptTextHeadings == null)
                                GlobalVariables.ConceptTextHeadings = OrganicIndexingDB.GetIndexingConceptTextHeadings();
                        }
                    }
                    else if (appName.ToUpper() == Enums.ApplicationName.NARRATIVES.ToString() || appName.ToUpper() == Enums.ApplicationName.EXPPROCEDURES.ToString())
                    {
                        //Narratives Highlighting Data
                        DataTable dtSplChars = NarrativesDB.GetSpecialCharsReplacementsOnApplication(Enums.ApplicationName.NARRATIVES.ToString());
                        DataView dvTemp = dtSplChars.DefaultView;
                        dvTemp.RowFilter = "USED_FOR = 'HIGHLIGHT'";
                        GlobalVariables.NarrHighLightingData = dvTemp.ToTable();

                        //Narratives Replacements Data
                        DataView dvConversion = dtSplChars.DefaultView;
                        dvConversion.RowFilter = "USED_FOR = 'REPLACEMENT'";
                        GlobalVariables.NarrReplacementData = dvConversion.ToTable();

                        if (GlobalVariables.FindingTypesData == null)
                        {
                            GlobalVariables.FindingTypesData = NarrativesDB.GetFindingTypesMasterData();
                        }

                        if (GlobalVariables.MaterialsData == null)
                        {
                            GlobalVariables.MaterialsData = NarrativesDB.GetMaterialsMasterData();
                        }

                        if (GlobalVariables.FindingTypeReplData == null)
                        {
                            GlobalVariables.FindingTypeReplData = NarrativesDB.GetFindingTypeReplacements();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void logintoolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                using (frmLogin objLogin = new frmLogin())
                {
                    if (objLogin.ShowDialog() == DialogResult.OK)
                    {
                        Cursor = Cursors.WaitCursor;

                        tSStatusLbl_UName.Text = GlobalVariables.UserName;
                        tSStatusLblRoleName.Text = GlobalVariables.RoleName;

                        tSStatusLblAppModuleName.Text = GlobalVariables.ModuleName;
                        tSStatusLblAppName.Text = GlobalVariables.ApplicationName;
                        
                        EnableMenu_SubMenuItems(GlobalVariables.RoleName);

                        logintoolStripMenuItem.Enabled = false;
                        logOffToolStripMenuItem.Enabled = true;

                        //Load Master table on Application
                        LoadMasterTablesOnApplication(GlobalVariables.ApplicationName);

                        if (GlobalVariables.RoleName.ToUpper() == RolesMaster.ANALYST.ToUpper() || GlobalVariables.RoleName.ToUpper() == RolesMaster.REV_ANALYST.ToUpper()
                            || GlobalVariables.RoleName.ToUpper() == RolesMaster.QC_ANALYST.ToUpper())
                        {
                            loadTANtoolStripMenuItem_Click(null, null);
                        }

                        Cursor = Cursors.Default;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void logOffToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult diaRes = MessageBox.Show("Do you want to log off the IRN?",GlobalVariables.MessageCaption,MessageBoxButtons.YesNo,MessageBoxIcon.Question);

                if (diaRes == DialogResult.Yes)
                {
                    ApplicationOperationTracking.LogOperation(logOffToolStripMenuItem.Text);

                    Form[] frmColl = this.MdiChildren;
                    foreach (Form frm in frmColl)
                    {
                        frm.Close();
                    }

                    DisableMenu_SubMenuItems();

                    logintoolStripMenuItem.Enabled = true;
                    logOffToolStripMenuItem.Enabled = false;

                    //Reset User information
                    tSStatusLbl_UName.Text = "";
                    tSStatusLblRoleName.Text = "";
                    tSStatusLblAppName.Text = "-";
                    tSStatusLblAppModuleName.Text = "-";
                    
                    logintoolStripMenuItem_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void assignmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(assignmentToolStripMenuItem.Text);
                
                frmTaskAssignment objTaskAssign = new frmTaskAssignment();
                objTaskAssign.MdiParent = this;
                objTaskAssign.Show();                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        //private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        ApplicationOperationTracking.LogOperation(changePasswordToolStripMenuItem.Text);

        //        UserManagement.frmChangePwd objChangePwd = new UserManagement.frmChangePwd();
        //        objChangePwd.ShowDialog();
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}

        private void createToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(createToolStripMenuItem.Text);

                frmUserCreate objCreateUser = new frmUserCreate();
                objCreateUser.MdiParent = this;
                objCreateUser.Show();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void insertBatchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(insertBatchToolStripMenuItem.Text);

                if (GlobalVariables.ApplicationName.ToUpper() == Enums.ApplicationName.ORGANIC.ToString() || GlobalVariables.ApplicationName.ToUpper() == Enums.ApplicationName.MACRO.ToString())
                {
                    OpenOrgIndexingLoadShipmentForm();
                }
                else if (GlobalVariables.ApplicationName.ToUpper() == Enums.ApplicationName.REACT.ToString())
                {
                    OpenReactLoadShipmentForm();
                }
                else if (GlobalVariables.ApplicationName.ToUpper() == Enums.ApplicationName.NARRATIVES.ToString())
                {
                    OpenNarrativesLoadShipmentForm();
                }
                else if (GlobalVariables.ApplicationName.ToUpper() == Enums.ApplicationName.EXPPROCEDURES.ToString())
                {
                    OpenExperimentalLoadShipmentForm();
                }
                //else if (GlobalVariables.ApplicationName.ToUpper() == Enums.ApplicationName.EXPPROCEDURES_2.ToString())
                //{
                //    OpenExperimental2LoadShipmentForm();
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void OpenOrgIndexingLoadShipmentForm()
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmImportIndexingTANs_New frmIndxImport = null;

                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMIMPORTINDEXINGTANS_NEW")
                    {
                        frmIndxImport = (frmImportIndexingTANs_New)frm;

                        blFrmOpen = true;
                        frmIndxImport.Show();
                        frmIndxImport.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    frmIndxImport = new frmImportIndexingTANs_New();
                    frmIndxImport.MdiParent = this;
                    frmIndxImport.Show();
                }
            }
            catch (Exception ex)
            {                
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void OpenReactLoadShipmentForm()
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmImportReactShipment frmIndxImport = null;

                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMIMPORTREACTSHIPMENT")
                    {
                        frmIndxImport = (frmImportReactShipment)frm;

                        blFrmOpen = true;
                        frmIndxImport.Show();
                        frmIndxImport.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    frmIndxImport = new frmImportReactShipment();
                    frmIndxImport.MdiParent = this;
                    frmIndxImport.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void OpenNarrativesLoadShipmentForm()
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmImportNarrShipment frmNarrImport = null;

                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMIMPORTNARRSHIPMENT")
                    {
                        frmNarrImport = (frmImportNarrShipment)frm;

                        blFrmOpen = true;
                        frmNarrImport.Show();
                        frmNarrImport.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    frmNarrImport = new frmImportNarrShipment();
                    frmNarrImport.MdiParent = this;
                    frmNarrImport.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void OpenExperimentalLoadShipmentForm()
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmImportExpProceduresShipment frmExpProcImport = null;

                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMIMPORTEXPPROCEDURESSHIPMENT")
                    {
                        frmExpProcImport = (frmImportExpProceduresShipment)frm;

                        blFrmOpen = true;
                        frmExpProcImport.Show();
                        frmExpProcImport.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    frmExpProcImport = new frmImportExpProceduresShipment();
                    frmExpProcImport.MdiParent = this;
                    frmExpProcImport.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void OpenExperimental2LoadShipmentForm()
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmImportExpProcedures2Shipment frmExpProcImport2 = null;

                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMIMPORTEXPPROCEDURESSHIPMENT_NEWPILOT")
                    {
                        frmExpProcImport2 = (frmImportExpProcedures2Shipment)frm;

                        blFrmOpen = true;
                        frmExpProcImport2.Show();
                        frmExpProcImport2.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    frmExpProcImport2 = new frmImportExpProcedures2Shipment();
                    frmExpProcImport2.MdiParent = this;
                    frmExpProcImport2.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void distributeBatchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(distributeBatchToolStripMenuItem.Text);

                //TaskManagement.frmDistributeBatch objDistBatch = new IndxReactNarr.TaskManagement.frmDistributeBatch();
                //objDistBatch.ShowDialog();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public void loadTANtoolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(loadTANtoolStripMenuItem.Text);
                              
                Cursor = Cursors.WaitCursor;
                
                DataTable dtAssignedTans = TaskManagementDB.GetUserTasksOnModule(GlobalVariables.URID, GlobalVariables.ApplicationName, GlobalVariables.ModuleName);
               
                frmTaskSheet usrTaskSheet = new frmTaskSheet();
                usrTaskSheet.AssignedTANs = dtAssignedTans;
                if (usrTaskSheet.ShowDialog() == DialogResult.OK)
                {
                    AnalystId = usrTaskSheet.ANALYST_ID;

                    if (usrTaskSheet.SelectedModule.ToUpper() == AppVariables.ReactModule)
                    {
                        LoadTANInReactionCurationForm(usrTaskSheet.TAN_ID, usrTaskSheet.Task_ID, usrTaskSheet.TaskAllocation_ID);
                    }
                    else if (usrTaskSheet.SelectedModule.ToUpper() == AppVariables.NarrModule && GlobalVariables.ApplicationName == Enums.ApplicationName.NARRATIVES.ToString())
                    {
                        LoadTANInNarrativesCurationForm(usrTaskSheet.TAN_ID, usrTaskSheet.Task_ID, usrTaskSheet.TaskAllocation_ID);
                    }
                    else if (usrTaskSheet.SelectedModule.ToUpper() == AppVariables.ExpProcModule && GlobalVariables.ApplicationName == Enums.ApplicationName.EXPPROCEDURES.ToString())
                    {
                        LoadTANInExpProceduresCurationForm(usrTaskSheet.TAN_ID, usrTaskSheet.Task_ID, usrTaskSheet.TaskAllocation_ID);
                    }
                    else if (usrTaskSheet.SelectedModule.ToUpper() == AppVariables.OrgIndxModule && GlobalVariables.ApplicationName == Enums.ApplicationName.ORGANIC.ToString())
                    {
                        LoadTANInOrganicIndexingCurationForm(usrTaskSheet.TAN_ID, usrTaskSheet.Task_ID, usrTaskSheet.TaskAllocation_ID);
                    }
                    else if (usrTaskSheet.SelectedModule.ToUpper() == AppVariables.OrgIndxModule && GlobalVariables.ApplicationName == Enums.ApplicationName.MACRO.ToString())
                    {
                        LoadTANInMacroIndexingCurationForm(usrTaskSheet.TAN_ID, usrTaskSheet.Task_ID, usrTaskSheet.TaskAllocation_ID);
                    }
                   
                }               
                Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        /// <summary>
        /// Load TAN In React Curation form
        /// </summary>
        /// <param name="tan_id"></param>
        private void LoadTANInReactionCurationForm(int tanID, int taskID, int taskAllocID)
        {
            try
            {
                frmReactCuration frmEntry = null;
                FormCollection frmColl = Application.OpenForms;
                foreach (Form objfrm in frmColl)
                {
                    if (objfrm.Name.ToUpper() == "FRMRXNENTRYSCREEN")
                    {
                        frmEntry = (frmReactCuration)objfrm;
                        frmEntry.Close();
                        break;
                    }
                }
                frmEntry = new frmReactCuration();
                frmEntry.TAN_ID = tanID;
                frmEntry.Task_ID = taskID;
                frmEntry.TaskAlloc_ID = taskAllocID;
                //frmEntry.TAN_Freezed = Convert.ToBoolean(_dtTanDetails.Rows[0]["tan_freezed"].ToString());
                frmEntry.MdiParent = this;
                frmEntry.Show();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        /// <summary>
        /// Load TAN in Organic Indexing form
        /// </summary>
        /// <param name="tan_id"></param>
        private void LoadTANInOrganicIndexingCurationForm(int tanID, int taskID, int taskAllocID)
        {
            try
            {
                frmOrganicIndexing frmIndexing = null;
                FormCollection frmColl = Application.OpenForms;
                foreach (Form objfrm in frmColl)
                {
                    if (objfrm.Name.ToUpper() == "FRMORGANICINDEXING")
                    {
                        frmIndexing = (frmOrganicIndexing)objfrm;
                        frmIndexing.Close();
                        break;
                    }
                }
                frmIndexing = new frmOrganicIndexing();
                frmIndexing.TAN_ID = tanID;
                frmIndexing.Task_ID = taskID;
                frmIndexing.TaskAlloc_ID = taskAllocID;
                frmIndexing.MdiParent = this;
                frmIndexing.Show();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        /// <summary>
        /// Load TAN in Narratives form
        /// </summary>
        /// <param name="tan_id"></param>
        private void LoadTANInNarrativesCurationForm(int tanID, int taskID, int taskAllocID)
        {
            try
            {
                frmNarrCuration_New frmNarratives = null;
                FormCollection frmColl = Application.OpenForms;
                foreach (Form objfrm in frmColl)
                {
                    if (objfrm.Name.ToUpper() == "FRMNARRCURATION_NEW")
                    {
                        frmNarratives = (frmNarrCuration_New)objfrm;
                        frmNarratives.Close();
                        break;
                    }
                }
                frmNarratives = new frmNarrCuration_New();
                frmNarratives.TAN_ID = tanID;
                frmNarratives.Task_ID = taskID;
                frmNarratives.TaskAlloc_ID = taskAllocID;
                frmNarratives.MdiParent = this;
                frmNarratives.Show();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void LoadTANInExpProceduresCurationForm(int tanID, int taskID, int taskAllocID)
        {
            try
            {
                frmExpProceduresCuration frmExpProc = null;
                FormCollection frmColl = Application.OpenForms;
                foreach (Form objfrm in frmColl)
                {
                    if (objfrm.Name.ToUpper() == "FRMEXPPROCEDURESCURATION")
                    {
                        frmExpProc = (frmExpProceduresCuration)objfrm;
                        frmExpProc.Close();
                        break;
                    }
                }
                frmExpProc = new frmExpProceduresCuration();
                frmExpProc.TAN_ID = tanID;
                frmExpProc.Task_ID = taskID;
                frmExpProc.TaskAlloc_ID = taskAllocID;
                frmExpProc.MdiParent = this;
                frmExpProc.Show();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void LoadTANInMacroIndexingCurationForm(int tanID, int taskID, int taskAllocID)
        {
            try
            {
                frmMacroIndexing frmIndexing = null;
                FormCollection frmColl = Application.OpenForms;
                foreach (Form objfrm in frmColl)
                {
                    if (objfrm.Name.ToUpper() == "FRMMACROINDEXING")
                    {
                        frmIndexing = (frmMacroIndexing)objfrm;
                        frmIndexing.Close();
                        break;
                    }
                }
                frmIndexing = new frmMacroIndexing();
                frmIndexing.TAN_ID = tanID;
                frmIndexing.Task_ID = taskID;
                frmIndexing.TaskAlloc_ID = taskAllocID;
                frmIndexing.MdiParent = this;
                frmIndexing.Show();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void moveToBatchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(moveToBatchToolStripMenuItem.Text);

                frmMoveTanToBatch objMoveBatch = new frmMoveTanToBatch();
                objMoveBatch.ShowDialog();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void duplicateTANToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(duplicateTANToolStripMenuItem.Text);
                
                //frmDuplicateTAN objDupTAN = new frmDuplicateTAN();
                //objDupTAN.ShowDialog();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void extractRSNToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(extractRSNToolStripMenuItem.Text);

                FormCollection frmColl = Application.OpenForms;
                frmExtractRSN objfrmExtract = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMEXTRACTRSN")
                    {
                        objfrmExtract = (frmExtractRSN)frm;

                        blFrmOpen = true;
                        objfrmExtract.Show();
                        objfrmExtract.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objfrmExtract = new frmExtractRSN();
                    objfrmExtract.MdiParent = this;
                    objfrmExtract.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void validateXMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(validateXMLToolStripMenuItem.Text);

                FormCollection frmColl = Application.OpenForms;
                frmXMLValidation xmlView_Valid = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMXMLVALIDATION")
                    {
                        xmlView_Valid = (frmXMLValidation)frm;

                        blFrmOpen = true;
                        xmlView_Valid.Show();
                        xmlView_Valid.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    xmlView_Valid = new frmXMLValidation();
                    xmlView_Valid.MdiParent = this;
                    xmlView_Valid.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }    
                

        private void toBatchXMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(toBatchXMLToolStripMenuItem.Text);
                
                frmBatchXml objBatch = new frmBatchXml();
                objBatch.MdiParent = this;
                objBatch.Show();

                //if (objBatch.ShowDialog() == DialogResult.OK)
                //{
                //    Cursor = Cursors.WaitCursor;

                //    IndxReactNarr.Export.INR_Export objB_XML = new IndxReactNarr.Export.INR_Export();// IndxReactNarr.CAS_XML.WriteXML_Batch();
                //    objB_XML.TANsForExport = objBatch.Batch_TANS;
                //    objB_XML.OutputFileName = objBatch.FileName;
                //    //objB_XML.Source = "GVKbio";
                //    //objB_XML.Version = "2";
                //    objB_XML.TrimReactXml = objBatch.TrimXml;
                //    //objB_XML.GenerateNarrXmls = objBatch.GenerateNarrXmls;
                //    //objB_XML.GenerateIdxDAT_Sdf = objBatch.GenerateIdxDAT_Sdf;

                //    if (objB_XML.ExportTANsDataToFiles())
                //    {
                //        MessageBox.Show("Generated Xml file successfully", "Write Xml", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        
                //        //Freeze TANs once xml file is generated
                //        if (objBatch.FreezeTANs && objBatch.SelectedTANs != null)
                //        {
                //           // CASRxnDataAccess.FreezeTANs(objBatch.SelectedTANs);
                //        }

                //        Cursor = Cursors.Default;
                //    }
                //    else
                //    {
                //        MessageBox.Show("Error in writing Xml file", "Write Xml", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //        Cursor = Cursors.Default;
                //    }
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
                Cursor = Cursors.Default;
            }
        }      

        private void errorSummaryReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(errorSummaryReportToolStripMenuItem.Text);
                
                //Reports.frmTANErrorSummary objErrSumm = null;

                //bool frmOpen = false;
                //FormCollection frmColl = Application.OpenForms;
                //foreach (Form objfrm in frmColl)
                //{
                //    if (objfrm.Name.ToUpper() == "FRMTANERRORSUMMARY")
                //    {
                //        objErrSumm = (Reports.frmTANErrorSummary)objfrm;
                //        objErrSumm.WindowState = FormWindowState.Maximized;
                //        objErrSumm.Show();
                //        frmOpen = true;
                //        break;
                //    }
                //}
                //if (!frmOpen)
                //{
                //    objErrSumm = new Reports.frmTANErrorSummary();
                //    objErrSumm.MdiParent = this;
                //    objErrSumm.Show();
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tANSearchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(tANSearchToolStripMenuItem.Text);

                frmTANReactionsReport frmRxnRep = null;
                bool frmOpen = false;
                FormCollection frmColl = Application.OpenForms;

                foreach (Form objfrm in frmColl)
                {
                    if (objfrm.Name.ToUpper() == "FRMRXNREPORT")
                    {
                        frmRxnRep = (frmTANReactionsReport)objfrm;
                        frmRxnRep.WindowState = FormWindowState.Maximized;
                        frmRxnRep.GetUserAssignedTANsBindToControl();
                        frmRxnRep.Show();
                        frmOpen = true;
                        break;
                    }
                }
                if (!frmOpen)
                {
                    frmRxnRep = new frmTANReactionsReport();
                    frmRxnRep.GetUserAssignedTANsBindToControl();
                    frmRxnRep.MdiParent = this;
                    frmRxnRep.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void listOfTANsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(listOfTANsToolStripMenuItem.Text);

                frmListOfTANs frmListofTans = null;

                bool frmOpen = false;
                FormCollection frmColl = Application.OpenForms;
                foreach (Form objfrm in frmColl)
                {
                    if (objfrm.Name.ToUpper() == "FRMLISTOFTANS")
                    {
                        frmListofTans = (frmListOfTANs)objfrm;
                        frmListofTans.WindowState = FormWindowState.Maximized;
                        frmListofTans.Show();
                        frmOpen = true;
                        break;
                    }
                }
                if (!frmOpen)
                {
                    frmListofTans = new frmListOfTANs();
                    frmListofTans.MdiParent = this;
                    frmListofTans.Show();
                }               
            }
            catch (Exception ex)
            {
               ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void nUMSearchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(nUMSearchToolStripMenuItem.Text);

                Cursor = Cursors.WaitCursor;
               
                FormCollection frmColl = Application.OpenForms;
                frmNUMSearch objNumSrch = null;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMNUMSEARCH")
                    {
                        objNumSrch = (frmNUMSearch)frm;
                        objNumSrch.Close();
                        break;
                    }
                }
                objNumSrch = new frmNUMSearch();
                objNumSrch.MdiParent = this;
                objNumSrch.Show();

                Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
               ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       

        private void cASREACTInputManualToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmCASREACTHelp objCASHelp = null;
                bool blFrmOpen = false;

                string strapplicationpath = System.Windows.Forms.Application.StartupPath.ToString();
                string FilePath = Path.Combine(strapplicationpath, "CASREACTInputManual.pdf");

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMCASREACTHELP")
                    {
                        objCASHelp = (frmCASREACTHelp)frm;

                        blFrmOpen = true;
                        objCASHelp.InputManualPath = FilePath;
                        objCASHelp.activeTab = 0;
                        objCASHelp.LoadFileInControl();
                        objCASHelp.Show();
                        objCASHelp.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objCASHelp = new frmCASREACTHelp();
                    objCASHelp.InputManualPath = FilePath;
                    objCASHelp.activeTab = 0;
                    objCASHelp.LoadFileInControl();
                    objCASHelp.MdiParent = this;
                    objCASHelp.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void codingHintsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmCASREACTHelp objCASHelp = null;
                bool blFrmOpen = false;

                string strapplicationpath = System.Windows.Forms.Application.StartupPath.ToString();
                string FilePath = Path.Combine(strapplicationpath, "ExternalCASREACTCODINGHINTSANDREMINDERS.pdf");

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMCASREACTHELP")
                    {
                        objCASHelp = (frmCASREACTHelp)frm;

                        blFrmOpen = true;
                        objCASHelp.CodingHintsPath = FilePath;
                        objCASHelp.activeTab = 1;
                        objCASHelp.LoadFileInControl();
                        objCASHelp.Show();
                        objCASHelp.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objCASHelp = new frmCASREACTHelp();
                    objCASHelp.CodingHintsPath = FilePath;
                    objCASHelp.activeTab = 1;
                    objCASHelp.LoadFileInControl();
                    objCASHelp.MdiParent = this;
                    objCASHelp.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void generalRemindersForConditionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmCASREACTHelp objCASHelp = null;
                bool blFrmOpen = false;

                string strapplicationpath = System.Windows.Forms.Application.StartupPath.ToString();
                string FilePath = Path.Combine(strapplicationpath, "GeneralremindersforConditions.pdf");

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMCASREACTHELP")
                    {
                        objCASHelp = (frmCASREACTHelp)frm;

                        blFrmOpen = true;
                        objCASHelp.ConditionsPath = FilePath;
                        objCASHelp.activeTab = 2;
                        objCASHelp.LoadFileInControl();
                        objCASHelp.Show();
                        objCASHelp.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objCASHelp = new frmCASREACTHelp();
                    objCASHelp.ConditionsPath = FilePath;
                    objCASHelp.activeTab = 2;
                    objCASHelp.LoadFileInControl();
                    objCASHelp.MdiParent = this;
                    objCASHelp.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void and8500sToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmCASREACTHelp objCASHelp = null;
                bool blFrmOpen = false;

                string strapplicationpath = System.Windows.Forms.Application.StartupPath.ToString();
                string FilePath = Path.Combine(strapplicationpath, "8000sand8500s.pdf");

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMCASREACTHELP")
                    {
                        objCASHelp = (frmCASREACTHelp)frm;

                        blFrmOpen = true;
                        objCASHelp.StructConvPath = FilePath;
                        objCASHelp.activeTab = 3;
                        objCASHelp.LoadFileInControl();
                        objCASHelp.Show();
                        objCASHelp.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objCASHelp = new frmCASREACTHelp();
                    objCASHelp.StructConvPath = FilePath;
                    objCASHelp.activeTab = 3;
                    objCASHelp.LoadFileInControl();
                    objCASHelp.MdiParent = this;
                    objCASHelp.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void protocToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmCASREACTHelp objCASHelp = null;
                bool blFrmOpen = false;

                string strapplicationpath = System.Windows.Forms.Application.StartupPath.ToString();
                string FilePath = Path.Combine(strapplicationpath, "Protocol_updates.pdf");

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMCASREACTHELP")
                    {
                        objCASHelp = (frmCASREACTHelp)frm;

                        blFrmOpen = true;
                        objCASHelp.ProtUpdatesPath = FilePath;
                        objCASHelp.activeTab = 4;
                        objCASHelp.LoadFileInControl();
                        objCASHelp.Show();
                        objCASHelp.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objCASHelp = new frmCASREACTHelp();
                    objCASHelp.ProtUpdatesPath = FilePath;
                    objCASHelp.activeTab = 4;
                    objCASHelp.LoadFileInControl();
                    objCASHelp.MdiParent = this;
                    objCASHelp.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rSNManualToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmCASREACTHelp objCASHelp = null;
                bool blFrmOpen = false;

                string strapplicationpath = System.Windows.Forms.Application.StartupPath.ToString();
                string FilePath = Path.Combine(strapplicationpath, "RSNManual.pdf");

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMCASREACTHELP")
                    {
                        objCASHelp = (frmCASREACTHelp)frm;

                        blFrmOpen = true;
                        objCASHelp.RSNPath = FilePath;
                        objCASHelp.activeTab = 5;
                        objCASHelp.LoadFileInControl();
                        objCASHelp.Show();
                        objCASHelp.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objCASHelp = new frmCASREACTHelp();
                    objCASHelp.RSNPath = FilePath;
                    objCASHelp.activeTab = 5;
                    objCASHelp.LoadFileInControl();
                    objCASHelp.MdiParent = this;
                    objCASHelp.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void finalCheckToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(finalCheckToolStripMenuItem.Text);

                FormCollection frmColl = Application.OpenForms;
                frmFinalChecks_Supervisor objFCheck = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMFINALCHECKS_SUPERVISOR")
                    {
                        objFCheck = (frmFinalChecks_Supervisor)frm;
                        blFrmOpen = true;
                        objFCheck.Show();
                        objFCheck.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objFCheck = new frmFinalChecks_Supervisor();
                    objFCheck.MdiParent = this;
                    objFCheck.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tANStatusReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                #region MyRegion
                //ApplicationOperationTracking.LogOperation(tANStatusReportToolStripMenuItem.Text);

                //FormCollection frmColl = Application.OpenForms;
                //Reports.frmTANStatusReport objfrmTStatus = null;
                //bool blFrmOpen = false;

                //foreach (Form frm in frmColl)
                //{
                //    if (frm.Name.ToUpper() == "FRMTANSTATUSREPORT")
                //    {
                //        objfrmTStatus = (Reports.frmTANStatusReport)frm;
                //        blFrmOpen = true;
                //        objfrmTStatus.Show();
                //        objfrmTStatus.WindowState = FormWindowState.Maximized;
                //    }
                //}
                //if (!blFrmOpen)
                //{
                //    objfrmTStatus = new Reports.frmTANStatusReport();
                //    objfrmTStatus.MdiParent = this;
                //    objfrmTStatus.Show();
                //} 
                #endregion

                ApplicationOperationTracking.LogOperation("Shipment Detailed Report - " + tANStatusReportToolStripMenuItem.Text);

                FormCollection frmColl = Application.OpenForms;
                frmShipmentDetailedReport objShReport = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMSHIPMENTDETAILEDREPORT")
                    {
                        objShReport = (frmShipmentDetailedReport)frm;

                        blFrmOpen = true;
                        objShReport.Show();
                        objShReport.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objShReport = new frmShipmentDetailedReport();
                    objShReport.MdiParent = this;
                    objShReport.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void errorLogReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(errorLogReportToolStripMenuItem.Text);
                
                //FormCollection frmColl = Application.OpenForms;
                //Reports.frmErrorLogReport objErrorLog = null;
                //bool blFrmOpen = false;

                //foreach (Form frm in frmColl)
                //{
                //    if (frm.Name.ToUpper() == "FRMERRORLOGREPORT")
                //    {
                //        objErrorLog = (Reports.frmErrorLogReport)frm;
                //        blFrmOpen = true;
                //        objErrorLog.Show();
                //        objErrorLog.WindowState = FormWindowState.Maximized;
                //    }
                //}
                //if (!blFrmOpen)
                //{
                //    objErrorLog = new Reports.frmErrorLogReport();
                //    objErrorLog.MdiParent = this;
                //    objErrorLog.Show();
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }  

        private void rSDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(rSDToolStripMenuItem.Text);

                FormCollection frmColl = Application.OpenForms;
                frmValidateRSD objfrmRSD = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMVALIDATERSD")
                    {
                        objfrmRSD = (frmValidateRSD)frm;
                        blFrmOpen = true;
                        objfrmRSD.Show();
                        objfrmRSD.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objfrmRSD = new frmValidateRSD();
                    objfrmRSD.MdiParent = this;
                    objfrmRSD.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       

        private void rSNFreeDictionaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(rSNFreeDictionaryToolStripMenuItem.Text);

                FormCollection frmColl = Application.OpenForms;
                frmAddFreeTextDict objfrmFText = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMADDFREETEXTDICT")
                    {
                        objfrmFText = (frmAddFreeTextDict)frm;
                        blFrmOpen = true;
                        objfrmFText.Show();
                        objfrmFText.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objfrmFText = new frmAddFreeTextDict();
                    objfrmFText.MdiParent = this;
                    objfrmFText.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void userTANErrorLogReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(userTANErrorLogReportToolStripMenuItem.Text);
                
                //FormCollection frmColl = Application.OpenForms;
                //frmUserTAN_ErrorLog objUsrTANELog = null;
                //bool blFrmOpen = false;

                //foreach (Form frm in frmColl)
                //{
                //    if (frm.Name.ToUpper() == "FRMUSERTAN_ERRORLOG")
                //    {
                //        objUsrTANELog = (frmUserTAN_ErrorLog)frm;
                //        blFrmOpen = true;
                //        objUsrTANELog.Show();
                //        objUsrTANELog.WindowState = FormWindowState.Maximized;
                //    }
                //}
                //if (!blFrmOpen)
                //{
                //    objUsrTANELog = new frmUserTAN_ErrorLog();
                //    objUsrTANELog.MdiParent = this;
                //    objUsrTANELog.Show();
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dailyStatusReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(dailyStatusReportToolStripMenuItem.Text);

                FormCollection frmColl = Application.OpenForms;
                frmDailyStatusReport objfrmDStatus = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMDAILYSTATUSREPORT")
                    {
                        objfrmDStatus = (frmDailyStatusReport)frm;
                        blFrmOpen = true;
                        objfrmDStatus.Show();
                        objfrmDStatus.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objfrmDStatus = new frmDailyStatusReport();
                    objfrmDStatus.MdiParent = this;
                    objfrmDStatus.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void solventBoilingPointToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(solventBoilingPointToolStripMenuItem.Text);

                frmSolvBoilPoints objfrmSolv = new frmSolvBoilPoints();
                objfrmSolv.ShowDialog();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void keywordSearchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    ApplicationOperationTracking.LogOperation(keywordSearchToolStripMenuItem.Text);

            //    FormCollection frmColl = Application.OpenForms;
            //    SearchPdfKeywords.frmSearchPdf objSrchPdf = null;
            //    bool blFrmOpen = false;

            //    foreach (Form frm in frmColl)
            //    {
            //        if (frm.Name.ToUpper() == "FRMSEARCHPDF")
            //        {
            //            objSrchPdf = (SearchPdfKeywords.frmSearchPdf)frm;
            //            blFrmOpen = true;
            //            objSrchPdf.Show();
            //            objSrchPdf.WindowState = FormWindowState.Maximized;
            //        }
            //    }
            //    if (!blFrmOpen)
            //    {
            //        objSrchPdf = new SearchPdfKeywords.frmSearchPdf();
            //        objSrchPdf.MdiParent = this;
            //        objSrchPdf.Show();
            //    }
            //}
            //catch (Exception ex)
            //{
            //    ErrorHandling.WriteErrorLog(ex.ToString());
            //}
        }

        private void series8500RegNosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(series8500RegNosToolStripMenuItem.Text);
                
                //FormCollection frmColl = Application.OpenForms;
                //frmSeries8500Entry ser8500Entry = null;
                //bool blFrmOpen = false;

                //foreach (Form frm in frmColl)
                //{
                //    if (frm.Name.ToUpper() == "FRMSERIES8500ENTRY")
                //    {
                //        ser8500Entry = (frmSeries8500Entry)frm;
                //        blFrmOpen = true;
                //        ser8500Entry.Show();
                //        ser8500Entry.WindowState = FormWindowState.Maximized;
                //    }
                //}
                //if (!blFrmOpen)
                //{
                //    ser8500Entry = new frmSeries8500Entry();
                //    ser8500Entry.MdiParent = this;
                //    ser8500Entry.Show();
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        

        private void monthlyReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(monthlyReportToolStripMenuItem.Text);

                FormCollection frmColl = Application.OpenForms;
                frmMonthlyReport frmMonthRep = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMMONTHLYREPORT")
                    {
                        frmMonthRep = (frmMonthlyReport)frm;
                        blFrmOpen = true;
                        frmMonthRep.Show();
                        frmMonthRep.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    frmMonthRep = new frmMonthlyReport();
                    frmMonthRep.MdiParent = this;
                    frmMonthRep.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void aminoAcidsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmAminoAcids objAminoAcids = null;
                bool blFrmOpen = false;

                string strAppPath = System.Windows.Forms.Application.StartupPath.ToString();
                string strFilePath = Path.Combine(strAppPath, "AminoAcids.pdf");
                if (File.Exists(strFilePath))
                {
                    foreach (Form frm in frmColl)
                    {
                        if (frm.Name.ToUpper() == "FRMAMINOACIDS")
                        {
                            objAminoAcids = (frmAminoAcids)frm;
                            blFrmOpen = true;
                            objAminoAcids.Show();
                            objAminoAcids.WindowState = FormWindowState.Maximized;
                        }
                    }
                    if (!blFrmOpen)
                    {
                        objAminoAcids = new frmAminoAcids();
                        objAminoAcids.FilePath_AminoAcids = strFilePath;
                        objAminoAcids.LoadFileInControl();
                        objAminoAcids.MdiParent = this;
                        objAminoAcids.Show();
                    }
                }
                else
                {
                    MessageBox.Show("AminoAcids.pdf file is not exist",GlobalVariables.MessageCaption,MessageBoxButtons.OK,MessageBoxIcon.Information);                  
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void clientFeedbackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(clientFeedbackToolStripMenuItem.Text);

                //FormCollection frmColl = Application.OpenForms;
                //frmClientFeedback objClientFeedback = null;
                //bool blFrmOpen = false;

                //foreach (Form frm in frmColl)
                //{
                //    if (frm.Name.ToUpper() == "FRMCLIENTFEEDBACK")
                //    {
                //        objClientFeedback = (frmClientFeedback)frm;
                //        blFrmOpen = true;
                //        objClientFeedback.Show();
                //        objClientFeedback.WindowState = FormWindowState.Maximized;
                //    }
                //}
                //if (!blFrmOpen)
                //{
                //    objClientFeedback = new frmClientFeedback();                 
                //    objClientFeedback.MdiParent = this;
                //    objClientFeedback.Show();
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void sendMailToUsersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(sendMailToUsersToolStripMenuItem.Text);

                FormCollection frmColl = Application.OpenForms;
                frmUpdatesMail objMail = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMUPDATESMAIL")
                    {
                        objMail = (frmUpdatesMail)frm;
                        blFrmOpen = true;
                        objMail.Show();
                        objMail.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objMail = new frmUpdatesMail();
                    objMail.MdiParent = this;
                    objMail.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void imageToPDFConvTSMnuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(imageToPDFConvTSMnuItem.Text);
                
                FormCollection frmColl = Application.OpenForms;
                //ImageToPdf_ITextSharp.frmImageToPdf objImgToPdf = null;
                //bool blFrmOpen = false;

                //foreach (Form frm in frmColl)
                //{
                //    if (frm.Name.ToUpper() == "FRMIMAGETOPDF")
                //    {
                //        objImgToPdf = (frmImageToPdf)frm;
                //        blFrmOpen = true;
                //        objImgToPdf.Show();
                //        objImgToPdf.WindowState = FormWindowState.Maximized;
                //    }
                //}
                //if (!blFrmOpen)
                //{
                //    objImgToPdf = new frmImageToPdf();
                //    objImgToPdf.MdiParent = this;
                //    objImgToPdf.Show();
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void batchTANStatusReportTSMnuItem_Click(object sender, EventArgs e)
        {
            try
            {
                //ApplicationOperationTracking.LogOperation(batchTANStatusReportTSMnuItem.Text);
                
                //FormCollection frmColl = Application.OpenForms;
                //frmUserTaskReport objUserTaskRep = null;
                //bool blFrmOpen = false;

                //foreach (Form frm in frmColl)
                //{
                //    if (frm.Name.ToUpper() == "FRMUSERTASKREPORT")
                //    {
                //        objUserTaskRep = (frmUserTaskReport)frm;
                //        blFrmOpen = true;
                //        objUserTaskRep.Show();
                //        objUserTaskRep.WindowState = FormWindowState.Maximized;
                //    }
                //}
                //if (!blFrmOpen)
                //{
                //    objUserTaskRep = new frmUserTaskReport();
                //    objUserTaskRep.MdiParent = this;
                //    objUserTaskRep.Show();
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void withoutStagesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
               // ApplicationOperationTracking.LogOperation("Shipment Report - " + withoutStagesToolStripMenuItem.Text);

                //FormCollection frmColl = Application.OpenForms;
                //frmShipmentReport_New objShReport = null;
                //bool blFrmOpen = false;

                //foreach (Form frm in frmColl)
                //{
                //    if (frm.Name.ToUpper() == "FRMSHIPMENTREPORT_NEW")
                //    {
                //        objShReport = (frmShipmentReport_New)frm;

                //        blFrmOpen = true;
                //        objShReport.Show();
                //        objShReport.WindowState = FormWindowState.Maximized;
                //    }
                //}
                //if (!blFrmOpen)
                //{
                //    objShReport = new frmShipmentReport_New();
                //    objShReport.MdiParent = this;
                //    objShReport.Show();
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        

        private void multipleBatchesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                //ApplicationOperationTracking.LogOperation("Shipment Report - " + multipleBatchesToolStripMenuItem.Text);
                
                FormCollection frmColl = Application.OpenForms;
                //frmBatchTANShipment objShReport = null;
                //bool blFrmOpen = false;

                //foreach (Form frm in frmColl)
                //{
                //    if (frm.Name.ToUpper() == "FRMBATCHTANSHIPMENT")
                //    {
                //        objShReport = (frmBatchTANShipment)frm;

                //        blFrmOpen = true;
                //        objShReport.Show();
                //        objShReport.WindowState = FormWindowState.Maximized;
                //    }
                //}
                //if (!blFrmOpen)
                //{
                //    objShReport = new frmBatchTANShipment();
                //    objShReport.MdiParent = this;
                //    objShReport.Show();
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void cGMTANSForPDfExportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(shipmentTanNUMsForPDfExportToolStripMenuItem.Text);

                //FormCollection frmColl = Application.OpenForms;
                //frmCgmTAN_Nums objCgmTANs = null;
                //bool blFrmOpen = false;

                //foreach (Form frm in frmColl)
                //{
                //    if (frm.Name.ToUpper() == "FRMCGMTAN_NUMS")
                //    {
                //        objCgmTANs = (frmCgmTAN_Nums)frm;

                //        blFrmOpen = true;
                //        objCgmTANs.Show();
                //        objCgmTANs.WindowState = FormWindowState.Maximized;
                //    }
                //}
                //if (!blFrmOpen)
                //{
                //    objCgmTANs = new frmCgmTAN_Nums();
                //    objCgmTANs.MdiParent = this;
                //    objCgmTANs.Show();
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void xmlDeliveryReportTSMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void userErrorsReportTSMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(userErrorsReportTSMenuItem.Text);

                //FormCollection frmColl = Application.OpenForms;
                //frmUserErrors objUserErrors = null;
                //bool blFrmOpen = false;

                //foreach (Form frm in frmColl)
                //{
                //    if (frm.Name.ToUpper() == "FRMUSERERRORS")
                //    {
                //        objUserErrors = (frmUserErrors)frm;

                //        blFrmOpen = true;
                //        objUserErrors.Show();
                //        objUserErrors.WindowState = FormWindowState.Maximized;
                //    }
                //}
                //if (!blFrmOpen)
                //{
                //    objUserErrors = new frmUserErrors();
                //    objUserErrors.MdiParent = this;
                //    objUserErrors.Show();
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        

        private void userProductivityReportTSMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(userProductivityReportTSMenuItem.Text);

                FormCollection frmColl = Application.OpenForms;
                frmProductivityReport objProdReport = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMPRODUCTIVITYREPORT")
                    {
                        objProdReport = (frmProductivityReport)frm;

                        blFrmOpen = true;
                        objProdReport.Show();
                        objProdReport.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objProdReport = new frmProductivityReport();
                    objProdReport.MdiParent = this;
                    objProdReport.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void IndexingTSMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(IndexingTSMenuItem.Text);

                frmIndexingReactTAN indexingTask = new frmIndexingReactTAN();
                if (indexingTask.ShowDialog() == DialogResult.OK)
                {
                    if (indexingTask.SelectedTool.ToUpper() == "REACT")
                    {
                        LoadTANInReactionCurationForm(indexingTask.TAN_ID, 0, 0);
                    }                    
                } 

                #region New code commented
                //frmStructureIndexing frmIndexing = null;

                //FormCollection frmColl = Application.OpenForms;
                //foreach (Form objfrm in frmColl)
                //{
                //    if (objfrm.Name.ToUpper() == "FRMSTRUCTUREINDEXING")
                //    {
                //        frmIndexing = (frmStructureIndexing)objfrm;
                //        frmIndexing.Close();
                //        break;
                //    }
                //}
                //frmIndexing = new frmStructureIndexing();                
                //frmIndexing.MdiParent = this;
                //frmIndexing.Show(); 
                #endregion
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void structuringConvensionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmCASREACTHelp objCASHelp = null;
                bool blFrmOpen = false;

                string strapplicationpath = System.Windows.Forms.Application.StartupPath.ToString();
                string FilePath = Path.Combine(strapplicationpath, "OrgIdx-StructuringConventions.pdf");

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMCASREACTHELP")
                    {
                        objCASHelp = (frmCASREACTHelp)frm;

                        blFrmOpen = true;
                        objCASHelp.StructConvPath = FilePath;
                        objCASHelp.activeTab = 3;
                        objCASHelp.LoadFileInControl();
                        objCASHelp.Show();
                        objCASHelp.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objCASHelp = new frmCASREACTHelp();
                    objCASHelp.StructConvPath = FilePath;
                    objCASHelp.activeTab = 3;
                    objCASHelp.LoadFileInControl();
                    objCASHelp.MdiParent = this;
                    objCASHelp.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void abstractingGuidelinesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmCASREACTHelp objCASHelp = null;
                bool blFrmOpen = false;

                string strapplicationpath = System.Windows.Forms.Application.StartupPath.ToString();
                string FilePath = Path.Combine(strapplicationpath, "OrgIdx-Abstract.pdf");

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMCASREACTHELP")
                    {
                        objCASHelp = (frmCASREACTHelp)frm;

                        blFrmOpen = true;
                        objCASHelp.AbstractsPath = FilePath;
                        objCASHelp.activeTab = 6;
                        objCASHelp.LoadFileInControl();
                        objCASHelp.Show();
                        objCASHelp.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objCASHelp = new frmCASREACTHelp();
                    objCASHelp.AbstractsPath = FilePath;
                    objCASHelp.activeTab = 6;
                    objCASHelp.LoadFileInControl();
                    objCASHelp.MdiParent = this;
                    objCASHelp.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void organicIndexingInputManualToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmCASREACTHelp objCASHelp = null;
                bool blFrmOpen = false;

                string strapplicationpath = System.Windows.Forms.Application.StartupPath.ToString();
                string FilePath = Path.Combine(strapplicationpath , "OrgIdx-DocumentAnalysisManual.pdf");

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMCASREACTHELP")
                    {
                        objCASHelp = (frmCASREACTHelp)frm;

                        blFrmOpen = true;
                        objCASHelp.IndxManualPath = FilePath;
                        objCASHelp.activeTab = 7;
                        objCASHelp.LoadFileInControl();
                        objCASHelp.Show();
                        objCASHelp.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objCASHelp = new frmCASREACTHelp();
                    objCASHelp.IndxManualPath = FilePath;
                    objCASHelp.activeTab = 7;
                    objCASHelp.LoadFileInControl();
                    objCASHelp.MdiParent = this;
                    objCASHelp.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void roleIndicatorsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmCASREACTHelp objCASHelp = null;
                bool blFrmOpen = false;

                string strapplicationpath = System.Windows.Forms.Application.StartupPath.ToString();
                string FilePath = Path.Combine(strapplicationpath, "OrgIdx-RoleIndicators.pdf");

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMCASREACTHELP")
                    {
                        objCASHelp = (frmCASREACTHelp)frm;

                        blFrmOpen = true;
                        objCASHelp.RoleIndPath = FilePath;
                        objCASHelp.activeTab = 8;
                        objCASHelp.LoadFileInControl();
                        objCASHelp.Show();
                        objCASHelp.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objCASHelp = new frmCASREACTHelp();
                    objCASHelp.RoleIndPath = FilePath;
                    objCASHelp.activeTab = 8;
                    objCASHelp.LoadFileInControl();
                    objCASHelp.MdiParent = this;
                    objCASHelp.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void titleGuideLinesTSMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmCASREACTHelp objCASHelp = null;
                bool blFrmOpen = false;

                string strapplicationpath = System.Windows.Forms.Application.StartupPath.ToString();
                string FilePath = Path.Combine(strapplicationpath, "OrgIdx-Title.pdf");

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMCASREACTHELP")
                    {
                        objCASHelp = (frmCASREACTHelp)frm;

                        blFrmOpen = true;
                        objCASHelp.TitlePath = FilePath;
                        objCASHelp.activeTab = 9;
                        objCASHelp.LoadFileInControl();
                        objCASHelp.Show();
                        objCASHelp.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objCASHelp = new frmCASREACTHelp();
                    objCASHelp.TitlePath = FilePath;
                    objCASHelp.activeTab = 9;
                    objCASHelp.LoadFileInControl();
                    objCASHelp.MdiParent = this;
                    objCASHelp.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void stereochemGuidelinesTSMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmCASREACTHelp objCASHelp = null;
                bool blFrmOpen = false;

                string strapplicationpath = System.Windows.Forms.Application.StartupPath.ToString();
                string FilePath = Path.Combine(strapplicationpath, "OrgIdx-StereoChemistry.pdf");

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMCASREACTHELP")
                    {
                        objCASHelp = (frmCASREACTHelp)frm;

                        blFrmOpen = true;
                        objCASHelp.StereoChemPath = FilePath;
                        objCASHelp.activeTab = 10;
                        objCASHelp.LoadFileInControl();
                        objCASHelp.Show();
                        objCASHelp.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objCASHelp = new frmCASREACTHelp();
                    objCASHelp.StereoChemPath = FilePath;
                    objCASHelp.activeTab = 10;
                    objCASHelp.LoadFileInControl();
                    objCASHelp.MdiParent = this;
                    objCASHelp.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void teamStructureTSMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmApplicationUsers objAppUsers = null;
                bool blFrmOpen = false;
              
                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMAPPLICATIONUSERS")
                    {
                        objAppUsers = (frmApplicationUsers)frm;

                        blFrmOpen = true;                        
                        objAppUsers.Show();
                        objAppUsers.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objAppUsers = new frmApplicationUsers();                   
                    objAppUsers.MdiParent = this;
                    objAppUsers.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void unicodesTSMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmXmlUnicodesValidation objUniCodes = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMXMLUNICODESVALIDATION")
                    {
                        objUniCodes = (frmXmlUnicodesValidation)frm;

                        blFrmOpen = true;
                        objUniCodes.Show();
                        objUniCodes.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objUniCodes = new frmXmlUnicodesValidation();
                    objUniCodes.MdiParent = this;
                    objUniCodes.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void series9000TSMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(orgRefToolStripMenuItem.Text);

                FormCollection frmColl = Application.OpenForms;
                frmOrgRefData objOrgRef = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMORGREFDATA")
                    {
                        objOrgRef = (frmOrgRefData)frm;
                        blFrmOpen = true;
                        objOrgRef.Show();
                        objOrgRef.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objOrgRef = new frmOrgRefData();
                    objOrgRef.SourceForm = "9000";
                    objOrgRef.MdiParent = this;
                    objOrgRef.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void series8500TSMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(orgRefToolStripMenuItem.Text);

                FormCollection frmColl = Application.OpenForms;
                frmOrgRefData objOrgRef = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMORGREFDATA")
                    {
                        objOrgRef = (frmOrgRefData)frm;
                        blFrmOpen = true;
                        objOrgRef.Show();
                        objOrgRef.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objOrgRef = new frmOrgRefData();
                    objOrgRef.SourceForm = "8500";
                    objOrgRef.MdiParent = this;
                    objOrgRef.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void formToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Properties.Settings.Default.ReactionView = "FORM";
                Properties.Settings.Default.Save();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void panelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Properties.Settings.Default.ReactionView = "PANEL";
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void narShipmentStatusReportTSMenuItem1_Click(object sender, EventArgs e)
        {
            try
            {
                if (GlobalVariables.ApplicationName == Enums.ApplicationName.NARRATIVES.ToString() ||
                    GlobalVariables.ApplicationName == Enums.ApplicationName.EXPPROCEDURES.ToString())
                {
                    ApplicationOperationTracking.LogOperation(orgRefToolStripMenuItem.Text);

                    FormCollection frmColl = Application.OpenForms;
                    frmShipmentsOverAllStatusReport narShipStatus = null;
                    bool blFrmOpen = false;

                    foreach (Form frm in frmColl)
                    {
                        if (frm.Name.ToUpper() == "FRMSHIPMENTSOVERALLSTATUSREPORT")
                        {
                            narShipStatus = (frmShipmentsOverAllStatusReport)frm;
                            blFrmOpen = true;
                            narShipStatus.Show();
                            narShipStatus.WindowState = FormWindowState.Maximized;
                        }
                    }
                    if (!blFrmOpen)
                    {
                        narShipStatus = new frmShipmentsOverAllStatusReport();
                        narShipStatus.MdiParent = this;
                        narShipStatus.Show();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void narrTANViewToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void taskModificationTSMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(orgRefToolStripMenuItem.Text);

                FormCollection frmColl = Application.OpenForms;
                frmModifyTask frmModifyTsk = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMMODIFYTASK")
                    {
                        frmModifyTsk = (frmModifyTask)frm;
                        blFrmOpen = true;
                        frmModifyTsk.Show();
                        frmModifyTsk.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    frmModifyTsk = new frmModifyTask();                   
                    frmModifyTsk.MdiParent = this;
                    frmModifyTsk.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void cTHReferenceTSMenuItem_Click(object sender, EventArgs e)
        {
            try
            {                
                ApplicationOperationTracking.LogOperation(cTHReferenceTSMenuItem.Text);

                FormCollection frmColl = Application.OpenForms;
                frmCTHReference frmCTH = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMCTHREFERENCE")
                    {
                        frmCTH = (frmCTHReference)frm;
                        blFrmOpen = true;
                        frmCTH.Show();
                        frmCTH.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    frmCTH = new frmCTHReference();
                    frmCTH.MdiParent = this;
                    frmCTH.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void updateTANBatchNoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //TODO: need to add Batch No update
        }

        private void validateNarrativesXMLTSMnuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmCheckUniCodes frmUniCodes = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMCHECKUNICODES")
                    {
                        frmUniCodes = (frmCheckUniCodes)frm;

                        blFrmOpen = true;
                        frmUniCodes.Show();
                        frmUniCodes.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    frmUniCodes = new frmCheckUniCodes();
                    frmUniCodes.MdiParent = this;
                    frmUniCodes.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }        
        }

        private void narrExpProcXmlTSMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmValidateExpProceXmls frmNarExpXmlVald = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMVALIDATEEXPPROCEXMLS")
                    {
                        frmNarExpXmlVald = (frmValidateExpProceXmls)frm;

                        blFrmOpen = true;
                        frmNarExpXmlVald.Show();
                        frmNarExpXmlVald.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    frmNarExpXmlVald = new frmValidateExpProceXmls();
                    frmNarExpXmlVald.MdiParent = this;
                    frmNarExpXmlVald.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }  
        }

        private void cTHUpdateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmCTHReference_Update frmCthUpdate = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMCTHREFERENCE_UPDATE")
                    {
                        frmCthUpdate = (frmCTHReference_Update)frm;

                        blFrmOpen = true;
                        frmCthUpdate.Show();
                        frmCthUpdate.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    frmCthUpdate = new frmCTHReference_Update();
                    frmCthUpdate.MdiParent = this;
                    frmCthUpdate.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            } 
        }

        private void expProcFinalChecksTSMnuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmNarrExpProcXmlsFinalChecks frmExpChecks = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMNARREXPPROCXMLSFINALCHECKS")
                    {
                        frmExpChecks = (frmNarrExpProcXmlsFinalChecks)frm;

                        blFrmOpen = true;
                        frmExpChecks.Show();
                        frmExpChecks.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    frmExpChecks = new frmNarrExpProcXmlsFinalChecks();
                    frmExpChecks.MdiParent = this;
                    frmExpChecks.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            } 
        }

        private void exporttoXMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            } 
        }

        private void orgRefToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(orgRefToolStripMenuItem.Text);

                FormCollection frmColl = Application.OpenForms;
                frmOrgRefData objOrgRef = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMORGREFDATA")
                    {
                        objOrgRef = (frmOrgRefData)frm;
                        blFrmOpen = true;
                        objOrgRef.Show();
                        objOrgRef.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objOrgRef = new frmOrgRefData();
                    //objOrgRef.SourceForm = "9000";
                    objOrgRef.MdiParent = this;
                    objOrgRef.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void expProcTANRxnFindingsTSMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(expProcTANRxnFindingsTSMenuItem.Text);

                FormCollection frmColl = Application.OpenForms;
                frmReviewTanRxnFindings frmRevTANFindings = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMREVIEWTANRXNFINDINGS")
                    {
                        frmRevTANFindings = (frmReviewTanRxnFindings)frm;
                        blFrmOpen = true;
                        frmRevTANFindings.Show();
                        frmRevTANFindings.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    frmRevTANFindings = new frmReviewTanRxnFindings();
                    frmRevTANFindings.MdiParent = this;
                    frmRevTANFindings.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void shipmentTANsFindAndReplaceTSripMnuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(expProcTANRxnFindingsTSMenuItem.Text);

                FormCollection frmColl = Application.OpenForms;
                frmFindAndReplace_ShipmentLevel frmTANFindReplace = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMFINDANDREPLACE_SHIPMENTLEVEL")
                    {
                        frmTANFindReplace = (frmFindAndReplace_ShipmentLevel)frm;
                        blFrmOpen = true;
                        frmTANFindReplace.Show();
                        frmTANFindReplace.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    frmTANFindReplace = new frmFindAndReplace_ShipmentLevel();
                    frmTANFindReplace.MdiParent = this;
                    frmTANFindReplace.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void shipmentTANsPageInfoTSMnuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(expProcTANRxnFindingsTSMenuItem.Text);

                FormCollection frmColl = Application.OpenForms;
                frmReviewShipmentTansPageLabel frmTANPageInfo = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMREVIEWSHIPMENTTANSPAGELABEL")
                    {
                        frmTANPageInfo = (frmReviewShipmentTansPageLabel)frm;
                        blFrmOpen = true;
                        frmTANPageInfo.Show();
                        frmTANPageInfo.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    frmTANPageInfo = new frmReviewShipmentTansPageLabel();
                    frmTANPageInfo.MdiParent = this;
                    frmTANPageInfo.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void deliveryReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(deliveryReportToolStripMenuItem.Text);

                FormCollection frmColl = Application.OpenForms;
                frmDeliveryReport objDeliveryReport = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMDELIVERYREPORT")
                    {
                        objDeliveryReport = (frmDeliveryReport)frm;

                        blFrmOpen = true;
                        objDeliveryReport.Show();
                        objDeliveryReport.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objDeliveryReport = new frmDeliveryReport();
                    objDeliveryReport.MdiParent = this;
                    objDeliveryReport.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void generateMarkupFoldersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(deliveryReportToolStripMenuItem.Text);

                FormCollection frmColl = Application.OpenForms;
                frmCreateMarkupFolder objCreateMarkupFolder = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMCREATEMARKUPFOLDER")
                    {
                        objCreateMarkupFolder = (frmCreateMarkupFolder)frm;

                        blFrmOpen = true;
                        objCreateMarkupFolder.Show();
                        objCreateMarkupFolder.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    objCreateMarkupFolder = new frmCreateMarkupFolder();
                    objCreateMarkupFolder.MdiParent = this;
                    objCreateMarkupFolder.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void multiShipmentsStatusReportTSMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ApplicationOperationTracking.LogOperation(orgRefToolStripMenuItem.Text);

                FormCollection frmColl = Application.OpenForms;
                frmMultipleShipmentsDetailedReport frmMultiShipments = null;
                bool blFrmOpen = false;

                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMMULTIPLESHIPMENTSDETAILEDREPORT")
                    {
                        frmMultiShipments = (frmMultipleShipmentsDetailedReport)frm;
                        blFrmOpen = true;
                        frmMultiShipments.Show();
                        frmMultiShipments.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    frmMultiShipments = new frmMultipleShipmentsDetailedReport();
                    frmMultiShipments.MdiParent = this;
                    frmMultiShipments.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void narrativesReactionProtocolsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmImportExpProcedures2Shipment frmExpProcPilotImport = null;

                bool blFrmOpen = false;
                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMIMPORTEXPPROCEDURES2SHIPMENT")
                    {
                        frmExpProcPilotImport = (frmImportExpProcedures2Shipment)frm;

                        blFrmOpen = true;
                        frmExpProcPilotImport.Show();
                        frmExpProcPilotImport.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    frmExpProcPilotImport = new frmImportExpProcedures2Shipment();
                    frmExpProcPilotImport.MdiParent = this;
                    frmExpProcPilotImport.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void extractProcedureCountFromXmlTSMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                FormCollection frmColl = Application.OpenForms;
                frmExtractProcedureCountFromXml frmExpProcCounts = null;

                bool blFrmOpen = false;
                foreach (Form frm in frmColl)
                {
                    if (frm.Name.ToUpper() == "FRMEXTRACTPROCEDURECOUNTFROMXML")
                    {
                        frmExpProcCounts = (frmExtractProcedureCountFromXml)frm;

                        blFrmOpen = true;
                        frmExpProcCounts.Show();
                        frmExpProcCounts.WindowState = FormWindowState.Maximized;
                    }
                }
                if (!blFrmOpen)
                {
                    frmExpProcCounts = new frmExtractProcedureCountFromXml();
                    frmExpProcCounts.MdiParent = this;
                    frmExpProcCounts.Show();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }                        
    }
}
