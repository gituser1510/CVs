﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using IndxReactNarr.Generic;

namespace IndxReactNarr.Common
{
    public static class GenerateRSD
    {
        private static string GetParticipant_RSD(DataTable _partpnttbl, string _partpnttype, int _reactionid,string _stageid)
        {
            try
            {
                string strPartpnt = "";
                if (_partpnttbl != null)
                {
                    if (_partpnttbl.Rows.Count > 0)
                    {
                       DataView dtView = new DataView(_partpnttbl);
                       dtView.RowFilter = "RXN_ID = " + _reactionid + "";
                       dtView.Sort = "DISPLAY_ORDER asc";
                       DataTable dtRes_Partpnt = dtView.ToTable();

                       if (dtRes_Partpnt != null)
                       {
                           if (dtRes_Partpnt.Rows.Count > 0)
                           {
                               int intP_NUM = 0;                       

                               for (int i = 0; i < dtRes_Partpnt.Rows.Count; i++)
                               {
                                   int.TryParse(dtRes_Partpnt.Rows[i]["SERIES_NUM"].ToString().Trim(), out intP_NUM);
                                  
                                   if (intP_NUM > 0)
                                   {
                                       if (dtRes_Partpnt.Rows[i]["RXN_STAGE_ID"].ToString() == _stageid)
                                       {
                                           if (strPartpnt == "")
                                           {
                                               strPartpnt = _partpnttype + "=" + intP_NUM.ToString();
                                           }
                                           else
                                           {

                                               strPartpnt = strPartpnt + "," + intP_NUM.ToString();
                                           }                                           
                                       }
                                   }                                  
                               }
                           }
                       }
                    }
                }
                return strPartpnt;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return "";
        }

        private static string GetProduct_Yield_RSD(DataTable _producttbl,int _reactionid)
        {
            try
            {
                string strProduct = "";
                if (_producttbl != null)
                {
                    if (_producttbl.Rows.Count > 0)
                    {
                       int intP_NUM = 0;                       
                       int intYield = 0;

                       DataView dtView = new DataView(_producttbl);
                       dtView.RowFilter = "RXN_ID = " + _reactionid + "";

                       DataTable dtRes_Prod = dtView.ToTable();

                       if (dtRes_Prod != null)
                       {
                           if (dtRes_Prod.Rows.Count > 0)
                           {
                               for (int i = 0; i < dtRes_Prod.Rows.Count; i++)
                               {
                                   int.TryParse(dtRes_Prod.Rows[i]["SERIES_NUM"].ToString().Trim(), out intP_NUM);                                  
                                   
                                   if (intP_NUM > 0)
                                   {
                                       if (strProduct == "")
                                       {
                                           strProduct = "P=" + intP_NUM.ToString();
                                       }
                                       else
                                       {
                                           strProduct = strProduct + "," + intP_NUM.ToString();
                                       }
                                   }
                                   
                                   if (int.TryParse(dtRes_Prod.Rows[i]["YIELD"].ToString().Trim(), out intYield))
                                   {
                                       if (intYield > 0)
                                       {
                                           strProduct = strProduct + "(" + intYield.ToString() + ")";
                                       }
                                   }
                                   else if(dtRes_Prod.Rows[i]["YIELD"].ToString().Trim() != "")
                                   {
                                       strProduct = strProduct + "(" + dtRes_Prod.Rows[i]["YIELD"].ToString().Trim() + ")";
                                   }
                               }
                           }
                       }
                    }
                }
                return strProduct;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return "";
        }

        public static string GetRSDString(int _reactionid,DataTable _prodtbl,DataTable _reactanttbl,DataTable _agenttbl,DataTable _solventtbl,DataTable _catalysttbl,DataTable _rsntbl,DataTable _stagestbl)
        {
            string strRSN = "";
            try
            {
                if (_reactionid > 0)
                {
                    //Product - Yield RSD
                    string strProd = "";
                    if (_prodtbl != null)
                    {
                        if (_prodtbl.Rows.Count > 0)
                        {
                            strProd = GetProduct_Yield_RSD(_prodtbl, _reactionid);
                        }
                    }

                    //Get Stage IDs from Participants tables
                    ArrayList alstStageIDs = new ArrayList();

                    //New code on 21Apr 2011 for getting stage ids on display order
                    alstStageIDs = GetStageIDsOnRxnID(_stagestbl, _reactionid);

                    #region Code commented on 21Apr 2011. Stage ids sort on created date
                    //GetStageIDsFromTable(ref alstStageIDs, _reactanttbl, _reactionid);
                    //GetStageIDsFromTable(ref alstStageIDs, _agenttbl, _reactionid);
                    //GetStageIDsFromTable(ref alstStageIDs, _solventtbl, _reactionid);
                    //GetStageIDsFromTable(ref alstStageIDs, _catalysttbl, _reactionid);
                    ////New code on 16th Dec 2010 for Jones Reagent
                    //GetStageIDsFromTable(ref alstStageIDs, _rsntbl, _reactionid); 
                    #endregion

                    //Loop all the stages and separate stage RSD with ";"
                    if (alstStageIDs != null)
                    {
                        if (alstStageIDs.Count > 0)
                        {
                            #region Code commented on 21st Apr 2011
                            //Sort the stage ids in ascending order. RSD order should match with reaction stage order                           
                            //var sortedList = alstStageIDs.Cast<string>().OrderBy(item => int.Parse(item));
                            //ArrayList alstSorted = new ArrayList();
                            //for (int k = 0; k < sortedList.Count();k++ )
                            //{
                            //    alstSorted.Add(sortedList.ElementAt(k));
                            //} 
                            #endregion
                            
                            string strReactant = "";
                            string strAgent = "";
                            string strSolvent = "";
                            string strCatalyst = "";

                            string strStageRSN = "";

                            for (int i = 0; i < alstStageIDs.Count; i++)
                            {
                                strStageRSN = "";
                                
                                if (i == 0)
                                {
                                    strStageRSN = strProd;
                                }
                                
                                //Reactant RSD 
                                strReactant = "";
                                if (_reactanttbl != null)
                                {
                                    if (_reactanttbl.Rows.Count > 0)
                                    {
                                        strReactant = GetParticipant_RSD(_reactanttbl, "R", _reactionid, alstStageIDs[i].ToString());
                                        if (strReactant != "")
                                        {
                                            strStageRSN = strStageRSN + strReactant;
                                        }
                                    }
                                }

                                //Agent RSD   
                                strAgent = "";
                                if (_agenttbl != null)
                                {
                                    if (_agenttbl.Rows.Count > 0)
                                    {
                                        strAgent = GetParticipant_RSD(_agenttbl, "A", _reactionid, alstStageIDs[i].ToString());
                                        if (strAgent != "")
                                        {
                                            strStageRSN = strStageRSN + strAgent;
                                        }
                                    }
                                }

                                //Solvent RSD 
                                strSolvent = "";
                                if (_solventtbl != null)
                                {
                                    if (_solventtbl.Rows.Count > 0)
                                    {
                                        strSolvent = GetParticipant_RSD(_solventtbl, "S", _reactionid, alstStageIDs[i].ToString());
                                        if (strSolvent != "")
                                        {
                                            strStageRSN = strStageRSN + strSolvent;
                                        }
                                    }
                                }

                                //Catalyst RSD  
                                strCatalyst = "";
                                if (_catalysttbl != null)
                                {
                                    if (_catalysttbl.Rows.Count > 0)
                                    {
                                        strCatalyst = GetParticipant_RSD(_catalysttbl, "C", _reactionid, alstStageIDs[i].ToString());
                                        if (strCatalyst != "")
                                        {
                                            strStageRSN = strStageRSN + strCatalyst;
                                        }
                                    }
                                }
                                if (strRSN == "")
                                {
                                    strRSN = strStageRSN;
                                }
                                else
                                {
                                    strRSN = strRSN + ";" + strStageRSN;
                                }
                            }                            
                        }
                    }
                    return strRSN;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strRSN;
        }      

        private static ArrayList GetStageIDsOnRxnID(DataTable _stagestbl, int _reactionid)
        {
            ArrayList stageids = null;
            try
            {
                if (_stagestbl != null)
                {
                    if (_stagestbl.Rows.Count > 0)
                    {
                        DataView dtViewPar = new DataView(_stagestbl);
                        dtViewPar.RowFilter = "RXN_ID = " + _reactionid + "";
                        DataTable dtRes_Partpnt = dtViewPar.ToTable();

                        if (dtRes_Partpnt != null)
                        {
                            if (dtRes_Partpnt.Rows.Count > 0)
                            {
                                DataView dtView = new DataView(dtRes_Partpnt);                              
                                DataTable dtStageIDs = dtView.ToTable(true, "RXN_STAGE_ID");
                                if (dtStageIDs != null)
                                {
                                    if (dtStageIDs.Rows.Count > 0)
                                    {
                                        stageids = new ArrayList();

                                        for (int i = 0; i < dtStageIDs.Rows.Count; i++)
                                        {
                                            if (!stageids.Contains(dtStageIDs.Rows[i][0].ToString()))
                                            {
                                                stageids.Add(dtStageIDs.Rows[i][0].ToString());
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return stageids;
        }
    }
}
