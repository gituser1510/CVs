﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace IndxReactNarr.Common
{
    public static class Get_Name_NrnReg_Saved8500
    {
        public static int Get_Name_NrnReg(string _tan,string _prodname, out int _nrnreg)
        {
            int int8500 = 0;
            try
            {
                if (_prodname.Trim() != "")
                {
                    if (Generic.GlobalVariables.Ser8500OrgrefData != null)
                    {
                        if (Generic.GlobalVariables.Ser8500OrgrefData.Rows.Count > 0)
                        {
                            DataRow[] dtRowArr = Generic.GlobalVariables.Ser8500OrgrefData.Select("ORGREF_NAME = '" + ReplaceSpecialCharsinString(_prodname) + "' and tan = '" + _tan + "'");
                            if (dtRowArr != null)
                            {
                                if (dtRowArr.Length > 0)
                                {
                                    int.TryParse(dtRowArr[0]["SERIES_8500"].ToString(), out int8500);
                                    int.TryParse(dtRowArr[0]["REG_NO"].ToString(), out _nrnreg);
                                    return int8500;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _nrnreg = 0;
            return int8500;
        }

        private static string ReplaceSpecialCharsinString(string value)
        {
            StringBuilder sb = new StringBuilder(value.Length);
            for (int i = 0; i < value.Length; i++)
            {
                char c = value[i];
                switch (c)
                {
                    case ']':
                    case '[':
                    case '%':
                    case '*':
                        sb.Append("[").Append(c).Append("]");
                        break;
                    case '\'':
                        sb.Append("''");
                        break;
                    default:
                        sb.Append(c);
                        break;
                }
            }
            return sb.ToString();
        }
    }
}
