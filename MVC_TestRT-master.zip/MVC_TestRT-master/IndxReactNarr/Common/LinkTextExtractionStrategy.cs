﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;

namespace IndxReactNarr.Common
{
    public class LinkTextExtractionStrategy : ITextExtractionStrategy
    {
        private PdfRectangle mBoundingBox;
        private string mCurrentWord;

        private void Reset()
        {
            mCurrentWord = string.Empty;
            mBoundingBox = new PdfRectangle(0, 0, 0, 0);
        }
        public LinkTextExtractionStrategy()
        {
            Reset();
        }
        public LinkTextExtractionStrategy(PdfRectangle boundingBox)
            : this()
        {
            mBoundingBox = boundingBox;
        }
        public PdfRectangle BoundingBox
        {
            get
            {
                if (mBoundingBox == null)
                {
                    return new PdfRectangle(0, 0, 0, 0);
                }
                else
                {
                    return mBoundingBox;
                }
            }
            set
            {
                mBoundingBox = value;
            }
        }
        public void BeginTextBlock()
        {
            //do nothing
        }
        public void EndTextBlock()
        {
            //do nothing
        }
        public void RenderImage(ImageRenderInfo info)
        {
            //do nothing
        }
        public void RenderText(TextRenderInfo info)
        {
            Vector bottomLeft;
            Vector upperRight;

            // get the location of the text.
            bottomLeft = info.GetDescentLine().GetStartPoint();
            upperRight = info.GetAscentLine().GetEndPoint();

            //see if the current text is within the bounding box specified for this ExtractionStrategy
            if (bottomLeft[Vector.I1] > BoundingBox.Left &&
               bottomLeft[Vector.I2] > BoundingBox.Bottom &&
               upperRight[Vector.I1] < BoundingBox.Right &
               upperRight[Vector.I2] < BoundingBox.Top)
            {
                mCurrentWord += info.GetText();
            }
        }




        public string GetResultantText()
        {
            return mCurrentWord.Trim();
        }
    }
}
