﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarr.Common
{
    class Error_Track
    {
        public int ID { get; set; }
        public string TAN { get; set; }
        public int Stage_ID { get; set; }
        public string Participant { get; set; }
        public string Column_Name { get; set; }
        public int Old_Value { get; set; }
        public int New_Value { get; set; }
    }
}
