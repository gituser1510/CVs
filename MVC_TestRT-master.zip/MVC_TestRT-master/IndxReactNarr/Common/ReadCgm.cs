﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Xml.Linq;
using System.IO;
using System.Xml;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Collections;
using IndxReactNarr.Generic;
using System.Drawing;
using CADViewLib;


namespace IndxReactNarr
{
    public static class ReadCgm
    {
        public static DataTable XmlConvsTbl = null;

        public static DataTable GetCgmFileData(string _filename)
        {
            DataTable dtTAN_CAN = null;
            try
            {
                if (_filename.Trim() != "")
                {                   
                    string strFileName = Path.GetFileNameWithoutExtension(_filename);                    

                    string[] strSplitter = {"-"};
                    string[] strArr = strFileName.Split(strSplitter, StringSplitOptions.RemoveEmptyEntries);

                    string strBarchName = "";
                    if (strArr != null && strArr.Length > 0)
                    {
                        strBarchName = strArr[0];
                    }

                    DataTable dtXmlCons = IndxReactNarrDAL.ReactDB.GetXMLConvDetails(); 

                    if (dtXmlCons != null)
                    {
                        XmlConvsTbl = dtXmlCons;
                    }

                    string[] strArrFLines = File.ReadAllLines(_filename);

                    string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";

                    if (strArrFLines != null && strArrFLines.Length > 0)
                    {
                        DataTable dtCGM = new DataTable();
                        dtCGM.Columns.Add("Article", typeof(string));

                        for (int i = 0; i < strArrFLines.Length; i++)
                        {
                            if (strArrFLines[i].StartsWith("<ARTICLE TYPE="))
                            {
                                DataRow dRow = dtCGM.NewRow();
                                dRow[0] = strArrFLines[i];
                                dtCGM.Rows.Add(dRow);
                            }
                        }

                        if (dtCGM != null && dtCGM.Rows.Count > 0)
                        {
                            StreamWriter sw = null;
                            XElement xEle = null;
                            string strTAN = "";
                            string strCAN = "";
                            string strDOCTYPE = "";
                            string strJTitle = "";
                            string strJIssue = "";
                            string strJYear = "";

                            dtTAN_CAN = new DataTable();
                            dtTAN_CAN.Columns.Add("Batch", typeof(string));
                            dtTAN_CAN.Columns.Add("TAN", typeof(string));
                            dtTAN_CAN.Columns.Add("CAN", typeof(string));
                            dtTAN_CAN.Columns.Add("NRNNUM", typeof(string));
                            dtTAN_CAN.Columns.Add("NRNREG", typeof(string));
                            dtTAN_CAN.Columns.Add("DOCTYPE", typeof(string));
                            dtTAN_CAN.Columns.Add("JOURNAL_TITLE", typeof(string));
                            dtTAN_CAN.Columns.Add("JOURNAL_ISSUE", typeof(string));
                            dtTAN_CAN.Columns.Add("JOURNAL_YEAR", typeof(string));

                            string strXFile = "";
                            string strConvXml = "";

                            DataRow dRow = null;

                            for (int i = 0; i < dtCGM.Rows.Count; i++)
                            {
                                strXFile = AppDomain.CurrentDomain.BaseDirectory + "CGM_Temp.xml";
                                if (File.Exists(strXFile))
                                {
                                    File.Delete(strXFile);
                                }

                                using (sw = new StreamWriter(strXFile))
                                {
                                    strConvXml = GetConvertedXmlString(dtCGM.Rows[i][0].ToString().Trim());

                                    sw.Write(strXml + "\r\n" + strConvXml);
                                    sw.Close();
                                    sw.Dispose();

                                    // //making use of a transitional dtd
                                    //var doc = new XmlDocument();
                                    //doc.LoadXml(strXml + "\r\n" + strConvXml);

                                    xEle = XElement.Load(strXFile);

                                    var query = from XElement r in xEle.Descendants("RN")
                                                select r.Attribute("RID").Value;

                                    strCAN = "";
                                    strTAN = "";
                                    strDOCTYPE = "";
                                    strJTitle = "";
                                    strJIssue = "";
                                    strJYear = "";

                                    strCAN = xEle.Element("AN").Value;
                                    strTAN = xEle.Element("TAN").Value;
                                    strDOCTYPE = GetDocTypeFromString(xEle.Element("DT").Value);

                                    try
                                    {
                                        //If TAN is Journal 
                                        strJTitle = xEle.Element("JBIB").Elements("JT").ElementAt(0).Value;

                                        //Get Issue and Year from TAN
                                        strJIssue = GetJournalIssue_Year(xEle, out strJYear);
                                    }
                                    catch
                                    {
                                        try
                                        {
                                            //If TAN is Patent
                                            strJTitle = GetPatentNumber_Year(xEle, out strJYear);
                                        }
                                        catch
                                        {
                                            strJTitle = "";
                                        }
                                    }

                                    var query2 = from XElement r2 in xEle.Elements("CSIE")
                                                 select r2;
                                    foreach (XElement _xe in query2)
                                    {
                                        dRow = dtTAN_CAN.NewRow();
                                        dRow["Batch"] = strBarchName;
                                        dRow["TAN"] = strTAN;
                                        dRow["CAN"] = strCAN;
                                        try
                                        {
                                            dRow["NRNNUM"] = _xe.Element("NUM").Value;
                                        }
                                        catch
                                        {
                                            dRow["NRNNUM"] = 0;
                                        }
                                        dRow["NRNREG"] = _xe.Element("RN").Attribute("RID").Value;
                                        dRow["DOCTYPE"] = strDOCTYPE;
                                        dRow["JOURNAL_TITLE"] = strJTitle;
                                        dRow["JOURNAL_ISSUE"] = strJIssue;
                                        dRow["JOURNAL_YEAR"] = strJYear;

                                        dtTAN_CAN.Rows.Add(dRow);
                                    }
                                }
                            }                           
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            return dtTAN_CAN;
        }

        private static string GetJournalIssue_Year(XElement _xele,out string _jyear)
        {
            string strJIssue = "";
            string strJYear = "";
            try
            {
                if (_xele != null)
                {
                    var queryJB = from XElement jb in _xele.Elements("JBIB").Descendants()
                                  select jb;

                    bool blJT = false;
                   
                    foreach (XElement _xe in queryJB)
                    {
                        if (_xe.Name.ToString() == "JT")
                        {
                            blJT = true;
                        }                        
                        else if (blJT)
                        {
                            strJIssue = _xe.Value;
                            blJT = false;
                        }
                        else if (_xe.Name.ToString() == "PY")
                        {
                            strJYear = _xe.Value;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            _jyear = strJYear;
            return strJIssue;
        }

        private static string GetPatentNumber_Year(XElement _xele, out string _jyear)
        {
            string strPatNum = "";
            string strPYear = "";
            try
            {
                if (_xele != null)
                {
                    var queryPB = from XElement jb in _xele.Elements("PBIB").Descendants()
                                  select jb;

                    bool blCS = false;

                    foreach (XElement _xe in queryPB)
                    {
                        if (_xe.Name.ToString() == "CS")
                        {
                            blCS = true;
                        }
                        else if (blCS)
                        {
                            strPatNum = _xe.Value;
                            blCS = false;
                        }
                        else if (_xe.Name.ToString() == "PY")
                        {
                            strPYear = _xe.Value;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            _jyear = strPYear;
            return strPatNum;
        }

        private static string GetDocTypeFromString(string _doctype)
        {
            string strDType = "";
            try
            {
                if (_doctype != "")
                {
                    string[] strVals = _doctype.Split(':');
                    if (strVals != null)
                    {
                        if (strVals.Length > 0)
                        {
                            string[] strDVals = strVals[1].Split(';');
                            if (strDVals != null)
                            {
                                if (strDVals.Length > 0)
                                {
                                    strDType = strDVals[0];
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            return strDType;
        }

        private static string GetConvertedXmlString(string _xmltag)
        {
            string strConvXml = _xmltag;
            try
            {
                if (XmlConvsTbl != null && XmlConvsTbl.Rows.Count > 0)
                {
                    for (int i = 0; i < XmlConvsTbl.Rows.Count; i++)
                    {
                        strConvXml = strConvXml.Replace(XmlConvsTbl.Rows[i]["CGM_STRING"].ToString(), XmlConvsTbl.Rows[i]["STRING_REPLACEMENT"].ToString());
                    }
                }               
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strConvXml;
        }
        
        public static string GetChemistryHexCodeOnRegNo(string _filename, string _nrnreg)
        {
            try
            {
                if (_filename.Trim() != "")
                {
                    string[] strArrFLines = File.ReadAllLines(_filename);

                    if (strArrFLines != null && strArrFLines.Length > 0)
                    {
                        DataTable dtCGM = new DataTable();
                        dtCGM.Columns.Add("SUBSTANC", typeof(string));

                        for (int i = 0; i < strArrFLines.Length; i++)
                        {
                            if (strArrFLines[i].StartsWith("<SUBSTANC><RN ID=" + "\"" + _nrnreg + "\"" + ">"))
                            {
                                DataRow dRow = dtCGM.NewRow();
                                dRow[0] = strArrFLines[i];
                                dtCGM.Rows.Add(dRow);
                                break;
                            }
                        }

                        if (dtCGM != null && dtCGM.Rows.Count > 0)
                        {
                            DataTable dt = new DataTable();

                            string strFCond = "<SUBSTANC><RN ID=" + "\"" + _nrnreg + "\"" + ">*";
                            try
                            {
                                DataTable dtoutput = dtCGM.AsEnumerable().Where(a => Regex.IsMatch(a[dtCGM.Columns[0].ColumnName].ToString(), strFCond)).CopyToDataTable();
                                if (dtoutput != null)
                                {
                                    if (dtoutput.Rows.Count > 0)
                                    {
                                        string cellValue = dtoutput.Rows[0][0].ToString();

                                        string strSIM = cellValue.Substring(cellValue.IndexOf("<SIM>") + ("<SIM>".Length), ((cellValue.IndexOf("</SIM>") + 1) - cellValue.IndexOf("<SIM>")) - ("</SIM>".Length));
                                        return strSIM;
                                    }
                                }
                            }
                            catch
                            {

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return "";
        }

        //Gets all the Substances information
        public static DataTable GetCgmFileDataForProdFormation(string _cgmpath)
        {
            DataTable dtSubstances = null;
            try
            {
                if (_cgmpath.Trim() != "")
                {
                    #region Code commented
                    //DataTable dtXmlCons = DataOperations.GetXMLConvDetails();
                    //if (dtXmlCons != null)
                    //{
                    //    _XmlConvsTbl = dtXmlCons;
                    //} 
                    #endregion                                            
                    
                    string[] strArrFLines = File.ReadAllLines(_cgmpath);
                    if (strArrFLines != null)
                    {
                        if (strArrFLines.Length > 0)
                        {
                            dtSubstances = new DataTable();
                            dtSubstances.Columns.Add("SUBSTANC", typeof(string));

                            for (int i = 0; i < strArrFLines.Length; i++)
                            {
                                if (strArrFLines[i].StartsWith("<SUBSTANC>"))
                                {
                                    DataRow dRow = dtSubstances.NewRow();
                                    dRow[0] = strArrFLines[i];// GetConvertedXmlString(strArrFLines[i]);
                                    dtSubstances.Rows.Add(dRow);                                    
                                }
                            }
                            return dtSubstances;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtSubstances;
        }

        public static DataTable GetCgmFileDataForNUMSearch(string cgmpath,string tanid,string canid,out DataTable substtbl_out)
        {
            DataTable dtCGM = null;
            DataTable dtSubstance = null;         
            try
            {
                if (cgmpath.Trim() != "")
                {
                    string[] strArrFLines = File.ReadAllLines(cgmpath);
                    if (strArrFLines != null)
                    {
                        if (strArrFLines.Length > 0)
                        {
                            dtCGM = new DataTable();
                            dtCGM.Columns.Add("ARTICLE", typeof(string));

                            dtSubstance = new DataTable();
                            dtSubstance.Columns.Add("SUBSTANC", typeof(string));

                            DataRow dRow = null;
                            for (int i = 0; i < strArrFLines.Length; i++)
                            {
                                if (strArrFLines[i].StartsWith("<ARTICLE TYPE=\"CA\"><AN>" + canid + "</AN><TAN>" + tanid + "</TAN>"))
                                {                       
                                    dRow = null;
                                    dRow = dtCGM.NewRow();
                                    dRow[0] = strArrFLines[i];
                                    dtCGM.Rows.Add(dRow);                                    
                                }
                                else if (strArrFLines[i].StartsWith("<SUBSTANC>"))
                                {
                                    dRow = null;
                                    dRow = dtSubstance.NewRow();
                                    dRow[0] = strArrFLines[i];
                                    dtSubstance.Rows.Add(dRow); 
                                }
                            }
                            substtbl_out = dtSubstance;                            
                            return dtCGM;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            substtbl_out = dtSubstance;            
            return dtCGM;
        }
        
        //New method for bulk copy

        private static string[] GetHexCodeArrayOnRegNo(int _regno)
        {
            string[] strHexArr = null;
            try
            {
                if (SubstanceData != null)
                {
                    if (SubstanceData.Rows.Count > 0)
                    {
                        using (DataTable dtSubstances = SubstanceData.Copy())// CGMDataTbl.Copy();
                        {

                            string strFCond = "<SUBSTANC><RN ID=" + "\"" + _regno + "\"" + ">*";
                            try
                            {
                                DataTable dtoutput = dtSubstances.AsEnumerable().Where(a => Regex.IsMatch(a[dtSubstances.Columns[0].ColumnName].ToString(), strFCond)).CopyToDataTable();
                                if (dtoutput != null)
                                {
                                    if (dtoutput.Rows.Count > 0)
                                    {
                                        string cellValue = dtoutput.Rows[0][0].ToString();
                                        if (cellValue.Contains("<SIM>"))//Single structure
                                        {
                                            string strSIM = cellValue.Substring(cellValue.IndexOf("<SIM>") + ("<SIM>".Length), ((cellValue.IndexOf("</SIM>") + 1) - cellValue.IndexOf("<SIM>")) - ("</SIM>".Length));
                                            strHexArr = new string[1];
                                            strHexArr[0] = strSIM;
                                            return strHexArr;
                                        }
                                        else if (cellValue.Contains("<CSIM>"))//Multiple structures
                                        {
                                            string[] splitter = { "<CSIM>" };
                                            string[] strValues = cellValue.Split(splitter, StringSplitOptions.RemoveEmptyEntries);

                                            ArrayList alstVals = new ArrayList();
                                            if (strValues != null)
                                            {
                                                if (strValues.Length > 0)
                                                {
                                                    string[] splitter_End = { "</CSIM>" };
                                                    for (int i = 0; i < strValues.Length; i++)
                                                    {
                                                        if (!strValues[i].StartsWith("<SUBSTANC"))
                                                        {
                                                            string[] strValues_Hex = strValues[i].Split(splitter_End, StringSplitOptions.RemoveEmptyEntries);
                                                            if (strValues_Hex != null)
                                                            {
                                                                if (strValues_Hex.Length > 0)
                                                                {
                                                                    alstVals.Add(strValues_Hex[0]);
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            if (alstVals != null)
                                            {
                                                if (alstVals.Count > 0)
                                                {
                                                    strHexArr = (String[])alstVals.ToArray(typeof(string));
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            catch //Exception for series 8500 RegNos
                            {

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strHexArr;
        }

        private static string[] GetHexCodeArrayOnRegNo_New(int _regno)
        {
            string[] strHexArr = null;
            try
            {
                if (SubstanceData != null)
                {
                    if (SubstanceData.Rows.Count > 0)
                    {
                        using (DataTable dtcdm = SubstanceData.Copy())// CGMDataTbl.Copy();
                        {

                            string strFCond = "<SUBSTANC><RN ID=" + "\"" + _regno + "\"" + ">*";
                            try
                            {
                                DataTable dtoutput = dtcdm.AsEnumerable().Where(a => Regex.IsMatch(a[dtcdm.Columns[0].ColumnName].ToString(), strFCond)).CopyToDataTable();
                                if (dtoutput != null)
                                {
                                    if (dtoutput.Rows.Count > 0)
                                    {
                                        string cellValue = dtoutput.Rows[0][0].ToString();
                                        if (cellValue.Contains("<SIM>"))//Single structure
                                        {
                                            string strSIM = cellValue.Substring(cellValue.IndexOf("<SIM>") + ("<SIM>".Length), ((cellValue.IndexOf("</SIM>") + 1) - cellValue.IndexOf("<SIM>")) - ("</SIM>".Length));
                                            strHexArr = new string[1];
                                            strHexArr[0] = strSIM;
                                            return strHexArr;
                                        }
                                        else if (cellValue.Contains("<CSIM>"))//Multiple strucrures
                                        {
                                            string[] splitter = { "<CSIM>" };
                                            string[] strValues = cellValue.Split(splitter, StringSplitOptions.RemoveEmptyEntries);

                                            ArrayList alstVals = new ArrayList();
                                            if (strValues != null)
                                            {
                                                if (strValues.Length > 0)
                                                {
                                                    string[] splitter_End = { "</CSIM>" };
                                                    for (int i = 0; i < strValues.Length; i++)
                                                    {
                                                        if (!strValues[i].StartsWith("<SUBSTANC"))
                                                        {
                                                            string[] strValues_Hex = strValues[i].Split(splitter_End, StringSplitOptions.RemoveEmptyEntries);
                                                            if (strValues_Hex != null)
                                                            {
                                                                if (strValues_Hex.Length > 0)
                                                                {
                                                                    alstVals.Add(strValues_Hex[0]);
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            if (alstVals != null)
                                            {
                                                if (alstVals.Count > 0)
                                                {
                                                    strHexArr = (String[])alstVals.ToArray(typeof(string));
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            catch //Exception for series 8500 RegNos
                            {

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strHexArr;
        }

        private static DataTable GetCGMTableDefinition()
        {
            DataTable dtCGMData = new DataTable();
            
            DataColumn column = new DataColumn("TBIT_ID");
            column.DataType = System.Type.GetType("System.Int32");
            column.AutoIncrement = true;
            column.AutoIncrementSeed = 1;
            column.AutoIncrementStep = 1;

            // Add the column to a new DataTable.   
            dtCGMData.Columns.Add(column);
            dtCGMData.Columns.Add("SHIPMENT_NAME", typeof(string));
            dtCGMData.Columns.Add("TAN_NAME", typeof(string));
            dtCGMData.Columns.Add("CAN", typeof(string));
            dtCGMData.Columns.Add("TAN_TYPE", typeof(string));
            dtCGMData.Columns.Add("JOURNAL_NAME", typeof(string));
            dtCGMData.Columns.Add("ISSUE", typeof(string));
            dtCGMData.Columns.Add("JOURNAL_YEAR", typeof(string));
            dtCGMData.Columns.Add("NUM", typeof(string));
            dtCGMData.Columns.Add("REG_NO", typeof(string));
            dtCGMData.Columns.Add("FORMULA", typeof(string));
            dtCGMData.Columns.Add("IUPAC_NAME", typeof(string));
            dtCGMData.Columns.Add("PEPTIDE_SEQ", typeof(string));
            dtCGMData.Columns.Add("NUCLIC_ACID_SEQ", typeof(string));
            dtCGMData.Columns.Add("OTHER_NAMES", typeof(string));            
            dtCGMData.Columns.Add("MOL_HEX_CODE", typeof(string));
            
            return dtCGMData;
        }
      
        private static byte[] ToByteArray(String HexString)
        {
            int NumberChars = HexString.Length;
            byte[] bytes = new byte[NumberChars / 2];
            for (int i = 0; i < NumberChars; i += 2)
            {
                bytes[i / 2] = Convert.ToByte(HexString.Substring(i, 2), 16);
            }
            return bytes;
        }
        
        public static DataTable CgmData = null;
        public static DataTable SubstanceData = null;

        public static DataTable GetCgmFileData_BulkCopy(string _filename)
        {
            try
            {
                if (_filename.Trim() != "")
                {
                    string strFileName = Path.GetFileNameWithoutExtension(_filename);

                    string[] strSplitter = { "-" };
                    string[] strArr = strFileName.Split(strSplitter, StringSplitOptions.RemoveEmptyEntries);

                    string strShipmentName = "";
                    if (strArr != null)
                    {
                        if (strArr.Length > 0)
                        {
                            strShipmentName = strArr[0];
                        }
                    }

                    SubstanceData = GetCgmFileDataForProdFormation(_filename);

                    DataTable dtXmlCons = IndxReactNarrDAL.ReactDB.GetXMLConvDetails();

                    if (dtXmlCons != null)
                    {
                        XmlConvsTbl = dtXmlCons;
                    }

                    string[] strArrFLines = File.ReadAllLines(_filename);

                    string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";

                    if (strArrFLines != null)
                    {
                        if (strArrFLines.Length > 0)
                        {
                            CgmData = new DataTable();
                            CgmData.Columns.Add("Article", typeof(string));

                            for (int i = 0; i < strArrFLines.Length; i++)
                            {
                                if (strArrFLines[i].StartsWith("<ARTICLE TYPE="))
                                {
                                    DataRow dRow = CgmData.NewRow();
                                    dRow[0] = strArrFLines[i];
                                    CgmData.Rows.Add(dRow);
                                }
                            }

                            if (CgmData != null)
                            {
                                if (CgmData.Rows.Count > 0)
                                {
                                    StreamWriter sw = null;
                                    XElement xEle = null;
                                    string strTAN = "";
                                    string strCAN = "";
                                    string strDOCTYPE = "";
                                    string strJTitle = "";
                                    string strJIssue = "";
                                    string strJYear = "";

                                    //Create CGM data table definition
                                    DataTable dtTAN_CAN = GetCGMTableDefinition();
                                                                       
                                    string strConvXml = "";
                                    DataRow dRow = null;
                                    string[] saHexCode = null;

                                    for (int i = 0; i < CgmData.Rows.Count; i++)
                                    {
                                        strConvXml = CgmData.Rows[i][0].ToString().Trim();

                                        try
                                        {                                           
                                            xEle = XElement.Parse(strConvXml);//If any unrecognized xml value. throws exception
                                        }
                                        catch
                                        {
                                            strConvXml = GetConvertedXmlString(CgmData.Rows[i][0].ToString().Trim());
                                            xEle = XElement.Parse(strConvXml);
                                        }

                                        var query = from XElement r in xEle.Descendants("RN")
                                                    select r.Attribute("RID").Value;

                                        strCAN = "";
                                        strTAN = "";
                                        strDOCTYPE = "";
                                        strJTitle = "";
                                        strJIssue = "";
                                        strJYear = "";

                                        strCAN = xEle.Element("AN").Value;
                                        strTAN = xEle.Element("TAN").Value;
                                        //if (strTAN == "25550363P")
                                        //{

                                            strDOCTYPE = GetDocTypeFromString(xEle.Element("DT").Value);

                                            try
                                            {
                                                //If TAN is Journal 
                                                strJTitle = xEle.Element("JBIB").Elements("JT").ElementAt(0).Value;

                                                //Get Issue and Year from TAN
                                                strJIssue = GetJournalIssue_Year(xEle, out strJYear);
                                            }
                                            catch
                                            {
                                                try
                                                {
                                                    //If TAN is Patent
                                                    strJTitle = GetPatentNumber_Year(xEle, out strJYear);
                                                }
                                                catch
                                                {
                                                    strJTitle = "";
                                                }
                                            }

                                            var query2 = from XElement r2 in xEle.Elements("CSIE")
                                                         select r2;
                                            foreach (XElement _xe in query2)
                                            {
                                                #region MyRegion
                                                //dRow = dtTAN_CAN.NewRow();
                                                //dRow["Batch"] = strBarchName;
                                                //dRow["TAN"] = strTAN;
                                                //dRow["CAN"] = strCAN;
                                                //try
                                                //{
                                                //    dRow["NRNNUM"] = _xe.Element("NUM").Value;
                                                //}
                                                //catch
                                                //{
                                                //    dRow["NRNNUM"] = 0;
                                                //}
                                                //dRow["NRNREG"] = _xe.Element("RN").Attribute("RID").Value; 
                                                #endregion

                                                saHexCode = GetHexCodeArrayOnRegNo(Convert.ToInt32(_xe.Element("RN").Attribute("RID").Value));
                                                if (saHexCode != null)
                                                {
                                                    for (int hIndx = 0; hIndx < saHexCode.Length; hIndx++)
                                                    {
                                                        dRow = dtTAN_CAN.NewRow();
                                                        dRow["SHIPMENT_NAME"] = strShipmentName;
                                                        dRow["TAN_NAME"] = strTAN;
                                                        dRow["CAN"] = strCAN;
                                                        dRow["TAN_TYPE"] = strDOCTYPE;
                                                        dRow["JOURNAL_NAME"] = strJTitle;
                                                        dRow["ISSUE"] = strJIssue;
                                                        dRow["JOURNAL_YEAR"] = strJYear;

                                                        try
                                                        {
                                                            dRow["NUM"] = _xe.Element("NUM").Value;
                                                        }
                                                        catch
                                                        {
                                                            dRow["NUM"] = 0;
                                                        }

                                                        dRow["REG_NO"] = _xe.Element("RN").Attribute("RID").Value;
                                                        dRow["MOL_HEX_CODE"] = saHexCode[hIndx];//GetChemImageOnHexCode(saHexCode[hIndx], _xe.Element("RN").Attribute("RID").Value.ToString());

                                                        dtTAN_CAN.Rows.Add(dRow);
                                                    }
                                                }
                                            }
                                         //   break;
                                        //}
                                    }
                                    return dtTAN_CAN;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            return null;
        }

        //===============New Method for TANs & Substances Table

        private static DataTable GetTANsInfoTableDefinition()
        {
            DataTable dtTANsInfo = new DataTable();       
              
            dtTANsInfo.Columns.Add("TAN_NAME", typeof(string));
            dtTANsInfo.Columns.Add("CAN", typeof(string));
            dtTANsInfo.Columns.Add("TAN_TYPE", typeof(string));
            dtTANsInfo.Columns.Add("JOURNAL_NAME", typeof(string));
            dtTANsInfo.Columns.Add("ISSUE", typeof(string));
            dtTANsInfo.Columns.Add("JOURNAL_YEAR", typeof(string));
           
            DataColumn col = new DataColumn();
            col.ColumnName = "DB_STATUS";
            col.AllowDBNull = false;
            col.DataType = typeof(string);
            col.DefaultValue = "Not Uploaded";
            dtTANsInfo.Columns.Add(col);

            return dtTANsInfo;
        }

        private static DataTable GetTANNUM_RegNOTableDefinition()
        {
            DataTable dtNUM_SEQ = new DataTable();

            dtNUM_SEQ.Columns.Add("TAN", typeof(string));
            dtNUM_SEQ.Columns.Add("NUM", typeof(Int32));
            dtNUM_SEQ.Columns.Add("REG_NO", typeof(Int32));           

            return dtNUM_SEQ;
        }

        private static DataTable GetSubstancesTableDefinition()
        {
            DataTable dtSubstances = new DataTable();
                        
            dtSubstances.Columns.Add("REG_NO", typeof(string));
            dtSubstances.Columns.Add("FORMULA", typeof(string));
            dtSubstances.Columns.Add("IUPAC_NAME", typeof(string));
            dtSubstances.Columns.Add("ABS_STEREO", typeof(string));
            dtSubstances.Columns.Add("PEPTIDE_SEQ", typeof(string));
            dtSubstances.Columns.Add("NUCLIC_ACID_SEQ", typeof(string));
            dtSubstances.Columns.Add("OTHER_NAMES", typeof(string));
            dtSubstances.Columns.Add("MOL_HEX_CODE", typeof(string));

            return dtSubstances;
        }

        public static DataTable GetTANsAndSubstancesInformationFromCGMFile(string cgmFilePath, out DataTable tanNUMs, out DataTable substancesData)
        {
            DataTable dtTANsInfo = null;
            DataTable dtSubstances = null;
            DataTable dtTANNums = null;

            try
            {
                if (!string.IsNullOrEmpty(cgmFilePath.Trim()))
                {
                    string strShipmentName = Path.GetFileNameWithoutExtension(cgmFilePath);

                    //Get Xml replacements data
                    XmlConvsTbl = IndxReactNarrDAL.ReactDB.GetXMLConvDetails();

                    //Get Articles and Substances from the cgm file
                    DataTable ArticlesData = null;
                    DataTable SubstancesData = null;
                    ArticlesData = GetArticlesAndSubstancesFromCgmFile(cgmFilePath, out SubstancesData);

                    // SubstanceData = GetCgmFileDataForProdFormation(cgmFilePath);

                    //Get TANs info from Articles data
                    dtTANsInfo = GetTANsInfoFromArticlesData(ArticlesData);
                    
                    //Get TANs NUM-RegNo Information from Articles Data
                    dtTANNums = GetTANsNUM_RegNoInfoFromArticlesData(ArticlesData);

                    //Get NUMs information(IUPAC Name, Formula, PepSeq, Other Names,HexCode) from Substances Data
                    dtSubstances = GetSubstancesInfoFromSubstancesData(SubstancesData);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            tanNUMs = dtTANNums;
            substancesData = dtSubstances;
            return dtTANsInfo;
        }

        //Gets all the Substances information
        public static DataTable GetAllSubstancesFromCgmFile(string cgmFilePath)
        {
            DataTable dtSubstances = null;
            try
            {
                if (!string.IsNullOrEmpty(cgmFilePath.Trim()))
                {
                    string[] strArrFLines = File.ReadAllLines(cgmFilePath);
                    if (strArrFLines != null)
                    {
                        if (strArrFLines.Length > 0)
                        {
                            dtSubstances = new DataTable();
                            dtSubstances.Columns.Add("REG_NO", typeof(string));
                            dtSubstances.Columns.Add("IUPAC_NAME", typeof(string));
                            dtSubstances.Columns.Add("FORMULA", typeof(string));
                            dtSubstances.Columns.Add("MOL_HEXCODE", typeof(string));
                            XElement xEle;

                            for (int i = 0; i < strArrFLines.Length; i++)
                            {
                                if (strArrFLines[i].StartsWith("<SUBSTANC>"))
                                {
                                    xEle = XElement.Parse(strArrFLines[i]);

                                    DataRow dRow = dtSubstances.NewRow();
                                    dRow[0] = strArrFLines[i];// GetConvertedXmlString(strArrFLines[i]);



                                    dtSubstances.Rows.Add(dRow);
                                }
                            }
                            return dtSubstances;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtSubstances;
        }

        //Gets Artilces and Substances data
        private static DataTable GetArticlesAndSubstancesFromCgmFile(string cgmFilePath, out DataTable substData)
        {
            DataTable dtArticles = null;
            DataTable dtSubstances = null;
            try
            {
                if (!string.IsNullOrEmpty(cgmFilePath.Trim()))
                {
                    //SubstanceData = GetCgmFileDataForProdFormation(cgmFilePath);                    

                    string[] strArrFLines = File.ReadAllLines(cgmFilePath);

                    if (strArrFLines != null)
                    {
                        if (strArrFLines.Length > 0)
                        {
                            dtArticles = new DataTable();
                            dtArticles.Columns.Add("Article", typeof(string));

                            dtSubstances = new DataTable();
                            dtSubstances.Columns.Add("Substance", typeof(string));

                            for (int i = 0; i < strArrFLines.Length; i++)
                            {
                                if (strArrFLines[i].StartsWith("<ARTICLE TYPE="))
                                {
                                    DataRow dRow = dtArticles.NewRow();
                                    dRow[0] = strArrFLines[i];
                                    dtArticles.Rows.Add(dRow);
                                }
                                if (strArrFLines[i].StartsWith("<SUBSTANC>"))
                                {
                                    DataRow dRow = dtSubstances.NewRow();
                                    dRow[0] = strArrFLines[i];
                                    dtSubstances.Rows.Add(dRow);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            substData = dtSubstances;
            return dtArticles;
        }

        //Get TANs Info from Articles Data
        private static DataTable GetTANsInfoFromArticlesData(DataTable articlesData)
        {
            DataTable dtTANsInfo = null;
            try
            {
                if (articlesData != null)
                {
                    if (articlesData.Rows.Count > 0)
                    {
                        XElement xEle = null;
                        string strTAN = "";
                        string strCAN = "";
                        string strDOCTYPE = "";
                        string strJTitle = "";
                        string strJIssue = "";
                        string strJYear = "";

                        //Get TANs info table definition
                        dtTANsInfo = GetTANsInfoTableDefinition();

                        string strConvXml = "";
                        DataRow dRow = null;

                        for (int i = 0; i < articlesData.Rows.Count; i++)
                        {
                            strConvXml = articlesData.Rows[i][0].ToString().Trim();

                            try
                            {
                                xEle = XElement.Parse(strConvXml);//If any unrecognized xml value. throws exception
                            }
                            catch
                            {
                                strConvXml = GetConvertedXmlString(articlesData.Rows[i][0].ToString().Trim());
                                xEle = XElement.Parse(strConvXml);
                            }

                            var query = from XElement r in xEle.Descendants("RN")
                                        select r.Attribute("RID").Value;

                            strCAN = "";
                            strTAN = "";
                            strDOCTYPE = "";
                            strJTitle = "";
                            strJIssue = "";
                            strJYear = "";

                            strCAN = xEle.Element("AN").Value;
                            strTAN = xEle.Element("TAN").Value;
                            strDOCTYPE = GetDocTypeFromString(xEle.Element("DT").Value);

                            try
                            {
                                //If TAN is Journal 
                                strJTitle = xEle.Element("JBIB").Elements("JT").ElementAt(0).Value;

                                //Get Issue and Year from TAN
                                strJIssue = GetJournalIssue_Year(xEle, out strJYear);
                            }
                            catch
                            {
                                try
                                {
                                    //If TAN is Patent
                                    strJTitle = GetPatentNumber_Year(xEle, out strJYear);
                                }
                                catch
                                {
                                    strJTitle = "";
                                }
                            }

                            dRow = dtTANsInfo.NewRow();
                            dRow["TAN_NAME"] = strTAN;
                            dRow["CAN"] = strCAN;
                            dRow["TAN_TYPE"] = strDOCTYPE;
                            dRow["JOURNAL_NAME"] = strJTitle;
                            dRow["ISSUE"] = strJIssue;
                            dRow["JOURNAL_YEAR"] = strJYear;

                            dtTANsInfo.Rows.Add(dRow);

                            #region MyRegion
                            //var query2 = from XElement r2 in xEle.Elements("CSIE")
                            //             select r2;
                            //foreach (XElement _xe in query2)
                            //{
                            //    #region MyRegion
                            //    //dRow = dtTAN_CAN.NewRow();
                            //    //dRow["Batch"] = strBarchName;
                            //    //dRow["TAN"] = strTAN;
                            //    //dRow["CAN"] = strCAN;
                            //    //try
                            //    //{
                            //    //    dRow["NRNNUM"] = _xe.Element("NUM").Value;
                            //    //}
                            //    //catch
                            //    //{
                            //    //    dRow["NRNNUM"] = 0;
                            //    //}
                            //    //dRow["NRNREG"] = _xe.Element("RN").Attribute("RID").Value; 
                            //    #endregion

                            //    saHexCode = GetHexCodeArrayOnRegNo(Convert.ToInt32(_xe.Element("RN").Attribute("RID").Value));
                            //    if (saHexCode != null)
                            //    {
                            //        for (int hIndx = 0; hIndx < saHexCode.Length; hIndx++)
                            //        {


                            //            try
                            //            {
                            //                dRow["NUM"] = _xe.Element("NUM").Value;
                            //            }
                            //            catch
                            //            {
                            //                dRow["NUM"] = 0;
                            //            }

                            //            dRow["REG_NO"] = _xe.Element("RN").Attribute("RID").Value;
                            //            dRow["MOL_HEX_CODE"] = saHexCode[hIndx];//GetChemImageOnHexCode(saHexCode[hIndx], _xe.Element("RN").Attribute("RID").Value.ToString());

                            //            dtTAN_CAN.Rows.Add(dRow);
                            //        }
                            //    }
                            //} 
                            #endregion

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            return dtTANsInfo;
        }

        //Get TANs NUM-RegNo info from Articles data
        private static DataTable GetTANsNUM_RegNoInfoFromArticlesData(DataTable articlesData)
        {
            DataTable dtTANNUM_RegNo = null;
            try
            {
                if (articlesData != null)
                {
                    if (articlesData.Rows.Count > 0)
                    {
                        XElement xEle = null;
                        string strTAN = "";                        

                        //Get TANs Num_RegNo info table definition
                        dtTANNUM_RegNo = GetTANNUM_RegNOTableDefinition();

                        string strConvXml = "";
                        DataRow dRow = null;

                        for (int i = 0; i < articlesData.Rows.Count; i++)
                        {
                            strConvXml = articlesData.Rows[i][0].ToString().Trim();

                            try
                            {
                                xEle = XElement.Parse(strConvXml);//If any unrecognized xml value. throws exception
                            }
                            catch
                            {
                                strConvXml = GetConvertedXmlString(articlesData.Rows[i][0].ToString().Trim());
                                xEle = XElement.Parse(strConvXml);
                            }

                            strTAN = xEle.Element("TAN").Value;


                            var query2 = from XElement r2 in xEle.Elements("CSIE")
                                         select r2;
                            foreach (XElement _xe in query2)
                            {
                                dRow = dtTANNUM_RegNo.NewRow();                               
                                dRow["TAN"] = strTAN;                               
                                try
                                {
                                    dRow["NUM"] = _xe.Element("NUM").Value;
                                }
                                catch
                                {
                                    dRow["NUM"] = 0;
                                }
                                dRow["REG_NO"] = _xe.Element("RN").Attribute("RID").Value;

                                dtTANNUM_RegNo.Rows.Add(dRow);
                            }
                        }

                        //Sort table on TAN, NUM
                        if (dtTANNUM_RegNo != null)
                        {
                            DataView dvTemp = dtTANNUM_RegNo.DefaultView;
                            dvTemp.Sort = "TAN, NUM asc";
                            dtTANNUM_RegNo = dvTemp.ToTable();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtTANNUM_RegNo;
        }

        //Get Substances Info(NUM,RegNo,Formula, PepSeq,OtherNames,Mol HexCode
        private static DataTable GetSubstancesInfoFromSubstancesData(DataTable substancesData)
        {
            DataTable dtSubstances = null;
            try
            {
                if (substancesData != null)
                {
                    //Get Substances Table definition
                    dtSubstances = GetSubstancesTableDefinition();

                    string[] saMolHexCode = null;
                    string strIUPACName = "";
                    string[] saAbsStereo = null;
                    string[] saMolFormulas = null;
                    string strSynonym = "";
                    string strPepSeq = "";
                    string strNuclicSeq = "";
                    XElement xEle;

                    foreach (DataRow dRow in substancesData.Rows)
                    {
                        string cellValue = dRow[0].ToString();
                        if (cellValue.Contains("<SIM>"))//Single structure
                        {
                            DataRow row = dtSubstances.NewRow();

                            saMolHexCode = new string[1];
                            strIUPACName = "";
                            saAbsStereo = new string[1];
                            saMolFormulas = new string[1];
                            strSynonym = "";
                            strPepSeq = "";
                            strNuclicSeq = "";

                            //string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";
                            cellValue = GetConvertedXmlString(cellValue);
                            //cellValue = strXml + "\r\n" + cellValue;

                            xEle = XElement.Parse(cellValue);

                            //xDoc = new XmlDocument();
                            //xDoc.LoadXml(cellValue);
                            row["REG_NO"] = xEle.Element("RN").Attribute("ID").Value;
                            row["FORMULA"] = xEle.Element("MF") != null ? xEle.Element("MF").Value : "";//Mol Formula
                            row["IUPAC_NAME"] = xEle.Element("IN") != null ? xEle.Element("IN").Value : "";//IUPAC Name
                            row["OTHER_NAMES"] = xEle.Element("SYN") != null ? xEle.Element("SYN").Value : "";//Synonyms                            
                            row["MOL_HEX_CODE"] = xEle.Element("SIM") != null ? xEle.Element("SIM").Value : "";//Hex Codes
                            row["ABS_STEREO"] = xEle.Element("STEMSG") != null ? xEle.Element("STEMSG").Value : "";//Absolute Stereo
                            row["PEPTIDE_SEQ"] = xEle.Element("PSEQ") != null ? xEle.Element("PSEQ").Value : "";//Peptide Sequence
                            row["NUCLIC_ACID_SEQ"] =xEle.Element("NSEQ") != null ? xEle.Element("NSEQ").Value : "";//Nuclic Acid Sequence
                            
                            dtSubstances.Rows.Add(row);

                            #region MyRegion
                            ////Hex Codes
                            //xnlSIMHex = xDoc.SelectNodes("SUBSTANC/SIM");

                            //objRegNoInfo.MolHexCodes = GetHexCodesFromNodeList(xnlSIMHex); //saMolHexCode;//New code on 19th Nov 2013

                            ////IUPAC Name
                            //xnlIUPACName = xDoc.SelectNodes("SUBSTANC/IN");
                            //objRegNoInfo.IUPACName = GetIUPACNameFromNodeList(xnlIUPACName);

                            ////Mol Formula
                            //xnlMolFormula = xDoc.SelectNodes("SUBSTANC/MF");
                            //objRegNoInfo.MolFormula = GetMolFormulaFromNodeList(xnlMolFormula);

                            //objRegNoInfo.MolFormulas = saMolFormulas;//New code on 19th Nov 2013

                            ////Absolute Stereo
                            //xnlAbsStreo = xDoc.SelectNodes("SUBSTANC/STEMSG");

                            //objRegNoInfo.MolAbsStereos = GetAbsoluteStereoFromNodeList(xnlAbsStreo, 0);//saAbsStereo;//New code on 19th Nov 2013

                            ////Synonyms
                            //xnlSynonyms = xDoc.SelectNodes("SUBSTANC/SYN");
                            //objRegNoInfo.MolSynonyms = GetSynonymsFromNodeList(xnlSynonyms);//New code on 19th Nov 2013

                            ////PSEQ - 18th NOv 2013
                            //xnlPSEQ = xDoc.SelectNodes("SUBSTANC/PSEQ");
                            //objRegNoInfo.MolProteinSeq = GetPeptideSequenceFromNodeList(xnlPSEQ);//New code on 19th Nov 2013

                            ////NSEQ - 18th NOv 2013
                            //xnlNSeq = xDoc.SelectNodes("SUBSTANC/NSEQ");
                            //objRegNoInfo.MolNuclicAcidSeq = GetNeuclicAcidSequenceFromNodeList(xnlNSeq);//New code on 19th Nov 2013 
                            #endregion
                        }
                        else if (cellValue.Contains("<CSIM>"))//Multiple structures
                        {
                            cellValue = GetConvertedXmlString(cellValue);
                            xEle = XElement.Parse(cellValue);
                            var query = from XElement r in xEle.Descendants("COMP")
                                        select r;

                            //string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";
                            //cellValue = strXml + "\r\n" + GetConvertedXmlString(cellValue);
                            //XmlDocument xDoc = new XmlDocument();
                            //xDoc.LoadXml(cellValue);                                                     
                            
                            //var query2 = from XElement r2 in xEle.Elements("COMP")
                            //                         select r2;                           

                            string molHexCodes = "";
                            string strHexCode = "";
                            foreach (XElement _xe in query)
                            {
                                 strHexCode = _xe.Element("CSIM") != null ? _xe.Element("CSIM").Value : "";
                                 if (!string.IsNullOrEmpty(strHexCode))
                                 {
                                     if (string.IsNullOrEmpty(molHexCodes))
                                     {
                                         molHexCodes = strHexCode;
                                     }
                                     else
                                     {
                                         molHexCodes = molHexCodes + "<CSIM>" + strHexCode;
                                     }
                                 }
                            }

                            DataRow row = dtSubstances.NewRow();
                            row["REG_NO"] = xEle.Element("RN").Attribute("ID").Value;
                            row["FORMULA"] = xEle.Element("MF") != null ? xEle.Element("MF").Value : "";
                            row["IUPAC_NAME"] = xEle.Element("IN") != null ? xEle.Element("IN").Value : "";//IUPAC Name
                            row["OTHER_NAMES"] = xEle.Element("SYN") != null ? xEle.Element("SYN").Value : "";//Synonyms
                            row["ABS_STEREO"] = xEle.Element("STEMSG") != null ? xEle.Element("STEMSG").Value : "";//Absolute Stereo
                            row["PEPTIDE_SEQ"] = xEle.Element("PSEQ") != null ? xEle.Element("PSEQ").Value : "";//Peptide Sequence
                            row["NUCLIC_ACID_SEQ"] = xEle.Element("NSEQ") != null ? xEle.Element("NSEQ").Value : "";//Nuclic Acid Sequence
                            row["MOL_HEX_CODE"] = molHexCodes;//Mol Hex Codes
                            dtSubstances.Rows.Add(row);

                            #region MyRegion
                            //xnlSIMHex = xDoc.SelectNodes("SUBSTANC/COMP/CSIM");
                            //if (xnlSIMHex.Count > 0)
                            //{
                            //    //Define arrays of equal size
                            //    saMolHexCode = new string[xnlSIMHex.Count];
                            //    saAbsStereo = new string[xnlSIMHex.Count];
                            //    saMolFormulas = new string[xnlSIMHex.Count];

                            //    objRegNoInfo.MolHexCodes = GetHexCodesFromNodeList(xnlSIMHex);// saMolHexCode;//New code on 19th Nov 2013

                            //    //IUPAC name
                            //    xnlIUPACName = xDoc.SelectNodes("SUBSTANC/IN");
                            //    objRegNoInfo.IUPACName = GetIUPACNameFromNodeList(xnlIUPACName);

                            //    //Absolute Stereo
                            //    xnlAbsStreo = xDoc.SelectNodes("SUBSTANC/COMP");//CSTEMSG

                            //    objRegNoInfo.MolAbsStereos = GetAbsoluteStereoFromNodeList(xnlAbsStreo, saAbsStereo.Length);// saAbsStereo;//New code on 19th Nov 2013

                            //    //Molecule Formula - Whole compound molecule formula
                            //    xnlMolFormula = xDoc.SelectNodes("SUBSTANC/MF");
                            //    objRegNoInfo.MolFormula = GetMolFormulaFromNodeList(xnlMolFormula);

                            //    //Molecule Formula Array, Individual compounds Mol Formulas
                            //    xnlMolFormArr = xDoc.SelectNodes("SUBSTANC/COMP/CMF");

                            //    objRegNoInfo.MolFormulas = GetMolFormulaArrayFromNodeList(xnlMolFormula, saMolFormulas.Length);//xnlMolFormArr.Count - Modified on 2nd Dec 2013, single structure, multiple formulas

                            //    //Synonyms
                            //    xnlSynonyms = xDoc.SelectNodes("SUBSTANC/SYN");
                            //    objRegNoInfo.MolSynonyms = GetSynonymsFromNodeList(xnlSynonyms);//New code on 19th Nov 2013

                            //    //ProteinSequence - 18th NOv 2013
                            //    xnlPSEQ = xDoc.SelectNodes("SUBSTANC/PSEQ");
                            //    objRegNoInfo.MolProteinSeq = GetPeptideSequenceFromNodeList(xnlPSEQ);//New code on 19th Nov 2013

                            //    //NuclicAcidSequence - 18th NOv 2013
                            //    xnlNSeq = xDoc.SelectNodes("SUBSTANC/NSEQ");
                            //    objRegNoInfo.MolNuclicAcidSeq = GetNeuclicAcidSequenceFromNodeList(xnlNSeq);//New code on 19th Nov 2013
                            //} 
                            #endregion
                        }
                        else //No Structure available
                        {                                                                                   
                            cellValue = GetConvertedXmlString(cellValue); 
                            xEle = XElement.Parse(cellValue);

                            DataRow row = dtSubstances.NewRow();
                            row["REG_NO"] = xEle.Element("RN").Attribute("ID").Value;
                            row["FORMULA"] = xEle.Element("MF") != null ? xEle.Element("MF").Value : "";
                            row["IUPAC_NAME"] = xEle.Element("IN") != null ? xEle.Element("IN").Value : "";//IUPAC Name
                            row["OTHER_NAMES"] = xEle.Element("SYN") != null ? xEle.Element("SYN").Value : "";//Synonyms
                            row["ABS_STEREO"] = xEle.Element("STEMSG") != null ? xEle.Element("STEMSG").Value : "";//Absolute Stereo
                            row["PEPTIDE_SEQ"] = xEle.Element("PSEQ") != null ? xEle.Element("PSEQ").Value : "";//Peptide Sequence
                            row["NUCLIC_ACID_SEQ"] = xEle.Element("NSEQ") != null ? xEle.Element("NSEQ").Value : "";//Nuclic Acid Sequence
                            row["MOL_HEX_CODE"] = "";//Mol Hex Codes      
                            dtSubstances.Rows.Add(row);
                        }
                    }           
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtSubstances;
        }

        #region Compound Elements - New methods on 11th Dec 2013

        #region MyRegion
        //private static string GetIUPACNameFromNodeList(XmlNodeList nodeList)
        //{
        //    string strIUPAC = "";
        //    try
        //    {
        //        if (nodeList != null)
        //        {
        //            if (nodeList.Count > 0)
        //            {
        //                strIUPAC = nodeList[0].InnerXml;
        //                strIUPAC = DeleteXMLTagsFromName(strIUPAC);
        //                strIUPAC = SetGreekLetters_IUPACName(strIUPAC);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return strIUPAC;
        //}

        //private static string GetMolFormulaFromNodeList(XmlNodeList nodeList)
        //{
        //    string strMolFormula = "";
        //    try
        //    {
        //        if (nodeList != null)
        //        {
        //            if (nodeList.Count > 0)
        //            {
        //                strMolFormula = nodeList[0].InnerText;
        //                strMolFormula = strMolFormula.Replace("<SUB>", "");
        //                strMolFormula = strMolFormula.Replace("</SUB>", "");
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return strMolFormula;
        //}

        //private static string GetSynonymsFromNodeList(XmlNodeList nodeList)
        //{
        //    string strSynonyms = "";
        //    try
        //    {
        //        if (nodeList != null)
        //        {
        //            if (nodeList.Count > 0)
        //            {
        //                for (int i = 0; i < nodeList.Count; i++)
        //                {
        //                    strSynonyms = strSynonyms.Trim() + "\r\n" + nodeList[i].InnerText.Trim();
        //                }
        //                strSynonyms = SetGreekLetters_IUPACName(strSynonyms);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return strSynonyms.Trim();
        //}

        //private static string GetPeptideSequenceFromNodeList(XmlNodeList nodeList)
        //{
        //    string strPepSeq = "";
        //    try
        //    {
        //        if (nodeList != null)
        //        {
        //            if (nodeList.Count > 0)
        //            {
        //                for (int i = 0; i < nodeList.Count; i++)
        //                {
        //                    strPepSeq = strPepSeq.Trim() + "\r\n" + nodeList[i].InnerText.Trim();
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return strPepSeq.Trim();
        //}

        //private static string GetNeuclicAcidSequenceFromNodeList(XmlNodeList nodeList)
        //{
        //    string strNeuclicSeq = "";
        //    try
        //    {
        //        if (nodeList != null)
        //        {
        //            if (nodeList.Count > 0)
        //            {
        //                for (int i = 0; i < nodeList.Count; i++)
        //                {
        //                    strNeuclicSeq = strNeuclicSeq.Trim() + "\r\n" + nodeList[i].InnerText.Trim();
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return strNeuclicSeq.Trim();
        //}

        //private static string[] GetHexCodesFromNodeList(XmlNodeList nodeList)
        //{
        //    string[] saHexCodes = null;
        //    try
        //    {
        //        if (nodeList != null)
        //        {
        //            saHexCodes = new string[xnlSIMHex.Count];
        //            for (int i = 0; i < xnlSIMHex.Count; i++)
        //            {
        //                saHexCodes[i] = xnlSIMHex[i].InnerText;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return saHexCodes;
        //}

        //private static string[] GetMolFormulaArrayFromNodeList(XmlNodeList nodeList, int nodeLength)
        //{
        //    string[] saMolFormulas = null;
        //    try
        //    {
        //        string strFormula = "";
        //        if (nodeList != null)
        //        {
        //            if (nodeList.Count > 0 && nodeLength > 0)
        //            {
        //                int intLen = nodeLength;
        //                if (nodeList.Count < nodeLength)
        //                {
        //                    intLen = nodeList.Count;
        //                }
        //                saMolFormulas = new string[intLen];

        //                for (int i = 0; i < saMolFormulas.Length; i++)//xnlMolFormArr.Count - Modified on 2nd Dec 2013, single structure, multiple formulas
        //                {
        //                    strFormula = nodeList[i].InnerText;
        //                    strFormula = strFormula.Replace("<SUB>", "");
        //                    strFormula = strFormula.Replace("</SUB>", "");
        //                    saMolFormulas[i] = strFormula;
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return saMolFormulas;
        //}

        //static string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";
        //private static string[] GetAbsoluteStereoFromNodeList(XmlNodeList nodeList, int nodeLength)
        //{
        //    string[] saAbsStereo = new string[nodeLength];
        //    try
        //    {
        //        if (nodeList != null)
        //        {
        //            if (nodeList.Count > 0)
        //            {
        //                if (nodeLength == 0)//Single compound
        //                {
        //                    saAbsStereo = new string[1];
        //                    saAbsStereo[0] = xnlAbsStreo[0].InnerText;
        //                }
        //                else //Multiple compounds
        //                {
        //                    int intLen = nodeLength;
        //                    if (nodeList.Count < nodeLength)
        //                    {
        //                        intLen = nodeList.Count;
        //                    }
        //                    saAbsStereo = new string[intLen];

        //                    string strXmlData = "";
        //                    for (int i = 0; i < saAbsStereo.Length; i++)
        //                    {
        //                        strXmlData = "";
        //                        strXmlData = strXml + "\r\n" + xnlAbsStreo[i].OuterXml;

        //                        XmlDocument xDoc_Abs = new XmlDocument();
        //                        xDoc_Abs.LoadXml(strXmlData);

        //                        XmlNodeList xNdLst_Abs = xDoc_Abs.SelectNodes("COMP/CSTEMSG");
        //                        if (xNdLst_Abs.Count > 0)
        //                        {
        //                            saAbsStereo[i] = xNdLst_Abs[0].InnerText;
        //                        }
        //                        else
        //                        {
        //                            saAbsStereo[i] = "";
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return saAbsStereo;
        //} 
        #endregion

        private static string SetGreekLetters_IUPACName(string _iupacname)
        {
            string strIUPAC = _iupacname;
            try
            {
                if (XmlConvsTbl != null)
                {
                    if (XmlConvsTbl.Rows.Count > 0)
                    {
                        for (int i = 0; i < XmlConvsTbl.Rows.Count; i++)
                        {
                            if (strIUPAC.Trim().Contains(XmlConvsTbl.Rows[i]["CGM_STRING"].ToString()))
                            {
                                strIUPAC = strIUPAC.Replace(XmlConvsTbl.Rows[i]["CGM_STRING"].ToString(), XmlConvsTbl.Rows[i]["GREEK_LETTER"].ToString());
                            }
                            if (strIUPAC.Trim().Contains(XmlConvsTbl.Rows[i]["STRING_REPLACEMENT"].ToString()))
                            {
                                strIUPAC = strIUPAC.Replace(XmlConvsTbl.Rows[i]["STRING_REPLACEMENT"].ToString(), XmlConvsTbl.Rows[i]["GREEK_LETTER"].ToString());
                            }
                        }
                    }
                }
                return strIUPAC;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strIUPAC;
        }

        private static string DeleteXMLTagsFromName(string _iupacname)
        {
            string strIUPAC = _iupacname;
            try
            {
                strIUPAC = strIUPAC.Replace("<IT>", "");
                strIUPAC = strIUPAC.Replace("</IT>", "");
                //strIUPAC = strIUPAC.Replace("<SUP>", "");
                //strIUPAC = strIUPAC.Replace("</SUP>", "");
                strIUPAC = strIUPAC.Replace("<SCP>", "");
                strIUPAC = strIUPAC.Replace("</SCP>", "");
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strIUPAC;
        }

        #endregion
    }
}
