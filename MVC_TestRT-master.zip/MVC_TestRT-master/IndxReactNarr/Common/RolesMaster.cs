﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarr.Common
{
    public class RolesMaster
    {
        public const string ADMIN = "Administrator";
        public const string PM = "Project Manager";
        public const string ANALYST = "Analyst";
        public const string REV_ANALYST = "Review Analyst";
        public const string QC_ANALYST = "Quality Analyst";
        public const string TOOL_MANAGER = "Tool Manager";
    }
}
