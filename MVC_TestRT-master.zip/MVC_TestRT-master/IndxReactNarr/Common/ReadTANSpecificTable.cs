﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace IndxReactNarr.Common
{
    public static class Get_TAN_Nrn_Reg_Data
    {
        public static int Get_NrnNum(DataTable _dttan_nrns, int _nrnreg)
        {
            int intNrnNum = 0;
            try
            {
                if (_nrnreg > 0)
                {
                    if (_dttan_nrns != null)
                    {
                        if (_dttan_nrns.Rows.Count > 0)
                        {
                            DataRow[] dtRowArr = _dttan_nrns.Select("REG_NO = '" + _nrnreg + "'");
                            if (dtRowArr != null)
                            {
                                if (dtRowArr.Length > 0)
                                {
                                    int.TryParse(dtRowArr[0]["NUM"].ToString(), out intNrnNum);                                  
                                    return intNrnNum;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }           
            return intNrnNum;
        }

        public static int Get_NrnReg(DataTable _dttan_nrns, int _nrnnum)
        {
            int intNrnReg = 0;
            try
            {
                if (_nrnnum > 0)
                {
                    if (_dttan_nrns != null)
                    {
                        if (_dttan_nrns.Rows.Count > 0)
                        {
                            DataRow[] dtRowArr = _dttan_nrns.Select("NUM = '" + _nrnnum + "'");
                            if (dtRowArr != null)
                            {
                                if (dtRowArr.Length > 0)
                                {
                                    int.TryParse(dtRowArr[0]["REG_NO"].ToString(), out intNrnReg);
                                    return intNrnReg;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return intNrnReg;
        }
    }
}
