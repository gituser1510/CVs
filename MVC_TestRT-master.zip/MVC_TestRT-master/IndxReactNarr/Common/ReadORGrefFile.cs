﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;

namespace IndxReactNarr.Common
{
    public static class Get_OrGref_Data
    {
        public static int GetRegNoAndNameOnNUM(int _nrnnum,out string _prodname)
        {
            int intNrnReg = 0;
            try
            {
                #region Code Commented
                //if (_filePath.Trim() != "")
                //{
                //    String strConString = "Provider=Microsoft.Jet.OLEDB.4.0;" +
                //    "Data Source=" + _filePath + ";" + "Extended Properties=Excel 8.0;";

                //    OleDbConnection objOleDBCon = new OleDbConnection(strConString);
                //    objOleDBCon.Open();

                //    OleDbCommand objOleDBCmd = new OleDbCommand("SELECT * FROM [Sheet1$]", objOleDBCon);

                //    OleDbDataAdapter objOleDBAdpt = new OleDbDataAdapter();
                //    objOleDBAdpt.SelectCommand = objOleDBCmd;

                //    DataSet dsResults = new DataSet();
                //    objOleDBAdpt.Fill(dsResults);
                //    objOleDBCon.Close();

                //    if (dsResults != null)
                //    {
                //        if (dsResults.Tables[0] != null)
                //        {
                //            dtResults = dsResults.Tables[0];
                //        }
                //    }

                //    return dtResults;
                //} 
                #endregion

                if (_nrnnum > 0)
                {
                    if (Generic.GlobalVariables.Ser9000OrgRefData != null)
                    {
                        if (Generic.GlobalVariables.Ser9000OrgRefData.Rows.Count > 0)
                        {
                            DataRow[] dtRowArr = Generic.GlobalVariables.Ser9000OrgRefData.Select("NUM = '" + _nrnnum + "'");
                            if (dtRowArr != null)
                            {
                                if (dtRowArr.Length > 0)
                                {
                                    int.TryParse(dtRowArr[0]["REG_NO"].ToString(),out intNrnReg);
                                    _prodname = dtRowArr[0]["ORGREF_NAME"].ToString();
                                    return intNrnReg;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _prodname = "";
            return intNrnReg;
        }

        public static int GetNumAndNameOnRegNo(int _nrnreg, out string _prodname)
        {
            int intNrnNum = 0;
            try
            {
                if (_nrnreg > 0)
                {
                    if (Generic.GlobalVariables.Ser9000OrgRefData != null)
                    {
                        if (Generic.GlobalVariables.Ser9000OrgRefData.Rows.Count > 0)
                        {
                            DataRow[] dtRowArr = Generic.GlobalVariables.Ser9000OrgRefData.Select("REG_NO = '" + _nrnreg + "'");
                            if (dtRowArr != null)
                            {
                                if (dtRowArr.Length > 0)
                                {
                                    int.TryParse(dtRowArr[0]["NUM"].ToString(),out intNrnNum);
                                    _prodname = dtRowArr[0]["ORGREF_NAME"].ToString();
                                    return intNrnNum;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _prodname = "";
            return intNrnNum;
        }

        public static int GetNumAndRegNoOnName(string _prodname, out int _nrnreg)
        {
            int intNrnNum = 0;
            try
            {
                if (_prodname.Trim() != "")
                {
                    if (Generic.GlobalVariables.Ser9000OrgRefData != null)
                    {
                        if (Generic.GlobalVariables.Ser9000OrgRefData.Rows.Count > 0)
                        {
                            DataRow[] dtRowArr = Generic.GlobalVariables.Ser9000OrgRefData.Select("ORGREF_NAME = '" + ReplaceSpecialCharsinString(_prodname) + "'");
                            if (dtRowArr != null)
                            {
                                if (dtRowArr.Length > 0)
                                {
                                    int.TryParse(dtRowArr[0]["NUM"].ToString(),out intNrnNum);
                                    int.TryParse(dtRowArr[0]["REG_NO"].ToString(),out _nrnreg);                                    
                                    return intNrnNum;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _nrnreg = 0;
            return intNrnNum;
        }

        private static string ReplaceSpecialCharsinString(string value)
        {
            StringBuilder sb = new StringBuilder(value.Length);
            for (int i = 0; i < value.Length; i++)
            {
                char c = value[i];
                switch (c)
                {
                    case ']':
                    case '[':
                    case '%':
                    case '*':
                        sb.Append("[").Append(c).Append("]");
                        break;
                    case '\'':
                        sb.Append("''");
                        break;
                    default:
                        sb.Append(c);
                        break;
                }
            }
            return sb.ToString();
        }
    }
}
