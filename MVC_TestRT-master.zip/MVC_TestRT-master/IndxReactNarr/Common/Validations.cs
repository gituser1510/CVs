﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using IndxReactNarr.Generic;

namespace IndxReactNarr.Common
{
    public class Validations
    {
        static Dictionary<char, string> SpecialCharList = new Dictionary<char, string>();

        public Validations()
        {
            Initialize_Dictionary();
        }

        public static bool ValidateCANFormat(string _strtext)
        {

            Regex RE = new Regex("[0-9]{3}:[0-9]{6}$", RegexOptions.Singleline);
            MatchCollection theMatches = RE.Matches(_strtext);
            if (theMatches.Count > 0)
                return true;
            else
                return false;

        }

        public static bool ValidateTANFormat(string _strtext)
        {
            Regex RE = new Regex("[0-9]{8}[A-Z]{1}$", RegexOptions.Singleline);
            MatchCollection theMatches = RE.Matches(_strtext);
            if (theMatches.Count > 0)
                return true;
            else
                return false;
        }

        public static Boolean ValidateTAN(string stTANName)
        {
            if (stTANName.Trim().Length != 9)
                return false;
            int result;
            if (Int32.TryParse(stTANName.Substring(0, 8), out result))
            {
                int result1;
                if (!Int32.TryParse(stTANName.Substring(8, 1), out result1))
                {
                    return true;
                }
            }

            return false;
        }

        private static void Initialize_Dictionary()
        {
            SpecialCharList.Clear();
            SpecialCharList.Add('\u0391', "^fA");
            SpecialCharList.Add('\u0392', "^fB");
            SpecialCharList.Add('\u0393', "^fG");
            SpecialCharList.Add('\u0394', "^fD");
            SpecialCharList.Add('\u0395', "^fE");
            SpecialCharList.Add('\u0396', "^fZ");
            SpecialCharList.Add('\u0397', "^fH");
            SpecialCharList.Add('\u0398', "^fJ");
            SpecialCharList.Add('\u0399', "^fI");
            SpecialCharList.Add('\u039a', "^fK");
            SpecialCharList.Add('\u039b', "^fL");
            SpecialCharList.Add('\u039c', "^fM");
            SpecialCharList.Add('\u039d', "^fN");
            SpecialCharList.Add('\u039e', "^fX");
            SpecialCharList.Add('\u039f', "^fQ");
            SpecialCharList.Add('\u03a0', "^fP");
            SpecialCharList.Add('\u03a1', "^fR");
            SpecialCharList.Add('\u03a3', "^fS");
            SpecialCharList.Add('\u03a4', "^fT");
            SpecialCharList.Add('\u03a5', "^fU");
            SpecialCharList.Add('\u03a6', "^fF");
            SpecialCharList.Add('\u03a7', "^fC");
            SpecialCharList.Add('\u03a8', "^fV");
            SpecialCharList.Add('\u03a9', "^fO");

            SpecialCharList.Add('\u03b1', "^fa");
            SpecialCharList.Add('\u03b2', "^fb");
            SpecialCharList.Add('\u03b3', "^fg");
            SpecialCharList.Add('\u03b4', "^fd");
            SpecialCharList.Add('\u03b5', "^fe");
            SpecialCharList.Add('\u03b6', "^fz");
            SpecialCharList.Add('\u03b7', "^fh");
            SpecialCharList.Add('\u03b8', "^fj");
            SpecialCharList.Add('\u03b9', "^fi");
            SpecialCharList.Add('\u03ba', "^fk");
            SpecialCharList.Add('\u03bb', "^fl");
            SpecialCharList.Add('\u03bc', "^fm");
            SpecialCharList.Add('\u03bd', "^fn");
            SpecialCharList.Add('\u03be', "^fx");
            SpecialCharList.Add('\u03bf', "^fq");
            SpecialCharList.Add('\u03c0', "^fp");
            SpecialCharList.Add('\u03c1', "^fr");
            SpecialCharList.Add('\u03c3', "^fs");
            SpecialCharList.Add('\u03c4', "^ft");
            SpecialCharList.Add('\u03c5', "^fu");
            SpecialCharList.Add('\u03c6', "^ff");
            SpecialCharList.Add('\u03c7', "^fc");
            SpecialCharList.Add('\u03c8', "^fv");
            SpecialCharList.Add('\u03c9', "^fo");

            SpecialCharList.Add('\u00c5', "^f\"");
            SpecialCharList.Add('\u00b0', "^f'");//Degree
            SpecialCharList.Add('\u2022', "^f0");
            SpecialCharList.Add('\u2265', "^f>");
            SpecialCharList.Add('\u2264', "^f<");
            SpecialCharList.Add('\u221e', "^f^finf");
            SpecialCharList.Add('\u2260', "^f?");
            SpecialCharList.Add('\u003d', "=");
            SpecialCharList.Add('\u00ab', "^f^fdar");
            SpecialCharList.Add('\u00ac', "^f^frar");
            SpecialCharList.Add('\u00ae', "^f_");
            SpecialCharList.Add('\u00ba', "^f3");
            SpecialCharList.Add('\u00db', "^f^fdar");
            SpecialCharList.Add('\u00d6', "^f^fsqr");
            SpecialCharList.Add('\u00b1', "^f+");

            //Temperory List for SubScript, Superscript and Bold - 24th March 2014
            SpecialCharList.Add('\u0060', "^v");//Subscript '`'
            SpecialCharList.Add('\u007e', "^^");//Superscript '~'           
            SpecialCharList.Add('\u007c', "^b");//Bold '|'          
            SpecialCharList.Add('\u0024', "^i");//Italic '$'
        }

        //static System.Windows.Forms.RichTextBox rtb;
        static HtmlRichText.HtmlRichTextBox rtb;
        public static string ConvertSpecialChars(string source)
        {
            string strTarget = "";
            try
            {
                rtb = new HtmlRichText.HtmlRichTextBox();
                try
                {
                    rtb.Rtf = source;                   
                  
                }
                catch
                {
                    rtb.Text = source;
                }

                string strTemp = "";

                if (rtb.Text != null)
                {
                    for (int i = 0; i < rtb.Text.Length; i++)
                    {
                        rtb.SelectionStart = i;
                        rtb.SelectionLength = 1;
                                                
                        string sHtml = Html_RtfConversions.Instance.GetHTMLFromRTFString(rtb.SelectedRtf);

                        if (rtb.SelectionFont.Bold)
                        {
                            //strTarget = strTarget + "^b" + rtb.SelectedText;  
                            strTarget = strTarget + "^b";
                        }
                        if (rtb.SelectionFont.Italic)
                        {
                            //strTarget = strTarget + "^i" + rtb.SelectedText; 
                            strTarget = strTarget + "^i";
                        }
                        //if (rtb.SelectionCharOffset == 5)//Superscript 
                        if (rtb.SelectionCharOffset == 4)//Superscript
                        {
                            //strTarget = strTarget + "^^" + rtb.SelectedText; 
                            strTarget = strTarget + "^^";
                        }
                        //if (rtb.SelectionCharOffset == -5)//Superscript
                        if (rtb.SelectionCharOffset == -4)//Subscript
                        {
                            //strTarget = strTarget + "^v" + rtb.SelectedText;
                            strTarget = strTarget + "^v";
                        }

                        strTemp = "";
                        if (SpecialCharList.Keys.Contains(rtb.SelectedText[0]))
                        {
                            foreach (KeyValuePair<char, string> kvSplChar in SpecialCharList)
                            {
                                if (rtb.SelectedText[0].ToString() == kvSplChar.Key.ToString())
                                {
                                    strTemp = rtb.SelectedText.Replace(kvSplChar.Key.ToString(), kvSplChar.Value);
                                    break;
                                }
                            }
                        }
                        else
                        {
                            strTemp = rtb.SelectedText;
                        }

                        if (!string.IsNullOrEmpty(strTemp))
                        {
                            strTarget = strTarget + strTemp;
                        }
                    }
                }

                //\n\n^b\n^b\n^b\n^b\n
                strTarget = strTarget.Replace("\n\n^b\n^b\n^b\n^b\n", "");
                return strTarget;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strTarget;
        }

        public static string RemoveInVisibleCharsDblSpaces(string inputstring)
        {
            string strInput = "";
            try
            {
                //Remove Zero width space (ASCII code - 8203) with none
                strInput = inputstring.Replace("​", "");

                //strInput = inputstring.Replace("", "");

                //Remove double spaces from string
                strInput = Regex.Replace(strInput, @" +", " ", RegexOptions.Multiline);                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strInput;
        }

        public static bool ValidatePageLabel(string pageLabel, ref string error)
        {
            bool blStatus = false;
            try
            {
                if (pageLabel.Trim() == "0")
                {
                    error = "Page label should not be 0";
                    return blStatus;
                }

                if (Regex.IsMatch(pageLabel, @"column", RegexOptions.IgnoreCase) && (Regex.IsMatch(pageLabel, @"page", RegexOptions.IgnoreCase)))
                {
                    error = "If both page label and column labels are present, in such cases prefer page label only.";
                    return blStatus;
                }
                if (Regex.IsMatch(pageLabel, @"'"))
                {
                    error = "Page label recorded like '3' , Please record it as \"3\"(without quotes).";
                    return blStatus;
                }
                if (Regex.IsMatch(pageLabel, @"^[-~]+|[-~]+$"))
                {
                    error = "Page label recorded like \"-3-\",Please record it as \"3\"(without quotes).";
                    return blStatus;
                }

                #region Code commented
                //if (Regex.IsMatch(pageLabel, @"^~'.*~$"))
                //{
                //    error = "Page label recorded like \'~3~\',Please record it as \"3\"(without quotes).";
                //    return blStatus;
                //}
                //if (Regex.IsMatch(pageLabel, @"[Ee][Mm][Pp][Tt][Yy]"))
                //{
                //    error = "Page label recorded like \'Empty\' record it as \"Blank\" (without quotes).";
                //    return blStatus;
                //}
                //if (Regex.IsMatch(pageLabel, @"[Pp][Aa][Gg][Ee].*\d[-]\d.*"))
                //{
                //    error = "Page label recorded like \'Page 3-2\',Please record it as \"2\" (without quotes).";
                //    return blStatus;
                //}
                //if (Regex.IsMatch(pageLabel, @"[Pp][Aa][Gg][Ee].*"))
                //{
                //    error = "Page label recorded like \'Page 3\',Please record it as \"3\" (without quotes).";
                //    return blStatus;
                //}
                //if (Regex.IsMatch(pageLabel, @".*-$"))
                //{
                //    error = "Page label recorded like \'S-3-\',Please record it as \"S-3\" (without quotes)";
                //    return blStatus;
                //}
                //if (Regex.IsMatch(pageLabel, @"^-.*"))
                //{
                //    error = "Page label recorded like \'-S3- of 33\' ,Please record it as \"S3\" (without quotes)";
                //    return blStatus;
                //} 
                #endregion

                if (Regex.IsMatch(pageLabel, @" of ", RegexOptions.IgnoreCase))
                {
                    error = "Page label recorded like \'S4 of S34\' ,Please record it as \"S4\" (without quotes).";
                    return blStatus;
                }
                if (Regex.IsMatch(pageLabel, @"\\/"))
                {
                    error = "Page label recorded like '4/16' ,Please record it as \"4\" (without quotes). ";
                    return blStatus;
                }
                if (Regex.IsMatch(pageLabel, @"[ \t]"))
                {
                    error = "Space not allowed in Page label";
                    return blStatus;
                }

                blStatus = true;
                return blStatus;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        public static bool ValidateUnicodeCharactersInString(string inputstring)
        {
            bool blStatus = false;
            try
            {
                //Check Latin characters in String
                if (CheckLatinCharacterssInString(inputstring))
                {
                    blStatus = true;
                }
                else
                {
                    String originalString = inputstring;
                    Byte[] bytes = Encoding.UTF32.GetBytes(originalString);
                    uint codepoint = 0;

                    //U+0000 – U+0008(decimal is 0000-0008) (Hex is &#x0000; - &#x0008;) - Disallowed by Xml - Characters found: 9
                    //U+000B – U+000C(decimal is 0011-0012) (Hex is &#x000B; - &#x000C;) - Disallowed by Xml - Characters found: 2
                    //U+000E – U+001F (decimal is 0014-0031) (Hex is &#x000E; - &#x001F;) - Disallowed by Xml - Characters found: 18
                    //U+D800 - U+DBFF decimal range is 55296-56319 - Disallowed by Xml - Characters found: 1024
                    //U+DC00 - U+DFFF (decimal is 56320-57343)(Hex is &#xDC00; - &#xDFFF;)-Disallowed by Xml - Characters found: 1024

                    //U+E000 - U+F8FF (decimal is - 57344-63743) (Hex is - &#xE000; - &#xF8FF;) disallowed by CAS (Unicode Private Use Area)- Characters found: 6400
                    //U+007F - U+009F (decimal is 0127-0159) (Hex is &#x007F; - &#x009F;) - disallowed by CAS (control codes) -Characters found: 33
                    //U+10000 - U+10FFFF (decimal is 65536-0) (Hex is &#x10000; - ;) - disallowed by CAS (outside of Unicode Basic Multilingual Plane) -Characters found: -

                    //New validations on 11th Aug 2014
                    //U+2019 = '’' - Copy paste problem of ' - 8217
                    //U+2013 = '–' - Copy paste problem of - - 8211
                    //U+FB01 = 'ﬁ' - Copy paste problem of 'fi' - 64257, 64258
                    //U+2032 = '′'(Prime) - Copy paste problem of ' - 8242
                    //U+0080 - U+00FF  - (decimal is 128 - 255) Latin-1 Supplement 0080—00FF - Characters found 128

                    //U+0100 - U+017F - (Decimal 256 - 383) Latin Extended-A - 128 code points
                    //U+0180 - U+024F - (decimal is 384 - 591) Latin Extended-B - 208 code points
                    //U+0250 - U+02AF - (decimal is 592 - 687) IPA Extensions - 96 code points

                    //U+2C60 - U+2C7F - (decimal is 11360 - 11391) Latin Extended-C - 32 code points
                    //U+A720 - U+A7FF - (decimal is 42784 - 43007) Latin Extended-D - 224 code points
                    //U+AB30 - U+AB6F - (decimal is 43824 - 43887) Latin Extended-E - 64 code points

                    //U+1E00 - U+1EFF - (decimal is 7680 - 7935) Latin Extended Additional - 256 code points
                    //U+2150 - U+218F - (decimal is 8528 - 8591) Number Forms - 64 code points
                    //U+FB00 - U+FB4F - (decimal is 64256 - 64335) Alphabetic Presentation Forms - 80 code points
                    //U+0000 - U+007F - (decimal is 0 - 127) C0 Controls and Basic Latin - 128 code points


                    for (int idx = 0; idx < bytes.Length; idx += 4)
                    {
                        codepoint = 0;
                        codepoint = BitConverter.ToUInt32(bytes, idx);

                        char c = System.BitConverter.ToChar(bytes, idx);

                        //Not Allowed Unicodes
                        if ((codepoint >= 0000 && codepoint <= 0008) || (codepoint >= 0011 && codepoint <= 0012) || (codepoint >= 0014 && codepoint <= 0031) ||
                            (codepoint >= 55296 && codepoint <= 56319) || (codepoint >= 56320 && codepoint <= 57343) || (codepoint >= 57344 && codepoint <= 63743) ||
                            (codepoint >= 0127 && codepoint <= 0159) || (codepoint >= 65536) || ((codepoint >= 0128 && codepoint <= 0255) && codepoint != 176 && codepoint != 197) ||
                             codepoint == 8217 || codepoint == 8211 || codepoint == 64257 || codepoint == 8242)
                        {
                            blStatus = true;
                        }

                        //Allowed Unicodes
                        //U+F900 – U+FFFD (decimal is 65536-0) (Hex is &#xF900; - &#xFFFD;) - Allowed - Characters found: 1603
                        //U+00A0 – U+D7FF (Decimal is 0160 - 55291) (Hex is &#x00A0; - &#xD7FB;) - Allowed
                        //U+2282 - (Subset of) Decimal - 8834 & Hex - 2282 - Allowed - New code as on 24th Jan 2013

                        //if ((codepoint >= 63744 && codepoint <= 65533) || (codepoint >= 0160 && codepoint <= 55291) || codepoint == 8834)
                        //{
                        //    char c = System.BitConverter.ToChar(bytes, idx);
                        //    //sbAllCode.AppendFormat("Allowed : " + c + " - Replacement:  " + "&#x{0:X4}; ", codepoint);
                        //    blStatus = true;

                        //    DataRow dtRow = AllowedData.NewRow();
                        //    dtRow["TAN"] = tan;
                        //    dtRow["RxnNum"] = rxnnum;
                        //    dtRow["RxnSeq"] = rxnseq;
                        //    dtRow["Tag Name"] = tag;
                        //    dtRow["Allowed Char"] = c;
                        //    dtRow["Replacement"] = string.Format("&#x{0:X4};", codepoint);
                        //    AllowedData.Rows.Add(dtRow);
                        //}
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private static bool CheckLatinCharacterssInString(string inputstring)
        {
            bool blStatus = false;
            try
            {
                //U+0000 - U+007F - (decimal is 0 - 127) C0 Controls and Basic Latin - 128 code points
                //U+0080 - U+00FF  - (decimal is 128 - 255) Latin-1 Supplement 0080—00FF - Characters found 128
                //U+0100 - U+017F - (Decimal 256 - 383) Latin Extended-A - 128 code points
                //U+0180 - U+024F - (decimal is 384 - 591) Latin Extended-B - 208 code points
                //U+0250 - U+02AF - (decimal is 592 - 687) IPA Extensions - 96 code points
                //U+02B0 - U+02FF (decimal is 688 - 767) Spacing Modifier Letters - 80 code points

                //U+1D00 - U+1D7F - (decinal is 7424 - 7551) Phonetic Extensions - 128 code points
                //U+1D80 - U+1DBF - (decimal is 7552 - 7615)-Phonetic Extensions Supplement 64 code points
                //U+1E00 - U+1EFF - (decimal is 7680 - 7935) Latin Extended Additional - 256 code points
                //U+2070 - U+209F -(decimal is 8304 - 8351) Unicode subscripts and superscripts

                //U+2100 - U+214F - (decimal is 8448 - 8527) Letterlike Symbols - 80 code points
                //U+2150 - U+218F - (decimal is 8528 - 8591) Number Forms - 64 code points
                //U+2C60 - U+2C7F - (decimal is 11360 - 11391) Latin Extended-C - 32 code points
                //U+A720 - U+A7FF - (decimal is 42784 - 43007) Latin Extended-D - 224 code points
                //U+AB30 - U+AB6F - (decimal is 43824 - 43887) Latin Extended-E - 64 code points      
                //U+FB00 - U+FB4F - (decimal is 64256 - 64335) Alphabetic Presentation Forms - 80 code points
                //U+FF00 – U+FFEF - (decimal is 65280 - 65519) Halfwidth and fullwidth forms 

                String originalString = inputstring;
                Byte[] bytes = Encoding.UTF32.GetBytes(originalString);
                uint codepoint = 0;

                for (int idx = 0; idx < bytes.Length; idx += 4)
                {
                    codepoint = 0;
                    codepoint = BitConverter.ToUInt32(bytes, idx);

                    char c = System.BitConverter.ToChar(bytes, idx);

                    //Not Allowed Unicodes
                    if ((codepoint >= 128 && codepoint <= 767) || (codepoint >= 7424 && codepoint <= 7615) || (codepoint >= 7680 && codepoint <= 7935) ||
                        (codepoint >= 8304 && codepoint <= 8351) || (codepoint >= 8448 && codepoint <= 8591) || (codepoint >= 11360 && codepoint <= 11391) ||
                        (codepoint >= 42784 && codepoint <= 43007) || (codepoint >= 43824 && codepoint <= 43887) || (codepoint >= 64256 && codepoint <= 64335) ||
                        (codepoint >= 65280 && codepoint <= 65519))
                    {
                        blStatus = true;
                    }                   
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        public bool IsChinese(string text)
        {
            return text.Any(c => c >= 0x20000 && c <= 0xFA2D);
        }

        public static bool ValidateUnicodeCharactersInString(string inputstring, out string errMsg)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                String originalString = inputstring;
                Byte[] bytes = Encoding.UTF32.GetBytes(originalString);
                uint codepoint = 0;

                //U+0000 – U+0008(decimal is 0000-0008) (Hex is &#x0000; - &#x0008;) - Disallowed by Xml - Characters found: 9
                //U+000B – U+000C(decimal is 0011-0012) (Hex is &#x000B; - &#x000C;) - Disallowed by Xml - Characters found: 2
                //U+000E – U+001F (decimal is 0014-0031) (Hex is &#x000E; - &#x001F;) - Disallowed by Xml - Characters found: 18
                //U+D800 - U+DBFF decimal range is 55296-56319 - Disallowed by Xml - Characters found: 1024
                //U+DC00 - U+DFFF (decimal is 56320-57343)(Hex is &#xDC00; - &#xDFFF;)-Disallowed by Xml - Characters found: 1024

                //U+E000 - U+F8FF (decimal is - 57344-63743) (Hex is - &#xE000; - &#xF8FF;) disallowed by CAS (Unicode Private Use Area)- Characters found: 6400
                //U+007F - U+009F (decimal is 0127-0159) (Hex is &#x007F; - &#x009F;) - disallowed by CAS (control codes) -Characters found: 33
                //U+10000 to U+10FFFF (decimal is 65536-0) (Hex is &#x10000; - ;) - disallowed by CAS (outside of Unicode Basic Multilingual Plane) -Characters found: -

                //New validations on 11th Aug 2014
                //U+2019 = '’' - Copy paste problem of ' - 8217
                //U+2013 = '–' - Copy paste problem of - - 8211
                //U+FB01 = 'ﬁ' - Copy paste problem of 'fi' - 64257
                //U+2032 = '′'(Prime) - Copy paste problem of ' - 8242
                //U+0080 - U+00FF  - (decimal is 128 - 255) Latin-1 Supplement 0080—00FF - Characters found 128
                //U+2103 - ℃ - 8451 - 
                //176 is Degree - Allowed
                //197 is Armstrong - Allowed
                //183 is Middot - Allowed - 23Jan 2015
                //177 is +/- Allowed - 12th March 2015
                //126 is Approximate - 12th March 2015

                for (int idx = 0; idx < bytes.Length; idx += 4)
                {
                    codepoint = 0;
                    codepoint = BitConverter.ToUInt32(bytes, idx);

                    //Not Allowed Unicodes
                    if ((codepoint >= 0000 && codepoint <= 0008) || (codepoint >= 0011 && codepoint <= 0012) || (codepoint >= 0014 && codepoint <= 0031) ||
                        (codepoint >= 55296 && codepoint <= 56319) || (codepoint >= 56320 && codepoint <= 57343) || (codepoint >= 57344 && codepoint <= 63743) ||
                        (codepoint >= 0127 && codepoint <= 0159) || (codepoint >= 65536) || ((codepoint >= 0128 && codepoint <= 0255) && codepoint != 176 && codepoint != 197 && codepoint != 183 && codepoint != 177 && codepoint != 126) ||
                         (codepoint == 8217) || (codepoint == 8211) || (codepoint == 64257) || (codepoint == 8242) || (codepoint == 8451))
                    {
                        char c = System.BitConverter.ToChar(bytes, idx);
                        blStatus = true;
                        strErrMsg = string.IsNullOrEmpty(strErrMsg.Trim()) ? c.ToString() : strErrMsg.Trim() + ", " + c.ToString();
                    }

                    //Narratives Allowed range
                    //U+0009
                    //U+000A
                    //U+000D
                    //U+0020-U+007E
                    //U+00A0-U+2102
                    //U+2104-U+2108
                    //U+210A-U+D7FF
                    //U+F900-U+FFFD

                    //Allowed Unicodes
                    //U+F900 – U+FFFD (decimal is 65536-0) (Hex is &#xF900; - &#xFFFD;) - Allowed - Characters found: 1603
                    //U+00A0 – U+D7FF (Decimal is 0160 - 55291) (Hex is &#x00A0; - &#xD7FB;) - Allowed
                    //U+2282 - (Subset of) Decimal - 8834 & Hex - 2282 - Allowed - New code as on 24th Jan 2013
                    
                    //if ((codepoint >= 63744 && codepoint <= 65533) || (codepoint >= 0160 && codepoint <= 55291) || codepoint == 8834)
                    //{
                    //    char c = System.BitConverter.ToChar(bytes, idx);
                    //    //sbAllCode.AppendFormat("Allowed : " + c + " - Replacement:  " + "&#x{0:X4}; ", codepoint);
                    //    blStatus = true;

                    //    DataRow dtRow = AllowedData.NewRow();
                    //    dtRow["TAN"] = tan;
                    //    dtRow["RxnNum"] = rxnnum;
                    //    dtRow["RxnSeq"] = rxnseq;
                    //    dtRow["Tag Name"] = tag;
                    //    dtRow["Allowed Char"] = c;
                    //    dtRow["Replacement"] = string.Format("&#x{0:X4};", codepoint);
                    //    AllowedData.Rows.Add(dtRow);
                    //}
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsg = strErrMsg;
            return blStatus;
        }
    }
}
