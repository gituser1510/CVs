﻿#region Import Assemblies

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using chemaxon;
using chemaxon.reaction;
using java.io;
using chemaxon.struc;
using chemaxon.util;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;
using chemaxon.formats;
using System.Collections;
using System.Data;
using IndxReactNarr.Generic;
using chemaxon.license;

#endregion

namespace IndxReactNarr
{
    public static class ChemistryOperations
    {
        public static string GetStandardizedMolecule(string strMolFile, out bool isChiral_Out)
        {
            string strStandMol = "";
            bool blIsChiral = false;
            try
            {
                chemaxon.util.MolHandler molHandler = new MolHandler(strMolFile);
                Molecule molObj = molHandler.getMolecule();
                Molecule molObj_Stand = StandardizeMolecule(molObj, out blIsChiral);
                strStandMol = molObj_Stand.toFormat("mol");

                isChiral_Out = blIsChiral;
                return strStandMol;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }

            isChiral_Out = blIsChiral;
            return strStandMol;
        }

        private static Molecule StandardizeMolecule(Molecule mol, out bool ischiral_out)
        {
            Molecule molChem = null;
            bool blIsChiral = false;
            try
            {
                Standardizer molSdz = new Standardizer("absolutestereo:set");
                molChem = molSdz.standardize(mol);

                blIsChiral = molChem.isAbsStereo();

                #region Code Commented
                //string strDirPath = AppDomain.CurrentDomain.BaseDirectory.ToString();
                //string strXmlPath = strDirPath + "chiral.xml";
                //StandardizerConfiguration sconfing = new StandardizerConfiguration();
                //sconfing.read(strXmlPath);
                //Standardizer sdz = sconfing.getStandardizer();
                //molChem = sdz.standardize(mol);                               
                //Standardizer sdz = new Standardizer(new File(strXmlPath)); 
                #endregion

                ischiral_out = blIsChiral;
                return molChem;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            ischiral_out = blIsChiral;
            return molChem;
        }

        public static bool GetStructureFromCompoundName(string strCompName, out string molstring_out,out bool ischiral_out, out string errmessage_out)
        {
            bool blStatus = false;
            string strMolString = "";
            string strErrMessage = "";
            bool blIsChiral = false;
            try
            {
                string strDirPath = AppDomain.CurrentDomain.BaseDirectory.ToString();
                string strExePath = strDirPath + "nam2mol.exe";

                string strInputFileName = "CompName.txt";
                string strOutputFileName = "CompStructure.mol";

                if (System.IO.File.Exists(strDirPath + strInputFileName))
                {
                    System.IO.File.Delete(strDirPath + strInputFileName);
                }
                System.IO.StreamWriter sWriter = new System.IO.StreamWriter(strDirPath + strInputFileName);
                sWriter.WriteLine(strCompName.Trim());
                sWriter.Close();
                sWriter.Dispose();

                if (System.IO.File.Exists(strDirPath + strOutputFileName))
                {
                    System.IO.File.Delete(strDirPath + strOutputFileName);
                }

                //ProcessStartInfo class
                ProcessStartInfo startInfo = new ProcessStartInfo();
                startInfo.CreateNoWindow = true;
                startInfo.UseShellExecute = false;
                startInfo.RedirectStandardError = true;               
                startInfo.FileName = @"" + strExePath + "";
                startInfo.WindowStyle = ProcessWindowStyle.Hidden;
                startInfo.Arguments = @"-in """ + strDirPath + strInputFileName + @"""  -out """ + strDirPath + strOutputFileName + @""" -depict true";
                //startInfo.Arguments = @"-in """ + strDirPath + strInputFileName + @""" -depict true";

                string strErrMsg = "";              
                try
                {
                    using (Process exeProcess = Process.Start(startInfo))
                    {
                        strErrMsg = exeProcess.StandardError.ReadToEnd();                        
                        exeProcess.WaitForExit();
                    }
                }
                catch (Exception ex)
                {
                    ErrorHandling.WriteErrorLog(ex.ToString());
                }

                //Read Output molecule from outputfile
                StreamReader sReader = new StreamReader(strDirPath + strOutputFileName);
                string newMolfileString;
                newMolfileString = sReader.ReadToEnd();

                //Standardize the molecule
                string strStandMol = GetStandardizedMolecule(newMolfileString, out blIsChiral);
                 
                sReader.Close();
                sReader.Dispose();

                if (newMolfileString != "")
                {
                    strMolString = strStandMol;
                    molstring_out = strMolString;
                    errmessage_out = "";
                    ischiral_out = blIsChiral;
                    blStatus = true;
                    return blStatus;
                }
                else
                {
                    strErrMessage = strErrMsg;
                    molstring_out = "";
                    ischiral_out = blIsChiral;
                    errmessage_out = strErrMessage;
                    blStatus = false;
                    return blStatus;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            molstring_out = "";
            ischiral_out = blIsChiral;
            errmessage_out = strErrMessage;
            return blStatus;
        }

        public static string GetMoleculeWeightAndMolFormula(string molstring, out string molformula_out)
        {
            string strMolWeight = "";
            string strMolFormula = "";
            try
            {
                MolHandler mHandler = new MolHandler(molstring);
                float fltMolWeight = mHandler.calcMolWeight();

                strMolFormula = mHandler.calcMolFormula();
                strMolWeight = fltMolWeight.ToString();

                molformula_out = strMolFormula;
                return strMolWeight;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            molformula_out = strMolFormula;
            return strMolWeight;
        }

        public static bool GetIUPACNameFromStructure(string molfilestring, out string iupacname_out, out string errmessage_out)
        {
            bool blStatus = false;
            string strIUPACName = "";
            string strErrMessage = "";
            try
            {
                string strDirPath = AppDomain.CurrentDomain.BaseDirectory.ToString();
                string strExePath = strDirPath + "mol2nam.exe";

                string strInputFileName = "MolFile.mol";
                //string strOutputFileName = "MolName.txt";

                if (System.IO.File.Exists(strDirPath + strInputFileName))
                {
                    System.IO.File.Delete(strDirPath + strInputFileName);
                }
                System.IO.StreamWriter sWriter = new System.IO.StreamWriter(strDirPath + strInputFileName);                
                sWriter.WriteLine(molfilestring);
                sWriter.Close();
                sWriter.Dispose();

                //if (System.IO.File.Exists(strDirPath + strOutputFileName))
                //{
                //    System.IO.File.Delete(strDirPath + strOutputFileName);
                //}

                //ProcessStartInfo class
                ProcessStartInfo startInfo = new ProcessStartInfo();
                startInfo.CreateNoWindow = true;
                startInfo.UseShellExecute = false;
                startInfo.RedirectStandardError = true;
                startInfo.RedirectStandardOutput = true;
                startInfo.FileName = @"" + strExePath + "";
                startInfo.WindowStyle = ProcessWindowStyle.Hidden;
                //startInfo.Arguments = @"-in """ + strDirPath + strInputFileName + @"""  -out """ + strDirPath + strOutputFileName + @""" -capitalize true";
                startInfo.Arguments = @"-in """ + @"" + strDirPath + strInputFileName + @""" -nobanner";

                string strErrMsg = "";
                string strIUPACName_Out = "";

                try
                {
                    using (Process exeProcess = Process.Start(startInfo))
                    {
                        strIUPACName_Out = exeProcess.StandardOutput.ReadToEnd();                        
                        strErrMsg = exeProcess.StandardError.ReadToEnd();
                        exeProcess.WaitForExit();
                    }
                }
                catch (Exception ex)
                {
                    ErrorHandling.WriteErrorLog(ex.ToString());
                }               

                //StreamReader sr = new StreamReader(strDirPath + strOutputFileName);
                //string IUPACName = "";
                //IUPACName = sr.ReadToEnd();
                //sr.Close();
                //sr.Dispose();

                if (strIUPACName_Out != "")
                {
                    strIUPACName = strIUPACName_Out;
                    strErrMessage = "";
                    blStatus = true;
                }
                else
                {
                    strIUPACName = "";
                    strErrMessage = strErrMsg;
                    blStatus = false;
                }

                iupacname_out = strIUPACName;
                errmessage_out = strErrMessage;
                return blStatus;

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }

            iupacname_out = strIUPACName;
            errmessage_out = strErrMessage;
            return blStatus;
        }

        public static int GetMoleculeCountFromFile(string filename)
        {
            try
            {
                string text = "";

                FileStream FS = new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.Read);
                StreamReader SR = new StreamReader(FS);
                text = SR.ReadToEnd();
               
                SR.Close();
                SR.Dispose();
                
                FS.Close();
                FS.Dispose();
                Regex RE = new Regex("^\\$\\$\\$\\$", RegexOptions.Multiline);
                MatchCollection theMatches = RE.Matches(text);
                
                return (theMatches.Count);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return 0;
        }

        public static bool CheckForV3000Format(string molfilestring)
        {
            bool blIsV3000 = false;
            try
            {
                if (molfilestring != "")
                {                                 
                    int v3000 = molfilestring.IndexOf("V3000");
                    if (v3000 == -1)
                    {
                        blIsV3000 = false;
                    }
                    else
                    {
                        blIsV3000 = true;
                    }                    
                   
                    #region Code Commented 
                    //MolHandler mHandler = new MolHandler(molfilestring);
                    //int atomCnt = mHandler.getAtomCount();
                    //if (atomCnt > 999)
                    //{
                    //    blIsV3000 = true;
                    //}
                    //else
                    //{
                    //    blIsV3000 = false;
                    //}
                    #endregion
                }
                return blIsV3000;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blIsV3000;
        }

        public static bool CheckForDuplicateStructure(string filename, string qrymolfile,int recindex,out Molecule mol_out)
        {
            bool blStatus = false;
            try
            {
                bool blIsChiral = false;

                MolHandler mHandler = new MolHandler(qrymolfile);
                Molecule qryMol = mHandler.getMolecule();
                qryMol = StandardizeMolecule(qryMol, out blIsChiral);

                string strqryMolInchi = qryMol.toFormat("inchi:key");
                strqryMolInchi = GetInchiKeyFromInchiString(strqryMolInchi);

                //Specify input file to MolInputStream object
                MolInputStream molInStream = new MolInputStream(new FileInputStream(filename));
                MolImporter molImp = new MolImporter(molInStream);
                Molecule objMol = new Molecule();
                
                blIsChiral = false;
                string strInchiKey = "";
                int intRecIndx = 0;

                Molecule molObj_Stand = null;
                while (molImp.read(objMol))
                {
                    molObj_Stand = StandardizeMolecule(objMol, out blIsChiral);

                    strInchiKey = objMol.toFormat("inchi:key");
                    strInchiKey = GetInchiKeyFromInchiString(strInchiKey);

                    intRecIndx++;

                    if ((strInchiKey == strqryMolInchi) && (intRecIndx != recindex))
                    {
                        blStatus = true;
                        mol_out = objMol;
                        return blStatus;
                    }
                }

                molImp.close();
                molInStream.close();

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            mol_out = null;
            return blStatus;
        }
                
        public static bool DeleteAllDuplicateStructures(string filename,out int totalreccnt, out int dupreccnt)
        {
            bool blStatus = false;
            int intDupRecCnt = 0;
            int intTotalRecCnt = 0;
            try
            {              
                MolInputStream molInStream = new MolInputStream(new FileInputStream(filename));
                MolImporter molImp = new MolImporter(molInStream);
                Molecule objMol = new Molecule();

                DataOutputStream dOutStream = new DataOutputStream(new FileOutputStream(filename));
                MolExporter molExpt = new MolExporter(dOutStream, "sdf");

                bool blIsChiral = false;
                string strInchiKey = "";

                ArrayList molInchiList = new ArrayList();
                               
                while (molImp.read(objMol))
                {
                    objMol = StandardizeMolecule(objMol, out blIsChiral);

                    strInchiKey = objMol.toFormat("inchi:key");
                    strInchiKey = GetInchiKeyFromInchiString(strInchiKey);

                    if (!molInchiList.Contains(strInchiKey))
                    {
                        molInchiList.Add(strInchiKey);
                        molExpt.write(objMol);
                    }
                    else
                    {
                        intDupRecCnt++;
                    }
                    intTotalRecCnt++;
                }
                //Close all the import & export objects
                molImp.close();               
                molInStream.close();
                dOutStream.close();
                molExpt.close();

                blStatus = true;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            totalreccnt = intTotalRecCnt;
            dupreccnt = intDupRecCnt;
            return blStatus;
        }

        public static int GetDuplicateRecordsCount(string filename, out int totalreccnt)
        {            
            int intDupRecCnt = 0;
            int intTotalRecCnt = 0;

            try
            {
                MolInputStream molInStream = new MolInputStream(new FileInputStream(filename));
                MolImporter molImp = new MolImporter(molInStream);
                Molecule objMol = new Molecule();

                bool blIsChiral = false;
                string strInchiKey = "";

                ArrayList molInchiList = new ArrayList();

                while (molImp.read(objMol))
                {
                    objMol = StandardizeMolecule(objMol, out blIsChiral);

                    strInchiKey = objMol.toFormat("inchi:key");
                    strInchiKey = GetInchiKeyFromInchiString(strInchiKey);

                    if (!molInchiList.Contains(strInchiKey))
                    {
                        molInchiList.Add(strInchiKey);                   
                    }
                    else
                    {
                        intDupRecCnt++;
                    }
                    intTotalRecCnt++;
                }

                molImp.close();
                molInStream.close();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            totalreccnt = intTotalRecCnt;
            return intDupRecCnt;
        }

        public static string GetStructureInchiKey(string _molfilestring)
        {
            string strInchiKey = "Inchi Not generated";
            try
            {
                MolHandler mHandler = new MolHandler(_molfilestring);
                Molecule mol = mHandler.getMolecule();
                try
                {
                    strInchiKey = mol.toFormat("inchi:key");                    
                }
                catch //Exception is inchi not generated
                {
                    // if inchi not generated
                    SetMolAbsStereo_Inchi_NotGenerated(ref mol);

                    strInchiKey = mol.toFormat("inchi:key");                    
                }
                if (strInchiKey != "")
                {
                    strInchiKey = GetInchiKeyFromInchiString(strInchiKey);
                }
                
                return strInchiKey;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strInchiKey; 
        }

        private static void SetMolAbsStereo_Inchi_NotGenerated(ref Molecule _molobj)
        {
            try
            {
                int atno = 0;
                MolAtom ma = null;
                for (int i = 0; i < (_molobj.getAtomCount() - 1); i++)
                {
                    atno = _molobj.getAtom(i).getAtno();
                    if (atno > 109)
                    {
                        ma = _molobj.getAtom(i);
                        ma.setAtno(6);
                    }
                }
                bool flag1 = _molobj.ungroupSgroups();
                bool flag2 = _molobj.hydrogenize(false);
                if (_molobj.isAbsStereo())
                {
                    _molobj.setAbsStereo(true);
                }
                _molobj.aromatize(false);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public static double GetStructureMolWeight_MolFormula(string _molfilestring,out string _molformula)
        {
            double dblMolWeight = 0.0;
            string strMolFormula = "";
            try
            {
                MolHandler mHandler = new MolHandler(_molfilestring);
                dblMolWeight = mHandler.calcMolWeight();

                strMolFormula = mHandler.calcMolFormula();

                _molformula = strMolFormula;
                return dblMolWeight;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _molformula = strMolFormula;
            return dblMolWeight;
        }

        public static bool CheckForDuplicateStructureInTANSeries8000Data(string srcmolfile, DataTable tanSer8000data,string _ser8000val, out string errmsg_out)
        {           
            try
            {
                if (tanSer8000data != null)
                {
                    if (tanSer8000data.Rows.Count > 0 && !string.IsNullOrEmpty(srcmolfile.Trim()))
                    {
                        bool blIsChiral = false;
                        string InchiKey_Qry = "";
                        string InchiKey_Trgt = "";

                        MolHandler mHandler = new MolHandler(srcmolfile);
                        Molecule qryMol = mHandler.getMolecule();
                        StandardizeMolecule(qryMol, out blIsChiral);

                        InchiKey_Qry = qryMol.toFormat("inchi:key");
                        InchiKey_Qry = GetInchiKeyFromInchiString(InchiKey_Qry);

                        Molecule objTrgtMol = null;
                        MolHandler mHandler_Trgt = null;
                        Molecule objMol = null;
                        for (int i = 0; i < tanSer8000data.Rows.Count; i++)
                        {
                            if (tanSer8000data.Rows[i]["SUBST_MOLECULE"].ToString() != "")
                            {
                                try
                                {
                                    mHandler_Trgt = null;
                                    objMol = null;

                                    mHandler_Trgt = new MolHandler(tanSer8000data.Rows[i]["SUBST_MOLECULE"].ToString());
                                    objMol = mHandler_Trgt.getMolecule();

                                    objTrgtMol = StandardizeMolecule(objMol, out blIsChiral);

                                    InchiKey_Trgt = "";
                                    InchiKey_Trgt = objMol.toFormat("inchi:key");
                                    InchiKey_Trgt = GetInchiKeyFromInchiString(InchiKey_Trgt);

                                    if ((InchiKey_Qry == InchiKey_Trgt) && (tanSer8000data.Rows[i]["SERIES_8000"].ToString() != _ser8000val))
                                    {
                                        errmsg_out = "Duplicate structure. Structure matching with  " + tanSer8000data.Rows[i]["SERIES_8000"].ToString();
                                        return true;
                                    }
                                }
                                catch //Unknown strucutures will not generate Inchi
                                { 
                                
                                }
                            }
                        }                       
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = "";
            return false;
        }

        public static bool CheckDuplicateStructureOnInchiInOrgRefData(string structInchi, out string errmsg_out)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                List<string> lstSer9000Nums = null;
                List<string> lstSer8500Nums = null;

                if (!string.IsNullOrEmpty(structInchi))
                {
                    if (GlobalVariables.Ser9000OrgRefData != null)
                    {
                        //DataTable dup9000Data = GlobalVariables.Ser9000OrgRefData.AsEnumerable()
                        //                        .Where(r => r.Field<string>("INCHI_KEY") == structInchi)
                        //                        .CopyToDataTable();

                        //if (dup9000Data != null)
                        //{
                        //    if (dup9000Data.Rows.Count > 0)
                        //    {
                        //        blStatus = true;
                        //        strErrMsg = strErrMsg.Trim() + "\r\n" + "Duplicate structure. Matching with  " + dup9000Data.Rows[0]["NUM"].ToString() + " in Sereis 9000 OrgRef Master.";
                        //    }
                        //}

                        lstSer9000Nums = new List<string>();

                        var rows = from r in GlobalVariables.Ser9000OrgRefData.AsEnumerable()
                                   where r.Field<string>("INCHI_KEY") == structInchi
                                   select new
                                   {
                                       dupNum = r.Field<string>("NUM")                                      
                                   };
                        if (rows != null)
                        {
                            foreach (var r in rows)
                            {
                                if (!lstSer9000Nums.Contains(r.dupNum))
                                {
                                    lstSer9000Nums.Add(r.dupNum);

                                    blStatus = true;
                                    strErrMsg = strErrMsg.Trim() + "\r\n" + "Duplicate structure. Matching with  " + r.dupNum + " in Sereis 9000 OrgRef Master.";
                                }
                            }
                        }                        
                    }

                    if (GlobalVariables.Ser8500OrgrefData != null)
                    {
                        //DataTable dup8500Data = GlobalVariables.Ser8500OrgrefData.AsEnumerable()
                        //                        .Where(r => r.Field<string>("INCHI_KEY") == structInchi)
                        //                        .CopyToDataTable();

                        //if (dup8500Data != null)
                        //{
                        //    if (dup8500Data.Rows.Count > 0)
                        //    {
                        //        blStatus = true;
                        //        strErrMsg = strErrMsg.Trim() + "\r\n" + "Duplicate structure. Matching with  " + dup8500Data.Rows[0]["REG_NO"].ToString() + " in Series 8500 OrgRef Master.";
                        //    }
                        //}

                        lstSer8500Nums = new List<string>();

                        var rows = from r in GlobalVariables.Ser8500OrgrefData.AsEnumerable()
                                   where r.Field<string>("INCHI_KEY") == structInchi && r.Field<string>("INCHI_KEY") != ""
                                   select new
                                   {
                                       dupRegNo = r.Field<string>("REG_NO")
                                   };
                        if (rows != null)
                        {
                            foreach (var r in rows)
                            {
                                if (!lstSer8500Nums.Contains(r.dupRegNo))
                                {
                                    lstSer8500Nums.Add(r.dupRegNo);

                                    blStatus = true;
                                    strErrMsg = strErrMsg.Trim() + "\r\n" + "Duplicate structure. Matching with  " + r.dupRegNo + " in Series 8500 OrgRef Master.";
                                }
                            }
                        }  
                    }
                }

                lstSer8500Nums = null;
                lstSer9000Nums = null;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errmsg_out = strErrMsg.Trim();
            return blStatus;
        }

        public static string GetInchiKeyFromInchiString(string inchistring)
        {
            string strInchikey = "";
            try
            {
                if (inchistring.Trim() != "")
                {
                    string[] splitter = { "InChIKey=" };
                    string[] strInchiArr = inchistring.Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                    if (strInchiArr != null)
                    {
                        if (strInchiArr.Length == 2)
                        {
                            strInchikey = strInchiArr[1];
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strInchikey;
        }

        public static DataTable CreateTANDetailsTable()
        {
            DataTable dtStructData = new DataTable();
            try
            {
                dtStructData.Columns.Add("tan_dtl_id", typeof(Int32));
                dtStructData.Columns.Add("structure", typeof(object));
                dtStructData.Columns.Add("mol_weight", typeof(double));
                dtStructData.Columns.Add("mol_formula", typeof(string));
                dtStructData.Columns.Add("iupac_name", typeof(string));
                dtStructData.Columns.Add("page_number", typeof(int));
                dtStructData.Columns.Add("page_label", typeof(string));
                dtStructData.Columns.Add("example_number", typeof(string));
                dtStructData.Columns.Add("en_name", typeof(string));
                dtStructData.Columns.Add("table_number", typeof(string));
                dtStructData.Columns.Add("inchi_key", typeof(string));               

                return dtStructData;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtStructData;
        }

        public static bool SetChemaxonLicenseFilePath(string licFilePath)
        {
            bool blStatus = false;
            try
            {
                LicenseManager.setLicenseFile(licFilePath);
                return blStatus = true;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }        
    }
}
