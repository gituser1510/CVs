﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IndxReactNarr.Generic;
using System.Data;
using System.IO;
using PdfSharp.Pdf.IO;
using PdfSharp.Pdf.Annotations;
using System.Text.RegularExpressions;
using PdfSharp.Pdf;

namespace IndxReactNarr.Common
{
    public static class MarkUpPdfValidations
    {
        private static bool ValidateMarkup_ExcessPdfFiles(string markupPdfsPath, DataTable batchTANs, out string errMsgOut)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (!string.IsNullOrEmpty(markupPdfsPath) && batchTANs != null)
                {
                    //Get TANs list from table
                    List<string> lstTANs = batchTANs.Rows.Cast<DataRow>()
                                            .Select(row => row["tan"].ToString())
                                            .ToList();

                    List<string> lstPdfs = GetDistinctTANsFromFolder(markupPdfsPath);

                    if (lstTANs != null && lstPdfs != null)
                    {
                        if (lstTANs.Count > 0 || lstPdfs.Count > 0)
                        {
                            //No Markups pdfs list
                            var noMarkups = lstTANs.Except(lstPdfs);

                            //Excess Markup pdfs list
                            var excessPdfs = lstPdfs.Except(lstTANs);

                            string noMarkup = "";
                            string excessPdf = "";

                            if (noMarkups != null)
                            {
                                if (noMarkups.Count() > 0)
                                {
                                    blStatus = false;

                                    noMarkup = String.Join(", ", noMarkups.ToArray());
                                    strErrMsg = "No markup pdfs available for the below TANs:\r\n" + noMarkup.Trim();
                                }
                            }
                            if (excessPdfs != null)
                            {
                                if (excessPdfs.Count() > 0)
                                {
                                    blStatus = false;

                                    excessPdf = String.Join(", ", excessPdfs.ToArray());
                                    strErrMsg = strErrMsg.Trim() + "\r\n" + "Excess pdfs in the Markups path:\r\n" + excessPdf.Trim();
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsgOut = strErrMsg;
            return blStatus;
        }

        private static List<string> GetDistinctTANsFromFolder(string pdfFolderPath)
        {
            List<string> lstTANs = null;
            try
            {
                if (!string.IsNullOrEmpty(pdfFolderPath))
                {
                    DirectoryInfo dirInfo = new DirectoryInfo(pdfFolderPath);
                    FileInfo[] faFiles = dirInfo.GetFiles("*.pdf", SearchOption.TopDirectoryOnly);
                    if (faFiles != null)
                    {
                        lstTANs = new List<string>();
                        //Filename format is TAN_Markup_N.pdf
                        foreach (FileInfo f in faFiles)
                        {
                            string[] saFileNames = f.Name.Split(new char[] { '_' });
                            if (saFileNames != null)
                            {
                                if (saFileNames.Length > 0)
                                {
                                    if (!string.IsNullOrEmpty(saFileNames[0].Trim().Replace(".pdf", "")))
                                    {
                                        if (!lstTANs.Contains(saFileNames[0].Trim().Replace(".pdf", "")))
                                        {
                                            lstTANs.Add(saFileNames[0].Trim().Replace(".pdf", ""));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstTANs;
        }

        /// <summary>
        /// Compare Comments with Database Reaction table.
        /// </summary>
        /// <param name="dtRxnDb">Datatable of Comments</param>
        /// <param name="pdfPath">Pdf file path.</param>
        /// <param name="errMsg">Error message (if comments are not matched with existing Reaction num, Sequence Num. ) </param>
        /// <returns>True if matches, else false.</returns>
        public static bool ValidateMarkUpReactions(DataTable reactionTbl, string pdfPath, out string errMsg)
        {          
            try
            {
                DataTable dtRxnSeqComments = new DataTable();  
                dtRxnSeqComments.Columns.Add("rxn", typeof(Int32));
                dtRxnSeqComments.Columns.Add("seq", typeof(Int32));

                using (PdfDocument inputDoc = PdfReader.Open(pdfPath, PdfDocumentOpenMode.Import))
                {
                    //PdfDocument document = new PdfDocument();
                    PdfPage page = new PdfPage();

                    for (int i = 0; i < inputDoc.PageCount; i++)
                    {
                        page = inputDoc.Pages[i];
                        page = inputDoc.AddPage(page);

                        for (int p = 0; p < inputDoc.Pages[i].Annotations.Elements.Count; p++)
                        {
                            PdfAnnotation textAnnot = inputDoc.Pages[i].Annotations[p];

                            string content = textAnnot.Contents;
                            if (!String.IsNullOrEmpty(content))
                            {
                                Regex expression = new Regex(@"rxn (\d+)-(\d+)", RegexOptions.IgnoreCase);
                                var matches = expression.Match(content);
                                if (matches != null)
                                {
                                    dtRxnSeqComments.Rows.Add(matches.Groups[1].Value, matches.Groups[2].Value);
                                }
                            }
                        }
                    }
                    errMsg = null;
                    return Compare(reactionTbl, dtRxnSeqComments, ref errMsg);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsg = null;
            return false;
        }

        /// <summary>
        /// Comparing two datatables.
        /// </summary>
        /// <param name="dtRxnSeq">Datatable which is from reaction table from datatable.</param>
        /// <param name="dtRxnSeqComments">Datatable rxn,seq comments</param>
        /// <param name="errMsg">Error message (if comments are not matched with existing Reaction num, Sequence Num. ) </param>
        /// <returns>True if matches, else false.</returns>
        private static bool Compare(DataTable dtRxnSeq, DataTable dtRxnSeqComments, ref string errMsg)
        {
            bool blStatus = true;
            try
            {
                DataTable result = new DataTable();
                if (dtRxnSeq.Rows.Count != dtRxnSeqComments.Rows.Count)
                {
                    if (dtRxnSeq.Rows.Count > dtRxnSeqComments.Rows.Count)
                    {
                        result = dtRxnSeq.AsEnumerable().Except(dtRxnSeqComments.AsEnumerable(), DataRowComparer.Default).CopyToDataTable();
                        errMsg = "Less Comments :" + result.Rows.Count + " \n";
                    }
                    else
                    {
                        result = dtRxnSeqComments.AsEnumerable().Except(dtRxnSeq.AsEnumerable(), DataRowComparer.Default).CopyToDataTable();
                        errMsg = "More  Comments :" + result.Rows.Count + "\n";
                    }
                    foreach (DataRow item in result.Rows)
                    {
                        errMsg += "Rxn =" + item["rxn"] + " Seq =" + item["seq"] + "\r\n";
                    }
                }

                blStatus = false;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        /// <summary>
        /// Extract comments from Pdf.
        /// </summary>
        /// <param name="file">Pdf File path.</param>
        /// <returns>List of Comments with page Numbers.</returns>
        public static List<Comment> LoadCommentPageWise(string file) //using pdfsharp
        {
            List<Comment> CommentList = new List<Comment>();
            try
            {
                PdfSharp.Pdf.PdfDocument inputDoc = PdfSharp.Pdf.IO.PdfReader.Open(file, PdfDocumentOpenMode.Import);
                PdfSharp.Pdf.PdfDocument document = new PdfSharp.Pdf.PdfDocument();
                PdfSharp.Pdf.PdfPage page = new PdfSharp.Pdf.PdfPage();

                for (int i = 0; i < inputDoc.PageCount; i++)
                {
                    page = inputDoc.Pages[i];
                    page = document.AddPage(page);

                    for (int p = 0; p < document.Pages[i].Annotations.Elements.Count; p++)
                    {
                        PdfAnnotation textAnnot = document.Pages[i].Annotations[p];

                        string content = textAnnot.Contents;
                        if (!String.IsNullOrEmpty(content))
                        {
                            Comment objComment = new Comment();
                            objComment.Comments = content;
                            objComment.Page = i;
                            CommentList.Add(objComment);
                        }
                    }
                }               
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return CommentList;
        }
    }
    
    /// <summary>
    /// Represents comments with page num.
    /// </summary>
    public class Comment
    {
        public string Comments { get; set; }
        public int Page { get; set; }
    }    
}
