﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using CADViewLib; 
#endregion
/////////////////////////////////////////////// CAS Reactant Tool///////////////////////////////////////////////////////////
///Start Data:
///End Data:
///Author:
///Developed by:
namespace IndxReactNarr.Generic
{
    public static class GlobalVariables
    {
        #region Global Variables
                   
        private static int _intReactionID = 0;
        public static int ReactantID
        {
            get { return _intReactionID; }
            set { _intReactionID = value; }
        }
        
        private static string _strucControlName = "ucParticipants";
        public static string UCControlName
        {
            get { return _strucControlName; }
        }

        public static DataTable Ser9000OrgRefData
        { get; set; }

        public static DataTable Ser8500OrgrefData
        { get; set; }

        public static DataTable TAN_Series8000Data
        { get; set; }

        public static DataTable TAN_Series8500Data
        { get; set; }

        public static DataTable RSN_CVT_Tbl
        { get; set; }

        public static DataTable RSN_FreeText_Tbl
        { get; set; }

        public static DataTable RSN_StageFreeTextTbl
        { get; set; }

        public static int UserID
        {
            get;
            set;
        }

        public static string UserName
        {
            get;
            set;
        }

        public static string RoleName { get; set; }

        public static int RoleID { get; set; }
            
        public static int URID
        {
            get;
            set;
        }

        public static DataTable User_Roles
        { get; set; }

        public static string PM_Name
        {
            get;
            set;
        }

        public static int PM_URID
        {
            get;
            set;
        }

        public static int Supvisr_URID
        { get; set; }

        public static DataTable CGMTbl_ForRxns
        { get; set; }

        public static DataTable EmptyStage_RSNs
        { get; set; }

        public static DataTable Solvent_BPoints
        { get; set; }

        public static DataTable CGMDataTbl
        { get; set; }

        public static DataTable SubstancesData
        { get; set; }

        public static DataTable NarrHighLightingData
        { get; set; }

        public static DataTable NarrReplacementData
        { get; set; }

        public static DataTable XMLConvTbl
        { get; set; }

        public static DataTable OrGrefTbl
        { get; set; }

        public static DataTable FindingTypesData
        { get; set; }

        public static DataTable MaterialsData
        { get; set; }

        public static DataTable FindingTypeReplData
        { get; set; }

        public static DataTable IndexingSections { get; set; }
        public static DataTable IndexingSubSections { get; set; }
        public static DataTable ConceptTextHeadings { get; set; }
        public static DataTable IndexingRoles { get; set; }
        public static DataTable NarrHighlightData { get; set; }

        public static string[] ReactantColumnNames = new string[] { "ID", "R_NAME", "R_MOL", "R_NRNNUM", "R_NRNREG","MOLFile" };
        public static string[] AgentColumnNames = new string[] { "ID", "A_NAME", "A_MOL", "A_NRNNUM", "A_NRNREG", "MOLFile" };
        public static string[] CatalystColumnNames = new string[] { "ID", "C_NAME", "C_MOL", "C_NRNNUM", "C_NRNREG", "MOLFile" };
        public static string[] SolventColumnNames = new string[] { "ID", "S_NAME", "S_MOL", "S_NRNNUM", "S_NRNREG", "MOLFile" };
        public static string[] ConditionsColumnNames = new string[] { "ID", "TIME", "TEMPERATURE", "PRESSURE", "PH" };
        public static string[] RSNColumnNames = new string[] { "ID", "RSN_CVT", "RSN_FT", "RSN_COMBINED" };

        public static string ApplicationName
        { get; set; }

        public static string ModuleName
        { get; set; }

        public static string ShipmentName { get; set; }

        #endregion
          
        public static bool IsLoginSuccess { get; set; }

        public static string MessageCaption = "CAS-IRN";

        //public static CADViewXClass CADViewObject { get; set; }

        public static CADViewX CADViewObject { get; set; }

        public static MDL.Draw.Renditor.Renditor ChemistryRenditor
        {
            get;
            set;
        }

        public static bool SkipValidations { get; set; }
    }
}
