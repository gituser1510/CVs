﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

#endregion

namespace IndxReactNarr.Generic
{
    public static class Enums
    {
        public enum ParticipantType
        {
            REACTANT,
            AGENT,
            SOLVENT,
            CATALYST
        }

        public enum ParticipantsMOlColumnNames
        {
            R_MOL,
            A_MOL,
            S_MOL,
            C_MOL,
            R_SUBST_MOL,
            A_SUBST_MOL,
            S_SUBST_MOL,
            C_SUBST_MOL
        }

        public enum ApplicationName
        {
            [Description("Narratives")]
            NARRATIVES,
            [Description("Organic Indexing")]
            ORGANIC,
            [Description("Reaction Analysis")]
            REACT,
            [Description("Macro Indexing")]
            MACRO,
            [Description("Exp.Procedures")]
            EXPPROCEDURES
            //[Description("Exp.Procedures2 Pilot")]
            //EXPPROCEDURES_2
        }
        
        public enum ModuleName
        {
            [Description("Module exists only in Organic/Macro indexing application")]
            INDX,
            [Description("This Module exists only in Narratives application")]
            NAR,
            [Description("This Module exists in Both applications (Organic indexing,Reaction analysis)")]
            RXN
        }

        public enum CommentsType
        {
            DEFAULT,
            OTHER,
            AUTHOR,
            INDEXING,
            TEMPERATURE,
            CAS,
            ORGINDEXING
        }

        public enum ScaleUnits
        {
            milligram,
            gram,
            kilogram            
        }
               
    }
}
