﻿#region NameSpaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using NLog.Targets.Wrappers;
using NLog.Targets;
using NLog;
using IndxReactNarrDAL;
using IndxReactNarrBll;

#endregion NameSpaces

namespace IndxReactNarr.Generic
{
    public static class ErrorHandling
    {      
        public static void WriteErrorLog(string message)
        {
            FileTarget target = new FileTarget();
            target.Layout = "${longdate} ${logger} ${message}";
            target.FileName = "${basedir}/Trace/CASIRNLog.txt";
            target.KeepFileOpen = false;
            target.Encoding = "iso-8859-2";

            AsyncTargetWrapper wrapper = new AsyncTargetWrapper();
            wrapper.WrappedTarget = target;
            wrapper.QueueLimit = 5000;
            wrapper.OverflowAction = AsyncTargetWrapperOverflowAction.Discard;

            NLog.Config.SimpleConfigurator.ConfigureForTargetLogging(wrapper, NLog.LogLevel.Trace);

            //MessageBox.Show(message);

            Logger logger = LogManager.GetLogger("CASIRNLOG");
            logger.Trace(message);

            try
            {
                ApplicationError appError = new ApplicationError();
                appError.UserName = GlobalVariables.UserName;
                appError.RoleName = GlobalVariables.RoleName;
                appError.AppError = message;
                CommonDB.SaveApplicationErrors(appError);
            }
            catch
            { }           
        }
    }
}
