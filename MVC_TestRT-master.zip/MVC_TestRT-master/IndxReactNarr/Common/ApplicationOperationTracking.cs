﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IndxReactNarrDAL;
using IndxReactNarr.Generic;
using System.Net;
using System.Reflection;
using System.Diagnostics;

namespace IndxReactNarr
{
    public class ApplicationOperationTracking
    {
        public static void LogOperation(string _seloperation)
        {
            try
            { 
                string strSystemName = Environment.GetEnvironmentVariable("COMPUTERNAME");
                string strUserName = Environment.UserName;
                string strIPAddress = GetSystemIP();

                IndxReactNarrBLL.AppLoginTrack objLogInTrack = new IndxReactNarrBLL.AppLoginTrack();
                objLogInTrack.UserID = GlobalVariables.UserID;
                objLogInTrack.RoleID = GlobalVariables.URID;
                objLogInTrack.SelOperation = _seloperation;
                objLogInTrack.SystemIPAddress = strIPAddress;
                objLogInTrack.SystemName = strSystemName;
                objLogInTrack.WindowsUserID = strUserName;
                objLogInTrack.AppVersion = GetApplicationVersion();
                //CASRxnDataAccess.InsertApplicationLogInTrack(objLogInTrack);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private static string GetSystemIP()
        {
            string strIP = "";
            try
            {
                string strHostName = "";
                strHostName = System.Net.Dns.GetHostName();
                IPHostEntry ipEntry = System.Net.Dns.GetHostEntry(strHostName);
                IPAddress[] addr = ipEntry.AddressList;

                strIP = addr[addr.Length - 1].ToString();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strIP;
        }

        private static string GetApplicationVersion()
        {
            string strAppVersion = "";
            try
            {
                Assembly assembly = Assembly.GetExecutingAssembly();
                FileVersionInfo fvi = FileVersionInfo.GetVersionInfo(assembly.Location);
                strAppVersion = fvi.FileVersion;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strAppVersion;
        }
    }
}
