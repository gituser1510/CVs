﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarr.Common
{
    public class FindReplaceType
    {
        public bool IsBold
        {
            get;
            set;
        }
        public bool IsItalic
        {
            get;
            set;
        }
        public bool IsSupScr
        {
            get;
            set;
        }
        public bool IsSubScr
        {
            get;
            set;
        }
        public bool IsBoldItalic
        {
            get;
            set;
        }
        public char CharValue
        {
            get;
            set;
        }
    }
}
