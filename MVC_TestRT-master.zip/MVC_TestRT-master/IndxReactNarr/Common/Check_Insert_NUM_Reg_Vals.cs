﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IndxReactNarr.Generic;

namespace IndxReactNarr.Common
{
    public static class Check_Insert_NUM_Reg_Vals
    {
        public static bool CheckAndInsertNUM_Reg(string _tan,string _id, int _nrnnum, int _nrnreg,int _reaction,
                                                 string _location,string _partpnt, out string o_reaction,
                                                 out string o_location, out string o_partpnt)
        {
            bool blStatus = false;
            try
            {
                string strFilter = "";
                if (Generic.GlobalVariables.Ser8500OrgrefData == null)
                {
                    DataTable dtNum_Reg = CreateGlobalNum_RegTable();

                    AddNewRowToTable(ref dtNum_Reg, _tan,_id, _nrnnum, _nrnreg, _reaction, _location, _partpnt);
                    Generic.GlobalVariables.Ser8500OrgrefData = dtNum_Reg;
                    blStatus = true;
                }
                else
                {
                    DataTable dtNum_Reg = Generic.GlobalVariables.Ser8500OrgrefData;

                    strFilter = "TAN = '" + _tan + "' and ID = '" + _id + "'";

                    //string strFilter = "TAN = '" + _tan + "' and NRNNUM = " + _nrnnum + " and NRNREG = " + _nrnreg +
                    //                   " and REACTION = " + _reaction + " and LOCATION = '" + _location +
                    //                   "' and PARTICIPANT = '" + _partpnt + "'";

                    DataRow[] dtRowArr = dtNum_Reg.Select(strFilter);

                    if (dtRowArr != null)
                    {
                        if (dtRowArr.Length > 0)
                        {
                            strFilter = "TAN = '" + _tan + "' and NRNNUM = " + _nrnnum + " and NRNREG = " + _nrnreg;

                            DataRow[] dtRArr = dtNum_Reg.Select(strFilter);
                            if (dtRArr != null)
                            {
                                if (dtRArr.Length > 0)
                                {
                                    o_reaction = dtRArr[0]["REACTION"].ToString();
                                    o_location = dtRArr[0]["LOCATION"].ToString();
                                    o_partpnt = dtRArr[0]["PARTICIPANT"].ToString();

                                    blStatus = false;
                                    return blStatus;
                                }
                                else
                                {
                                    UpdateRowInTable(ref dtNum_Reg, _tan, _id, _nrnnum, _nrnreg, _reaction, _location, _partpnt);
                                    Generic.GlobalVariables.Ser8500OrgrefData = dtNum_Reg;
                                    blStatus = true;
                                }
                            }
                            else
                            {
                                UpdateRowInTable(ref dtNum_Reg, _tan, _id, _nrnnum, _nrnreg, _reaction, _location, _partpnt);
                                Generic.GlobalVariables.Ser8500OrgrefData = dtNum_Reg;
                                blStatus = true;
                            }                            
                        }
                        else
                        {
                            strFilter = "TAN = '" + _tan + "' and NRNNUM = " + _nrnnum + " and NRNREG = " + _nrnreg;


                            DataRow[] dtRArr = dtNum_Reg.Select(strFilter);
                            if (dtRArr != null)
                            {
                                if (dtRArr.Length > 0)
                                {
                                    o_reaction = dtRArr[0]["REACTION"].ToString();
                                    o_location = dtRArr[0]["LOCATION"].ToString();
                                    o_partpnt = dtRArr[0]["PARTICIPANT"].ToString();

                                    blStatus = false;
                                    return blStatus;
                                }
                                else
                                {
                                    AddNewRowToTable(ref dtNum_Reg, _tan, _id, _nrnnum, _nrnreg, _reaction, _location, _partpnt);
                                    Generic.GlobalVariables.Ser8500OrgrefData = dtNum_Reg;
                                    blStatus = true;
                                }
                            }
                            else
                            {
                                AddNewRowToTable(ref dtNum_Reg, _tan, _id, _nrnnum, _nrnreg, _reaction, _location, _partpnt);
                                Generic.GlobalVariables.Ser8500OrgrefData = dtNum_Reg;
                                blStatus = true;
                            }
                        }
                    }
                    else
                    {
                        AddNewRowToTable(ref dtNum_Reg, _tan,_id, _nrnnum, _nrnreg, _reaction, _location, _partpnt);
                        Generic.GlobalVariables.Ser8500OrgrefData = dtNum_Reg;
                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            o_reaction = "";
            o_location = "";
            o_partpnt = "";
            return blStatus;
        }

        private static void AddNewRowToTable(ref DataTable _dtNrn_Reg, string _tan,string _ident, int _nrnnum, int _nrnreg, int _reaction,
                                                 string _location, string _partpnt)
        {
            try
            {
                DataRow dRow = _dtNrn_Reg.NewRow();
                dRow["ID"] = _ident;
                dRow["TAN"] = _tan;
                dRow["NRNNUM"] = _nrnnum;
                dRow["NRNREG"] = _nrnreg;
                dRow["REACTION"] = _reaction;
                dRow["LOCATION"] = _location;
                dRow["PARTICIPANT"] = _partpnt;
                _dtNrn_Reg.Rows.Add(dRow);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private static void UpdateRowInTable(ref DataTable _dtNrn_Reg, string _tan, string _ident, int _nrnnum, int _nrnreg, int _reaction,
                                                string _location, string _partpnt)
        {
            try
            {
                if (_dtNrn_Reg != null)
                {
                    if (_dtNrn_Reg.Rows.Count > 0)
                    {
                        for (int i = 0; i < _dtNrn_Reg.Rows.Count; i++)
                        {
                            if (_dtNrn_Reg.Rows[i]["TAN"].ToString() == _tan && _dtNrn_Reg.Rows[i]["ID"].ToString() == _ident)
                            {
                                _dtNrn_Reg.Rows[i]["NRNNUM"] = _nrnnum;
                                _dtNrn_Reg.Rows[i]["NRNREG"] = _nrnreg;
                                _dtNrn_Reg.Rows[i]["REACTION"] = _reaction;
                                _dtNrn_Reg.Rows[i]["LOCATION"] = _location;
                                _dtNrn_Reg.Rows[i]["PARTICIPANT"] = _partpnt;
                                _dtNrn_Reg.AcceptChanges();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        public static DataTable CreateGlobalNum_RegTable()
        {
            DataTable dtNum_Reg = null;
            try
            {
                dtNum_Reg = new DataTable();
                dtNum_Reg.Columns.Add("ID", typeof(Int32));
                dtNum_Reg.Columns.Add("TAN", typeof(string));
                dtNum_Reg.Columns.Add("NRNNUM", typeof(Int32));
                dtNum_Reg.Columns.Add("NRNREG", typeof(Int32));
                dtNum_Reg.Columns.Add("REACTION", typeof(Int32));
                dtNum_Reg.Columns.Add("LOCATION", typeof(string));
                dtNum_Reg.Columns.Add("PARTICIPANT", typeof(string));                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtNum_Reg;
        }
    }
}
