﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IndxReactNarr.Generic;
using System.Windows.Forms;
using System.ComponentModel;

namespace IndxReactNarr.Common
{
    public static class CAS_AutoFillCollection
    {                

        public static BindingList<string> Get8500SeriesNames()
        {
            BindingList<string> bindingList = new BindingList<string>();
            try
            {               
                bindingList.Add("");
                if (GlobalVariables.Ser9000OrgRefData != null)
                {
                    if (GlobalVariables.Ser9000OrgRefData.Rows.Count > 0)
                    {
                        for (int i = 0; i < GlobalVariables.Ser9000OrgRefData.Rows.Count; i++)
                        {
                            if (GlobalVariables.Ser9000OrgRefData.Rows[i]["NUM"].ToString() == ""
                                && GlobalVariables.Ser9000OrgRefData.Rows[i]["ORGREF_NAME"].ToString() != "")
                            {
                                if (!bindingList.Contains(GlobalVariables.Ser9000OrgRefData.Rows[i]["ORGREF_NAME"].ToString()))
                                {
                                    bindingList.Add(GlobalVariables.Ser9000OrgRefData.Rows[i]["ORGREF_NAME"].ToString());
                                }
                            }
                        }
                    }
                }
                return bindingList;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return bindingList;
        }
    }
}
