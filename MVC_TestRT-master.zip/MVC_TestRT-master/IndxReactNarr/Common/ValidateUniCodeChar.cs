﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HtmlRichText;
using System.Drawing;
using IndxReactNarrBll;
using IndxReactNarr.Generic;

namespace IndxReactNarr
{
    public class ValidateUniCodeChar
    {
        /// <summary>
        /// New method on 13th Nov 2013
        /// </summary>
        /// <param name="inputstring"></param>
        /// <param name="tan"></param>
        /// <param name="rxnnum"></param>
        /// <param name="rxnseq"></param>
        /// <param name="tag"></param>
        /// <returns></returns>
        public static bool ValidateUnicodes(HtmlRichTextBox item, string narId, ref List<UniCodeChar> lstUniCode)
        {

            bool blStatus = false;
            try
            {
                String originalString = item.Text;
                Byte[] bytes = Encoding.UTF32.GetBytes(item.Text);
                uint codepoint = 0;

                //Disallowed characters
                //U+0000 – U+0008(decimal is 0000-0008) (Hex is &#x0000; - &#x0008;) - Disallowed by Xml - Characters found: 9
                //U+000B – U+000C(decimal is 0011-0012) (Hex is &#x000B; - &#x000C;) - Disallowed by Xml - Characters found: 2
                //U+000E – U+001F (decimal is 0014-0031) (Hex is &#x000E; - &#x001F;) - Disallowed by Xml - Characters found: 18
                //U+D800 - U+DBFF decimal range is 55296-56319 - Disallowed by Xml - Characters found: 1024
                //U+DC00 - U+DFFF (decimal is 56320-57343)(Hex is &#xDC00; - &#xDFFF;)-Disallowed by Xml - Characters found: 1024
                //U+FFFE – U+FFFF(decimal is 65534 - 65535)(Hex is &#xFFFE; - &#xFFFF;) - Disallowed by Xml - Characters found: 2
                //U+E000 - U+F8FF (decimal is - 57344-63743) (Hex is - &#xE000; - &#xF8FF;) disallowed by CAS (Unicode Private Use Area)- Characters found: 6400
                //U+007F - U+009F (decimal is 0127-0159) (Hex is &#x007F; - &#x009F;) - disallowed by CAS (control codes) -Characters found: 33
                //U+10000 to U+10FFFF (decimal is 65536-0) (Hex is &#x10000; - ;) - disallowed by CAS (outside of Unicode Basic Multilingual Plane) -Characters found: -

                //Allowed characters are thus:
                //U+0009			tab - Decimal is 9
                //U+000A			line feed - decimal is 10
                //U+000D			carriage return - decimal is 13
                //U+0020 – U+007E	ASCII - Decimal range is 32 - 126
                //U+00A0 – U+D7FF	various - Decimal range is 160 - 55295
                //U+F900 – U+FFFD	various - Decimal range is 63744 - 65533


                for (int idx = 0; idx < bytes.Length; idx += 4)
                {
                    codepoint = 0;
                    codepoint = BitConverter.ToUInt32(bytes, idx);

                    //U+F061,U+F05D - error codes exist in xml

                    #region Code commented
                    ////Not Allowed Unicodes
                    //if ((codepoint >= 0000 && codepoint <= 0008) || (codepoint >= 0011 && codepoint <= 0012) || (codepoint >= 0014 && codepoint <= 0031) ||
                    //    (codepoint >= 55296 && codepoint <= 56319) || (codepoint >= 56320 && codepoint <= 57343) || (codepoint >= 57344 && codepoint <= 63743) ||
                    //    (codepoint >= 0127 && codepoint <= 0159) || (codepoint >= 65534 && codepoint <= 65535) || (codepoint >= 65536))
                    //{
                    //    blStatus = true;

                    //    DataRow dtRow = NonAllowedData.NewRow();
                    //    dtRow["TAN"] = tan;
                    //    dtRow["RxnNum"] = rxnnum;
                    //    dtRow["RxnSeq"] = rxnseq;
                    //    dtRow["Tag Name"] = tag;
                    //    dtRow["NonAllowed Char"] = System.BitConverter.ToChar(bytes, idx);
                    //    dtRow["Replacement"] = string.Format("&#x{0:X4};", codepoint);
                    //    NonAllowedData.Rows.Add(dtRow);
                    //} 
                    #endregion

                    // 
                    // Not Allowed Unicodes  on 3rd March 2014.
                    // unicode &#x0080; char '€' codepoint = 8482
                    // unicode &#x0084; char '„' codepoint = 732 
                    // unicode &#x0098; char '˜'  codepoint = 8364 (invisible char)
                    // unicode &#x0099; char '™' codepoint = 8222
                    // unicode  &#8203; char '​' codepoing=8203
                    if (codepoint == 8482 || codepoint == 732 || codepoint == 8364 || codepoint == 8222 || codepoint == 8203)
                    {
                        UniCodeChar objUnicode = new UniCodeChar();
                        blStatus = true;
                        char c = System.BitConverter.ToChar(bytes, idx);
                        objUnicode.NarId = narId;
                        objUnicode.Position = idx / 4;
                        // objUnicode.UserControlSerialNo = ucSerialNum;
                        objUnicode.UniChar = c;
                        objUnicode.ErrField = item.Name;
                        objUnicode.Word = GetWord(item.Text, idx / 4);
                        lstUniCode.Add(objUnicode);
                    }

                    //Allowed Unicodes
                    //U+F900 – U+FFFD (decimal is 65536-0) (Hex is &#xF900; - &#xFFFD;) - Allowed - Characters found: 1603
                    //U+00A0 – U+D7FF (Decimal is 0160 - 55291) (Hex is &#x00A0; - &#xD7FB;) - Allowed
                    //U+2282 - (Subset of) Decimal - 8834 & Hex - 2282 - Allowed - New code as on 24th Jan 2013

                    //if (codepoint >= 57344 && codepoint <= 63743)//Boxes unicode range
                    //{ 

                    //}

                    if (!(codepoint == 9) || !(codepoint == 10) || !(codepoint == 13) || (codepoint >= 32 && codepoint <= 126) ||
                       (codepoint >= 160 && codepoint <= 55295) || (codepoint >= 63744 && codepoint <= 65533))
                    {
                        //char c = System.BitConverter.ToChar(bytes, idx);
                        ////sbAllCode.AppendFormat("Allowed : " + c + " - Replacement:  " + "&#x{0:X4}; ", codepoint);
                        //blStatus = true;

                        //DataRow dtRow = AllowedData.NewRow();
                        //dtRow["TAN"] = tan;
                        //dtRow["RxnNum"] = rxnnum;
                        //dtRow["RxnSeq"] = rxnseq;
                        //dtRow["Tag Name"] = tag;
                        //dtRow["Allowed Char"] = c;
                        //dtRow["Replacement"] = string.Format("&#x{0:X4};", codepoint);
                        //AllowedData.Rows.Add(dtRow);
                    }
                    else
                    {
                        //DataRow dtRow = NonAllowedData.NewRow();
                        //dtRow["TAN"] = tan;
                        //dtRow["RxnNum"] = rxnnum;
                        //dtRow["RxnSeq"] = rxnseq;
                        //dtRow["Tag Name"] = tag;
                        //dtRow["NonAllowed Char"] = System.BitConverter.ToChar(bytes, idx);
                        //dtRow["Replacement"] = string.Format("&#x{0:X4};", codepoint);
                        //NonAllowedData.Rows.Add(dtRow);
                        blStatus = true;
                        char c = System.BitConverter.ToChar(bytes, idx);
                        UniCodeChar objUnicode = new UniCodeChar();
                        objUnicode.NarId = narId;
                        objUnicode.Position = idx / 4;
                        // objUnicode.UserControlSerialNo = ucSerialNum;
                        objUnicode.UniChar = c;
                        objUnicode.ErrField = item.Name;
                        objUnicode.Word = GetWord(item.Text, idx / 4);
                        lstUniCode.Add(objUnicode);

                    }
                }
                //if (unicodestring != null)
                //{
                //    unicodestring = GetTextBoxName(item) + unicodestring;
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        /// <summary>
        /// Get word from index which is belongsto the word
        /// </summary>
        /// <param name="inputString">String</param>
        /// <param name="position">index</param>
        /// <returns>word which is belongs to that index.</returns>
        private static string GetWord(string inputString, int position)
        {
            int cursorPosition = position;
            int nextSpace = inputString.IndexOf(' ', cursorPosition);
            int selectionStart = 0;
            string trimmedString = string.Empty;
            // Strip everything after the next space...
            if (nextSpace != -1)
            {
                trimmedString = inputString.Substring(0, nextSpace);
            }
            else
            {
                trimmedString = inputString.Trim();
            }


            if (trimmedString.Trim().LastIndexOf(' ') != -1)
            {
                selectionStart = 1 + trimmedString.LastIndexOf(' ');
                trimmedString = trimmedString.Substring(1 + trimmedString.LastIndexOf(' '));
            }

            return trimmedString.Trim();
        }

        public static bool IsASCIIData(string inputString)
        {
            bool blStatus = false;
            try
            {
                // ASCII encoding replaces non-ascii with question marks, so we use UTF8 to see if multi-byte sequences are there
                blStatus = Encoding.UTF8.GetByteCount(inputString) == inputString.Length;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

    }
}
