﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using System.Data;
using System.Text.RegularExpressions;
using IndxReactNarr.Generic;

namespace IndxReactNarr.Common
{
    public class MarkUpsValidation_IText
    {
        public static DataTable GetMarkUpReactionsNumSeqs(string pdfPath, out bool pdfReadStatus, out string authorName)
        {
            DataTable dtRxnSeqComments = null;
            bool blReadStatus = false;
            string pdfAuthorName = "";
            try
            {
                dtRxnSeqComments = new DataTable();
                dtRxnSeqComments.Columns.Add("RXN_NUM", typeof(int));
                dtRxnSeqComments.Columns.Add("RXN_SEQ", typeof(int));

                using (PdfReader reader = new PdfReader(pdfPath))
                {
                    try
                    {
                        pdfAuthorName = reader.Info["Author"];
                    }
                    catch
                    { }

                    blReadStatus = true;

                    PdfDictionary annotationDictionary;
                    string content;
                    Regex expression = new Regex(@"rxn (\d+)-(\d+)", RegexOptions.IgnoreCase);

                    for (int i = 1; i <= reader.NumberOfPages; i++)
                    {
                        PdfArray array = reader.GetPageN(i).GetAsArray(PdfName.ANNOTS);
                        if (array == null) continue;

                        foreach (PdfObject annotation in array.ArrayList)
                        {
                            //Convert the itext-specific object as a generic PDF object
                            annotationDictionary = (PdfDictionary)PdfReader.GetPdfObject(annotation);
                            if (annotationDictionary.Get(PdfName.CONTENTS) != null)
                            {
                                content = annotationDictionary.Get(PdfName.CONTENTS).ToString();
                                if (!String.IsNullOrEmpty(content))
                                {
                                    var matches = expression.Match(content);
                                    if (matches != null)
                                    {
                                        if (!string.IsNullOrEmpty(matches.Groups[1].Value) && !string.IsNullOrEmpty(matches.Groups[2].Value))
                                        {
                                            dtRxnSeqComments.Rows.Add(matches.Groups[1].Value, matches.Groups[2].Value);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            pdfReadStatus = blReadStatus;
            authorName = pdfAuthorName;
            return dtRxnSeqComments;
        }

        public static DataTable GetMarkUpIndexingNUMs(string pdfPath)
        {
            DataTable dtRxnSeqComments = null;
            try
            {
                dtRxnSeqComments = new DataTable();
                dtRxnSeqComments.Columns.Add("NUM", typeof(string));

                RandomAccessFileOrArray raf = null;
                PdfReader reader = null;
                //System.Collections.ArrayList outlines = null;
                raf = new iTextSharp.text.pdf.RandomAccessFileOrArray(pdfPath);
                reader = new iTextSharp.text.pdf.PdfReader(raf, null);
                //outlines = iTextSharp.text.pdf.SimpleBookmark.GetBookmark(reader1);

                //PdfReader reader = new PdfReader(pdfPath);
                PdfDictionary annotationDictionary;
                string content;
                //Regex expression = new Regex(@"(\d+)", RegexOptions.IgnoreCase);
                //Regex expression = new Regex(@"\d{1,3}[ \-]?[^ \-0-9]*", RegexOptions.IgnoreCase);
                Regex expression = new Regex(@"^([0-9]+)(?: +-?.+)?$|^([0-9]+) *\((?:[0-9]+ *\+)+[0-9]+\)$", RegexOptions.IgnoreCase);

                if (reader != null)
                {
                    for (int i = 1; i <= reader.NumberOfPages; i++)
                    {
                        PdfArray array = reader.GetPageN(i).GetAsArray(PdfName.ANNOTS);
                        if (array == null) continue;

                        foreach (PdfObject annotation in array.ArrayList)
                        {
                            //Convert the itext-specific object as a generic PDF object
                            annotationDictionary = (PdfDictionary)PdfReader.GetPdfObject(annotation);
                            if (annotationDictionary.Get(PdfName.CONTENTS) != null)
                            {
                                content = annotationDictionary.Get(PdfName.CONTENTS).ToString();

                                if (!String.IsNullOrEmpty(content) && !content.ToUpper().StartsWith("RXN"))
                                {
                                    string[] saTempNUMs = content.Trim().Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                                    if (saTempNUMs != null && saTempNUMs.Length > 0)
                                    {
                                        foreach (string strNUM in saTempNUMs)
                                        {
                                            var output = Regex.Replace(strNUM.Trim(), "[^0-9]+", string.Empty);
                                            
                                            var matches = expression.Match(output);
                                            if (matches.Success)
                                            {
                                                if (matches.Groups.Count > 0)
                                                {
                                                    //dtRxnSeqComments.Rows.Add(content);
                                                    dtRxnSeqComments.Rows.Add(matches.Groups[0].Value);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtRxnSeqComments;
        }
    }
}
