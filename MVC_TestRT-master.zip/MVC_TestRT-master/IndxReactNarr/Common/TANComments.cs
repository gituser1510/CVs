﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IndxReactNarr.Generic;
using System.Text.RegularExpressions;

namespace IndxReactNarr.Common
{
    public class TANComments
    {
        #region Comments for Batch Final Checks

        //New Method on 13th May 2013
        private static string GetCommentsFromTANComments(string comments, string comments_type)
        {
            string strComments = "";
            try
            {
                if (!string.IsNullOrEmpty(comments) && !string.IsNullOrEmpty(comments_type))
                {
                    Regex regEx;
                    string strCmnts = "";
                    string[] saCmnts = null;

                    switch (comments_type.ToUpper())
                    {
                        case "CAS": //CAS Comments

                            regEx = new Regex("<CE>(.*?)</CE>");
                            var vCE = regEx.Match(comments);
                            strCmnts = vCE.Groups[1].ToString();
                            if (!string.IsNullOrEmpty(strCmnts))
                            {
                                strComments = strCmnts.Replace("~CE~", ". ");
                            }
                            break;

                        case "AUTHOR": //AUTHOR Error Comments     

                            regEx = new Regex("<AE>(.*?)</AE>");
                            var vAE = regEx.Match(comments);
                            strCmnts = vAE.Groups[1].ToString();
                            if (!string.IsNullOrEmpty(strCmnts))
                            {
                                strComments = strCmnts.Replace("~AE~", ". ");
                            }
                            break;

                        case "INDEXING": //INDEXING Error Comments     

                            regEx = new Regex("<IE>(.*?)</IE>");
                            var vIE = regEx.Match(comments);
                            strCmnts = vIE.Groups[1].ToString();
                            if (!string.IsNullOrEmpty(strCmnts))
                            {
                                strComments = strCmnts.Replace("~IE~", ". ");
                            }
                            break;

                        case "OTHER": //Other Error Comments
                            strComments = GetRequiredCommentsFromOtherCommentsString(comments, "OTHER");
                            break;

                        case "DEFAULT": //Default Comments  
                            strComments = GetRequiredCommentsFromOtherCommentsString(comments, "DEFAULT");
                            break;

                        case "TEMPERATURE": //Default Comments  
                            strComments = GetRequiredCommentsFromOtherCommentsString(comments, "TEMPERATURE");
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strComments;
        }

        //New Method on 13th May 2013
        private static string GetRequiredCommentsFromOtherCommentsString(string comments, string comments_type)
        {
            string strComments = "";
            try
            {
                //Other Comments 
                if (comments.Trim().Contains("<OE>") && comments.Trim().Contains("</OE>"))
                {
                    Regex regEx = new Regex("<OE>(.*?)</OE>");
                    var vOE = regEx.Match(comments);
                    string strCmnts = vOE.Groups[1].ToString();
                    if (!string.IsNullOrEmpty(strCmnts))
                    {
                        string[] saCmnts = strCmnts.Split(new string[] { "~OE~" }, StringSplitOptions.RemoveEmptyEntries);
                        if (saCmnts != null)
                        {
                            string strOtherCmnts = "";
                            for (int i = 0; i < saCmnts.Length; i++)
                            {
                                strOtherCmnts = "";
                                strOtherCmnts = saCmnts[i].Trim();

                                Regex rgOther = new Regex("^(?<defltcmnts>[^~]*)~~(?<tmpcmnts>[^`]*)`(?<usrcmnts>.*)$");
                                var vOUC = rgOther.Match(strOtherCmnts);
                                if (vOUC.Groups.Count == 4)
                                {
                                    if (comments_type.ToUpper() == "DEFAULT")//Default Comments
                                    {
                                        strComments = vOUC.Groups["defltcmnts"].Value.ToString().Trim();
                                    }
                                    if (comments_type.ToUpper() == "TEMPERATURE")//Temperature Comments
                                    {
                                        strComments = vOUC.Groups["tmpcmnts"].Value.ToString().Trim();
                                    }
                                    if (comments_type.ToUpper() == "OTHER")//Other Comments
                                    {
                                        strComments = vOUC.Groups["usrcmnts"].Value.ToString().Trim();
                                    }
                                }

                                #region Code commented on 15th May 2013
                                ////Old User Comments - format is DefaultComments~~TemperatureComments`UserComments
                                //if (strOtherCmnts.Trim().Contains("~~") && strOtherCmnts.Trim().Contains("`"))
                                //{
                                //    Regex rgOther = new Regex("^(?<defltcmnts>[^~]*)~~(?<tmpcmnts>[^`]*)`(?<usrcmnts>.*)$");
                                //    var vOUC = rgOther.Match(strOtherCmnts);
                                //    if (vOUC.Groups.Count == 4)
                                //    {
                                //        if (comments_type.ToUpper() == "DEFAULT")//Default Comments
                                //        {
                                //            strComments = vOUC.Groups["defltcmnts"].Value.ToString().Trim();
                                //        }
                                //        if (comments_type.ToUpper() == "TEMPERATURE")//Temperature Comments
                                //        {
                                //            strComments = vOUC.Groups["tmpcmnts"].Value.ToString().Trim();
                                //        }
                                //        if (comments_type.ToUpper() == "OTHER")//Other Comments
                                //        {
                                //            strComments = vOUC.Groups["usrcmnts"].Value.ToString().Trim();
                                //        }
                                //    }
                                //}
                                //else if (!strOtherCmnts.Trim().Contains("~~") && !strOtherCmnts.Trim().Contains("`"))//Only Default Comments
                                //{
                                //    if (comments_type.ToUpper() == "DEFAULT")//Default Comments
                                //    {
                                //        strComments = strOtherCmnts.Trim();
                                //    }
                                //}
                                //else if (strOtherCmnts.Trim().Contains("~~"))//Comments contains Temperature Comments
                                //{
                                //    string[] saComments = strOtherCmnts.Trim().Split(new string[] { "~~" }, StringSplitOptions.RemoveEmptyEntries);
                                //    if (saComments != null)
                                //    {
                                //        if (saComments.Length == 2)
                                //        {
                                //            if (comments_type.ToUpper() == "DEFAULT")//Default Comments
                                //            {
                                //                strComments = saComments[0].Trim();
                                //            }
                                //            else if (comments_type.ToUpper() == "TEMPERATURE")
                                //            {
                                //                strComments = saComments[1].Trim();
                                //            }
                                //        }
                                //        else if (saComments.Length == 1)
                                //        {
                                //            if (comments_type.ToUpper() == "TEMPERATURE")
                                //            {
                                //                strComments = saComments[0].Trim();
                                //            }
                                //        }
                                //    }
                                //}
                                //else if (strOtherCmnts.Trim().Contains("`"))//Comments contains Temperature Comments
                                //{
                                //    string[] saComments = strOtherCmnts.Trim().Split(new string[] { "`" }, StringSplitOptions.RemoveEmptyEntries);
                                //    if (saComments != null)
                                //    {
                                //        if (saComments.Length == 2)
                                //        {
                                //            if (comments_type.ToUpper() == "DEFAULT")//Default Comments
                                //            {
                                //                strComments = saComments[0].Trim();
                                //            }
                                //            else if (comments_type.ToUpper() == "OTHER")//Default Comments
                                //            {
                                //                strComments = saComments[1].Trim();
                                //            }
                                //        }
                                //        else if (saComments.Length == 1)
                                //        {
                                //            if (comments_type.ToUpper() == "OTHER")//Default Comments
                                //            {
                                //                strComments = saComments[0].Trim();
                                //            }
                                //        }
                                //    }
                                //} 
                                #endregion
                            }
                        }
                    }
                }
                else if (comments.Trim().Contains("~~") || comments.Trim().Contains("`"))
                {
                    Regex rgOther = new Regex("^(?<defltcmnts>[^~]*)~~(?<tmpcmnts>[^`]*)`(?<usrcmnts>.*)$");
                    var vOUC = rgOther.Match(comments);
                    if (vOUC.Groups.Count == 4)
                    {
                        if (comments_type.ToUpper() == "DEFAULT")//Default Comments
                        {
                            strComments = vOUC.Groups["defltcmnts"].Value.ToString().Trim();
                        }
                        if (comments_type.ToUpper() == "TEMPERATURE")//Temperature Comments
                        {
                            strComments = vOUC.Groups["tmpcmnts"].Value.ToString().Trim();
                        }
                        if (comments_type.ToUpper() == "OTHER")//Other Comments
                        {
                            strComments = vOUC.Groups["usrcmnts"].Value.ToString().Trim();
                        }
                    }

                    //Old User Comments - format is DefaultComments~~TemperatureComments`UserComments
                    #region Code commented on 15th May 2013
                    //if (comments.Trim().Contains("~~") && comments.Trim().Contains("`"))
                    //{
                    //    Regex regEx = new Regex("^(.*)~~([^`]*)`(.+)$"); //
                    //    var vOUC = regEx.Match(comments);
                    //    if (vOUC.Groups.Count == 4)
                    //    {
                    //        if (!string.IsNullOrEmpty(vOUC.Groups[1].ToString()))//Default Comments
                    //        {
                    //            if (comments_type.ToUpper() == "DEFAULT")
                    //            {
                    //                strComments = vOUC.Groups[1].ToString().Trim();
                    //            }
                    //        }
                    //        if (!string.IsNullOrEmpty(vOUC.Groups[2].ToString()))//Temperature Comments
                    //        {
                    //            if (comments_type.ToUpper() == "TEMPERATURE")
                    //            {
                    //                strComments = vOUC.Groups[2].ToString().Trim();
                    //            }
                    //        }
                    //        if (!string.IsNullOrEmpty(vOUC.Groups[3].ToString()))//Other Comments
                    //        {
                    //            if (comments_type.ToUpper() == "OTHER")
                    //            {
                    //                strComments = vOUC.Groups[3].ToString().Trim();
                    //            }
                    //        }
                    //    }
                    //}
                    //else if (!comments.Trim().Contains("~~") && !comments.Trim().Contains("`"))//Only Default Comments
                    //{
                    //    if (comments_type.ToUpper() == "DEFAULT")
                    //    {
                    //        strComments = comments.Trim();
                    //    }
                    //}
                    //else if (comments.Trim().Contains("~~"))//Comments contains Temperature Comments
                    //{
                    //    string[] saComments = comments.Trim().Split(new string[] { "~~" }, StringSplitOptions.RemoveEmptyEntries);
                    //    if (saComments != null)
                    //    {
                    //        if (saComments.Length == 2)
                    //        {
                    //            if (comments_type.ToUpper() == "DEFAULT")
                    //            {
                    //                strComments = saComments[0].Trim();
                    //            }
                    //            else if (comments_type.ToUpper() == "TEMPERATURE")
                    //            {
                    //                strComments = saComments[1].Trim();
                    //            }
                    //        }
                    //        else if (saComments.Length == 1)
                    //        {
                    //            if (comments_type.ToUpper() == "TEMPERATURE")
                    //            {
                    //                strComments = saComments[0].Trim();
                    //            }
                    //        }
                    //    }
                    //}
                    //else if (comments.Trim().Contains("`"))//Comments contains Temperature Comments
                    //{
                    //    string[] saComments = comments.Trim().Split(new string[] { "`" }, StringSplitOptions.RemoveEmptyEntries);
                    //    if (saComments != null)
                    //    {
                    //        if (saComments.Length == 2)
                    //        {
                    //            if (comments_type.ToUpper() == "DEFAULT")
                    //            {
                    //                strComments = saComments[0].Trim();
                    //            }
                    //            else if (comments_type.ToUpper() == "OTHER")
                    //            {
                    //                strComments = saComments[1].Trim();
                    //            }
                    //        }
                    //        else if (saComments.Length == 1)
                    //        {
                    //            if (comments_type.ToUpper() == "OTHER")
                    //            {
                    //                strComments = saComments[0].Trim();
                    //            }
                    //        }
                    //    }
                    //} 
                    #endregion
                }
                else
                {
                    if (comments_type.ToUpper() == "DEFAULT")//Default Comments
                    {
                        strComments = comments.Trim();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strComments;
        }

        //New method on 13th May 2013 for Comments update
        private static string GetCommentsStringFromCommentsRow(System.Data.DataRow commentsrow)
        {
            string strComments = "";
            try
            {
                if (commentsrow != null)
                {
                    string strIEComments = commentsrow["IEComments"] != null ? commentsrow["IEComments"].ToString() : "";
                    strIEComments = strIEComments.Trim().Replace(".", "~IE~");
                    strIEComments = !string.IsNullOrEmpty(strIEComments.Trim()) ? "<IE>" + strIEComments + "</IE>" : strIEComments;

                    string strAEComments = commentsrow["AEComments"] != null ? commentsrow["AEComments"].ToString() : "";
                    strAEComments = strAEComments.Trim().Replace(".", "~AE~");
                    strAEComments = !string.IsNullOrEmpty(strAEComments.Trim()) ? "<AE>" + strAEComments + "</AE>" : strAEComments;

                    string strCASComments = commentsrow["CASComments"] != null ? commentsrow["CASComments"].ToString() : "";
                    strCASComments = strCASComments.Trim().Replace(".", "~CE~");
                    strCASComments = !string.IsNullOrEmpty(strCASComments.Trim()) ? "<CE>" + strCASComments + "</CE>" : strCASComments;

                    string strOtherComments = commentsrow["OtherComments"] != null ? commentsrow["OtherComments"].ToString() : "";
                    string strDefaultComments = commentsrow["DefaultComments"] != null ? commentsrow["DefaultComments"].ToString() : "";
                    string strTemprtureComments = commentsrow["TemprtureComments"] != null ? commentsrow["TemprtureComments"].ToString() : "";

                    strOtherComments = strDefaultComments + "~~" + strTemprtureComments + "`" + strOtherComments;
                    strOtherComments = !string.IsNullOrEmpty(strOtherComments.Trim()) ? "<OE>" + strOtherComments.Trim() + "</OE>" : strOtherComments.Trim();

                    //Combine all the comments
                    strComments = strCASComments + strAEComments + strIEComments + strOtherComments;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strComments;
        }

        #endregion


        #region Comments related methods for Xml

        private static string GetFormattedComments(string _comments)
        {
            string strComments = "";
            try
            {
                if (!string.IsNullOrEmpty(_comments.Trim()))
                {
                    //Get CAS consulted for comments
                    strComments = strComments.Trim() + " " + GetCASConsultedForErrorCommentsFromComments(_comments.Trim());

                    //Get Author Error comments
                    strComments = strComments.Trim() + " " + GetAuthorErrorCommentsFromComments(_comments.Trim());

                    //Get Indexing Error comments
                    strComments = strComments.Trim() + " " + GetIndexingErrorCommentsFromComments(_comments.Trim());

                    //Get Other comments
                    strComments = strComments.Trim() + " " + GetOtherCommentsFromComments(_comments.Trim());

                    if (string.IsNullOrEmpty(strComments.Trim()))
                    {
                        strComments = "~~";
                    }
                }
                else
                {
                    strComments = "~~";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strComments.Trim();
        }

        private static string GetOtherCommentsFromComments(string comments)
        {
            string strOtherComments = "";
            try
            {
                if (!string.IsNullOrEmpty(comments.Trim()))
                {
                    string strDefltCmnts = "";
                    string strTempCmnts = "";
                    string strOtherCmnts = "";

                    if (comments.Contains("<OE>") && comments.Contains("</OE>"))
                    {
                        Regex regEx = new Regex("<OE>(.*?)</OE>");
                        var vAE = regEx.Match(comments);
                        string strComments = vAE.Groups[1].ToString();

                        if (!string.IsNullOrEmpty(strComments))
                        {
                            //Multiple other comments are delimited by '~OE~'
                            string[] saCmnts = strComments.Split(new string[] { "~OE~" }, StringSplitOptions.RemoveEmptyEntries);
                            if (saCmnts != null)
                            {
                                for (int i = 0; i < saCmnts.Length; i++)
                                {
                                    strDefltCmnts = "";
                                    strTempCmnts = "";
                                    strOtherCmnts = "";
                                    strOtherCmnts = "";

                                    strOtherCmnts = saCmnts[i].Trim();
                                    if (strOtherCmnts.Trim().Contains("~~") || strOtherCmnts.Trim().Contains("`"))
                                    {
                                        Regex rgOther = new Regex("^(?<defltcmnts>[^~]*)~~(?<tmpcmnts>[^`]*)`(?<usrcmnts>.*)$");
                                        var vOUC = rgOther.Match(strOtherCmnts);
                                        if (vOUC.Groups.Count == 4)
                                        {
                                            strDefltCmnts = GetRequiredDefaultComments(vOUC.Groups["defltcmnts"].Value.ToString().Trim());
                                            strTempCmnts = vOUC.Groups["tmpcmnts"].Value.ToString();
                                            strOtherCmnts = vOUC.Groups["usrcmnts"].Value.ToString();

                                            if (!string.IsNullOrEmpty(strDefltCmnts.Trim()) && !strDefltCmnts.Trim().EndsWith("."))
                                            {
                                                strDefltCmnts = strDefltCmnts.Trim() + ".";
                                            }

                                            if (!string.IsNullOrEmpty(strTempCmnts.Trim()) && !strTempCmnts.Trim().EndsWith("."))
                                            {
                                                strTempCmnts = strTempCmnts.Trim() + ".";
                                            }

                                            if (!string.IsNullOrEmpty(strOtherCmnts.Trim()) && !strOtherCmnts.Trim().EndsWith("."))
                                            {
                                                strOtherCmnts = strOtherCmnts.Trim() + ".";
                                            }

                                            strOtherComments = !string.IsNullOrEmpty(strDefltCmnts.Trim()) ? strOtherComments.Trim() + " Other comment: " + strDefltCmnts.Trim() : strOtherComments.Trim();
                                            strOtherComments = !string.IsNullOrEmpty(strTempCmnts.Trim()) ? strOtherComments.Trim() + " Other comment: " + strTempCmnts.Trim() : strOtherComments.Trim();
                                            strOtherComments = !string.IsNullOrEmpty(strOtherCmnts.Trim()) ? strOtherComments.Trim() + " Other comment: " + strOtherCmnts.Trim() : strOtherComments.Trim();
                                        }
                                    }
                                    else
                                    {
                                        strOtherCmnts = GetRequiredDefaultComments(strOtherCmnts.Trim());
                                        strOtherComments = !string.IsNullOrEmpty(strOtherCmnts.Trim()) ? strOtherComments.Trim() + " Other comment: " + strOtherCmnts.Trim() : strOtherComments.Trim();
                                    }
                                }
                            }
                        }
                    }
                    else if (comments.Trim().Contains("~~") || comments.Trim().Contains("`"))
                    {
                        Regex rgOther = new Regex("^(?<defltcmnts>[^~]*)~~(?<tmpcmnts>[^`]*)`(?<usrcmnts>.*)$");
                        var vOUC = rgOther.Match(comments);
                        if (vOUC.Groups.Count == 4)
                        {
                            strDefltCmnts = GetRequiredDefaultComments(vOUC.Groups["defltcmnts"].Value.ToString().Trim());
                            strTempCmnts = vOUC.Groups["tmpcmnts"].Value.ToString();
                            strOtherCmnts = vOUC.Groups["usrcmnts"].Value.ToString();

                            if (!string.IsNullOrEmpty(strDefltCmnts.Trim()) && !strDefltCmnts.Trim().EndsWith("."))
                            {
                                strDefltCmnts = strDefltCmnts.Trim() + ".";
                            }

                            if (!string.IsNullOrEmpty(strTempCmnts.Trim()) && !strTempCmnts.Trim().EndsWith("."))
                            {
                                strTempCmnts = strTempCmnts.Trim() + ".";
                            }

                            if (!string.IsNullOrEmpty(strOtherCmnts.Trim()) && !strOtherCmnts.Trim().EndsWith("."))
                            {
                                strOtherCmnts = strOtherCmnts.Trim() + ".";
                            }

                            strOtherComments = !string.IsNullOrEmpty(strDefltCmnts.Trim()) ? strOtherComments.Trim() + " Other comment: " + strDefltCmnts.Trim() : strOtherComments.Trim();
                            strOtherComments = !string.IsNullOrEmpty(strTempCmnts.Trim()) ? strOtherComments.Trim() + " Other comment: " + strTempCmnts.Trim() : strOtherComments.Trim();
                            strOtherComments = !string.IsNullOrEmpty(strOtherCmnts.Trim()) ? strOtherComments.Trim() + " Other comment: " + strOtherCmnts.Trim() : strOtherComments.Trim();
                        }
                    }
                    else
                    {
                        strOtherCmnts = GetRequiredDefaultComments(comments.Trim());
                        strOtherComments = !string.IsNullOrEmpty(strOtherCmnts.Trim()) ? strOtherComments.Trim() + " Other comment: " + strOtherCmnts.Trim() : strOtherComments.Trim();
                    }                   
                }
                else
                {
                    strOtherComments = "~~";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strOtherComments.Trim();
        }

        private static string GetRequiredDefaultComments(string comments)
        {
            string strDefltCmnts = "";
            try
            {
                if (!string.IsNullOrEmpty(comments))
                {
                    strDefltCmnts = comments.Trim();

                    if (strDefltCmnts.Trim().StartsWith("~~reaction"))
                    {
                        strDefltCmnts = strDefltCmnts.Remove(0, 2);
                    }

                    //Default comments removal
                    strDefltCmnts = strDefltCmnts.Replace("8000 and 8500 used as reactant", "@#$");
                    strDefltCmnts = strDefltCmnts.Replace("8000 and 8500 used as product", "@#$");
                    strDefltCmnts = strDefltCmnts.Replace("8000 used as product and reactant", "@#$");
                    strDefltCmnts = strDefltCmnts.Replace("8500 used as product and reactant", "@#$");
                    strDefltCmnts = strDefltCmnts.Replace("8000 used as reactant", "@#$");
                    strDefltCmnts = strDefltCmnts.Replace("8500 used as reactant", "@#$");
                    strDefltCmnts = strDefltCmnts.Replace("8000 used as product", "@#$");
                    strDefltCmnts = strDefltCmnts.Replace("8500 used as product", "@#$");
                    strDefltCmnts = strDefltCmnts.Replace("@#$, @#$", "");
                    strDefltCmnts = strDefltCmnts.Replace("@#$,@#$", "");
                    strDefltCmnts = strDefltCmnts.Replace("@#$.", "");
                    strDefltCmnts = strDefltCmnts.Replace("@#$", "");
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strDefltCmnts.Trim();
        }

        private static string GetIndexingErrorCommentsFromComments(string comments)
        {
            string strComments = "";
            try
            {
                if (!string.IsNullOrEmpty(comments.Trim()))
                {
                    //Get only Indexing comments
                    if (comments.Contains("<IE>") && comments.Contains("</IE>"))
                    {
                        Regex regEx = new Regex("<IE>(.*?)</IE>");
                        var vAE = regEx.Match(comments);
                        strComments = vAE.Groups[1].ToString();

                        //int intStIndx = strComments.IndexOf("<IE>");
                        //int intEndIndx = strComments.IndexOf("</IE>");
                        //if (intEndIndx > intStIndx)
                        //{
                        //    strComments = strComments.Substring((intStIndx + 4), (intEndIndx - (intStIndx + 4)));
                        //}

                        strComments = strComments.Trim().Replace("~IE~", ". Indexing error: ");
                        strComments = !strComments.StartsWith("Indexing error:") ? "Indexing error: " + strComments : strComments;
                        strComments = strComments.Trim().Replace("`", " ");

                        //End with .
                        strComments = !strComments.Trim().EndsWith(".") ? strComments.Trim() + "." : strComments.Trim();
                    }
                }
                else
                {
                    strComments = "~~";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strComments.Trim();
        }

        private static string GetAuthorErrorCommentsFromComments(string comments)
        {
            string strComments = "";
            try
            {
                if (!string.IsNullOrEmpty(comments.Trim()))
                {
                    //Get only Author Error comments
                    if (comments.Contains("<AE>") && comments.Contains("</AE>"))
                    {
                        Regex regEx = new Regex("<AE>(.*?)</AE>");
                        var vAE = regEx.Match(comments);
                        strComments = vAE.Groups[1].ToString();

                        //int intStIndx = strComments.IndexOf("<AE>");
                        //int intEndIndx = strComments.IndexOf("</AE>");
                        //if (intEndIndx > intStIndx)
                        //{
                        //    strComments = strComments.Substring((intStIndx + 4), (intEndIndx - (intStIndx + 4)));
                        //}

                        strComments = strComments.Trim().Replace("~AE~", ". Author error: ");
                        strComments = !strComments.StartsWith("Author error:") ? "Author error: " + strComments.Trim() : strComments.Trim();
                        strComments = strComments.Trim().Replace("`", " ");

                        //End with .
                        strComments = !strComments.Trim().EndsWith(".") ? strComments.Trim() + "." : strComments.Trim();
                    }
                }
                else
                {
                    strComments = "~~";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strComments.Trim();
        }

        private static string GetCASConsultedForErrorCommentsFromComments(string comments)
        {
            string strComments = "";
            try
            {
                if (!string.IsNullOrEmpty(comments.Trim()))
                {
                    //Get only CAS Error comments
                    if (comments.Contains("<CE>") && comments.Contains("</CE>"))
                    {
                        Regex regEx = new Regex("<CE>(.*?)</CE>");
                        var vAE = regEx.Match(comments);
                        strComments = vAE.Groups[1].ToString();

                        //int intStIndx = strComments.IndexOf("<CE>");
                        //int intEndIndx = strComments.IndexOf("</CE>");

                        //if (intEndIndx > intStIndx)
                        //{
                        //    strComments = strComments.Substring((intStIndx + 4), (intEndIndx - (intStIndx + 4)));
                        //}

                        strComments = strComments.Trim().Replace("~CE~", ". CAS consulted for ");
                        strComments = !strComments.StartsWith("CAS consulted for") ? "CAS consulted for " + strComments.Trim() : strComments.Trim();

                        //End with .
                        strComments = !strComments.Trim().EndsWith(".") ? strComments.Trim() + "." : strComments.Trim();
                    }
                }
                else
                {
                    strComments = "~~";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strComments.Trim();
        }

        #endregion
    }
}
