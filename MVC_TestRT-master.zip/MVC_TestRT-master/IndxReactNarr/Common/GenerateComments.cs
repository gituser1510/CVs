﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace IndxReactNarr.Common
{
    class GenerateComments
    {
        #region 8000, 8500 Comments Methods
        
        public static string GetComments_On_8000_8500(int p_8000, int p_8500, int r_8000, int r_8500)
        {
            string strComments = "";
            try
            {
                if (p_8000 > 0 && p_8500 > 0 && r_8000 > 0 && r_8500 > 0)
                {
                    strComments = "8000 used as product and reactant, 8500 used as product and reactant";
                }
                else if (p_8000 > 0 && p_8500 > 0 && r_8000 > 0 && r_8500 == 0)
                {
                    strComments = "8000 used as product and reactant, 8500 used as product";
                }
                else if (p_8000 > 0 && p_8500 == 0 && r_8000 > 0 && r_8500 > 0)
                {
                    strComments = "8000 used as product and reactant, 8500 used as reactant";
                }
                else if (p_8000 == 0 && p_8500 > 0 && r_8000 > 0 && r_8500 > 0)
                {
                    strComments = "8500 used as product and reactant, 8000 used as reactant";
                }
                else if (p_8000 > 0 && p_8500 > 0 && r_8000 == 0 && r_8500 > 0)
                {
                    strComments = "8500 used as product and reactant, 8000 used as product";
                }
                else if (p_8000 > 0 && p_8500 > 0 && r_8000 == 0 && r_8500 == 0)
                {
                    strComments = "8000 and 8500 used as product";
                }
                else if (p_8000 == 0 && p_8500 == 0 && r_8000 > 0 && r_8500 > 0)
                {
                    strComments = "8000 and 8500 used as reactant";
                }
                else if (p_8000 > 0 && p_8500 == 0 && r_8000 > 0 && r_8500 == 0)
                {
                    strComments = "8000 used as product and reactant";
                }
                else if (p_8000 == 0 && p_8500 > 0 && r_8000 == 0 && r_8500 > 0)
                {
                    strComments = "8500 used as product and reactant";
                }
                else if (p_8000 > 0 && p_8500 == 0 && r_8000 == 0 && r_8500 == 0)
                {
                    strComments = "8000 used as product";
                }
                else if (p_8000 == 0 && p_8500 > 0 && r_8000 == 0 && r_8500 == 0)
                {
                    strComments = "8500 used as product";
                }
                else if (p_8000 == 0 && p_8500 == 0 && r_8000 > 0 && r_8500 == 0)
                {
                    strComments = "8000 used as reactant";
                }
                else if (p_8000 == 0 && p_8500 == 0 && r_8000 == 0 && r_8500 > 0)
                {
                    strComments = "8500 used as reactant";
                }
                else if (p_8000 > 0 && p_8500 == 0 && r_8000 == 0 && r_8500 > 0)
                {
                    strComments = "8000 used as product, 8500 used as reactant";
                }
                else if (p_8000 == 0 && p_8500 > 0 && r_8000 > 0 && r_8500 == 0)
                {
                    strComments = "8500 used as product, 8000 used as reactant";
                }

                return strComments;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strComments;
        } 
        
        #endregion

        #region +/- Temperature Comments Methods
        
        public static string GetCommentsOnTemperature(DataTable temperaturedata)
        {
            string strTempCmnts = "";
            try
            {
                if (temperaturedata != null)
                {
                    if (temperaturedata.Rows.Count > 0)
                    {
                        DataTable dtRxns_Filtered = null;
                        DataTable dtTemperture = null;
                        DataTable dtRxns = null;
                        DataTable dtStages_Unique = null;
                        DataTable dtTempVals = null;

                        string strRxnNUM = "";
                        string strFiltCond = "";
                        string strStageName = "";
                        string strTempVal = "";
                        string strStgTempInfo = "";
                        string[] saFiltCols = null;

                        int intStgCount = 0;

                        //Get Distinct Reactions                        
                        saFiltCols = new string[] { "RXN_NUM", "RXN_SEQ" };//NUM_Seq
                        dtRxns = GetUniqueValuesFromTable(temperaturedata, saFiltCols);

                        if (dtRxns != null)
                        {
                            for (int i = 0; i < dtRxns.Rows.Count; i++)
                            {                                
                                strRxnNUM = dtRxns.Rows[i][0].ToString();
                                string strRxnSeq = dtRxns.Rows[i][1].ToString();

                                if (!string.IsNullOrEmpty(strRxnNUM))
                                {
                                    //Get Stages on RxnNUM
                                    //strFiltCond = "NUM_Seq = '" + strRxnNUM + "'";
                                    strFiltCond = "RXN_NUM = " + strRxnNUM + " and RXN_SEQ = " + strRxnSeq + "";
                                    dtRxns_Filtered = GetFilteredDataFromTable(temperaturedata, strFiltCond);

                                    if (dtRxns_Filtered != null)
                                    {
                                        if (dtRxns_Filtered.Rows.Count > 0)
                                        {
                                            intStgCount = Convert.ToInt32(dtRxns_Filtered.Rows[0]["RXN_STAGE_COUNT"].ToString());//stage_count

                                            //Get Distinct Stages in the Reaction Conditions                                     
                                            saFiltCols = new string[] { "STAGE" };//Stage
                                            dtStages_Unique = GetUniqueValuesFromTable(dtRxns_Filtered, saFiltCols);

                                            if (dtStages_Unique != null)
                                            {
                                                strStgTempInfo = "";

                                                //For each Stage in the Reaction
                                                for (int j = 0; j < dtStages_Unique.Rows.Count; j++)
                                                {
                                                    strStageName = dtStages_Unique.Rows[j]["STAGE"].ToString();
                                                    if (!string.IsNullOrEmpty(strStageName))
                                                    {
                                                        //Get Temperature based on Stage
                                                        strFiltCond = "STAGE = '" + strStageName + "'";
                                                        dtTemperture = GetFilteredDataFromTable(dtRxns_Filtered, strFiltCond);

                                                        if (dtTemperture != null)
                                                        {
                                                            //Get Distinct Temperatures                                                  
                                                            saFiltCols = new string[] { "TEMPERATURE" };
                                                            dtTempVals = GetUniqueValuesFromTable(dtTemperture, saFiltCols);

                                                            //Get Temperature string from Table
                                                            strTempVal = GetTemperatureStringFromTable(dtTempVals);
                                                        }

                                                        if (!string.IsNullOrEmpty(strTempVal))
                                                        {
                                                            if (intStgCount == 1)
                                                            {
                                                                if (string.IsNullOrEmpty(strStgTempInfo))
                                                                {
                                                                    strStgTempInfo = "needs " + strTempVal;
                                                                }
                                                                else
                                                                {
                                                                    strStgTempInfo = strStgTempInfo.Trim() + ", " + " needs " + strTempVal;
                                                                }
                                                            }
                                                            else if (intStgCount > 1)
                                                            {
                                                                if (string.IsNullOrEmpty(strStgTempInfo))
                                                                {
                                                                    strStgTempInfo = strStageName + " should be " + strTempVal;
                                                                }
                                                                else
                                                                {
                                                                    strStgTempInfo = strStgTempInfo.Trim() + ", " + strStageName + " should be " + strTempVal;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                if (!string.IsNullOrEmpty(strStgTempInfo))
                                                {
                                                    strStgTempInfo = "NUM-SEQ " + strRxnNUM + "-" + strRxnSeq + " " + strStgTempInfo;//New code on 8th Apr 2013
                                                }
                                            }
                                        }
                                    }

                                    strTempCmnts = string.IsNullOrEmpty(strTempCmnts.Trim()) ? strStgTempInfo.Trim() : strTempCmnts.Trim() + ". " + strStgTempInfo.Trim();
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strTempCmnts;
        }

        private static DataTable GetUniqueValuesFromTable(DataTable rxndata, string[] filtercols)
        {
            DataTable dtUniqueVals = null;
            try
            {
                if (rxndata != null && filtercols != null)
                {
                    DataView dvTemp = rxndata.DefaultView;
                    if (dvTemp != null)
                    {
                        dtUniqueVals = dvTemp.ToTable(true, filtercols);
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtUniqueVals;
        }

        private static DataTable GetFilteredDataFromTable(DataTable rxndata, string filtercond)
        {
            DataTable dtFiltered = null;
            try
            {
                if (rxndata != null && !string.IsNullOrEmpty(filtercond))
                {
                    DataView dvTemp = rxndata.DefaultView;
                    dvTemp.RowFilter = filtercond;//"NUM-Seq = '" + strRxnNUM + "'";
                    dtFiltered = dvTemp.ToTable();
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtFiltered;
        }

        private static string GetTemperatureStringFromTable(DataTable tempdata)
        {
            string strTemprature = "";
            try
            {
                if (tempdata != null)
                {
                    for (int i = 0; i < tempdata.Rows.Count; i++)
                    {
                        if (!string.IsNullOrEmpty(tempdata.Rows[i]["TEMPERATURE"].ToString()))
                        {
                            strTemprature = strTemprature.Trim() + " " + "TP=" + tempdata.Rows[i]["TEMPERATURE"].ToString().Trim();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strTemprature.Trim();
        } 
        
        #endregion
    }
}
