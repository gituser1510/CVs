﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using HtmlRichText;
using mshtml;
using SautinSoft;
using IndxReactNarr.Generic;

namespace IndxReactNarr
{
    public class Html_RtfConversions
    {       
        private static Html_RtfConversions _instance;               
        public static Html_RtfConversions Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Html_RtfConversions();

                    rtfTxtBox_Rtf = new HtmlRichTextBox();
                    rtfTxtBox_Html = new HtmlRichTextBox();
                    rtfTxtBox_Export = new HtmlRichTextBox();

                    objHtmlToRtf = new HtmlToRtf();
                    objRtfToHtml = new SautinSoft.RtfToHtml();
                }
                return _instance;
            }
        }

        static HtmlToRtf objHtmlToRtf;
        static RtfToHtml objRtfToHtml;           
        string htmlstring = string.Empty;
        string rtfstring = string.Empty;
        static HtmlRichTextBox rtfTxtBox_Rtf;
        static HtmlRichTextBox rtfTxtBox_Html;
        static HtmlRichTextBox rtfTxtBox_Export;

        static Dictionary<char, string> SpecialCharList = new Dictionary<char, string>();
        public Hashtable SplCharReplTbl { get; set; }
//Test
        /// <summary>
        /// Load key(Special char), value(Replace code).
        /// </summary>
        public Html_RtfConversions()
        {
            Initialize_Dictionary();
        }

        /// <summary>
        /// Replace font style with export formatted code
        /// </summary>
        /// <param name="rtf">rtf with font styles</param>
        /// <returns>rtf with replaced code for font styles</returns>
        public string ReplaceFontstyleWithCodes(string rtf)
        {
            HtmlRichTextBox htmltext = new HtmlRichTextBox();
            htmltext.Rtf = rtf;
            Font currentFont = htmltext.SelectionFont;

            for (int x = 0; x <= htmltext.TextLength - 1; x++)
            {

                htmltext.SelectionStart = x;
                htmltext.SelectionLength = 1;
                if (htmltext != null)
                {
                    //if (htmlRichTextBox1.IsSuperScript())
                    //{
                    //   // htmlRichTextBox1.SetSuperScript(false);
                    //    htmlRichTextBox1.SelectedText = "^^" + htmlRichTextBox1.SelectedText;
                    //    x += 2;
                    //}
                    // if (htmlRichTextBox1.IsSubScript())
                    //{
                    //  //  htmlRichTextBox1.SetSubScript(false);
                    //    htmlRichTextBox1.SelectedText = "^v" + htmlRichTextBox1.SelectedText;
                    //    x += 2;
                    //}
                    // if (htmlRichTextBox1.SelectionFont.Style == FontStyle.Italic)
                    //{
                    //   // htmlRichTextBox1.SelectionFont = new Font(currentFont.FontFamily, currentFont.Size, FontStyle.Regular);
                    //    htmlRichTextBox1.SelectedText = "^i" + htmlRichTextBox1.SelectedText;
                    //    x += 2;
                    //}
                    // if (htmlRichTextBox1.SelectionFont.Style == FontStyle.Bold)
                    //{
                    //  //  htmlRichTextBox1.SelectionFont = new Font(currentFont.FontFamily, currentFont.Size, FontStyle.Regular);
                    //    htmlRichTextBox1.SelectedText = "^b" + htmlRichTextBox1.SelectedText;
                    //    x += 2;
                    //}

                    if (htmltext.SelectionFont.Bold)
                    {
                        //strTarget = strTarget + "^b" + htmlRichTextBox1.SelectedText;  by jayendra
                        htmltext.SelectedText = "^b" + htmltext.SelectedText;
                        x += 2;
                        htmltext.Select(x, 1);
                    }
                    if (htmltext.SelectionFont.Italic)
                    {
                        //strTarget = strTarget + "^i" + htmlRichTextBox1.SelectedText;  by jayendra
                        htmltext.SelectedText = "^i" + htmltext.SelectedText;
                        x += 2;
                        htmltext.Select(x, 1);
                    }
                    //if (htmlRichTextBox1.SelectionCharOffset == 5)//Superscript by jayendra
                    if (htmltext.SelectionCharOffset == 4 || htmltext.IsSuperScript())//Superscript
                    {
                        //strTarget = strTarget + "^^" + htmlRichTextBox1.SelectedText; by jayendra
                        htmltext.SelectedText = "^^" + htmltext.SelectedText;
                        x += 2;
                        htmltext.Select(x, 1);
                    }
                    //if (htmlRichTextBox1.SelectionCharOffset == -5)//Superscript by jayendra
                    if (htmltext.SelectionCharOffset == -4 || htmltext.IsSubScript())//Superscript
                    {
                        //strTarget = strTarget + "^v" + htmlRichTextBox1.SelectedText;
                        htmltext.SelectedText = "^v" + htmltext.SelectedText;
                        x += 2;
                        htmltext.Select(x, 1);
                    }
                }
            }
            htmltext.SelectAll();
            htmltext.SelectionFont = new Font(currentFont.FontFamily, currentFont.Size, FontStyle.Regular);

            return htmltext.Rtf;
        }

        /// <summary>
        /// Save string to Text file
        /// </summary>
        /// <param name="text">String</param>
        /// <param name="path">Path to save</param>
        public void StringToTextFile(string text, string path)
        {
            File.WriteAllText(path, text);
        }
                
        public string GetRTFfromHTMLString(string html, bool preserveMultiline)
        {
            string strRtf = "";
            try
            {
                if (!String.IsNullOrEmpty(html))
                {
                    //rtfTxtBox_Html = new HtmlRichTextBox();

                    //html = html.Replace("?", " "); //Code commented by Sairam on 18th Nov 2013
                    html = html.Replace("<", "&lt;");
                    html = html.Replace(">", "&gt;");
                    html = html.Replace("&lt;bold&gt;", "<bold>");
                    html = html.Replace("&lt;/bold&gt;", "</bold>");
                    html = html.Replace("&lt;ital&gt;", "<ital>");
                    html = html.Replace("&lt;/ital&gt;", "</ital>");
                    html = html.Replace("&lt;sup&gt;", "<sup>");
                    html = html.Replace("&lt;/sup&gt;", "</sup>");
                    html = html.Replace("&lt;sub&gt;", "<sub>");
                    html = html.Replace("&lt;/sub&gt;", "</sub>");
                    html = html.Replace("<bold>", "<b>");
                    html = html.Replace("</bold>", "</b>");
                    html = html.Replace("<ital>", "<I>");
                    html = html.Replace("</ital>", "</I>");
                    html = html.Replace("<sup>", "<SUP>");
                    html = html.Replace("</sup>", "</SUP>");
                    html = html.Replace("<sub>", "<SUB>");
                    html = html.Replace("</sub>", "</SUB>");
//Test by 
                    //specify some options
                    objHtmlToRtf.OutputFormat = HtmlToRtf.eOutputFormat.Rtf;
                    objHtmlToRtf.Encoding = HtmlToRtf.eEncoding.AutoSelect;
                    objHtmlToRtf.PageStyle.PageSize.Letter();
                    objHtmlToRtf.PreserveAlignment = true;
                    objHtmlToRtf.FontFace = HtmlToRtf.eFontFace.f_Calibri;

                    htmlstring = string.Empty;
                    rtfstring = string.Empty;

                    if (preserveMultiline)
                    {
                        htmlstring = html.Replace("\r\n", "NEWlINE$NEWlINE");
                        rtfstring = objHtmlToRtf.ConvertString(htmlstring);
                        rtfstring = rtfstring.Replace("NEWlINE$NEWlINE", "\\par\r\n");
                    }
                    else
                    {
                        htmlstring = html;
                        rtfstring = objHtmlToRtf.ConvertString(htmlstring);
                    }

                    rtfTxtBox_Html.Rtf = rtfstring;

                    string strremovetext = rtfTxtBox_Html.Rtf;
                    rtfTxtBox_Html.Rtf = strremovetext;

                    RemoveTrialVersionstring("", rtfTxtBox_Html);

                    strRtf = rtfTxtBox_Html.Rtf.Replace(@"\par
\b\line\line\line\par
\cf2\ul\par", "");
                    return strRtf;

                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            finally
            {
                //if (rtfTxtBox_Html != null)
                //{
                //    rtfTxtBox_Html.Dispose();
                //}

                rtfTxtBox_Html.Rtf = null;
                rtfTxtBox_Html.Text = null;
            }
            return strRtf;
        }
        
        public string GetHTMLFromRTFString(string rtfText)
        {
            try
            {
                if (!string.IsNullOrEmpty(rtfText))
                {
                    //rtfTxtBox_Rtf = new HtmlRichTextBox();

                    rtfTxtBox_Rtf.Rtf = rtfText;

                    objRtfToHtml.OutputFormat = SautinSoft.eOutputFormat.HTML_401;
                    objRtfToHtml.Encoding = SautinSoft.eEncoding.UTF_8;

                    string rtfFile = rtfTxtBox_Rtf.Rtf.ToString();
                    string rtfString = rtfTxtBox_Rtf.Rtf.ToString();

                    rtfString = rtfString.Replace("?", " "); //Code commented by Sairam on 14th Nov 2013
                    rtfString = rtfString.Replace("<", "&lt;");
                    rtfString = rtfString.Replace(">", "&gt;");

                    string htmlString = objRtfToHtml.ConvertString(rtfString);
                    htmlString = ReplaceHTMLCharsInString(htmlString);

                    htmlString = GetBodyTagFromHtml(htmlString);

                    //string strremovestr1 = "Trial version can convert no more than 30000 symbols.";
                    //string strremovestr2 = "Get the full \r\nfeatured version!</A>";
                    //string strremovestr3 = "href=\"http://www.sautinsoft.com/convert-rtf-to-html/order.php\"";
                    string strTrial = "<div align=\"center\">Trial version can convert no more than 30000 symbols.<br><a href=\"http://www.sautinsoft.com/convert-rtf-to-html/order.php\">Get the full featured version!</a></div>";
                    #region MyRegion
                    ////htmlString = r.ConvertString(rtfString);
                    //htmlEditor.SelectAll();
                    //IHTMLSelectionObject objselection = htmlEditor.Document.selection;
                    //IHTMLTxtRange objrange = (IHTMLTxtRange)objselection.createRange();                              
                    ////htmlString = element.innerHTML;
                    //htmlString = objrange.htmlText; 
                    #endregion

                    htmlString = htmlString.Replace(strTrial, "");

                    //htmlString = htmlString.Replace(strremovestr1, "");
                    //htmlString = htmlString.Replace(strremovestr2, "");
                    //htmlString = htmlString.Replace(strremovestr3, "");

                    htmlString = RichTextValidations.RemoveHTMLTagsInString(htmlString);
                    htmlString = htmlString.Replace("&lt;", "<");
                    htmlString = htmlString.Replace("&gt;", ">");
                    htmlString = htmlString.Replace("&amp;", "&");

                    htmlString = htmlString.Replace("&nbsp;", " ").TrimEnd();
                    htmlString = htmlString.Replace("<bold></bold>", "");
                    htmlString = htmlString.Replace("<ital><bold></bold></ital>", "");
                    htmlString = htmlString.Replace("<ital></ital>", "");
                    htmlString = htmlString.Replace("<bold> </bold>", "");

                    //Zero width space
                    htmlString = htmlString.Replace("&#8203;", "").TrimEnd();

                    return htmlString;                   
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            finally
            {
                //if (rtfTxtBox_Rtf != null)
                //{
                //    rtfTxtBox_Rtf.Dispose();
                //}

                rtfTxtBox_Rtf.Rtf = null;
                rtfTxtBox_Rtf.Text = null;
            }
            return "";
        }

        public string GetFormattedRtfFromRtf(string rtfText, bool preserveMultiLines)
        {
            string formattedRtf = rtfText;
            try
            {
                if (!string.IsNullOrEmpty(rtfText))
                {
                    formattedRtf = GetHTMLFromRTFString(rtfText);
                    formattedRtf = GetRTFfromHTMLString(formattedRtf, preserveMultiLines);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return formattedRtf;
        }

        public string GetExportFormatStringFromHtmlString(string htmlText)
        {
            string strExport = "";
            try
            {
                if (!string.IsNullOrEmpty(htmlText))
                {
                    string strRtf = GetRTFfromHTMLString(htmlText, false);
                    if (!string.IsNullOrEmpty(strRtf))
                    {
                        //rtfTxtBox_Export = new HtmlRichText.HtmlRichTextBox();

                        try
                        {
                            rtfTxtBox_Export.Rtf = strRtf;
                        }
                        catch
                        {
                            rtfTxtBox_Export.Text = strRtf;
                        }

                        string strTemp = "";

                        if (rtfTxtBox_Export.Text != null)
                        {
                            for (int i = 0; i < rtfTxtBox_Export.Text.Length; i++)
                            {
                                rtfTxtBox_Export.SelectionStart = i;
                                rtfTxtBox_Export.SelectionLength = 1;

                                if (!string.IsNullOrEmpty(rtfTxtBox_Export.Text[i].ToString().Trim()))
                                {
                                    string sHtml = GetHTMLFromRTFString(rtfTxtBox_Export.SelectedRtf);
                                    if (!string.IsNullOrEmpty(sHtml))
                                    {
                                        if (sHtml.Contains("<bold>"))
                                        {
                                            strExport = strExport + "^b";
                                        }
                                        if (sHtml.Contains("<ital>"))
                                        {
                                            strExport = strExport + "^i";
                                        }
                                        if (sHtml.Contains("<sup>"))
                                        {
                                            strExport = strExport + "^^";
                                        }
                                        if (sHtml.Contains("<sub>"))
                                        {
                                            strExport = strExport + "^v";
                                        }

                                        #region MyRegion
                                        //if (rtb.SelectionFont.Bold)
                                        //{
                                        //    //strTarget = strTarget + "^b" + rtb.SelectedText;  
                                        //    strExport = strExport + "^b";
                                        //}
                                        //if (rtb.SelectionFont.Italic)
                                        //{
                                        //    //strTarget = strTarget + "^i" + rtb.SelectedText; 
                                        //    strExport = strExport + "^i";
                                        //}
                                        ////if (rtb.SelectionCharOffset == 5)//Superscript 
                                        //if (rtb.SelectionCharOffset == 4)//Superscript
                                        //{
                                        //    //strTarget = strTarget + "^^" + rtb.SelectedText; 
                                        //    strExport = strExport + "^^";
                                        //}
                                        ////if (rtb.SelectionCharOffset == -5)//Superscript
                                        //if (rtb.SelectionCharOffset == -4)//Subscript
                                        //{
                                        //    //strTarget = strTarget + "^v" + rtb.SelectedText;
                                        //    strExport = strExport + "^v";
                                        //} 
                                        #endregion

                                        strTemp = "";
                                        strTemp = ReplaceSpecialCharInString(rtfTxtBox_Export.SelectedText[0].ToString());

                                        if (!string.IsNullOrEmpty(strTemp))
                                        {
                                            strExport = strExport + strTemp;
                                        }
                                    }
                                }
                                else
                                {
                                    strExport = strExport + " ";
                                }
                            }
                        }

                        //\n\n^b\n^b\n^b\n^b\n
                        strExport = strExport.Replace("\n\n^b\n^b\n^b\n^b\n", "");                       
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            finally
            {
                //if (rtfTxtBox_Export != null)
                //{
                //    rtfTxtBox_Export.Dispose();
                //}

                rtfTxtBox_Export.Rtf = null;
                rtfTxtBox_Export.Text = null;
            }
            return strExport;
        }

        private string GetBodyTagFromHtml(string html)
        {
            string outputString = String.Empty;
            string patten = @"<body>(.|\n)*?</body>";
            MatchCollection collection = Regex.Matches(html, patten, RegexOptions.Multiline);
            if (Regex.Match(html, patten).Success)
            {
                outputString = collection[0].Value;
            }
            return outputString.Trim();
        }

        private string ReplaceHTMLCharsInString(string htmlstring)
        {
            string strHtml = htmlstring;
            try
            {
                if (SplCharReplTbl != null)
                {
                    foreach (string strkey in SplCharReplTbl.Keys)
                    {
                        if (strkey != "")
                        {
                            if (strHtml.Contains(strkey))
                            {
                                strHtml = strHtml.Replace(strkey, SplCharReplTbl[strkey].ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return strHtml;
        }

        public string GetConvertedXmlValueFromHtmlString(string _xmltag)
        {
            string strConvXml = _xmltag;
            try
            {
                if (!string.IsNullOrEmpty(strConvXml))
                {
                    //if (GlobalVariables.XMLConvTbl != null && GlobalVariables.XMLConvTbl.Rows.Count > 0)
                    //{
                    //    foreach (DataRow dr in GlobalVariables.XMLConvTbl.Rows)
                    //    {
                    //        strConvXml = strConvXml.Replace(dr["SPECIAL_CHAR"].ToString(), dr["REPLACEMENT_CHAR"].ToString());
                    //    }
                    //}

                    //Convert < and > in text to junk test
                    strConvXml = strConvXml.Replace("&lt;", "_&lt;_");
                    strConvXml = strConvXml.Replace("&gt;", "_&gt;_");

                    //Decode Html
                    strConvXml = System.Web.HttpUtility.HtmlDecode(strConvXml);

                    //Replace &
                    strConvXml = strConvXml.Replace("&", "&amp;");

                    //Reconvert junk text to < and >
                    strConvXml = strConvXml.Replace("_<_", "&lt;");
                    strConvXml = strConvXml.Replace("_>_", "&gt;");
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strConvXml;
        }

        #region Helper Methods

        /// <summary>
        /// Load key(Special char), value(Replace code).
        /// </summary>
        private void Initialize_Dictionary()
        {
            #region MyRegion
            ////SpecialCharList = new Dictionary<char, string>();
            //SpecialCharList.Clear();
            //SpecialCharList.Add('Å', "^f\"");  //Angstrom          // direct
            //SpecialCharList.Add('•', "^f0");   //center dot        // direct
            //SpecialCharList.Add('°', "^f'");  //degree             // direct
            //SpecialCharList.Add('®', "^f_");  //forward arrow      // Symbol
            //SpecialCharList.Add('≥', "^f>");  //greater than/equal // direct
            //SpecialCharList.Add('∞', "^f^finf"); //infinity        // Symbol
            //SpecialCharList.Add('≤', "^f<");     //less than/equal //direct
            //SpecialCharList.Add('±', "^f+");     //plus minus      //Symbol
            //SpecialCharList.Add('¬', "^f^frar"); //reverse arrow   //Symbol reverse arrow             
            //SpecialCharList.Add('Ö', "^f^fsqr"); //  square root   //Symbol            
            //SpecialCharList.Add('º', "^f3");    // Triple bond     //Symbol           
            //SpecialCharList.Add('=', "=");      //Double bond      //direct
            //SpecialCharList.Add('≠', "^f?");    //Not equal to     //direct
            //SpecialCharList.Add('Û', "^f^fdar");//Symbol Double arrow single
            //SpecialCharList.Add('«', "^f^fdar");//Symbol Double arrow double

            //SpecialCharList.Add('α', "^fa");
            //SpecialCharList.Add('β', "^fb");
            //SpecialCharList.Add('χ', "^fc");
            //SpecialCharList.Add('δ', "^fd");
            //SpecialCharList.Add('ε', "^fe");
            //SpecialCharList.Add('η', "^fh");
            //SpecialCharList.Add('γ', "^fg");
            //SpecialCharList.Add('ι', "^fi");
            //SpecialCharList.Add('κ', "^fk");
            //SpecialCharList.Add('λ', "^fl");
            //SpecialCharList.Add('μ', "^fm");
            //SpecialCharList.Add('ν', "^fn");
            //SpecialCharList.Add('ω', "^fo");
            //SpecialCharList.Add('ο', "^fq");
            //SpecialCharList.Add('φ', "^ff");
            //SpecialCharList.Add('π', "^fp");
            //SpecialCharList.Add('ψ', "^fv");
            //SpecialCharList.Add('ρ', "^fr");
            //SpecialCharList.Add('σ', "^fs");
            //SpecialCharList.Add('τ', "^ft");
            //SpecialCharList.Add('θ', "^fj");
            //SpecialCharList.Add('υ', "^fu");
            //SpecialCharList.Add('ξ', "^fx");
            //SpecialCharList.Add('ζ', "^fz");

            //SpecialCharList.Add('Α', "^fA");
            //SpecialCharList.Add('Β', "^fB");
            //SpecialCharList.Add('Χ', "^fC");
            //SpecialCharList.Add('Δ', "^fD");
            //SpecialCharList.Add('Ε', "^fE");
            //SpecialCharList.Add('Η', "^fH");
            //SpecialCharList.Add('Γ', "^fG");
            //SpecialCharList.Add('Ι', "^fI");
            //SpecialCharList.Add('Κ', "^fK");
            //SpecialCharList.Add('Λ', "^fL");
            //SpecialCharList.Add('Μ', "^fM");
            //SpecialCharList.Add('Ν', "^fN");
            //SpecialCharList.Add('Ω', "^fO");
            //SpecialCharList.Add('Ο', "^fQ");
            //SpecialCharList.Add('Φ', "^fF");
            //SpecialCharList.Add('Π', "^fP");
            //SpecialCharList.Add('Ψ', "^fV");
            //SpecialCharList.Add('Ρ', "^fR");
            //SpecialCharList.Add('Σ', "^fS");
            //SpecialCharList.Add('Τ', "^fT");
            //SpecialCharList.Add('Θ', "^fJ");
            //SpecialCharList.Add('Υ', "^fU");
            //SpecialCharList.Add('Ξ', "^fX");
            //SpecialCharList.Add('Ζ', "^fZ"); 
            #endregion

            SpecialCharList.Clear();
            SpecialCharList.Add('\u0391', "^fA");
            SpecialCharList.Add('\u0392', "^fB");
            SpecialCharList.Add('\u0393', "^fG");
            SpecialCharList.Add('\u0394', "^fD");
            SpecialCharList.Add('\u0395', "^fE");
            SpecialCharList.Add('\u0396', "^fZ");
            SpecialCharList.Add('\u0397', "^fH");
            SpecialCharList.Add('\u0398', "^fJ");
            SpecialCharList.Add('\u0399', "^fI");
            SpecialCharList.Add('\u039a', "^fK");
            SpecialCharList.Add('\u039b', "^fL");
            SpecialCharList.Add('\u039c', "^fM");
            SpecialCharList.Add('\u039d', "^fN");
            SpecialCharList.Add('\u039e', "^fX");
            SpecialCharList.Add('\u039f', "^fQ");
            SpecialCharList.Add('\u03a0', "^fP");
            SpecialCharList.Add('\u03a1', "^fR");
            SpecialCharList.Add('\u03a3', "^fS");
            SpecialCharList.Add('\u03a4', "^fT");
            SpecialCharList.Add('\u03a5', "^fU");
            SpecialCharList.Add('\u03a6', "^fF");
            SpecialCharList.Add('\u03a7', "^fC");
            SpecialCharList.Add('\u03a8', "^fV");
            SpecialCharList.Add('\u03a9', "^fO");

            SpecialCharList.Add('\u03b1', "^fa");
            SpecialCharList.Add('\u03b2', "^fb");
            SpecialCharList.Add('\u03b3', "^fg");
            SpecialCharList.Add('\u03b4', "^fd");
            SpecialCharList.Add('\u03b5', "^fe");
            SpecialCharList.Add('\u03b6', "^fz");
            SpecialCharList.Add('\u03b7', "^fh");
            SpecialCharList.Add('\u03b8', "^fj");
            SpecialCharList.Add('\u03b9', "^fi");
            SpecialCharList.Add('\u03ba', "^fk");
            SpecialCharList.Add('\u03bb', "^fl");
            SpecialCharList.Add('\u03bc', "^fm");
            SpecialCharList.Add('\u03bd', "^fn");
            SpecialCharList.Add('\u03be', "^fx");
            SpecialCharList.Add('\u03bf', "^fq");
            SpecialCharList.Add('\u03c0', "^fp");
            SpecialCharList.Add('\u03c1', "^fr");
            SpecialCharList.Add('\u03c3', "^fs");
            SpecialCharList.Add('\u03c4', "^ft");
            SpecialCharList.Add('\u03c5', "^fu");
            SpecialCharList.Add('\u03c6', "^ff");
            SpecialCharList.Add('\u03c7', "^fc");
            SpecialCharList.Add('\u03c8', "^fv");
            SpecialCharList.Add('\u03c9', "^fo");

            SpecialCharList.Add('\u00c5', "^f\"");//Angstrom
            SpecialCharList.Add('\u00b0', "^f'");//Degrees
            SpecialCharList.Add('\u2022', "^f0");//Center dot          
            SpecialCharList.Add('\u2265', "^f>");//Greater than/equal
            SpecialCharList.Add('\u2264', "^f<");//Less than / equal
            SpecialCharList.Add('\u221e', "^f^finf");//Infinity
            SpecialCharList.Add('\u2260', "^f?");//Not Equal to
            SpecialCharList.Add('\u003d', "=");//Equal to
            SpecialCharList.Add('\u00ab', "^f^fdar");//Double Arrow
            SpecialCharList.Add('\u00ac', "^f^frar");//Reverse Arrow
            SpecialCharList.Add('\u2190', "^f^frar");//Reverse Arrow
            SpecialCharList.Add('\u00ae', "^f_");//Forward arrow
            SpecialCharList.Add('\u2192', "^f_");//Forward arrow
            //SpecialCharList.Add('\u00ba', "^f3");//Triple bond
            SpecialCharList.Add('\u2261', "^f3");//Triple bond
            SpecialCharList.Add('\u00db', "^f^fdar");//Double Arrow
            SpecialCharList.Add('\u21D4', "^f^fdar");//Double Arrow
            SpecialCharList.Add('\u2194', "^f^fdar");//Double Arrow           
            SpecialCharList.Add('\u00d6', "^f^fsqr");//Square Root
            SpecialCharList.Add('\u221A', "^f^fsqr");//Square Root
            SpecialCharList.Add('\u00b1', "^f+");//Plus minus
        }

        int _indexOfSearchText = 0;
        int _start = 0;
        private void RemoveTrialVersionstring(string strrtfstring, HtmlRichTextBox rtbox)
        {
            string str1 = "________________________________________________________";
            string str2 = "Trial version converts only first 100000 characters. Evaluation only.";
            string str3 = "Converted by HTML-to-RTF Pro DLL .Net 3.5.4.21.";
            string str4 = "(Licensed version doesn't display this notice!)";
            string str5 = "- Get license for the HTML-to-RTF Pro DLL .Net <http://www.sautinsoft.com/products/html-to-rtf/order.php>";
            string str6 = "\n\n\n\n\n\n";

            string[] strvalues = new string[6] { str1, str2, str3, str4, str5, str6 };
            try
            {

                foreach (string str in strvalues)
                {
                    if (rtbox.Text.Contains(str))
                    {
                        bool blnloop = false;
                        int startindex = 0;

                        _indexOfSearchText = 0;
                        _start = 0;
                        while (blnloop == false)
                        {

                            if (str.Length > 0)
                            {
                                startindex = FindMyText(str.Trim(), _start, rtbox.Text.Length, rtbox);
                                if (startindex == -1)
                                {
                                    blnloop = true;
                                }
                            }

                            if (startindex >= 0)
                            {
                                // Set the highlight color as red
                                int endindex = str.Length;
                                // Highlight the search string
                                rtbox.Select(startindex, endindex);
                                rtbox.SelectedRtf = "";
                                blnloop = true;
                                rtbox.SelectAll();
                                //start = startindex + endindex;
                                // continue;

                            }
                        }
                        continue;

                    }
                }

                //rtbox.Rtf = rtbox.Rtf.ToString().Replace("\r\n", "").Trim();
                //rtbox.Rtf = Regex.Replace(rtbox.Rtf, @"^\s*$\n|\r", "", RegexOptions.Multiline);
                //rtbox.Text = rtbox.Text.Trim();
                rtbox.Text.Trim();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        /// <summary>
        /// Find Text
        /// </summary>
        /// <param name="txtToSearch"></param>
        /// <param name="searchStart"></param>
        /// <param name="searchEnd"></param>
        /// <param name="rtb"></param>
        /// <returns></returns>
        private int FindMyText(string txtToSearch, int searchStart, int searchEnd, HtmlRichTextBox rtb)
        {
            // Unselect the previously searched string
            //if (searchStart > 0 && searchEnd > 0 && indexOfSearchText >= 0)
            //{
            //    return -1;
            //   // rtb.Undo();
            //}

            // Set the return value to -1 by default.
            int retVal = -1;

            try
            {
                // A valid starting index should be specified.
                // if indexOfSearchText = -1, the end of search
                if (searchStart >= 0 && _indexOfSearchText >= 0)
                {
                    // A valid ending index
                    if (searchEnd > searchStart || searchEnd == -1)
                    {
                        rtb.Refresh();
                        // Find the position of search string in RichTextBox
                        _indexOfSearchText = rtb.Find(txtToSearch, searchStart, searchEnd, RichTextBoxFinds.None);
                        //indexOfSearchText = rtb.Find(txtToSearch);
                        // Determine whether the text was found in richTextBox1.
                        //if (indexOfSearchText != searchStart)
                        //{
                        // Return the index to the specified search text.
                        retVal = _indexOfSearchText;
                        //}
                        //else
                        //{
                        //    return -1;
                        //}
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return retVal;
        }

        private string ReplaceSpecialCharInString(string data)
        {
            string strReplace = data;
            try
            {
                if (SpecialCharList != null)
                {
                    foreach (char k in SpecialCharList.Keys)
                    {
                        if (strReplace.Contains(k.ToString()))
                        {
                            strReplace = strReplace.Replace(k.ToString(), SpecialCharList[k]);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strReplace;
        }

        #endregion
    }

    #region RichText Helper Class

    public static class RichTextValidations
    {
        public static string RemoveSpace(string strtext)
        {
            try
            {
                if (strtext != null)
                {
                    strtext = strtext.Replace("&nbsp;", " ");
                }
            }
            catch (Exception ex)
            {
                return strtext;
            }
            return strtext;
        }

        public static string FindAndReplaceStrings(string _strrichtextcontent, DataSet _dsFandR)
        {
            string strText = _strrichtextcontent;
            strText = strText.Replace("\n", " ");
            strText = strText.Replace("\r\n", " ");
            strText = strText.Replace("  ", " ");
            //strText = strText.Replace("&nbsp;", " ");

            try
            {
                if (_dsFandR != null && _dsFandR.Tables.Count > 0)
                {
                    if (_dsFandR.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i < _dsFandR.Tables[0].Rows.Count; i++)
                        {
                            strText = CheckandReplaceContent(strText, _dsFandR.Tables[0].Rows[i]["NAME"].ToString(), _dsFandR.Tables[0].Rows[i]["VALUE"].ToString());
                        }
                        return strText;
                    }
                }
            }
            catch (Exception ex)
            {
                //Exceptions.CASExceptions.WriteErrorLog(ex.ToString());
                return _strrichtextcontent;
            }
            return _strrichtextcontent;
        }

        private static string CheckandReplaceContent(string _richtxt, string strkey, string strvalue)
        {
            try
            {
                if (_richtxt.Contains(strkey))
                {
                    _richtxt = _richtxt.Replace(strkey, strvalue);
                    return _richtxt;
                }
                else
                    return _richtxt;
            }
            catch (Exception ex)
            {
                // Exceptions.CASExceptions.WriteErrorLog(ex.ToString());
                return _richtxt;
            }
            return _richtxt;
        }

        public static string FindAndReplaceSymbolstring(string _strrichtextcontent, System.Collections.Hashtable _dsFandR)
        {
            string strText = _strrichtextcontent.Replace("\n", " ");
            strText = strText.Replace("\r\n", " ");
            strText = strText.Replace("  ", " ");
            try
            {
                if (_dsFandR != null && _dsFandR.Count > 0)
                {
                    foreach (DictionaryEntry de in _dsFandR)
                    {
                        strText = CheckandReplaceContent(strText, de.Key.ToString(), de.Value.ToString());

                    }
                    return strText;
                }
            }
            catch (Exception ex)
            {
                //   Exceptions.CASExceptions.WriteErrorLog(ex.ToString());
                return _strrichtextcontent;
            }
            return _strrichtextcontent;
        }

        public static string FindAndReplaceSymbolforXMLstring(string _strrichtextcontent, System.Collections.Hashtable _dsFandR)
        {
            string strText = _strrichtextcontent;
            try
            {
                if (_dsFandR != null && _dsFandR.Count > 0)
                {
                    foreach (DictionaryEntry de in _dsFandR)
                    {
                        strText = CheckandReplaceContent(strText, de.Key.ToString(), de.Value.ToString());

                    }
                    return ReplaceGreaterandLessthan(strText);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());               
                return _strrichtextcontent;
            }
            return ReplaceGreaterandLessthan(_strrichtextcontent);
        }

        public static string ReplaceGreaterandLessthan(string str)
        {
            try
            {
                str = str.Replace("<", "&lt;");
                str = str.Replace(">", "&gt;");

                Hashtable allist = new Hashtable();
                allist.Add("&lt;bold&gt;", "<bold>");
                allist.Add("&lt;/bold&gt;", "</bold>");
                allist.Add("&lt;ital&gt;", "<ital>");
                allist.Add("&lt;/ital&gt;", "</ital>");
                allist.Add("&lt;sup&gt;", "<sup>");
                allist.Add("&lt;/sup&gt;", "</sup>");
                allist.Add("&lt;sub&gt;", "<sub>");
                allist.Add("&lt;/sub&gt;", "</sub>");
                
                foreach (string strkey in allist.Keys)
                {
                    str = str.Replace(strkey, allist[strkey].ToString());
                }
                str = str.Replace("&", "&amp;");
                str = str.Replace("&amp;#", "&#");
                str = str.Replace("&amp;lt;", "&lt;");
                str = str.Replace("&amp;gt;", "&gt;");               
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return str;
        }

        public static string GetStringReplaceSupscript(string inputtext)
        {
            inputtext = inputtext.Replace("<SUP>", "<sup>");
            inputtext = inputtext.Replace("</SUP>", "</sup>");
            inputtext = inputtext.Replace("<sup>", "<sup>");
            inputtext = inputtext.Replace("</sup>", "</sup>");
            return inputtext;
        }

        private static string GetStringReplaceSubscript(string inputtext)
        {
            inputtext = inputtext.Replace("<SUB>", "<sub>");
            inputtext = inputtext.Replace("</SUB>", "</sub>");
            inputtext = inputtext.Replace("<sub>", "<sub>");
            inputtext = inputtext.Replace("</sub>", "</sub>");
            return inputtext;
        }

        private static string GetStringReplaceItalic(string inputtext)
        {
            inputtext = inputtext.Replace("<I>", "<ital>");
            inputtext = inputtext.Replace("</I>", "</ital>");
            inputtext = inputtext.Replace("<EM>", "<ital>");
            inputtext = inputtext.Replace("</EM>", "</ital>");
            inputtext = inputtext.Replace("<i>", "<ital>");
            inputtext = inputtext.Replace("</i>", "</ital>");
            return inputtext;
        }

        private static string GetStringReplaceBold(string inputtext)
        {
            string _strval = inputtext;
            _strval = _strval.Replace("<STRONG>", "<bold>");
            _strval = _strval.Replace("</STRONG>", "</bold>");
            _strval = _strval.Replace("<B>", "<bold>");
            _strval = _strval.Replace("</B>", "</bold>");
            _strval = _strval.Replace("<b>", "<bold>");
            _strval = _strval.Replace("</b>", "</bold>");

            return _strval;
        }

        private static string RemoveEmptyBoldTags(string _strtext)
        {
            if (_strtext.Contains("<bold></bold>"))
            {
                _strtext = _strtext.Replace("<bold></bold>", "");
            }
            return _strtext;
        }

        static Regex docType = new Regex("</?(?:HTML|HEAD|o:p|SPAN|BODY|DIV|TITLE|BR|FONT|P|DL|DT|DD|H1|H2|H3|H4|H5|H6|U)[^>]*>", RegexOptions.IgnoreCase | RegexOptions.Multiline);
        static Regex fonyMatch = new Regex("</?\\w+\\s+[^>]*>", RegexOptions.IgnoreCase | RegexOptions.Singleline);

        public static string RemoveHTMLTagsInString(string input)
        {
            string output = input;
            try
            {
                if (!string.IsNullOrEmpty(input))
                {                   

                    //Regex docType = new Regex("<[/]{0,1}(HTML|HEAD|o:p|SPAN|BODY|DIV|TITLE|BR|FONT|P|DL|DT|DD|H1|H2|H3|H4|H5|H6|U){1}[.]*>", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                    
                    output = docType.Replace(output, "");                                        
                    output = fonyMatch.Replace(output, "");

                    output = GetStringReplaceSupscript(output);
                    output = GetStringReplaceSubscript(output);
                    output = GetStringReplaceBold(output);
                    output = GetStringReplaceItalic(output);

                    //output = output.Replace("\r\n", " ");
                    output = output.Replace("  ", " ").Trim();                   
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return output;
        }
    }

    #endregion
}
