﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using IndxReactNarr.Generic;
using System.Data;
using System.Text.RegularExpressions;
using System.Drawing;
using System.IO;
using System.Drawing.Imaging;
using IndxReactNarr;
using System.Globalization;

namespace IndxReactNarr.Common
{
    class DataConversions
    {        
        public static ArrayList GetArrayListFromDataTable(DataTable _dtTanIds, int colindex)
        {
            try
            {
                if (_dtTanIds != null)
                {
                    ArrayList lstTANIds = new ArrayList();
                    if (_dtTanIds.Rows.Count > 0)
                    {
                        for (int i = 0; i < _dtTanIds.Rows.Count; i++)
                        {
                            if (!lstTANIds.Contains(_dtTanIds.Rows[i][colindex].ToString()))
                            {
                                lstTANIds.Add(_dtTanIds.Rows[i][colindex].ToString());
                            }
                        }
                    }
                    return lstTANIds;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return null;
        }

        public static bool IsValidTanNumber(string tanNumString)
        {
            bool blStatus = false;
            try
            {
                string strRegEx = "[1-9][0-9]{7}[A-HJ-KM-NP-Z]";
                //Regex regExp = new Regex("[0-9]{8}[A-Z]{1}$", RegexOptions.Singleline);
                Regex regExp = new Regex(strRegEx, RegexOptions.Singleline);
                MatchCollection matchColl = regExp.Matches(tanNumString);

                if (matchColl.Count == 1)
                {
                    blStatus = true;
                }
                else
                {
                    blStatus = false;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        public static int GetRoleIDByRoleName(string _rolename)
        {
            int intRoleId = 0;
            try
            {
                DataTable dtRoles = GlobalVariables.User_Roles;
                if (dtRoles != null)
                {
                    if (dtRoles.Rows.Count > 0)
                    {
                        DataRow[] dtRowArr = dtRoles.Select("role = '" + _rolename + "'");
                        if (dtRowArr != null)
                        {
                            if (dtRowArr.Length > 0)
                            {
                                intRoleId = Convert.ToInt32(dtRowArr[0]["role id"]);
                                return intRoleId;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return intRoleId;
        }

        #region Image conversion related methods

        public static byte[] ImageToByteArray(System.Drawing.Image imageIn)
        {
            byte[] baImage = null; 
            try
            {
                using (Image img = new Bitmap(imageIn))
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        img.Save(ms, System.Drawing.Imaging.ImageFormat.Gif);
                        baImage = ms.ToArray();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return baImage;
        }

        public static Image ByteArrayToImage(byte[] byteArrayIn)
        {
            Image returnImage = null;
            try
            {
                if (byteArrayIn != null)
                {
                    using (MemoryStream ms = new MemoryStream(byteArrayIn))
                    {
                        returnImage = Image.FromStream(ms);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return returnImage;
        }

        #endregion 

        public static string EscapeSpecialCharsInFilterCondition(string filtervalue)
        {
            string filterCond = "";
            try
            {
                if (!string.IsNullOrEmpty(filtervalue))
                {
                    StringBuilder sb = new StringBuilder(filtervalue.Length);
                    for (int i = 0; i < filtervalue.Length; i++)
                    {
                        char c = filtervalue[i];
                        switch (c)
                        {
                            case ']':

                            case '[':

                                sb.Append("[").Append(c).Append("]");
                                break;

                            default:
                                if (c.ToString().Contains("'"))
                                {
                                    sb.Append("'").Append(c).Append("'");
                                }
                                if (c.ToString().Contains(""))
                                {
                                    sb.Append(c);
                                }
                                break;
                        }
                    }
                    filterCond = sb.ToString();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return filterCond;
        }
    }
}
