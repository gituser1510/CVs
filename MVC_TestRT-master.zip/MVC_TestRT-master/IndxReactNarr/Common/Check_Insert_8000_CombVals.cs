﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IndxReactNarr.Generic;

namespace IndxReactNarr.Common
{
    public static class Validate_Series_8500_8000_Vals
    {
        public static bool CheckAndInsert8000_CombData(string _tan,string _id, int _num8000, string _substname,
                                                   string _substloc,int _reaction,string _location,string _partpnt, 
                                                   out string o_reaction,out string o_location, out string o_partpnt)
        {
            bool blStatus = false;
            string strFilter = "";
            DataTable dt8000_Comb = null;
            try
            {

                if (Generic.GlobalVariables.TAN_Series8000Data == null)
                {
                    dt8000_Comb = CreateGlobalNum_RegTable();

                    AddNewRowToTable(ref dt8000_Comb, _tan, _id, _num8000, _substname, _substloc, _reaction, _location, _partpnt);
                    Generic.GlobalVariables.TAN_Series8000Data = dt8000_Comb;
                    blStatus = true;
                }
                else
                {
                    dt8000_Comb = Generic.GlobalVariables.TAN_Series8000Data;

                    strFilter = "TAN = '" + _tan + "' and ID = '" + _id + "'";
                    DataRow[] dtRowArr = dt8000_Comb.Select(strFilter);

                    if (dtRowArr.Length > 0)
                    {
                        strFilter = "TAN = '" + _tan + "' and P_8000 = " + _num8000;
                        DataRow[] dtRArr = dt8000_Comb.Select(strFilter);

                        if (dtRArr.Length > 0)
                        {
                            if (dtRArr[0]["ID"].ToString() != _id
                                && dtRArr[0]["SUBSTNAME"].ToString().ToUpper() != _substname.ToUpper()
                                && dtRArr[0]["SUBSTLOC"].ToString().ToUpper() != _substloc.ToUpper())
                            {
                                o_reaction = dtRArr[0]["REACTION"].ToString();
                                o_location = dtRArr[0]["LOCATION"].ToString();
                                o_partpnt = dtRArr[0]["PARTICIPANT"].ToString();

                                blStatus = false;
                                return blStatus;
                            }
                            else if (dtRArr[0]["ID"].ToString() != _id
                                && dtRArr[0]["SUBSTNAME"].ToString().ToUpper() == _substname.ToUpper()
                                && dtRArr[0]["SUBSTLOC"].ToString().ToUpper() == _substloc.ToUpper())
                            {
                                blStatus = true;
                            }
                            else if (dtRArr[0]["ID"].ToString() == _id
                                && dtRArr[0]["SUBSTNAME"].ToString().ToUpper() != _substname.ToUpper()
                                && dtRArr[0]["SUBSTLOC"].ToString().ToUpper() != _substloc.ToUpper())
                            {
                            
                            }
                            else
                            {
                                UpdateRowInTable(ref dt8000_Comb, _tan, _id, _num8000, _substname, _substloc, _reaction, _location, _partpnt);
                                Generic.GlobalVariables.TAN_Series8000Data = dt8000_Comb;
                                blStatus = true;
                            }
                        }
                        else
                        {
                            UpdateRowInTable(ref dt8000_Comb, _tan, _id, _num8000, _substname, _substloc, _reaction, _location, _partpnt);
                            Generic.GlobalVariables.TAN_Series8000Data = dt8000_Comb;
                            blStatus = true;
                        }
                    }
                    else
                    {
                        strFilter = "TAN = '" + _tan + "' and P_8000 = " + _num8000;
                        DataRow[] dtRArr = dt8000_Comb.Select(strFilter);
                        
                        if (dtRArr.Length > 0)
                        {
                            if (dtRArr[0]["ID"].ToString() != _id
                                && dtRArr[0]["SUBSTNAME"].ToString().ToUpper() != _substname.ToUpper()
                                && dtRArr[0]["SUBSTLOC"].ToString().ToUpper() != _substloc.ToUpper())
                            {
                                o_reaction = dtRArr[0]["REACTION"].ToString();
                                o_location = dtRArr[0]["LOCATION"].ToString();
                                o_partpnt = dtRArr[0]["PARTICIPANT"].ToString();

                                blStatus = false;
                                return blStatus;
                            }
                            else if (dtRArr[0]["ID"].ToString() != _id
                                && dtRArr[0]["SUBSTNAME"].ToString().ToUpper() == _substname.ToUpper()
                                && dtRArr[0]["SUBSTLOC"].ToString().ToUpper() == _substloc.ToUpper())
                            {
                                blStatus = true;
                            }
                            else if (dtRArr[0]["ID"].ToString() == _id)                                
                            {
                                DeleteRowFromTable(ref dt8000_Comb, _tan, _id, _num8000);
                                blStatus = true;
                            }
                        }
                        else
                        {
                            AddNewRowToTable(ref dt8000_Comb, _tan, _id, _num8000, _substname, _substloc, _reaction, _location, _partpnt);
                            Generic.GlobalVariables.TAN_Series8000Data = dt8000_Comb;
                            blStatus = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            o_reaction = "";
            o_location = "";
            o_partpnt = "";
            return blStatus;
        }

        private static void AddNewRowToTable(ref DataTable _dt8000_Comb, string _tan,string _ident, int _p_8000,
                           string _substname, string _substloc, int _reaction,string _location, string _partpnt)
        {
            try
            {
                DataRow dRow = _dt8000_Comb.NewRow();
                dRow["ID"] = _ident;
                dRow["TAN"] = _tan;
                dRow["P_8000"] = _p_8000;
                dRow["SUBSTNAME"] = _substname;
                dRow["SUBSTLOC"] = _substloc;
                dRow["REACTION"] = _reaction;
                dRow["LOCATION"] = _location;
                dRow["PARTICIPANT"] = _partpnt;
                _dt8000_Comb.Rows.Add(dRow);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private static void UpdateRowInTable(ref DataTable _dt8000_Comb, string _tan, string _ident, int _p_8000,
                            string _substname, string _substloc, int _reaction,string _location, string _partpnt)
        {
            try
            {
                if (_dt8000_Comb != null)
                {
                    if (_dt8000_Comb.Rows.Count > 0)
                    {
                        for (int i = 0; i < _dt8000_Comb.Rows.Count; i++)
                        {
                            if (_dt8000_Comb.Rows[i]["TAN"].ToString() == _tan && _dt8000_Comb.Rows[i]["ID"].ToString() == _ident)
                            {
                                _dt8000_Comb.Rows[i]["P_8000"] = _p_8000;
                                _dt8000_Comb.Rows[i]["SUBSTNAME"] = _substname;
                                _dt8000_Comb.Rows[i]["SUBSTLOC"] = _substloc;
                                _dt8000_Comb.Rows[i]["REACTION"] = _reaction;
                                _dt8000_Comb.Rows[i]["LOCATION"] = _location;
                                _dt8000_Comb.Rows[i]["PARTICIPANT"] = _partpnt;
                                _dt8000_Comb.AcceptChanges();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private static void DeleteRowFromTable(ref DataTable _dt8000_Comb, string _tan, string _ident, int _p_8000)
        {
            try
            {
                if (_dt8000_Comb != null)
                {
                    if (_dt8000_Comb.Rows.Count > 0)
                    {
                        for (int i = 0; i < _dt8000_Comb.Rows.Count; i++)
                        {
                            if (_dt8000_Comb.Rows[i]["TAN"].ToString().ToUpper() == _tan.ToUpper()
                                && _dt8000_Comb.Rows[i]["ID"].ToString() == _ident)
                            {
                                _dt8000_Comb.Rows[i].Delete();
                                _dt8000_Comb.AcceptChanges();
                                i = _dt8000_Comb.Rows.Count;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public static DataTable CreateGlobalNum_RegTable()
        {
            DataTable dtNum_Reg = null;
            try
            {
                dtNum_Reg = new DataTable();
                dtNum_Reg.Columns.Add("ID", typeof(Int32));
                dtNum_Reg.Columns.Add("TAN", typeof(string));
                dtNum_Reg.Columns.Add("P_8000", typeof(Int32));
                dtNum_Reg.Columns.Add("SUBSTNAME", typeof(string));
                dtNum_Reg.Columns.Add("SUBSTLOC", typeof(string));
                dtNum_Reg.Columns.Add("REACTION", typeof(Int32));
                dtNum_Reg.Columns.Add("LOCATION", typeof(string));
                dtNum_Reg.Columns.Add("PARTICIPANT", typeof(string));
                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtNum_Reg;
        }

        public static bool Get8000Comb_SubstName_LocValues(string _tan, int _num8000,out string o_substname, out string o_substloc,out string o_substmol,out string o_author,out string o_other)
        {
            bool blStatus = false;
            try
            {
                if (Generic.GlobalVariables.TAN_Series8000Data != null)
                {
                    if (Generic.GlobalVariables.TAN_Series8000Data.Rows.Count > 0)
                    {
                        DataTable dt8000_Comb = Generic.GlobalVariables.TAN_Series8000Data;
                        
                        string strFilter = "TAN = '" + _tan + "' and ser8000 = " + _num8000;
                        DataRow[] dtRArr = dt8000_Comb.Select(strFilter);
                        if (dtRArr != null)
                        {
                            if (dtRArr.Length > 0)
                            {
                                o_substname = dtRArr[0]["subst_name"].ToString();
                                o_substloc = dtRArr[0]["subst_loc"].ToString();
                                o_substmol = dtRArr[0]["substmol"].ToString();
                                o_author = dtRArr[0]["author_name"].ToString();
                                o_other = dtRArr[0]["other_name"].ToString();
                                blStatus = true;
                                return blStatus;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            o_substname = "";
            o_substloc = "";
            o_substmol = "";
            o_author = "";
            o_other = "";
            return blStatus;
        }

        public static bool Get8500_NrnRegValues(string _tan, int _num8500, out int o_nrnreg,out string o_name)
        {
            bool blStatus = false;
            try
            {
                if (Generic.GlobalVariables.Ser8500OrgrefData != null)
                {
                    if (Generic.GlobalVariables.Ser8500OrgrefData.Rows.Count > 0)
                    {
                        DataTable dt8000_Comb = Generic.GlobalVariables.Ser8500OrgrefData;

                        string strFilter = "TAN = '" + _tan + "' and ser8500 = " + _num8500;
                        DataRow[] dtRArr = dt8000_Comb.Select(strFilter);
                        if (dtRArr != null)
                        {
                            if (dtRArr.Length > 0)
                            {
                                o_nrnreg = Convert.ToInt32(dtRArr[0]["nrnreg"]);
                                o_name = dtRArr[0]["descriptor"].ToString();
                                blStatus = true;
                                return blStatus;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            o_nrnreg = 0;
            o_name = "";
            return blStatus;
        }
    }
}
