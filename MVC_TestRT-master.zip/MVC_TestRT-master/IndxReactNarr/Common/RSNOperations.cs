﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IndxReactNarrDAL;
using IndxReactNarr.Export;
using IndxReactNarr.Generic;
using System.IO;

namespace IndxReactNarr.Common
{
    class RSNOperations
    {
        public static DataSet DsXmlData
        {
            get;
            set;
        }

        public static bool GetTANdata_ExportToXml(int tanID, string _filepath)
        {
            bool blStatus = false;
            try
            {
                string strFilePath = _filepath;

                DataTable dtPatent = null;
                DataTable dtReactions = null;
                DataTable dtProdData = null;
                DataTable dtRSNData = null;
                DataTable dtCondData = null;
                DataTable dtPartpntData = null;
                DataTable dtStages_TAN = null;

                DataTable dtReact = null;
                DataTable dtAgent = null;
                DataTable dtSolv = null;
                DataTable dtCatl = null;

                DataView dView_R = null;
                DataView dView_A = null;
                DataView dView_S = null;
                DataView dView_C = null;

                ExportReact objWriteXml = null;

                dtPatent = ReactDB.GetTANDetailsOnTANID(tanID);
                dtReactions = ReactDB.GetReactionsOnTANID(tanID);               
                dtRSNData = ReactDB.GetRSNDetailsOnTAN(tanID);
                dtCondData = ReactDB.GetConditionDataOnTAN(tanID);                
                dtStages_TAN = ReactDB.GetStagesOnTAN(tanID);

                dtPartpntData = ReactDB.GetProduct_ParticipantsDataOnTAN(tanID);
                if (dtPartpntData != null)
                {
                    DataView dvTemp = dtPartpntData.DefaultView;
                    dvTemp.RowFilter = "PP_TYPE = 'PRODUCT'";
                    dtProdData = dvTemp.ToTable();
                }                

                if (dtPartpntData != null)
                {
                    dView_R = dtPartpntData.DefaultView;
                    dView_R.RowFilter = "PP_TYPE = 'REACTANT'";
                    dtReact = dView_R.ToTable();

                    dView_A = dtPartpntData.DefaultView;
                    dView_A.RowFilter = "PP_TYPE = 'AGENT'";
                    dtAgent = dView_A.ToTable();

                    dView_S = dtPartpntData.DefaultView;
                    dView_S.RowFilter = "PP_TYPE = 'SOLVENT'";
                    dtSolv = dView_S.ToTable();

                    dView_C = dtPartpntData.DefaultView;
                    dView_C.RowFilter = "PP_TYPE = 'CATALYST'";
                    dtCatl = dView_C.ToTable();
                }
                objWriteXml = new ExportReact();
                objWriteXml.TANInfoTbl = dtPatent;
                objWriteXml.ProductsTbl = dtProdData;
                objWriteXml.ReactionsTbl = dtReactions;
                objWriteXml.ReactantsTbl = dtReact;
                objWriteXml.AgentsTbl = dtAgent;
                objWriteXml.SolventsTbl = dtSolv;
                objWriteXml.CatalystsTbl = dtCatl;
                objWriteXml.RSNTbl = dtRSNData;
                objWriteXml.ConditionsTbl = dtCondData;
                objWriteXml.StagesTbl = dtStages_TAN;

                if (objWriteXml.WriteXmlFileUsingXSD(strFilePath))
                {
                    blStatus = true;
                    return blStatus;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }               

        public static DataTable ExtractRSNDetails(string _xmlpath)
        {
            try
            {
                if (_xmlpath != "")
                {
                    //Read Batch xml Data to Dataset
                    DataSet dsBXmlData = new DataSet();
                    dsBXmlData.ReadXml(_xmlpath);

                    if (dsBXmlData != null)
                    {
                        if (dsBXmlData.Tables.Count > 0)
                        {
                            DsXmlData = dsBXmlData;

                            if (dsBXmlData.Tables["DOCUMENT"] != null)
                            {
                                DataTable dtRSNData = CreateRSNDataTable();

                                string strTAN = "";
                                string strR_Num_Seq = "";
                                string strRXNNo = "";

                                for (int i = 0; i < dsBXmlData.Tables["DOCUMENT"].Rows.Count; i++)
                                {
                                    strTAN = dsBXmlData.Tables["DOCUMENT"].Rows[i]["TAN"].ToString();

                                    var docQry = (from r in dsBXmlData.Tables["RXNGRP"].AsEnumerable()
                                                  where r.Field<Int32>("DOCUMENT_Id") == Convert.ToInt32(dsBXmlData.Tables["DOCUMENT"].Rows[i]["DOCUMENT_Id"].ToString())
                                                  select r.Field<Int32>("RXNGRP_ID")).Distinct();

                                    foreach (int rxngrpid in docQry)
                                    {
                                        var rxnQry = (from r in dsBXmlData.Tables["RXN"].AsEnumerable()
                                                      where r.Field<Int32>("RXNGRP_ID") == rxngrpid
                                                      select r.Field<Int32>("RXN_ID")).Distinct();

                                        foreach (int rxnid in rxnQry)
                                        {
                                            var rxnNo = (from r in dsBXmlData.Tables["RXN"].AsEnumerable()
                                                         where r.Field<Int32>("RXNGRP_ID") == rxngrpid
                                                            && r.Field<Int32>("RXN_ID") == rxnid
                                                         select r.Field<string>("NO"));

                                            strRXNNo = rxnNo.ElementAt(0).ToString();
                                            strR_Num_Seq = GetRXN_NUM_Seq_On_RXNID(rxnid);

                                            //Reaction RSN

                                            var rxnRSNQry = (from r in dsBXmlData.Tables["RXNPROCESS"].AsEnumerable()
                                                             where r.Field<Int32>("RXN_Id") == rxnid
                                                             select r.Field<Int32>("RXNPROCESS_Id")).Distinct();

                                            int StgIndx = 0;
                                            foreach (int rxnprocid in rxnRSNQry)
                                            {
                                                StgIndx = StgIndx + 1;

                                                if (dsBXmlData.Tables["RSN"].Columns.Contains("RXNPROCESS_Id"))
                                                {
                                                    DataView dtView = dsBXmlData.Tables["RSN"].DefaultView;
                                                    dtView.RowFilter = "RXNPROCESS_Id = " + rxnprocid;
                                                    DataTable dtRxnRSN = dtView.ToTable();

                                                    if (dtRxnRSN != null)
                                                    {
                                                        if (dtRxnRSN.Rows.Count > 0)
                                                        {
                                                            for (int k = 0; k < dtRxnRSN.Rows.Count; k++)
                                                            {
                                                                DataRow dtRow = dtRSNData.NewRow();
                                                                dtRow["TAN"] = strTAN;
                                                                dtRow["RXNNO"] = strRXNNo;
                                                                dtRow["NUM_SEQ"] = strR_Num_Seq;
                                                                dtRow["STAGE"] = "Stage" + StgIndx;
                                                                if (dtRxnRSN.Columns.Contains("RSN_Text"))
                                                                {
                                                                    dtRow["RSN_REACTION"] = GetRSN_XMLTAG(dtRxnRSN.Rows[k]["RSN_Text"].ToString(), dtRxnRSN.Rows[k]["TYPE"].ToString());
                                                                }
                                                                else
                                                                {
                                                                    dtRow["RSN_REACTION"] = GetRSN_XMLTAG("", dtRxnRSN.Rows[k]["TYPE"].ToString());
                                                                }
                                                                dtRSNData.Rows.Add(dtRow);
                                                            }
                                                        }
                                                    }
                                                }

                                                //Stage RSN
                                                var rxnStageQry = (from r in dsBXmlData.Tables["STAGE"].AsEnumerable()
                                                                   where r.Field<Int32>("RXNPROCESS_Id") == rxnprocid
                                                                   select r.Field<Int32>("STAGE_Id")).Distinct();

                                                int intStgId = 0;
                                                foreach (int stageid in rxnStageQry)
                                                {
                                                    intStgId = intStgId + 1;

                                                    if (dsBXmlData.Tables["RSN"].Columns.Contains("STAGE_Id"))
                                                    {
                                                        DataView dtStageView = dsBXmlData.Tables["RSN"].DefaultView;

                                                        dtStageView.RowFilter = "STAGE_Id = " + stageid;
                                                        DataTable dtStageRSN = dtStageView.ToTable();

                                                        if (dtStageRSN != null)
                                                        {
                                                            if (dtStageRSN.Rows.Count > 0)
                                                            {
                                                                for (int m = 0; m < dtStageRSN.Rows.Count; m++)
                                                                {
                                                                    DataRow dtRow = dtRSNData.NewRow();
                                                                    dtRow["TAN"] = strTAN;
                                                                    dtRow["RXNNO"] = strRXNNo;
                                                                    dtRow["NUM_SEQ"] = strR_Num_Seq;
                                                                    dtRow["STAGE"] = "Stage" + intStgId;
                                                                    dtRow["RSN_STAGE"] = GetRSN_XMLTAG(dtStageRSN.Rows[m]["RSN_Text"].ToString(), dtStageRSN.Rows[m]["TYPE"].ToString());
                                                                    dtRSNData.Rows.Add(dtRow);
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }                                
                                return dtRSNData;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                IndxReactNarr.Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }            
            return null;
        }

        private static DataTable CreateRSNDataTable()
        {
            try
            {
                DataTable dtRSNData = new DataTable();
                dtRSNData.Columns.Add("TAN", typeof(string));
                dtRSNData.Columns.Add("RXNNO", typeof(string));
                dtRSNData.Columns.Add("NUM_SEQ", typeof(string));
                dtRSNData.Columns.Add("STAGE", typeof(string));
                dtRSNData.Columns.Add("RSN_REACTION", typeof(string));
                dtRSNData.Columns.Add("RSN_STAGE", typeof(string));

                return dtRSNData;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return null;
        }

        private static string GetRSN_XMLTAG(string _cvt, string _freetext)
        {
            try
            {
                if (_cvt.Trim() != "" && _freetext.Trim() != "")
                {
                    return "<RSN TYPE=\"" + _freetext.Trim() + "\">" + _cvt.Trim() + "</RSN>";
                }
                else if (_cvt.Trim() == "" && _freetext.Trim() != "")
                {
                    return "<RSN TYPE=" + _freetext.Trim() + "></RSN>";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return "";
        }

        private static string GetRXN_NUM_Seq_On_RXNID(int _rxnid)
        {
            try
            {
                var rxnNumQry = (from r in DsXmlData.Tables["RXNID"].AsEnumerable()
                                 where r.Field<Int32>("RXN_ID") == _rxnid
                                 select r.Field<string>("RXNNUM") + "-" + r.Field<string>("RXNSEQ"));

                return rxnNumQry.ElementAt(0).ToString();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return "";
        }
    }
}
