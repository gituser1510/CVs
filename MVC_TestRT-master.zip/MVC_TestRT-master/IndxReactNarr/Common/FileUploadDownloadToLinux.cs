﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WinSCP;

namespace IndxReactNarr.Common
{
    class FileUploadDownloadToLinux
    {

        public bool UploadFileToServer(string localFilePath)
        {
            bool blStatus = false;
            try
            {
                localFilePath = @"D:\9801-005.pdf";

                SessionOptions sessionOptions = new SessionOptions
                {
                    Protocol = Protocol.Scp,
                    HostName = @"\\172.21.0.63\smbshare",
                    UserName = "rmcv3",
                    Password = "rmc#7876",
                    SshHostKeyFingerprint = "ssh-rsa 2048 xx:xx:xx:xx:xx:xx:xx:xx:xx:xx:xx:xx:xx:xx:xx:xx"
                };

                using (Session session = new Session())
                {
                    // Connect
                    session.Open(sessionOptions);

                    // Upload files
                    TransferOptions transferOptions = new TransferOptions();
                    transferOptions.TransferMode = TransferMode.Binary;

                    TransferOperationResult transferResult;
                    transferResult = session.PutFiles(localFilePath, "/disk1/smbshare/", false, transferOptions);

                    // Throw on any error
                    transferResult.Check();

                    // Print results
                    foreach (TransferEventArgs transfer in transferResult.Transfers)
                    {
                        Console.WriteLine("Upload of {0} succeeded", transfer.FileName);
                    }
                }

            }
            catch (Exception ex)
            {

                throw;
            }
            return blStatus;
        }
    }
}
