﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;
using IndxReactNarr.Generic;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;

using CADViewLib;
using IndxReactNarrBLL;

namespace IndxReactNarr.Common
{
    public class CgmNUMsExport
    {
        #region Pdf Color settings

        BaseColor bgcolTANInfo = new BaseColor(204, 255, 204);

        BaseColor bgcolRxnNo = new BaseColor(255, 239, 213);
        BaseColor bgcolNumSeq = new BaseColor(209, 238, 238);//(255, 215, 0);
        BaseColor bgcolPageInfo = new BaseColor(238, 245, 238);
        BaseColor bgcolProduct = new BaseColor(255, 204, 153);//(255, 215, 0);
        BaseColor bgcolReactant = new BaseColor(255, 239, 213);
        BaseColor bgcolRctNumStage = new BaseColor(255, 239, 213);
        BaseColor bgcolRxnPartpnt = new BaseColor(245, 255, 250);

        private iTextSharp.text.Font fontTinyItalic = FontFactory.GetFont("Arial", 7, iTextSharp.text.Font.NORMAL);

        #endregion

        #region Property Procedures
        
        public DataTable CGMDataTbl
        {
            get;
            set;
        }

        public DataTable SUBSTDataTbl
        {
            get;

            set;
        }

        public DataTable NUMsTbl
        {
            get;
            set;
        }

        public DataTable XMLConvTbl
        {
            get;
            set;
        } 
        
        #endregion

        #region Public variables

        XmlNodeList xnlPSEQ;
        XmlNodeList xnlNSeq;
        XmlDocument xDoc;
        XmlNodeList xnlSIMHex;
        XmlNodeList xnlIUPACName;
        XmlNodeList xnlMolFormula;
        XmlNodeList xnlMolFormArr;
        XmlNodeList xnlAbsStreo;
        XmlNodeList xnlSynonyms;
        
        PdfPCell pcInfo = null;
        PdfPCell pcCmntsHdr = null;
        PdfPCell pcComments = null;
        PdfPCell pcTAN = null;
        PdfPCell pcCAN = null;
        PdfPCell pcBatch = null;
        PdfPCell pcNum = null;
        PdfPCell prdYieldCell = null;

        #endregion

        float rowHeight = 90f;//60f

        public bool ExportNUMsToPdf(string tan,string can, string batch, string pdfFilePath)
        {
            bool blStatus = false;
            try
            {
                if (!string.IsNullOrEmpty(tan) && !string.IsNullOrEmpty(pdfFilePath) && NUMsTbl != null)
                {
                    if (NUMsTbl.Rows.Count > 0)
                    {
                        //Initialize Document & PdfWriter
                        Document pdfDoc = new Document();
                        PdfWriter writer = PdfWriter.GetInstance(pdfDoc, new FileStream(pdfFilePath, FileMode.Create));
                        pdfDoc.Open();

                        //Add Pdf Header to document
                        PdfPTable ptHeader = GetPdfHeaderTable(tan, can, batch);
                        pdfDoc.Add(ptHeader);

                        string strNUM = "";
                        int intRegNo = 0;
                        RegNoInfoBO objRegInfo;
                        for (int i = 0; i < NUMsTbl.Rows.Count; i++)
                        {
                            strNUM = NUMsTbl.Rows[i][0].ToString();
                            intRegNo = GetRegNoOnNUM(strNUM);
                            
                            //Get NUM info, NUM info table and add to document
                            objRegInfo = GetRegNoPropertiesFromCGMSubstances(intRegNo, Convert.ToInt32(strNUM));
                            if (objRegInfo != null)
                            {
                                PdfPTable ptNUMDetails = GetNUMTableOnNumInfo(objRegInfo);
                                pdfDoc.Add(ptNUMDetails);
                            }
                        }
                        //Close pdf document
                        pdfDoc.Close();
                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private RegNoInfoBO GetRegNoPropertiesFromCGMSubstances(int _regno, int num)
        {
            RegNoInfoBO objRegNoInfo = null;
            string[] saMolHexCode = null;
            string strName = "";
            string[] saAbsStereo = null;
            string[] saMolFormulas = null;
            string strMolFormula = "";
            string strSynonym = "";
            string strProteinSeq = "";
            string strNuclicSeq = "";

            try
            {
                if (SUBSTDataTbl != null && _regno > 0)
                {
                    if (SUBSTDataTbl.Rows.Count > 0)
                    {
                        DataTable dtsubstance = SUBSTDataTbl.Copy();
                        DataTable dt = new DataTable();

                        string strFCond = "<SUBSTANC><RN ID=" + "\"" + _regno + "\"" + ">*";
                        try
                        {
                            DataTable dtoutput = dtsubstance.AsEnumerable().Where(a => Regex.IsMatch(a[dtsubstance.Columns[0].ColumnName].ToString(), strFCond)).CopyToDataTable();
                            if (dtoutput != null)
                            {
                                objRegNoInfo = new RegNoInfoBO();
                                objRegNoInfo.RegNo = _regno;
                                objRegNoInfo.NUM = num;

                                if (dtoutput.Rows.Count > 0)
                                {
                                    string cellValue = dtoutput.Rows[0][0].ToString();
                                    if (cellValue.Contains("<SIM>"))//Single structure
                                    {
                                        saMolHexCode = new string[1];
                                        strName = "";
                                        saAbsStereo = new string[1];
                                        saMolFormulas = new string[1];
                                        strSynonym = "";

                                        string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";
                                        cellValue = GetConvertedXmlString(cellValue);
                                        cellValue = strXml + "\r\n" + cellValue;

                                        xDoc = new XmlDocument();
                                        xDoc.LoadXml(cellValue);

                                        //Hex Codes
                                        xnlSIMHex = xDoc.SelectNodes("SUBSTANC/SIM");
                                        if (xnlSIMHex.Count > 0)
                                        {
                                            saMolHexCode[0] = xnlSIMHex[0].InnerText;
                                        }
                                        objRegNoInfo.MolHexCodes = saMolHexCode;//New code on 19th Nov 2013

                                        //IUPAC Name
                                        xnlIUPACName = xDoc.SelectNodes("SUBSTANC/IN");
                                        if (xnlIUPACName.Count > 0)
                                        {
                                            strName = xnlIUPACName[0].InnerXml;
                                            strName = DeleteXMLTagsFromName(strName);
                                            strName = SetGreekLetters_IUPACName(strName);
                                        }
                                        objRegNoInfo.IUPACName = strName;//New code on 19th Nov 2013

                                        //Mol Formula
                                        xnlMolFormula = xDoc.SelectNodes("SUBSTANC/MF");
                                        if (xnlMolFormula.Count > 0)
                                        {
                                            strMolFormula = xnlMolFormula[0].InnerText;
                                            strMolFormula = strMolFormula.Replace("<SUB>", "");
                                            strMolFormula = strMolFormula.Replace("</SUB>", "");

                                            objRegNoInfo.MolFormula = strMolFormula;//New code on 19th Nov 2013
                                        }
                                        objRegNoInfo.MolFormulas = saMolFormulas;//New code on 19th Nov 2013

                                        //Absolute Stereo
                                        xnlAbsStreo = xDoc.SelectNodes("SUBSTANC/STEMSG");
                                        if (xnlAbsStreo.Count > 0)
                                        {
                                            saAbsStereo[0] = xnlAbsStreo[0].InnerText;
                                        }
                                        objRegNoInfo.MolAbsStereos = saAbsStereo;//New code on 19th Nov 2013

                                        //Synonyms
                                        xnlSynonyms = xDoc.SelectNodes("SUBSTANC/SYN");
                                        if (xnlSynonyms.Count > 0)
                                        {
                                            for (int i = 0; i < xnlSynonyms.Count; i++)
                                            {
                                                strSynonym = strSynonym.Trim() + "\r\n" + xnlSynonyms[i].InnerText.Trim();
                                            }
                                            strSynonym = SetGreekLetters_IUPACName(strSynonym);
                                        }
                                        objRegNoInfo.MolSynonyms = strSynonym;//New code on 19th Nov 2013

                                        //PSEQ - 18th NOv 2013
                                        xnlPSEQ = xDoc.SelectNodes("SUBSTANC/PSEQ");
                                        if (xnlPSEQ != null)
                                        {
                                            if (xnlPSEQ.Count > 0)
                                            {
                                                for (int i = 0; i < xnlPSEQ.Count; i++)
                                                {
                                                    strProteinSeq = strProteinSeq.Trim() + "\r\n" + xnlPSEQ[i].InnerText.Trim();
                                                }
                                            }
                                        }
                                        objRegNoInfo.MolProteinSeq = strProteinSeq.Trim();//New code on 19th Nov 2013

                                        //NSEQ - 18th NOv 2013
                                        xnlNSeq = xDoc.SelectNodes("SUBSTANC/NSEQ");
                                        if (xnlNSeq != null)
                                        {
                                            if (xnlNSeq.Count > 0)
                                            {
                                                for (int i = 0; i < xnlNSeq.Count; i++)
                                                {
                                                    strNuclicSeq = strNuclicSeq.Trim() + "\r\n" + xnlNSeq[i].InnerText.Trim();
                                                }
                                            }
                                        }
                                        objRegNoInfo.MolNuclicAcidSeq = strNuclicSeq;//New code on 19th Nov 2013
                                    }
                                    else if (cellValue.Contains("<CSIM>"))//Multiple strucrures
                                    {
                                        string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";
                                        cellValue = strXml + "\r\n" + GetConvertedXmlString(cellValue);

                                        XmlDocument xDoc = new XmlDocument();
                                        xDoc.LoadXml(cellValue);

                                        xnlSIMHex = xDoc.SelectNodes("SUBSTANC/COMP/CSIM");
                                        if (xnlSIMHex.Count > 0)
                                        {
                                            //Define arrays of equal size
                                            saMolHexCode = new string[xnlSIMHex.Count];
                                            saAbsStereo = new string[xnlSIMHex.Count];
                                            saMolFormulas = new string[xnlSIMHex.Count];
                                            strSynonym = "";

                                            //Structure Hex code Array
                                            for (int i = 0; i < xnlSIMHex.Count; i++)
                                            {
                                                saMolHexCode[i] = xnlSIMHex[i].InnerText;
                                            }
                                            objRegNoInfo.MolHexCodes = saMolHexCode;//New code on 19th Nov 2013

                                            //IUPAC name
                                            xnlIUPACName = xDoc.SelectNodes("SUBSTANC/IN");
                                            if (xnlIUPACName.Count > 0)
                                            {
                                                strName = "";
                                                strName = xnlIUPACName[0].InnerXml;
                                                strName = DeleteXMLTagsFromName(strName);
                                                strName = SetGreekLetters_IUPACName(strName);
                                            }
                                            objRegNoInfo.IUPACName = strName;//New code on 19th Nov 2013

                                            //Absolute Stereo
                                            xnlAbsStreo = xDoc.SelectNodes("SUBSTANC/COMP");//CSTEMSG
                                            if (xnlAbsStreo.Count > 0)
                                            {
                                                for (int i = 0; i < saAbsStereo.Length; i++)
                                                {
                                                    cellValue = "";
                                                    cellValue = strXml + "\r\n" + xnlAbsStreo[i].OuterXml;

                                                    XmlDocument xDoc_Abs = new XmlDocument();
                                                    xDoc_Abs.LoadXml(cellValue);

                                                    XmlNodeList xNdLst_Abs = xDoc_Abs.SelectNodes("COMP/CSTEMSG");
                                                    if (xNdLst_Abs.Count > 0)
                                                    {
                                                        saAbsStereo[i] = xNdLst_Abs[0].InnerText;
                                                    }
                                                    else
                                                    {
                                                        saAbsStereo[i] = "";
                                                    }
                                                }
                                            }
                                            objRegNoInfo.MolAbsStereos = saAbsStereo;//New code on 19th Nov 2013

                                            //Molecule Formula - Whole compound molecule formula
                                            xnlMolFormula = xDoc.SelectNodes("SUBSTANC/MF");
                                            if (xnlMolFormula.Count > 0)
                                            {
                                                for (int i = 0; i < xnlMolFormula.Count; i++)
                                                {
                                                    strMolFormula = xnlMolFormula[i].InnerText;
                                                    strMolFormula = strMolFormula.Replace("<SUB>", "");
                                                    strMolFormula = strMolFormula.Replace("</SUB>", "");
                                                    //strMolFormula = strMform;
                                                }
                                            }
                                            objRegNoInfo.MolFormula = strMolFormula;//New code on 19th Nov 2013

                                            //Molecule Formula Array
                                            xnlMolFormArr = xDoc.SelectNodes("SUBSTANC/COMP/CMF");
                                            if (xnlMolFormArr.Count > 0)
                                            {
                                                for (int i = 0; i < xnlMolFormArr.Count; i++)
                                                {
                                                    strMolFormula = xnlMolFormArr[i].InnerText;
                                                    strMolFormula = strMolFormula.Replace("<SUB>", "");
                                                    strMolFormula = strMolFormula.Replace("</SUB>", "");
                                                    saMolFormulas[i] = strMolFormula;
                                                }
                                            }
                                            objRegNoInfo.MolFormulas = saMolFormulas;//New code on 19th Nov 2013

                                            //Synonyms
                                            xnlSynonyms = xDoc.SelectNodes("SUBSTANC/SYN");
                                            if (xnlSynonyms.Count > 0)
                                            {
                                                for (int i = 0; i < xnlSynonyms.Count; i++)
                                                {
                                                    strSynonym = strSynonym.Trim() + "\r\n" + xnlSynonyms[i].InnerText.Trim();
                                                }
                                                strSynonym = SetGreekLetters_IUPACName(strSynonym);
                                            }
                                            objRegNoInfo.MolSynonyms = strSynonym;//New code on 19th Nov 2013

                                            //ProteinSequence - 18th NOv 2013
                                            xnlPSEQ = xDoc.SelectNodes("SUBSTANC/PSEQ");
                                            if (xnlPSEQ != null)
                                            {
                                                if (xnlPSEQ.Count > 0)
                                                {
                                                    for (int i = 0; i < xnlPSEQ.Count; i++)
                                                    {
                                                        strProteinSeq = strProteinSeq.Trim() + "\r\n" + xnlPSEQ[i].InnerText.Trim();
                                                    }
                                                }
                                            }
                                            objRegNoInfo.MolProteinSeq = strProteinSeq.Trim();//New code on 19th Nov 2013

                                            //NuclicAcidSequence - 18th NOv 2013
                                            xnlNSeq = xDoc.SelectNodes("SUBSTANC/NSEQ");
                                            if (xnlNSeq != null)
                                            {
                                                if (xnlNSeq.Count > 0)
                                                {
                                                    for (int i = 0; i < xnlNSeq.Count; i++)
                                                    {
                                                        strNuclicSeq = strNuclicSeq.Trim() + "\r\n" + xnlNSeq[i].InnerText.Trim();
                                                    }
                                                }
                                            }
                                            objRegNoInfo.MolNuclicAcidSeq = strNuclicSeq.Trim();//New code on 19th Nov 2013
                                        }
                                    }
                                    else //No Structure available
                                    {
                                        saMolHexCode = new string[1];
                                        strName = "";
                                        saAbsStereo = new string[1];
                                        saMolFormulas = new string[1];
                                        strSynonym = "";

                                        string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";
                                        cellValue = GetConvertedXmlString(cellValue);
                                        cellValue = strXml + "\r\n" + cellValue;

                                        xDoc = new XmlDocument();
                                        xDoc.LoadXml(cellValue);

                                        //IUPAC name
                                        xnlIUPACName = xDoc.SelectNodes("SUBSTANC/IN");
                                        if (xnlIUPACName.Count > 0)
                                        {
                                            strName = "";
                                            strName = xnlIUPACName[0].InnerXml;
                                            strName = DeleteXMLTagsFromName(strName);
                                            strName = SetGreekLetters_IUPACName(strName);
                                        }
                                        objRegNoInfo.IUPACName = strName;//New code on 19th Nov 2013

                                        //Molecule Formula
                                        xnlMolFormula = xDoc.SelectNodes("SUBSTANC/MF");
                                        if (xnlMolFormula.Count > 0)
                                        {
                                            strMolFormula = xnlMolFormula[0].InnerText;
                                            strMolFormula = strMolFormula.Replace("<SUB>", "");
                                            strMolFormula = strMolFormula.Replace("</SUB>", "");
                                            saMolFormulas[0] = strMolFormula;
                                        }
                                        objRegNoInfo.MolFormulas = saMolFormulas;//New code on 19th Nov 2013

                                        //Synonyms
                                        xnlSynonyms = xDoc.SelectNodes("SUBSTANC/SYN");
                                        if (xnlSynonyms.Count > 0)
                                        {
                                            for (int i = 0; i < xnlSynonyms.Count; i++)
                                            {
                                                strSynonym = strSynonym.Trim() + "\r\n" + xnlSynonyms[i].InnerText.Trim();
                                            }
                                            strSynonym = SetGreekLetters_IUPACName(strSynonym);
                                        }
                                        objRegNoInfo.MolSynonyms = strSynonym;//New code on 19th Nov 2013

                                        //PSEQ - 18th NOv 2013
                                        xnlPSEQ = xDoc.SelectNodes("SUBSTANC/PSEQ");
                                        if (xnlPSEQ != null)
                                        {
                                            if (xnlPSEQ.Count > 0)
                                            {
                                                for (int i = 0; i < xnlPSEQ.Count; i++)
                                                {
                                                    strProteinSeq = strProteinSeq.Trim() + "\r\n" + xnlPSEQ[i].InnerText.Trim();
                                                }
                                            }
                                        }
                                        objRegNoInfo.MolProteinSeq = strProteinSeq.Trim();//New code on 19th Nov 2013

                                        //NSEQ - 18th NOv 2013
                                        xnlNSeq = xDoc.SelectNodes("SUBSTANC/NSEQ");
                                        if (xnlNSeq != null)
                                        {
                                            if (xnlNSeq.Count > 0)
                                            {
                                                for (int i = 0; i < xnlNSeq.Count; i++)
                                                {
                                                    strNuclicSeq = strNuclicSeq.Trim() + "\r\n" + xnlNSeq[i].InnerText.Trim();
                                                }
                                            }
                                        }
                                        objRegNoInfo.MolNuclicAcidSeq = strNuclicSeq.Trim();//New code on 19th Nov 2013
                                    }
                                }
                            }
                        }
                        catch
                        {

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return objRegNoInfo;
        }

        private int GetRegNoOnNUM(string _numval)
        {
            int intRegNo = 0;
            try
            {
                if (CGMDataTbl != null)
                {
                    if (CGMDataTbl.Rows.Count > 0)
                    {
                        DataTable dtcgm = CGMDataTbl.Copy();
                        DataTable dt = new DataTable();

                        string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";

                        string cellValue = dtcgm.Rows[0][0].ToString();
                        cellValue = GetConvertedXmlString(cellValue);

                        cellValue = strXml + "\r\n" + cellValue;

                        XElement xEle = XElement.Parse(cellValue, LoadOptions.None);

                        var query = (from XElement r2 in xEle.Elements("CSIE")
                                     where r2.Descendants("NUM").ElementAt(0).Value == _numval
                                     select r2.Descendants("RN").Attributes("RID").ElementAt(0).Value.ToString());

                        if (query != null)
                        {
                            if (query.ToString() != "")
                            {
                                intRegNo = Convert.ToInt32(query.ElementAt(0));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return intRegNo;
        }

        private string GetConvertedXmlString(string _xmltag)
        {
            string strConvXml = _xmltag;
            try
            {
                if (XMLConvTbl != null)
                {
                    if (XMLConvTbl.Rows.Count > 0)
                    {
                        for (int i = 0; i < XMLConvTbl.Rows.Count; i++)
                        {
                            strConvXml = strConvXml.Replace(XMLConvTbl.Rows[i]["xmlstring"].ToString(), XMLConvTbl.Rows[i]["xmlstring_replacement"].ToString());
                        }
                    }
                }
                return strConvXml;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strConvXml;
        }

        private string SetGreekLetters_IUPACName(string _iupacname)
        {
            string strIUPAC = _iupacname;
            try
            {
                if (XMLConvTbl != null)
                {
                    if (XMLConvTbl.Rows.Count > 0)
                    {
                        for (int i = 0; i < XMLConvTbl.Rows.Count; i++)
                        {
                            if (strIUPAC.Trim().Contains(XMLConvTbl.Rows[i]["xmlstring"].ToString()))
                            {
                                strIUPAC = strIUPAC.Replace(XMLConvTbl.Rows[i]["xmlstring"].ToString(), XMLConvTbl.Rows[i]["greek_letter"].ToString());
                            }
                            if (strIUPAC.Trim().Contains(XMLConvTbl.Rows[i]["xmlstring_replacement"].ToString()))
                            {
                                strIUPAC = strIUPAC.Replace(XMLConvTbl.Rows[i]["xmlstring_replacement"].ToString(), XMLConvTbl.Rows[i]["greek_letter"].ToString());
                            }
                        }
                    }
                }
                return strIUPAC;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strIUPAC;
        }

        private string DeleteXMLTagsFromName(string _iupacname)
        {
            string strIUPAC = _iupacname;
            try
            {
                strIUPAC = strIUPAC.Replace("<IT>", "");
                strIUPAC = strIUPAC.Replace("</IT>", "");
                //strIUPAC = strIUPAC.Replace("<SUP>", "");
                //strIUPAC = strIUPAC.Replace("</SUP>", "");
                strIUPAC = strIUPAC.Replace("<SCP>", "");
                strIUPAC = strIUPAC.Replace("</SCP>", "");
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strIUPAC;
        }
              
        private PdfPTable GetPdfHeaderTable(string tan, string can, string batch)
        {
            PdfPTable ptHdr = null;
            try
            {
                if (!string.IsNullOrEmpty(tan) && !string.IsNullOrEmpty(can))
                {
                    ptHdr = new PdfPTable(3);
                    ptHdr.WidthPercentage = 100;
                    ptHdr.SpacingAfter = 8f;

                    pcInfo = new PdfPCell(new Phrase("GVKBio Sciences Pvt. Ltd Internal document", fontTinyItalic));
                    pcInfo.Colspan = 3;
                    pcInfo.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                    pcInfo.BackgroundColor = bgcolTANInfo;// new BaseColor(255, 160, 122);
                    ptHdr.AddCell(pcInfo);

                    pcTAN = new PdfPCell(new Phrase("TAN - " + tan, fontTinyItalic));
                    pcCAN = new PdfPCell(new Phrase("CAN - " + can, fontTinyItalic));                    
                    pcBatch = new PdfPCell(new Phrase("Batch - " + batch, fontTinyItalic));

                    pcTAN.BackgroundColor = bgcolRxnNo;
                    pcCAN.BackgroundColor = bgcolRxnNo;
                    pcBatch.BackgroundColor = bgcolRxnNo;                    

                    ptHdr.AddCell(pcTAN);
                    ptHdr.AddCell(pcCAN);                   
                    ptHdr.AddCell(pcBatch);                   
                    
                    return ptHdr;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return ptHdr;
        }

        //Get NUM data table
        private PdfPTable GetNUMTableOnNumInfo(RegNoInfoBO numInfo)
        {
            PdfPTable ptNUMDetails = null;
            try
            {
                if (numInfo != null)
                {
                    ptNUMDetails = new PdfPTable(3);
                    ptNUMDetails.WidthPercentage = 100;
                    ptNUMDetails.SpacingAfter = 5f;

                    //NUM, Reg.No, IUPAC Name
                    PdfPCell pcNUM = new PdfPCell(new Phrase(numInfo.NUM.ToString(), fontTinyItalic));
                    PdfPCell pcRegNo = new PdfPCell(new Phrase(numInfo.RegNo.ToString(), fontTinyItalic));
                    PdfPCell pcFormula = new PdfPCell(new Phrase(numInfo.MolFormula, fontTinyItalic));

                    pcNUM.BackgroundColor = bgcolRxnNo;
                    pcRegNo.BackgroundColor = bgcolRxnNo;
                    pcFormula.BackgroundColor = bgcolRxnNo; 
                    
                    ptNUMDetails.AddCell(pcNUM);
                    ptNUMDetails.AddCell(pcRegNo);
                    ptNUMDetails.AddCell(pcFormula);

                    //IUPAC Name
                    PdfPCell pcNameHdr = new PdfPCell(new Phrase("Name", fontTinyItalic));
                    pcNameHdr.Colspan = 3;
                    pcNameHdr.BackgroundColor = bgcolRxnNo;
                    ptNUMDetails.AddCell(pcNameHdr);
                    PdfPCell pcName = new PdfPCell(new Phrase(numInfo.IUPACName, fontTinyItalic));
                    pcName.Colspan = 3;
                    ptNUMDetails.AddCell(pcName);

                    //Peptide Sequence
                    if (!string.IsNullOrEmpty(numInfo.MolProteinSeq))
                    {
                        PdfPCell pcPepSeqHdr = new PdfPCell(new Phrase("Peptide Sequence", fontTinyItalic));
                        pcPepSeqHdr.BackgroundColor = bgcolRxnNo;
                        pcPepSeqHdr.Colspan = 3;
                        ptNUMDetails.AddCell(pcPepSeqHdr);

                        PdfPCell pcPepSeq = new PdfPCell(new Phrase(numInfo.MolProteinSeq, fontTinyItalic));                        
                        pcPepSeq.Colspan = 3;
                        ptNUMDetails.AddCell(pcPepSeq);
                    }

                    //Neuclic Acid Sequence
                    if (!string.IsNullOrEmpty(numInfo.MolNuclicAcidSeq))
                    {
                        PdfPCell pcNucSeqHdr = new PdfPCell(new Phrase("Neuclic Acid Sequence", fontTinyItalic));
                        pcNucSeqHdr.Colspan = 3;
                        pcNucSeqHdr.BackgroundColor = bgcolRxnNo;
                        ptNUMDetails.AddCell(pcNucSeqHdr);

                        PdfPCell pcNeuclicSeq = new PdfPCell(new Phrase(numInfo.MolNuclicAcidSeq, fontTinyItalic));
                        pcNeuclicSeq.Colspan = 3;
                        ptNUMDetails.AddCell(pcNeuclicSeq);
                    }

                    //Molecule Images
                    PdfPCell pcMolecule = null;
                    PdfPTable ptMolecules = GetMoleculeImagesTable(numInfo);
                    if (ptMolecules != null)
                    {
                        pcMolecule = new PdfPCell(ptMolecules);
                        pcMolecule.Colspan = 3;
                        ptNUMDetails.AddCell(pcMolecule);
                    }

                    //Synonyms
                    if (!string.IsNullOrEmpty(numInfo.MolSynonyms))
                    {
                        PdfPCell pcSynonymsHdr = new PdfPCell(new Phrase("Synonyms", fontTinyItalic));
                        pcSynonymsHdr.Colspan = 3;
                        pcSynonymsHdr.BackgroundColor = bgcolRxnNo;
                        ptNUMDetails.AddCell(pcSynonymsHdr);

                        PdfPCell pcSynonyms = new PdfPCell(new Phrase(numInfo.MolSynonyms, fontTinyItalic));
                        pcSynonyms.Colspan = 3;
                        ptNUMDetails.AddCell(pcSynonyms);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return ptNUMDetails;
        }

        //Get Molecule Images table
        private PdfPTable GetMoleculeImagesTable(RegNoInfoBO numInfo)
        {
            PdfPTable ptMolecules = null;
            try
            {                
                PdfPCell pcMolImage = null;
                iTextSharp.text.Image chemimg = null;

                if (numInfo.MolHexCodes != null)
                {
                    if (numInfo.MolHexCodes.Length == 1)
                    {
                        ptMolecules = new PdfPTable(1);
                        ptMolecules.WidthPercentage = 100;
                        //ptNUMDetails.SpacingAfter = 5f;

                        chemimg = HexCodeToStructureImage.GetITextImageOnHexCode(numInfo.MolHexCodes[0].Trim(), numInfo.RegNo.ToString());
                        if (chemimg != null)
                        {
                            chemimg.ScaleToFit(50f, 50f);
                            chemimg.ScaleAbsolute((float)50f, (float)50f);
                            chemimg.Alignment = iTextSharp.text.Image.TEXTWRAP | iTextSharp.text.Image.ALIGN_CENTER;

                            pcMolImage = new PdfPCell(chemimg, true);
                        }
                        else
                        {
                            pcMolImage = new PdfPCell(new Phrase("Structure generation error", fontTinyItalic));
                        }
                        pcMolImage.VerticalAlignment = PdfPCell.ALIGN_MIDDLE;
                        pcMolImage.FixedHeight = rowHeight;
                        pcMolImage.HorizontalAlignment = 1;
                        pcMolImage.Colspan = 3;
                        ptMolecules.AddCell(pcMolImage);
                    }
                    else if (numInfo.MolHexCodes.Length > 1)
                    {
                        ptMolecules = new PdfPTable(numInfo.MolHexCodes.Length);

                        for (int i = 0; i < numInfo.MolHexCodes.Length; i++)
                        {
                            chemimg = HexCodeToStructureImage.GetITextImageOnHexCode(numInfo.MolHexCodes[i].Trim(), numInfo.RegNo.ToString());
                            if (chemimg != null)
                            {
                                chemimg.ScaleToFit(50f, 50f);
                                chemimg.ScaleAbsolute((float)50f, (float)50f);
                                chemimg.Alignment = iTextSharp.text.Image.TEXTWRAP | iTextSharp.text.Image.ALIGN_CENTER;

                                pcMolImage = new PdfPCell(chemimg, true);
                            }
                            else
                            {
                                pcMolImage = new PdfPCell(new Phrase("Structure generation error", fontTinyItalic));
                            }
                            pcMolImage.VerticalAlignment = PdfPCell.ALIGN_MIDDLE;
                            pcMolImage.FixedHeight = rowHeight;
                            pcMolImage.HorizontalAlignment = 1;
                            ptMolecules.AddCell(pcMolImage);
                        }
                    }                   
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return ptMolecules;
        }
    }
}
