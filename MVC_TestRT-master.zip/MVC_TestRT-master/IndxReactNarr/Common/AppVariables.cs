﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IndxReactNarr.Common
{
    public class AppVariables
    {
        public const string MacroIndxAppName = "Macro Indexing";
        public const string OrgIndxAppName = "Organic Indexing";
        public const string ReactAppName = "Reaction Analysis";
        public const string NarrAppName = "Narratives";
        public const string ExpProcedureAppName = "Experimental Procedures";

        public const string OrgIndxModule = "INDX";
        public const string NarrModule = "NAR";
        public const string ReactModule = "RXN";

        public const string ExpProcModule = "NAR";
        
    }
}
