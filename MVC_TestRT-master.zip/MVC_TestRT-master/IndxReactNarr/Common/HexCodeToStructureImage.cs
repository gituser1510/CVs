﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using CADViewLib;
using System.IO;
using IndxReactNarr.Generic;

namespace IndxReactNarr.Common
{
    class HexCodeToStructureImage
    {       
        public static Image GetChemImageOnHexCode(string hexcode, string regno)
        {
            Image imgChem = null;
            try
            {
                if (hexcode.Trim() != "")
                {
                    //HexToCgmFile objHex = new HexToCgmFile();
                    string strCgmPath = AppDomain.CurrentDomain.BaseDirectory + regno + ".cgm";
                    string strImagePath = AppDomain.CurrentDomain.BaseDirectory + regno + ".gif";

                    //objHex.Convert_HexToCgm_Save_In_File(hexcode, ref strCgmPath);
                    
                    byte[] newByte = ToByteArray(hexcode);
                    File.WriteAllBytes(strCgmPath, newByte);
                    
                    //CADViewXClass cs = null;
                    if (GlobalVariables.CADViewObject == null)
                    {                                              
                        GlobalVariables.CADViewObject = new CADViewX();
                    }                  

                    try
                    {
                        //cs.DrawMode = TxDXFDrawMode.dmBlack;
                        //cs.Color = UInt32.MinValue;
                        GlobalVariables.CADViewObject.LoadFile(strCgmPath);
                        GlobalVariables.CADViewObject.SaveToFile(strImagePath);
                        GlobalVariables.CADViewObject.CloseFile();

                        //cs.ConvertCADToJPEG(strCgmPath, strImagePath, 500);
                        //cs.CloseFile();                           
                    }
                    catch (Exception ex)
                    {
                        try
                        {
                            GlobalVariables.CADViewObject.LoadFile(strCgmPath);
                            GlobalVariables.CADViewObject.SaveToFile(strImagePath);
                            GlobalVariables.CADViewObject.CloseFile();
                        }
                        catch (Exception)
                        {
                            //throw;
                        }
                    }
                                                           
                    if (File.Exists(strImagePath))
                    {                      
                        using (FileStream fstream = File.Open(strImagePath, FileMode.Open, FileAccess.Read))
                        {
                            BinaryReader br = new BinaryReader(fstream);
                            byte[] imgData = br.ReadBytes((int)fstream.Length);
                            using (MemoryStream stream = new MemoryStream(imgData))
                            {
                                imgChem = System.Drawing.Image.FromStream(stream);
                            }
                            br.Close();
                        }
                    }
                                        
                    if (File.Exists(strCgmPath))
                    {
                        File.Delete(strCgmPath);
                    }
                    if (File.Exists(strImagePath))
                    {
                        File.Delete(strImagePath);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return imgChem;
        }

        private static byte[] ToByteArray(String HexString)
        {
            byte[] bytes = null;
            try
            {
                int NumberChars = HexString.Length;
                bytes = new byte[NumberChars / 2];

                for (int i = 0; i < NumberChars; i += 2)
                {
                    try
                    {
                        bytes[i / 2] = Convert.ToByte(HexString.Substring(i, 2), 16);
                    }
                    catch
                    { 
                    
                    }
                }
                return bytes;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return bytes;
        }

        public static iTextSharp.text.Image GetITextImageOnHexCode(string hexcode, string regno)
        {
            iTextSharp.text.Image imgChem = null;
            try
            {
                if (hexcode.Trim() != "")
                {                   
                    string strCgmPath = AppDomain.CurrentDomain.BaseDirectory + regno + ".cgm";
                    string strImagePath = AppDomain.CurrentDomain.BaseDirectory + regno + ".gif";

                    byte[] newByte = ToByteArray(hexcode);
                    File.WriteAllBytes(strCgmPath, newByte);

                    if (GlobalVariables.CADViewObject == null)
                    {
                        //CADViewX cad = new CADViewX();

                        GlobalVariables.CADViewObject = new CADViewX();
                    } 
                    try
                    {
                        GlobalVariables.CADViewObject.LoadFile(strCgmPath);
                        GlobalVariables.CADViewObject.SaveToFile(strImagePath);
                        GlobalVariables.CADViewObject.CloseFile();
                    }
                    catch (Exception ex)
                    {
                        ErrorHandling.WriteErrorLog(ex.ToString());
                    }

                    if (File.Exists(strImagePath))
                    {
                        using (FileStream fstream = File.Open(strImagePath, FileMode.Open, FileAccess.Read))
                        {
                            BinaryReader br = new BinaryReader(fstream);
                            byte[] imgData = br.ReadBytes((int)fstream.Length);
                            using (MemoryStream stream = new MemoryStream(imgData))
                            {
                                imgChem = iTextSharp.text.Image.GetInstance(stream);
                            }
                            br.Close();
                        }
                    }         

                    //Resize image depend upon your need
                    imgChem.ScaleToFit(280f, 260f);
                    //Give space before image
                    imgChem.SpacingBefore = 30f;
                    //Give some space after the image
                    imgChem.SpacingAfter = 1f;
                    imgChem.Alignment = iTextSharp.text.Element.ALIGN_CENTER;

                    //Delete temp files
                    if (File.Exists(strCgmPath))
                    {
                        File.Delete(strCgmPath);
                    }
                    if (File.Exists(strImagePath))
                    {
                        File.Delete(strImagePath);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return imgChem;
        }

    }
}
