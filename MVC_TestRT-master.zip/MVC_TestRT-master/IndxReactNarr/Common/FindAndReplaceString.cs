﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HtmlRichText;
using System.Data;
using System.Drawing;
using IndxReactNarr.Generic;
using System.Windows.Forms;


namespace IndxReactNarr.Common
{
    public static class FindAndReplaceString
    {
        static int indexOfSearchText = 0;
        static int start = 0;
        //static Html_RtfConversions htmlRtfConv = new Html_RtfConversions();

        public static bool ReplaceDataInReactions(string findString, string replaceString, List<FindReplaceType> findReplCharsList, ref DataTable selectedRxns)
        {            
            try
            {
                if (selectedRxns != null)
                {                    
                    HtmlRichTextBox htfw = new HtmlRichTextBox();
                    HtmlRichTextBox hrtbReplace = new HtmlRichTextBox();
                    HtmlRichTextBox rtbox = new HtmlRichTextBox();

                    foreach (DataRow dRow in selectedRxns.Rows)
                    {
                        rtbox.Rtf = dRow["FIELDVALUE"].ToString();

                        if (rtbox.Text.Contains(findString))
                        {
                            bool blnloop = false;
                            int startindex = 0;

                            indexOfSearchText = 0;
                            start = 0;
                            while (blnloop == false)
                            {
                                if (findString.Length > 0)
                                {
                                    startindex = FindMyText(findString.Trim(), start, rtbox.Text.Length, rtbox);
                                    if (startindex == -1)
                                    {
                                        blnloop = true;
                                    }
                                }

                                if (startindex >= 0)
                                {
                                    // Set the highlight color as red
                                    int endindex = findString.Length;
                                    // Highlight the search string
                                    rtbox.Select(startindex, endindex);
                                    rtbox.SelectionBackColor = Color.LightBlue;
                                    //blnloop = false;
                                    start = startindex + endindex;
                                    // continue;

                                    try
                                    {
                                        if (rtbox.SelectedText != null)
                                        {
                                            hrtbReplace.Text = "";
                                            hrtbReplace.Text = replaceString;
                                            int startposition = rtbox.SelectionStart;
                                            int endpostion = rtbox.SelectionLength;
                                            string strtext = rtbox.SelectedText;
                                            string a = replaceString;
                                            string b = findString;

                                            bool iscontinue = true;
                                            htfw.Clear();
                                            htfw.Text = findString;

                                            if (iscontinue)
                                            {
                                                if (findReplCharsList.Count == replaceString.Length)
                                                {
                                                    for (int i = 0; i < a.Length; i++)
                                                    {
                                                        FindReplaceType fr = findReplCharsList[i];
                                                        string x = a.Substring(i, 1);

                                                        if (Convert.ToChar(x) == fr.CharValue)
                                                        {
                                                            hrtbReplace.Select(i, 1);
                                                            if (fr.IsSubScr)
                                                            {
                                                                hrtbReplace.SetSubScript(true);
                                                            }
                                                            if (fr.IsSupScr)
                                                            {
                                                                hrtbReplace.SetSuperScript(true);
                                                            }
                                                            if (fr.IsBold)
                                                            {
                                                                if (hrtbReplace.SelectionFont != null)
                                                                {
                                                                    hrtbReplace.SelectionFont = new Font(hrtbReplace.SelectionFont, hrtbReplace.SelectionFont.Style ^ FontStyle.Bold);
                                                                }
                                                            }
                                                            if (fr.IsItalic)
                                                            {
                                                                if (hrtbReplace.SelectionFont != null)
                                                                {
                                                                    hrtbReplace.SelectionFont = new Font(hrtbReplace.SelectionFont, hrtbReplace.SelectionFont.Style ^ FontStyle.Italic);
                                                                }
                                                            }
                                                            if (fr.IsBoldItalic)
                                                            {
                                                                if (hrtbReplace.SelectionFont != null)
                                                                {
                                                                    hrtbReplace.SelectionFont = new Font(hrtbReplace.SelectionFont, hrtbReplace.SelectionFont.Style ^ FontStyle.Bold | FontStyle.Italic);
                                                                }
                                                            }
                                                        }
                                                    }

                                                    hrtbReplace.SelectAll();
                                                    rtbox.SelectedRtf = hrtbReplace.SelectedRtf;
                                                    //rtbox.SelectionBackColor = Color.LightGray;
                                                    rtbox.Refresh();                                                   
                                                }
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorHandling.WriteErrorLog(ex.ToString());
                                    }
                                }
                            }

                            dRow["FIELDVALUE"] = rtbox.Rtf;
                        }
                    }
                    selectedRxns.AcceptChanges();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return true;
        }

        public static int FindMyText(string searchText, int searchStart, int searchEnd, HtmlRichTextBox rtb)
        {
            // Set the return value to -1 by default.
            int retVal = -1;
            try
            {
                // A valid starting index should be specified.
                // if indexOfSearchText = -1, the end of search
                if (searchStart >= 0 && indexOfSearchText >= 0)
                {
                    // A valid ending index
                    if (searchEnd > searchStart || searchEnd == -1)
                    {
                        rtb.Refresh();
                        // Find the position of search string in RichTextBox
                        indexOfSearchText = rtb.Find(searchText, searchStart, searchEnd, RichTextBoxFinds.MatchCase);
                        retVal = indexOfSearchText;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return retVal;
        }
              
        public static DataTable FindStringInReactions_Test(string findRtf, List<FindReplaceType> findCharsList, DataTable reactionsTbl, DataTable tanFindingsTbl)
        {
            DataTable dtFindResults = null;
            try
            {
                dtFindResults = new DataTable();
                dtFindResults.Columns.Add("TAN_ID");
                dtFindResults.Columns.Add("TAN_NAME");
                dtFindResults.Columns.Add("RXN_ID");
                dtFindResults.Columns.Add("NARID");
                dtFindResults.Columns.Add("FIELDNAME");
                dtFindResults.Columns.Add("FIELDVALUE");

                HtmlRichTextBox rtbox = new HtmlRichTextBox();
                HtmlRichTextBox rtboxTemp = new HtmlRichTextBox();

                rtboxTemp.Rtf = findRtf;

                bool blPreserveLines = false;
                for (int rowIndx = 0; rowIndx < reactionsTbl.Rows.Count; rowIndx++)
                {
                    for (int colIndx = 0; colIndx < reactionsTbl.Columns.Count; colIndx++)
                    {
                        if (reactionsTbl.Columns[colIndx].ColumnName.ToUpper() == "TEXT_LINE" || 
                            reactionsTbl.Columns[colIndx].ColumnName.ToUpper() == "PARA_TEXT" ||
                            reactionsTbl.Columns[colIndx].ColumnName.ToUpper() == "DATA_TEXT" ||
                            reactionsTbl.Columns[colIndx].ColumnName.ToUpper() == "YIELD_TEXT" ||
                            reactionsTbl.Columns[colIndx].ColumnName.ToUpper() == "PROCEDURE_TEXT")
                        {
                            blPreserveLines = reactionsTbl.Columns[colIndx].ColumnName.ToUpper() == "PROCEDURE_TEXT" ? true : false;

                            rtbox.Rtf = Html_RtfConversions.Instance.GetRTFfromHTMLString(reactionsTbl.Rows[rowIndx][colIndx].ToString(), blPreserveLines);

                            if (rtbox.Text.Contains(rtboxTemp.Text))
                            {
                                bool blFind = FindStringInHTML(rtboxTemp.Text, findCharsList, reactionsTbl.Rows[rowIndx][colIndx].ToString());
                                if (blFind)
                                {
                                    DataRow dRow = dtFindResults.NewRow();
                                    dRow["TAN_ID"] = reactionsTbl.Rows[rowIndx]["TAN_ID"].ToString();
                                    dRow["TAN_NAME"] = reactionsTbl.Rows[rowIndx]["TAN_NAME"].ToString();
                                    dRow["RXN_ID"] = reactionsTbl.Rows[rowIndx]["RXN_ID"].ToString();
                                    dRow["NARID"] = reactionsTbl.Rows[rowIndx]["RXN_NAR_ID"].ToString();
                                    dRow["FIELDNAME"] = reactionsTbl.Columns[colIndx].ColumnName.ToUpper();
                                    dRow["FIELDVALUE"] = Html_RtfConversions.Instance.GetRTFfromHTMLString(reactionsTbl.Rows[rowIndx][colIndx].ToString(), blPreserveLines);
                                    dtFindResults.Rows.Add(dRow);                                  
                                }
                            }
                        }                        
                    }

                    //TAN Reaction Findings
                    if (tanFindingsTbl != null && tanFindingsTbl.Rows.Count > 0)
                    {
                        DataRow[] drRxnFinds = tanFindingsTbl.Select("RXN_ID = " + Convert.ToInt32(reactionsTbl.Rows[rowIndx]["RXN_ID"].ToString()));
                        if (drRxnFinds != null && drRxnFinds.Length > 0)
                        {
                            foreach (DataRow dr in drRxnFinds)
                            {
                                rtbox.Rtf = Html_RtfConversions.Instance.GetRTFfromHTMLString(dr["FINDING_VALUE"].ToString(), false);
                                if (rtbox.Text.Contains(rtboxTemp.Text))
                                {
                                    bool blFind = FindStringInHTML(rtboxTemp.Text, findCharsList, dr["FINDING_VALUE"].ToString());
                                    if (blFind)
                                    {
                                        DataRow dRow = dtFindResults.NewRow();
                                        dRow["TAN_ID"] = reactionsTbl.Rows[rowIndx]["TAN_ID"].ToString();
                                        dRow["TAN_NAME"] = reactionsTbl.Rows[rowIndx]["TAN_NAME"].ToString();
                                        dRow["RXN_ID"] = reactionsTbl.Rows[rowIndx]["RXN_ID"].ToString();
                                        dRow["NARID"] = reactionsTbl.Rows[rowIndx]["RXN_NAR_ID"].ToString();
                                        dRow["FIELDNAME"] = dr["FINDING_TYPE"].ToString();
                                        dRow["FIELDVALUE"] = Html_RtfConversions.Instance.GetRTFfromHTMLString(dr["FINDING_VALUE"].ToString(), false);
                                        dtFindResults.Rows.Add(dRow);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtFindResults;
        }

        public static DataTable FindStringInReactionsInTAN(string findRtf, List<FindReplaceType> findCharsList, string tanName, int tanID, DataTable reactionsTbl, DataTable tanFindingsTbl)
        {
            DataTable dtFindResults = null;
            try
            {
                dtFindResults = new DataTable();
                dtFindResults.Columns.Add("TAN_ID");
                dtFindResults.Columns.Add("TAN_NAME");
                dtFindResults.Columns.Add("RXN_ID");
                dtFindResults.Columns.Add("NARID");
                dtFindResults.Columns.Add("FIELDNAME");
                dtFindResults.Columns.Add("FIELDVALUE");

                HtmlRichTextBox rtbox = new HtmlRichTextBox();
                HtmlRichTextBox rtboxTemp = new HtmlRichTextBox();

                rtboxTemp.Rtf = findRtf;

                bool blPreserveLines = false;
                for (int rowIndx = 0; rowIndx < reactionsTbl.Rows.Count; rowIndx++)
                {
                    for (int colIndx = 0; colIndx < reactionsTbl.Columns.Count; colIndx++)
                    {
                        if (reactionsTbl.Columns[colIndx].ColumnName.ToUpper() == "TEXT_LINE" ||
                            reactionsTbl.Columns[colIndx].ColumnName.ToUpper() == "PARA_TEXT" ||
                            reactionsTbl.Columns[colIndx].ColumnName.ToUpper() == "DATA_TEXT" ||
                            reactionsTbl.Columns[colIndx].ColumnName.ToUpper() == "YIELD_TEXT" ||
                            reactionsTbl.Columns[colIndx].ColumnName.ToUpper() == "PROCEDURE_TEXT")
                        {
                            blPreserveLines = reactionsTbl.Columns[colIndx].ColumnName.ToUpper() == "PROCEDURE_TEXT" ? true : false;

                            rtbox.Rtf = Html_RtfConversions.Instance.GetRTFfromHTMLString(reactionsTbl.Rows[rowIndx][colIndx].ToString(), blPreserveLines);

                            if (rtbox.Text.Contains(rtboxTemp.Text))
                            {
                                bool blFind = FindStringInHTML(rtboxTemp.Text, findCharsList, reactionsTbl.Rows[rowIndx][colIndx].ToString());
                                if (blFind)
                                {
                                    DataRow dRow = dtFindResults.NewRow();
                                    dRow["TAN_ID"] = tanID;// reactionsTbl.Rows[rowIndx]["TAN_ID"].ToString();
                                    dRow["TAN_NAME"] = tanName;
                                    dRow["RXN_ID"] = reactionsTbl.Rows[rowIndx]["RXN_ID"].ToString();
                                    dRow["NARID"] = reactionsTbl.Rows[rowIndx]["RXN_NAR_ID"].ToString();
                                    dRow["FIELDNAME"] = reactionsTbl.Columns[colIndx].ColumnName.ToUpper();
                                    dRow["FIELDVALUE"] = Html_RtfConversions.Instance.GetRTFfromHTMLString(reactionsTbl.Rows[rowIndx][colIndx].ToString(), blPreserveLines);
                                    dtFindResults.Rows.Add(dRow);
                                }
                            }
                        }
                    }

                    //TAN Reaction Findings
                    if (tanFindingsTbl != null && tanFindingsTbl.Rows.Count > 0)
                    {
                        DataRow[] drRxnFinds = tanFindingsTbl.Select("RXN_ID = " + Convert.ToInt32(reactionsTbl.Rows[rowIndx]["RXN_ID"].ToString()));
                        if (drRxnFinds != null && drRxnFinds.Length > 0)
                        {
                            foreach (DataRow dr in drRxnFinds)
                            {
                                rtbox.Rtf = Html_RtfConversions.Instance.GetRTFfromHTMLString(dr["FINDING_VALUE"].ToString(), false);
                                if (rtbox.Text.Contains(rtboxTemp.Text))
                                {
                                    bool blFind = FindStringInHTML(rtboxTemp.Text, findCharsList, dr["FINDING_VALUE"].ToString());
                                    if (blFind)
                                    {
                                        DataRow dRow = dtFindResults.NewRow();
                                        dRow["TAN_ID"] = tanID;//reactionsTbl.Rows[rowIndx]["TAN_ID"].ToString();
                                        dRow["TAN_NAME"] = tanName;
                                        dRow["RXN_ID"] = reactionsTbl.Rows[rowIndx]["RXN_ID"].ToString();
                                        dRow["NARID"] = reactionsTbl.Rows[rowIndx]["RXN_NAR_ID"].ToString();
                                        dRow["FIELDNAME"] = dr["FINDING_TYPE"].ToString();
                                        dRow["FIELDVALUE"] = Html_RtfConversions.Instance.GetRTFfromHTMLString(dr["FINDING_VALUE"].ToString(), false);
                                        dtFindResults.Rows.Add(dRow);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtFindResults;
        }

        public static List<FindReplaceType> GetReplacementCharsList(string rtfString)
        {
            List<FindReplaceType> fndReplist = new List<FindReplaceType>();
            try
            {
                if (!string.IsNullOrEmpty(rtfString))
                {
                    using (HtmlRichTextBox hrtbSrch = new HtmlRichTextBox())
                    {
                        hrtbSrch.Rtf = rtfString;

                        if (hrtbSrch.Text.Length > 0)
                        {
                            for (int i = 0; i < hrtbSrch.Text.Length; i++)
                            {
                                hrtbSrch.Select(i, 1);
                                string strrtf = hrtbSrch.SelectedRtf;
                                FindReplaceType fr = new FindReplaceType();
                                #region MyRegion
                                //if (strrtf.Contains("\\b"))
                                //{
                                //    fr.IsBold = true;
                                //}
                                //if (strrtf.Contains("\\i"))
                                //{
                                //    fr.IsItalic = true;

                                //}
                                //if (strrtf.Contains("\\super"))
                                //{
                                //    fr.IsSupScr = true;
                                //}
                                //if (strrtf.Contains("\\sub"))
                                //{
                                //    fr.IsSubScr = true;
                                //} 
                                #endregion

                                string html = Html_RtfConversions.Instance.GetHTMLFromRTFString(strrtf);
                                if (html.Contains("<sup>"))
                                {
                                    fr.IsSupScr = true;
                                }
                                else if (html.Contains("<sub>"))
                                {
                                    fr.IsSubScr = true;
                                }
                                else if (html.Contains("<bold>") && html.Contains("<ital>"))
                                {
                                    fr.IsBoldItalic = true;
                                }
                                else if (html.Contains("<bold>"))
                                {
                                    fr.IsBold = true;
                                }
                                else if (html.Contains("<ital>"))
                                {
                                    fr.IsItalic = true;
                                }

                                fr.CharValue = Convert.ToChar(hrtbSrch.SelectedText);
                                fndReplist.Add(fr);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return fndReplist;
        }

        private static bool FindStringInHTML(string findhtml, List<FindReplaceType> findcharsList, string searchinHtml)
        {
            bool blStatus = false;
            try
            {
                if (!string.IsNullOrEmpty(findhtml) && !string.IsNullOrEmpty(searchinHtml))
                {
                    bool blnloop = false;
                    int startindex = 0;
                    List<FindReplaceType> lstFindChar;

                    using (HtmlRichTextBox rtbox = new HtmlRichTextBox())
                    {
                        rtbox.Rtf = Html_RtfConversions.Instance.GetRTFfromHTMLString(searchinHtml, false);

                        indexOfSearchText = 0;
                        start = 0;
                        while (blnloop == false)
                        {
                            if (findhtml.Length > 0)
                            {
                                startindex = FindMyText(findhtml.Trim(), start, rtbox.Text.Length, rtbox);
                                if (startindex == -1)
                                {
                                    blnloop = true;
                                }
                            }
                            if (startindex >= 0)
                            {
                                // Set the highlight color as red
                                int endindex = findhtml.Length;
                                // Highlight the search string
                                rtbox.Select(startindex, endindex);

                                start = startindex + endindex;

                                // rtbox.SelectionFont = new Font(rtbox.Font.Name, rtbox.Font.Size);

                                lstFindChar = GetReplacementCharsList(rtbox.SelectedRtf);

                                //blStatus = findcharsList.Equals(lstFindChar);

                                blStatus = CompareList(findcharsList, lstFindChar);
                                
                                if (blStatus)
                                {
                                    return blStatus;
                                }
                            }
                        }
                    }                   
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }

            return blStatus;
        }

        public static bool CompareList(List<FindReplaceType> list1, List<FindReplaceType> list2)
        {
            bool flag = true;
            try
            {
                foreach (FindReplaceType obj in list1)
                {
                    if (!obj.CharValue.Equals(list2[list1.IndexOf(obj)].CharValue))
                    {
                        flag = false;
                    }
                    if (!obj.IsBold.Equals(list2[list1.IndexOf(obj)].IsBold))
                    {
                        flag = false;
                    }
                    if (!obj.IsItalic.Equals(list2[list1.IndexOf(obj)].IsItalic))
                    {
                        flag = false;
                    }
                    if (!obj.IsSubScr.Equals(list2[list1.IndexOf(obj)].IsSubScr))
                    {
                        flag = false;
                    }
                    if (!obj.IsSupScr.Equals(list2[list1.IndexOf(obj)].IsSupScr))
                    {
                        flag = false;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return flag;
        }

    }
}
