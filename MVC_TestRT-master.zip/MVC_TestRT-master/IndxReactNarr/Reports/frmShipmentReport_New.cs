﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarrDAL;
using Microsoft.Office.Interop.Excel;
using IndxReactNarr.Generic;

namespace IndxReactNarr.Reports
{
    public partial class frmShipmentReport_New : Form
    {
        public frmShipmentReport_New()
        {
            InitializeComponent();
        }
        
        private void BindShipmentDataToGrid(System.Data.DataTable dtshipmentdata)
        {
            try
            {
                if (dtshipmentdata != null)
                {
                    dgvReport.AutoGenerateColumns = false;
                    dgvReport.DataSource = dtshipmentdata;

                    colTAN.DataPropertyName = "tan";
                    colTANType.DataPropertyName = "tan_type";
                    colBatch.DataPropertyName = "batch_name";
                    colBatchNo.DataPropertyName = "batch_no";
                    colDate.DataPropertyName = "date";
                    colNoofRxns.DataPropertyName = "rxn_cnt";
                    colDocClass.DataPropertyName = "doc_class";
                    colTANPriority.DataPropertyName = "tan_priority";

                    if (dtshipmentdata.Rows.Count > 0)
                    {
                        DataRow dtRow = dtshipmentdata.NewRow();
                        dtRow["tan"] = dtshipmentdata.Compute("count(tan)", "");
                        dtRow["rxn_cnt"] = dtshipmentdata.Compute("sum([rxn_cnt])", "");                        
                        dtshipmentdata.Rows.Add(dtRow);
                    }
                    dgvReport.Rows[dgvReport.Rows.Count - 1].DefaultCellStyle.BackColor = Color.LimeGreen;

                    txtZeroRxnCnt.Text = "Number of documents returned with no reactions: " + GetZeroReactionsCount(dtshipmentdata);
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private int GetZeroReactionsCount(System.Data.DataTable _reporttbl)
        {
            int intCnt = 0;
            try
            {
                if (_reporttbl != null)
                {
                    if (_reporttbl.Rows.Count > 0)
                    {
                        System.Data.DataTable dtReport = _reporttbl.Copy();
                        DataView dvTemp = dtReport.DefaultView;
                        dvTemp.RowFilter = "[No.of Reactions]" + " = 0";
                        System.Data.DataTable dt = dvTemp.ToTable();
                        if (dt != null)
                        {
                            intCnt = dt.Rows.Count;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return intCnt;
        }

        private void SaveGridDataToExcel()
        {
            try
            {
                //Microsoft.Office.Interop.Excel.ApplicationClass excel = new Microsoft.Office.Interop.Excel.ApplicationClass();
                Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();

                if (excel != null)
                {
                    excel.Application.Workbooks.Add(true);
                    System.Data.DataTable table = (System.Data.DataTable)dgvReport.DataSource;
                    int ColumnIndex = 0;
                    foreach (DataColumn col in table.Columns)
                    {
                        ColumnIndex++;
                        excel.Cells[1, ColumnIndex] = col.ColumnName;
                    }
                    int rowIndex = 0;
                    foreach (DataRow row in table.Rows)
                    {
                        rowIndex++;
                        ColumnIndex = 0;
                        foreach (DataColumn col in table.Columns)
                        {
                            ColumnIndex++;
                            excel.Cells[rowIndex + 1, ColumnIndex] = row[col.ColumnName].ToString();
                        }
                    }

                    excel.Cells[rowIndex + 2, 1] = txtZeroRxnCnt.Text.Trim();

                    excel.Visible = true;
                    Worksheet worksheet = (Worksheet)excel.ActiveSheet;
                    worksheet.Activate();
                }
                else
                {
                    MessageBox.Show("Excel is not installed on your system. Please install Excel", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnGetReport_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtBName.Text.Trim() != "")
                {
                    Cursor = Cursors.WaitCursor;

                    int intBatchNo = 0;
                    int.TryParse(txtBNo.Text.Trim(), out intBatchNo);

                    System.Data.DataTable dtReportData = null;// ReactDB.GetShipmentReportData_New(txtBName.Text.Trim(), intBatchNo);
                    if (dtReportData != null)
                    {
                        if (dtReportData.Rows.Count > 0)
                        {
                            BindShipmentDataToGrid(dtReportData);
                        }
                        else
                        {
                            dgvReport.DataSource = null;
                            MessageBox.Show("No data available for the batch", "Shipment report", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            Cursor = Cursors.Default;
                        }
                    }
                    else
                    {
                        dgvReport.DataSource = null;
                        MessageBox.Show("No data available for the batch", "Shipment report", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Cursor = Cursors.Default;
                    }
                    Cursor = Cursors.Default;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                SaveGridDataToExcel();
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void frmShipmentReport_New_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void dgvReport_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvReport.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvReport.Font);

                if (dgvReport.RowHeadersWidth < (int)(size.Width + 20)) dgvReport.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
