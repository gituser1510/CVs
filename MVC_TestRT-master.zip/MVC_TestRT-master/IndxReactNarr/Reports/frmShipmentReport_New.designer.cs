﻿namespace IndxReactNarr.Reports
{
    partial class frmShipmentReport_New
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvReport = new System.Windows.Forms.DataGridView();
            this.colTANType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBatch = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBatchNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTAN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNoofRxns = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDocClass = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTANPriority = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlZeroRxns = new System.Windows.Forms.Panel();
            this.txtZeroRxnCnt = new System.Windows.Forms.TextBox();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnGetReport = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBNo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBName = new System.Windows.Forms.TextBox();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReport)).BeginInit();
            this.pnlZeroRxns.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.dgvReport);
            this.pnlMain.Controls.Add(this.pnlZeroRxns);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1055, 505);
            this.pnlMain.TabIndex = 1;
            // 
            // dgvReport
            // 
            this.dgvReport.AllowUserToAddRows = false;
            this.dgvReport.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvReport.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvReport.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReport.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTANType,
            this.colBatch,
            this.colBatchNo,
            this.colDate,
            this.colTAN,
            this.colNoofRxns,
            this.colDocClass,
            this.colTANPriority});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvReport.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvReport.Location = new System.Drawing.Point(0, 37);
            this.dgvReport.Name = "dgvReport";
            this.dgvReport.ReadOnly = true;
            this.dgvReport.Size = new System.Drawing.Size(1055, 441);
            this.dgvReport.TabIndex = 10;
            this.dgvReport.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvReport_RowPostPaint);
            // 
            // colTANType
            // 
            this.colTANType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colTANType.HeaderText = "TANType";
            this.colTANType.Name = "colTANType";
            this.colTANType.ReadOnly = true;
            this.colTANType.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colTANType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // colBatch
            // 
            this.colBatch.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colBatch.HeaderText = "Batch";
            this.colBatch.Name = "colBatch";
            this.colBatch.ReadOnly = true;
            this.colBatch.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colBatch.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colBatchNo
            // 
            this.colBatchNo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colBatchNo.HeaderText = "Batch No";
            this.colBatchNo.Name = "colBatchNo";
            this.colBatchNo.ReadOnly = true;
            this.colBatchNo.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colBatchNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colDate
            // 
            this.colDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colDate.HeaderText = "Date";
            this.colDate.Name = "colDate";
            this.colDate.ReadOnly = true;
            this.colDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colTAN
            // 
            this.colTAN.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colTAN.HeaderText = "TAN";
            this.colTAN.Name = "colTAN";
            this.colTAN.ReadOnly = true;
            this.colTAN.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colTAN.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colNoofRxns
            // 
            this.colNoofRxns.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colNoofRxns.DefaultCellStyle = dataGridViewCellStyle2;
            this.colNoofRxns.HeaderText = "No.of Reactions";
            this.colNoofRxns.Name = "colNoofRxns";
            this.colNoofRxns.ReadOnly = true;
            this.colNoofRxns.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colDocClass
            // 
            this.colDocClass.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colDocClass.HeaderText = "Doc_Class";
            this.colDocClass.Name = "colDocClass";
            this.colDocClass.ReadOnly = true;
            this.colDocClass.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colDocClass.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // colTANPriority
            // 
            this.colTANPriority.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colTANPriority.HeaderText = "Priority";
            this.colTANPriority.Name = "colTANPriority";
            this.colTANPriority.ReadOnly = true;
            this.colTANPriority.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colTANPriority.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // pnlZeroRxns
            // 
            this.pnlZeroRxns.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlZeroRxns.Controls.Add(this.txtZeroRxnCnt);
            this.pnlZeroRxns.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlZeroRxns.Location = new System.Drawing.Point(0, 478);
            this.pnlZeroRxns.Name = "pnlZeroRxns";
            this.pnlZeroRxns.Size = new System.Drawing.Size(1055, 27);
            this.pnlZeroRxns.TabIndex = 12;
            // 
            // txtZeroRxnCnt
            // 
            this.txtZeroRxnCnt.BackColor = System.Drawing.Color.White;
            this.txtZeroRxnCnt.Dock = System.Windows.Forms.DockStyle.Left;
            this.txtZeroRxnCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtZeroRxnCnt.ForeColor = System.Drawing.Color.Blue;
            this.txtZeroRxnCnt.Location = new System.Drawing.Point(0, 0);
            this.txtZeroRxnCnt.Name = "txtZeroRxnCnt";
            this.txtZeroRxnCnt.ReadOnly = true;
            this.txtZeroRxnCnt.Size = new System.Drawing.Size(380, 25);
            this.txtZeroRxnCnt.TabIndex = 11;
            this.txtZeroRxnCnt.Text = "Number of documents returned with no reactions:  0";
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlTop.Controls.Add(this.btnSave);
            this.pnlTop.Controls.Add(this.btnGetReport);
            this.pnlTop.Controls.Add(this.label4);
            this.pnlTop.Controls.Add(this.txtBNo);
            this.pnlTop.Controls.Add(this.label2);
            this.pnlTop.Controls.Add(this.txtBName);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1055, 37);
            this.pnlTop.TabIndex = 8;
            // 
            // btnSave
            // 
            this.btnSave.AutoSize = true;
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnSave.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(466, 5);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(94, 25);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnGetReport
            // 
            this.btnGetReport.AutoSize = true;
            this.btnGetReport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGetReport.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnGetReport.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGetReport.Location = new System.Drawing.Point(339, 5);
            this.btnGetReport.Name = "btnGetReport";
            this.btnGetReport.Size = new System.Drawing.Size(94, 25);
            this.btnGetReport.TabIndex = 2;
            this.btnGetReport.Text = "Get Report";
            this.btnGetReport.UseVisualStyleBackColor = true;
            this.btnGetReport.Click += new System.EventHandler(this.btnGetReport_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(217, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 17);
            this.label4.TabIndex = 11;
            this.label4.Text = "Batch No.";
            // 
            // txtBNo
            // 
            this.txtBNo.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBNo.ForeColor = System.Drawing.Color.Blue;
            this.txtBNo.Location = new System.Drawing.Point(286, 5);
            this.txtBNo.Name = "txtBNo";
            this.txtBNo.Size = new System.Drawing.Size(36, 25);
            this.txtBNo.TabIndex = 1;
            this.txtBNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "Batch Name";
            // 
            // txtBName
            // 
            this.txtBName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBName.ForeColor = System.Drawing.Color.Blue;
            this.txtBName.Location = new System.Drawing.Point(95, 4);
            this.txtBName.Name = "txtBName";
            this.txtBName.Size = new System.Drawing.Size(110, 25);
            this.txtBName.TabIndex = 0;
            this.txtBName.Text = "rxnfile.8000";
            // 
            // frmShipmentReport_New
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1055, 505);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmShipmentReport_New";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Shipment Report";
            this.Load += new System.EventHandler(this.frmShipmentReport_New_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvReport)).EndInit();
            this.pnlZeroRxns.ResumeLayout(false);
            this.pnlZeroRxns.PerformLayout();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.DataGridView dgvReport;
        private System.Windows.Forms.Panel pnlZeroRxns;
        private System.Windows.Forms.TextBox txtZeroRxnCnt;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnGetReport;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBNo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTANType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBatch;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBatchNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTAN;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNoofRxns;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDocClass;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTANPriority;
    }
}