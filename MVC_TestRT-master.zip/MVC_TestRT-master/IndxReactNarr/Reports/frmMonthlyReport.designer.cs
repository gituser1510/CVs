﻿namespace IndxReactNarr.Reports
{
    partial class frmMonthlyReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvReport = new System.Windows.Forms.DataGridView();
            this.colUserID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colUserName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRoleName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTANCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.lblRxnsCount_Curation = new System.Windows.Forms.Label();
            this.lblRxnsStatus = new System.Windows.Forms.Label();
            this.lblTANsCount = new System.Windows.Forms.Label();
            this.lblTANsStatus = new System.Windows.Forms.Label();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.Button();
            this.dpToDate = new System.Windows.Forms.DateTimePicker();
            this.lblToDate = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.dpFromDate = new System.Windows.Forms.DateTimePicker();
            this.lblSelect = new System.Windows.Forms.Label();
            this.lblRxnsCount_QC = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblRxnsCount_Review = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReport)).BeginInit();
            this.pnlBottom.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.dgvReport);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1092, 517);
            this.pnlMain.TabIndex = 0;
            // 
            // dgvReport
            // 
            this.dgvReport.AllowUserToAddRows = false;
            this.dgvReport.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvReport.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvReport.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReport.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colUserID,
            this.colUserName,
            this.colRoleName,
            this.colTANCount,
            this.colRxnCount});
            this.dgvReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvReport.Location = new System.Drawing.Point(0, 37);
            this.dgvReport.Name = "dgvReport";
            this.dgvReport.ReadOnly = true;
            this.dgvReport.Size = new System.Drawing.Size(1092, 446);
            this.dgvReport.TabIndex = 2;
            this.dgvReport.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvReport_RowPostPaint);
            // 
            // colUserID
            // 
            this.colUserID.HeaderText = "User ID";
            this.colUserID.Name = "colUserID";
            this.colUserID.ReadOnly = true;
            this.colUserID.Visible = false;
            // 
            // colUserName
            // 
            this.colUserName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colUserName.HeaderText = "User Name";
            this.colUserName.Name = "colUserName";
            this.colUserName.ReadOnly = true;
            // 
            // colRoleName
            // 
            this.colRoleName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colRoleName.HeaderText = "Role Name";
            this.colRoleName.Name = "colRoleName";
            this.colRoleName.ReadOnly = true;
            // 
            // colTANCount
            // 
            this.colTANCount.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colTANCount.HeaderText = "TAN Count";
            this.colTANCount.Name = "colTANCount";
            this.colTANCount.ReadOnly = true;
            // 
            // colRxnCount
            // 
            this.colRxnCount.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colRxnCount.HeaderText = "Rxns Count";
            this.colRxnCount.Name = "colRxnCount";
            this.colRxnCount.ReadOnly = true;
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom.Controls.Add(this.lblRxnsCount_QC);
            this.pnlBottom.Controls.Add(this.label3);
            this.pnlBottom.Controls.Add(this.lblRxnsCount_Review);
            this.pnlBottom.Controls.Add(this.label2);
            this.pnlBottom.Controls.Add(this.lblRxnsCount_Curation);
            this.pnlBottom.Controls.Add(this.lblRxnsStatus);
            this.pnlBottom.Controls.Add(this.lblTANsCount);
            this.pnlBottom.Controls.Add(this.lblTANsStatus);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 483);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(1092, 34);
            this.pnlBottom.TabIndex = 3;
            // 
            // lblRxnsCount_Curation
            // 
            this.lblRxnsCount_Curation.AutoSize = true;
            this.lblRxnsCount_Curation.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnsCount_Curation.ForeColor = System.Drawing.Color.Blue;
            this.lblRxnsCount_Curation.Location = new System.Drawing.Point(366, 8);
            this.lblRxnsCount_Curation.Name = "lblRxnsCount_Curation";
            this.lblRxnsCount_Curation.Size = new System.Drawing.Size(16, 17);
            this.lblRxnsCount_Curation.TabIndex = 3;
            this.lblRxnsCount_Curation.Text = "0";
            // 
            // lblRxnsStatus
            // 
            this.lblRxnsStatus.AutoSize = true;
            this.lblRxnsStatus.Location = new System.Drawing.Point(178, 9);
            this.lblRxnsStatus.Name = "lblRxnsStatus";
            this.lblRxnsStatus.Size = new System.Drawing.Size(194, 17);
            this.lblRxnsStatus.TabIndex = 2;
            this.lblRxnsStatus.Text = "Curation Completed Reactions: ";
            // 
            // lblTANsCount
            // 
            this.lblTANsCount.AutoSize = true;
            this.lblTANsCount.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTANsCount.ForeColor = System.Drawing.Color.Blue;
            this.lblTANsCount.Location = new System.Drawing.Point(117, 8);
            this.lblTANsCount.Name = "lblTANsCount";
            this.lblTANsCount.Size = new System.Drawing.Size(16, 17);
            this.lblTANsCount.TabIndex = 1;
            this.lblTANsCount.Text = "0";
            // 
            // lblTANsStatus
            // 
            this.lblTANsStatus.AutoSize = true;
            this.lblTANsStatus.Location = new System.Drawing.Point(4, 8);
            this.lblTANsStatus.Name = "lblTANsStatus";
            this.lblTANsStatus.Size = new System.Drawing.Size(118, 17);
            this.lblTANsStatus.TabIndex = 0;
            this.lblTANsStatus.Text = "Completed TANs: ";
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.btnSave);
            this.pnlTop.Controls.Add(this.dpToDate);
            this.pnlTop.Controls.Add(this.lblToDate);
            this.pnlTop.Controls.Add(this.btnSubmit);
            this.pnlTop.Controls.Add(this.dpFromDate);
            this.pnlTop.Controls.Add(this.lblSelect);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1092, 37);
            this.pnlTop.TabIndex = 1;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(785, 2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 30);
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Visible = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // dpToDate
            // 
            this.dpToDate.Location = new System.Drawing.Point(413, 5);
            this.dpToDate.Name = "dpToDate";
            this.dpToDate.Size = new System.Drawing.Size(228, 25);
            this.dpToDate.TabIndex = 4;
            // 
            // lblToDate
            // 
            this.lblToDate.AutoSize = true;
            this.lblToDate.Location = new System.Drawing.Point(337, 9);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.Size = new System.Drawing.Size(56, 17);
            this.lblToDate.TabIndex = 3;
            this.lblToDate.Text = "To Date";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(665, 2);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 30);
            this.btnSubmit.TabIndex = 2;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // dpFromDate
            // 
            this.dpFromDate.Location = new System.Drawing.Point(79, 5);
            this.dpFromDate.Name = "dpFromDate";
            this.dpFromDate.Size = new System.Drawing.Size(228, 25);
            this.dpFromDate.TabIndex = 1;
            // 
            // lblSelect
            // 
            this.lblSelect.AutoSize = true;
            this.lblSelect.Location = new System.Drawing.Point(3, 9);
            this.lblSelect.Name = "lblSelect";
            this.lblSelect.Size = new System.Drawing.Size(72, 17);
            this.lblSelect.TabIndex = 0;
            this.lblSelect.Text = "From Date";
            // 
            // lblRxnsCount_QC
            // 
            this.lblRxnsCount_QC.AutoSize = true;
            this.lblRxnsCount_QC.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnsCount_QC.ForeColor = System.Drawing.Color.Blue;
            this.lblRxnsCount_QC.Location = new System.Drawing.Point(853, 8);
            this.lblRxnsCount_QC.Name = "lblRxnsCount_QC";
            this.lblRxnsCount_QC.Size = new System.Drawing.Size(16, 17);
            this.lblRxnsCount_QC.TabIndex = 11;
            this.lblRxnsCount_QC.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(691, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(165, 17);
            this.label3.TabIndex = 10;
            this.label3.Text = "QC Completed Reactions: ";
            // 
            // lblRxnsCount_Review
            // 
            this.lblRxnsCount_Review.AutoSize = true;
            this.lblRxnsCount_Review.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnsCount_Review.ForeColor = System.Drawing.Color.Blue;
            this.lblRxnsCount_Review.Location = new System.Drawing.Point(625, 9);
            this.lblRxnsCount_Review.Name = "lblRxnsCount_Review";
            this.lblRxnsCount_Review.Size = new System.Drawing.Size(16, 17);
            this.lblRxnsCount_Review.TabIndex = 9;
            this.lblRxnsCount_Review.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(431, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(189, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "Review Completed Reactions: ";
            // 
            // frmMonthlyReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1092, 517);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmMonthlyReport";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Monthly Report";
            this.Load += new System.EventHandler(this.frmMonthlyReport_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvReport)).EndInit();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.DateTimePicker dpToDate;
        private System.Windows.Forms.Label lblToDate;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.DateTimePicker dpFromDate;
        private System.Windows.Forms.Label lblSelect;
        private System.Windows.Forms.DataGridView dgvReport;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.DataGridViewTextBoxColumn colUserID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colUserName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRoleName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTANCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnCount;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Label lblRxnsCount_Curation;
        private System.Windows.Forms.Label lblRxnsStatus;
        private System.Windows.Forms.Label lblTANsCount;
        private System.Windows.Forms.Label lblTANsStatus;
        private System.Windows.Forms.Label lblRxnsCount_QC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblRxnsCount_Review;
        private System.Windows.Forms.Label label2;
    }
}