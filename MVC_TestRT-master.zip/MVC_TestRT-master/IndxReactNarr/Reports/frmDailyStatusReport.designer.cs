﻿namespace IndxReactNarr.Reports
{
    partial class frmDailyStatusReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvReport = new System.Windows.Forms.DataGridView();
            this.colUserName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRoleName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTANCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCompletedRxnsCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.lblRxnsCount_Curation = new System.Windows.Forms.Label();
            this.lblRxnsStatus = new System.Windows.Forms.Label();
            this.lblTANsCount = new System.Windows.Forms.Label();
            this.lblTANsStatus = new System.Windows.Forms.Label();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.datePicker = new System.Windows.Forms.DateTimePicker();
            this.lblSelect = new System.Windows.Forms.Label();
            this.lblRxnsCount_Review = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblRxnsCount_QC = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReport)).BeginInit();
            this.pnlBottom.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.dgvReport);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(918, 516);
            this.pnlMain.TabIndex = 0;
            // 
            // dgvReport
            // 
            this.dgvReport.AllowUserToAddRows = false;
            this.dgvReport.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvReport.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvReport.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvReport.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReport.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colUserName,
            this.colRoleName,
            this.colTANCount,
            this.colCompletedRxnsCount});
            this.dgvReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvReport.Location = new System.Drawing.Point(0, 37);
            this.dgvReport.Name = "dgvReport";
            this.dgvReport.ReadOnly = true;
            this.dgvReport.Size = new System.Drawing.Size(918, 445);
            this.dgvReport.TabIndex = 1;
            this.dgvReport.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvReport_RowPostPaint);
            // 
            // colUserName
            // 
            this.colUserName.HeaderText = "UserName";
            this.colUserName.Name = "colUserName";
            this.colUserName.ReadOnly = true;
            // 
            // colRoleName
            // 
            this.colRoleName.HeaderText = "RoleName";
            this.colRoleName.Name = "colRoleName";
            this.colRoleName.ReadOnly = true;
            // 
            // colTANCount
            // 
            this.colTANCount.HeaderText = "CompletedTANs";
            this.colTANCount.Name = "colTANCount";
            this.colTANCount.ReadOnly = true;
            // 
            // colCompletedRxnsCount
            // 
            this.colCompletedRxnsCount.HeaderText = "ReactionsCount";
            this.colCompletedRxnsCount.Name = "colCompletedRxnsCount";
            this.colCompletedRxnsCount.ReadOnly = true;
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom.Controls.Add(this.lblRxnsCount_QC);
            this.pnlBottom.Controls.Add(this.label3);
            this.pnlBottom.Controls.Add(this.lblRxnsCount_Review);
            this.pnlBottom.Controls.Add(this.label2);
            this.pnlBottom.Controls.Add(this.lblRxnsCount_Curation);
            this.pnlBottom.Controls.Add(this.lblRxnsStatus);
            this.pnlBottom.Controls.Add(this.lblTANsCount);
            this.pnlBottom.Controls.Add(this.lblTANsStatus);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 482);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(918, 34);
            this.pnlBottom.TabIndex = 2;
            // 
            // lblRxnsCount_Curation
            // 
            this.lblRxnsCount_Curation.AutoSize = true;
            this.lblRxnsCount_Curation.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnsCount_Curation.ForeColor = System.Drawing.Color.Blue;
            this.lblRxnsCount_Curation.Location = new System.Drawing.Point(374, 8);
            this.lblRxnsCount_Curation.Name = "lblRxnsCount_Curation";
            this.lblRxnsCount_Curation.Size = new System.Drawing.Size(16, 17);
            this.lblRxnsCount_Curation.TabIndex = 3;
            this.lblRxnsCount_Curation.Text = "0";
            // 
            // lblRxnsStatus
            // 
            this.lblRxnsStatus.AutoSize = true;
            this.lblRxnsStatus.Location = new System.Drawing.Point(185, 8);
            this.lblRxnsStatus.Name = "lblRxnsStatus";
            this.lblRxnsStatus.Size = new System.Drawing.Size(194, 17);
            this.lblRxnsStatus.TabIndex = 2;
            this.lblRxnsStatus.Text = "Curation Completed Reactions: ";
            // 
            // lblTANsCount
            // 
            this.lblTANsCount.AutoSize = true;
            this.lblTANsCount.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTANsCount.ForeColor = System.Drawing.Color.Blue;
            this.lblTANsCount.Location = new System.Drawing.Point(117, 8);
            this.lblTANsCount.Name = "lblTANsCount";
            this.lblTANsCount.Size = new System.Drawing.Size(16, 17);
            this.lblTANsCount.TabIndex = 1;
            this.lblTANsCount.Text = "0";
            // 
            // lblTANsStatus
            // 
            this.lblTANsStatus.AutoSize = true;
            this.lblTANsStatus.Location = new System.Drawing.Point(4, 8);
            this.lblTANsStatus.Name = "lblTANsStatus";
            this.lblTANsStatus.Size = new System.Drawing.Size(118, 17);
            this.lblTANsStatus.TabIndex = 0;
            this.lblTANsStatus.Text = "Completed TANs: ";
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.splitter1);
            this.pnlTop.Controls.Add(this.btnSubmit);
            this.pnlTop.Controls.Add(this.datePicker);
            this.pnlTop.Controls.Add(this.lblSelect);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(918, 37);
            this.pnlTop.TabIndex = 0;
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 35);
            this.splitter1.TabIndex = 3;
            this.splitter1.TabStop = false;
            this.splitter1.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.splitter1_SplitterMoved);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(320, 3);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 30);
            this.btnSubmit.TabIndex = 2;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // datePicker
            // 
            this.datePicker.Location = new System.Drawing.Point(86, 5);
            this.datePicker.Name = "datePicker";
            this.datePicker.Size = new System.Drawing.Size(228, 25);
            this.datePicker.TabIndex = 1;
            // 
            // lblSelect
            // 
            this.lblSelect.AutoSize = true;
            this.lblSelect.Location = new System.Drawing.Point(3, 9);
            this.lblSelect.Name = "lblSelect";
            this.lblSelect.Size = new System.Drawing.Size(77, 17);
            this.lblSelect.TabIndex = 0;
            this.lblSelect.Text = "Select Date";
            // 
            // lblRxnsCount_Review
            // 
            this.lblRxnsCount_Review.AutoSize = true;
            this.lblRxnsCount_Review.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnsCount_Review.ForeColor = System.Drawing.Color.Blue;
            this.lblRxnsCount_Review.Location = new System.Drawing.Point(632, 9);
            this.lblRxnsCount_Review.Name = "lblRxnsCount_Review";
            this.lblRxnsCount_Review.Size = new System.Drawing.Size(16, 17);
            this.lblRxnsCount_Review.TabIndex = 5;
            this.lblRxnsCount_Review.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(438, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(189, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Review Completed Reactions: ";
            // 
            // lblRxnsCount_QC
            // 
            this.lblRxnsCount_QC.AutoSize = true;
            this.lblRxnsCount_QC.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnsCount_QC.ForeColor = System.Drawing.Color.Blue;
            this.lblRxnsCount_QC.Location = new System.Drawing.Point(860, 8);
            this.lblRxnsCount_QC.Name = "lblRxnsCount_QC";
            this.lblRxnsCount_QC.Size = new System.Drawing.Size(16, 17);
            this.lblRxnsCount_QC.TabIndex = 7;
            this.lblRxnsCount_QC.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(698, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(165, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "QC Completed Reactions: ";
            // 
            // frmDailyStatusReport
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(918, 516);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmDailyStatusReport";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Daily Status Report";
            this.Load += new System.EventHandler(this.frmDailyStatusReport_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvReport)).EndInit();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.DateTimePicker datePicker;
        private System.Windows.Forms.Label lblSelect;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.DataGridView dgvReport;
        private System.Windows.Forms.DataGridViewTextBoxColumn colUserName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRoleName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTANCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCompletedRxnsCount;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Label lblRxnsCount_Curation;
        private System.Windows.Forms.Label lblRxnsStatus;
        private System.Windows.Forms.Label lblTANsCount;
        private System.Windows.Forms.Label lblTANsStatus;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Label lblRxnsCount_Review;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblRxnsCount_QC;
        private System.Windows.Forms.Label label3;
    }
}