﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarrDAL;
using IndxReactNarr.Generic;
using IndxReactNarrBLL;
using IndxReactNarr.Common;

namespace IndxReactNarr.Reports
{
    public partial class frmMonthlyReport : Form
    {
        public frmMonthlyReport()
        {
            InitializeComponent();
        }

        public DataTable ModuleUsers { get; set; }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (dpFromDate.Text != null && dpToDate.Text != null)
                {
                    //if (GlobalVariables.ApplicationName == Enums.ApplicationName.NARRATIVES.ToString() ||
                    //    GlobalVariables.ApplicationName == Enums.ApplicationName.EXPPROCEDURES.ToString())
                    //{
                        using (DataTable dtDStatus = NarrativesDB.GetDailyStatusReport(GlobalVariables.ApplicationName,GlobalVariables.ModuleName, dpFromDate.Value.Date, dpToDate.Value.Date))
                        {
                            BindDailyStatusDataToGrid(dtDStatus);
                        }
                   // }                    
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindDailyStatusDataToGrid(DataTable dailystatusdata)
        {
            try
            {
                if (dailystatusdata != null)
                {
                    if (GlobalVariables.RoleName.ToUpper() == RolesMaster.PM.ToUpper() ||
                        GlobalVariables.RoleName.ToUpper() == RolesMaster.TOOL_MANAGER.ToUpper() ||
                        GlobalVariables.RoleName.ToUpper() == RolesMaster.ADMIN.ToUpper())
                    {
                        dgvReport.AutoGenerateColumns = false;
                        dgvReport.DataSource = dailystatusdata;

                        colUserName.DataPropertyName = "USER_NAME";
                        colRoleName.DataPropertyName = "ROLE_NAME";
                        colTANCount.DataPropertyName = "TASK_COMPLETED_CNT";
                        colRxnCount.DataPropertyName = "RXN_COMPLETED_CNT";

                        //No.of Reactions - Curation completed
                        object objRxnCnt = dailystatusdata.Compute("sum([RXN_COMPLETED_CNT])", "[RXN_COMPLETED_CNT] is not null and ROLE_NAME = 'Analyst'");
                        if (objRxnCnt != null)
                        {
                            lblRxnsCount_Curation.Text = objRxnCnt.ToString();
                        }

                        //No.of Reactions - Review completed
                        object objRevRxnCnt = dailystatusdata.Compute("sum([RXN_COMPLETED_CNT])", "[RXN_COMPLETED_CNT] is not null and ROLE_NAME = 'Review Analyst'");
                        if (objRevRxnCnt != null)
                        {
                            lblRxnsCount_Review.Text = objRevRxnCnt.ToString();
                        }

                        //No.of Reactions - QC completed
                        object objQcRxnCnt = dailystatusdata.Compute("sum([RXN_COMPLETED_CNT])", "[RXN_COMPLETED_CNT] is not null and ROLE_NAME = 'QC Analyst'");
                        if (objQcRxnCnt != null)
                        {
                            lblRxnsCount_QC.Text = objQcRxnCnt.ToString();
                        }

                        object objTANCnt = dailystatusdata.Compute("sum([TASK_COMPLETED_CNT])", "[TASK_COMPLETED_CNT] is not null");
                        if (objRxnCnt != null)
                        {
                            lblTANsCount.Text = objTANCnt.ToString();
                        }
                    }
                    else if (GlobalVariables.RoleName.ToUpper() == RolesMaster.QC_ANALYST.ToUpper())//- 23rd May 2013
                    {
                        DataView dvTemp = dailystatusdata.Copy().DefaultView;
                        dvTemp.RowFilter = GetRowFilterConditionOnQC(GlobalVariables.UserName.ToUpper());
                        DataTable dtUserReport = dvTemp.ToTable();
                        dgvReport.DataSource = dtUserReport;
                    }
                    else
                    {
                        DataView dvTemp = dailystatusdata.Copy().DefaultView;
                        dvTemp.RowFilter = "USER_NAME = '" + GlobalVariables.UserName.ToUpper() + "'";
                        DataTable dtUserReport = dvTemp.ToTable();
                        dgvReport.DataSource = dtUserReport;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetRowFilterConditionOnQC(string qcName)
        {
            string filterCond = "";
            try
            {
                if (!string.IsNullOrEmpty(qcName))
                {
                    //Get Module Users
                    ModuleUsers = ReactDB.GetUsersByApplicationModule(GlobalVariables.ApplicationName, GlobalVariables.ModuleName);

                    string usersList = "";
                    if (ModuleUsers != null)
                    {
                        if (ModuleUsers.Rows.Count > 0)
                        {
                            using (DataView dvTemp = ModuleUsers.DefaultView)
                            {
                                dvTemp.RowFilter = "QUAL_ANLST_NAME = '" + qcName + "'";

                                DataTable dtUsers = dvTemp.ToTable();

                                if (dtUsers != null)
                                {
                                    foreach (DataRow dRow in dtUsers.Rows)
                                    {
                                        if (string.IsNullOrEmpty(usersList.Trim()))
                                        {
                                            usersList = "'" + dRow["REV_ANLST_NAME"].ToString().Trim() + "'" + ", '" + dRow["ANLST_NAME"].ToString().Trim() + "'";
                                        }
                                        else
                                        {
                                            usersList = usersList.Trim() + ",'" + dRow["REV_ANLST_NAME"].ToString().Trim() + "'" + ", '" + dRow["ANLST_NAME"].ToString().Trim() + "'";
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (!string.IsNullOrEmpty(usersList))
                    {
                        filterCond = "USER_NAME in (" + usersList + ")";
                    }
                    else
                    {
                        filterCond = "USER_NAME is null";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return filterCond;
        }

        private void frmMonthlyReport_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void dgvReport_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();
                while (strRowNumber.Length < dgvReport.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvReport.Font);

                if (dgvReport.RowHeadersWidth < (int)(size.Width + 20)) dgvReport.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvReport.Rows.Count > 0)
                {
                    DialogResult diaRes = MessageBox.Show("Do you want to save the User Monthly Status Report?","Monthly Report",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
                    if (diaRes == DialogResult.Yes)
                    {
                        for (int i = 0; i < dgvReport.Rows.Count; i++)
                        {
                            //PTTProductivity objPttBll = new PTTProductivity();
                            //objPttBll.ApplicationID = 4;//CASREACT Application ID is 4
                            //objPttBll.SupervisorID = 244;//Project InCharge PTT User ID is 244
                            //objPttBll.PTT_UserID = Convert.ToInt32(dgvReport.Rows[i].Cells["colPTTID"].Value.ToString());

                            //objPttBll.UserID = Convert.ToInt32(dgvReport.Rows[i].Cells["colUserID"].Value.ToString());
                            //objPttBll.UserRole = dgvReport.Rows[i].Cells["colUserRole"].Value.ToString();
                            //objPttBll.Productivity = Convert.ToInt32(dgvReport.Rows[i].Cells["colRxnCount"].Value.ToString());

                            //objPttBll.FromDate = dpFromDate.Value.ToShortDateString();
                            //objPttBll.ToDate = dpToDate.Value.ToShortDateString();
                            //PTTProductivityDAL.UpdateUserMonthlyStatusReport(objPttBll);
                        }
                        MessageBox.Show("User Monthly report saved successfully", "Monthly Status Report", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("No Data is available to save","Monthly Status Report",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
