﻿namespace IndxReactNarr.Reports
{
    partial class frmShipmentDetailedReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvReport = new System.Windows.Forms.DataGridView();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.grpRxns = new System.Windows.Forms.GroupBox();
            this.lblRxnCnt_CurAssigned = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblRxnCnt_QcProgr = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblRxnCnt_RevProgr = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblRxnCnt_CurProgr = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblRxnCnt_QcCompl = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblTotalRxnsCnt = new System.Windows.Forms.Label();
            this.lblRxnCnt_RevCompl = new System.Windows.Forms.Label();
            this.lblRxnCnt_CurCompl = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.grpTANs = new System.Windows.Forms.GroupBox();
            this.lblCuration = new System.Windows.Forms.Label();
            this.lblCuration_Val = new System.Windows.Forms.Label();
            this.lblQCProgress_Val = new System.Windows.Forms.Label();
            this.lblReview = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblReview_Val = new System.Windows.Forms.Label();
            this.lblReviewProgress_Val = new System.Windows.Forms.Label();
            this.lblQC = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblQC_Val = new System.Windows.Forms.Label();
            this.lblCurationProgress_Val = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblPending_Val = new System.Windows.Forms.Label();
            this.lblStages = new System.Windows.Forms.Label();
            this.lblPending = new System.Windows.Forms.Label();
            this.lblStages_Val = new System.Windows.Forms.Label();
            this.lblAss_Cur_Val = new System.Windows.Forms.Label();
            this.lblAss_Cur = new System.Windows.Forms.Label();
            this.lblTANCnt = new System.Windows.Forms.Label();
            this.lblTANs = new System.Windows.Forms.Label();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.grpFilters = new System.Windows.Forms.GroupBox();
            this.lblStauts = new System.Windows.Forms.Label();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.lblQCheck = new System.Windows.Forms.Label();
            this.txtQC = new System.Windows.Forms.TextBox();
            this.txtReviewer = new System.Windows.Forms.TextBox();
            this.lblCurator = new System.Windows.Forms.Label();
            this.txtCurator = new System.Windows.Forms.TextBox();
            this.lblTAN = new System.Windows.Forms.Label();
            this.txtTAN = new System.Windows.Forms.TextBox();
            this.lblReviewer = new System.Windows.Forms.Label();
            this.btnGet = new System.Windows.Forms.Button();
            this.txtBatchNo = new System.Windows.Forms.TextBox();
            this.lblBatchNo = new System.Windows.Forms.Label();
            this.txtShipmentName = new System.Windows.Forms.TextBox();
            this.lblBatchName = new System.Windows.Forms.Label();
            this.dataGridViewAutoFilterTextBoxColumn1 = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.dataGridViewAutoFilterTextBoxColumn2 = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.dataGridViewAutoFilterTextBoxColumn3 = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.dataGridViewAutoFilterTextBoxColumn4 = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.dataGridViewAutoFilterTextBoxColumn5 = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.dataGridViewAutoFilterTextBoxColumn6 = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.dataGridViewAutoFilterTextBoxColumn7 = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.dataGridViewAutoFilterTextBoxColumn8 = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.dataGridViewAutoFilterTextBoxColumn9 = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.dataGridViewAutoFilterTextBoxColumn10 = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.dataGridViewAutoFilterTextBoxColumn11 = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.dataGridViewAutoFilterTextBoxColumn12 = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colTAN = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colBatchNo = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colDocClass = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colTANPriority = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colAnalyst = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colRevAnalyst = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colQCAnalyst = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colTaskStatus = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colNUMsCnt = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colReactionCnt = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colExtraStageCnt = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colMappingUpdateCnt = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label10 = new System.Windows.Forms.Label();
            this.lblMappingUpdateCnt = new System.Windows.Forms.Label();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReport)).BeginInit();
            this.pnlBottom.SuspendLayout();
            this.grpRxns.SuspendLayout();
            this.grpTANs.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.grpFilters.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.dgvReport);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1065, 494);
            this.pnlMain.TabIndex = 1;
            // 
            // dgvReport
            // 
            this.dgvReport.AllowUserToAddRows = false;
            this.dgvReport.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvReport.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvReport.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvReport.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            this.dgvReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReport.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTAN,
            this.colBatchNo,
            this.colDocClass,
            this.colTANPriority,
            this.colAnalyst,
            this.colRevAnalyst,
            this.colQCAnalyst,
            this.colTaskStatus,
            this.colNUMsCnt,
            this.colReactionCnt,
            this.colExtraStageCnt,
            this.colMappingUpdateCnt});
            this.dgvReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvReport.Location = new System.Drawing.Point(0, 114);
            this.dgvReport.Name = "dgvReport";
            this.dgvReport.ReadOnly = true;
            this.dgvReport.Size = new System.Drawing.Size(1065, 209);
            this.dgvReport.TabIndex = 1;
            this.dgvReport.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgvReport_DataBindingComplete);
            this.dgvReport.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvReport_RowPostPaint);
            // 
            // pnlBottom
            // 
            this.pnlBottom.BackColor = System.Drawing.Color.White;
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlBottom.Controls.Add(this.grpRxns);
            this.pnlBottom.Controls.Add(this.grpTANs);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 323);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(1065, 171);
            this.pnlBottom.TabIndex = 2;
            // 
            // grpRxns
            // 
            this.grpRxns.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpRxns.Controls.Add(this.lblRxnCnt_CurAssigned);
            this.grpRxns.Controls.Add(this.label1);
            this.grpRxns.Controls.Add(this.lblRxnCnt_QcProgr);
            this.grpRxns.Controls.Add(this.label9);
            this.grpRxns.Controls.Add(this.lblRxnCnt_RevProgr);
            this.grpRxns.Controls.Add(this.label11);
            this.grpRxns.Controls.Add(this.lblRxnCnt_CurProgr);
            this.grpRxns.Controls.Add(this.label13);
            this.grpRxns.Controls.Add(this.label5);
            this.grpRxns.Controls.Add(this.lblRxnCnt_QcCompl);
            this.grpRxns.Controls.Add(this.label3);
            this.grpRxns.Controls.Add(this.label8);
            this.grpRxns.Controls.Add(this.lblTotalRxnsCnt);
            this.grpRxns.Controls.Add(this.lblRxnCnt_RevCompl);
            this.grpRxns.Controls.Add(this.lblRxnCnt_CurCompl);
            this.grpRxns.Controls.Add(this.label7);
            this.grpRxns.Location = new System.Drawing.Point(3, 84);
            this.grpRxns.Name = "grpRxns";
            this.grpRxns.Size = new System.Drawing.Size(1057, 82);
            this.grpRxns.TabIndex = 37;
            this.grpRxns.TabStop = false;
            this.grpRxns.Text = "Reactions";
            // 
            // lblRxnCnt_CurAssigned
            // 
            this.lblRxnCnt_CurAssigned.AutoSize = true;
            this.lblRxnCnt_CurAssigned.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnCnt_CurAssigned.ForeColor = System.Drawing.Color.Red;
            this.lblRxnCnt_CurAssigned.Location = new System.Drawing.Point(286, 20);
            this.lblRxnCnt_CurAssigned.Name = "lblRxnCnt_CurAssigned";
            this.lblRxnCnt_CurAssigned.Size = new System.Drawing.Size(16, 17);
            this.lblRxnCnt_CurAssigned.TabIndex = 44;
            this.lblRxnCnt_CurAssigned.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(140, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 17);
            this.label1.TabIndex = 43;
            this.label1.Text = "Assigned for Curation:";
            // 
            // lblRxnCnt_QcProgr
            // 
            this.lblRxnCnt_QcProgr.AutoSize = true;
            this.lblRxnCnt_QcProgr.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnCnt_QcProgr.ForeColor = System.Drawing.Color.Red;
            this.lblRxnCnt_QcProgr.Location = new System.Drawing.Point(628, 36);
            this.lblRxnCnt_QcProgr.Name = "lblRxnCnt_QcProgr";
            this.lblRxnCnt_QcProgr.Size = new System.Drawing.Size(16, 17);
            this.lblRxnCnt_QcProgr.TabIndex = 42;
            this.lblRxnCnt_QcProgr.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Blue;
            this.label9.Location = new System.Drawing.Point(533, 36);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 17);
            this.label9.TabIndex = 41;
            this.label9.Text = "QC Progress:";
            // 
            // lblRxnCnt_RevProgr
            // 
            this.lblRxnCnt_RevProgr.AutoSize = true;
            this.lblRxnCnt_RevProgr.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnCnt_RevProgr.ForeColor = System.Drawing.Color.Red;
            this.lblRxnCnt_RevProgr.Location = new System.Drawing.Point(470, 48);
            this.lblRxnCnt_RevProgr.Name = "lblRxnCnt_RevProgr";
            this.lblRxnCnt_RevProgr.Size = new System.Drawing.Size(16, 17);
            this.lblRxnCnt_RevProgr.TabIndex = 40;
            this.lblRxnCnt_RevProgr.Text = "0";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Blue;
            this.label11.Location = new System.Drawing.Point(351, 48);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(112, 17);
            this.label11.TabIndex = 39;
            this.label11.Text = "Review Progress:";
            // 
            // lblRxnCnt_CurProgr
            // 
            this.lblRxnCnt_CurProgr.AutoSize = true;
            this.lblRxnCnt_CurProgr.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnCnt_CurProgr.ForeColor = System.Drawing.Color.Red;
            this.lblRxnCnt_CurProgr.Location = new System.Drawing.Point(286, 49);
            this.lblRxnCnt_CurProgr.Name = "lblRxnCnt_CurProgr";
            this.lblRxnCnt_CurProgr.Size = new System.Drawing.Size(16, 17);
            this.lblRxnCnt_CurProgr.TabIndex = 38;
            this.lblRxnCnt_CurProgr.Text = "0";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(159, 49);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(117, 17);
            this.label13.TabIndex = 37;
            this.label13.Text = "Curation Progress:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(351, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 17);
            this.label5.TabIndex = 31;
            this.label5.Text = "Review Assigned:";
            // 
            // lblRxnCnt_QcCompl
            // 
            this.lblRxnCnt_QcCompl.AutoSize = true;
            this.lblRxnCnt_QcCompl.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnCnt_QcCompl.ForeColor = System.Drawing.Color.Red;
            this.lblRxnCnt_QcCompl.Location = new System.Drawing.Point(627, 59);
            this.lblRxnCnt_QcCompl.Name = "lblRxnCnt_QcCompl";
            this.lblRxnCnt_QcCompl.Size = new System.Drawing.Size(16, 17);
            this.lblRxnCnt_QcCompl.TabIndex = 36;
            this.lblRxnCnt_QcCompl.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(4, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 17);
            this.label3.TabIndex = 29;
            this.label3.Text = "No.of Rxns: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(522, 59);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(99, 17);
            this.label8.TabIndex = 35;
            this.label8.Text = "QC Completed:";
            // 
            // lblTotalRxnsCnt
            // 
            this.lblTotalRxnsCnt.AutoSize = true;
            this.lblTotalRxnsCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalRxnsCnt.ForeColor = System.Drawing.Color.Red;
            this.lblTotalRxnsCnt.Location = new System.Drawing.Point(86, 21);
            this.lblTotalRxnsCnt.Name = "lblTotalRxnsCnt";
            this.lblTotalRxnsCnt.Size = new System.Drawing.Size(16, 17);
            this.lblTotalRxnsCnt.TabIndex = 30;
            this.lblTotalRxnsCnt.Text = "0";
            // 
            // lblRxnCnt_RevCompl
            // 
            this.lblRxnCnt_RevCompl.AutoSize = true;
            this.lblRxnCnt_RevCompl.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnCnt_RevCompl.ForeColor = System.Drawing.Color.Red;
            this.lblRxnCnt_RevCompl.Location = new System.Drawing.Point(628, 14);
            this.lblRxnCnt_RevCompl.Name = "lblRxnCnt_RevCompl";
            this.lblRxnCnt_RevCompl.Size = new System.Drawing.Size(16, 17);
            this.lblRxnCnt_RevCompl.TabIndex = 34;
            this.lblRxnCnt_RevCompl.Text = "0";
            // 
            // lblRxnCnt_CurCompl
            // 
            this.lblRxnCnt_CurCompl.AutoSize = true;
            this.lblRxnCnt_CurCompl.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnCnt_CurCompl.ForeColor = System.Drawing.Color.Red;
            this.lblRxnCnt_CurCompl.Location = new System.Drawing.Point(470, 21);
            this.lblRxnCnt_CurCompl.Name = "lblRxnCnt_CurCompl";
            this.lblRxnCnt_CurCompl.Size = new System.Drawing.Size(16, 17);
            this.lblRxnCnt_CurCompl.TabIndex = 32;
            this.lblRxnCnt_CurCompl.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(532, 14);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 17);
            this.label7.TabIndex = 33;
            this.label7.Text = "QC Assigned:";
            // 
            // grpTANs
            // 
            this.grpTANs.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpTANs.Controls.Add(this.label10);
            this.grpTANs.Controls.Add(this.lblMappingUpdateCnt);
            this.grpTANs.Controls.Add(this.lblCuration);
            this.grpTANs.Controls.Add(this.lblCuration_Val);
            this.grpTANs.Controls.Add(this.lblQCProgress_Val);
            this.grpTANs.Controls.Add(this.lblReview);
            this.grpTANs.Controls.Add(this.label2);
            this.grpTANs.Controls.Add(this.lblReview_Val);
            this.grpTANs.Controls.Add(this.lblReviewProgress_Val);
            this.grpTANs.Controls.Add(this.lblQC);
            this.grpTANs.Controls.Add(this.label4);
            this.grpTANs.Controls.Add(this.lblQC_Val);
            this.grpTANs.Controls.Add(this.lblCurationProgress_Val);
            this.grpTANs.Controls.Add(this.label6);
            this.grpTANs.Controls.Add(this.lblPending_Val);
            this.grpTANs.Controls.Add(this.lblStages);
            this.grpTANs.Controls.Add(this.lblPending);
            this.grpTANs.Controls.Add(this.lblStages_Val);
            this.grpTANs.Controls.Add(this.lblAss_Cur_Val);
            this.grpTANs.Controls.Add(this.lblAss_Cur);
            this.grpTANs.Controls.Add(this.lblTANCnt);
            this.grpTANs.Controls.Add(this.lblTANs);
            this.grpTANs.Location = new System.Drawing.Point(3, 2);
            this.grpTANs.Name = "grpTANs";
            this.grpTANs.Size = new System.Drawing.Size(1057, 81);
            this.grpTANs.TabIndex = 38;
            this.grpTANs.TabStop = false;
            this.grpTANs.Text = "TANs";
            // 
            // lblCuration
            // 
            this.lblCuration.AutoSize = true;
            this.lblCuration.ForeColor = System.Drawing.Color.Blue;
            this.lblCuration.Location = new System.Drawing.Point(350, 15);
            this.lblCuration.Name = "lblCuration";
            this.lblCuration.Size = new System.Drawing.Size(113, 17);
            this.lblCuration.TabIndex = 3;
            this.lblCuration.Text = "Review Assigned:";
            // 
            // lblCuration_Val
            // 
            this.lblCuration_Val.AutoSize = true;
            this.lblCuration_Val.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCuration_Val.ForeColor = System.Drawing.Color.Red;
            this.lblCuration_Val.Location = new System.Drawing.Point(470, 15);
            this.lblCuration_Val.Name = "lblCuration_Val";
            this.lblCuration_Val.Size = new System.Drawing.Size(16, 17);
            this.lblCuration_Val.TabIndex = 4;
            this.lblCuration_Val.Text = "0";
            // 
            // lblQCProgress_Val
            // 
            this.lblQCProgress_Val.AutoSize = true;
            this.lblQCProgress_Val.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQCProgress_Val.ForeColor = System.Drawing.Color.Red;
            this.lblQCProgress_Val.Location = new System.Drawing.Point(628, 38);
            this.lblQCProgress_Val.Name = "lblQCProgress_Val";
            this.lblQCProgress_Val.Size = new System.Drawing.Size(16, 17);
            this.lblQCProgress_Val.TabIndex = 28;
            this.lblQCProgress_Val.Text = "0";
            // 
            // lblReview
            // 
            this.lblReview.AutoSize = true;
            this.lblReview.ForeColor = System.Drawing.Color.Blue;
            this.lblReview.Location = new System.Drawing.Point(530, 15);
            this.lblReview.Name = "lblReview";
            this.lblReview.Size = new System.Drawing.Size(89, 17);
            this.lblReview.TabIndex = 5;
            this.lblReview.Text = "QC Assigned:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(531, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 17);
            this.label2.TabIndex = 27;
            this.label2.Text = "QC Progress:";
            // 
            // lblReview_Val
            // 
            this.lblReview_Val.AutoSize = true;
            this.lblReview_Val.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReview_Val.ForeColor = System.Drawing.Color.Red;
            this.lblReview_Val.Location = new System.Drawing.Point(628, 15);
            this.lblReview_Val.Name = "lblReview_Val";
            this.lblReview_Val.Size = new System.Drawing.Size(16, 17);
            this.lblReview_Val.TabIndex = 6;
            this.lblReview_Val.Text = "0";
            // 
            // lblReviewProgress_Val
            // 
            this.lblReviewProgress_Val.AutoSize = true;
            this.lblReviewProgress_Val.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReviewProgress_Val.ForeColor = System.Drawing.Color.Red;
            this.lblReviewProgress_Val.Location = new System.Drawing.Point(470, 39);
            this.lblReviewProgress_Val.Name = "lblReviewProgress_Val";
            this.lblReviewProgress_Val.Size = new System.Drawing.Size(16, 17);
            this.lblReviewProgress_Val.TabIndex = 26;
            this.lblReviewProgress_Val.Text = "0";
            // 
            // lblQC
            // 
            this.lblQC.AutoSize = true;
            this.lblQC.ForeColor = System.Drawing.Color.Blue;
            this.lblQC.Location = new System.Drawing.Point(523, 61);
            this.lblQC.Name = "lblQC";
            this.lblQC.Size = new System.Drawing.Size(99, 17);
            this.lblQC.TabIndex = 7;
            this.lblQC.Text = "QC Completed:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(351, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 17);
            this.label4.TabIndex = 25;
            this.label4.Text = "Review Progress:";
            // 
            // lblQC_Val
            // 
            this.lblQC_Val.AutoSize = true;
            this.lblQC_Val.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQC_Val.ForeColor = System.Drawing.Color.Red;
            this.lblQC_Val.Location = new System.Drawing.Point(628, 61);
            this.lblQC_Val.Name = "lblQC_Val";
            this.lblQC_Val.Size = new System.Drawing.Size(16, 17);
            this.lblQC_Val.TabIndex = 8;
            this.lblQC_Val.Text = "0";
            // 
            // lblCurationProgress_Val
            // 
            this.lblCurationProgress_Val.AutoSize = true;
            this.lblCurationProgress_Val.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurationProgress_Val.ForeColor = System.Drawing.Color.Red;
            this.lblCurationProgress_Val.Location = new System.Drawing.Point(286, 39);
            this.lblCurationProgress_Val.Name = "lblCurationProgress_Val";
            this.lblCurationProgress_Val.Size = new System.Drawing.Size(16, 17);
            this.lblCurationProgress_Val.TabIndex = 24;
            this.lblCurationProgress_Val.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(163, 39);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 17);
            this.label6.TabIndex = 23;
            this.label6.Text = "Curation Progress:";
            // 
            // lblPending_Val
            // 
            this.lblPending_Val.AutoSize = true;
            this.lblPending_Val.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPending_Val.ForeColor = System.Drawing.Color.Red;
            this.lblPending_Val.Location = new System.Drawing.Point(973, 38);
            this.lblPending_Val.Name = "lblPending_Val";
            this.lblPending_Val.Size = new System.Drawing.Size(16, 17);
            this.lblPending_Val.TabIndex = 22;
            this.lblPending_Val.Text = "0";
            // 
            // lblStages
            // 
            this.lblStages.AutoSize = true;
            this.lblStages.ForeColor = System.Drawing.Color.Blue;
            this.lblStages.Location = new System.Drawing.Point(850, 15);
            this.lblStages.Name = "lblStages";
            this.lblStages.Size = new System.Drawing.Size(124, 17);
            this.lblStages.TabIndex = 11;
            this.lblStages.Text = "No.of Extra Stages:";
            // 
            // lblPending
            // 
            this.lblPending.AutoSize = true;
            this.lblPending.ForeColor = System.Drawing.Color.Blue;
            this.lblPending.Location = new System.Drawing.Point(872, 38);
            this.lblPending.Name = "lblPending";
            this.lblPending.Size = new System.Drawing.Size(98, 17);
            this.lblPending.TabIndex = 21;
            this.lblPending.Text = "Pending TANs:";
            // 
            // lblStages_Val
            // 
            this.lblStages_Val.AutoSize = true;
            this.lblStages_Val.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStages_Val.ForeColor = System.Drawing.Color.Red;
            this.lblStages_Val.Location = new System.Drawing.Point(972, 15);
            this.lblStages_Val.Name = "lblStages_Val";
            this.lblStages_Val.Size = new System.Drawing.Size(16, 17);
            this.lblStages_Val.TabIndex = 12;
            this.lblStages_Val.Text = "0";
            // 
            // lblAss_Cur_Val
            // 
            this.lblAss_Cur_Val.AutoSize = true;
            this.lblAss_Cur_Val.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAss_Cur_Val.ForeColor = System.Drawing.Color.Red;
            this.lblAss_Cur_Val.Location = new System.Drawing.Point(286, 15);
            this.lblAss_Cur_Val.Name = "lblAss_Cur_Val";
            this.lblAss_Cur_Val.Size = new System.Drawing.Size(16, 17);
            this.lblAss_Cur_Val.TabIndex = 16;
            this.lblAss_Cur_Val.Text = "0";
            // 
            // lblAss_Cur
            // 
            this.lblAss_Cur.AutoSize = true;
            this.lblAss_Cur.ForeColor = System.Drawing.Color.Blue;
            this.lblAss_Cur.Location = new System.Drawing.Point(140, 15);
            this.lblAss_Cur.Name = "lblAss_Cur";
            this.lblAss_Cur.Size = new System.Drawing.Size(140, 17);
            this.lblAss_Cur.TabIndex = 15;
            this.lblAss_Cur.Text = "Assigned for Curation:";
            // 
            // lblTANCnt
            // 
            this.lblTANCnt.AutoSize = true;
            this.lblTANCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTANCnt.ForeColor = System.Drawing.Color.Red;
            this.lblTANCnt.Location = new System.Drawing.Point(87, 16);
            this.lblTANCnt.Name = "lblTANCnt";
            this.lblTANCnt.Size = new System.Drawing.Size(16, 17);
            this.lblTANCnt.TabIndex = 14;
            this.lblTANCnt.Text = "0";
            // 
            // lblTANs
            // 
            this.lblTANs.AutoSize = true;
            this.lblTANs.ForeColor = System.Drawing.Color.Blue;
            this.lblTANs.Location = new System.Drawing.Point(1, 17);
            this.lblTANs.Name = "lblTANs";
            this.lblTANs.Size = new System.Drawing.Size(89, 17);
            this.lblTANs.TabIndex = 13;
            this.lblTANs.Text = "No.of TANs: ";
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.White;
            this.pnlTop.Controls.Add(this.grpFilters);
            this.pnlTop.Controls.Add(this.btnGet);
            this.pnlTop.Controls.Add(this.txtBatchNo);
            this.pnlTop.Controls.Add(this.lblBatchNo);
            this.pnlTop.Controls.Add(this.txtShipmentName);
            this.pnlTop.Controls.Add(this.lblBatchName);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1065, 114);
            this.pnlTop.TabIndex = 0;
            // 
            // grpFilters
            // 
            this.grpFilters.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpFilters.Controls.Add(this.lblStauts);
            this.grpFilters.Controls.Add(this.txtStatus);
            this.grpFilters.Controls.Add(this.lblQCheck);
            this.grpFilters.Controls.Add(this.txtQC);
            this.grpFilters.Controls.Add(this.txtReviewer);
            this.grpFilters.Controls.Add(this.lblCurator);
            this.grpFilters.Controls.Add(this.txtCurator);
            this.grpFilters.Controls.Add(this.lblTAN);
            this.grpFilters.Controls.Add(this.txtTAN);
            this.grpFilters.Controls.Add(this.lblReviewer);
            this.grpFilters.ForeColor = System.Drawing.Color.Blue;
            this.grpFilters.Location = new System.Drawing.Point(4, 29);
            this.grpFilters.Name = "grpFilters";
            this.grpFilters.Size = new System.Drawing.Size(1058, 80);
            this.grpFilters.TabIndex = 5;
            this.grpFilters.TabStop = false;
            this.grpFilters.Text = "Search Options";
            // 
            // lblStauts
            // 
            this.lblStauts.AutoSize = true;
            this.lblStauts.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStauts.ForeColor = System.Drawing.Color.Black;
            this.lblStauts.Location = new System.Drawing.Point(648, 24);
            this.lblStauts.Name = "lblStauts";
            this.lblStauts.Size = new System.Drawing.Size(44, 17);
            this.lblStauts.TabIndex = 20;
            this.lblStauts.Text = "Status";
            // 
            // txtStatus
            // 
            this.txtStatus.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStatus.ForeColor = System.Drawing.Color.Blue;
            this.txtStatus.Location = new System.Drawing.Point(698, 20);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(351, 25);
            this.txtStatus.TabIndex = 19;
            this.txtStatus.TextChanged += new System.EventHandler(this.txtStatus_TextChanged);
            // 
            // lblQCheck
            // 
            this.lblQCheck.AutoSize = true;
            this.lblQCheck.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQCheck.ForeColor = System.Drawing.Color.Black;
            this.lblQCheck.Location = new System.Drawing.Point(663, 55);
            this.lblQCheck.Name = "lblQCheck";
            this.lblQCheck.Size = new System.Drawing.Size(29, 17);
            this.lblQCheck.TabIndex = 18;
            this.lblQCheck.Text = "QC";
            // 
            // txtQC
            // 
            this.txtQC.AcceptsTab = true;
            this.txtQC.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQC.ForeColor = System.Drawing.Color.Blue;
            this.txtQC.Location = new System.Drawing.Point(698, 51);
            this.txtQC.Name = "txtQC";
            this.txtQC.Size = new System.Drawing.Size(351, 25);
            this.txtQC.TabIndex = 17;
            this.txtQC.TextChanged += new System.EventHandler(this.txtQC_TextChanged);
            // 
            // txtReviewer
            // 
            this.txtReviewer.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReviewer.ForeColor = System.Drawing.Color.Blue;
            this.txtReviewer.Location = new System.Drawing.Point(371, 51);
            this.txtReviewer.Name = "txtReviewer";
            this.txtReviewer.Size = new System.Drawing.Size(271, 25);
            this.txtReviewer.TabIndex = 15;
            this.txtReviewer.TextChanged += new System.EventHandler(this.txtReviewer_TextChanged);
            // 
            // lblCurator
            // 
            this.lblCurator.AutoSize = true;
            this.lblCurator.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurator.ForeColor = System.Drawing.Color.Black;
            this.lblCurator.Location = new System.Drawing.Point(5, 55);
            this.lblCurator.Name = "lblCurator";
            this.lblCurator.Size = new System.Drawing.Size(53, 17);
            this.lblCurator.TabIndex = 14;
            this.lblCurator.Text = "Analyst";
            // 
            // txtCurator
            // 
            this.txtCurator.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCurator.ForeColor = System.Drawing.Color.Blue;
            this.txtCurator.Location = new System.Drawing.Point(64, 51);
            this.txtCurator.Name = "txtCurator";
            this.txtCurator.Size = new System.Drawing.Size(203, 25);
            this.txtCurator.TabIndex = 13;
            this.txtCurator.TextChanged += new System.EventHandler(this.txtCurator_TextChanged);
            // 
            // lblTAN
            // 
            this.lblTAN.AutoSize = true;
            this.lblTAN.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTAN.ForeColor = System.Drawing.Color.Black;
            this.lblTAN.Location = new System.Drawing.Point(19, 21);
            this.lblTAN.Name = "lblTAN";
            this.lblTAN.Size = new System.Drawing.Size(38, 17);
            this.lblTAN.TabIndex = 12;
            this.lblTAN.Text = "TAN";
            // 
            // txtTAN
            // 
            this.txtTAN.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTAN.ForeColor = System.Drawing.Color.Blue;
            this.txtTAN.Location = new System.Drawing.Point(64, 20);
            this.txtTAN.Name = "txtTAN";
            this.txtTAN.Size = new System.Drawing.Size(578, 25);
            this.txtTAN.TabIndex = 11;
            this.txtTAN.TextChanged += new System.EventHandler(this.txtTAN_TextChanged);
            // 
            // lblReviewer
            // 
            this.lblReviewer.AutoSize = true;
            this.lblReviewer.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReviewer.ForeColor = System.Drawing.Color.Black;
            this.lblReviewer.Location = new System.Drawing.Point(273, 55);
            this.lblReviewer.Name = "lblReviewer";
            this.lblReviewer.Size = new System.Drawing.Size(101, 17);
            this.lblReviewer.TabIndex = 16;
            this.lblReviewer.Text = "Review Analyst";
            // 
            // btnGet
            // 
            this.btnGet.Location = new System.Drawing.Point(498, 3);
            this.btnGet.Name = "btnGet";
            this.btnGet.Size = new System.Drawing.Size(88, 27);
            this.btnGet.TabIndex = 4;
            this.btnGet.Text = "Get Report";
            this.btnGet.UseVisualStyleBackColor = true;
            this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
            // 
            // txtBatchNo
            // 
            this.txtBatchNo.ForeColor = System.Drawing.Color.Blue;
            this.txtBatchNo.Location = new System.Drawing.Point(442, 4);
            this.txtBatchNo.Name = "txtBatchNo";
            this.txtBatchNo.Size = new System.Drawing.Size(39, 25);
            this.txtBatchNo.TabIndex = 3;
            this.txtBatchNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblBatchNo
            // 
            this.lblBatchNo.AutoSize = true;
            this.lblBatchNo.Location = new System.Drawing.Point(372, 8);
            this.lblBatchNo.Name = "lblBatchNo";
            this.lblBatchNo.Size = new System.Drawing.Size(69, 17);
            this.lblBatchNo.TabIndex = 2;
            this.lblBatchNo.Text = "Batch No.";
            // 
            // txtShipmentName
            // 
            this.txtShipmentName.ForeColor = System.Drawing.Color.Blue;
            this.txtShipmentName.Location = new System.Drawing.Point(111, 4);
            this.txtShipmentName.Name = "txtShipmentName";
            this.txtShipmentName.Size = new System.Drawing.Size(255, 25);
            this.txtShipmentName.TabIndex = 1;
            // 
            // lblBatchName
            // 
            this.lblBatchName.AutoSize = true;
            this.lblBatchName.Location = new System.Drawing.Point(4, 8);
            this.lblBatchName.Name = "lblBatchName";
            this.lblBatchName.Size = new System.Drawing.Size(102, 17);
            this.lblBatchName.TabIndex = 0;
            this.lblBatchName.Text = "Shipment Name";
            // 
            // dataGridViewAutoFilterTextBoxColumn1
            // 
            this.dataGridViewAutoFilterTextBoxColumn1.HeaderText = "TAN";
            this.dataGridViewAutoFilterTextBoxColumn1.Name = "dataGridViewAutoFilterTextBoxColumn1";
            this.dataGridViewAutoFilterTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewAutoFilterTextBoxColumn2
            // 
            this.dataGridViewAutoFilterTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewAutoFilterTextBoxColumn2.HeaderText = "B.No";
            this.dataGridViewAutoFilterTextBoxColumn2.Name = "dataGridViewAutoFilterTextBoxColumn2";
            this.dataGridViewAutoFilterTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewAutoFilterTextBoxColumn2.Width = 50;
            // 
            // dataGridViewAutoFilterTextBoxColumn3
            // 
            this.dataGridViewAutoFilterTextBoxColumn3.HeaderText = "DocClass";
            this.dataGridViewAutoFilterTextBoxColumn3.Name = "dataGridViewAutoFilterTextBoxColumn3";
            this.dataGridViewAutoFilterTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewAutoFilterTextBoxColumn4
            // 
            this.dataGridViewAutoFilterTextBoxColumn4.HeaderText = "Priority";
            this.dataGridViewAutoFilterTextBoxColumn4.Name = "dataGridViewAutoFilterTextBoxColumn4";
            // 
            // dataGridViewAutoFilterTextBoxColumn5
            // 
            this.dataGridViewAutoFilterTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewAutoFilterTextBoxColumn5.HeaderText = "Analyst";
            this.dataGridViewAutoFilterTextBoxColumn5.Name = "dataGridViewAutoFilterTextBoxColumn5";
            this.dataGridViewAutoFilterTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewAutoFilterTextBoxColumn6
            // 
            this.dataGridViewAutoFilterTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewAutoFilterTextBoxColumn6.HeaderText = "Rev.Analyst";
            this.dataGridViewAutoFilterTextBoxColumn6.Name = "dataGridViewAutoFilterTextBoxColumn6";
            this.dataGridViewAutoFilterTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewAutoFilterTextBoxColumn7
            // 
            this.dataGridViewAutoFilterTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewAutoFilterTextBoxColumn7.HeaderText = "QcAnalyst";
            this.dataGridViewAutoFilterTextBoxColumn7.Name = "dataGridViewAutoFilterTextBoxColumn7";
            this.dataGridViewAutoFilterTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewAutoFilterTextBoxColumn8
            // 
            this.dataGridViewAutoFilterTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewAutoFilterTextBoxColumn8.HeaderText = "TANStatus";
            this.dataGridViewAutoFilterTextBoxColumn8.Name = "dataGridViewAutoFilterTextBoxColumn8";
            this.dataGridViewAutoFilterTextBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewAutoFilterTextBoxColumn9
            // 
            this.dataGridViewAutoFilterTextBoxColumn9.HeaderText = "NUMsCnt";
            this.dataGridViewAutoFilterTextBoxColumn9.Name = "dataGridViewAutoFilterTextBoxColumn9";
            this.dataGridViewAutoFilterTextBoxColumn9.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewAutoFilterTextBoxColumn10
            // 
            this.dataGridViewAutoFilterTextBoxColumn10.HeaderText = "RxnCnt";
            this.dataGridViewAutoFilterTextBoxColumn10.Name = "dataGridViewAutoFilterTextBoxColumn10";
            this.dataGridViewAutoFilterTextBoxColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewAutoFilterTextBoxColumn11
            // 
            this.dataGridViewAutoFilterTextBoxColumn11.HeaderText = "ExtraStages";
            this.dataGridViewAutoFilterTextBoxColumn11.Name = "dataGridViewAutoFilterTextBoxColumn11";
            this.dataGridViewAutoFilterTextBoxColumn11.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewAutoFilterTextBoxColumn12
            // 
            this.dataGridViewAutoFilterTextBoxColumn12.HeaderText = "MappingUpdateCnt";
            this.dataGridViewAutoFilterTextBoxColumn12.Name = "dataGridViewAutoFilterTextBoxColumn12";
            this.dataGridViewAutoFilterTextBoxColumn12.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colTAN
            // 
            this.colTAN.HeaderText = "TAN";
            this.colTAN.Name = "colTAN";
            this.colTAN.ReadOnly = true;
            this.colTAN.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colBatchNo
            // 
            this.colBatchNo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colBatchNo.HeaderText = "B.No";
            this.colBatchNo.Name = "colBatchNo";
            this.colBatchNo.ReadOnly = true;
            this.colBatchNo.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colBatchNo.Width = 50;
            // 
            // colDocClass
            // 
            this.colDocClass.HeaderText = "DocClass";
            this.colDocClass.Name = "colDocClass";
            this.colDocClass.ReadOnly = true;
            this.colDocClass.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colTANPriority
            // 
            this.colTANPriority.HeaderText = "Priority";
            this.colTANPriority.Name = "colTANPriority";
            this.colTANPriority.ReadOnly = true;
            // 
            // colAnalyst
            // 
            this.colAnalyst.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colAnalyst.HeaderText = "Analyst";
            this.colAnalyst.Name = "colAnalyst";
            this.colAnalyst.ReadOnly = true;
            this.colAnalyst.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colRevAnalyst
            // 
            this.colRevAnalyst.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colRevAnalyst.HeaderText = "Rev.Analyst";
            this.colRevAnalyst.Name = "colRevAnalyst";
            this.colRevAnalyst.ReadOnly = true;
            this.colRevAnalyst.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colQCAnalyst
            // 
            this.colQCAnalyst.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colQCAnalyst.HeaderText = "QcAnalyst";
            this.colQCAnalyst.Name = "colQCAnalyst";
            this.colQCAnalyst.ReadOnly = true;
            this.colQCAnalyst.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colTaskStatus
            // 
            this.colTaskStatus.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colTaskStatus.HeaderText = "TANStatus";
            this.colTaskStatus.Name = "colTaskStatus";
            this.colTaskStatus.ReadOnly = true;
            this.colTaskStatus.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colNUMsCnt
            // 
            this.colNUMsCnt.HeaderText = "NUMsCnt";
            this.colNUMsCnt.Name = "colNUMsCnt";
            this.colNUMsCnt.ReadOnly = true;
            this.colNUMsCnt.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colReactionCnt
            // 
            this.colReactionCnt.HeaderText = "RxnCnt";
            this.colReactionCnt.Name = "colReactionCnt";
            this.colReactionCnt.ReadOnly = true;
            this.colReactionCnt.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colExtraStageCnt
            // 
            this.colExtraStageCnt.HeaderText = "ExtraStages";
            this.colExtraStageCnt.Name = "colExtraStageCnt";
            this.colExtraStageCnt.ReadOnly = true;
            this.colExtraStageCnt.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colMappingUpdateCnt
            // 
            this.colMappingUpdateCnt.HeaderText = "MappingUpdateCnt";
            this.colMappingUpdateCnt.Name = "colMappingUpdateCnt";
            this.colMappingUpdateCnt.ReadOnly = true;
            this.colMappingUpdateCnt.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "TAN";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn2.HeaderText = "BatchNo";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 50;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn3.HeaderText = "Analyst";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn4.HeaderText = "Rev.Analyst";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn5.HeaderText = "QcAnalyst";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn6.HeaderText = "TAN Status";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "ReactionCnt";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "ExtraStages";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "ExtraStages";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Blue;
            this.label10.Location = new System.Drawing.Point(788, 61);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(182, 17);
            this.label10.TabIndex = 29;
            this.label10.Text = "Rxns Mapping Update Count:";
            // 
            // lblMappingUpdateCnt
            // 
            this.lblMappingUpdateCnt.AutoSize = true;
            this.lblMappingUpdateCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMappingUpdateCnt.ForeColor = System.Drawing.Color.Red;
            this.lblMappingUpdateCnt.Location = new System.Drawing.Point(973, 61);
            this.lblMappingUpdateCnt.Name = "lblMappingUpdateCnt";
            this.lblMappingUpdateCnt.Size = new System.Drawing.Size(16, 17);
            this.lblMappingUpdateCnt.TabIndex = 30;
            this.lblMappingUpdateCnt.Text = "0";
            // 
            // frmShipmentDetailedReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1065, 494);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmShipmentDetailedReport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Shipment Detailed Report";
            this.Load += new System.EventHandler(this.frmShipmentDetailedReport_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvReport)).EndInit();
            this.pnlBottom.ResumeLayout(false);
            this.grpRxns.ResumeLayout(false);
            this.grpRxns.PerformLayout();
            this.grpTANs.ResumeLayout(false);
            this.grpTANs.PerformLayout();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.grpFilters.ResumeLayout(false);
            this.grpFilters.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.DataGridView dgvReport;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Label lblPending_Val;
        private System.Windows.Forms.Label lblPending;
        private System.Windows.Forms.Label lblAss_Cur_Val;
        private System.Windows.Forms.Label lblAss_Cur;
        private System.Windows.Forms.Label lblTANCnt;
        private System.Windows.Forms.Label lblTANs;
        private System.Windows.Forms.Label lblStages_Val;
        private System.Windows.Forms.Label lblStages;
        private System.Windows.Forms.Label lblQC_Val;
        private System.Windows.Forms.Label lblQC;
        private System.Windows.Forms.Label lblReview_Val;
        private System.Windows.Forms.Label lblReview;
        private System.Windows.Forms.Label lblCuration_Val;
        private System.Windows.Forms.Label lblCuration;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.GroupBox grpFilters;
        private System.Windows.Forms.Label lblStauts;
        private System.Windows.Forms.TextBox txtStatus;
        private System.Windows.Forms.Label lblQCheck;
        private System.Windows.Forms.TextBox txtQC;
        private System.Windows.Forms.Label lblReviewer;
        private System.Windows.Forms.TextBox txtReviewer;
        private System.Windows.Forms.Label lblCurator;
        private System.Windows.Forms.TextBox txtCurator;
        private System.Windows.Forms.Label lblTAN;
        private System.Windows.Forms.TextBox txtTAN;
        private System.Windows.Forms.Button btnGet;
        private System.Windows.Forms.TextBox txtBatchNo;
        private System.Windows.Forms.Label lblBatchNo;
        private System.Windows.Forms.TextBox txtShipmentName;
        private System.Windows.Forms.Label lblBatchName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.Label lblQCProgress_Val;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblReviewProgress_Val;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblCurationProgress_Val;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox grpRxns;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblRxnCnt_QcCompl;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblTotalRxnsCnt;
        private System.Windows.Forms.Label lblRxnCnt_RevCompl;
        private System.Windows.Forms.Label lblRxnCnt_CurCompl;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblRxnCnt_QcProgr;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblRxnCnt_RevProgr;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblRxnCnt_CurProgr;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox grpTANs;
        private System.Windows.Forms.Label lblRxnCnt_CurAssigned;
        private System.Windows.Forms.Label label1;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colTAN;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colBatchNo;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colDocClass;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colTANPriority;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colAnalyst;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colRevAnalyst;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colQCAnalyst;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colTaskStatus;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colNUMsCnt;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colReactionCnt;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colExtraStageCnt;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colMappingUpdateCnt;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblMappingUpdateCnt;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn dataGridViewAutoFilterTextBoxColumn1;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn dataGridViewAutoFilterTextBoxColumn2;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn dataGridViewAutoFilterTextBoxColumn3;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn dataGridViewAutoFilterTextBoxColumn4;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn dataGridViewAutoFilterTextBoxColumn5;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn dataGridViewAutoFilterTextBoxColumn6;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn dataGridViewAutoFilterTextBoxColumn7;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn dataGridViewAutoFilterTextBoxColumn8;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn dataGridViewAutoFilterTextBoxColumn9;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn dataGridViewAutoFilterTextBoxColumn10;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn dataGridViewAutoFilterTextBoxColumn11;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn dataGridViewAutoFilterTextBoxColumn12;
    }
}