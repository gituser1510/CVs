﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using IndxReactNarrDAL;
using System.IO;
using MSExcel = Microsoft.Office.Interop.Excel;

namespace IndxReactNarr.Reports
{
    public partial class frmDeliveryReport : Form
    {
        public frmDeliveryReport()
        {
            InitializeComponent();
        }
               
        BindingSource bsDeliveries = new BindingSource();
        BindingSource bsTans = new BindingSource();
        string path = string.Empty;

        private void frmDeliveryReport_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;

                DataTable dtDeliveries = GetApplicationDeliveries();
                BindDeliveriesDatatableToGrid(dtDeliveries);                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindDeliveriesDatatableToGrid(DataTable deliveryMaster)
        {
            try
            {
                dgvDeliveryMaster.AutoGenerateColumns = false;
                bsDeliveries.DataSource = deliveryMaster;
                dgvDeliveryMaster.DataSource = bsDeliveries;                                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private DataTable GetApplicationDeliveries()
        {
            DataTable dtDeliTemp = null;            
            try
            {
                if (!string.IsNullOrEmpty(GlobalVariables.ApplicationName))
                {
                    dtDeliTemp = DeliveryManagementDB.GetDeliveries(GlobalVariables.ApplicationName);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtDeliTemp;
        }
        
        private void BindTansInfoToGrid(DataTable deliveryTANs)
        {
            try
            {
                if (deliveryTANs != null && deliveryTANs.Rows.Count > 0)
                {
                    dgvDeliveryTANs.DataSource = null;
                    dgvDeliveryTANs.AutoGenerateColumns = false;
                    bsTans.DataSource = deliveryTANs;
                    dgvDeliveryTANs.DataSource = bsTans;

                    colRxnCount.DataPropertyName = "REACTION_CNT";

                    lblTANscnt.Text = deliveryTANs.Rows.Count.ToString();
                }
                else
                {
                    bsTans.DataSource = null;
                    dgvDeliveryTANs.DataSource = bsTans;

                    lblTANscnt.Text = "--";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private DataTable GetDeliveryTANsInfo(int deliveryID)
        {
            DataTable dtDeliveryTANs = null;
            try
            {
                if (deliveryID > 0)
                {
                    dtDeliveryTANs = DeliveryManagementDB.GetDeliveriesTansByDeliveryID(deliveryID);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtDeliveryTANs;
        }

        private void dgvDeliveryMaster_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();
                while (strRowNumber.Length < dgvDeliveryMaster.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvDeliveryMaster.Font);

                if (dgvDeliveryMaster.RowHeadersWidth < (int)(size.Width + 20)) dgvDeliveryMaster.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvTansRep_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();
                while (strRowNumber.Length < dgvDeliveryTANs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvDeliveryTANs.Font);

                if (dgvDeliveryTANs.RowHeadersWidth < (int)(size.Width + 20)) dgvDeliveryTANs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                FolderBrowserDialog fldBrowse = new FolderBrowserDialog();
                if (fldBrowse.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    path = fldBrowse.SelectedPath;
                    txtPath.Text = path;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(path))
                {
                    if (dgvDeliveryTANs.Rows.Count > 0)
                    {
                        string strFileName = "Delivery Report " + "_" + DateTime.Today.ToString("dd-MM-yyyy") + "_" + DateTime.Now.ToString("h-mm-ss") + "_" + "Report";

                        DataTable dtReport = bsTans.DataSource as DataTable;
                        dtReport.Locale = System.Globalization.CultureInfo.CurrentUICulture;
                        if (dtReport != null && dtReport.Rows.Count > 0)
                        {
                            DialogResult diaRes = MessageBox.Show("Do you want to export Report?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            if (diaRes == System.Windows.Forms.DialogResult.Yes)
                            {
                                FolderBrowserDialog objFBD = new FolderBrowserDialog();
                                if (objFBD.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                                {
                                    MSExcel.Application excel;
                                    excel = new MSExcel.Application();
                                    excel.DisplayAlerts = false;

                                    MSExcel.Workbook workbook = excel.Application.Workbooks.Add(true);

                                    int icol = 0;
                                    foreach (DataColumn c in dtReport.Columns)
                                    {
                                        icol++;
                                        excel.Cells[1, icol] = c.ColumnName;
                                        excel.Cells[1, icol].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Tan);
                                    }

                                    int irow = 0;
                                    foreach (DataRow r in dtReport.Rows)
                                    {
                                        irow++;
                                        icol = 0;
                                        foreach (DataColumn c in dtReport.Columns)
                                        {
                                            icol++;
                                            excel.Cells[irow + 1, icol] = r[c.ColumnName];
                                        }
                                    }

                                    string strFilName = objFBD.SelectedPath + "\\" + strFileName + ".xls";

                                    if (File.Exists(strFilName))
                                    {
                                        File.Delete(strFilName);
                                    }

                                    object missing = System.Reflection.Missing.Value;
                                    workbook.SaveAs(strFilName, MSExcel.XlFileFormat.xlXMLSpreadsheet, missing, missing, missing, missing, MSExcel.XlSaveAsAccessMode.xlExclusive);
                                    excel.Visible = false;
                                    ((MSExcel._Application)excel).Quit();

                                    MessageBox.Show("Delivery report exported to " + strFilName + " Successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please generate report to export", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Output path is Mandatory", "Delivery Report", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvDeliveryMaster_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                {
                    int deliveryID = dgvDeliveryMaster.Rows[e.RowIndex].Cells[colDELIVERY_ID.Name].Value != null ? Convert.ToInt32(dgvDeliveryMaster.Rows[e.RowIndex].Cells[colDELIVERY_ID.Name].Value.ToString()) : 0;

                    DataTable deliveryTans = GetDeliveryTANsInfo(deliveryID);
                    BindTansInfoToGrid(deliveryTans);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
