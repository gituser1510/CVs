﻿namespace IndxReactNarr.Reports
{
    partial class frmDeliveryReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.sptContReport = new System.Windows.Forms.SplitContainer();
            this.dgvDeliveryMaster = new System.Windows.Forms.DataGridView();
            this.colDELIVERY_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDELIVERY_NAME = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colDELIVERY_DATE = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colTanCnt = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colReactCNT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvDeliveryTANs = new System.Windows.Forms.DataGridView();
            this.colDT_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDelId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTAN_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTanName = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colTanType = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colBatchNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnCount = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.pnlTBTM = new System.Windows.Forms.Panel();
            this.lbloutput = new System.Windows.Forms.Label();
            this.txtPath = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.btnExport = new System.Windows.Forms.Button();
            this.lblTANscnt = new System.Windows.Forms.Label();
            this.lblTanscntText = new System.Windows.Forms.Label();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewAutoFilterTextBoxColumn1 = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.dataGridViewAutoFilterTextBoxColumn2 = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.dataGridViewAutoFilterTextBoxColumn3 = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.dataGridViewAutoFilterTextBoxColumn4 = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewAutoFilterTextBoxColumn5 = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.dataGridViewAutoFilterTextBoxColumn6 = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewAutoFilterTextBoxColumn7 = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            ((System.ComponentModel.ISupportInitialize)(this.sptContReport)).BeginInit();
            this.sptContReport.Panel1.SuspendLayout();
            this.sptContReport.Panel2.SuspendLayout();
            this.sptContReport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeliveryMaster)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeliveryTANs)).BeginInit();
            this.pnlTBTM.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // sptContReport
            // 
            this.sptContReport.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.sptContReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sptContReport.Location = new System.Drawing.Point(0, 0);
            this.sptContReport.Name = "sptContReport";
            this.sptContReport.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // sptContReport.Panel1
            // 
            this.sptContReport.Panel1.Controls.Add(this.dgvDeliveryMaster);
            this.sptContReport.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // sptContReport.Panel2
            // 
            this.sptContReport.Panel2.Controls.Add(this.dgvDeliveryTANs);
            this.sptContReport.Panel2.Controls.Add(this.pnlTBTM);
            this.sptContReport.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.sptContReport.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.sptContReport.Size = new System.Drawing.Size(1205, 478);
            this.sptContReport.SplitterDistance = 257;
            this.sptContReport.SplitterWidth = 3;
            this.sptContReport.TabIndex = 0;
            // 
            // dgvDeliveryMaster
            // 
            this.dgvDeliveryMaster.AllowUserToAddRows = false;
            this.dgvDeliveryMaster.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LemonChiffon;
            this.dgvDeliveryMaster.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvDeliveryMaster.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvDeliveryMaster.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDeliveryMaster.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colDELIVERY_ID,
            this.colDELIVERY_NAME,
            this.colDELIVERY_DATE,
            this.colTanCnt,
            this.colReactCNT});
            this.dgvDeliveryMaster.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDeliveryMaster.Location = new System.Drawing.Point(0, 0);
            this.dgvDeliveryMaster.MultiSelect = false;
            this.dgvDeliveryMaster.Name = "dgvDeliveryMaster";
            this.dgvDeliveryMaster.ReadOnly = true;
            this.dgvDeliveryMaster.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dgvDeliveryMaster.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDeliveryMaster.Size = new System.Drawing.Size(1201, 253);
            this.dgvDeliveryMaster.TabIndex = 0;
            this.dgvDeliveryMaster.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDeliveryMaster_RowEnter);
            this.dgvDeliveryMaster.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvDeliveryMaster_RowPostPaint);
            // 
            // colDELIVERY_ID
            // 
            this.colDELIVERY_ID.DataPropertyName = "DELIVERY_ID";
            this.colDELIVERY_ID.HeaderText = "Delivery ID";
            this.colDELIVERY_ID.Name = "colDELIVERY_ID";
            this.colDELIVERY_ID.ReadOnly = true;
            this.colDELIVERY_ID.Visible = false;
            // 
            // colDELIVERY_NAME
            // 
            this.colDELIVERY_NAME.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colDELIVERY_NAME.DataPropertyName = "DELIVERY_NAME";
            this.colDELIVERY_NAME.HeaderText = "Delivery Name";
            this.colDELIVERY_NAME.Name = "colDELIVERY_NAME";
            this.colDELIVERY_NAME.ReadOnly = true;
            this.colDELIVERY_NAME.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colDELIVERY_DATE
            // 
            this.colDELIVERY_DATE.DataPropertyName = "DELIVERY_DATE";
            this.colDELIVERY_DATE.HeaderText = "Delivery Date";
            this.colDELIVERY_DATE.MinimumWidth = 10;
            this.colDELIVERY_DATE.Name = "colDELIVERY_DATE";
            this.colDELIVERY_DATE.ReadOnly = true;
            this.colDELIVERY_DATE.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colDELIVERY_DATE.Width = 200;
            // 
            // colTanCnt
            // 
            this.colTanCnt.DataPropertyName = "DELIVERED_TAN_CNT";
            this.colTanCnt.HeaderText = "TANs Count";
            this.colTanCnt.MinimumWidth = 10;
            this.colTanCnt.Name = "colTanCnt";
            this.colTanCnt.ReadOnly = true;
            this.colTanCnt.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colTanCnt.Width = 200;
            // 
            // colReactCNT
            // 
            this.colReactCNT.DataPropertyName = "DELIVERED_REACTION_CNT";
            this.colReactCNT.HeaderText = "Rxns Count";
            this.colReactCNT.MinimumWidth = 10;
            this.colReactCNT.Name = "colReactCNT";
            this.colReactCNT.ReadOnly = true;
            this.colReactCNT.Width = 200;
            // 
            // dgvDeliveryTANs
            // 
            this.dgvDeliveryTANs.AllowUserToAddRows = false;
            this.dgvDeliveryTANs.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LemonChiffon;
            this.dgvDeliveryTANs.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvDeliveryTANs.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvDeliveryTANs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDeliveryTANs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colDT_ID,
            this.colDelId,
            this.colTAN_ID,
            this.colTanName,
            this.colTanType,
            this.colBatchNo,
            this.colRxnCount});
            this.dgvDeliveryTANs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDeliveryTANs.Location = new System.Drawing.Point(0, 0);
            this.dgvDeliveryTANs.Name = "dgvDeliveryTANs";
            this.dgvDeliveryTANs.ReadOnly = true;
            this.dgvDeliveryTANs.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dgvDeliveryTANs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDeliveryTANs.Size = new System.Drawing.Size(1201, 185);
            this.dgvDeliveryTANs.TabIndex = 1;
            this.dgvDeliveryTANs.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvTansRep_RowPostPaint);
            // 
            // colDT_ID
            // 
            this.colDT_ID.DataPropertyName = "DT_ID";
            this.colDT_ID.HeaderText = "DT_ID";
            this.colDT_ID.Name = "colDT_ID";
            this.colDT_ID.ReadOnly = true;
            this.colDT_ID.Visible = false;
            // 
            // colDelId
            // 
            this.colDelId.DataPropertyName = "DELIVERY_ID";
            this.colDelId.HeaderText = "DELIVERY ID\t";
            this.colDelId.Name = "colDelId";
            this.colDelId.ReadOnly = true;
            this.colDelId.Visible = false;
            // 
            // colTAN_ID
            // 
            this.colTAN_ID.DataPropertyName = "TAN_ID\t";
            this.colTAN_ID.HeaderText = "TAN ID";
            this.colTAN_ID.Name = "colTAN_ID";
            this.colTAN_ID.ReadOnly = true;
            this.colTAN_ID.Visible = false;
            // 
            // colTanName
            // 
            this.colTanName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colTanName.DataPropertyName = "TAN_NAME";
            this.colTanName.HeaderText = "Tan Name";
            this.colTanName.Name = "colTanName";
            this.colTanName.ReadOnly = true;
            this.colTanName.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colTanType
            // 
            this.colTanType.DataPropertyName = "TAN_TYPE";
            this.colTanType.HeaderText = "TanType";
            this.colTanType.Name = "colTanType";
            this.colTanType.ReadOnly = true;
            this.colTanType.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colTanType.Width = 150;
            // 
            // colBatchNo
            // 
            this.colBatchNo.DataPropertyName = "BATCH_NO";
            this.colBatchNo.HeaderText = "BatchNo";
            this.colBatchNo.Name = "colBatchNo";
            this.colBatchNo.ReadOnly = true;
            this.colBatchNo.Width = 150;
            // 
            // colRxnCount
            // 
            this.colRxnCount.HeaderText = "RxnCount";
            this.colRxnCount.Name = "colRxnCount";
            this.colRxnCount.ReadOnly = true;
            this.colRxnCount.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colRxnCount.Width = 150;
            // 
            // pnlTBTM
            // 
            this.pnlTBTM.BackColor = System.Drawing.Color.White;
            this.pnlTBTM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTBTM.Controls.Add(this.lbloutput);
            this.pnlTBTM.Controls.Add(this.txtPath);
            this.pnlTBTM.Controls.Add(this.btnBrowse);
            this.pnlTBTM.Controls.Add(this.btnExport);
            this.pnlTBTM.Controls.Add(this.lblTANscnt);
            this.pnlTBTM.Controls.Add(this.lblTanscntText);
            this.pnlTBTM.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlTBTM.Location = new System.Drawing.Point(0, 185);
            this.pnlTBTM.Name = "pnlTBTM";
            this.pnlTBTM.Size = new System.Drawing.Size(1201, 29);
            this.pnlTBTM.TabIndex = 2;
            // 
            // lbloutput
            // 
            this.lbloutput.AutoSize = true;
            this.lbloutput.Location = new System.Drawing.Point(618, 5);
            this.lbloutput.Name = "lbloutput";
            this.lbloutput.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbloutput.Size = new System.Drawing.Size(55, 17);
            this.lbloutput.TabIndex = 7;
            this.lbloutput.Text = "Output :";
            // 
            // txtPath
            // 
            this.txtPath.Location = new System.Drawing.Point(677, 1);
            this.txtPath.Name = "txtPath";
            this.txtPath.ReadOnly = true;
            this.txtPath.Size = new System.Drawing.Size(305, 25);
            this.txtPath.TabIndex = 6;
            // 
            // btnBrowse
            // 
            this.btnBrowse.BackColor = System.Drawing.Color.White;
            this.btnBrowse.Image = global::IndxReactNarr.Properties.Resources.elipsis;
            this.btnBrowse.Location = new System.Drawing.Point(987, 1);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(32, 25);
            this.btnBrowse.TabIndex = 5;
            this.btnBrowse.UseVisualStyleBackColor = false;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // btnExport
            // 
            this.btnExport.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnExport.Location = new System.Drawing.Point(1082, 0);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(117, 27);
            this.btnExport.TabIndex = 4;
            this.btnExport.Text = "Export To Excel";
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // lblTANscnt
            // 
            this.lblTANscnt.AutoSize = true;
            this.lblTANscnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTANscnt.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTANscnt.Location = new System.Drawing.Point(89, 4);
            this.lblTANscnt.Name = "lblTANscnt";
            this.lblTANscnt.Size = new System.Drawing.Size(16, 17);
            this.lblTANscnt.TabIndex = 3;
            this.lblTANscnt.Text = "0";
            // 
            // lblTanscntText
            // 
            this.lblTanscntText.AutoSize = true;
            this.lblTanscntText.Location = new System.Drawing.Point(4, 4);
            this.lblTanscntText.Name = "lblTanscntText";
            this.lblTanscntText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblTanscntText.Size = new System.Drawing.Size(90, 17);
            this.lblTanscntText.TabIndex = 2;
            this.lblTanscntText.Text = "TANs Count :";
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.sptContReport);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1205, 478);
            this.pnlMain.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "DELIVERY_ID";
            this.dataGridViewTextBoxColumn1.HeaderText = "Delivery ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Visible = false;
            // 
            // dataGridViewAutoFilterTextBoxColumn1
            // 
            this.dataGridViewAutoFilterTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewAutoFilterTextBoxColumn1.DataPropertyName = "APPLICATION_NAME";
            this.dataGridViewAutoFilterTextBoxColumn1.HeaderText = "Application Name";
            this.dataGridViewAutoFilterTextBoxColumn1.Name = "dataGridViewAutoFilterTextBoxColumn1";
            this.dataGridViewAutoFilterTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewAutoFilterTextBoxColumn2
            // 
            this.dataGridViewAutoFilterTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewAutoFilterTextBoxColumn2.DataPropertyName = "DELIVERY_NAME\t";
            this.dataGridViewAutoFilterTextBoxColumn2.HeaderText = "Delivery Name";
            this.dataGridViewAutoFilterTextBoxColumn2.Name = "dataGridViewAutoFilterTextBoxColumn2";
            this.dataGridViewAutoFilterTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewAutoFilterTextBoxColumn3
            // 
            this.dataGridViewAutoFilterTextBoxColumn3.DataPropertyName = "DELIVERY_DATE";
            this.dataGridViewAutoFilterTextBoxColumn3.HeaderText = "Delivery Date";
            this.dataGridViewAutoFilterTextBoxColumn3.MinimumWidth = 10;
            this.dataGridViewAutoFilterTextBoxColumn3.Name = "dataGridViewAutoFilterTextBoxColumn3";
            this.dataGridViewAutoFilterTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewAutoFilterTextBoxColumn3.Width = 200;
            // 
            // dataGridViewAutoFilterTextBoxColumn4
            // 
            this.dataGridViewAutoFilterTextBoxColumn4.DataPropertyName = "DELIVERED_TAN_CNT";
            this.dataGridViewAutoFilterTextBoxColumn4.HeaderText = "Delivered Tan Count";
            this.dataGridViewAutoFilterTextBoxColumn4.MinimumWidth = 10;
            this.dataGridViewAutoFilterTextBoxColumn4.Name = "dataGridViewAutoFilterTextBoxColumn4";
            this.dataGridViewAutoFilterTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewAutoFilterTextBoxColumn4.Width = 200;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "DELIVERED_REACTION_CNT";
            this.dataGridViewTextBoxColumn2.HeaderText = "Delivered Rxn Count";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 200;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "DT_ID";
            this.dataGridViewTextBoxColumn3.HeaderText = "DT_ID";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Visible = false;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "DELIVERY_ID";
            this.dataGridViewTextBoxColumn4.HeaderText = "DELIVERY ID\t";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Visible = false;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "TAN_ID\t";
            this.dataGridViewTextBoxColumn5.HeaderText = "TAN ID";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Visible = false;
            // 
            // dataGridViewAutoFilterTextBoxColumn5
            // 
            this.dataGridViewAutoFilterTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewAutoFilterTextBoxColumn5.DataPropertyName = "TAN_NAME";
            this.dataGridViewAutoFilterTextBoxColumn5.HeaderText = "Tan Name";
            this.dataGridViewAutoFilterTextBoxColumn5.Name = "dataGridViewAutoFilterTextBoxColumn5";
            this.dataGridViewAutoFilterTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewAutoFilterTextBoxColumn6
            // 
            this.dataGridViewAutoFilterTextBoxColumn6.DataPropertyName = "TAN_TYPE";
            this.dataGridViewAutoFilterTextBoxColumn6.HeaderText = "TanType";
            this.dataGridViewAutoFilterTextBoxColumn6.Name = "dataGridViewAutoFilterTextBoxColumn6";
            this.dataGridViewAutoFilterTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewAutoFilterTextBoxColumn6.Width = 150;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "BATCH_NO";
            this.dataGridViewTextBoxColumn6.HeaderText = "BatchNo";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 150;
            // 
            // dataGridViewAutoFilterTextBoxColumn7
            // 
            this.dataGridViewAutoFilterTextBoxColumn7.DataPropertyName = "IS_DELIVERED";
            this.dataGridViewAutoFilterTextBoxColumn7.HeaderText = "Is Delivered";
            this.dataGridViewAutoFilterTextBoxColumn7.Name = "dataGridViewAutoFilterTextBoxColumn7";
            this.dataGridViewAutoFilterTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewAutoFilterTextBoxColumn7.Width = 150;
            // 
            // frmDeliveryReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1205, 478);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmDeliveryReport";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Delivery Report";
            this.Load += new System.EventHandler(this.frmDeliveryReport_Load);
            this.sptContReport.Panel1.ResumeLayout(false);
            this.sptContReport.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sptContReport)).EndInit();
            this.sptContReport.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeliveryMaster)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeliveryTANs)).EndInit();
            this.pnlTBTM.ResumeLayout(false);
            this.pnlTBTM.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer sptContReport;
        private System.Windows.Forms.Panel pnlTBTM;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.Label lblTANscnt;
        private System.Windows.Forms.Label lblTanscntText;
        private System.Windows.Forms.Label lbloutput;
        private System.Windows.Forms.TextBox txtPath;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.DataGridView dgvDeliveryMaster;
        private System.Windows.Forms.DataGridView dgvDeliveryTANs;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn dataGridViewAutoFilterTextBoxColumn1;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn dataGridViewAutoFilterTextBoxColumn2;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn dataGridViewAutoFilterTextBoxColumn3;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn dataGridViewAutoFilterTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn dataGridViewAutoFilterTextBoxColumn5;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn dataGridViewAutoFilterTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn dataGridViewAutoFilterTextBoxColumn7;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDT_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDelId;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTAN_ID;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colTanName;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colTanType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBatchNo;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colRxnCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDELIVERY_ID;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colDELIVERY_NAME;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colDELIVERY_DATE;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colTanCnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn colReactCNT;
    }
}