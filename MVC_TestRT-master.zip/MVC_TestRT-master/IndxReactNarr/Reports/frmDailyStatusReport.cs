﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using IndxReactNarrDAL;
using IndxReactNarr.Common;

namespace IndxReactNarr.Reports
{
    public partial class frmDailyStatusReport : Form
    {
        public frmDailyStatusReport()
        {
            InitializeComponent();
        }

        public DataTable ModuleUsers { get; set; }

        private void frmDailyStatusReport_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;               
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (datePicker.Text != null)
                {
                    //if (GlobalVariables.ApplicationName == Enums.ApplicationName.NARRATIVES.ToString() ||
                    //    GlobalVariables.ApplicationName == Enums.ApplicationName.EXPPROCEDURES.ToString())
                    //{
                    using (DataTable dtDStatus = NarrativesDB.GetDailyStatusReport(GlobalVariables.ApplicationName, GlobalVariables.ModuleName, datePicker.Value.Date, datePicker.Value.Date))
                    {
                        BindDailyStatusDataToGrid(dtDStatus);
                    }
                    //}
                    //else
                    //{

                    //    using (DataTable dtDStatus = ReactDB.GetDailyStatusReport(GlobalVariables.ApplicationName, datePicker.Value.Date))
                    //    {
                    //        BindDailyStatusDataToGrid(dtDStatus);
                    //    }
                    //}
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindDailyStatusDataToGrid(DataTable dailystatusdata)
        {
            try
            {
                if (dailystatusdata != null)
                {                    
                    dgvReport.AutoGenerateColumns = false;
                    colUserName.DataPropertyName = "USER_NAME";
                    colRoleName.DataPropertyName = "ROLE_NAME";
                    colTANCount.DataPropertyName = "TASK_COMPLETED_CNT";
                    colCompletedRxnsCount.DataPropertyName = "RXN_COMPLETED_CNT";

                    if (GlobalVariables.RoleName.ToUpper() == RolesMaster.PM.ToUpper() ||
                        GlobalVariables.RoleName.ToUpper() == RolesMaster.TOOL_MANAGER.ToUpper() ||
                        GlobalVariables.RoleName.ToUpper() == RolesMaster.ADMIN.ToUpper())
                    {
                        dgvReport.DataSource = dailystatusdata;
                        
                        //No.of Reactions - Curation completed
                        object objRxnCnt = dailystatusdata.Compute("sum([RXN_COMPLETED_CNT])", "[RXN_COMPLETED_CNT] is not null and ROLE_NAME = 'Analyst'");
                        if (objRxnCnt != null)
                        {
                            lblRxnsCount_Curation.Text = objRxnCnt.ToString();
                        }

                        //No.of Reactions - Review completed
                        object objRevRxnCnt = dailystatusdata.Compute("sum([RXN_COMPLETED_CNT])", "[RXN_COMPLETED_CNT] is not null and ROLE_NAME = 'Review Analyst'");
                        if (objRevRxnCnt != null)
                        {
                            lblRxnsCount_Review.Text = objRevRxnCnt.ToString();
                        }

                        //No.of Reactions - QC completed
                        object objQcRxnCnt = dailystatusdata.Compute("sum([RXN_COMPLETED_CNT])", "[RXN_COMPLETED_CNT] is not null and ROLE_NAME = 'QC Analyst'");
                        if (objQcRxnCnt != null)
                        {
                            lblRxnsCount_QC.Text = objQcRxnCnt.ToString();
                        }

                        object objTANCnt = dailystatusdata.Compute("sum([TASK_COMPLETED_CNT])", "[TASK_COMPLETED_CNT] is not null");
                        if (objRxnCnt != null)
                        {
                            lblTANsCount.Text = objTANCnt.ToString();
                        }
                    }
                    else if (GlobalVariables.RoleName.ToUpper() == RolesMaster.QC_ANALYST.ToUpper())//- 23rd May 2013
                    {
                        DataView dvTemp = dailystatusdata.Copy().DefaultView;
                        dvTemp.RowFilter = GetRowFilterConditionOnQC(GlobalVariables.UserName.ToUpper());
                        DataTable dtUserReport = dvTemp.ToTable();
                        dgvReport.DataSource = dtUserReport;
                    }
                    else
                    {
                        DataView dvTemp = dailystatusdata.Copy().DefaultView;
                        dvTemp.RowFilter = "USER_NAME = '" + GlobalVariables.UserName.ToUpper() + "'";
                        DataTable dtUserReport = dvTemp.ToTable();
                        dgvReport.DataSource = dtUserReport;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetRowFilterConditionOnQC(string qcName)
        {
            string filterCond = "";
            try
            {
                if (!string.IsNullOrEmpty(qcName))
                {
                    //Get Module Users
                    ModuleUsers = ReactDB.GetUsersByApplicationModule(GlobalVariables.ApplicationName, GlobalVariables.ModuleName);

                    string usersList = "";
                    if (ModuleUsers != null)
                    {
                        if (ModuleUsers.Rows.Count > 0)
                        {
                            using (DataView dvTemp = ModuleUsers.DefaultView)
                            {
                                dvTemp.RowFilter = "QUAL_ANLST_NAME = '" + qcName + "'";

                                DataTable dtUsers = dvTemp.ToTable();

                                if (dtUsers != null)
                                {
                                    foreach (DataRow dRow in dtUsers.Rows)
                                    {
                                        if (string.IsNullOrEmpty(usersList.Trim()))
                                        {
                                            usersList = "'" + dRow["REV_ANLST_NAME"].ToString().Trim() + "'" + ", '" + dRow["ANLST_NAME"].ToString().Trim() + "'";
                                        }
                                        else
                                        {
                                            usersList = usersList.Trim() + ",'" + dRow["REV_ANLST_NAME"].ToString().Trim() + "'" + ", '" + dRow["ANLST_NAME"].ToString().Trim() + "'";
                                        }
                                    }
                                }
                            }
                        }
                    }
                  
                    if (!string.IsNullOrEmpty(usersList))
                    {
                        filterCond = "USER_NAME in (" + usersList + ")";
                    }
                    else
                    {
                        filterCond = "USER_NAME is null";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return filterCond;
        }
        
        private void dgvReport_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();
                while (strRowNumber.Length < dgvReport.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvReport.Font);

                if (dgvReport.RowHeadersWidth < (int)(size.Width + 20)) dgvReport.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void splitter1_SplitterMoved(object sender, SplitterEventArgs e)
        {

        }
    }
}
