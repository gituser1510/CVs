﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using IndxReactNarrDAL;

namespace IndxReactNarr.Reports
{
    public partial class frmShipmentsOverAllStatusReport : Form
    {
        public frmShipmentsOverAllStatusReport()
        {
            InitializeComponent();
        }

        private void frmShipmentsOverAllStatusReport_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;

                //Get Report
                DataTable dtShipmentsStatus = NarrativesDB.GetShipmentsOverAllStatusReport(GlobalVariables.ApplicationName);
                BindReportDataToGrid(dtShipmentsStatus);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindReportDataToGrid(DataTable reportData)
        {
            try
            {
                dgvShipmentsStatus.AutoGenerateColumns = false;
                dgvShipmentsStatus.DataSource = reportData;

                colShipmentName.DataPropertyName = "SHIPMENT_NAME";
                colTotalTANs.DataPropertyName = "TAN_CNT";
                
                colCurationAssignedTANs.DataPropertyName = "CURATION_ASSIGNED_CNT";
                colNotAssignedTANs.DataPropertyName = "NOT_ASSIGNED_CNT";
                colCurationProgressTANs.DataPropertyName = "CURATION_PROGRESS_CNT";
               
                colReviewAssignedTANs.DataPropertyName = "REVIEW_ASSIGNED_CNT";
                colReviewProgressTANs.DataPropertyName = "REVIEW_PROGRESS_CNT";

                colQCAssignedTANs.DataPropertyName = "QC_ASSIGNED_CNT";
                colQCProgressTANs.DataPropertyName = "QC_PROGRESS_CNT";
                colQCCompletedTANs.DataPropertyName = "QC_COMPLETED";

                colTotalRxnsCnt.DataPropertyName = "REACTION_CNT";
                colCuratedRxnsCnt.DataPropertyName = "CURATED_REACTION_CNT";
                colReviewedRxnCnt.DataPropertyName = "REVIEWED_REATION_CNT";
                colQCRxnsCnt.DataPropertyName = "QB_REACTION_CNT";
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvShipmentsStatus_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvShipmentsStatus.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvShipmentsStatus.Font);

                if (dgvShipmentsStatus.RowHeadersWidth < (int)(size.Width + 20)) dgvShipmentsStatus.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
