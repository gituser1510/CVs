﻿namespace IndxReactNarr.Reports
{
    partial class frmUserTaskReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvReport = new System.Windows.Forms.DataGridView();
            this.colBatch = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colBatchNo = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colTAN = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colCurator = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colReviewer = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colQC = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colTANStatus = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colRxnCnt = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colStageCnt = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colDocClass = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.colTanPriority = new DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.lblTANCnt = new System.Windows.Forms.Label();
            this.lblTANs = new System.Windows.Forms.Label();
            this.lblStages_Val = new System.Windows.Forms.Label();
            this.lblStages = new System.Windows.Forms.Label();
            this.lblRxns_Val = new System.Windows.Forms.Label();
            this.lblRxns = new System.Windows.Forms.Label();
            this.lblClearFilter = new System.Windows.Forms.Label();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.btnGetReport = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.chklstBatchName = new System.Windows.Forms.CheckedListBox();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReport)).BeginInit();
            this.pnlBottom.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.dgvReport);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1211, 511);
            this.pnlMain.TabIndex = 0;
            // 
            // dgvReport
            // 
            this.dgvReport.AllowUserToAddRows = false;
            this.dgvReport.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvReport.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReport.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colBatch,
            this.colBatchNo,
            this.colTAN,
            this.colCurator,
            this.colReviewer,
            this.colQC,
            this.colTANStatus,
            this.colRxnCnt,
            this.colStageCnt,
            this.colDocClass,
            this.colTanPriority});
            this.dgvReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvReport.Location = new System.Drawing.Point(0, 92);
            this.dgvReport.Name = "dgvReport";
            this.dgvReport.ReadOnly = true;
            this.dgvReport.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            this.dgvReport.Size = new System.Drawing.Size(1211, 392);
            this.dgvReport.TabIndex = 1;
            this.dgvReport.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvReport_RowPostPaint);
            this.dgvReport.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgvReport_DataBindingComplete);
            // 
            // colBatch
            // 
            this.colBatch.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colBatch.HeaderText = "BatchName";
            this.colBatch.Name = "colBatch";
            this.colBatch.ReadOnly = true;
            // 
            // colBatchNo
            // 
            this.colBatchNo.HeaderText = "B.No";
            this.colBatchNo.Name = "colBatchNo";
            this.colBatchNo.ReadOnly = true;
            this.colBatchNo.Width = 60;
            // 
            // colTAN
            // 
            this.colTAN.HeaderText = "TAN";
            this.colTAN.Name = "colTAN";
            this.colTAN.ReadOnly = true;
            // 
            // colCurator
            // 
            this.colCurator.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colCurator.HeaderText = "Curator";
            this.colCurator.Name = "colCurator";
            this.colCurator.ReadOnly = true;
            // 
            // colReviewer
            // 
            this.colReviewer.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colReviewer.HeaderText = "Reviewer";
            this.colReviewer.Name = "colReviewer";
            this.colReviewer.ReadOnly = true;
            // 
            // colQC
            // 
            this.colQC.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colQC.HeaderText = "QualityCheck";
            this.colQC.Name = "colQC";
            this.colQC.ReadOnly = true;
            // 
            // colTANStatus
            // 
            this.colTANStatus.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colTANStatus.HeaderText = "TANStatus";
            this.colTANStatus.Name = "colTANStatus";
            this.colTANStatus.ReadOnly = true;
            // 
            // colRxnCnt
            // 
            this.colRxnCnt.HeaderText = "Reactions";
            this.colRxnCnt.Name = "colRxnCnt";
            this.colRxnCnt.ReadOnly = true;
            this.colRxnCnt.Width = 80;
            // 
            // colStageCnt
            // 
            this.colStageCnt.HeaderText = "ExtraStages";
            this.colStageCnt.Name = "colStageCnt";
            this.colStageCnt.ReadOnly = true;
            this.colStageCnt.Width = 80;
            // 
            // colDocClass
            // 
            this.colDocClass.HeaderText = "Doc_Class";
            this.colDocClass.Name = "colDocClass";
            this.colDocClass.ReadOnly = true;
            this.colDocClass.Width = 60;
            // 
            // colTanPriority
            // 
            this.colTanPriority.HeaderText = "Priority";
            this.colTanPriority.Name = "colTanPriority";
            this.colTanPriority.ReadOnly = true;
            this.colTanPriority.Width = 50;
            // 
            // pnlBottom
            // 
            this.pnlBottom.BackColor = System.Drawing.Color.White;
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlBottom.Controls.Add(this.lblTANCnt);
            this.pnlBottom.Controls.Add(this.lblTANs);
            this.pnlBottom.Controls.Add(this.lblStages_Val);
            this.pnlBottom.Controls.Add(this.lblStages);
            this.pnlBottom.Controls.Add(this.lblRxns_Val);
            this.pnlBottom.Controls.Add(this.lblRxns);
            this.pnlBottom.Controls.Add(this.lblClearFilter);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 484);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(1211, 27);
            this.pnlBottom.TabIndex = 3;
            // 
            // lblTANCnt
            // 
            this.lblTANCnt.AutoSize = true;
            this.lblTANCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTANCnt.ForeColor = System.Drawing.Color.Red;
            this.lblTANCnt.Location = new System.Drawing.Point(89, 3);
            this.lblTANCnt.Name = "lblTANCnt";
            this.lblTANCnt.Size = new System.Drawing.Size(16, 17);
            this.lblTANCnt.TabIndex = 14;
            this.lblTANCnt.Text = "0";
            // 
            // lblTANs
            // 
            this.lblTANs.AutoSize = true;
            this.lblTANs.ForeColor = System.Drawing.Color.Blue;
            this.lblTANs.Location = new System.Drawing.Point(1, 4);
            this.lblTANs.Name = "lblTANs";
            this.lblTANs.Size = new System.Drawing.Size(90, 17);
            this.lblTANs.TabIndex = 13;
            this.lblTANs.Text = "No.of TANs: ";
            // 
            // lblStages_Val
            // 
            this.lblStages_Val.AutoSize = true;
            this.lblStages_Val.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStages_Val.ForeColor = System.Drawing.Color.Red;
            this.lblStages_Val.Location = new System.Drawing.Point(455, 3);
            this.lblStages_Val.Name = "lblStages_Val";
            this.lblStages_Val.Size = new System.Drawing.Size(16, 17);
            this.lblStages_Val.TabIndex = 12;
            this.lblStages_Val.Text = "0";
            // 
            // lblStages
            // 
            this.lblStages.AutoSize = true;
            this.lblStages.ForeColor = System.Drawing.Color.Blue;
            this.lblStages.Location = new System.Drawing.Point(327, 4);
            this.lblStages.Name = "lblStages";
            this.lblStages.Size = new System.Drawing.Size(124, 17);
            this.lblStages.TabIndex = 11;
            this.lblStages.Text = "No.of Extra Stages:";
            // 
            // lblRxns_Val
            // 
            this.lblRxns_Val.AutoSize = true;
            this.lblRxns_Val.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxns_Val.ForeColor = System.Drawing.Color.Red;
            this.lblRxns_Val.Location = new System.Drawing.Point(264, 3);
            this.lblRxns_Val.Name = "lblRxns_Val";
            this.lblRxns_Val.Size = new System.Drawing.Size(16, 17);
            this.lblRxns_Val.TabIndex = 10;
            this.lblRxns_Val.Text = "0";
            // 
            // lblRxns
            // 
            this.lblRxns.AutoSize = true;
            this.lblRxns.ForeColor = System.Drawing.Color.Blue;
            this.lblRxns.Location = new System.Drawing.Point(152, 4);
            this.lblRxns.Name = "lblRxns";
            this.lblRxns.Size = new System.Drawing.Size(107, 17);
            this.lblRxns.TabIndex = 9;
            this.lblRxns.Text = "No.of Reactions:";
            // 
            // lblClearFilter
            // 
            this.lblClearFilter.AutoSize = true;
            this.lblClearFilter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblClearFilter.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClearFilter.ForeColor = System.Drawing.Color.Blue;
            this.lblClearFilter.Location = new System.Drawing.Point(556, 4);
            this.lblClearFilter.Name = "lblClearFilter";
            this.lblClearFilter.Size = new System.Drawing.Size(74, 17);
            this.lblClearFilter.TabIndex = 3;
            this.lblClearFilter.Text = "Clear Filter";
            this.lblClearFilter.Click += new System.EventHandler(this.lblClearFilter_Click);
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.White;
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlTop.Controls.Add(this.btnGetReport);
            this.pnlTop.Controls.Add(this.label1);
            this.pnlTop.Controls.Add(this.chklstBatchName);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1211, 92);
            this.pnlTop.TabIndex = 0;
            // 
            // btnGetReport
            // 
            this.btnGetReport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGetReport.Location = new System.Drawing.Point(1108, 3);
            this.btnGetReport.Name = "btnGetReport";
            this.btnGetReport.Size = new System.Drawing.Size(96, 29);
            this.btnGetReport.TabIndex = 8;
            this.btnGetReport.Text = "Get Report";
            this.btnGetReport.UseVisualStyleBackColor = true;
            this.btnGetReport.Click += new System.EventHandler(this.btnGetReport_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "Batch";
            // 
            // chklstBatchName
            // 
            this.chklstBatchName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.chklstBatchName.CheckOnClick = true;
            this.chklstBatchName.ColumnWidth = 150;
            this.chklstBatchName.FormattingEnabled = true;
            this.chklstBatchName.Location = new System.Drawing.Point(83, 2);
            this.chklstBatchName.MultiColumn = true;
            this.chklstBatchName.Name = "chklstBatchName";
            this.chklstBatchName.Size = new System.Drawing.Size(1019, 84);
            this.chklstBatchName.TabIndex = 6;
            // 
            // frmUserTaskReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1211, 511);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmUserTaskReport";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Batch-TANs Status Report";
            this.Load += new System.EventHandler(this.frmUserTaskReport_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvReport)).EndInit();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.DataGridView dgvReport;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckedListBox chklstBatchName;
        private System.Windows.Forms.Button btnGetReport;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Label lblTANCnt;
        private System.Windows.Forms.Label lblTANs;
        private System.Windows.Forms.Label lblStages_Val;
        private System.Windows.Forms.Label lblStages;
        private System.Windows.Forms.Label lblRxns_Val;
        private System.Windows.Forms.Label lblRxns;
        private System.Windows.Forms.Label lblClearFilter;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colBatch;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colBatchNo;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colTAN;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colCurator;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colReviewer;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colQC;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colTANStatus;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colRxnCnt;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colStageCnt;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colDocClass;
        private DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn colTanPriority;
    }
}