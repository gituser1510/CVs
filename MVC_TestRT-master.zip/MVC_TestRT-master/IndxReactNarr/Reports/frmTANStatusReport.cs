﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarrDAL;
using IndxReactNarr.Generic;

namespace IndxReactNarr.Reports
{
    public partial class frmTANStatusReport : Form
    {
        public frmTANStatusReport()
        {
            InitializeComponent();
        }

        public DataTable BatchTANs
        {
            get;
            set;
        }

        private void btnGetList_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;

                if (!string.IsNullOrEmpty(txtShipmentName.Text.Trim()))
                {                    
                    int intBNo = 0;
                    int.TryParse(txtBNo.Text.Trim(), out intBNo);

                    DataTable dtBatchTANS = ShipmentMasterDB.GetTANsForExportOnApp_Shipment(GlobalVariables.ApplicationName, txtShipmentName.Text.Trim(), intBNo);
                    if (dtBatchTANS != null)
                    {
                        BatchTANs = dtBatchTANS;

                        txtTANSrch.Text = "";
                        BindTANsToGrid(dtBatchTANS);
                    }
                }

                Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public void BindTANsToGrid(DataTable batchTans)
        {
            try
            {
                if (batchTans != null)
                {
                    //Hide Application based columns
                    //colIndexing.Visible = false;
                    colDocClass.Visible = false;
                    colTANPriority.Visible = false;
                    colRxnCount.Visible = false;
                    colIndexing.Visible = false;


                    lblTANCount.Text = batchTans.Rows.Count.ToString();

                    dgvTans.AutoGenerateColumns = false;
                    dgvTans.DataSource = batchTans;

                    colTAN_ID.DataPropertyName = "TAN_ID";
                    colTAN_Name.DataPropertyName = "TAN_NAME";

                    colIndexing.DataPropertyName = "TAN_NAME";
                    colReact.DataPropertyName = "TAN_NAME";

                    colBatchNo.DataPropertyName = "BATCH_NO";
                    colRxnCount.DataPropertyName = "REACTION_CNT";
                    colTANPriority.DataPropertyName = "TAN_PRIORITY";
                    colTAN_Type.DataPropertyName = "TAN_TYPE";
                    colTaskStatus.DataPropertyName = "TASK_STATUS";

                    if (GlobalVariables.ApplicationName == Enums.ApplicationName.ORGANIC.ToString()
                        || GlobalVariables.ApplicationName == Enums.ApplicationName.MACRO.ToString())
                    {
                        colIndexing.Visible = true;
                        colReact.Visible = true;
                        colRxnCount.Visible = true;
                    }
                    else if (GlobalVariables.ApplicationName == Enums.ApplicationName.REACT.ToString())
                    {
                        colReact.Visible = true;
                        colDocClass.Visible = true;
                        colTANPriority.Visible = true;
                        colRxnCount.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void dgvTans_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvTans.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvTans.Font);

                if (dgvTans.RowHeadersWidth < (int)(size.Width + 20)) dgvTans.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;

                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtTANSrch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (BatchTANs != null)
                {
                    if (!string.IsNullOrEmpty(txtTANSrch.Text.Trim()))
                    {
                        string strFCond = GetFilterCondition(txtTANSrch.Text.Trim());

                        DataTable dtAllTANs = BatchTANs.Copy();
                        DataView dvTemp = dtAllTANs.DefaultView;
                        dvTemp.RowFilter = strFCond;
                        DataTable dtTANs = dvTemp.ToTable();
                        BindTANsToGrid(dtTANs);
                    }
                    else
                    {
                        DataTable dtAllTANs = BatchTANs.Copy();
                        BindTANsToGrid(dtAllTANs);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetFilterCondition(string _query_tan)
        {
            string strFCond = "";
            try
            {
                if (_query_tan.Trim().Contains(";"))
                {
                    string[] splitter = { ";" };
                    string[] strArrTans = _query_tan.Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);

                    if (strArrTans != null)
                    {
                        if (strArrTans.Length > 0)
                        {
                            for (int i = 0; i < strArrTans.Length; i++)
                            {
                                if (i == 0)
                                {
                                    strFCond = "TAN_NAME Like '" + strArrTans[i] + "%' ";
                                }
                                else
                                {
                                    strFCond += " OR" + " TAN_NAME Like '" + strArrTans[i] + "%'";
                                }
                            }
                        }
                    }
                }
                else
                {
                    strFCond = "TAN_NAME Like '" + _query_tan.Trim() + "%'";
                }
                return strFCond;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strFCond;
        }
               
        private void GetShipmentNamesAndSetToUserNameTxtBox_AutoComplete()
        {
            try
            {
                DataTable dtTanTypes = null;
                DataTable dtShipments = null;
                using (dtShipments = ReactDB.GetShipmentDetailsByAppName(GlobalVariables.ApplicationName, out dtTanTypes))
                {
                    if (dtShipments != null)
                    {
                        if (dtShipments.Rows.Count > 0)
                        {
                            AutoCompleteStringCollection shipmentColl = new AutoCompleteStringCollection();

                            for (int i = 0; i < dtShipments.Rows.Count; i++)
                            {
                                if (dtShipments.Rows[i][0] != null)
                                {
                                    shipmentColl.Add(dtShipments.Rows[i]["SHIPMENT_NAME"].ToString());
                                }
                            }

                            txtShipmentName.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                            txtShipmentName.AutoCompleteSource = AutoCompleteSource.CustomSource;
                            txtShipmentName.AutoCompleteCustomSource = shipmentColl;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void frmTANStatusReport_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;
                txtShipmentName.Focus();

                //Get Shipment Names and Set Autofill
                GetShipmentNamesAndSetToUserNameTxtBox_AutoComplete();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
