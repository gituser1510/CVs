﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using IndxReactNarrDAL;
using DataGridViewAutoFilter;

namespace IndxReactNarr.Reports
{
    public partial class frmUserTaskReport : Form
    {
        public frmUserTaskReport()
        {
            InitializeComponent();
        }

        private void btnGetReport_Click(object sender, EventArgs e)
        {
            try
            {
                if (chklstBatchName.CheckedItems.Count > 0)
                {
                    Cursor = Cursors.WaitCursor;

                    string[] saBatches = GetSelectedBatchNames();
                    DataTable dtReport = null;// IndxReactNarrDAL.ReactDB.GetTANStatusReport(saBatches);
                    if (dtReport != null)
                    {                        
                        BindDataToGrid(dtReport);
                    }

                    Cursor = Cursors.Default;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
                Cursor = Cursors.Default;
            }
        }

        private string[] GetSelectedBatchNames()
        {
            string[] saBatches = null;
            try
            {
                if (chklstBatchName.CheckedItems.Count > 0)
                {
                    saBatches = new string[chklstBatchName.CheckedItems.Count];
                    DataRowView drView = null;
                    for (int i = 0; i < chklstBatchName.CheckedItems.Count; i++)
                    {
                        drView = chklstBatchName.CheckedItems[i] as DataRowView;
                        saBatches[i] = (string)drView["Batch_Name"];
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return saBatches;
        }

        private void BindReportDataToGrid(DataTable reportdata)
        {
            try
            {
                if (reportdata != null)
                {
                    dgvReport.Columns.Clear();
                    dgvReport.DataSource = null;
                    
                    dgvReport.AutoGenerateColumns = false;
                    BindingSource bsQryResults = new BindingSource(reportdata, null);
                    dgvReport.DataSource = bsQryResults;

                    DataGridViewAutoFilterTextBoxColumn objTCol = null;

                    for (int i = 0; i < reportdata.Columns.Count; i++)
                    {
                        objTCol = new DataGridViewAutoFilterTextBoxColumn();
                        objTCol.HeaderText = reportdata.Columns[i].ColumnName;
                        objTCol.DataPropertyName = reportdata.Columns[i].ColumnName;
                        objTCol.DropDownListBoxMaxLines = 50;     
                        
                        objTCol.FilteringEnabled = true;                          
                        dgvReport.Columns.Add(objTCol);
                    }                                    
                }
                else
                {
                    dgvReport.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindDataToGrid(DataTable _reportdata)
        {
            try
            {
                if (_reportdata != null)
                {
                    dgvReport.AutoGenerateColumns = false;
                    BindingSource bsQryResults = new BindingSource(_reportdata, null);
                    dgvReport.DataSource = bsQryResults;

                    colTAN.DataPropertyName = "TAN"; 
                    colBatch.DataPropertyName = "Batch_Name";
                    colBatchNo.DataPropertyName = "B.No";
                    colCurator.DataPropertyName = "Curator";
                    colReviewer.DataPropertyName = "Reviewer";
                    colQC.DataPropertyName = "QC";
                    colTANStatus.DataPropertyName = "Status";
                    colRxnCnt.DataPropertyName = "RXN Cnt";
                    colStageCnt.DataPropertyName = "Extra Stage Cnt";
                    colDocClass.DataPropertyName = "doc_class";
                    colTanPriority.DataPropertyName = "tan_priority"; 

                    GetStatusValues_BindToControls();

                    dgvReport.AutoResizeColumns();
                }
                else
                {
                    dgvReport.DataSource = null; ;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetStatusValues_BindToControls()
        {
            try
            {
                if (dgvReport.DataSource != null)
                {
                    BindingSource bs = (BindingSource)dgvReport.DataSource;
                    if (bs != null)
                    {
                        DataTable _reportdata = ((DataTable)bs.DataSource);

                        if (_reportdata.Rows.Count > 0)
                        {
                            if (bs.Filter != null)
                            {
                                DataView dv_Cur = _reportdata.Copy().DefaultView;
                                dv_Cur.RowFilter = bs.Filter;
                                DataTable dtFilterData = dv_Cur.ToTable();

                                if (dtFilterData != null)
                                {
                                    //No.of Reactions
                                    object objRxnCnt = dtFilterData.Compute("sum([RXN Cnt])", "[RXN Cnt] is not null");
                                    if (objRxnCnt != null)
                                    {
                                        lblRxns_Val.Text = objRxnCnt.ToString();
                                    }

                                    //No.of Extra Stages
                                    object objStgCnt = dtFilterData.Compute("sum([Extra Stage Cnt])", "[Extra Stage Cnt] is not null");
                                    if (objStgCnt != null)
                                    {
                                        lblStages_Val.Text = objStgCnt.ToString();
                                    }

                                    //No.of TANs
                                    lblTANCnt.Text = dtFilterData.Rows.Count.ToString();
                                }
                            }
                            else
                            {
                                //No.of Reactions
                                object objRxnCnt = _reportdata.Compute("sum([RXN Cnt])", "[RXN Cnt] is not null");
                                if (objRxnCnt != null)
                                {
                                    lblRxns_Val.Text = objRxnCnt.ToString();
                                }

                                //No.of Extra Stages
                                object objStgCnt = _reportdata.Compute("sum([Extra Stage Cnt])", "[Extra Stage Cnt] is not null");
                                if (objStgCnt != null)
                                {
                                    lblStages_Val.Text = objStgCnt.ToString();
                                }

                                //No.of TANs
                                lblTANCnt.Text = _reportdata.Rows.Count.ToString();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void frmUserTaskReport_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;

                DataTable dtBatches = null;// ReactDB.GetBatchNames();
                if (dtBatches != null)
                {
                    if (dtBatches.Rows.Count > 0)
                    {
                        chklstBatchName.DataSource = dtBatches;
                        chklstBatchName.DisplayMember = dtBatches.Columns[0].ColumnName;
                        chklstBatchName.ValueMember = dtBatches.Columns[0].ColumnName;
                        chklstBatchName.SelectedIndex = 0;                       
                    }
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvReport_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            try
            {
                GetStatusValues_BindToControls();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void lblClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                DataGridViewAutoFilterColumnHeaderCell.RemoveFilter(dgvReport);               
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvReport_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();
                while (strRowNumber.Length < dgvReport.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvReport.Font);

                if (dgvReport.RowHeadersWidth < (int)(size.Width + 20)) dgvReport.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
