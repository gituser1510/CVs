﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarrDAL;
using IndxReactNarr.Generic;
using IndxReactNarrBLL;

namespace IndxReactNarr
{
    public partial class frmProductivityReport : Form
    {
        public frmProductivityReport()
        {
            InitializeComponent();
        }

        public DataTable DailyStatusData = null;
        public DataTable DATWorkHours = null;

        private void frmProductivityReport_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;

                //DAT transfer is accessable only to Project Manager/Admin
                if (!string.IsNullOrEmpty(GlobalVariables.RoleName))
                {
                    btnTransferToDAT.Visible = false;
                    if (GlobalVariables.RoleName.ToUpper() == "PROJECT MANAGER" || GlobalVariables.RoleName.ToUpper() == "ADMINISTRATOR")
                    {
                        btnTransferToDAT.Visible = true;
                    }                    
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void datePicker_CloseUp(object sender, EventArgs e)
        {

        }

        private void BindProductivityDataToGrid(DataTable reportData)
        {
            try
            {
                if (reportData != null)
                {
                    dgvReport.AutoGenerateColumns = false;
                    dgvReport.DataSource = reportData;

                    colUserName.DataPropertyName = "UserName";
                    colUserRole.DataPropertyName = "UserRole";
                    colProductivityDate.DataPropertyName = "ProductivityDate";
                    colRxnCnt.DataPropertyName = "RxnCount";
                    colBenchMark.DataPropertyName = "Benchmark";
                    colProductivity.DataPropertyName = "Productivity";
                    colActivityCode.DataPropertyName = "ActivityCode";
                    colActivityID.DataPropertyName = "ActivityID";
                    colDATHrs.DataPropertyName = "DATHours";
                    colDATStatus.DataPropertyName = "DATStatus";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnTransferToDAT_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvReport.Rows.Count > 0)
                {
                    List<string> lstUserNames = new List<string>();
                    List<string> lstUserRoles = new List<string>();
                    //int[] iaActCodes = new int[dgvReport.Rows.Count];
                    List<string> lstActCodes = new List<string>();
                    List<DateTime> lstProdDate = new List<DateTime>();
                    List<double> lstdblProductivity = new List<double>();

                    double dblProd = 0;

                    for (int i = 0; i < dgvReport.Rows.Count; i++)
                    {
                        if (!string.IsNullOrEmpty(dgvReport.Rows[i].Cells["colActivityCode"].Value.ToString()))
                        {
                            if (dgvReport.Rows[i].Cells["colUserName"].Value != null)
                            {
                                lstUserNames.Add(dgvReport.Rows[i].Cells["colUserName"].Value.ToString());
                            }

                            if (dgvReport.Rows[i].Cells["colUserRole"].Value != null)
                            {
                                lstUserRoles.Add(dgvReport.Rows[i].Cells["colUserRole"].Value.ToString());
                            }

                            if (dgvReport.Rows[i].Cells["colActivityCode"].Value != null)
                            {
                                lstActCodes.Add(dgvReport.Rows[i].Cells["colActivityCode"].Value.ToString());
                            }

                            if (dgvReport.Rows[i].Cells["colProductivityDate"].Value != null)
                            {
                                lstProdDate.Add(Convert.ToDateTime(dgvReport.Rows[i].Cells["colProductivityDate"].Value.ToString()));
                            }

                            dblProd = 0;
                            if (dgvReport.Rows[i].Cells["colProductivity"].Value != null)
                            {
                                double.TryParse(dgvReport.Rows[i].Cells["colProductivity"].Value.ToString(), out dblProd);
                                lstdblProductivity.Add(Convert.ToDouble(dgvReport.Rows[i].Cells["colProductivity"].Value.ToString()));
                            }                           
                        }
                    }

                    //Transfer to DAT
                    PTTProductivityBO objPTT = new PTTProductivityBO();
                    //objPTT.ProdStartDate = dpStartDate.Value;
                    //objPTT.ProjectName = "CAS_RXN";
                    //objPTT.ProjectToolName = "CAS_RXN_TOOL";
                    //objPTT.UsersList = lstUserNames.ToArray(); 
                    //objPTT.UsersRoles = lstUserRoles.ToArray();
                    //objPTT.ActivityCodes = lstActCodes.ToArray();
                    //objPTT.ProductivityDate = lstProdDate.ToArray();
                    //objPTT.ProductivityVals = lstdblProductivity.ToArray();
                    //objPTT.SubmittedByUser = GlobalVariables.UserName;

                    if (DATDataAccess.UpdateUserProductivity(objPTT))
                    {
                        MessageBox.Show("Productivity data successfully transferred to DAT", "Reaction Analysis", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Error in productivity data transfer to DAT", "Reaction Analysis", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("No data available", "Reaction Analysis", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       

        private string[] GetDistinctUsersFromTable(DataTable dailyStatusRepData)
        {
            string[] saDistUsers = null;
            try
            {
                if (dailyStatusRepData != null)
                {
                    DataTable dtDistUsers = dailyStatusRepData.DefaultView.ToTable(true, new string[] { "user_name"});
                    if (dtDistUsers != null)
                    {                       
                        saDistUsers = dtDistUsers.Rows.Cast<DataRow>()
                                            .Select(row => row[0].ToString())
                                            .ToArray();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return saDistUsers;
        }

        private DataTable GetProductivityData(DateTime prodDate)
        {
            DataTable dtProductivity = null;
            try
            {
                if (DailyStatusData != null && DATWorkHours != null)
                {
                    //Get Productivity table definition
                    dtProductivity = GetProductivityTableDefinition();

                    double dbHrsWorked = 0;
                    int intRxnCnt = 0;
                    int intBenchMark = 0;
                    string strUserName = "";
                    string strRoleName = "";
                    int intActID = 0;
                    string strActivityCode = "";
                    string strDATStatus = "";
                    string strProdDate = "";

                    for (int i = 0; i < DailyStatusData.Rows.Count; i++)
                    {
                        strDATStatus = "";
                        strActivityCode = "";
                        intActID = 0;

                        strUserName = DailyStatusData.Rows[i]["User_Name"].ToString();
                        strRoleName = DailyStatusData.Rows[i]["Role_Name"].ToString();
                        strProdDate = DailyStatusData.Rows[i]["productivity_date"].ToString();
                        int.TryParse(DailyStatusData.Rows[i]["monthly_benchmark"].ToString(), out intBenchMark);
                        dbHrsWorked = GetUserDATWorkHoursFromTable(strUserName, strRoleName, Convert.ToDateTime(strProdDate), ref strActivityCode, ref intActID, ref strDATStatus);
                        int.TryParse(DailyStatusData.Rows[i]["reaction_cnt"].ToString(), out intRxnCnt);                        
                        
                        DataRow dtRow = dtProductivity.NewRow();
                        dtRow["UserName"] = strUserName;
                        dtRow["UserRole"] = strRoleName;
                        dtRow["DATHours"] = dbHrsWorked;
                        dtRow["ProductivityDate"] = strProdDate;
                        dtRow["DATStatus"] = strDATStatus;
                        dtRow["Benchmark"] = intBenchMark;
                        dtRow["ActivityID"] = intActID;
                        dtRow["ActivityCode"] = strActivityCode;
                        dtRow["RxnCount"] = intRxnCnt;
                        dtRow["Productivity"] = GetProductivityValue(intRxnCnt, dbHrsWorked, intBenchMark);
                        dtProductivity.Rows.Add(dtRow);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtProductivity;
        }

        private DataTable GetProductivityTableDefinition()
        {
            DataTable dtProductivity = null;
            try
            {
                dtProductivity = new DataTable();
                dtProductivity.Columns.Add("UserName");
                dtProductivity.Columns.Add("UserRole");
                dtProductivity.Columns.Add("ProductivityDate");
                dtProductivity.Columns.Add("ActivityCode");
                dtProductivity.Columns.Add("ActivityID");
                dtProductivity.Columns.Add("Benchmark");
                dtProductivity.Columns.Add("RxnCount");
                dtProductivity.Columns.Add("DATHours");
                dtProductivity.Columns.Add("DATStatus");
                dtProductivity.Columns.Add("Productivity");
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtProductivity;
        }

        private double GetUserDATWorkHoursFromTable(string userName, string roleName,DateTime prodDate, ref string activity_code, ref int activity_id, ref string datStatus)
        {
            double dblWorkHrs = 0;           
            try
            {
                if (DATWorkHours != null && !string.IsNullOrEmpty(userName) && !string.IsNullOrEmpty(roleName))
                {
                    DataView dvTemp = DATWorkHours.DefaultView;
                    string strRowFilter = "";
                    if (roleName.ToUpper() == "CURATOR")
                    {
                        strRowFilter = "USER_ID = '" + userName + "' and ACT_CODE = 'CUR' and TASK_DATE = '" + prodDate + "'";
                    }
                    else if (roleName.ToUpper() == "REVIEWER")
                    {
                        strRowFilter = "USER_ID = '" + userName + "' and ACT_CODE = 'REW' and TASK_DATE = '" + prodDate + "'";
                    }
                    else if (roleName.ToUpper() == "QUALITY CHECK")
                    {
                        strRowFilter = "USER_ID = '" + userName + "' and ACT_CODE = 'QC' and TASK_DATE = '" + prodDate + "'";
                    }
                    dvTemp.RowFilter = strRowFilter;

                    DataTable dtTemp = dvTemp.ToTable();
                    if (dtTemp != null)
                    {
                        if (dtTemp.Rows.Count > 0)
                        {
                            double.TryParse(dtTemp.Rows[0]["TASK_DAY_HRS"].ToString(), out dblWorkHrs);
                            activity_id = Convert.ToInt32(dtTemp.Rows[0]["ACT_ID"].ToString());
                            activity_code = dtTemp.Rows[0]["ACT_CODE"].ToString();
                            datStatus = dtTemp.Rows[0]["APPROVAL_STATUS"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }           
            return dblWorkHrs;
        }

        private double GetProductivityValue(int rxnCnt, double hrsWorked, int benchMarkVal)
        {
            double dblProdcutivity = 0;
            try
            {
                //Productivy formul  = (Total reactions/((Total Man hours/8.5)*Bench Mark)*100)
                if (rxnCnt > 0 && hrsWorked > 0 && benchMarkVal > 0)
                {
                    dblProdcutivity = (rxnCnt / ((hrsWorked / 8.5) * benchMarkVal) * 100);

                    dblProdcutivity = Math.Round(dblProdcutivity, 2);
                }
            }
            catch (Exception ex)
            {                
              ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dblProdcutivity;
        }

        private void dgvReport_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();
                while (strRowNumber.Length < dgvReport.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvReport.Font);

                if (dgvReport.RowHeadersWidth < (int)(size.Width + 20)) dgvReport.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnGetReport_Click(object sender, EventArgs e)
        {
            try
            {
                if (dpStartDate.Text != null && dpEndDate.Text != null)
                {
                    Cursor = Cursors.WaitCursor;

                    //Get Daily Productivity Status report
                    //DailyStatusData = CASRxnDataAccess.GetDailyProductivityReport(dpStartDate.Value);

                    DailyStatusData = null;// ReactDB.GetWeeklyProductivityReport(dpStartDate.Value, dpEndDate.Value);

                    //Get No.of Hours worked from DAT
                    PTTProductivityBO objPTT = new PTTProductivityBO();
                    //objPTT.ProdStartDate = dpStartDate.Value;
                    //objPTT.ProdEndDate = dpEndDate.Value;
                    objPTT.UsersList = GetDistinctUsersFromTable(DailyStatusData);
                    objPTT.ProjectName = "CAS_RXN";
                    DATWorkHours = DATDataAccess.GetUserWorkedHours(objPTT);

                    //Calculate Users Productivity & bind to grid
                    DataTable dtProductivity = GetProductivityData(dpStartDate.Value);
                    BindProductivityDataToGrid(dtProductivity);

                    btnTransferToDAT.Enabled = dgvReport.Rows.Count > 0 ? true : false;

                    Cursor = Cursors.Default;
                }
                else
                {
                    MessageBox.Show("Please enter start date and end date", "Reaction Analysis", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            Cursor = Cursors.Default;
        }        
    }
}
