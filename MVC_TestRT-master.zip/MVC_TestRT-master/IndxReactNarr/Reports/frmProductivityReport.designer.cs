﻿namespace IndxReactNarr
{
    partial class frmProductivityReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvReport = new System.Windows.Forms.DataGridView();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.btnTransferToDAT = new System.Windows.Forms.Button();
            this.dpStartDate = new System.Windows.Forms.DateTimePicker();
            this.lblSelect = new System.Windows.Forms.Label();
            this.dpEndDate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.btnGetReport = new System.Windows.Forms.Button();
            this.colUserName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colUserRole = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colProductivityDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDATHrs = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colActivityCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colActivityID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDATStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnCnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBenchMark = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colProductivity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReport)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.dgvReport);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1008, 498);
            this.pnlMain.TabIndex = 0;
            // 
            // dgvReport
            // 
            this.dgvReport.AllowUserToAddRows = false;
            this.dgvReport.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvReport.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvReport.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReport.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colUserName,
            this.colUserRole,
            this.colProductivityDate,
            this.colDATHrs,
            this.colActivityCode,
            this.colActivityID,
            this.colDATStatus,
            this.colRxnCnt,
            this.colBenchMark,
            this.colProductivity});
            this.dgvReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvReport.Location = new System.Drawing.Point(0, 37);
            this.dgvReport.Name = "dgvReport";
            this.dgvReport.ReadOnly = true;
            this.dgvReport.Size = new System.Drawing.Size(1008, 461);
            this.dgvReport.TabIndex = 2;
            this.dgvReport.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvReport_RowPostPaint);
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.btnGetReport);
            this.pnlTop.Controls.Add(this.dpEndDate);
            this.pnlTop.Controls.Add(this.label1);
            this.pnlTop.Controls.Add(this.btnTransferToDAT);
            this.pnlTop.Controls.Add(this.dpStartDate);
            this.pnlTop.Controls.Add(this.lblSelect);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1008, 37);
            this.pnlTop.TabIndex = 1;
            // 
            // btnTransferToDAT
            // 
            this.btnTransferToDAT.Location = new System.Drawing.Point(849, 3);
            this.btnTransferToDAT.Name = "btnTransferToDAT";
            this.btnTransferToDAT.Size = new System.Drawing.Size(130, 30);
            this.btnTransferToDAT.TabIndex = 3;
            this.btnTransferToDAT.Text = "Transfer to DAT";
            this.btnTransferToDAT.UseVisualStyleBackColor = true;
            this.btnTransferToDAT.Click += new System.EventHandler(this.btnTransferToDAT_Click);
            // 
            // dpStartDate
            // 
            this.dpStartDate.Location = new System.Drawing.Point(115, 5);
            this.dpStartDate.Name = "dpStartDate";
            this.dpStartDate.Size = new System.Drawing.Size(228, 25);
            this.dpStartDate.TabIndex = 1;
            // 
            // lblSelect
            // 
            this.lblSelect.AutoSize = true;
            this.lblSelect.Location = new System.Drawing.Point(3, 9);
            this.lblSelect.Name = "lblSelect";
            this.lblSelect.Size = new System.Drawing.Size(108, 17);
            this.lblSelect.TabIndex = 0;
            this.lblSelect.Text = "Week Start Date";
            // 
            // dpEndDate
            // 
            this.dpEndDate.Location = new System.Drawing.Point(466, 5);
            this.dpEndDate.Name = "dpEndDate";
            this.dpEndDate.Size = new System.Drawing.Size(228, 25);
            this.dpEndDate.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(359, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Week End Date";
            // 
            // btnGetReport
            // 
            this.btnGetReport.Location = new System.Drawing.Point(700, 3);
            this.btnGetReport.Name = "btnGetReport";
            this.btnGetReport.Size = new System.Drawing.Size(82, 30);
            this.btnGetReport.TabIndex = 6;
            this.btnGetReport.Text = "Get Report";
            this.btnGetReport.UseVisualStyleBackColor = true;
            this.btnGetReport.Click += new System.EventHandler(this.btnGetReport_Click);
            // 
            // colUserName
            // 
            this.colUserName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colUserName.HeaderText = "User Name";
            this.colUserName.Name = "colUserName";
            this.colUserName.ReadOnly = true;
            // 
            // colUserRole
            // 
            this.colUserRole.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colUserRole.HeaderText = "User Role";
            this.colUserRole.Name = "colUserRole";
            this.colUserRole.ReadOnly = true;
            // 
            // colProductivityDate
            // 
            this.colProductivityDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colProductivityDate.HeaderText = "ProductivityDate";
            this.colProductivityDate.Name = "colProductivityDate";
            this.colProductivityDate.ReadOnly = true;
            // 
            // colDATHrs
            // 
            this.colDATHrs.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colDATHrs.HeaderText = "DAT Hours";
            this.colDATHrs.Name = "colDATHrs";
            this.colDATHrs.ReadOnly = true;
            // 
            // colActivityCode
            // 
            this.colActivityCode.HeaderText = "ActivityCode";
            this.colActivityCode.Name = "colActivityCode";
            this.colActivityCode.ReadOnly = true;
            // 
            // colActivityID
            // 
            this.colActivityID.HeaderText = "ActivityID";
            this.colActivityID.Name = "colActivityID";
            this.colActivityID.ReadOnly = true;
            this.colActivityID.Visible = false;
            // 
            // colDATStatus
            // 
            this.colDATStatus.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colDATStatus.HeaderText = "DAT Status";
            this.colDATStatus.Name = "colDATStatus";
            this.colDATStatus.ReadOnly = true;
            // 
            // colRxnCnt
            // 
            this.colRxnCnt.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colRxnCnt.HeaderText = "ReactionCount";
            this.colRxnCnt.Name = "colRxnCnt";
            this.colRxnCnt.ReadOnly = true;
            // 
            // colBenchMark
            // 
            this.colBenchMark.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colBenchMark.HeaderText = "Benchmark";
            this.colBenchMark.Name = "colBenchMark";
            this.colBenchMark.ReadOnly = true;
            // 
            // colProductivity
            // 
            this.colProductivity.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colProductivity.HeaderText = "Productivity";
            this.colProductivity.Name = "colProductivity";
            this.colProductivity.ReadOnly = true;
            // 
            // frmProductivityReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1008, 498);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmProductivityReport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Productivity Report";
            this.Load += new System.EventHandler(this.frmProductivityReport_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvReport)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.DateTimePicker dpStartDate;
        private System.Windows.Forms.Label lblSelect;
        private System.Windows.Forms.DataGridView dgvReport;
        private System.Windows.Forms.Button btnTransferToDAT;
        private System.Windows.Forms.DateTimePicker dpEndDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnGetReport;
        private System.Windows.Forms.DataGridViewTextBoxColumn colUserName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colUserRole;
        private System.Windows.Forms.DataGridViewTextBoxColumn colProductivityDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDATHrs;
        private System.Windows.Forms.DataGridViewTextBoxColumn colActivityCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn colActivityID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDATStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnCnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBenchMark;
        private System.Windows.Forms.DataGridViewTextBoxColumn colProductivity;
    }
}