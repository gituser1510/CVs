﻿namespace IndxReactNarr.Reports
{
    partial class frmShipmentsOverAllStatusReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvShipmentsStatus = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colShipmentName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTotalTANs = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNotAssignedTANs = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCurationAssignedTANs = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCurationProgressTANs = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colReviewAssignedTANs = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colReviewProgressTANs = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colQCAssignedTANs = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colQCProgressTANs = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colQCCompletedTANs = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTotalRxnsCnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCuratedRxnsCnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colReviewedRxnCnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colQCRxnsCnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvShipmentsStatus)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.dgvShipmentsStatus);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1255, 438);
            this.pnlMain.TabIndex = 0;
            // 
            // dgvShipmentsStatus
            // 
            this.dgvShipmentsStatus.AllowUserToAddRows = false;
            this.dgvShipmentsStatus.AllowUserToDeleteRows = false;
            this.dgvShipmentsStatus.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Linen;
            this.dgvShipmentsStatus.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvShipmentsStatus.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            this.dgvShipmentsStatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvShipmentsStatus.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvShipmentsStatus.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colShipmentName,
            this.colTotalTANs,
            this.colNotAssignedTANs,
            this.colCurationAssignedTANs,
            this.colCurationProgressTANs,
            this.colReviewAssignedTANs,
            this.colReviewProgressTANs,
            this.colQCAssignedTANs,
            this.colQCProgressTANs,
            this.colQCCompletedTANs,
            this.colTotalRxnsCnt,
            this.colCuratedRxnsCnt,
            this.colReviewedRxnCnt,
            this.colQCRxnsCnt});
            this.dgvShipmentsStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvShipmentsStatus.Location = new System.Drawing.Point(0, 0);
            this.dgvShipmentsStatus.Name = "dgvShipmentsStatus";
            this.dgvShipmentsStatus.ReadOnly = true;
            this.dgvShipmentsStatus.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvShipmentsStatus.Size = new System.Drawing.Size(1255, 438);
            this.dgvShipmentsStatus.TabIndex = 0;
            this.dgvShipmentsStatus.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvShipmentsStatus_RowPostPaint);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Shipment";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Total TANs";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "NotAssignedTANs";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "AssignedForCuration";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "CurationProgress";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "AssignedForReview";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "ReviewProgressTANs";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "QCAssigned";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "QCProgress";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.HeaderText = "Total Rxns";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "CuratedRxns";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.HeaderText = "ReviewedRxns";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.HeaderText = "QCRxns";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            // 
            // colShipmentName
            // 
            this.colShipmentName.HeaderText = "Shipment";
            this.colShipmentName.Name = "colShipmentName";
            this.colShipmentName.ReadOnly = true;
            // 
            // colTotalTANs
            // 
            this.colTotalTANs.HeaderText = "Total TANs";
            this.colTotalTANs.Name = "colTotalTANs";
            this.colTotalTANs.ReadOnly = true;
            // 
            // colNotAssignedTANs
            // 
            this.colNotAssignedTANs.HeaderText = "Not Assigned TANs";
            this.colNotAssignedTANs.Name = "colNotAssignedTANs";
            this.colNotAssignedTANs.ReadOnly = true;
            // 
            // colCurationAssignedTANs
            // 
            this.colCurationAssignedTANs.HeaderText = "Assigned For Curation";
            this.colCurationAssignedTANs.Name = "colCurationAssignedTANs";
            this.colCurationAssignedTANs.ReadOnly = true;
            // 
            // colCurationProgressTANs
            // 
            this.colCurationProgressTANs.HeaderText = "Curation Progress TANs";
            this.colCurationProgressTANs.Name = "colCurationProgressTANs";
            this.colCurationProgressTANs.ReadOnly = true;
            // 
            // colReviewAssignedTANs
            // 
            this.colReviewAssignedTANs.HeaderText = "Assigned For Review TANs";
            this.colReviewAssignedTANs.Name = "colReviewAssignedTANs";
            this.colReviewAssignedTANs.ReadOnly = true;
            // 
            // colReviewProgressTANs
            // 
            this.colReviewProgressTANs.HeaderText = "Review Progress TANs";
            this.colReviewProgressTANs.Name = "colReviewProgressTANs";
            this.colReviewProgressTANs.ReadOnly = true;
            // 
            // colQCAssignedTANs
            // 
            this.colQCAssignedTANs.HeaderText = "QC Assigned TANs";
            this.colQCAssignedTANs.Name = "colQCAssignedTANs";
            this.colQCAssignedTANs.ReadOnly = true;
            // 
            // colQCProgressTANs
            // 
            this.colQCProgressTANs.HeaderText = "QC Progress TANs";
            this.colQCProgressTANs.Name = "colQCProgressTANs";
            this.colQCProgressTANs.ReadOnly = true;
            // 
            // colQCCompletedTANs
            // 
            this.colQCCompletedTANs.HeaderText = "QC Completed TANs";
            this.colQCCompletedTANs.Name = "colQCCompletedTANs";
            this.colQCCompletedTANs.ReadOnly = true;
            // 
            // colTotalRxnsCnt
            // 
            this.colTotalRxnsCnt.HeaderText = "Total Rxns";
            this.colTotalRxnsCnt.Name = "colTotalRxnsCnt";
            this.colTotalRxnsCnt.ReadOnly = true;
            // 
            // colCuratedRxnsCnt
            // 
            this.colCuratedRxnsCnt.HeaderText = "Curated Rxns";
            this.colCuratedRxnsCnt.Name = "colCuratedRxnsCnt";
            this.colCuratedRxnsCnt.ReadOnly = true;
            // 
            // colReviewedRxnCnt
            // 
            this.colReviewedRxnCnt.HeaderText = "Reviewed Rxns";
            this.colReviewedRxnCnt.Name = "colReviewedRxnCnt";
            this.colReviewedRxnCnt.ReadOnly = true;
            // 
            // colQCRxnsCnt
            // 
            this.colQCRxnsCnt.HeaderText = "QC Rxns";
            this.colQCRxnsCnt.Name = "colQCRxnsCnt";
            this.colQCRxnsCnt.ReadOnly = true;
            // 
            // frmShipmentsOverAllStatusReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1255, 438);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmShipmentsOverAllStatusReport";
            this.ShowIcon = false;
            this.Text = "Shipments Overall Status Report";
            this.Load += new System.EventHandler(this.frmShipmentsOverAllStatusReport_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvShipmentsStatus)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.DataGridView dgvShipmentsStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn colShipmentName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTotalTANs;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNotAssignedTANs;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCurationAssignedTANs;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCurationProgressTANs;
        private System.Windows.Forms.DataGridViewTextBoxColumn colReviewAssignedTANs;
        private System.Windows.Forms.DataGridViewTextBoxColumn colReviewProgressTANs;
        private System.Windows.Forms.DataGridViewTextBoxColumn colQCAssignedTANs;
        private System.Windows.Forms.DataGridViewTextBoxColumn colQCProgressTANs;
        private System.Windows.Forms.DataGridViewTextBoxColumn colQCCompletedTANs;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTotalRxnsCnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCuratedRxnsCnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn colReviewedRxnCnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn colQCRxnsCnt;
    }
}