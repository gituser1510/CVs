﻿#region NameSpaces
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Collections;
using IndxReactNarr.Generic;
using IndxReactNarrDAL;
using IndxReactNarr.Common;
#endregion NameSpaces

namespace IndxReactNarr
{
    public partial class frmTANReactionsReport : Form
    {
        #region Constructor
        
        public frmTANReactionsReport()
        {
            InitializeComponent();
        }
       
        #endregion      

        #region Public properties       
              
        public string TAN_Name
        {
            get;
            set;
        }

        public int TAN_ID
        {
            get;
            set;
        }
        #endregion

        private void frmRxnReport_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;
                ColorGridRowsOnRxnID();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            try
            {
                dgReportView.DataSource = null;
                
                //Clear Status labels count, if any
                ClearStatusLabelsCount();

                if (txtTan.Visible)
                {
                    if (string.IsNullOrEmpty(txtTan.Text.Trim()))
                    {
                        MessageBox.Show("TAN field can't be blank", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    else
                    {
                        if (Validations.ValidateTANFormat(txtTan.Text.Trim()))
                        {
                            TAN_Name = txtTan.Text.Trim();
                        }
                        else
                        {
                            MessageBox.Show("TAN format is not valid", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }
                    }
                }
                else if (cmbTANs.Visible)
                {
                    if (cmbTANs.SelectedItem != null)
                    {
                        if (cmbTANs.Text.ToString() != "")
                        {
                            TAN_Name = cmbTANs.Text.ToString();
                        }
                    }
                }
                GetReportDataOnTANAndBindToGrid(TAN_Name);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        public void GetUserAssignedTANsBindToControl()
        {
            try
            {
                if (Generic.GlobalVariables.RoleName.ToUpper() == "ANALYST" || Generic.GlobalVariables.RoleName.ToUpper() == "REVIEW ANALYST")// || Generic.GlobalVariables.RoleName.ToUpper() == "QUALITY ANALYST"
                {
                    txtTan.Visible = false;
                    cmbTANs.Visible = true;

                    //Retrieve assigned TANs for the user based on userid,role
                    DataTable dtAssignedTans = TaskManagementDB.GetUserTasksOnModule(GlobalVariables.URID, GlobalVariables.ApplicationName, GlobalVariables.ModuleName);
                    if (dtAssignedTans != null && dtAssignedTans.Rows.Count > 0)
                    {
                        cmbTANs.DataSource = dtAssignedTans;
                        cmbTANs.DisplayMember = "TAN_NAME";
                        cmbTANs.ValueMember = "TAN_ID";
                    }
                }
                else
                {
                    txtTan.Visible = true;
                    cmbTANs.Visible = false;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetReportDataOnTANAndBindToGrid(string tanName)
        {
            try
            {
                //Get TAN Report data
                DataTable dtComments = null;
                DataTable tanReport = ReactDB.GetTANDetailedReportOnTAN(tanName, out dtComments);

                if (dtComments != null)
                {
                    txtComments.Text = GetFormattedComments(dtComments);
                }

                if (tanReport != null)
                {
                    if (tanReport.Rows.Count > 0)
                    {
                        //lblAnalystID.Text = tanReport.Rows[0]["analyst"].ToString();
                       
                        lblBatchName.Text = tanReport.Rows[0]["SHIPMENT_NAME"].ToString();
                        lblBatchNo.Text = tanReport.Rows[0]["BATCH_NO"].ToString();

                        //Customize the datatable on reactionid here               
                        DataTable dtCust = CustomizeDataTableOnRxnID(tanReport);
                        if (dtCust != null)
                        {
                            dgReportView.DataSource = dtCust;
                            dgReportView.Refresh();
                        }

                        //Color Datagrid Rows based on Rxn ID
                        ColorGridRowsOnRxnID();

                        //Get Participants Count on TAN
                        GetParticipantsCount();

                        //Get Reactions,Stages count on TAN
                        CountsOfReactionStageCounts(tanReport);

                        //Disable Sort on Grid Columns
                        DisableSort_Allow_Sizing_OnColumns();

                        //Hide Reaction Stage ID column
                        dgReportView.Columns["RxnStageID"].Visible = false;
                    }
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        private string GetFormattedComments(DataTable commentsData)
        {
            string strComments = "";
            try
            {
                if (commentsData != null)
                {
                    if (commentsData.Rows.Count > 0)
                    {
                        //Get CAS consulted for comments
                        strComments = strComments.Trim() + Environment.NewLine + GetCommentsOnCommentsType(commentsData, Enums.CommentsType.CAS.ToString());

                        //Get Author Error comments
                        strComments = strComments.Trim() + Environment.NewLine + GetCommentsOnCommentsType(commentsData, Enums.CommentsType.AUTHOR.ToString());

                        //Get Indexing Error comments
                        strComments = strComments.Trim() + Environment.NewLine + GetCommentsOnCommentsType(commentsData, Enums.CommentsType.INDEXING.ToString());

                        //Get Other comments
                        strComments = strComments.Trim() + Environment.NewLine + GetCommentsOnCommentsType(commentsData, Enums.CommentsType.TEMPERATURE.ToString());

                        //Get Other comments
                        strComments = strComments.Trim() + Environment.NewLine + GetCommentsOnCommentsType(commentsData, Enums.CommentsType.OTHER.ToString());

                        //Get Default comments
                        strComments = strComments.Trim() + Environment.NewLine + GetCommentsOnCommentsType(commentsData, Enums.CommentsType.DEFAULT.ToString());
                    }
                }

                //if (string.IsNullOrEmpty(strComments.Trim()))
                //{
                //    strComments = "~~";
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strComments.Trim();
        }

        private string GetCommentsOnCommentsType(DataTable commentsData, string commentsType)
        {
            string strComments = "";
            try
            {
                if (commentsData != null)
                {
                    if (commentsData.Rows.Count > 0)
                    {
                        string strDelimiter = "";
                        switch (commentsType.ToUpper())
                        {
                            case "CAS":
                                strDelimiter = "CAS: ";
                                break;

                            case "INDEXING":
                                strDelimiter = "INDEXING: ";
                                break;

                            case "AUTHOR":
                                strDelimiter = "AUTHOR: ";
                                break;

                            case "OTHER":
                                strDelimiter = "OTHER: ";
                                break;
                            case "TEMPERATURE":
                                strDelimiter = "TEMPERATURE: ";
                                break;
                            case "DEFAULT":
                                strDelimiter = "DEFAULT: ";
                                break;
                        }

                        var rows = from r in commentsData.AsEnumerable()
                                   where r.Field<string>("COMMENT_TYPE") == commentsType
                                   select new
                                   {
                                       Comments = r.Field<string>("TAN_COMMENT")
                                   };

                        if (rows != null)
                        {
                            foreach (var r in rows)
                            {
                                strComments = string.IsNullOrEmpty(strComments) ? strDelimiter + r.Comments.Trim() : r.Comments.Trim();
                                //End with .
                                strComments = !strComments.Trim().EndsWith(".") ? strComments.Trim() + "." : r.Comments.Trim();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strComments.Trim();
        }

        public void LoadTANDetailsReport()
        {
            try
            {
                if (!string.IsNullOrEmpty(TAN_Name.Trim()))
                {
                    txtTan.Text = TAN_Name;
                    txtTan.ReadOnly = true;
                    txtTan.BackColor = Color.White;
                    txtTan.ForeColor = Color.Blue;
                    GetReportDataOnTANAndBindToGrid(TAN_Name);                  
                }
            }
            catch (Exception ex)
            {
               ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        public void GetParticipantsCount()
        {
            try
            {
                DataTable dtConds = null;
                DataTable dtSer8000 = null;
                DataTable dtParticipants = ReactDB.GetTANParticipantCountsOnTAN(TAN_Name, out dtConds, out dtSer8000);
                if (dtParticipants != null)
                {
                    if (dtParticipants.Rows.Count > 0)
                    {
                        string temp_val = "";
                        foreach (DataRow dRow in dtParticipants.Rows)
                        {
                            temp_val = dRow["PP_TYPE"].ToString();
                            if (temp_val == "AGENT")
                            {
                                lblAgCnt.Text = dRow["PP_CNT"].ToString();
                            }
                            else if (temp_val == "SOLVENT")
                            {
                                lblsolCnt.Text = dRow["PP_CNT"].ToString();
                            }
                            else if (temp_val == "REACTANT")
                            {
                                lblreactCnt.Text = dRow["PP_CNT"].ToString();
                            }
                            else if (temp_val == "CATALYST")
                            {
                                lblcatCnt.Text = dRow["PP_CNT"].ToString();
                            }
                            else if (temp_val == "PRODUCT")
                            {
                                lblprodCnt.Text = dRow["PP_CNT"].ToString();
                            }
                        }
                    }
                }
                               
                if (dtConds != null)
                {
                    if (dtConds.Rows.Count > 0)
                    {
                        lblTempCnt.Text = dtConds.Rows[0]["TEMPERATURE"].ToString();
                        lblPrCnt.Text = dtConds.Rows[0]["PRESSURE"].ToString();
                        lblPhCnt.Text = dtConds.Rows[0]["PH"].ToString();
                        lblTimeCnt.Text = dtConds.Rows[0]["TIME"].ToString();
                    }
                }
                               
                if (dtSer8000 != null)
                {
                    if (dtSer8000.Rows.Count > 0)
                    {
                        lblDist8000.Text = dtSer8000.Rows[0]["DIST_SER_8000"].ToString();
                        lblRxn8000.Text = dtSer8000.Rows[0]["DISTINCT_REACTIONS"].ToString();
                    }
                }

                //DataTable dtDist8000 = CASRxnDataAccess.GetDistinct8000OnTAN(TAN);
                //if (dtDist8000 != null)
                //{
                //    if (dtDist8000.Rows.Count > 0)
                //    {
                //        lblDist8000.Text = dtDist8000.Rows[0][0].ToString();
                //        lblRxn8000.Text = dtDist8000.Rows[0][1].ToString();
                //    }
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        public void CountsOfReactionStageCounts(DataTable reportData)
        {
            try
            {               
                if (reportData != null)
                {
                    if (reportData.Rows.Count > 0)
                    {
                        DataTable dtRIds_Uniq = reportData.DefaultView.ToTable(true, "RXN_ID");//rxnnum
                        if (dtRIds_Uniq != null)
                        {
                            if (dtRIds_Uniq.Rows.Count > 0)
                            {
                                lblrtct.Text = dtRIds_Uniq.Rows.Count.ToString();
                            }
                        }

                        DataTable dtStg_Uniq = reportData.DefaultView.ToTable(true, "RXN_STAGE_ID");//id
                        if (dtStg_Uniq != null)
                        {
                            if (dtStg_Uniq.Rows.Count > 0)
                            {
                                lblstct.Text = dtStg_Uniq.Rows.Count.ToString();
                            }
                        }                        
                    }
                }
            }
            catch (Exception ex)
            {
                IndxReactNarr.Generic.ErrorHandling.WriteErrorLog(" CountsOFParticipants " + ex.StackTrace.ToString());
            }
        }

        private DataTable CustomizeDataTableOnRxnID(DataTable _rxndatatbl)
        {
            DataTable dtCustRIds = new DataTable();
            try
            {
                if (_rxndatatbl != null)
                {
                    if (_rxndatatbl.Rows.Count > 0)
                    {
                        dtCustRIds.Columns.Add("S.No", typeof(string));
                        dtCustRIds.Columns.Add("RxnNum",typeof(string));
                        dtCustRIds.Columns.Add("Product(Yield)", typeof(string));
                        dtCustRIds.Columns.Add("RxnStageId", typeof(string));
                        dtCustRIds.Columns.Add("Reactants", typeof(string));
                        dtCustRIds.Columns.Add("Agents", typeof(string));
                        dtCustRIds.Columns.Add("Catalyst", typeof(string));
                        dtCustRIds.Columns.Add("Solvent", typeof(string));
                        dtCustRIds.Columns.Add("Time", typeof(string));
                        dtCustRIds.Columns.Add("Temperature", typeof(string));
                        dtCustRIds.Columns.Add("Pressure", typeof(string));
                        dtCustRIds.Columns.Add("Ph", typeof(string));
                        dtCustRIds.Columns.Add("CVT", typeof(string));
                        dtCustRIds.Columns.Add("FreeText", typeof(string));

                        DataTable dtRxnIdsUniq = _rxndatatbl.DefaultView.ToTable(true, "RXN_ID"); //rxnnum                     
                        if (dtRxnIdsUniq != null)
                        {
                            if (dtRxnIdsUniq.Rows.Count > 0)
                            {
                                int rxnID = 0;
                                int intRxnCnt = 0;
                                for (int i = 0; i < dtRxnIdsUniq.Rows.Count; i++)
                                {
                                    rxnID = Convert.ToInt32(dtRxnIdsUniq.Rows[i]["RXN_ID"].ToString());//rxnnum

                                    var query = (from r in _rxndatatbl.AsEnumerable()
                                                 where r.Field<Int64>("RXN_ID") == rxnID //rxnnum
                                                 select r.Field<Int64>("RXN_STAGE_ID")).Distinct();      //id                             

                                    int cntr = 0;
                                    foreach (int rsid in query)
                                    {
                                        DataRow dtRow = dtCustRIds.NewRow();

                                        if (cntr == 0)
                                        {
                                            intRxnCnt++;
                                            dtRow["S.No"] = intRxnCnt.ToString();

                                            var query1 = from r in _rxndatatbl.AsEnumerable()
                                                         where r.Field<Int64>("RXN_ID") == rxnID //rxnnum
                                                         select new
                                                         {
                                                             rxnNUM = r.Field<Int32>("RXN_NUM"),
                                                             rxnSeq = r.Field<Int32>("RXN_SEQ")
                                                         };

                                            if (query1 != null)
                                            {
                                                dtRow["RxnNum"] = query1.ElementAt(0).rxnNUM + "-"  + query1.ElementAt(0).rxnSeq;
                                            }

                                            dtRow["Product(Yield)"] = ReturnQueryValue(_rxndatatbl, rxnID, rsid, "PRODUCT");// ReturnProductYield(_rxndatatbl, rxnID, rsid);
                                        }
                                        cntr++;

                                        dtRow["RxnStageId"] = rsid.ToString();                                        

                                        dtRow["Reactants"] = ReturnQueryValue(_rxndatatbl, rxnID,rsid, "REACTANT");
                                        dtRow["Agents"] = ReturnQueryValue(_rxndatatbl, rxnID,rsid, "AGENT");
                                        dtRow["Catalyst"] = ReturnQueryValue(_rxndatatbl, rxnID,rsid, "CATALYST");
                                        dtRow["Solvent"] = ReturnQueryValue(_rxndatatbl, rxnID,rsid, "SOLVENT");
                                        dtRow["Time"] = ReturnQueryValue(_rxndatatbl, rxnID, rsid, "RC_TIME");
                                        dtRow["Temperature"] = ReturnQueryValue(_rxndatatbl, rxnID,rsid, "TEMPERATURE");
                                        dtRow["Pressure"] = ReturnQueryValue(_rxndatatbl, rxnID,rsid, "PRESSURE");
                                        dtRow["Ph"] = ReturnQueryValue(_rxndatatbl, rxnID,rsid, "PH");
                                        dtRow["CVT"] = ReturnQueryValue(_rxndatatbl, rxnID, rsid, "CVT");
                                        dtRow["FreeText"] = ReturnQueryValue(_rxndatatbl, rxnID, rsid, "FREE_TEXT");

                                        dtCustRIds.Rows.Add(dtRow);
                                    }
                                }
                                return dtCustRIds;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return null;
        }

        private string ReturnProductYield(DataTable _dtrxntbl, string _rxnno, int _rxnstageid)
        {
            string strProd_Y = "";
            try
            {
                if (_dtrxntbl != null)
                {
                    if (_dtrxntbl.Rows.Count > 0)
                    {
                        DataRow[] dtRowArr = _dtrxntbl.Select("rxnnum = '" + _rxnno + "' and id = '" + _rxnstageid + "'");
                        if (dtRowArr != null)
                        {
                            if (dtRowArr.Length > 0)
                            {
                                for (int i = 0; i < dtRowArr.Length; i++)
                                {
                                    if (dtRowArr[i]["p_y"].ToString() != "0")
                                    {
                                        if (strProd_Y == "")
                                        {
                                            strProd_Y = dtRowArr[i]["p_y"].ToString();
                                        }
                                        else
                                        {
                                            strProd_Y = strProd_Y + "," + dtRowArr[i]["p_y"].ToString();
                                        }
                                    }
                                }                         
                                return strProd_Y;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strProd_Y;
        }

        private string ReturnQueryValue(DataTable _dtrxntbl,int _rxnID,int _rxnStageId,string _columnname)
        {
            string strResult = "";
            try
            {
                if (_dtrxntbl != null)
                {
                    if (_dtrxntbl.Rows.Count > 0)
                    {
                        ArrayList alstResVals = new ArrayList();

                        if (_dtrxntbl.Columns[_columnname].DataType.ToString() == "System.Decimal")
                        {
                           var query = (from r in _dtrxntbl.AsEnumerable()
                                        where r.Field<Int64>("RXN_ID") == _rxnID
                                              && r.Field<Int64>("RXN_STAGE_ID") == _rxnStageId
                                              && r.Field<decimal?>(_columnname) != null
                                       select r.Field<decimal?>(_columnname)).Distinct();
                            
                           foreach (decimal s in query)
                           {
                               if (s > 0)
                               {
                                   if (!alstResVals.Contains(s.ToString()))
                                   {
                                       alstResVals.Add(s.ToString());
                                   }                                  
                               }
                           }
                           if (alstResVals != null)
                           {
                               if (alstResVals.Count > 0)
                               {
                                   for (int i = 0; i < alstResVals.Count; i++)
                                   {
                                       strResult = string.IsNullOrEmpty(strResult.Trim()) ? alstResVals[i].ToString() : strResult.Trim() + "\r\n" + alstResVals[i].ToString();
                                   }
                               }
                           }
                        }
                        else if (_dtrxntbl.Columns[_columnname].DataType.ToString() == "System.String")
                        {
                            var query = (from r in _dtrxntbl.AsEnumerable()
                                         where r.Field<Int64>("RXN_ID") == _rxnID
                                         && r.Field<Int64>("RXN_STAGE_ID") == _rxnStageId
                                         && r.Field<string>(_columnname) != null
                                         select r.Field<string>(_columnname));

                            foreach (string s in query)
                            {
                                if (s != "")
                                {
                                    if (!alstResVals.Contains(s.ToString()))
                                    {
                                        alstResVals.Add(s.ToString());
                                    } 
                                }
                            }

                            if (alstResVals != null)
                            {
                                if (alstResVals.Count > 0)
                                {
                                    for (int i = 0; i < alstResVals.Count; i++)
                                    {
                                        strResult = string.IsNullOrEmpty(strResult.Trim()) ? alstResVals[i].ToString() : strResult.Trim() + "\r\n" + alstResVals[i].ToString();
                                    }
                                }
                            }
                        }                 
                                              
                    }
                }
                return strResult;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strResult;
        }

        private string ReturnStringFromList(ArrayList _vallist)
        {
            string strVals = "";
            try
            {
                foreach (string str in _vallist)
                {
                    strVals = string.IsNullOrEmpty(strVals.Trim()) ? str.Trim() : strVals + "," + str.Trim();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strVals;
        }

        private void ColorGridRowsOnRxnID()
        {
            try
            {         
                if (dgReportView.Rows.Count > 0)
                {
                    dgReportView.ReadOnly = false;
                    Color clr = Color.LightYellow;                   

                    for (int i = 0; i < dgReportView.Rows.Count; i++)
                    {
                        if (dgReportView.Rows[i].Cells[0].Value.ToString() != "")
                        {
                            if (i > 0 && dgReportView.Rows[i - 1].DefaultCellStyle.BackColor == Color.LightYellow)
                            {
                                clr = Color.LightSalmon;                                
                            }
                            else if (i > 0 && dgReportView.Rows[i - 1].DefaultCellStyle.BackColor == Color.LightSalmon)
                            {
                                clr = Color.LightYellow;                                
                            }                            
                            dgReportView.Rows[i].DefaultCellStyle.BackColor = clr;                             
                        }
                        else
                        {
                            dgReportView.Rows[i].DefaultCellStyle.BackColor = clr;
                        }
                    }                    
                    dgReportView.ReadOnly = true;
                    dgReportView.Refresh();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void DisableSort_Allow_Sizing_OnColumns()
        {
            try
            {
                if (dgReportView.Columns.Count > 0)
                {
                    for (int i = 0; i < dgReportView.Columns.Count; i++)
                    {
                        dgReportView.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
                        dgReportView.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                    }
                    dgReportView.Columns[0].Width = 40;//S.No column
                    dgReportView.Columns[1].Width = 65;//RxnNum Column
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void ClearStatusLabelsCount()
        {
            try
            {
                lblBatchName.Text = "";
                lblBatchNo.Text = "";

                lblrtct.Text = "0";
                lblstct.Text = "0";
                lblDist8000.Text = "0";
                lblRxn8000.Text = "0";
                lblprodCnt.Text = "0";
                lblreactCnt.Text = "0";
                lblcatCnt.Text = "0";
                lblsolCnt.Text = "0";
                lblAgCnt.Text = "0";
                lblTimeCnt.Text = "0";
                lblPrCnt.Text = "0";
                lblTempCnt.Text = "0";
                lblPhCnt.Text = "0";
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }                    
    }
}
