﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using IndxReactNarrDAL;

namespace IndxReactNarr.Reports
{
    public partial class frmShipmentDetailedReport : Form
    {
        public frmShipmentDetailedReport()
        {
            InitializeComponent();
        }

        public DataTable ShipmentsData
        {
            get;
            set;
        }

        public DataTable ReportData
        {
            get;
            set;
        }

        private void frmShipmentDetailedReport_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;
                
                GetShipmentsAndBindToTextBox();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetShipmentsAndBindToTextBox()
        {
            try
            {
                DataTable dtTanTypes = null;
                DataTable dtShipments = null;

                using (dtShipments = ReactDB.GetShipmentDetailsByAppName(GlobalVariables.ApplicationName, out dtTanTypes))
                {
                    if (dtShipments != null && dtShipments.Rows.Count > 0)
                    {
                        ShipmentsData = dtShipments;

                        AutoCompleteStringCollection shipmentColl = new AutoCompleteStringCollection();

                        for (int i = 0; i < dtShipments.Rows.Count; i++)
                        {
                            if (dtShipments.Rows[i][0] != null)
                            {
                                shipmentColl.Add(dtShipments.Rows[i]["SHIPMENT_NAME"].ToString());
                            }
                        }

                        txtShipmentName.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                        txtShipmentName.AutoCompleteSource = AutoCompleteSource.CustomSource;
                        txtShipmentName.AutoCompleteCustomSource = shipmentColl;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtShipmentName.Text.Trim()) && ShipmentsData != null)
                {
                    int intBNo = 0;
                    int.TryParse(txtBatchNo.Text.Trim(), out intBNo);
                    Int64 shipmentID = ShipmentsData.Select("SHIPMENT_NAME = '" + txtShipmentName.Text.Trim() + "'").ElementAt(0).Field<Int64>("SHIPMENT_ID");

                    List<int> lstShipmentID = new List<int>();
                    lstShipmentID.Add(Convert.ToInt32(shipmentID));

                    DataTable dtReport = ReactDB.GetMultipleShipmentsStatusReport(lstShipmentID, intBNo);

                    if (dtReport != null)
                    {
                        ReportData = dtReport;

                        BindDataShipmentReportToGrid(dtReport);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindDataShipmentReportToGrid(DataTable reportData)
        {
            try
            {
                if (reportData != null)
                {
                    dgvReport.AutoGenerateColumns = false;
                    BindingSource bsQryResults = new BindingSource(reportData, null);
                    dgvReport.DataSource = bsQryResults;

                    dgvReport.AutoGenerateColumns = false;
                    dgvReport.DataSource = bsQryResults;

                    colTAN.DataPropertyName = "TAN_NAME";
                    colBatchNo.DataPropertyName = "BATCH_NO";
                    colDocClass.DataPropertyName = "DOC_CLASS";
                    colTANPriority.DataPropertyName = "TAN_PRIORITY";
                    colAnalyst.DataPropertyName = "ANALYST";
                    colRevAnalyst.DataPropertyName = "REV_ANALYST";
                    colQCAnalyst.DataPropertyName = "QC_ANALYST";
                    colReactionCnt.DataPropertyName = "RXN_CNT";
                    colExtraStageCnt.DataPropertyName = "RXN_STAGE_CNT";
                    colNUMsCnt.DataPropertyName = "NUM_CNT";
                    colTaskStatus.DataPropertyName = "TASK_STATUS";
                    colMappingUpdateCnt.DataPropertyName = "RXN_MAPPING_UPDATE_CNT";

                    if (GlobalVariables.ApplicationName == Enums.ApplicationName.EXPPROCEDURES.ToString() ||
                        GlobalVariables.ApplicationName == Enums.ApplicationName.NARRATIVES.ToString())
                    {
                        colExtraStageCnt.Visible = false;
                        lblStages.Visible = false;
                        lblStages_Val.Visible = false;
                        colNUMsCnt.Visible = false;
                    }
                    
                    colMappingUpdateCnt.Visible = GlobalVariables.ApplicationName == Enums.ApplicationName.EXPPROCEDURES.ToString() ? true : false;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetStatusValues_BindToControls()
        {
            try
            {
                if (dgvReport.DataSource != null)
                {
                    BindingSource bs = (BindingSource)dgvReport.DataSource;
                    if (bs != null)
                    {
                        DataTable _reportdata = ((DataTable)bs.DataSource);

                        if (bs.Filter != null)
                        {
                            DataView dv_Cur = _reportdata.Copy().DefaultView;
                            dv_Cur.RowFilter = bs.Filter;
                            DataTable dtFilterData = dv_Cur.ToTable();

                            SetStatusLabelsData(dtFilterData);
                        }
                        else
                        {
                            SetStatusLabelsData(_reportdata);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void SetStatusLabelsData(DataTable filteredData)
        {
            try
            {
                if (filteredData != null && filteredData.Rows.Count > 0)
                {
                    //Assigned for Curation
                    lblAss_Cur_Val.Text = filteredData.Select("TASK_STATUS = 'CURATION - ASSIGNED' and TASK_STATUS is not null").Count().ToString();
                    lblRxnCnt_CurAssigned.Text = filteredData.Compute("sum([RXN_CNT])", "TASK_STATUS = 'CURATION - ASSIGNED' and TASK_STATUS is not null").ToString();

                    //Curation Progress
                    lblCurationProgress_Val.Text = filteredData.Select("TASK_STATUS = 'CURATION - PROGRESS' and TASK_STATUS is not null").Count().ToString();
                    lblRxnCnt_CurProgr.Text = filteredData.Compute("sum([RXN_CNT])", "TASK_STATUS = 'CURATION - PROGRESS' and TASK_STATUS is not null").ToString();

                    //Curation Completed
                    lblCuration_Val.Text = filteredData.Select("TASK_STATUS = 'REVIEW - ASSIGNED' and TASK_STATUS is not null").Count().ToString();
                    lblRxnCnt_CurCompl.Text = filteredData.Compute("sum([RXN_CNT])", "TASK_STATUS = 'REVIEW - ASSIGNED' and TASK_STATUS is not null").ToString();

                    //Review Progress
                    lblReviewProgress_Val.Text = filteredData.Select("TASK_STATUS = 'REVIEW - PROGRESS' and TASK_STATUS is not null").Count().ToString();
                    lblRxnCnt_RevProgr.Text = filteredData.Compute("sum([RXN_CNT])", "TASK_STATUS = 'REVIEW - PROGRESS' and TASK_STATUS is not null").ToString();

                    //Review Completed
                    lblReview_Val.Text = filteredData.Select("TASK_STATUS = 'QC - ASSIGNED' and TASK_STATUS is not null").Count().ToString();
                    lblRxnCnt_RevCompl.Text = filteredData.Compute("sum([RXN_CNT])", "TASK_STATUS = 'QC - ASSIGNED' and TASK_STATUS is not null").ToString();

                    //QC - Progress
                    lblQCProgress_Val.Text = filteredData.Select("TASK_STATUS = 'QC - PROGRESS' and TASK_STATUS is not null").Count().ToString();
                    lblRxnCnt_QcProgr.Text = filteredData.Compute("sum([RXN_CNT])", "TASK_STATUS = 'QC - PROGRESS' and TASK_STATUS is not null").ToString();

                    //QC Completed
                    lblQC_Val.Text = filteredData.Select("TASK_STATUS = 'QC - COMPLETED' and TASK_STATUS is not null").Count().ToString();

                    //Not Assigned TANs
                    lblPending_Val.Text = filteredData.Select("TASK_STATUS = 'NOT ASSIGNED' and TASK_STATUS is not null").Count().ToString();

                    //No.of Reactions
                    lblTotalRxnsCnt.Text = filteredData.Compute("sum([RXN_CNT])", "[RXN_CNT] is not null").ToString();

                    //No.of Extra Stages
                    lblStages_Val.Text = filteredData.Compute("sum([RXN_STAGE_CNT])", "[RXN_STAGE_CNT] is not null").ToString();
                                        
                    //No.of TANs
                    lblTANCnt.Text = filteredData.Rows.Count.ToString();

                    lblMappingUpdateCnt.Text = filteredData.Compute("sum([RXN_MAPPING_UPDATE_CNT])", "[RXN_MAPPING_UPDATE_CNT] is not null").ToString();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetFilterDataAndBindToGrid()
        {
            try
            {
                if (ReportData != null)
                {
                    string strFCond = GetFilterCondition();
                    if (strFCond.Trim() != "")
                    {
                        DataTable dtTANs = ReportData.Copy();
                        DataView dv = dtTANs.DefaultView;
                        DataTable dtTemp = null;

                        dv.RowFilter = strFCond;
                        dtTemp = dv.ToTable();
                        BindDataShipmentReportToGrid(dtTemp);
                    }
                    else
                    {
                        DataTable dtAllTANs = ReportData.Copy();
                        BindDataShipmentReportToGrid(dtAllTANs);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetFilterCondition()
        {
            string strFCond = "";
            try
            {
                if (!string.IsNullOrEmpty(txtTAN.Text.Trim()))
                {
                    strFCond = "TAN_NAME like '" + txtTAN.Text.Trim() + "%'";
                }

                if (!string.IsNullOrEmpty(txtCurator.Text.Trim()))
                {
                    if (strFCond.Trim() == "")
                    {
                        strFCond = "ANALYST like '" + txtCurator.Text.Trim() + "%'";
                    }
                    else
                    {
                        strFCond = strFCond + " and ANALYST like '" + txtCurator.Text.Trim() + "%'";
                    }
                }

                if (!string.IsNullOrEmpty(txtReviewer.Text.Trim()))
                {
                    if (strFCond.Trim() == "")
                    {
                        strFCond = "REV_ANALYST like '" + txtReviewer.Text.Trim() + "%'";
                    }
                    else
                    {
                        strFCond = strFCond + " and REV_ANALYST like '" + txtReviewer.Text.Trim() + "%'";
                    }
                }

                if (!string.IsNullOrEmpty(txtQC.Text.Trim() ))
                {
                    if (strFCond.Trim() == "")
                    {
                        strFCond = "QC_ANALYST like '" + txtQC.Text.Trim() + "%'";
                    }
                    else
                    {
                        strFCond = strFCond + " and QC_ANALYST like '" + txtQC.Text.Trim() + "%'";
                    }
                }

                if (!string.IsNullOrEmpty(txtStatus.Text.Trim() ))
                {
                    if (strFCond.Trim() == "")
                    {
                        strFCond = "TASK_STATUS like '" + txtStatus.Text.Trim() + "%'";
                    }
                    else
                    {
                        strFCond = strFCond + " and TASK_STATUS like '" + txtStatus.Text.Trim() + "%'";
                    }
                }
                return strFCond;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strFCond;
        }

        private void txtTAN_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilterDataAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtStatus_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilterDataAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtCurator_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilterDataAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtQC_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilterDataAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtReviewer_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilterDataAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvReport_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();
                while (strRowNumber.Length < dgvReport.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvReport.Font);

                if (dgvReport.RowHeadersWidth < (int)(size.Width + 20)) dgvReport.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvReport_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            try
            {
                GetStatusValues_BindToControls();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       
    }
}
