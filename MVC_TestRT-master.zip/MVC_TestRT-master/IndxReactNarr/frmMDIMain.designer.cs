﻿namespace IndxReactNarr
{
    partial class frmMDIMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMDIMain));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.fileMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.loadTANtoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newTANToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.IndexingTSMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.logintoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logOffToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.listOfTANsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tANSearchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nUMSearchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.narrTANViewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.exporttoXMLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toBatchXMLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.validateMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.validateXMLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rSDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unicodesTSMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.validateNarrativesXMLTSMnuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.narrExpProcXmlTSMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.expProcFinalChecksTSMnuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.expProcTANRxnFindingsTSMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shipmentTANsFindAndReplaceTSripMnuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shipmentTANsPageInfoTSMnuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.tANStatusReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.multiShipmentsStatusReportTSMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userTANErrorLogReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.dailyStatusReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.monthlyReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.narShipmentStatusReportTSMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.userErrorsReportTSMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.errorSummaryReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.errorLogReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.shipmentTanNUMsForPDfExportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xmlDeliveryReportTSMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userProductivityReportTSMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.deliveryReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.batchMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.insertBatchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.narrativesReactionProtocolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.distributeBatchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.moveToBatchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.keywordSearchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generateMarkupFoldersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.taskMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.assignmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.taskModificationTSMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.advancedMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.extractRSNToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.duplicateTANToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.finalCheckToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.orgRefToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cTHReferenceTSMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cTHUpdateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.rSNFreeDictionaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.solventBoilingPointToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.series8500RegNosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clientFeedbackToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sendMailToUsersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.imageToPDFConvTSMnuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.reactionViewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userPrefsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.userAccountsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teamStructureTSMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.cASREACTInputManualToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.codingHintsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generalRemindersForConditionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.and8500sToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.protocToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rSNManualToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aminoAcidsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.structuringConvensionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.roleIndicatorsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.abstractingGuidelinesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.organicIndexingInputManualToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.titleGuideLinesTSMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stereochemGuidelinesTSMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.organicIndexingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inputManualToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.structuringConventionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.roleIndicatorsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.titleGuidelinesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stereoChemistryGuidelinesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.macroIndexingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inputManualToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.rEACTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inputManualToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.codingHintsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.generalRemaindersForConditionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.and8500ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.protocolUpdatesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aminoAcidsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.narrativesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.statusStrip_UInfo = new System.Windows.Forms.StatusStrip();
            this.tSStatusLbl = new System.Windows.Forms.ToolStripStatusLabel();
            this.tSStatusLbl_UName = new System.Windows.Forms.ToolStripStatusLabel();
            this.tSStatusLblRole = new System.Windows.Forms.ToolStripStatusLabel();
            this.tSStatusLblRoleName = new System.Windows.Forms.ToolStripStatusLabel();
            this.tSStatusLblApplication = new System.Windows.Forms.ToolStripStatusLabel();
            this.tSStatusLblAppName = new System.Windows.Forms.ToolStripStatusLabel();
            this.tSStatusLblAppModule = new System.Windows.Forms.ToolStripStatusLabel();
            this.tSStatusLblAppModuleName = new System.Windows.Forms.ToolStripStatusLabel();
            this.extractProcedureCountFromXmlTSMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            this.statusStrip_UInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileMenu,
            this.searchMenu,
            this.exportMenu,
            this.validateMenu,
            this.reportMenu,
            this.batchMenu,
            this.taskMenu,
            this.advancedMenu,
            this.userPrefsMenu,
            this.helpMenu,
            this.aboutMenu});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(994, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // fileMenu
            // 
            this.fileMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadTANtoolStripMenuItem,
            this.newTANToolStripMenuItem,
            this.IndexingTSMenuItem,
            this.toolStripSeparator3,
            this.logintoolStripMenuItem,
            this.logOffToolStripMenuItem,
            this.toolStripSeparator5,
            this.exitToolStripMenuItem});
            this.fileMenu.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder;
            this.fileMenu.Name = "fileMenu";
            this.fileMenu.Size = new System.Drawing.Size(42, 20);
            this.fileMenu.Text = "&File";
            // 
            // loadTANtoolStripMenuItem
            // 
            this.loadTANtoolStripMenuItem.Enabled = false;
            this.loadTANtoolStripMenuItem.Name = "loadTANtoolStripMenuItem";
            this.loadTANtoolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.loadTANtoolStripMenuItem.Text = "User Task";
            this.loadTANtoolStripMenuItem.Click += new System.EventHandler(this.loadTANtoolStripMenuItem_Click);
            // 
            // newTANToolStripMenuItem
            // 
            this.newTANToolStripMenuItem.Enabled = false;
            this.newTANToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("newTANToolStripMenuItem.Image")));
            this.newTANToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.newTANToolStripMenuItem.Name = "newTANToolStripMenuItem";
            this.newTANToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.newTANToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.newTANToolStripMenuItem.Text = "&New TAN";
            this.newTANToolStripMenuItem.Visible = false;
            // 
            // IndexingTSMenuItem
            // 
            this.IndexingTSMenuItem.Enabled = false;
            this.IndexingTSMenuItem.Name = "IndexingTSMenuItem";
            this.IndexingTSMenuItem.Size = new System.Drawing.Size(178, 22);
            this.IndexingTSMenuItem.Text = "Indexing Task";
            this.IndexingTSMenuItem.Click += new System.EventHandler(this.IndexingTSMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(175, 6);
            // 
            // logintoolStripMenuItem
            // 
            this.logintoolStripMenuItem.Name = "logintoolStripMenuItem";
            this.logintoolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.logintoolStripMenuItem.Text = "Login";
            this.logintoolStripMenuItem.Click += new System.EventHandler(this.logintoolStripMenuItem_Click);
            // 
            // logOffToolStripMenuItem
            // 
            this.logOffToolStripMenuItem.Name = "logOffToolStripMenuItem";
            this.logOffToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.logOffToolStripMenuItem.Text = "Log Off";
            this.logOffToolStripMenuItem.Click += new System.EventHandler(this.logOffToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(175, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.ExitToolsStripMenuItem_Click);
            // 
            // searchMenu
            // 
            this.searchMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listOfTANsToolStripMenuItem,
            this.tANSearchToolStripMenuItem,
            this.nUMSearchToolStripMenuItem,
            this.narrTANViewToolStripMenuItem});
            this.searchMenu.Enabled = false;
            this.searchMenu.Name = "searchMenu";
            this.searchMenu.Size = new System.Drawing.Size(63, 20);
            this.searchMenu.Text = "&Search";
            // 
            // listOfTANsToolStripMenuItem
            // 
            this.listOfTANsToolStripMenuItem.Enabled = false;
            this.listOfTANsToolStripMenuItem.Name = "listOfTANsToolStripMenuItem";
            this.listOfTANsToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.listOfTANsToolStripMenuItem.Text = "List of TANs";
            this.listOfTANsToolStripMenuItem.Click += new System.EventHandler(this.listOfTANsToolStripMenuItem1_Click);
            // 
            // tANSearchToolStripMenuItem
            // 
            this.tANSearchToolStripMenuItem.Enabled = false;
            this.tANSearchToolStripMenuItem.Name = "tANSearchToolStripMenuItem";
            this.tANSearchToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.tANSearchToolStripMenuItem.Text = "TAN Search";
            this.tANSearchToolStripMenuItem.Click += new System.EventHandler(this.tANSearchToolStripMenuItem_Click);
            // 
            // nUMSearchToolStripMenuItem
            // 
            this.nUMSearchToolStripMenuItem.Enabled = false;
            this.nUMSearchToolStripMenuItem.Name = "nUMSearchToolStripMenuItem";
            this.nUMSearchToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.nUMSearchToolStripMenuItem.Text = "NUM Search";
            this.nUMSearchToolStripMenuItem.Click += new System.EventHandler(this.nUMSearchToolStripMenuItem_Click);
            // 
            // narrTANViewToolStripMenuItem
            // 
            this.narrTANViewToolStripMenuItem.Name = "narrTANViewToolStripMenuItem";
            this.narrTANViewToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.narrTANViewToolStripMenuItem.Text = "Narr-TAN View";
            this.narrTANViewToolStripMenuItem.Click += new System.EventHandler(this.narrTANViewToolStripMenuItem_Click);
            // 
            // exportMenu
            // 
            this.exportMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exporttoXMLToolStripMenuItem,
            this.toBatchXMLToolStripMenuItem});
            this.exportMenu.Enabled = false;
            this.exportMenu.Name = "exportMenu";
            this.exportMenu.Size = new System.Drawing.Size(58, 20);
            this.exportMenu.Text = "&Export";
            // 
            // exporttoXMLToolStripMenuItem
            // 
            this.exporttoXMLToolStripMenuItem.Enabled = false;
            this.exporttoXMLToolStripMenuItem.Name = "exporttoXMLToolStripMenuItem";
            this.exporttoXMLToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.exporttoXMLToolStripMenuItem.Text = "To XML";
            this.exporttoXMLToolStripMenuItem.Click += new System.EventHandler(this.exporttoXMLToolStripMenuItem_Click);
            // 
            // toBatchXMLToolStripMenuItem
            // 
            this.toBatchXMLToolStripMenuItem.Enabled = false;
            this.toBatchXMLToolStripMenuItem.Name = "toBatchXMLToolStripMenuItem";
            this.toBatchXMLToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.toBatchXMLToolStripMenuItem.Text = "To Batch XML";
            this.toBatchXMLToolStripMenuItem.Click += new System.EventHandler(this.toBatchXMLToolStripMenuItem_Click);
            // 
            // validateMenu
            // 
            this.validateMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.validateXMLToolStripMenuItem,
            this.rSDToolStripMenuItem,
            this.unicodesTSMenuItem,
            this.validateNarrativesXMLTSMnuItem,
            this.narrExpProcXmlTSMenuItem,
            this.toolStripSeparator11,
            this.expProcFinalChecksTSMnuItem,
            this.expProcTANRxnFindingsTSMenuItem,
            this.shipmentTANsFindAndReplaceTSripMnuItem,
            this.shipmentTANsPageInfoTSMnuItem});
            this.validateMenu.Enabled = false;
            this.validateMenu.Name = "validateMenu";
            this.validateMenu.Size = new System.Drawing.Size(70, 20);
            this.validateMenu.Text = "&Validate";
            // 
            // validateXMLToolStripMenuItem
            // 
            this.validateXMLToolStripMenuItem.Enabled = false;
            this.validateXMLToolStripMenuItem.Name = "validateXMLToolStripMenuItem";
            this.validateXMLToolStripMenuItem.Size = new System.Drawing.Size(321, 22);
            this.validateXMLToolStripMenuItem.Text = "XML";
            this.validateXMLToolStripMenuItem.Click += new System.EventHandler(this.validateXMLToolStripMenuItem_Click);
            // 
            // rSDToolStripMenuItem
            // 
            this.rSDToolStripMenuItem.Enabled = false;
            this.rSDToolStripMenuItem.Name = "rSDToolStripMenuItem";
            this.rSDToolStripMenuItem.Size = new System.Drawing.Size(321, 22);
            this.rSDToolStripMenuItem.Text = "RSD";
            this.rSDToolStripMenuItem.Click += new System.EventHandler(this.rSDToolStripMenuItem_Click);
            // 
            // unicodesTSMenuItem
            // 
            this.unicodesTSMenuItem.Name = "unicodesTSMenuItem";
            this.unicodesTSMenuItem.Size = new System.Drawing.Size(321, 22);
            this.unicodesTSMenuItem.Text = "React Unicodes";
            this.unicodesTSMenuItem.Click += new System.EventHandler(this.unicodesTSMenuItem_Click);
            // 
            // validateNarrativesXMLTSMnuItem
            // 
            this.validateNarrativesXMLTSMnuItem.Name = "validateNarrativesXMLTSMnuItem";
            this.validateNarrativesXMLTSMnuItem.Size = new System.Drawing.Size(321, 22);
            this.validateNarrativesXMLTSMnuItem.Text = "Narratives Unicodes";
            this.validateNarrativesXMLTSMnuItem.Click += new System.EventHandler(this.validateNarrativesXMLTSMnuItem_Click);
            // 
            // narrExpProcXmlTSMenuItem
            // 
            this.narrExpProcXmlTSMenuItem.Name = "narrExpProcXmlTSMenuItem";
            this.narrExpProcXmlTSMenuItem.Size = new System.Drawing.Size(321, 22);
            this.narrExpProcXmlTSMenuItem.Text = "Narratives / Exp Procedures Xml";
            this.narrExpProcXmlTSMenuItem.Click += new System.EventHandler(this.narrExpProcXmlTSMenuItem_Click);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(318, 6);
            // 
            // expProcFinalChecksTSMnuItem
            // 
            this.expProcFinalChecksTSMnuItem.Name = "expProcFinalChecksTSMnuItem";
            this.expProcFinalChecksTSMnuItem.Size = new System.Drawing.Size(321, 22);
            this.expProcFinalChecksTSMnuItem.Text = "Exp Procedures Final Checks";
            this.expProcFinalChecksTSMnuItem.Click += new System.EventHandler(this.expProcFinalChecksTSMnuItem_Click);
            // 
            // expProcTANRxnFindingsTSMenuItem
            // 
            this.expProcTANRxnFindingsTSMenuItem.Name = "expProcTANRxnFindingsTSMenuItem";
            this.expProcTANRxnFindingsTSMenuItem.Size = new System.Drawing.Size(321, 22);
            this.expProcTANRxnFindingsTSMenuItem.Text = "Exp Procedures TAN - Reaction Findings";
            this.expProcTANRxnFindingsTSMenuItem.Click += new System.EventHandler(this.expProcTANRxnFindingsTSMenuItem_Click);
            // 
            // shipmentTANsFindAndReplaceTSripMnuItem
            // 
            this.shipmentTANsFindAndReplaceTSripMnuItem.Name = "shipmentTANsFindAndReplaceTSripMnuItem";
            this.shipmentTANsFindAndReplaceTSripMnuItem.Size = new System.Drawing.Size(321, 22);
            this.shipmentTANsFindAndReplaceTSripMnuItem.Text = "Shipment TANs - Find And Replace";
            this.shipmentTANsFindAndReplaceTSripMnuItem.Click += new System.EventHandler(this.shipmentTANsFindAndReplaceTSripMnuItem_Click);
            // 
            // shipmentTANsPageInfoTSMnuItem
            // 
            this.shipmentTANsPageInfoTSMnuItem.Name = "shipmentTANsPageInfoTSMnuItem";
            this.shipmentTANsPageInfoTSMnuItem.Size = new System.Drawing.Size(321, 22);
            this.shipmentTANsPageInfoTSMnuItem.Text = "Shipment TANs - Page Information";
            this.shipmentTANsPageInfoTSMnuItem.Click += new System.EventHandler(this.shipmentTANsPageInfoTSMnuItem_Click);
            // 
            // reportMenu
            // 
            this.reportMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tANStatusReportToolStripMenuItem,
            this.multiShipmentsStatusReportTSMenuItem,
            this.userTANErrorLogReportToolStripMenuItem,
            this.toolStripSeparator4,
            this.dailyStatusReportToolStripMenuItem,
            this.monthlyReportToolStripMenuItem,
            this.toolStripSeparator6,
            this.narShipmentStatusReportTSMenuItem1,
            this.toolStripSeparator8,
            this.userErrorsReportTSMenuItem,
            this.errorSummaryReportToolStripMenuItem,
            this.errorLogReportToolStripMenuItem,
            this.toolStripSeparator7,
            this.shipmentTanNUMsForPDfExportToolStripMenuItem,
            this.xmlDeliveryReportTSMenuItem,
            this.userProductivityReportTSMenuItem,
            this.toolStripSeparator12,
            this.deliveryReportToolStripMenuItem});
            this.reportMenu.Enabled = false;
            this.reportMenu.Name = "reportMenu";
            this.reportMenu.Size = new System.Drawing.Size(68, 20);
            this.reportMenu.Text = "&Reports";
            // 
            // tANStatusReportToolStripMenuItem
            // 
            this.tANStatusReportToolStripMenuItem.Enabled = false;
            this.tANStatusReportToolStripMenuItem.Name = "tANStatusReportToolStripMenuItem";
            this.tANStatusReportToolStripMenuItem.Size = new System.Drawing.Size(344, 22);
            this.tANStatusReportToolStripMenuItem.Text = "Shipment TANs Status Report";
            this.tANStatusReportToolStripMenuItem.Click += new System.EventHandler(this.tANStatusReportToolStripMenuItem_Click);
            // 
            // multiShipmentsStatusReportTSMenuItem
            // 
            this.multiShipmentsStatusReportTSMenuItem.Enabled = false;
            this.multiShipmentsStatusReportTSMenuItem.Name = "multiShipmentsStatusReportTSMenuItem";
            this.multiShipmentsStatusReportTSMenuItem.Size = new System.Drawing.Size(344, 22);
            this.multiShipmentsStatusReportTSMenuItem.Text = "Multiple Shipments Status Report";
            this.multiShipmentsStatusReportTSMenuItem.Click += new System.EventHandler(this.multiShipmentsStatusReportTSMenuItem_Click);
            // 
            // userTANErrorLogReportToolStripMenuItem
            // 
            this.userTANErrorLogReportToolStripMenuItem.Enabled = false;
            this.userTANErrorLogReportToolStripMenuItem.Name = "userTANErrorLogReportToolStripMenuItem";
            this.userTANErrorLogReportToolStripMenuItem.Size = new System.Drawing.Size(344, 22);
            this.userTANErrorLogReportToolStripMenuItem.Text = "User-TAN Error Log Report";
            this.userTANErrorLogReportToolStripMenuItem.Click += new System.EventHandler(this.userTANErrorLogReportToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(341, 6);
            // 
            // dailyStatusReportToolStripMenuItem
            // 
            this.dailyStatusReportToolStripMenuItem.Enabled = false;
            this.dailyStatusReportToolStripMenuItem.Name = "dailyStatusReportToolStripMenuItem";
            this.dailyStatusReportToolStripMenuItem.Size = new System.Drawing.Size(344, 22);
            this.dailyStatusReportToolStripMenuItem.Text = "Daily Status Report";
            this.dailyStatusReportToolStripMenuItem.Click += new System.EventHandler(this.dailyStatusReportToolStripMenuItem_Click);
            // 
            // monthlyReportToolStripMenuItem
            // 
            this.monthlyReportToolStripMenuItem.Enabled = false;
            this.monthlyReportToolStripMenuItem.Name = "monthlyReportToolStripMenuItem";
            this.monthlyReportToolStripMenuItem.Size = new System.Drawing.Size(344, 22);
            this.monthlyReportToolStripMenuItem.Text = "Monthly Status Report";
            this.monthlyReportToolStripMenuItem.Click += new System.EventHandler(this.monthlyReportToolStripMenuItem_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(341, 6);
            // 
            // narShipmentStatusReportTSMenuItem1
            // 
            this.narShipmentStatusReportTSMenuItem1.Name = "narShipmentStatusReportTSMenuItem1";
            this.narShipmentStatusReportTSMenuItem1.Size = new System.Drawing.Size(344, 22);
            this.narShipmentStatusReportTSMenuItem1.Text = "Narratives/ExpProc-Shipments Status Report";
            this.narShipmentStatusReportTSMenuItem1.Click += new System.EventHandler(this.narShipmentStatusReportTSMenuItem1_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(341, 6);
            // 
            // userErrorsReportTSMenuItem
            // 
            this.userErrorsReportTSMenuItem.Name = "userErrorsReportTSMenuItem";
            this.userErrorsReportTSMenuItem.Size = new System.Drawing.Size(344, 22);
            this.userErrorsReportTSMenuItem.Text = "User Errors Report";
            this.userErrorsReportTSMenuItem.Click += new System.EventHandler(this.userErrorsReportTSMenuItem_Click);
            // 
            // errorSummaryReportToolStripMenuItem
            // 
            this.errorSummaryReportToolStripMenuItem.Enabled = false;
            this.errorSummaryReportToolStripMenuItem.Name = "errorSummaryReportToolStripMenuItem";
            this.errorSummaryReportToolStripMenuItem.Size = new System.Drawing.Size(344, 22);
            this.errorSummaryReportToolStripMenuItem.Text = "Error Summary Report";
            this.errorSummaryReportToolStripMenuItem.Click += new System.EventHandler(this.errorSummaryReportToolStripMenuItem_Click);
            // 
            // errorLogReportToolStripMenuItem
            // 
            this.errorLogReportToolStripMenuItem.Enabled = false;
            this.errorLogReportToolStripMenuItem.Name = "errorLogReportToolStripMenuItem";
            this.errorLogReportToolStripMenuItem.Size = new System.Drawing.Size(344, 22);
            this.errorLogReportToolStripMenuItem.Text = "Error Log Report";
            this.errorLogReportToolStripMenuItem.Click += new System.EventHandler(this.errorLogReportToolStripMenuItem_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(341, 6);
            // 
            // shipmentTanNUMsForPDfExportToolStripMenuItem
            // 
            this.shipmentTanNUMsForPDfExportToolStripMenuItem.Enabled = false;
            this.shipmentTanNUMsForPDfExportToolStripMenuItem.Name = "shipmentTanNUMsForPDfExportToolStripMenuItem";
            this.shipmentTanNUMsForPDfExportToolStripMenuItem.Size = new System.Drawing.Size(344, 22);
            this.shipmentTanNUMsForPDfExportToolStripMenuItem.Text = "Shipment TANs - NUMs for  Pdf Export";
            this.shipmentTanNUMsForPDfExportToolStripMenuItem.Visible = false;
            this.shipmentTanNUMsForPDfExportToolStripMenuItem.Click += new System.EventHandler(this.cGMTANSForPDfExportToolStripMenuItem_Click);
            // 
            // xmlDeliveryReportTSMenuItem
            // 
            this.xmlDeliveryReportTSMenuItem.Name = "xmlDeliveryReportTSMenuItem";
            this.xmlDeliveryReportTSMenuItem.Size = new System.Drawing.Size(344, 22);
            this.xmlDeliveryReportTSMenuItem.Text = "Xml Delivery Report";
            this.xmlDeliveryReportTSMenuItem.Click += new System.EventHandler(this.xmlDeliveryReportTSMenuItem_Click);
            // 
            // userProductivityReportTSMenuItem
            // 
            this.userProductivityReportTSMenuItem.Enabled = false;
            this.userProductivityReportTSMenuItem.Name = "userProductivityReportTSMenuItem";
            this.userProductivityReportTSMenuItem.Size = new System.Drawing.Size(344, 22);
            this.userProductivityReportTSMenuItem.Text = "User Productivity Report";
            this.userProductivityReportTSMenuItem.Click += new System.EventHandler(this.userProductivityReportTSMenuItem_Click);
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(341, 6);
            // 
            // deliveryReportToolStripMenuItem
            // 
            this.deliveryReportToolStripMenuItem.Name = "deliveryReportToolStripMenuItem";
            this.deliveryReportToolStripMenuItem.Size = new System.Drawing.Size(344, 22);
            this.deliveryReportToolStripMenuItem.Text = "Delivery Report";
            this.deliveryReportToolStripMenuItem.Click += new System.EventHandler(this.deliveryReportToolStripMenuItem_Click);
            // 
            // batchMenu
            // 
            this.batchMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.insertBatchToolStripMenuItem,
            this.distributeBatchToolStripMenuItem,
            this.moveToBatchToolStripMenuItem,
            this.keywordSearchToolStripMenuItem,
            this.generateMarkupFoldersToolStripMenuItem});
            this.batchMenu.Enabled = false;
            this.batchMenu.Name = "batchMenu";
            this.batchMenu.Size = new System.Drawing.Size(76, 20);
            this.batchMenu.Text = "&Shipment";
            // 
            // insertBatchToolStripMenuItem
            // 
            this.insertBatchToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.narrativesReactionProtocolsToolStripMenuItem});
            this.insertBatchToolStripMenuItem.Enabled = false;
            this.insertBatchToolStripMenuItem.Name = "insertBatchToolStripMenuItem";
            this.insertBatchToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.insertBatchToolStripMenuItem.Text = "Insert Shipment";
            this.insertBatchToolStripMenuItem.Click += new System.EventHandler(this.insertBatchToolStripMenuItem_Click);
            // 
            // narrativesReactionProtocolsToolStripMenuItem
            // 
            this.narrativesReactionProtocolsToolStripMenuItem.Name = "narrativesReactionProtocolsToolStripMenuItem";
            this.narrativesReactionProtocolsToolStripMenuItem.Size = new System.Drawing.Size(255, 22);
            this.narrativesReactionProtocolsToolStripMenuItem.Text = "Narratives Reaction Protocols";
            this.narrativesReactionProtocolsToolStripMenuItem.Click += new System.EventHandler(this.narrativesReactionProtocolsToolStripMenuItem_Click);
            // 
            // distributeBatchToolStripMenuItem
            // 
            this.distributeBatchToolStripMenuItem.Enabled = false;
            this.distributeBatchToolStripMenuItem.Name = "distributeBatchToolStripMenuItem";
            this.distributeBatchToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.distributeBatchToolStripMenuItem.Text = "Distribute Batch";
            this.distributeBatchToolStripMenuItem.Click += new System.EventHandler(this.distributeBatchToolStripMenuItem_Click);
            // 
            // moveToBatchToolStripMenuItem
            // 
            this.moveToBatchToolStripMenuItem.Enabled = false;
            this.moveToBatchToolStripMenuItem.Name = "moveToBatchToolStripMenuItem";
            this.moveToBatchToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.moveToBatchToolStripMenuItem.Text = "Move To Batch";
            this.moveToBatchToolStripMenuItem.Click += new System.EventHandler(this.moveToBatchToolStripMenuItem_Click);
            // 
            // keywordSearchToolStripMenuItem
            // 
            this.keywordSearchToolStripMenuItem.Enabled = false;
            this.keywordSearchToolStripMenuItem.Name = "keywordSearchToolStripMenuItem";
            this.keywordSearchToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.keywordSearchToolStripMenuItem.Text = "Keyword Search";
            this.keywordSearchToolStripMenuItem.Click += new System.EventHandler(this.keywordSearchToolStripMenuItem_Click);
            // 
            // generateMarkupFoldersToolStripMenuItem
            // 
            this.generateMarkupFoldersToolStripMenuItem.Name = "generateMarkupFoldersToolStripMenuItem";
            this.generateMarkupFoldersToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.generateMarkupFoldersToolStripMenuItem.Text = "Generate Markup Folders";
            this.generateMarkupFoldersToolStripMenuItem.Click += new System.EventHandler(this.generateMarkupFoldersToolStripMenuItem_Click);
            // 
            // taskMenu
            // 
            this.taskMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.assignmentToolStripMenuItem,
            this.taskModificationTSMenuItem});
            this.taskMenu.Enabled = false;
            this.taskMenu.Name = "taskMenu";
            this.taskMenu.Size = new System.Drawing.Size(51, 20);
            this.taskMenu.Text = "&Task";
            // 
            // assignmentToolStripMenuItem
            // 
            this.assignmentToolStripMenuItem.Enabled = false;
            this.assignmentToolStripMenuItem.Name = "assignmentToolStripMenuItem";
            this.assignmentToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.assignmentToolStripMenuItem.Text = "Assignment";
            this.assignmentToolStripMenuItem.Click += new System.EventHandler(this.assignmentToolStripMenuItem_Click);
            // 
            // taskModificationTSMenuItem
            // 
            this.taskModificationTSMenuItem.Name = "taskModificationTSMenuItem";
            this.taskModificationTSMenuItem.Size = new System.Drawing.Size(226, 22);
            this.taskModificationTSMenuItem.Text = "Cancellation/Modification";
            this.taskModificationTSMenuItem.Click += new System.EventHandler(this.taskModificationTSMenuItem_Click);
            // 
            // advancedMenu
            // 
            this.advancedMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.extractRSNToolStripMenuItem,
            this.duplicateTANToolStripMenuItem,
            this.finalCheckToolStripMenuItem,
            this.toolStripSeparator9,
            this.orgRefToolStripMenuItem,
            this.cTHReferenceTSMenuItem,
            this.cTHUpdateToolStripMenuItem,
            this.toolStripSeparator10,
            this.rSNFreeDictionaryToolStripMenuItem,
            this.solventBoilingPointToolStripMenuItem,
            this.series8500RegNosToolStripMenuItem,
            this.clientFeedbackToolStripMenuItem,
            this.sendMailToUsersToolStripMenuItem,
            this.imageToPDFConvTSMnuItem,
            this.toolStripSeparator2,
            this.reactionViewToolStripMenuItem,
            this.extractProcedureCountFromXmlTSMenuItem});
            this.advancedMenu.Enabled = false;
            this.advancedMenu.Name = "advancedMenu";
            this.advancedMenu.Size = new System.Drawing.Size(82, 20);
            this.advancedMenu.Text = "A&dvanced";
            // 
            // extractRSNToolStripMenuItem
            // 
            this.extractRSNToolStripMenuItem.Enabled = false;
            this.extractRSNToolStripMenuItem.Name = "extractRSNToolStripMenuItem";
            this.extractRSNToolStripMenuItem.Size = new System.Drawing.Size(278, 22);
            this.extractRSNToolStripMenuItem.Text = "Extract RSN";
            this.extractRSNToolStripMenuItem.Click += new System.EventHandler(this.extractRSNToolStripMenuItem1_Click);
            // 
            // duplicateTANToolStripMenuItem
            // 
            this.duplicateTANToolStripMenuItem.Enabled = false;
            this.duplicateTANToolStripMenuItem.Name = "duplicateTANToolStripMenuItem";
            this.duplicateTANToolStripMenuItem.Size = new System.Drawing.Size(278, 22);
            this.duplicateTANToolStripMenuItem.Text = "Duplicate TAN";
            this.duplicateTANToolStripMenuItem.Click += new System.EventHandler(this.duplicateTANToolStripMenuItem_Click);
            // 
            // finalCheckToolStripMenuItem
            // 
            this.finalCheckToolStripMenuItem.Enabled = false;
            this.finalCheckToolStripMenuItem.Name = "finalCheckToolStripMenuItem";
            this.finalCheckToolStripMenuItem.Size = new System.Drawing.Size(278, 22);
            this.finalCheckToolStripMenuItem.Text = "Batch Final Check";
            this.finalCheckToolStripMenuItem.Click += new System.EventHandler(this.finalCheckToolStripMenuItem_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(275, 6);
            // 
            // orgRefToolStripMenuItem
            // 
            this.orgRefToolStripMenuItem.Enabled = false;
            this.orgRefToolStripMenuItem.Name = "orgRefToolStripMenuItem";
            this.orgRefToolStripMenuItem.Size = new System.Drawing.Size(278, 22);
            this.orgRefToolStripMenuItem.Text = "OrgRef Reference";
            this.orgRefToolStripMenuItem.Click += new System.EventHandler(this.orgRefToolStripMenuItem_Click);
            // 
            // cTHReferenceTSMenuItem
            // 
            this.cTHReferenceTSMenuItem.Enabled = false;
            this.cTHReferenceTSMenuItem.Name = "cTHReferenceTSMenuItem";
            this.cTHReferenceTSMenuItem.Size = new System.Drawing.Size(278, 22);
            this.cTHReferenceTSMenuItem.Text = "CTH Reference";
            this.cTHReferenceTSMenuItem.Click += new System.EventHandler(this.cTHReferenceTSMenuItem_Click);
            // 
            // cTHUpdateToolStripMenuItem
            // 
            this.cTHUpdateToolStripMenuItem.Name = "cTHUpdateToolStripMenuItem";
            this.cTHUpdateToolStripMenuItem.Size = new System.Drawing.Size(278, 22);
            this.cTHUpdateToolStripMenuItem.Text = "CTH Update";
            this.cTHUpdateToolStripMenuItem.Click += new System.EventHandler(this.cTHUpdateToolStripMenuItem_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(275, 6);
            // 
            // rSNFreeDictionaryToolStripMenuItem
            // 
            this.rSNFreeDictionaryToolStripMenuItem.Enabled = false;
            this.rSNFreeDictionaryToolStripMenuItem.Name = "rSNFreeDictionaryToolStripMenuItem";
            this.rSNFreeDictionaryToolStripMenuItem.Size = new System.Drawing.Size(278, 22);
            this.rSNFreeDictionaryToolStripMenuItem.Text = "RSN Free Dictionary";
            this.rSNFreeDictionaryToolStripMenuItem.Click += new System.EventHandler(this.rSNFreeDictionaryToolStripMenuItem_Click);
            // 
            // solventBoilingPointToolStripMenuItem
            // 
            this.solventBoilingPointToolStripMenuItem.Enabled = false;
            this.solventBoilingPointToolStripMenuItem.Name = "solventBoilingPointToolStripMenuItem";
            this.solventBoilingPointToolStripMenuItem.Size = new System.Drawing.Size(278, 22);
            this.solventBoilingPointToolStripMenuItem.Text = "Solvent Boiling Point";
            this.solventBoilingPointToolStripMenuItem.Click += new System.EventHandler(this.solventBoilingPointToolStripMenuItem_Click);
            // 
            // series8500RegNosToolStripMenuItem
            // 
            this.series8500RegNosToolStripMenuItem.Enabled = false;
            this.series8500RegNosToolStripMenuItem.Name = "series8500RegNosToolStripMenuItem";
            this.series8500RegNosToolStripMenuItem.Size = new System.Drawing.Size(278, 22);
            this.series8500RegNosToolStripMenuItem.Text = "Series 8500 Reg Nos";
            this.series8500RegNosToolStripMenuItem.Click += new System.EventHandler(this.series8500RegNosToolStripMenuItem_Click);
            // 
            // clientFeedbackToolStripMenuItem
            // 
            this.clientFeedbackToolStripMenuItem.Enabled = false;
            this.clientFeedbackToolStripMenuItem.Name = "clientFeedbackToolStripMenuItem";
            this.clientFeedbackToolStripMenuItem.Size = new System.Drawing.Size(278, 22);
            this.clientFeedbackToolStripMenuItem.Text = "Client Feedback";
            this.clientFeedbackToolStripMenuItem.Click += new System.EventHandler(this.clientFeedbackToolStripMenuItem_Click);
            // 
            // sendMailToUsersToolStripMenuItem
            // 
            this.sendMailToUsersToolStripMenuItem.Enabled = false;
            this.sendMailToUsersToolStripMenuItem.Name = "sendMailToUsersToolStripMenuItem";
            this.sendMailToUsersToolStripMenuItem.Size = new System.Drawing.Size(278, 22);
            this.sendMailToUsersToolStripMenuItem.Text = "Send Mail to Users";
            this.sendMailToUsersToolStripMenuItem.Click += new System.EventHandler(this.sendMailToUsersToolStripMenuItem_Click);
            // 
            // imageToPDFConvTSMnuItem
            // 
            this.imageToPDFConvTSMnuItem.Enabled = false;
            this.imageToPDFConvTSMnuItem.Name = "imageToPDFConvTSMnuItem";
            this.imageToPDFConvTSMnuItem.Size = new System.Drawing.Size(278, 22);
            this.imageToPDFConvTSMnuItem.Text = "Image To PDF Conversion";
            this.imageToPDFConvTSMnuItem.Click += new System.EventHandler(this.imageToPDFConvTSMnuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(275, 6);
            // 
            // reactionViewToolStripMenuItem
            // 
            this.reactionViewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.formToolStripMenuItem,
            this.panelToolStripMenuItem});
            this.reactionViewToolStripMenuItem.Name = "reactionViewToolStripMenuItem";
            this.reactionViewToolStripMenuItem.Size = new System.Drawing.Size(278, 22);
            this.reactionViewToolStripMenuItem.Text = "Reaction View";
            // 
            // formToolStripMenuItem
            // 
            this.formToolStripMenuItem.Name = "formToolStripMenuItem";
            this.formToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.formToolStripMenuItem.Text = "Form";
            this.formToolStripMenuItem.Click += new System.EventHandler(this.formToolStripMenuItem_Click);
            // 
            // panelToolStripMenuItem
            // 
            this.panelToolStripMenuItem.Name = "panelToolStripMenuItem";
            this.panelToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.panelToolStripMenuItem.Text = "Panel";
            this.panelToolStripMenuItem.Click += new System.EventHandler(this.panelToolStripMenuItem_Click);
            // 
            // userPrefsMenu
            // 
            this.userPrefsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.userAccountsToolStripMenuItem,
            this.teamStructureTSMenuItem});
            this.userPrefsMenu.Enabled = false;
            this.userPrefsMenu.Name = "userPrefsMenu";
            this.userPrefsMenu.Size = new System.Drawing.Size(83, 20);
            this.userPrefsMenu.Text = "&User Prefs";
            // 
            // userAccountsToolStripMenuItem
            // 
            this.userAccountsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.createToolStripMenuItem});
            this.userAccountsToolStripMenuItem.Enabled = false;
            this.userAccountsToolStripMenuItem.Name = "userAccountsToolStripMenuItem";
            this.userAccountsToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.userAccountsToolStripMenuItem.Text = "User Accounts";
            // 
            // createToolStripMenuItem
            // 
            this.createToolStripMenuItem.Name = "createToolStripMenuItem";
            this.createToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.createToolStripMenuItem.Text = "Create";
            this.createToolStripMenuItem.Click += new System.EventHandler(this.createToolStripMenuItem_Click);
            // 
            // teamStructureTSMenuItem
            // 
            this.teamStructureTSMenuItem.Name = "teamStructureTSMenuItem";
            this.teamStructureTSMenuItem.Size = new System.Drawing.Size(167, 22);
            this.teamStructureTSMenuItem.Text = "Team Structure";
            this.teamStructureTSMenuItem.Click += new System.EventHandler(this.teamStructureTSMenuItem_Click);
            // 
            // helpMenu
            // 
            this.helpMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cASREACTInputManualToolStripMenuItem1,
            this.codingHintsToolStripMenuItem,
            this.generalRemindersForConditionsToolStripMenuItem,
            this.and8500sToolStripMenuItem,
            this.protocToolStripMenuItem,
            this.rSNManualToolStripMenuItem,
            this.aminoAcidsToolStripMenuItem,
            this.toolStripSeparator1,
            this.structuringConvensionsToolStripMenuItem,
            this.roleIndicatorsToolStripMenuItem,
            this.abstractingGuidelinesToolStripMenuItem,
            this.organicIndexingInputManualToolStripMenuItem,
            this.titleGuideLinesTSMenuItem,
            this.stereochemGuidelinesTSMenuItem,
            this.organicIndexingToolStripMenuItem,
            this.macroIndexingToolStripMenuItem,
            this.rEACTToolStripMenuItem,
            this.narrativesToolStripMenuItem});
            this.helpMenu.Name = "helpMenu";
            this.helpMenu.Size = new System.Drawing.Size(49, 20);
            this.helpMenu.Text = "&Help";
            // 
            // cASREACTInputManualToolStripMenuItem1
            // 
            this.cASREACTInputManualToolStripMenuItem1.Name = "cASREACTInputManualToolStripMenuItem1";
            this.cASREACTInputManualToolStripMenuItem1.Size = new System.Drawing.Size(271, 22);
            this.cASREACTInputManualToolStripMenuItem1.Text = "Input Manual";
            this.cASREACTInputManualToolStripMenuItem1.Click += new System.EventHandler(this.cASREACTInputManualToolStripMenuItem1_Click);
            // 
            // codingHintsToolStripMenuItem
            // 
            this.codingHintsToolStripMenuItem.Name = "codingHintsToolStripMenuItem";
            this.codingHintsToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.codingHintsToolStripMenuItem.Text = "Coding Hints";
            this.codingHintsToolStripMenuItem.Click += new System.EventHandler(this.codingHintsToolStripMenuItem_Click);
            // 
            // generalRemindersForConditionsToolStripMenuItem
            // 
            this.generalRemindersForConditionsToolStripMenuItem.Name = "generalRemindersForConditionsToolStripMenuItem";
            this.generalRemindersForConditionsToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.generalRemindersForConditionsToolStripMenuItem.Text = "General reminders for Conditions";
            this.generalRemindersForConditionsToolStripMenuItem.Click += new System.EventHandler(this.generalRemindersForConditionsToolStripMenuItem_Click);
            // 
            // and8500sToolStripMenuItem
            // 
            this.and8500sToolStripMenuItem.Name = "and8500sToolStripMenuItem";
            this.and8500sToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.and8500sToolStripMenuItem.Text = "8000 and 8500s";
            this.and8500sToolStripMenuItem.Click += new System.EventHandler(this.and8500sToolStripMenuItem_Click);
            // 
            // protocToolStripMenuItem
            // 
            this.protocToolStripMenuItem.Name = "protocToolStripMenuItem";
            this.protocToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.protocToolStripMenuItem.Text = "Protocol Updates";
            this.protocToolStripMenuItem.Click += new System.EventHandler(this.protocToolStripMenuItem_Click);
            // 
            // rSNManualToolStripMenuItem
            // 
            this.rSNManualToolStripMenuItem.Name = "rSNManualToolStripMenuItem";
            this.rSNManualToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.rSNManualToolStripMenuItem.Text = "RSN Manual";
            this.rSNManualToolStripMenuItem.Click += new System.EventHandler(this.rSNManualToolStripMenuItem_Click);
            // 
            // aminoAcidsToolStripMenuItem
            // 
            this.aminoAcidsToolStripMenuItem.Name = "aminoAcidsToolStripMenuItem";
            this.aminoAcidsToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.aminoAcidsToolStripMenuItem.Text = "Amino Acids";
            this.aminoAcidsToolStripMenuItem.Click += new System.EventHandler(this.aminoAcidsToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(268, 6);
            // 
            // structuringConvensionsToolStripMenuItem
            // 
            this.structuringConvensionsToolStripMenuItem.Name = "structuringConvensionsToolStripMenuItem";
            this.structuringConvensionsToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.structuringConvensionsToolStripMenuItem.Text = "Structuring Convensions";
            this.structuringConvensionsToolStripMenuItem.Click += new System.EventHandler(this.structuringConvensionsToolStripMenuItem_Click);
            // 
            // roleIndicatorsToolStripMenuItem
            // 
            this.roleIndicatorsToolStripMenuItem.Name = "roleIndicatorsToolStripMenuItem";
            this.roleIndicatorsToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.roleIndicatorsToolStripMenuItem.Text = "Role Indicators";
            this.roleIndicatorsToolStripMenuItem.Click += new System.EventHandler(this.roleIndicatorsToolStripMenuItem_Click);
            // 
            // abstractingGuidelinesToolStripMenuItem
            // 
            this.abstractingGuidelinesToolStripMenuItem.Name = "abstractingGuidelinesToolStripMenuItem";
            this.abstractingGuidelinesToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.abstractingGuidelinesToolStripMenuItem.Text = "Abstracting Guidelines";
            this.abstractingGuidelinesToolStripMenuItem.Click += new System.EventHandler(this.abstractingGuidelinesToolStripMenuItem_Click);
            // 
            // organicIndexingInputManualToolStripMenuItem
            // 
            this.organicIndexingInputManualToolStripMenuItem.Name = "organicIndexingInputManualToolStripMenuItem";
            this.organicIndexingInputManualToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.organicIndexingInputManualToolStripMenuItem.Text = "Organic Indexing Input Manual";
            this.organicIndexingInputManualToolStripMenuItem.Click += new System.EventHandler(this.organicIndexingInputManualToolStripMenuItem_Click);
            // 
            // titleGuideLinesTSMenuItem
            // 
            this.titleGuideLinesTSMenuItem.Name = "titleGuideLinesTSMenuItem";
            this.titleGuideLinesTSMenuItem.Size = new System.Drawing.Size(271, 22);
            this.titleGuideLinesTSMenuItem.Text = "Title Guidelines";
            this.titleGuideLinesTSMenuItem.Click += new System.EventHandler(this.titleGuideLinesTSMenuItem_Click);
            // 
            // stereochemGuidelinesTSMenuItem
            // 
            this.stereochemGuidelinesTSMenuItem.Name = "stereochemGuidelinesTSMenuItem";
            this.stereochemGuidelinesTSMenuItem.Size = new System.Drawing.Size(271, 22);
            this.stereochemGuidelinesTSMenuItem.Text = "Stereochemistry Guidelines";
            this.stereochemGuidelinesTSMenuItem.Click += new System.EventHandler(this.stereochemGuidelinesTSMenuItem_Click);
            // 
            // organicIndexingToolStripMenuItem
            // 
            this.organicIndexingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inputManualToolStripMenuItem,
            this.structuringConventionsToolStripMenuItem,
            this.roleIndicatorsToolStripMenuItem1,
            this.titleGuidelinesToolStripMenuItem,
            this.stereoChemistryGuidelinesToolStripMenuItem});
            this.organicIndexingToolStripMenuItem.Name = "organicIndexingToolStripMenuItem";
            this.organicIndexingToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.organicIndexingToolStripMenuItem.Text = "Organic Indexing";
            // 
            // inputManualToolStripMenuItem
            // 
            this.inputManualToolStripMenuItem.Name = "inputManualToolStripMenuItem";
            this.inputManualToolStripMenuItem.Size = new System.Drawing.Size(242, 22);
            this.inputManualToolStripMenuItem.Text = "Input Manual";
            // 
            // structuringConventionsToolStripMenuItem
            // 
            this.structuringConventionsToolStripMenuItem.Name = "structuringConventionsToolStripMenuItem";
            this.structuringConventionsToolStripMenuItem.Size = new System.Drawing.Size(242, 22);
            this.structuringConventionsToolStripMenuItem.Text = "Structuring Conventions";
            // 
            // roleIndicatorsToolStripMenuItem1
            // 
            this.roleIndicatorsToolStripMenuItem1.Name = "roleIndicatorsToolStripMenuItem1";
            this.roleIndicatorsToolStripMenuItem1.Size = new System.Drawing.Size(242, 22);
            this.roleIndicatorsToolStripMenuItem1.Text = "Role Indicators";
            // 
            // titleGuidelinesToolStripMenuItem
            // 
            this.titleGuidelinesToolStripMenuItem.Name = "titleGuidelinesToolStripMenuItem";
            this.titleGuidelinesToolStripMenuItem.Size = new System.Drawing.Size(242, 22);
            this.titleGuidelinesToolStripMenuItem.Text = "Title Guidelines";
            // 
            // stereoChemistryGuidelinesToolStripMenuItem
            // 
            this.stereoChemistryGuidelinesToolStripMenuItem.Name = "stereoChemistryGuidelinesToolStripMenuItem";
            this.stereoChemistryGuidelinesToolStripMenuItem.Size = new System.Drawing.Size(242, 22);
            this.stereoChemistryGuidelinesToolStripMenuItem.Text = "StereoChemistry Guidelines";
            // 
            // macroIndexingToolStripMenuItem
            // 
            this.macroIndexingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inputManualToolStripMenuItem1});
            this.macroIndexingToolStripMenuItem.Name = "macroIndexingToolStripMenuItem";
            this.macroIndexingToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.macroIndexingToolStripMenuItem.Text = "Macro Indexing";
            // 
            // inputManualToolStripMenuItem1
            // 
            this.inputManualToolStripMenuItem1.Name = "inputManualToolStripMenuItem1";
            this.inputManualToolStripMenuItem1.Size = new System.Drawing.Size(151, 22);
            this.inputManualToolStripMenuItem1.Text = "Input Manual";
            // 
            // rEACTToolStripMenuItem
            // 
            this.rEACTToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inputManualToolStripMenuItem2,
            this.codingHintsToolStripMenuItem1,
            this.generalRemaindersForConditionsToolStripMenuItem,
            this.and8500ToolStripMenuItem,
            this.protocolUpdatesToolStripMenuItem,
            this.aminoAcidsToolStripMenuItem1});
            this.rEACTToolStripMenuItem.Name = "rEACTToolStripMenuItem";
            this.rEACTToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.rEACTToolStripMenuItem.Text = "REACT";
            // 
            // inputManualToolStripMenuItem2
            // 
            this.inputManualToolStripMenuItem2.Name = "inputManualToolStripMenuItem2";
            this.inputManualToolStripMenuItem2.Size = new System.Drawing.Size(279, 22);
            this.inputManualToolStripMenuItem2.Text = "Input Manual";
            // 
            // codingHintsToolStripMenuItem1
            // 
            this.codingHintsToolStripMenuItem1.Name = "codingHintsToolStripMenuItem1";
            this.codingHintsToolStripMenuItem1.Size = new System.Drawing.Size(279, 22);
            this.codingHintsToolStripMenuItem1.Text = "Coding Hints";
            // 
            // generalRemaindersForConditionsToolStripMenuItem
            // 
            this.generalRemaindersForConditionsToolStripMenuItem.Name = "generalRemaindersForConditionsToolStripMenuItem";
            this.generalRemaindersForConditionsToolStripMenuItem.Size = new System.Drawing.Size(279, 22);
            this.generalRemaindersForConditionsToolStripMenuItem.Text = "General remainders for Conditions";
            // 
            // and8500ToolStripMenuItem
            // 
            this.and8500ToolStripMenuItem.Name = "and8500ToolStripMenuItem";
            this.and8500ToolStripMenuItem.Size = new System.Drawing.Size(279, 22);
            this.and8500ToolStripMenuItem.Text = "8000 and 8500";
            // 
            // protocolUpdatesToolStripMenuItem
            // 
            this.protocolUpdatesToolStripMenuItem.Name = "protocolUpdatesToolStripMenuItem";
            this.protocolUpdatesToolStripMenuItem.Size = new System.Drawing.Size(279, 22);
            this.protocolUpdatesToolStripMenuItem.Text = "Protocol Updates";
            // 
            // aminoAcidsToolStripMenuItem1
            // 
            this.aminoAcidsToolStripMenuItem1.Name = "aminoAcidsToolStripMenuItem1";
            this.aminoAcidsToolStripMenuItem1.Size = new System.Drawing.Size(279, 22);
            this.aminoAcidsToolStripMenuItem1.Text = "Amino Acids";
            // 
            // narrativesToolStripMenuItem
            // 
            this.narrativesToolStripMenuItem.Name = "narrativesToolStripMenuItem";
            this.narrativesToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.narrativesToolStripMenuItem.Text = "Narratives";
            // 
            // aboutMenu
            // 
            this.aboutMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.aboutMenu.Name = "aboutMenu";
            this.aboutMenu.Size = new System.Drawing.Size(55, 20);
            this.aboutMenu.Text = "&About";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(99, 22);
            this.aboutToolStripMenuItem.Text = "IRN";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutIRNToolStripMenuItem_Click);
            // 
            // statusStrip_UInfo
            // 
            this.statusStrip_UInfo.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.statusStrip_UInfo.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusStrip_UInfo.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tSStatusLbl,
            this.tSStatusLbl_UName,
            this.tSStatusLblRole,
            this.tSStatusLblRoleName,
            this.tSStatusLblApplication,
            this.tSStatusLblAppName,
            this.tSStatusLblAppModule,
            this.tSStatusLblAppModuleName});
            this.statusStrip_UInfo.Location = new System.Drawing.Point(0, 720);
            this.statusStrip_UInfo.Name = "statusStrip_UInfo";
            this.statusStrip_UInfo.Size = new System.Drawing.Size(994, 22);
            this.statusStrip_UInfo.TabIndex = 2;
            this.statusStrip_UInfo.Text = "statusStrip1";
            // 
            // tSStatusLbl
            // 
            this.tSStatusLbl.Name = "tSStatusLbl";
            this.tSStatusLbl.Size = new System.Drawing.Size(77, 17);
            this.tSStatusLbl.Text = "User Name: ";
            // 
            // tSStatusLbl_UName
            // 
            this.tSStatusLbl_UName.ForeColor = System.Drawing.Color.Blue;
            this.tSStatusLbl_UName.Name = "tSStatusLbl_UName";
            this.tSStatusLbl_UName.Size = new System.Drawing.Size(0, 17);
            // 
            // tSStatusLblRole
            // 
            this.tSStatusLblRole.Name = "tSStatusLblRole";
            this.tSStatusLblRole.Size = new System.Drawing.Size(69, 17);
            this.tSStatusLblRole.Text = "User Role: ";
            // 
            // tSStatusLblRoleName
            // 
            this.tSStatusLblRoleName.ForeColor = System.Drawing.Color.Blue;
            this.tSStatusLblRoleName.Name = "tSStatusLblRoleName";
            this.tSStatusLblRoleName.Size = new System.Drawing.Size(0, 17);
            // 
            // tSStatusLblApplication
            // 
            this.tSStatusLblApplication.Name = "tSStatusLblApplication";
            this.tSStatusLblApplication.Size = new System.Drawing.Size(73, 17);
            this.tSStatusLblApplication.Text = "Application: ";
            // 
            // tSStatusLblAppName
            // 
            this.tSStatusLblAppName.ForeColor = System.Drawing.Color.Blue;
            this.tSStatusLblAppName.Name = "tSStatusLblAppName";
            this.tSStatusLblAppName.Size = new System.Drawing.Size(11, 17);
            this.tSStatusLblAppName.Text = "-";
            // 
            // tSStatusLblAppModule
            // 
            this.tSStatusLblAppModule.Name = "tSStatusLblAppModule";
            this.tSStatusLblAppModule.Size = new System.Drawing.Size(53, 17);
            this.tSStatusLblAppModule.Text = "Module: ";
            // 
            // tSStatusLblAppModuleName
            // 
            this.tSStatusLblAppModuleName.ForeColor = System.Drawing.Color.Blue;
            this.tSStatusLblAppModuleName.Name = "tSStatusLblAppModuleName";
            this.tSStatusLblAppModuleName.Size = new System.Drawing.Size(11, 17);
            this.tSStatusLblAppModuleName.Text = "-";
            // 
            // extractProcedureCountFromXmlTSMenuItem
            // 
            this.extractProcedureCountFromXmlTSMenuItem.Name = "extractProcedureCountFromXmlTSMenuItem";
            this.extractProcedureCountFromXmlTSMenuItem.Size = new System.Drawing.Size(278, 22);
            this.extractProcedureCountFromXmlTSMenuItem.Text = "Extract Procedure Count From Xml";
            this.extractProcedureCountFromXmlTSMenuItem.Click += new System.EventHandler(this.extractProcedureCountFromXmlTSMenuItem_Click);
            // 
            // frmMDIMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::IndxReactNarr.Properties.Resources.cas_react_screen_bg1_new;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(994, 742);
            this.Controls.Add(this.statusStrip_UInfo);
            this.Controls.Add(this.menuStrip);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "frmMDIMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CAS-IRN";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMDIMain_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusStrip_UInfo.ResumeLayout(false);
            this.statusStrip_UInfo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileMenu;
        private System.Windows.Forms.ToolStripMenuItem newTANToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutMenu;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem logintoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadTANtoolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem userPrefsMenu;
        private System.Windows.Forms.ToolStripMenuItem userAccountsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem createToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem taskMenu;
        private System.Windows.Forms.ToolStripMenuItem assignmentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem batchMenu;
        private System.Windows.Forms.ToolStripMenuItem insertBatchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem distributeBatchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logOffToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem moveToBatchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem advancedMenu;
        private System.Windows.Forms.ToolStripMenuItem extractRSNToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem duplicateTANToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem validateMenu;
        private System.Windows.Forms.ToolStripMenuItem validateXMLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportMenu;
        private System.Windows.Forms.ToolStripMenuItem errorSummaryReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchMenu;
        private System.Windows.Forms.ToolStripMenuItem listOfTANsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tANSearchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportMenu;
        private System.Windows.Forms.ToolStripMenuItem exporttoXMLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toBatchXMLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nUMSearchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpMenu;
        private System.Windows.Forms.ToolStripMenuItem cASREACTInputManualToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem codingHintsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem generalRemindersForConditionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem and8500sToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem protocToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rSNManualToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem finalCheckToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tANStatusReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rSDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem errorLogReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem orgRefToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rSNFreeDictionaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dailyStatusReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userTANErrorLogReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem solventBoilingPointToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem keywordSearchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem series8500RegNosToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip_UInfo;
        private System.Windows.Forms.ToolStripStatusLabel tSStatusLbl;
        private System.Windows.Forms.ToolStripStatusLabel tSStatusLbl_UName;
        private System.Windows.Forms.ToolStripStatusLabel tSStatusLblRole;
        private System.Windows.Forms.ToolStripStatusLabel tSStatusLblRoleName;
        private System.Windows.Forms.ToolStripMenuItem monthlyReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aminoAcidsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clientFeedbackToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sendMailToUsersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem imageToPDFConvTSMnuItem;
        private System.Windows.Forms.ToolStripMenuItem shipmentTanNUMsForPDfExportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xmlDeliveryReportTSMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userErrorsReportTSMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userProductivityReportTSMenuItem;
        private System.Windows.Forms.ToolStripMenuItem IndexingTSMenuItem;
        private System.Windows.Forms.ToolStripMenuItem structuringConvensionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem roleIndicatorsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem abstractingGuidelinesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem organicIndexingInputManualToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem titleGuideLinesTSMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stereochemGuidelinesTSMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel tSStatusLblApplication;
        private System.Windows.Forms.ToolStripStatusLabel tSStatusLblAppName;
        private System.Windows.Forms.ToolStripStatusLabel tSStatusLblAppModule;
        private System.Windows.Forms.ToolStripStatusLabel tSStatusLblAppModuleName;
        private System.Windows.Forms.ToolStripMenuItem teamStructureTSMenuItem;
        private System.Windows.Forms.ToolStripMenuItem organicIndexingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inputManualToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem structuringConventionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem roleIndicatorsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem titleGuidelinesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stereoChemistryGuidelinesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem macroIndexingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inputManualToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem rEACTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inputManualToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem codingHintsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem generalRemaindersForConditionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem and8500ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem protocolUpdatesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aminoAcidsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem narrativesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unicodesTSMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem reactionViewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem panelToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem narShipmentStatusReportTSMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem narrTANViewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem taskModificationTSMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cTHReferenceTSMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripMenuItem validateNarrativesXMLTSMnuItem;
        private System.Windows.Forms.ToolStripMenuItem narrExpProcXmlTSMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cTHUpdateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem expProcFinalChecksTSMnuItem;
        private System.Windows.Forms.ToolStripMenuItem expProcTANRxnFindingsTSMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shipmentTANsFindAndReplaceTSripMnuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripMenuItem shipmentTANsPageInfoTSMnuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripMenuItem deliveryReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem generateMarkupFoldersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem multiShipmentsStatusReportTSMenuItem;
        private System.Windows.Forms.ToolStripMenuItem narrativesReactionProtocolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem extractProcedureCountFromXmlTSMenuItem;
    }
}



