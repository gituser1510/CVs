﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;
using IndxReactNarrDAL;
using IndxReactNarr.Generic;
using IndxReactNarrBll;
using System.IO;


namespace IndxReactNarr.IndexingImport
{
    public partial class frmImportIndexingTANs_New : Form
    {
        public frmImportIndexingTANs_New()
        {
            InitializeComponent();
        }

        DataTable dtShipmentTANs = null;
        DataTable dtTanFiles = null;
        string shipmentName = "";

        private void frmImportIndexingTANs_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {              

                if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
                {
                    Cursor = Cursors.WaitCursor;

                    txtFileName.Text = folderBrowserDialog1.SelectedPath;
                    shipmentName = Path.GetFileName(folderBrowserDialog1.SelectedPath);
                    string[] files = Directory.GetFiles(folderBrowserDialog1.SelectedPath);
                    string tanInfoFileName = "";
                    string docInfoFileName = "";

                    if (files != null && files.Length == 2)
                    {
                        if (Path.GetFileNameWithoutExtension(files[0]).ToString().StartsWith("docInfo"))
                        {
                            tanInfoFileName = files[0];
                            docInfoFileName = files[1];
                        }
                        else if (Path.GetFileNameWithoutExtension(files[0]).ToString().StartsWith("docFiles"))
                        {
                            docInfoFileName = files[0];
                            tanInfoFileName = files[1];
                        }

                        dtShipmentTANs = GetBatchTANsData(tanInfoFileName);
                        dtTanFiles = GetTanFiles(docInfoFileName);

                        BindBatchTANsDataToGrid(dtShipmentTANs);
                        BindTanFilesToGrid(dtTanFiles);
                    }

                    Cursor = Cursors.Default;
                }               
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindTanFilesToGrid(DataTable dtTanFiles)
        {
            try
            {
                if (dtTanFiles != null)
                {
                    dgvTanFiles.AutoGenerateColumns = false;
                    dgvTanFiles.DataSource = dtTanFiles;

                    colTanName.DataPropertyName = "TAN";
                    colFileType.DataPropertyName = "FileType";
                    colFileName.DataPropertyName = "FileName";
                    coluuid.DataPropertyName = "UUID";

                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private DataTable GetTanFiles(string xmlFile)
        {
            DataTable dtTANFiles = null;
            try
            {
                if (!string.IsNullOrEmpty(xmlFile) && Path.GetFileName(xmlFile).ToLower().StartsWith("docfiles") && Path.GetExtension(xmlFile).ToLower() == ".xml")
                {
                    dtTANFiles = new DataTable();
                    dtTANFiles.Columns.Add("TAN", typeof(string));
                    dtTANFiles.Columns.Add("FileType", typeof(string));
                    dtTANFiles.Columns.Add("FileName", typeof(string));
                    dtTANFiles.Columns.Add("UUID", typeof(string));

                    DataRow dRow = null;

                    XElement xEle = XElement.Load(xmlFile);

                    foreach (XElement _xTan in xEle.Elements("document"))
                    {
                        foreach (XElement _xContent in _xTan.Elements("content"))
                        {
                            foreach (XElement _xfile in _xContent.Elements("file"))
                            {
                                dRow = dtTANFiles.NewRow();
                                dRow["TAN"] = _xTan.Element("tan").Value;
                                dRow["FileType"] = _xfile.Element("type").Value;
                                dRow["FileName"] = _xfile.Element("name").Value;
                                dRow["UUID"] = _xfile.Element("uuid").Value;

                                dtTANFiles.Rows.Add(dRow);

                            }

                        }

                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtTANFiles;
        }

        private void BindBatchTANsDataToGrid(DataTable batchTANs)
        {
            try
            {
                if (batchTANs != null)
                {
                    dgvBatchTANs.AutoGenerateColumns = false;
                    dgvBatchTANs.DataSource = batchTANs;

                    colTAN.DataPropertyName = "TAN";
                    colSection.DataPropertyName = "Section";
                    colLanguage.DataPropertyName = "Language";
                    colTitle.DataPropertyName = "Title";
                    colAbstract.DataPropertyName = "Abstract";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private DataTable GetBatchTANsData(string xmlFile)
        {
            DataTable dtBatchTANs = null;
            try
            {
                if (!string.IsNullOrEmpty(xmlFile) && Path.GetFileName(xmlFile).ToLower().StartsWith("docinfo") && Path.GetExtension(xmlFile).ToLower() == ".xml")
                {
                    dtBatchTANs = new DataTable();
                    dtBatchTANs.Columns.Add("Batch", typeof(string));
                    dtBatchTANs.Columns.Add("TAN", typeof(string));
                    dtBatchTANs.Columns.Add("Section", typeof(Int32));
                    dtBatchTANs.Columns.Add("Language", typeof(string));
                    dtBatchTANs.Columns.Add("Title", typeof(string));
                    dtBatchTANs.Columns.Add("Abstract", typeof(string));
                    dtBatchTANs.Columns.Add("DBStatus");
                    DataRow dRow = null;

                    XElement xEle = XElement.Load(xmlFile);

                    var query2 = from XElement r2 in xEle.Elements("document")
                                 select r2;
                    foreach (XElement _xe in query2)
                    {
                        dRow = dtBatchTANs.NewRow();
                        dRow["Batch"] = "";
                        dRow["TAN"] = _xe.Element("tan").Value;
                        dRow["Section"] = _xe.Element("section").Value;
                        dRow["Language"] = _xe.Element("language").Value;
                        dRow["Title"] = _xe.Element("title").Value;
                        dRow["Abstract"] = _xe.Element("abstract").Value;
                        dRow["DBStatus"] = "Not Loaded";
                        dtBatchTANs.Rows.Add(dRow);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtBatchTANs;
        }

        private void btnSaveInDB_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;
                //string strShipmentName = System.IO.Path.GetFileNameWithoutExtension(txtFileName.Text.Trim());
                //strShipmentName = strShipmentName.Replace("docInfo.", "rxnfile.");

                //Check if Shipment is duplicate
                ShipmentMasterBO shipMaster = new ShipmentMasterBO();
                shipMaster.ShipmentName = shipmentName;// strShipmentName;
                shipMaster.Application = GlobalVariables.ApplicationName;
                if (!ShipmentMasterDB.CheckForDuplicateShipment(shipMaster))
                {
                    Cursor = Cursors.WaitCursor;

                    if (dtShipmentTANs != null && dtShipmentTANs.Rows.Count > 0)
                    {
                        Macro_OrgIndxShipment narrShipment = null;
                        foreach (DataRow row in dtShipmentTANs.Rows)
                        {
                            narrShipment = GetTANShipmentDataFromTables(row["TAN"].ToString(), shipmentName);
                            if (narrShipment != null)
                            {
                                //Save Narr Shipment Data in the database
                                string strStatus = ShipmentMasterDB.UpdateMacro_OrganicShipmentData_Xml(narrShipment);
                                row["DBStatus"] = strStatus;
                            }
                        }
                    }

                    Cursor = Cursors.Default;

                    MessageBox.Show("Indexing Shipment data saved successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Duplicate shipment", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                      
                Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        private Macro_OrgIndxShipment GetTANShipmentDataFromTables(string tan, string shipment)
        {
            Macro_OrgIndxShipment indxShipment = null;
            try
            {
                indxShipment = new Macro_OrgIndxShipment();

                indxShipment.ShipmentName = shipment;
                indxShipment.Application = GlobalVariables.ApplicationName;

                //Get CAN, DOI info from dtTANs
                var rows = from r in dtShipmentTANs.AsEnumerable()
                           where r.Field<string>("TAN") == tan
                           select new
                           {                               
                               Title = r.Field<string>("Title"),
                               Abstract = r.Field<string>("Abstract"),                              
                               Section = r.Field<Int32>("Section"),
                               Language = r.Field<string>("Language")
                           };
                if (rows != null)
                {
                    foreach (var r in rows)
                    {
                        indxShipment.TAN = tan;
                        indxShipment.TANType = "";
                        indxShipment.Title = r.Title;
                        indxShipment.Abstract = r.Abstract;
                        indxShipment.Section = r.Section;
                        indxShipment.Language = r.Language;
                    }
                }

                //Get TAN File Names from dtTANFiles
                var fileNames = (from r in dtTanFiles.AsEnumerable()
                                 where r.Field<string>("TAN") == tan
                                 select r);

                if (fileNames != null)
                {
                    indxShipment.FileNameList = fileNames.AsEnumerable().Select(x => x["FileName"].ToString()).ToList();
                    indxShipment.FileTypeList = fileNames.AsEnumerable().Select(x => x["FileType"].ToString()).ToList();
                    indxShipment.FileUUIdList = fileNames.AsEnumerable().Select(x => x["UUID"].ToString()).ToList();
                }

                indxShipment.UR_ID = GlobalVariables.URID;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return indxShipment;
        }

        private void dgvBatchTANs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvBatchTANs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvBatchTANs.Font);

                if (dgvBatchTANs.RowHeadersWidth < (int)(size.Width + 20)) dgvBatchTANs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvTanFiles_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvTanFiles.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvTanFiles.Font);

                if (dgvTanFiles.RowHeadersWidth < (int)(size.Width + 20)) dgvTanFiles.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }

        }

    }
}
