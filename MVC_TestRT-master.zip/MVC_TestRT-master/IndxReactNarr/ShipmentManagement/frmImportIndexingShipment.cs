﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;
using IndxReactNarrDAL;
using IndxReactNarr.Generic;
using IndxReactNarrBll;

namespace IndxReactNarr.IndexingImport
{
    public partial class frmImportIndexingTANs : Form
    {
        public frmImportIndexingTANs()
        {
            InitializeComponent();
        }

        private void frmImportIndexingTANs_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;

                openFileDialog1.Filter = "XML|*.xml";
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    txtFileName.Text = openFileDialog1.FileName;

                    DataTable dtBatchTANs = GetBatchTANsData(openFileDialog1.FileName);
                    BindBatchTANsDataToGrid(dtBatchTANs);
                }
                Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindBatchTANsDataToGrid(DataTable batchTANs)
        {
            try
            {
                if (batchTANs != null)
                {
                    dgvBatchTANs.AutoGenerateColumns = false;
                    dgvBatchTANs.DataSource = batchTANs;

                    colTAN.DataPropertyName = "TAN";
                    colSection.DataPropertyName = "Section";
                    colLanguage.DataPropertyName = "Language";
                    colTitle.DataPropertyName = "Title";
                    colAbstract.DataPropertyName = "Abstract";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private DataTable GetBatchTANsData(string xmlFile)
        {
            DataTable dtBatchTANs = null;
            try
            {
                if (!string.IsNullOrEmpty(xmlFile))
                {
                    dtBatchTANs = new DataTable();
                    dtBatchTANs.Columns.Add("Batch", typeof(string));
                    dtBatchTANs.Columns.Add("TAN", typeof(string));                  
                    dtBatchTANs.Columns.Add("Section", typeof(Int32));
                    dtBatchTANs.Columns.Add("Language", typeof(string));
                    dtBatchTANs.Columns.Add("Title", typeof(string));
                    dtBatchTANs.Columns.Add("Abstract", typeof(string));

                    DataRow dRow = null;

                    XElement xEle = XElement.Load(xmlFile);

                    var query2 = from XElement r2 in xEle.Elements("document")
                                 select r2;
                    foreach (XElement _xe in query2)
                    {
                        dRow = dtBatchTANs.NewRow();
                        dRow["Batch"] = "";
                        dRow["TAN"] = _xe.Element("tan").Value;                        
                        dRow["Section"] = _xe.Element("section").Value;
                        dRow["Language"] = _xe.Element("language").Value;
                        dRow["Title"] = _xe.Element("title").Value;
                        dRow["Abstract"] = _xe.Element("abstract").Value;

                        dtBatchTANs.Rows.Add(dRow);
                    }                   
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtBatchTANs;
        }

        private void btnSaveInDB_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;

                if (dgvBatchTANs.DataSource != null)
                {
                    DataTable dtBatchTANs = dgvBatchTANs.DataSource as DataTable;

                    if (dtBatchTANs != null && dtBatchTANs.Rows.Count > 0)
                    {
                        string strBatchName = System.IO.Path.GetFileNameWithoutExtension(txtFileName.Text.Trim());
                        strBatchName = strBatchName.Replace("docInfo.", "rxnfile.");

                        string[] saTAN = dtBatchTANs.AsEnumerable().Select(r => r.Field<string>("TAN")).ToArray();
                        string[] saCAN = Enumerable.Repeat<string>("", dtBatchTANs.Rows.Count).ToArray();
                        string[] saTANType = Enumerable.Repeat<string>("JOURNAL", dtBatchTANs.Rows.Count).ToArray(); //For Organic Indexing, all are Journal documents
                        string[] saJournal = Enumerable.Repeat<string>("", dtBatchTANs.Rows.Count).ToArray();
                        string[] saIssue = Enumerable.Repeat<string>("", dtBatchTANs.Rows.Count).ToArray();
                        string[] saYear = Enumerable.Repeat<string>("", dtBatchTANs.Rows.Count).ToArray();
                        Int32[] saSection = dtBatchTANs.AsEnumerable().Select(r => r.Field<Int32>("Section")).ToArray();
                        string[] saTitle = dtBatchTANs.AsEnumerable().Select(r => r.Field<string>("Title")).ToArray();
                        string[] saAbstract = dtBatchTANs.AsEnumerable().Select(r => r.Field<string>("Abstract")).ToArray();
                        string[] saLanguage = dtBatchTANs.AsEnumerable().Select(r => r.Field<string>("Language")).ToArray();

                        ShipmentMasterBO shipMaster = new ShipmentMasterBO();
                        shipMaster.ShipmentName = strBatchName;
                        shipMaster.Application = GlobalVariables.ApplicationName;
                        shipMaster.Shipment_TANs = saTAN;
                        shipMaster.TAN_CAN = saCAN;
                        shipMaster.TAN_Type = saTANType;
                        shipMaster.Journals = saJournal;
                        shipMaster.Issue = saIssue;
                        shipMaster.Year = saYear;
                        shipMaster.Section = saSection;
                        shipMaster.Title = saTitle;
                        shipMaster.Abstract = saAbstract;
                        shipMaster.Language = saLanguage;
                        shipMaster.UR_ID = GlobalVariables.URID;

                        if (ShipmentMasterDB.UpdateIndexingShipmentData(shipMaster))
                        {
                            MessageBox.Show("Batch TANs saved successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Error in saving batch TANs", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
                Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        private void dgvBatchTANs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvBatchTANs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvBatchTANs.Font);

                if (dgvBatchTANs.RowHeadersWidth < (int)(size.Width + 20)) dgvBatchTANs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }             
    }
}
