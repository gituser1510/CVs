﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using IndxReactNarr.Generic;
using IndxReactNarrBll;
using IndxReactNarrDAL;

namespace IndxReactNarr
{
    public partial class frmImportReactShipment : Form
    {
        public DataTable CgmDataTbl = null;

        public frmImportReactShipment()
        {
            InitializeComponent();
        }

        DataTable dtTANs = null;
        DataTable dtTAN_NUMs = null;
        DataTable dtSubstances = null;
        string shipmentName = "";

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                lblTANsCnt.Text = "0";
                lblUploadedTANsCnt.Text = "0";

                openFileDialog1.Filter = "CGM|*.cgm";
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    Cursor = Cursors.WaitCursor;

                    txtFileName.Text = openFileDialog1.FileName;

                    shipmentName = Path.GetFileNameWithoutExtension(openFileDialog1.FileName);

                    #region MyRegion
                    //DataTable dtCGMData = ReadCgm.GetCgmFileData(openFileDialog1.FileName);
                    //if (dtCGMData != null)
                    //{
                    //    if (dtCGMData.Rows.Count > 0)
                    //    {
                    //        dgCgmData.DataSource = dtCGMData;
                    //        CgmDataTbl = dtCGMData;
                    //    }
                    //}

                    //DataTable dtCGMData = ReadCgm.GetCgmFileData_BulkCopy(openFileDialog1.FileName);
                    //if (dtCGMData != null)
                    //{
                    //    if (dtCGMData.Rows.Count > 0)
                    //    {
                    //        dgvTANDetails.DataSource = dtCGMData;
                    //        CgmDataTbl = dtCGMData;

                    //        IndxReactNarrDAL.CASRxnDataAccess.BulkUploadPackingData(dtCGMData);
                    //    }
                    //} 
                    #endregion
                    
                    dtTANs = ReadCgm.GetTANsAndSubstancesInformationFromCGMFile(openFileDialog1.FileName, out dtTAN_NUMs, out dtSubstances);
                    
                    dgvTANDetails.DataSource = dtTANs;
                    dgvTAN_NUMs.DataSource = dtTAN_NUMs;
                    dgvNUMsInfo.DataSource = dtSubstances;

                    lblTANsCnt.Text = dtTANs.Rows.Count.ToString();
                }

                Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnSaveExl_Click(object sender, EventArgs e)
        {
            try
            {
                if (chkSaveInvFiles.Checked)
                {
                    if (foldBrowsDlg.ShowDialog() == DialogResult.OK)
                    {
                        if (SaveAsIndividualTANFiles(foldBrowsDlg.SelectedPath))
                        {
                            MessageBox.Show("Saved data successfully", "Save File", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
                else
                {
                    saveFileDialog1.Filter = "XlS|*.xls";

                    if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                    {
                        if (SaveAsSingleExcelFile(saveFileDialog1.FileName))
                        {
                            MessageBox.Show("Saved data successfully","Save File",MessageBoxButtons.OK,MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private bool SaveAsSingleExcelFile(string _filepath)
        {
            try
            {
                if (_filepath.Trim() != "")
                {
                    StreamWriter sWriter;
                    sWriter = File.CreateText(_filepath);
                    StringBuilder objStrBlder = new StringBuilder();

                    int borderWidth = 1;

                    string boldTagStart = "<B>";
                    string boldTagEnd = "</B>";

                    objStrBlder.Append("<Table border=" + borderWidth + ">");

                    objStrBlder.Append("<TR>");

                    foreach (DataColumn oDataColumn in CgmDataTbl.Columns)
                    {
                        objStrBlder.Append("<TD>" + boldTagStart + oDataColumn.ColumnName + boldTagEnd + "</TD>");
                    }
                    objStrBlder.Append("</TR>");

                    foreach (DataRow oDataRow in CgmDataTbl.Rows)
                    {
                        objStrBlder.Append("<TR>");

                        foreach (DataColumn oDataColumn in CgmDataTbl.Columns)
                        {
                            objStrBlder.Append("<TD>" + oDataRow[oDataColumn.ColumnName] + "</TD>");
                        }
                        objStrBlder.Append("</TR>");
                    }

                    objStrBlder.Append("</Table>");

                    sWriter.WriteLine(objStrBlder.ToString());
                    sWriter.Close();
                    return true;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return false;
        }

        private bool SaveAsIndividualTANFiles(string _filepath)
        {
            try
            {
                if (_filepath.Trim() != "")
                {
                    StreamWriter sWriter;
                    StringBuilder objStrBlder = null;

                    int borderWidth = 1;

                    string boldTagStart = "<B>";
                    string boldTagEnd = "</B>";

                    DataView dtView = null;
                    DataTable dtResData = null;


                    DataTable dtCGM = CgmDataTbl.Copy();                    

                    var qry = (from r in dtCGM.AsEnumerable()
                             select r["TAN"]).Distinct().ToList();

                    if (qry != null)
                    {
                        if (qry.Count > 0)
                        {
                            for (int i = 0; i < qry.Count; i++)
                            {                                
                                sWriter = File.CreateText(_filepath + "\\" + qry[i].ToString() + ".xls");
                                objStrBlder = new StringBuilder();                        

                                objStrBlder.Append("<Table border=" + borderWidth + ">");
                                objStrBlder.Append("<TR>");                               

                                //Write Columns Names to File
                                foreach (DataColumn oDataColumn in dtCGM.Columns)
                                {
                                    objStrBlder.Append("<TD>" + boldTagStart + oDataColumn.ColumnName + boldTagEnd + "</TD>");
                                }
                                objStrBlder.Append("</TR>");                                
                                
                                dtView = dtCGM.DefaultView;
                                dtView.RowFilter = "TAN = '" + qry[i].ToString() + "'";

                                dtResData = dtView.ToTable();

                                if (dtResData != null)
                                {
                                    if (dtResData.Rows.Count > 0)
                                    {
                                        foreach (DataRow oDataRow in dtResData.Rows)
                                        {
                                            objStrBlder.Append("<TR>");

                                            foreach (DataColumn oDataColumn in dtResData.Columns)
                                            {
                                                objStrBlder.Append("<TD>" + oDataRow[oDataColumn.ColumnName] + "</TD>");
                                            }
                                            objStrBlder.Append("</TR>");
                                        }
                                    }
                                }
                                objStrBlder.Append("</Table>");

                                sWriter.WriteLine(objStrBlder.ToString());
                                sWriter.Close();
                            }
                            return true;
                        }
                    }              
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return false;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (ValidateNUM_RegNoCombination())
                {
                    //Check if Shipment is duplicate
                    ShipmentMasterBO shipMaster = new ShipmentMasterBO();
                    shipMaster.ShipmentName = shipmentName;
                    shipMaster.Application = GlobalVariables.ApplicationName;
                    if (!ShipmentMasterDB.CheckForDuplicateShipment(shipMaster))
                    {
                        DialogResult diaREs = MessageBox.Show("Do you want to upload the shipment task?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (diaREs == System.Windows.Forms.DialogResult.Yes)
                        {
                            Cursor = Cursors.WaitCursor;

                            SaveReactShipmentDataInDataBase();

                            Cursor = Cursors.Default;

                            MessageBox.Show("React Shipment data saved successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Duplicate shipment", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("NUM 0 is not allowed in TAN-NUMs", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }    

        private void frmReadCgmFile_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }
               
        private DataTable GetUniqueTANsFromCgmData()
        {
            DataTable dtTANs = null;
            try
            {
                if (CgmDataTbl != null)
                {
                    DataView dvCGM = CgmDataTbl.Copy().DefaultView;
                    string[] saDistCol = { "TAN" };
                    dtTANs = dvCGM.ToTable(true, saDistCol);
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtTANs;
        }

        private bool ValidateNUM_RegNoCombination()
        {
            bool blStatus = true;
            try
            {
                if (dgvTAN_NUMs.Rows.Count > 0)
                {
                    DataTable dtTANNums = dgvTAN_NUMs.DataSource as DataTable;
                    if (dtTANNums != null && dtTANNums.Rows.Count > 0)
                    {
                       int zeroNumCnt = dtTANNums.Select("NUM = 0").Count();
                       if (zeroNumCnt > 0)
                       {
                           blStatus = false;
                       }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private ReactShipmentMasterBO GetReactShipmentInfoOnTAN(DataRow dRow)
        {
            ReactShipmentMasterBO reactShipment = null;
            try
            {
                if (dRow != null)
                {                   
                    string strTANType = "";
                    string strTAN = "";
                    string strCAN = "";
                    string strJournalName = "";
                    string strIssue = "";
                    string strYear = "";
                    DataView dvTemp;
                    DataTable dtNumsInfo;

                    string strNUM = "";
                    string strRegNo = "";

                    List<string> lstNUMs = null;
                    List<string> lstRegNos = null;
                    List<string> lstFormulas = null;
                    List<string> lstIUPACName = null;
                    List<string> lstPepSeq = null;
                    List<string> lstNuclicSeq = null;
                    List<string> lstOtherNames = null;
                    List<string> lstMolHexCode = null;
                    List<string> lstAbsStereo = null;

                    strTAN = dRow["TAN_NAME"].ToString().Trim();
                    strCAN = dRow["CAN"].ToString().Trim();
                    strTANType = dRow["TAN_TYPE"].ToString().Trim();
                    strYear = dRow["JOURNAL_YEAR"].ToString().Trim();
                    strJournalName = dRow["JOURNAL_NAME"].ToString().Trim();
                    strIssue = dRow["ISSUE"].ToString().Trim();

                    reactShipment = new ReactShipmentMasterBO();
                    reactShipment.ShipmentName = shipmentName;
                    reactShipment.Application = GlobalVariables.ApplicationName;
                    reactShipment.TAN = strTAN;
                    reactShipment.CAN = strCAN;
                    reactShipment.TANType = strTANType;
                    reactShipment.JournalYear = strYear;
                    reactShipment.IssueName = strIssue;
                    reactShipment.JournalName = strJournalName;

                    lstNUMs = new List<string>();
                    lstRegNos = new List<string>();
                    lstFormulas = new List<string>();
                    lstIUPACName = new List<string>();
                    lstPepSeq = new List<string>();
                    lstNuclicSeq = new List<string>();
                    lstOtherNames = new List<string>();
                    lstMolHexCode = new List<string>();
                    lstAbsStereo = new List<string>();

                    //For each TAN Get NUMs Info
                    DataView dvNums = dtTAN_NUMs.Copy().DefaultView;
                    dvNums.RowFilter = "TAN = '" + strTAN + "'";

                    string nuclicAcidSeq = "";
                    string peptideSeq = "";
                    
                    using (DataTable dtNums = dvNums.ToTable())
                    {
                        if (dtNums != null)
                        {
                            foreach (DataRow numRow in dtNums.Rows)
                            {
                                strNUM = numRow["NUM"].ToString();
                                strRegNo = numRow["REG_NO"].ToString();

                                //For each NUM Get NUM Info
                                dvTemp = dtSubstances.Copy().DefaultView;
                                dvTemp.RowFilter = "REG_NO = " + strRegNo + "";
                                dtNumsInfo = dvTemp.ToTable();

                                if (dtNumsInfo != null && dtNumsInfo.Rows.Count > 0)
                                {
                                    for (int i = 0; i < dtNumsInfo.Rows.Count; i++)
                                    {
                                        nuclicAcidSeq = "";
                                        peptideSeq = "";

                                        lstNUMs.Add(strNUM);
                                        lstRegNos.Add(strRegNo);
                                        lstFormulas.Add(dtNumsInfo.Rows[i]["FORMULA"].ToString());
                                        lstOtherNames.Add(dtNumsInfo.Rows[i]["OTHER_NAMES"].ToString());
                                        lstIUPACName.Add(dtNumsInfo.Rows[i]["IUPAC_NAME"].ToString());

                                        nuclicAcidSeq = dtNumsInfo.Rows[i]["NUCLIC_ACID_SEQ"].ToString();
                                        peptideSeq = dtNumsInfo.Rows[i]["PEPTIDE_SEQ"].ToString();

                                        lstPepSeq.Add(peptideSeq.Length <= 3900 ? peptideSeq : peptideSeq.Substring(0, 3900));
                                        lstNuclicSeq.Add(nuclicAcidSeq.Length <= 3900 ? nuclicAcidSeq : nuclicAcidSeq.Substring(0, 3900));
                                        lstMolHexCode.Add(dtNumsInfo.Rows[i]["MOL_HEX_CODE"].ToString());

                                        lstAbsStereo.Add(dtNumsInfo.Rows[i]["ABS_STEREO"].ToString());
                                    }
                                }
                                else
                                {
                                    lstNUMs.Add(strNUM);
                                    lstRegNos.Add(strRegNo);

                                    lstFormulas.Add("");
                                    lstOtherNames.Add("");
                                    lstIUPACName.Add("");
                                                                        
                                    lstPepSeq.Add("");
                                    lstNuclicSeq.Add("");
                                    lstMolHexCode.Add("");
                                    lstAbsStereo.Add("");
                                }
                            }

                            //Convert list to Array
                            reactShipment.NUM = lstNUMs.ToArray();
                            reactShipment.REG_NO = lstRegNos.ToArray();
                            reactShipment.Formula = lstFormulas.ToArray();
                            reactShipment.IUPACName = lstIUPACName.ToArray();
                            reactShipment.OtherNames = lstOtherNames.ToArray();
                            reactShipment.PeptideSeq = lstPepSeq.ToArray();
                            reactShipment.NuclicAcidSeq = lstNuclicSeq.ToArray();
                            reactShipment.MolHexCode = lstMolHexCode.ToArray();
                            reactShipment.AbsStereo = lstAbsStereo.ToArray();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return reactShipment;
        }

        int uploadedTANsCnt = 0;
        private bool SaveReactShipmentDataInDataBase()
        {
            bool blStatus = true;
            try
            {
                uploadedTANsCnt = 0;
                if (dtTANs != null && dtTANs.Rows.Count > 0)
                {
                    ReactShipmentMasterBO reactShipment = null;
                    foreach (DataRow dRow in dtTANs.Rows)
                    {
                        try
                        {
                            //Get React Shipment info on TAN
                            reactShipment = GetReactShipmentInfoOnTAN(dRow);
                            if (reactShipment != null)
                            {
                                if (reactShipment.TAN != "35126856M")
                                {
                                    reactShipment.UR_ID = GlobalVariables.URID;

                                    // Save React Shipment Data in the database
                                    string strStatus = ShipmentMasterDB.UpdateReactShipmentData(reactShipment);
                                    dRow["DB_STATUS"] = strStatus;
                                    if (strStatus.ToUpper() == "INSERT SUCCESS")
                                    {
                                        uploadedTANsCnt = uploadedTANsCnt + 1;
                                    }
                                }
                            }
                        }
                        catch
                        {
                            blStatus = false;
                        }
                    }

                    dgvTANDetails.Refresh();

                    lblUploadedTANsCnt.Text = uploadedTANsCnt.ToString();

                    #region MyRegion
                    //{
                    //    if (dtDistTANs.Rows.Count > 0)
                    //    {
                    //        string strBatchName = CgmDataTbl.Rows[0]["Batch"].ToString().Trim();
                    //        string strDocType = "";
                    //        string strTAN = "";
                    //        string strCAN = "";

                    //        string strErrMsg = "";

                    //        DataTable dtNUMs = null;
                    //        int[] iaNUMs = null;
                    //        int[] iaRegNos = null;

                    //        for (int i = 0; i < dtDistTANs.Rows.Count; i++)
                    //        {
                    //            strTAN = dtDistTANs.Rows[i][0].ToString().Trim();

                    //            //Get NUMs from cgm table based on TAN
                    //            dtNUMs = GetNUMsFromCGMTableOnTAN(strTAN);
                    //            if (dtNUMs != null)
                    //            {
                    //                if (dtNUMs.Rows.Count > 0)
                    //                {
                    //                    strCAN = dtNUMs.Rows[0]["CAN"].ToString().Trim();
                    //                    strDocType = dtNUMs.Rows[0]["DOCTYPE"].ToString().Trim();

                    //                    //Convert NUMs table to array                                  
                    //                    iaNUMs = GetNUMs_RegNosArraysFromNUMsTable(dtNUMs, out iaRegNos);
                    //                    if (iaNUMs != null && iaRegNos != null)
                    //                    {
                    //                        if (!IndxReactNarrDAL.CASRxnDataAccess.CheckAndInsert_Batch_TAN_CAN_NUMs(strBatchName, strTAN, strCAN, iaNUMs, iaRegNos, iaNUMs.Length, strDocType))
                    //                        {
                    //                            if (!string.IsNullOrEmpty(strErrMsg))
                    //                            {
                    //                                strErrMsg = strErrMsg + ", " + strTAN;
                    //                            }
                    //                            else
                    //                            {
                    //                                strErrMsg = strTAN;
                    //                            }
                    //                        }
                    //                    }
                    //                }
                    //            }
                    //        }
                    //        if (!string.IsNullOrEmpty(strErrMsg))
                    //        {
                    //            MessageBox.Show("Below TANs insertion is failed: \r\n" + strErrMsg, "Insert Batch",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    //        }
                    //    }
                    //} 
                    #endregion
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        #region Grid RowPostPaint Events
        
        private void dgvTANDetails_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvTANDetails.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvTANDetails.Font);

                if (dgvTANDetails.RowHeadersWidth < (int)(size.Width + 20)) dgvTANDetails.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvTAN_NUMs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvTAN_NUMs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvTAN_NUMs.Font);

                if (dgvTAN_NUMs.RowHeadersWidth < (int)(size.Width + 20)) dgvTAN_NUMs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvNUMsInfo_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvNUMsInfo.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvNUMsInfo.Font);

                if (dgvNUMsInfo.RowHeadersWidth < (int)(size.Width + 20)) dgvNUMsInfo.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        } 
        
        #endregion
        
    }
}
