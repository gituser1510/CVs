﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using IndxReactNarr.Generic;
using Microsoft.Office.Interop.Word;
using System.Text.RegularExpressions;
using IndxReactNarrBll;
using IndxReactNarrDAL;
using System.Xml.Linq;

namespace IndxReactNarr
{
    public partial class frmImportExpProcedures2Shipment : Form
    {
        public frmImportExpProcedures2Shipment()
        {
            InitializeComponent();
        }       
                       
        List<string> lstUniqueTANs = null;      
        DataTable dtTANs = null;
        DataTable dtTANNumSeq = null;
        DataTable dtTANFiles = null;
        string shipmentType = "JOURNAL";
        string shipmentName = "";

        public DataTable dtTanMaster = null;
        public DataTable dtTanReactions = null;
        public DataTable dtRxn_Substances = null;
        public DataTable dtFiles = null;

        public List<ExpProcedures> lstExperimProc = new List<ExpProcedures>();

        private void frmImportExpProceduresShipment_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void btnBrowseFolder_Click(object sender, EventArgs e)
        {
            try
            {
                String Folder_Path = String.Empty;

                if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
                {                  
                    Folder_Path = folderBrowserDialog1.SelectedPath;
                    txtShipmentPath.Text = Folder_Path;

                    /*---------- Getting All The XML Files from All TAN Folders -----------*/

                    shipmentName = Path.GetFileNameWithoutExtension(folderBrowserDialog1.SelectedPath);
                    shipmentType = shipmentName.ToUpper().Contains("-PAT-") ? "PATENT" : "JOURNAL";

                    String[] Files = null;

                    if (Directory.Exists(Folder_Path))
                    {
                        Files = Directory.GetFiles(Folder_Path, @"*.xml", SearchOption.AllDirectories);
                    }

                    CreateDataTables(); // Function Creating Data Tables 

                    foreach (String Item in Files)
                    {
                        XElement xElm_XmlFile = XElement.Load(Item);
                        
                        /*------------ Extracting TAN, CAN, DOI & DOC_Seq Details into Data Tables ------------------*/

                        IEnumerable<XElement> IE_Document = from X in xElm_XmlFile.Elements("document") select X;

                        IEnumerable<XElement> XEle_dockeys = IE_Document.Elements("dockeys");
                        IEnumerable<XElement> XEle_Tans = XEle_dockeys.Elements("tan");
                        IEnumerable<XElement> XEle_Can = XEle_dockeys.Elements("can");
                        IEnumerable<XElement> XEle_doi = XEle_dockeys.Elements("doi");
                        IEnumerable<XElement> XEle_DocSeq = XEle_dockeys.Elements("docseq");

                        String TAN = XEle_Tans.ElementAtOrDefault(0).Value.ToString();
                        String CAN = XEle_Can.ElementAtOrDefault(0).Value.ToString();
                        String DOI = XEle_doi.ElementAtOrDefault(0) != null ? XEle_doi.ElementAtOrDefault(0).Value.ToString() : "";
                        String Doc_Seq = XEle_DocSeq.ElementAtOrDefault(0).Value.ToString();

                        //IEnumerable<XElement> XEle_Doc_Type = IE_Document.Elements("doc-type");
                        //IEnumerable<XElement> XEle_Coden = IE_Document.Elements("coden");
                        //IEnumerable<XElement> XEle_Publisher = IE_Document.Elements("publisher-family");

                        String Doc_Type = IE_Document.Elements("doc-type").ElementAt(0).Value.ToString();
                        String Coden = IE_Document.Elements("coden").ElementAt(0).Value.ToString();
                        String Publish = IE_Document.Elements("publisher-family").ElementAt(0).Value.ToString();

                        int rxnCount = 0;

                        try
                        {
                           rxnCount = xElm_XmlFile.Elements("reactions").Elements("reaction").Count();
                        }
                        catch
                        { 
                        
                        }

                        dtTanMaster.Rows.Add(TAN, CAN, DOI, Doc_Seq, Doc_Type, Coden, Publish, rxnCount);

                        List<String> lst_FileType = new List<String>();
                        List<String> lst_FileId = new List<String>();
                        List<String> lst_FileName = new List<String>();
                        List<String> lst_FileUid = new List<String>();

                        /*------------ Extracting File Info from TAN/XML Files -----------*/

                        if (IE_Document.Elements("files").Count() > 0)
                        {
                            //IEnumerable<XElement> XEle_Files = IE_Document.Elements("files");

                            IEnumerable<XElement> XEle_File = IE_Document.Elements("files").Elements("file");

                            String Type = String.Empty;
                            String Id = String.Empty;                            
                            String Name = String.Empty;
                            String Uid = String.Empty;
                            String FileDocRef = String.Empty;

                            foreach (XElement XFile in XEle_File)
                            {
                                Type = XFile.Attribute("type").Value.ToString();
                                Id = XFile.Attribute("id").Value.ToString();
                                Name = XFile.Attribute("name").Value.ToString();
                               
                                try
                                {
                                    Uid = XFile.Attribute("uuid").Value.ToString();
                                }
                                catch
                                { }

                                dtFiles.Rows.Add(TAN, Type, Id, Name, Uid);

                                lst_FileType.Add(Type);
                                lst_FileId.Add(Id);
                                lst_FileName.Add(Name);
                                lst_FileUid.Add(Uid);
                            }
                        }


                        /*-------------- Extracting RXN_NUM, RXN_SEQ, RXN_ID for TANS/XML File --------------*/

                        IEnumerable<XElement> IE_RXN_Data = from Y in xElm_XmlFile.Elements("reactions").Elements("reaction") select Y;

                        //String RxnNarID = String.Empty;
                        String RxnNum = String.Empty;
                        String RxnSeq = String.Empty;
                        String RxnIdentifier = String.Empty;
                        String RxnDocRef = String.Empty;
                        Int32 RxnPageNo = 0;
                        String RxnPageLabel = String.Empty;
                        Double RxnXPageSize = 0.0;
                        Double RxnYPageSize = 0.0;
                        Double RxnXPageOffset = 0.0;
                        Double RxnYPageOffset = 0.0;
                        //String AnalgusRxnNumSeq = String.Empty;
                        String AnalgusRxnNarID = String.Empty;
                        String RxnNarID = String.Empty;
                        String RxnPara = String.Empty;
                        String RxnData = String.Empty;
                        String RxnTextLine = String.Empty;

                        List<String> lstRXN_NUM = new List<String>();
                        List<String> lstRXN_Seq = new List<String>();
                        List<String> lstRXNIdentifier = new List<String>();

                        List<String> lstSubstRxnNarID = new List<String>();
                        List<String> lstSubId = new List<String>();
                        List<String> lstSub_RegNo = new List<String>();
                        List<String> lstSub_Role = new List<String>();

                        //New properties for Experimental Procedures Narratives - 19th Feb 2016
                        List<String> lstRxnDocRef = new List<String>();
                        List<String> lstRxnNarIDs = new List<String>();

                        List<Int32> lstRxnPageNo = new List<Int32>();
                        List<String> lstRxnPageLabel = new List<String>();
                        List<Double> lstRxnXPageSize = new List<Double>();
                        List<Double> lstRxnXPageOffset = new List<Double>();
                        List<Double> lstRxnYPageSize = new List<Double>();
                        List<Double> lstRxnYPageOffset = new List<Double>();
                        List<String> lstAnalgsRxnNarID = new List<String>();
                        List<String> lstRxnPara = new List<String>();
                        List<String> lstRxnData = new List<String>();
                        List<String> lstRxnTextLine = new List<String>();

                        foreach (XElement XE in IE_RXN_Data)
                        {
                            RxnNum = String.Empty;
                            RxnSeq = String.Empty;
                            RxnIdentifier = String.Empty;
                            RxnDocRef = String.Empty;
                            RxnPageNo = 0;
                            RxnPageLabel = String.Empty;
                            RxnXPageSize = 0.0;
                            RxnYPageSize = 0.0;
                            RxnXPageOffset = 0.0;
                            RxnYPageOffset = 0.0;

                            AnalgusRxnNarID = null;
                            RxnNarID = String.Empty;
                            RxnPara = String.Empty;
                            RxnData = String.Empty;
                            RxnTextLine = String.Empty;

                            RxnNum = Convert.ToInt32(XE.Attribute("num").Value.ToString()).ToString();
                            RxnSeq = Convert.ToInt32(XE.Attribute("seq").Value.ToString()).ToString();
                            RxnIdentifier = XE.Attribute("rxnid").Value.ToString();
                                    
                            //Exp.Procedures Narratives values - 19th Feb 2016
                            try
                            {
                                RxnDocRef = XE.Element("procedure").Element("location").Attribute("doc-ref").Value.ToString();
                            }
                            catch { }
                            try
                            {
                                RxnPageNo = Convert.ToInt32(XE.Element("procedure").Element("location").Element("page").Element("number").Value.ToString());
                            }
                            catch { }
                            try
                            {
                                RxnPageLabel = XE.Element("procedure").Element("location").Element("page").Element("label").Value.ToString();
                            }
                            catch { }
                            try
                            {
                                RxnXPageSize = Convert.ToDouble(XE.Element("procedure").Element("location").Element("position").Element("x-pos").Element("page-size").Value.ToString());
                            }
                            catch { }
                            try
                            {
                                RxnYPageSize = Convert.ToDouble(XE.Element("procedure").Element("location").Element("position").Element("y-pos").Element("page-size").Value.ToString());
                            }
                            catch { }
                            try
                            {
                                RxnXPageOffset = Convert.ToDouble(XE.Element("procedure").Element("location").Element("position").Element("x-pos").Element("offset").Value.ToString());
                            }
                            catch { }
                            try
                            {
                                RxnYPageOffset = Convert.ToDouble(XE.Element("procedure").Element("location").Element("position").Element("y-pos").Element("offset").Value.ToString());
                            }
                            catch { }

                            try
                            {
                                RxnTextLine = XE.Element("procedure").Element("location").Element("text-line").Value.ToString().Trim();
                            }
                            catch { }

                            try
                            {
                                if (!string.IsNullOrEmpty(XE.Element("procedure").Element("narrative").Attribute("id").Value.ToString().Trim()))
                                {
                                    RxnNarID = XE.Element("procedure").Element("narrative").Attribute("id").Value.ToString();
                                }
                                else
                                {
                                    RxnNarID = RxnNum + "-" + RxnSeq;
                                }
                            }
                            catch  //Missing reaction
                            {
                                RxnNarID = RxnNum + "-" + RxnSeq;
                            }

                            try
                            {                                                              
                                AnalgusRxnNarID = XE.Element("procedure").Element("narrative").Attribute("analogous-to").Value.ToString().Trim();

                                //AnalgusRxnNarID = XE.Element("procedure").Element("narrative").Attribute("analogousNum").Value.ToString() + "-" +
                                //                   XE.Element("procedure").Element("narrative").Attribute("analogousSeq").Value.ToString();
                            }
                            catch 
                            {
                            
                            }
                            
                            try
                            {
                                RxnPara = string.Join("``PARA``", XE.Element("procedure").Element("narrative").Elements("para").ToList()).Replace("<para>","").Replace("</para>","").Replace("<para substance-yield-text=\"true\">","").Trim();
                            }
                            catch { }

                            try
                            {
                                RxnData = string.Join("``DATA``", XE.Element("procedure").Element("data").Elements("para").ToList()).Replace("<para>", "").Replace("</para>", "").Trim();
                            }
                            catch { }

                            if (!string.IsNullOrEmpty(RxnTextLine))
                            {
                                string rtfTextLine = Html_RtfConversions.Instance.GetRTFfromHTMLString(RxnTextLine, false);
                                RxnTextLine = Html_RtfConversions.Instance.GetHTMLFromRTFString(rtfTextLine);
                            }

                            if (!string.IsNullOrEmpty(RxnPara))
                            {
                                string rtfPara = Html_RtfConversions.Instance.GetRTFfromHTMLString(RxnPara, false);
                                RxnPara = Html_RtfConversions.Instance.GetHTMLFromRTFString(rtfPara);
                            }

                            if (!string.IsNullOrEmpty(RxnData))
                            {
                                string rtfData = Html_RtfConversions.Instance.GetRTFfromHTMLString(RxnData, false);
                                RxnData = Html_RtfConversions.Instance.GetHTMLFromRTFString(rtfData);
                            }

                            dtTanReactions.Rows.Add(TAN, RxnNum, RxnSeq, RxnIdentifier, RxnDocRef, RxnNarID, AnalgusRxnNarID, RxnPageNo,
                                                    RxnPageLabel, RxnXPageSize, RxnYPageSize, RxnXPageOffset, RxnYPageOffset,RxnTextLine, RxnPara, RxnData);

                            lstRXN_NUM.Add(RxnNum);
                            lstRXN_Seq.Add(RxnSeq);
                            lstRXNIdentifier.Add(RxnIdentifier);
                            lstRxnNarIDs.Add(RxnNarID);

                            //Exp. Proc Narratives parameters - 19th Feb 2016
                            lstRxnTextLine.Add(RxnTextLine);
                            lstRxnDocRef.Add(RxnDocRef);
                            lstRxnPageNo.Add(RxnPageNo);
                            lstRxnPageLabel.Add(RxnPageLabel);
                            lstRxnXPageSize.Add(RxnXPageSize);
                            lstRxnYPageSize.Add(RxnYPageSize);
                            lstRxnXPageOffset.Add(RxnXPageOffset);
                            lstRxnYPageOffset.Add(RxnYPageOffset);

                            lstAnalgsRxnNarID.Add(AnalgusRxnNarID);
                            lstRxnPara.Add(RxnPara);
                            lstRxnData.Add(RxnData);

                            //IEnumerable<XElement> IE_RXN_Substances = XE.Elements("substances");
                            IEnumerable<XElement> IE_RXN_Substance = XE.Elements("substances").Elements("substance");

                            String Sub_Id = String.Empty;
                            String Reg_No = String.Empty;
                            String Role = String.Empty;
                           
                            foreach (XElement XSub in IE_RXN_Substance)
                            {
                                Sub_Id = XSub.Attribute("id").Value.ToString();
                                Reg_No = XSub.Attribute("registry-number").Value.ToString();
                                Role = XSub.Attribute("role").Value.ToString();

                                dtRxn_Substances.Rows.Add(TAN, RxnIdentifier, Sub_Id, Reg_No, Role);

                                lstSubstRxnNarID.Add(RxnNarID);//
                                lstSubId.Add(Sub_Id);
                                lstSub_RegNo.Add(Reg_No);
                                lstSub_Role.Add(Role);
                            }
                        }

                        /*--------- Adding Narrative XML Data except FILE Tag Data to LIST for DB Insert ------------*/

                        ExpProcedures objExpProc = new ExpProcedures();

                        //TAN information
                        objExpProc.TAN = TAN;
                        objExpProc.CAN = CAN;
                        objExpProc.DOI = DOI;
                        objExpProc.CODEN = Coden;
                        objExpProc.DocSeq = !string.IsNullOrEmpty(Doc_Seq) ? Convert.ToInt32(Doc_Seq) : 0;
                        objExpProc.Publisher_Family = Publish;
                        objExpProc.Doc_Type = Doc_Type;

                        //TAN Reactions
                        objExpProc.RXN_NUM = lstRXN_NUM;
                        objExpProc.RXN_Seq = lstRXN_Seq;
                        objExpProc.RXN_Id = lstRXNIdentifier;
                        objExpProc.RxnNarIDList = lstRxnNarIDs;
                        objExpProc.AnalogousRxnNarIdList = lstAnalgsRxnNarID;
                        objExpProc.RxnDocRefList = lstRxnDocRef;
                        objExpProc.RxnPageNoList = lstRxnPageNo;
                        objExpProc.RxnPageLabelList = lstRxnPageLabel;
                        objExpProc.RxnXPageSizeList = lstRxnXPageSize;
                        objExpProc.RxnYPageSizeList = lstRxnYPageSize;
                        objExpProc.RxnXPageOffsetList = lstRxnXPageOffset;
                        objExpProc.RxnYPageOffsetList = lstRxnYPageOffset;
                        objExpProc.RxnTextLineList = lstRxnTextLine;
                        objExpProc.RxnParaList = lstRxnPara;
                        objExpProc.RxnDataList = lstRxnData;
                        
                        //TAN-Reactions Substances
                        objExpProc.SubstRxnNarID = lstSubstRxnNarID;
                        objExpProc.SubstIds = lstSubId; 
                        objExpProc.SubstRegNos = lstSub_RegNo;
                        objExpProc.SubstRoles = lstSub_Role;

                        //TAN Files
                        objExpProc.File_Type = lst_FileType;
                        objExpProc.File_Id = lst_FileId;
                        objExpProc.File_Name = lst_FileName;
                        objExpProc.File_UUID = lst_FileUid;                        

                        lstExperimProc.Add(objExpProc);                        
                    }
                }
                
                //Bind grids data
                dgvTANs.DataSource = dtTanMaster;
                dgvTANNumSeq.DataSource = dtTanReactions;
                dgvRxnSubstances.DataSource = dtRxn_Substances;
                dgvTANFiles.DataSource = dtFiles;               

                //Set Counts
                lblTANCount.Text = dgvTANs.Rows.Count.ToString();
                lblFileCount.Text = dgvTANFiles.Rows.Count.ToString();
                lblRxnCount.Text = dgvTANNumSeq.Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public void CreateDataTables()
        {
            try
            {
                dtTanMaster = new DataTable();
                dtTanMaster.Columns.Add("TAN", typeof(String));
                dtTanMaster.Columns.Add("CAN", typeof(String));
                dtTanMaster.Columns.Add("DOI", typeof(String));
                dtTanMaster.Columns.Add("DocSeq", typeof(String));
                dtTanMaster.Columns.Add("Doc_Type", typeof(String));
                dtTanMaster.Columns.Add("Coden", typeof(String));
                dtTanMaster.Columns.Add("Publisher_Family", typeof(String));
                dtTanMaster.Columns.Add("RxnCount", typeof(String));

                dtTanReactions = new DataTable();
                dtTanReactions.Columns.Add("TAN", typeof(String));
                dtTanReactions.Columns.Add("RXN_NUM", typeof(String));
                dtTanReactions.Columns.Add("RXN_SEQ", typeof(String));
                dtTanReactions.Columns.Add("RXN_ID", typeof(String));

                dtTanReactions.Columns.Add("DocRef", typeof(String));
                dtTanReactions.Columns.Add("NarID", typeof(String));
                //dtTanReactions.Columns.Add("AnalogousNumSeq", typeof(String));
                dtTanReactions.Columns.Add("AnalogousNarID", typeof(String));
                dtTanReactions.Columns.Add("PageNo", typeof(String));
                dtTanReactions.Columns.Add("PageLabel", typeof(String));
                dtTanReactions.Columns.Add("XPageSize", typeof(String));
                dtTanReactions.Columns.Add("YPageSize", typeof(String));
                dtTanReactions.Columns.Add("XPageOffset", typeof(String));
                dtTanReactions.Columns.Add("YPageOffset", typeof(String));
                dtTanReactions.Columns.Add("TextLine", typeof(String));
                dtTanReactions.Columns.Add("Para", typeof(String));
                dtTanReactions.Columns.Add("Data", typeof(String));
                
                dtRxn_Substances = new DataTable();
                dtRxn_Substances.Columns.Add("TAN", typeof(String));
                dtRxn_Substances.Columns.Add("RXN_ID", typeof(String));
                dtRxn_Substances.Columns.Add("Substance_ID", typeof(String));
                dtRxn_Substances.Columns.Add("Reg_No", typeof(String));
                dtRxn_Substances.Columns.Add("Role", typeof(String));

                dtFiles = new DataTable();
                dtFiles.Columns.Add("TAN", typeof(String));
                dtFiles.Columns.Add("Type", typeof(String));
                dtFiles.Columns.Add("Name", typeof(String));
                dtFiles.Columns.Add("Id", typeof(String));
                dtFiles.Columns.Add("UUID", typeof(String));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnUpdateToDB_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtTanMaster != null)
                {
                    //Check if Shipment is duplicate
                    ShipmentMasterBO shipMaster = new ShipmentMasterBO();
                    shipMaster.ShipmentName = shipmentName;
                    shipMaster.Application = GlobalVariables.ApplicationName;
                    if (!ShipmentMasterDB.CheckForDuplicateShipment(shipMaster))
                    {
                        Cursor = Cursors.WaitCursor;
                        
                        List<ExpProcedures> lstExpProcTAN = new List<ExpProcedures>(lstExperimProc);
                                                
                        foreach (ExpProcedures objExp in lstExpProcTAN)
                        {
                            objExp.UR_ID = GlobalVariables.URID;

                            //Save Narr Shipment Data in the database
                            string strStatus = ShipmentMasterDB.UpdateExperimentalProcedures_NarrativesShipmentData(objExp, shipmentName, GlobalVariables.ApplicationName);                           
                        }

                        Cursor = Cursors.Default;

                        MessageBox.Show("Experimental Procedures shipment data saved successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Duplicate shipment", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       

        private DataTable GetShipmentTANsFromTextFile(string txtFilePath)
        {
            DataTable dtTans = null;
            try
            {
                if (File.Exists(txtFilePath))//tan-to-casreactCan.txt
                {
                    dtTans = new DataTable();
                    dtTans.Columns.Add("TAN");
                    dtTans.Columns.Add("CAN");
                    dtTans.Columns.Add("DOI");
                    dtTans.Columns.Add("RxnCount");
                    dtTans.Columns.Add("DBStatus");

                    string[] saLines = System.IO.File.ReadAllLines(txtFilePath);
                    if (saLines != null)
                    {
                        for (int i = 1; i < saLines.Length; i++)
                        {
                            var cols = saLines[i].Split('\t');
                            if (cols.Length == 4)
                            {
                                DataRow dr = dtTans.NewRow();
                                dr["TAN"] = cols[0];
                                dr["CAN"] = cols[1];
                                dr["DOI"] = cols[2];
                                dr["RxnCount"] = cols[3];
                                dr["DBStatus"] = "Not Loaded";
                                dtTans.Rows.Add(dr);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }

            return dtTans;
        }

        private DataTable GetTANFileNames_NumSeqsFromFolder(List<string> tansList, string dirPath, out DataTable rxnNumSeqData)
        {
            DataTable dtTANFiles = null;
            DataTable dtTANNum_Seq = null;
            try
            {
                if (tansList != null)
                {
                    dtTANFiles = new DataTable();
                    dtTANFiles.Columns.Add("TAN");
                    dtTANFiles.Columns.Add("File_Name");
                    dtTANFiles.Columns.Add("File_Type");

                    dtTANNum_Seq = new DataTable();
                    dtTANNum_Seq.Columns.Add("TAN");
                    dtTANNum_Seq.Columns.Add("RXN_NUM");
                    dtTANNum_Seq.Columns.Add("RXN_SEQ");

                    string[] saNumSeq = null;
                    string[] saDocs = null;
                    string strReactions = "";
                    string[] saNum_Seq = null;
                    foreach (string tan in lstUniqueTANs)
                    {
                        if (tan == "28572977Z")
                        { 
                        
                        }
                        
                        //Get TAN files
                        string[] saSubDir = Directory.GetDirectories(Path.Combine(dirPath, tan));
                        if (saSubDir != null)
                        {
                            foreach (string dirName in saSubDir)
                            {
                                if (Path.GetFileName(dirName).ToUpper() == "PRIMARY")//Primary Pdf
                                {
                                    saDocs = GetPdfFileNamesFromDirectory(dirName, "PRIMARY");
                                    if (saDocs != null)
                                    {
                                        for (int i = 0; i < saDocs.Length; i++)
                                        {
                                            DataRow dRow = dtTANFiles.NewRow();
                                            dRow["TAN"] = tan;
                                            dRow["File_Name"] = saDocs[i];
                                            dRow["File_Type"] = "PRIMARY";
                                            dtTANFiles.Rows.Add(dRow);
                                        }
                                    }

                                }
                                else if (Path.GetFileName(dirName).ToUpper() == "SUPPORTING")//Supporting PDF
                                {
                                    saDocs = GetPdfFileNamesFromDirectory(dirName, "SUPPORTING");
                                    if (saDocs != null)
                                    {
                                        for (int i = 0; i < saDocs.Length; i++)
                                        {
                                            DataRow dRow = dtTANFiles.NewRow();
                                            dRow["TAN"] = tan;
                                            dRow["File_Name"] = saDocs[i];
                                            dRow["File_Type"] = "SUPPORTING";
                                            dtTANFiles.Rows.Add(dRow);
                                        }
                                    }
                                }
                                else if (Path.GetFileName(dirName).ToUpper() == "TRANSCRIPT")//Reactions RTF file
                                {
                                    strReactions = GetTANReactionsFromRtfFile(Path.Combine(dirName, tan + ".rtf"));

                                    if (!string.IsNullOrEmpty(strReactions))
                                    {
                                        saNumSeq = strReactions.Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
                                        if (saNumSeq != null)
                                        {
                                            foreach (string numSeq in saNumSeq)
                                            {
                                                saNum_Seq = numSeq.Split(new string[] { "  " }, StringSplitOptions.RemoveEmptyEntries);
                                                if (saNum_Seq != null)
                                                {
                                                    DataRow dRow = dtTANNum_Seq.NewRow();
                                                    dRow["TAN"] = tan;
                                                    dRow["RXN_NUM"] = saNum_Seq[0].Trim();
                                                    dRow["RXN_SEQ"] = saNum_Seq[1].Trim();
                                                    dtTANNum_Seq.Rows.Add(dRow);
                                                }
                                            }
                                        }
                                    }
                                }
                                else
                                { 
                                
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            rxnNumSeqData = dtTANNum_Seq;
            return dtTANFiles;
        }

        private string[] GetPdfFileNamesFromDirectory(string dirPath, string fileType)
        {
            string[] saFilenames = null;
            try
            {
                if (Directory.Exists(dirPath))
                {
                    //For Primary document only PDF and for Supporting Documents Pdf/Doc/Docx/Xls/Xlsx
                    string strPattern = fileType.ToUpper() == "PRIMARY" ? @"^.+\.pdf$" : @"^.+\.(pdf|doc|docx|xls|xlsx)$";
                    saFilenames = Directory.GetFiles(dirPath).Where(file => Regex.IsMatch(file, strPattern, RegexOptions.IgnoreCase)).ToArray();            
                    
                    if (saFilenames != null)
                    {
                        if (saFilenames.Length > 0)
                        {
                            ArrayList al = new ArrayList();
                            for (int i = 0; i < saFilenames.Length; i++)
                            {
                                al.Add(System.IO.Path.GetFileName(saFilenames[i]));
                            }
                            al.Sort();
                            if (al.Count >= 7)
                            {

                            }
                            string[] strfiles = new string[al.Count];
                            for (int i = 0; i < al.Count; i++)
                            {
                                strfiles[i] = al[i].ToString();
                            }
                            return strfiles;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return null;
        }
        
        private string GetTANReactionsFromRtfFile(string tanfilepath)
        {
            string strrxnnumbers = "";
            try
            {
                string strTAN = Path.GetFileNameWithoutExtension(tanfilepath);

                #region Word code commented
                // Microsoft.Office.Interop.Word.Application application = new Microsoft.Office.Interop.Word.Application();                
                //object nullobj = System.Reflection.Missing.Value;
                //Document document = wordApp.Documents.Open(tanfilepath, ref nullobj, ref nullobj, ref nullobj, ref nullobj, ref nullobj,
                //                                             ref nullobj, ref nullobj, ref nullobj, ref nullobj, ref nullobj,
                //                                             ref nullobj, ref nullobj, ref nullobj, ref nullobj, ref nullobj);
                //string text = document.Content.Text;
                //wordApp.Documents.Close(); 
                #endregion
            
                richTextBox1.LoadFile(tanfilepath, RichTextBoxStreamType.RichText);
                string text = richTextBox1.Text;

                string strrxncount = "0";
                strrxnnumbers = GetReactionNumberfromString(text, strTAN, out strrxncount);         
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strrxnnumbers;
        }

        private string GetReactionNumberfromString(string strcontent, string strtannumber, out string _reactioncount)
        {
            ArrayList alreactionnums = new ArrayList();

            string[] strcontents = strcontent.Split(new string[1] { "\n" }, StringSplitOptions.None);
            if (strcontents != null && strcontents.Length > 0)
            {
                foreach (string strcon in strcontents)
                {
                    if (strcon.StartsWith(strtannumber) && strcon.Contains("RX("))
                    {
                        alreactionnums.Add(strcon.Trim());
                    }
                }

                if (alreactionnums != null && alreactionnums.Count > 0)
                {
                    string strrxnnumbers = "";
                    for (int i = 0; i < alreactionnums.Count; i++)
                    {
                        if (i == 0)
                            strrxnnumbers = GetRXNNUMBERfromString(alreactionnums[i].ToString());
                        else
                            strrxnnumbers += ";" + GetRXNNUMBERfromString(alreactionnums[i].ToString());

                    }
                    _reactioncount = alreactionnums.Count.ToString();
                    return strrxnnumbers;
                }

            }
            _reactioncount = "0";
            return "";
        }
        
        private string GetRXNNUMBERfromString(string _strrxnnumber)
        {
            string rxnnumber="";
            if (_strrxnnumber != null && _strrxnnumber.Length > 0)
            {
                string[] strrxnnumbers=_strrxnnumber.Split(new string[1]{"  "},StringSplitOptions.None);
                if(strrxnnumbers!=null && strrxnnumbers.Length>0)
                {
                    if(strrxnnumbers.Length > 3)
                    {
                        rxnnumber=strrxnnumbers[1] + " " + strrxnnumbers[2];
                    }                    
                } 
            }
            return rxnnumber;
        }

        private NarrShipmentMasterBO GetTANShipmentDataFromTables(string tan)
        {
            NarrShipmentMasterBO narrShipment = null;
            try
            {
                narrShipment = new NarrShipmentMasterBO();

                narrShipment.ShipmentName = shipmentName;
                narrShipment.Application = GlobalVariables.ApplicationName;

                //Get CAN, DOI info from dtTANs
                var rows = from r in dtTANs.AsEnumerable()
                           where r.Field<string>("TAN") == tan
                           select new
                           {
                               CAN = r.Field<string>("CAN"),
                               DOI = r.Field<string>("DOI")
                           };
                if (rows != null)
                {
                    foreach (var r in rows)
                    {
                        narrShipment.TAN = tan;
                        narrShipment.CAN = r.CAN;
                        narrShipment.DOI = r.DOI;
                        narrShipment.TANType = shipmentType;
                    }
                }

                //Get TAN File Names from dtTANFiles
                var fileNames = (from r in dtTANFiles.AsEnumerable()
                                 where r.Field<string>("TAN") == tan
                                 select r);

                if (fileNames != null)
                {
                    narrShipment.FileNameList = fileNames.AsEnumerable().Select(x => x["File_Name"].ToString()).ToList();
                    narrShipment.FileTypeList = fileNames.AsEnumerable().Select(x => x["File_Type"].ToString()).ToList();
                }

                //Get TAN NUM-Seq from dtTANNumSeq
                var numSeqs = (from r in dtTANNumSeq.AsEnumerable()
                               where r.Field<string>("TAN") == tan
                               select r);

                if (numSeqs != null)
                {
                    narrShipment.RXN_NUMList = numSeqs.AsEnumerable().Select(x => x["RXN_NUM"].ToString()).ToList();
                    narrShipment.RXN_SEQList = numSeqs.AsEnumerable().Select(x => x["RXN_SEQ"].ToString()).ToList();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return narrShipment;
        }
                
        #region Grid Row PostPaint Events
        
        private void dgvTANs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvTANs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvTANs.Font);

                if (dgvTANs.RowHeadersWidth < (int)(size.Width + 20)) dgvTANs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvTANNumSeq_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvTANNumSeq.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvTANNumSeq.Font);

                if (dgvTANNumSeq.RowHeadersWidth < (int)(size.Width + 20)) dgvTANNumSeq.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvTANFiles_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvTANFiles.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvTANFiles.Font);

                if (dgvTANFiles.RowHeadersWidth < (int)(size.Width + 20)) dgvTANFiles.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        } 
        
        private void dgvRxnSubstances_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvRxnSubstances.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvRxnSubstances.Font);

                if (dgvRxnSubstances.RowHeadersWidth < (int)(size.Width + 20)) dgvRxnSubstances.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion
    }
}
