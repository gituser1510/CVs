﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using IndxReactNarrDAL;

namespace IndxReactNarr
{
    public partial class frmDistributeBatch : Form
    {
        public frmDistributeBatch()
        {
            InitializeComponent();
        }

        #region Property Procedures

        public DataTable AvailTANsTbl
        {
            get;
            set;
        }
       
        public DataTable SelectedTANsTbl
        {
            get;
            set;
        }

        #endregion
                
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (SelectedTANsTbl != null)
                {
                    if (SelectedTANsTbl.Rows.Count > 0)
                    {
                        Cursor = Cursors.WaitCursor;

                        //string strShipment = cmbShipment.Text.ToString();
                        //int intBNo = Convert.ToInt32(cmbBatchNo.Text.ToString());
                        //string strTANType = cmbTANType.Text.Trim();
                        //int intUserID = GlobalVariables.UserID;

                        //int intCntr = 0;
                        //string strError = "";

                        List<Int64> list = SelectedTANsTbl.AsEnumerable()
                           .Select(r => r.Field<Int64>("TAN_ID"))
                           .ToList();

                        bool blStatus= ReactDB.Update_TAN_Batch_Details(Convert.ToInt32(cmbBatchNo.SelectedItem), list);
                        //for (int i = 0; i < SelectedTANsTbl.Rows.Count; i++)
                        //{
                        //    //if (CASRxnDataAccess.InsertBatchNameBNoTAN(strShipment, intBNo, SelectedTANsTbl.Rows[i][0].ToString(), intUserID, strTANType))
                        //    //{
                        //    //    intCntr = intCntr + 1;
                        //    //}
                        //    //else
                        //    //{
                        //    //    strError = strError + SelectedTANsTbl.Rows[i][0].ToString();
                        //    //    strError = strError + ";";
                        //    //}
                        //}
                        if (blStatus)
                        {
                            MessageBox.Show("Distributed Batch successfully","Distribute Batch",MessageBoxButtons.OK,MessageBoxIcon.Information);

                            dtselTans = null;
                            SelectedTANsTbl = null;
                            dgvSelTANs.DataSource = null;
                        }
                        else
                        {
                            //strError = strError.TrimEnd(';');
                            MessageBox.Show("Failed to distribute  TANs in the batch", "Distribute Batch", MessageBoxButtons.OK, MessageBoxIcon.Error); 
                        }

                        Cursor = Cursors.Default;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void frmDistBatch_Load(object sender, EventArgs e)
        {
            try
            {
                DataTable dtTAN_Types=null;
                string appName="RXN";
                DataTable  dtShipment_Names=ReactDB.GetShipmentDetailsByAppName(appName,out dtTAN_Types);
                //DataTable dtBatchs = CASRxnDataAccess.GetBatchNames();
                if (dtShipment_Names != null)
                {
                    if (dtShipment_Names.Rows.Count > 0)
                    {
                        cmbShipment.DataSource = dtShipment_Names;
                        cmbShipment.DisplayMember = dtShipment_Names.Columns[1].ColumnName;
                        cmbShipment.ValueMember = dtShipment_Names.Columns[0].ColumnName;
                        cmbShipment.SelectedIndex = 0;

                        cmbBatchNo.SelectedIndex = 0;
                    }
                }

                //DataTable dtDocTypes = CASRxnDataAccess.GetDocTypes();
                if (dtTAN_Types != null)
                {
                    if (dtTAN_Types.Rows.Count > 0)
                    {
                        cmbTANType.DataSource = dtTAN_Types;
                        cmbTANType.DisplayMember = dtTAN_Types.Columns[0].ColumnName;
                        cmbTANType.ValueMember = dtTAN_Types.Columns[0].ColumnName;
                        cmbTANType.SelectedIndex = 0;
                    }
                }
                ////Default TAN type is Patent
                cmbTANType.SelectedIndex = 0;
                GetTANAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void cmbShipment_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                GetTANAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void cmbTANType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                GetTANAndBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetTANAndBindToGrid()
        {
            try
            {
                if (cmbShipment.Text.ToString() != "" && cmbTANType.Text.ToString()!= "")
                {
                
                     DataTable dtTANs = ReactDB.GetTANsOnShipmentName_TANType(cmbShipment.Text.ToString(), cmbTANType.Text.ToString().Trim());
                     dgvAvailTANs.DataSource = null;
                     if (dtTANs != null)
                     {
                         AvailTANsTbl = dtTANs;

                         
                         dgvAvailTANs.DataSource = dtTANs;
                         //dgvAvailTANs.Columns["doctype"].Visible = false;
                     }
                        
               
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        DataTable dtselTans = null;
        private void btnSelOne_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvAvailTANs.Rows.Count > 0)
                {
                    if (dgvAvailTANs.SelectedRows.Count > 0)
                    {
                        if (dtselTans == null)
                        {
                            dtselTans = AvailTANsTbl.Clone();
                        }

                        DataGridViewSelectedRowCollection rcoll_SelTans = dgvAvailTANs.SelectedRows;

                        int rindex_out = 0;
                        for (int i = 0; i < rcoll_SelTans.Count; i++)
                        {
                            dtselTans.ImportRow(GetSelectedRowFromMainTable(rcoll_SelTans[i].Cells[0].Value.ToString(), out rindex_out));
                            AvailTANsTbl.Rows[rindex_out].Delete();
                        }

                        AvailTANsTbl.AcceptChanges();

                        dgvAvailTANs.DataSource = null;
                        dgvAvailTANs.DataSource = AvailTANsTbl;
                        if (dgvAvailTANs.Columns.Contains("doctype"))
                        dgvAvailTANs.Columns["doctype"].Visible = false;

                        SelectedTANsTbl = dtselTans;

                        dgvSelTANs.DataSource = null;
                        dgvSelTANs.DataSource = SelectedTANsTbl;

                        if (dgvSelTANs.Columns.Contains("doctype"))
                        dgvSelTANs.Columns["doctype"].Visible = false;

                       
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private DataRow GetSelectedRowFromMainTable(string _tannumber, out int _rowindex_out)
        {
            try
            {
                if (AvailTANsTbl != null)
                {
                    if (AvailTANsTbl.Rows.Count > 0)
                    {
                        DataRow dtRow = null;
                        for (int i = 0; i < AvailTANsTbl.Rows.Count; i++)
                        {
                            if (AvailTANsTbl.Rows[i][0].ToString() == _tannumber)
                            {
                                dtRow = AvailTANsTbl.Rows[i];
                                _rowindex_out = i;
                                return dtRow;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _rowindex_out = 0;
            return null;
        }

        private DataRow GetSelectedRowFromSelectedTANSTable(string _tannumber, out int _rowindex_out)
        {
            try
            {
                if (SelectedTANsTbl != null)
                {
                    if (SelectedTANsTbl.Rows.Count > 0)
                    {
                        DataRow dtRow = null;
                        for (int i = 0; i < SelectedTANsTbl.Rows.Count; i++)
                        {
                            if (SelectedTANsTbl.Rows[i][0].ToString() == _tannumber)
                            {
                                dtRow = SelectedTANsTbl.Rows[i];
                                _rowindex_out = i;
                                return dtRow;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _rowindex_out = 0;
            return null;
        }

        private void btnDelOne_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvSelTANs.Rows.Count > 0)
                {
                    if (dgvSelTANs.SelectedRows.Count > 0)
                    {
                        DataTable dtAvailTans = AvailTANsTbl;
                        int seltan_out = 0;

                        DataGridViewSelectedRowCollection dgvSelRColl = dgvSelTANs.SelectedRows;

                        for (int i = 0; i < dgvSelRColl.Count; i++)
                        {
                            dtAvailTans.ImportRow(GetSelectedRowFromSelectedTANSTable(dgvSelRColl[i].Cells[0].Value.ToString().ToString(), out seltan_out));
                            SelectedTANsTbl.Rows[seltan_out].Delete();
                        }
                        SelectedTANsTbl.AcceptChanges();

                        AvailTANsTbl = dtAvailTans;

                        dgvAvailTANs.DataSource = null;
                        dgvAvailTANs.DataSource = AvailTANsTbl;
                        if (dgvAvailTANs.Columns.Contains("doctype"))
                        dgvAvailTANs.Columns["doctype"].Visible = false;

                        dgvSelTANs.DataSource = null;
                        dgvSelTANs.DataSource = SelectedTANsTbl;

                        if (dgvSelTANs.Columns.Contains("doctype"))
                        dgvSelTANs.Columns["doctype"].Visible = false;

                        
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dtGrid_TANs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvAvailTANs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvAvailTANs.Font);

                if (dgvAvailTANs.RowHeadersWidth < (int)(size.Width + 20)) dgvAvailTANs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dtGridSelTANs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvSelTANs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvSelTANs.Font);

                if (dgvSelTANs.RowHeadersWidth < (int)(size.Width + 20)) dgvSelTANs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
                
        private void txtTANSrch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (AvailTANsTbl != null)
                {
                    if (txtTANSrch.Text.Trim() != "")
                    {
                        string strFCond = GetFilterCondition(txtTANSrch.Text.Trim());

                        DataTable dtAllTANs = AvailTANsTbl.Copy();
                        DataView dvTemp = dtAllTANs.DefaultView;
                        dvTemp.RowFilter = strFCond;
                        DataTable dtTANs = dvTemp.ToTable();
                        dgvAvailTANs.DataSource = dtTANs;
                    }
                    else
                    {
                        DataTable dtAllTANs = AvailTANsTbl.Copy();
                        dgvAvailTANs.DataSource = dtAllTANs;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetFilterCondition(string _query_tan)
        {
            string strFCond = "";
            try
            {
                if (_query_tan.Trim().Contains(";"))
                {
                    string[] splitter = { ";" };
                    string[] strArrTans = _query_tan.Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);

                    if (strArrTans != null)
                    {
                        if (strArrTans.Length > 0)
                        {
                            for (int i = 0; i < strArrTans.Length; i++)
                            {
                                if (i == 0)
                                {
                                    strFCond = "TAN_NAME Like '" + strArrTans[i] + "%' ";
                                }
                                else
                                {
                                    strFCond += " OR" + " TAN_NAME Like '" + strArrTans[i] + "%'";
                                }
                            }
                        }
                    }
                }
                else
                {
                    strFCond = "TAN_NAME Like '" + _query_tan.Trim() + "%'";
                }
                return strFCond;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strFCond;
        }

       
    }
}
