﻿namespace IndxReactNarr
{
    partial class frmImportExpProcedures2Shipment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtShipmentPath = new System.Windows.Forms.TextBox();
            this.btnBrowseFolder = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.lblFolderPath = new System.Windows.Forms.Label();
            this.dgvTANs = new System.Windows.Forms.DataGridView();
            this.btnUpdatetodb = new System.Windows.Forms.Button();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.tcShipmentDetails = new System.Windows.Forms.TabControl();
            this.tpTANDtls = new System.Windows.Forms.TabPage();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.tpTANNumSeq = new System.Windows.Forms.TabPage();
            this.dgvTANNumSeq = new System.Windows.Forms.DataGridView();
            this.tpTANFiles = new System.Windows.Forms.TabPage();
            this.dgvTANFiles = new System.Windows.Forms.DataGridView();
            this.tpRxnSubstances = new System.Windows.Forms.TabPage();
            this.dgvRxnSubstances = new System.Windows.Forms.DataGridView();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.lblFileCount = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblRxnCount = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblTANCount = new System.Windows.Forms.Label();
            this.lblTANs = new System.Windows.Forms.Label();
            this.pnlTop = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTANs)).BeginInit();
            this.pnlMain.SuspendLayout();
            this.tcShipmentDetails.SuspendLayout();
            this.tpTANDtls.SuspendLayout();
            this.tpTANNumSeq.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTANNumSeq)).BeginInit();
            this.tpTANFiles.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTANFiles)).BeginInit();
            this.tpRxnSubstances.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRxnSubstances)).BeginInit();
            this.pnlBottom.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtShipmentPath
            // 
            this.txtShipmentPath.Location = new System.Drawing.Point(145, 5);
            this.txtShipmentPath.Name = "txtShipmentPath";
            this.txtShipmentPath.Size = new System.Drawing.Size(776, 25);
            this.txtShipmentPath.TabIndex = 3;
            // 
            // btnBrowseFolder
            // 
            this.btnBrowseFolder.Location = new System.Drawing.Point(927, 7);
            this.btnBrowseFolder.Name = "btnBrowseFolder";
            this.btnBrowseFolder.Size = new System.Drawing.Size(36, 23);
            this.btnBrowseFolder.TabIndex = 2;
            this.btnBrowseFolder.Text = "...";
            this.btnBrowseFolder.UseVisualStyleBackColor = true;
            this.btnBrowseFolder.Click += new System.EventHandler(this.btnBrowseFolder_Click);
            // 
            // lblFolderPath
            // 
            this.lblFolderPath.AutoSize = true;
            this.lblFolderPath.Location = new System.Drawing.Point(5, 9);
            this.lblFolderPath.Name = "lblFolderPath";
            this.lblFolderPath.Size = new System.Drawing.Size(134, 17);
            this.lblFolderPath.TabIndex = 4;
            this.lblFolderPath.Text = "Shipment Folder Path";
            // 
            // dgvTANs
            // 
            this.dgvTANs.AllowUserToAddRows = false;
            this.dgvTANs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTANs.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvTANs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTANs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTANs.Location = new System.Drawing.Point(3, 3);
            this.dgvTANs.Name = "dgvTANs";
            this.dgvTANs.ReadOnly = true;
            this.dgvTANs.Size = new System.Drawing.Size(962, 413);
            this.dgvTANs.TabIndex = 5;
            this.dgvTANs.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvTANs_RowPostPaint);
            // 
            // btnUpdatetodb
            // 
            this.btnUpdatetodb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdatetodb.Location = new System.Drawing.Point(840, 1);
            this.btnUpdatetodb.Name = "btnUpdatetodb";
            this.btnUpdatetodb.Size = new System.Drawing.Size(131, 26);
            this.btnUpdatetodb.TabIndex = 6;
            this.btnUpdatetodb.Text = "Save in Database";
            this.btnUpdatetodb.UseVisualStyleBackColor = true;
            this.btnUpdatetodb.Click += new System.EventHandler(this.btnUpdateToDB_Click);
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.tcShipmentDetails);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(976, 516);
            this.pnlMain.TabIndex = 7;
            // 
            // tcShipmentDetails
            // 
            this.tcShipmentDetails.Controls.Add(this.tpTANDtls);
            this.tcShipmentDetails.Controls.Add(this.tpTANNumSeq);
            this.tcShipmentDetails.Controls.Add(this.tpTANFiles);
            this.tcShipmentDetails.Controls.Add(this.tpRxnSubstances);
            this.tcShipmentDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcShipmentDetails.Location = new System.Drawing.Point(0, 37);
            this.tcShipmentDetails.Name = "tcShipmentDetails";
            this.tcShipmentDetails.SelectedIndex = 0;
            this.tcShipmentDetails.Size = new System.Drawing.Size(976, 449);
            this.tcShipmentDetails.TabIndex = 9;
            // 
            // tpTANDtls
            // 
            this.tpTANDtls.Controls.Add(this.dgvTANs);
            this.tpTANDtls.Controls.Add(this.richTextBox1);
            this.tpTANDtls.Location = new System.Drawing.Point(4, 26);
            this.tpTANDtls.Name = "tpTANDtls";
            this.tpTANDtls.Padding = new System.Windows.Forms.Padding(3);
            this.tpTANDtls.Size = new System.Drawing.Size(968, 419);
            this.tpTANDtls.TabIndex = 0;
            this.tpTANDtls.Text = "TAN-CAN-DOI";
            this.tpTANDtls.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(527, 55);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(159, 137);
            this.richTextBox1.TabIndex = 6;
            this.richTextBox1.Text = "";
            // 
            // tpTANNumSeq
            // 
            this.tpTANNumSeq.Controls.Add(this.dgvTANNumSeq);
            this.tpTANNumSeq.Location = new System.Drawing.Point(4, 26);
            this.tpTANNumSeq.Name = "tpTANNumSeq";
            this.tpTANNumSeq.Padding = new System.Windows.Forms.Padding(3);
            this.tpTANNumSeq.Size = new System.Drawing.Size(968, 419);
            this.tpTANNumSeq.TabIndex = 1;
            this.tpTANNumSeq.Text = "TAN-Reactions";
            this.tpTANNumSeq.UseVisualStyleBackColor = true;
            // 
            // dgvTANNumSeq
            // 
            this.dgvTANNumSeq.AllowUserToAddRows = false;
            this.dgvTANNumSeq.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTANNumSeq.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvTANNumSeq.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTANNumSeq.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTANNumSeq.Location = new System.Drawing.Point(3, 3);
            this.dgvTANNumSeq.Name = "dgvTANNumSeq";
            this.dgvTANNumSeq.ReadOnly = true;
            this.dgvTANNumSeq.Size = new System.Drawing.Size(962, 413);
            this.dgvTANNumSeq.TabIndex = 6;
            this.dgvTANNumSeq.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvTANNumSeq_RowPostPaint);
            // 
            // tpTANFiles
            // 
            this.tpTANFiles.Controls.Add(this.dgvTANFiles);
            this.tpTANFiles.Location = new System.Drawing.Point(4, 26);
            this.tpTANFiles.Name = "tpTANFiles";
            this.tpTANFiles.Padding = new System.Windows.Forms.Padding(3);
            this.tpTANFiles.Size = new System.Drawing.Size(968, 419);
            this.tpTANFiles.TabIndex = 2;
            this.tpTANFiles.Text = "TAN-Files";
            this.tpTANFiles.UseVisualStyleBackColor = true;
            // 
            // dgvTANFiles
            // 
            this.dgvTANFiles.AllowUserToAddRows = false;
            this.dgvTANFiles.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTANFiles.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvTANFiles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTANFiles.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTANFiles.Location = new System.Drawing.Point(3, 3);
            this.dgvTANFiles.Name = "dgvTANFiles";
            this.dgvTANFiles.ReadOnly = true;
            this.dgvTANFiles.Size = new System.Drawing.Size(962, 413);
            this.dgvTANFiles.TabIndex = 6;
            this.dgvTANFiles.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvTANFiles_RowPostPaint);
            // 
            // tpRxnSubstances
            // 
            this.tpRxnSubstances.Controls.Add(this.dgvRxnSubstances);
            this.tpRxnSubstances.Location = new System.Drawing.Point(4, 26);
            this.tpRxnSubstances.Name = "tpRxnSubstances";
            this.tpRxnSubstances.Padding = new System.Windows.Forms.Padding(3);
            this.tpRxnSubstances.Size = new System.Drawing.Size(968, 419);
            this.tpRxnSubstances.TabIndex = 3;
            this.tpRxnSubstances.Text = "TAN - Rxn - Substances";
            this.tpRxnSubstances.UseVisualStyleBackColor = true;
            // 
            // dgvRxnSubstances
            // 
            this.dgvRxnSubstances.AllowUserToAddRows = false;
            this.dgvRxnSubstances.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvRxnSubstances.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvRxnSubstances.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRxnSubstances.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvRxnSubstances.Location = new System.Drawing.Point(3, 3);
            this.dgvRxnSubstances.Name = "dgvRxnSubstances";
            this.dgvRxnSubstances.ReadOnly = true;
            this.dgvRxnSubstances.Size = new System.Drawing.Size(962, 413);
            this.dgvRxnSubstances.TabIndex = 7;
            this.dgvRxnSubstances.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvRxnSubstances_RowPostPaint);
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom.Controls.Add(this.lblFileCount);
            this.pnlBottom.Controls.Add(this.label5);
            this.pnlBottom.Controls.Add(this.lblRxnCount);
            this.pnlBottom.Controls.Add(this.label3);
            this.pnlBottom.Controls.Add(this.lblTANCount);
            this.pnlBottom.Controls.Add(this.lblTANs);
            this.pnlBottom.Controls.Add(this.btnUpdatetodb);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 486);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(976, 30);
            this.pnlBottom.TabIndex = 8;
            // 
            // lblFileCount
            // 
            this.lblFileCount.AutoSize = true;
            this.lblFileCount.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFileCount.ForeColor = System.Drawing.Color.Blue;
            this.lblFileCount.Location = new System.Drawing.Point(428, 5);
            this.lblFileCount.Name = "lblFileCount";
            this.lblFileCount.Size = new System.Drawing.Size(16, 17);
            this.lblFileCount.TabIndex = 12;
            this.lblFileCount.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(342, 5);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 17);
            this.label5.TabIndex = 11;
            this.label5.Text = "No.of Files: ";
            // 
            // lblRxnCount
            // 
            this.lblRxnCount.AutoSize = true;
            this.lblRxnCount.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnCount.ForeColor = System.Drawing.Color.Blue;
            this.lblRxnCount.Location = new System.Drawing.Point(281, 5);
            this.lblRxnCount.Name = "lblRxnCount";
            this.lblRxnCount.Size = new System.Drawing.Size(16, 17);
            this.lblRxnCount.TabIndex = 10;
            this.lblRxnCount.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(165, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 17);
            this.label3.TabIndex = 9;
            this.label3.Text = "No.of Reactions: ";
            // 
            // lblTANCount
            // 
            this.lblTANCount.AutoSize = true;
            this.lblTANCount.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTANCount.ForeColor = System.Drawing.Color.Blue;
            this.lblTANCount.Location = new System.Drawing.Point(100, 5);
            this.lblTANCount.Name = "lblTANCount";
            this.lblTANCount.Size = new System.Drawing.Size(16, 17);
            this.lblTANCount.TabIndex = 8;
            this.lblTANCount.Text = "0";
            // 
            // lblTANs
            // 
            this.lblTANs.AutoSize = true;
            this.lblTANs.Location = new System.Drawing.Point(4, 5);
            this.lblTANs.Name = "lblTANs";
            this.lblTANs.Size = new System.Drawing.Size(89, 17);
            this.lblTANs.TabIndex = 7;
            this.lblTANs.Text = "No. of TANs:";
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.txtShipmentPath);
            this.pnlTop.Controls.Add(this.lblFolderPath);
            this.pnlTop.Controls.Add(this.btnBrowseFolder);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(976, 37);
            this.pnlTop.TabIndex = 7;
            // 
            // frmImportExpProceduresShipment_NewPilot
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(976, 516);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmImportExpProceduresShipment_NewPilot";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Experimental Procedures shipment loading";
            this.Load += new System.EventHandler(this.frmImportExpProceduresShipment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTANs)).EndInit();
            this.pnlMain.ResumeLayout(false);
            this.tcShipmentDetails.ResumeLayout(false);
            this.tpTANDtls.ResumeLayout(false);
            this.tpTANNumSeq.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTANNumSeq)).EndInit();
            this.tpTANFiles.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTANFiles)).EndInit();
            this.tpRxnSubstances.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRxnSubstances)).EndInit();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtShipmentPath;
        private System.Windows.Forms.Button btnBrowseFolder;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Label lblFolderPath;
        private System.Windows.Forms.DataGridView dgvTANs;
        private System.Windows.Forms.Button btnUpdatetodb;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.TabControl tcShipmentDetails;
        private System.Windows.Forms.TabPage tpTANDtls;
        private System.Windows.Forms.TabPage tpTANNumSeq;
        private System.Windows.Forms.TabPage tpTANFiles;
        private System.Windows.Forms.DataGridView dgvTANNumSeq;
        private System.Windows.Forms.DataGridView dgvTANFiles;
        private System.Windows.Forms.Label lblFileCount;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblRxnCount;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblTANCount;
        private System.Windows.Forms.Label lblTANs;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.TabPage tpRxnSubstances;
        private System.Windows.Forms.DataGridView dgvRxnSubstances;
    }
}