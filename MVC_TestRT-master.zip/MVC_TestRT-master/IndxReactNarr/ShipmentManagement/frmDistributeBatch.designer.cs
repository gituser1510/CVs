﻿namespace IndxReactNarr
{
    partial class frmDistributeBatch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMain = new System.Windows.Forms.Panel();
            this.lblType = new System.Windows.Forms.Label();
            this.cmbTANType = new System.Windows.Forms.ComboBox();
            this.lblTAN = new System.Windows.Forms.Label();
            this.txtTANSrch = new System.Windows.Forms.TextBox();
            this.pnlButtons = new System.Windows.Forms.Panel();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.cmbBatchNo = new System.Windows.Forms.ComboBox();
            this.lblShipment = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvSelTANs = new System.Windows.Forms.DataGridView();
            this.dgvAvailTANs = new System.Windows.Forms.DataGridView();
            this.btnDelOne = new System.Windows.Forms.Button();
            this.btnSelOne = new System.Windows.Forms.Button();
            this.cmbShipment = new System.Windows.Forms.ComboBox();
            this.lblPhase = new System.Windows.Forms.Label();
            this.pnlMain.SuspendLayout();
            this.pnlButtons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSelTANs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAvailTANs)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.lblType);
            this.pnlMain.Controls.Add(this.cmbTANType);
            this.pnlMain.Controls.Add(this.lblTAN);
            this.pnlMain.Controls.Add(this.txtTANSrch);
            this.pnlMain.Controls.Add(this.pnlButtons);
            this.pnlMain.Controls.Add(this.label2);
            this.pnlMain.Controls.Add(this.label1);
            this.pnlMain.Controls.Add(this.dgvSelTANs);
            this.pnlMain.Controls.Add(this.dgvAvailTANs);
            this.pnlMain.Controls.Add(this.btnDelOne);
            this.pnlMain.Controls.Add(this.btnSelOne);
            this.pnlMain.Controls.Add(this.cmbShipment);
            this.pnlMain.Controls.Add(this.lblPhase);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(477, 567);
            this.pnlMain.TabIndex = 0;
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(279, 9);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(71, 17);
            this.lblType.TabIndex = 34;
            this.lblType.Text = "TAN Type";
            // 
            // cmbTANType
            // 
            this.cmbTANType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTANType.FormattingEnabled = true;
            this.cmbTANType.Items.AddRange(new object[] {
            "Patent",
            "Journal"});
            this.cmbTANType.Location = new System.Drawing.Point(354, 5);
            this.cmbTANType.Name = "cmbTANType";
            this.cmbTANType.Size = new System.Drawing.Size(98, 25);
            this.cmbTANType.TabIndex = 33;
            this.cmbTANType.SelectedIndexChanged += new System.EventHandler(this.cmbTANType_SelectedIndexChanged);
            // 
            // lblTAN
            // 
            this.lblTAN.AutoSize = true;
            this.lblTAN.ForeColor = System.Drawing.Color.Black;
            this.lblTAN.Location = new System.Drawing.Point(1, 33);
            this.lblTAN.Name = "lblTAN";
            this.lblTAN.Size = new System.Drawing.Size(83, 17);
            this.lblTAN.TabIndex = 32;
            this.lblTAN.Text = "TAN Search";
            // 
            // txtTANSrch
            // 
            this.txtTANSrch.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.txtTANSrch.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTANSrch.ForeColor = System.Drawing.Color.Blue;
            this.txtTANSrch.Location = new System.Drawing.Point(4, 52);
            this.txtTANSrch.Multiline = true;
            this.txtTANSrch.Name = "txtTANSrch";
            this.txtTANSrch.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtTANSrch.Size = new System.Drawing.Size(469, 57);
            this.txtTANSrch.TabIndex = 31;
            this.txtTANSrch.TextChanged += new System.EventHandler(this.txtTANSrch_TextChanged);
            // 
            // pnlButtons
            // 
            this.pnlButtons.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlButtons.Controls.Add(this.btnUpdate);
            this.pnlButtons.Controls.Add(this.cmbBatchNo);
            this.pnlButtons.Controls.Add(this.lblShipment);
            this.pnlButtons.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlButtons.Location = new System.Drawing.Point(0, 532);
            this.pnlButtons.Name = "pnlButtons";
            this.pnlButtons.Size = new System.Drawing.Size(477, 35);
            this.pnlButtons.TabIndex = 30;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdate.Location = new System.Drawing.Point(395, 2);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(77, 29);
            this.btnUpdate.TabIndex = 0;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // cmbBatchNo
            // 
            this.cmbBatchNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBatchNo.FormattingEnabled = true;
            this.cmbBatchNo.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cmbBatchNo.Location = new System.Drawing.Point(270, 4);
            this.cmbBatchNo.Name = "cmbBatchNo";
            this.cmbBatchNo.Size = new System.Drawing.Size(70, 25);
            this.cmbBatchNo.TabIndex = 26;
            // 
            // lblShipment
            // 
            this.lblShipment.AutoSize = true;
            this.lblShipment.Location = new System.Drawing.Point(167, 8);
            this.lblShipment.Name = "lblShipment";
            this.lblShipment.Size = new System.Drawing.Size(102, 17);
            this.lblShipment.TabIndex = 25;
            this.lblShipment.Text = "New Batch No.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(271, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 17);
            this.label2.TabIndex = 29;
            this.label2.Text = "Selected TANs";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 17);
            this.label1.TabIndex = 28;
            this.label1.Text = "Available TANs";
            // 
            // dgvSelTANs
            // 
            this.dgvSelTANs.AllowUserToAddRows = false;
            this.dgvSelTANs.AllowUserToDeleteRows = false;
            this.dgvSelTANs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSelTANs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSelTANs.Location = new System.Drawing.Point(271, 132);
            this.dgvSelTANs.Name = "dgvSelTANs";
            this.dgvSelTANs.ReadOnly = true;
            this.dgvSelTANs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSelTANs.Size = new System.Drawing.Size(202, 399);
            this.dgvSelTANs.TabIndex = 24;
            this.dgvSelTANs.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dtGridSelTANs_RowPostPaint);
            // 
            // dgvAvailTANs
            // 
            this.dgvAvailTANs.AllowUserToAddRows = false;
            this.dgvAvailTANs.AllowUserToDeleteRows = false;
            this.dgvAvailTANs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAvailTANs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAvailTANs.Location = new System.Drawing.Point(7, 132);
            this.dgvAvailTANs.Name = "dgvAvailTANs";
            this.dgvAvailTANs.ReadOnly = true;
            this.dgvAvailTANs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAvailTANs.Size = new System.Drawing.Size(193, 399);
            this.dgvAvailTANs.TabIndex = 23;
            this.dgvAvailTANs.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dtGrid_TANs_RowPostPaint);
            // 
            // btnDelOne
            // 
            this.btnDelOne.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelOne.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelOne.Location = new System.Drawing.Point(210, 341);
            this.btnDelOne.Name = "btnDelOne";
            this.btnDelOne.Size = new System.Drawing.Size(51, 32);
            this.btnDelOne.TabIndex = 22;
            this.btnDelOne.Text = "<";
            this.btnDelOne.UseVisualStyleBackColor = true;
            this.btnDelOne.Click += new System.EventHandler(this.btnDelOne_Click);
            // 
            // btnSelOne
            // 
            this.btnSelOne.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSelOne.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelOne.Location = new System.Drawing.Point(210, 273);
            this.btnSelOne.Name = "btnSelOne";
            this.btnSelOne.Size = new System.Drawing.Size(51, 32);
            this.btnSelOne.TabIndex = 21;
            this.btnSelOne.Text = ">";
            this.btnSelOne.UseVisualStyleBackColor = true;
            this.btnSelOne.Click += new System.EventHandler(this.btnSelOne_Click);
            // 
            // cmbShipment
            // 
            this.cmbShipment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbShipment.FormattingEnabled = true;
            this.cmbShipment.Location = new System.Drawing.Point(71, 5);
            this.cmbShipment.Name = "cmbShipment";
            this.cmbShipment.Size = new System.Drawing.Size(190, 25);
            this.cmbShipment.TabIndex = 18;
            this.cmbShipment.SelectedIndexChanged += new System.EventHandler(this.cmbShipment_SelectedIndexChanged);
            // 
            // lblPhase
            // 
            this.lblPhase.AutoSize = true;
            this.lblPhase.Location = new System.Drawing.Point(3, 9);
            this.lblPhase.Name = "lblPhase";
            this.lblPhase.Size = new System.Drawing.Size(62, 17);
            this.lblPhase.TabIndex = 17;
            this.lblPhase.Text = "Shipment";
            // 
            // frmDistributeBatch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(477, 567);
            this.Controls.Add(this.pnlMain);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmDistributeBatch";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Distribute Batch";
            this.Load += new System.EventHandler(this.frmDistBatch_Load);
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.pnlButtons.ResumeLayout(false);
            this.pnlButtons.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSelTANs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAvailTANs)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.ComboBox cmbShipment;
        private System.Windows.Forms.Label lblPhase;
        private System.Windows.Forms.DataGridView dgvSelTANs;
        private System.Windows.Forms.DataGridView dgvAvailTANs;
        private System.Windows.Forms.Button btnDelOne;
        private System.Windows.Forms.Button btnSelOne;
        private System.Windows.Forms.ComboBox cmbBatchNo;
        private System.Windows.Forms.Label lblShipment;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlButtons;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Label lblTAN;
        private System.Windows.Forms.TextBox txtTANSrch;
        private System.Windows.Forms.ComboBox cmbTANType;
        private System.Windows.Forms.Label lblType;
    }
}