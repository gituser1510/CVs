﻿namespace IndxReactNarr
{
    partial class frmImportReactShipment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMain = new System.Windows.Forms.Panel();
            this.tcTANDetails = new System.Windows.Forms.TabControl();
            this.tpTANs = new System.Windows.Forms.TabPage();
            this.dgvTANDetails = new System.Windows.Forms.DataGridView();
            this.tpTANNums = new System.Windows.Forms.TabPage();
            this.dgvTAN_NUMs = new System.Windows.Forms.DataGridView();
            this.tpNUMsInfo = new System.Windows.Forms.TabPage();
            this.dgvNUMsInfo = new System.Windows.Forms.DataGridView();
            this.pnlButtons = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.chkSaveInvFiles = new System.Windows.Forms.CheckBox();
            this.btnSaveExl = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.pnlCntrls = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtFileName = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.foldBrowsDlg = new System.Windows.Forms.FolderBrowserDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.label2 = new System.Windows.Forms.Label();
            this.lblTANsCnt = new System.Windows.Forms.Label();
            this.lblUploadedTANsCnt = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pnlMain.SuspendLayout();
            this.tcTANDetails.SuspendLayout();
            this.tpTANs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTANDetails)).BeginInit();
            this.tpTANNums.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTAN_NUMs)).BeginInit();
            this.tpNUMsInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNUMsInfo)).BeginInit();
            this.pnlButtons.SuspendLayout();
            this.pnlCntrls.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.tcTANDetails);
            this.pnlMain.Controls.Add(this.pnlButtons);
            this.pnlMain.Controls.Add(this.pnlCntrls);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1011, 501);
            this.pnlMain.TabIndex = 0;
            // 
            // tcTANDetails
            // 
            this.tcTANDetails.Controls.Add(this.tpTANs);
            this.tcTANDetails.Controls.Add(this.tpTANNums);
            this.tcTANDetails.Controls.Add(this.tpNUMsInfo);
            this.tcTANDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcTANDetails.Location = new System.Drawing.Point(0, 34);
            this.tcTANDetails.Name = "tcTANDetails";
            this.tcTANDetails.SelectedIndex = 0;
            this.tcTANDetails.Size = new System.Drawing.Size(1011, 430);
            this.tcTANDetails.TabIndex = 3;
            // 
            // tpTANs
            // 
            this.tpTANs.Controls.Add(this.dgvTANDetails);
            this.tpTANs.Location = new System.Drawing.Point(4, 26);
            this.tpTANs.Name = "tpTANs";
            this.tpTANs.Padding = new System.Windows.Forms.Padding(3);
            this.tpTANs.Size = new System.Drawing.Size(1003, 400);
            this.tpTANs.TabIndex = 0;
            this.tpTANs.Text = "TAN-CAN";
            this.tpTANs.UseVisualStyleBackColor = true;
            // 
            // dgvTANDetails
            // 
            this.dgvTANDetails.AllowUserToAddRows = false;
            this.dgvTANDetails.AllowUserToDeleteRows = false;
            this.dgvTANDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTANDetails.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvTANDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTANDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTANDetails.Location = new System.Drawing.Point(3, 3);
            this.dgvTANDetails.Name = "dgvTANDetails";
            this.dgvTANDetails.ReadOnly = true;
            this.dgvTANDetails.Size = new System.Drawing.Size(997, 394);
            this.dgvTANDetails.TabIndex = 0;
            this.dgvTANDetails.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvTANDetails_RowPostPaint);
            // 
            // tpTANNums
            // 
            this.tpTANNums.Controls.Add(this.dgvTAN_NUMs);
            this.tpTANNums.Location = new System.Drawing.Point(4, 26);
            this.tpTANNums.Name = "tpTANNums";
            this.tpTANNums.Padding = new System.Windows.Forms.Padding(3);
            this.tpTANNums.Size = new System.Drawing.Size(1003, 400);
            this.tpTANNums.TabIndex = 1;
            this.tpTANNums.Text = "TAN-NUMs";
            this.tpTANNums.UseVisualStyleBackColor = true;
            // 
            // dgvTAN_NUMs
            // 
            this.dgvTAN_NUMs.AllowUserToAddRows = false;
            this.dgvTAN_NUMs.AllowUserToDeleteRows = false;
            this.dgvTAN_NUMs.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvTAN_NUMs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTAN_NUMs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTAN_NUMs.Location = new System.Drawing.Point(3, 3);
            this.dgvTAN_NUMs.Name = "dgvTAN_NUMs";
            this.dgvTAN_NUMs.ReadOnly = true;
            this.dgvTAN_NUMs.Size = new System.Drawing.Size(997, 394);
            this.dgvTAN_NUMs.TabIndex = 1;
            this.dgvTAN_NUMs.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvTAN_NUMs_RowPostPaint);
            // 
            // tpNUMsInfo
            // 
            this.tpNUMsInfo.Controls.Add(this.dgvNUMsInfo);
            this.tpNUMsInfo.Location = new System.Drawing.Point(4, 26);
            this.tpNUMsInfo.Name = "tpNUMsInfo";
            this.tpNUMsInfo.Size = new System.Drawing.Size(1003, 400);
            this.tpNUMsInfo.TabIndex = 2;
            this.tpNUMsInfo.Text = "NUMs Information";
            this.tpNUMsInfo.UseVisualStyleBackColor = true;
            // 
            // dgvNUMsInfo
            // 
            this.dgvNUMsInfo.AllowUserToAddRows = false;
            this.dgvNUMsInfo.AllowUserToDeleteRows = false;
            this.dgvNUMsInfo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvNUMsInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNUMsInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvNUMsInfo.Location = new System.Drawing.Point(0, 0);
            this.dgvNUMsInfo.Name = "dgvNUMsInfo";
            this.dgvNUMsInfo.ReadOnly = true;
            this.dgvNUMsInfo.Size = new System.Drawing.Size(1003, 400);
            this.dgvNUMsInfo.TabIndex = 2;
            this.dgvNUMsInfo.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvNUMsInfo_RowPostPaint);
            // 
            // pnlButtons
            // 
            this.pnlButtons.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlButtons.Controls.Add(this.lblUploadedTANsCnt);
            this.pnlButtons.Controls.Add(this.label4);
            this.pnlButtons.Controls.Add(this.lblTANsCnt);
            this.pnlButtons.Controls.Add(this.label2);
            this.pnlButtons.Controls.Add(this.button1);
            this.pnlButtons.Controls.Add(this.chkSaveInvFiles);
            this.pnlButtons.Controls.Add(this.btnSaveExl);
            this.pnlButtons.Controls.Add(this.btnSave);
            this.pnlButtons.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlButtons.Location = new System.Drawing.Point(0, 464);
            this.pnlButtons.Name = "pnlButtons";
            this.pnlButtons.Size = new System.Drawing.Size(1011, 37);
            this.pnlButtons.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Location = new System.Drawing.Point(441, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(129, 30);
            this.button1.TabIndex = 5;
            this.button1.Text = "Save RegNos";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            // 
            // chkSaveInvFiles
            // 
            this.chkSaveInvFiles.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chkSaveInvFiles.AutoSize = true;
            this.chkSaveInvFiles.Location = new System.Drawing.Point(634, 9);
            this.chkSaveInvFiles.Name = "chkSaveInvFiles";
            this.chkSaveInvFiles.Size = new System.Drawing.Size(121, 21);
            this.chkSaveInvFiles.TabIndex = 4;
            this.chkSaveInvFiles.Text = "Save TAN wise";
            this.chkSaveInvFiles.UseVisualStyleBackColor = true;
            // 
            // btnSaveExl
            // 
            this.btnSaveExl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSaveExl.Location = new System.Drawing.Point(769, 3);
            this.btnSaveExl.Name = "btnSaveExl";
            this.btnSaveExl.Size = new System.Drawing.Size(94, 30);
            this.btnSaveExl.TabIndex = 3;
            this.btnSaveExl.Text = "Save in File";
            this.btnSaveExl.UseVisualStyleBackColor = true;
            this.btnSaveExl.Click += new System.EventHandler(this.btnSaveExl_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Location = new System.Drawing.Point(877, 2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(129, 30);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "Save in Database";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // pnlCntrls
            // 
            this.pnlCntrls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCntrls.Controls.Add(this.label1);
            this.pnlCntrls.Controls.Add(this.txtFileName);
            this.pnlCntrls.Controls.Add(this.btnBrowse);
            this.pnlCntrls.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlCntrls.Location = new System.Drawing.Point(0, 0);
            this.pnlCntrls.Name = "pnlCntrls";
            this.pnlCntrls.Size = new System.Drawing.Size(1011, 34);
            this.pnlCntrls.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Shipment Folder Path";
            // 
            // txtFileName
            // 
            this.txtFileName.BackColor = System.Drawing.Color.White;
            this.txtFileName.Location = new System.Drawing.Point(146, 4);
            this.txtFileName.Name = "txtFileName";
            this.txtFileName.ReadOnly = true;
            this.txtFileName.Size = new System.Drawing.Size(771, 25);
            this.txtFileName.TabIndex = 1;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(923, 1);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(75, 30);
            this.btnBrowse.TabIndex = 0;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "Total TANs:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblTANsCnt
            // 
            this.lblTANsCnt.AutoSize = true;
            this.lblTANsCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTANsCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblTANsCnt.Location = new System.Drawing.Point(83, 9);
            this.lblTANsCnt.Name = "lblTANsCnt";
            this.lblTANsCnt.Size = new System.Drawing.Size(16, 17);
            this.lblTANsCnt.TabIndex = 7;
            this.lblTANsCnt.Text = "0";
            // 
            // lblUploadedTANsCnt
            // 
            this.lblUploadedTANsCnt.AutoSize = true;
            this.lblUploadedTANsCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUploadedTANsCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblUploadedTANsCnt.Location = new System.Drawing.Point(248, 9);
            this.lblUploadedTANsCnt.Name = "lblUploadedTANsCnt";
            this.lblUploadedTANsCnt.Size = new System.Drawing.Size(16, 17);
            this.lblUploadedTANsCnt.TabIndex = 9;
            this.lblUploadedTANsCnt.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(144, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "Uploaded TANs:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // frmImportReactShipment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1011, 501);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmImportReactShipment";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Load REACT Shipment Data";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmReadCgmFile_Load);
            this.pnlMain.ResumeLayout(false);
            this.tcTANDetails.ResumeLayout(false);
            this.tpTANs.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTANDetails)).EndInit();
            this.tpTANNums.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTAN_NUMs)).EndInit();
            this.tpNUMsInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNUMsInfo)).EndInit();
            this.pnlButtons.ResumeLayout(false);
            this.pnlButtons.PerformLayout();
            this.pnlCntrls.ResumeLayout(false);
            this.pnlCntrls.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlCntrls;
        private System.Windows.Forms.TextBox txtFileName;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlButtons;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.DataGridView dgvTANDetails;
        private System.Windows.Forms.Button btnSaveExl;
        private System.Windows.Forms.CheckBox chkSaveInvFiles;
        private System.Windows.Forms.FolderBrowserDialog foldBrowsDlg;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl tcTANDetails;
        private System.Windows.Forms.TabPage tpTANs;
        private System.Windows.Forms.TabPage tpTANNums;
        private System.Windows.Forms.DataGridView dgvTAN_NUMs;
        private System.Windows.Forms.TabPage tpNUMsInfo;
        private System.Windows.Forms.DataGridView dgvNUMsInfo;
        private System.Windows.Forms.Label lblUploadedTANsCnt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblTANsCnt;
        private System.Windows.Forms.Label label2;
    }
}

