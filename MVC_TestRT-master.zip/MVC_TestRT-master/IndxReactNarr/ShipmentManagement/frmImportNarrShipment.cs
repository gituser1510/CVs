﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using IndxReactNarr.Generic;
using Microsoft.Office.Interop.Word;
using System.Text.RegularExpressions;
using IndxReactNarrBll;
using IndxReactNarrDAL;

namespace IndxReactNarr
{
    public partial class frmImportNarrShipment : Form
    {
        public frmImportNarrShipment()
        {
            InitializeComponent();
        }       
                       
        List<string> lstUniqueTANs = null;      
        DataTable dtTANs = null;
        DataTable dtTANNumSeq = null;
        DataTable dtTANFiles = null;
        string shipmentType = "JOURNAL";
        string shipmentName = "";

        private void frmImportNarrShipment_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void btnBrowseFolder_Click(object sender, EventArgs e)
        {
            try
            {
                if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
                {
                    Cursor = Cursors.WaitCursor;
                    
                    txtShipmentPath.Text = folderBrowserDialog1.SelectedPath;

                    //If Patents, Shipment name contains 'pat' //Ex: rxn-pat-20131209-a
                    shipmentName = Path.GetFileNameWithoutExtension(folderBrowserDialog1.SelectedPath);
                    shipmentType = shipmentName.ToUpper().Contains("-PAT-") ? "PATENT" : "JOURNAL";
                   
                    //TAN-CAN-DOI Details
                    string strTxtFile = Path.Combine(folderBrowserDialog1.SelectedPath,"tan-to-casreactCan.txt");
                    dtTANs = GetShipmentTANsFromTextFile(strTxtFile);
                    dgvTANs.DataSource = dtTANs;

                    //TAN-File Names & NUM-Seq
                    if (dtTANs != null)
                    {
                        lstUniqueTANs = dtTANs.AsEnumerable().Select(x => x["TAN"].ToString()).ToList();
                        dtTANNumSeq = null;
                        dtTANFiles = GetTANFileNames_NumSeqsFromFolder(lstUniqueTANs, folderBrowserDialog1.SelectedPath, out dtTANNumSeq);
                        
                        //Bind Data to grid
                        dgvTANFiles.DataSource = dtTANFiles;
                        dgvTANNumSeq.DataSource = dtTANNumSeq;
                                                
                        //Set Counts
                        lblTANCount.Text = dgvTANs.Rows.Count.ToString();
                        lblFileCount.Text = dgvTANFiles.Rows.Count.ToString();
                        lblRxnCount.Text = dgvTANNumSeq.Rows.Count.ToString();

                        Cursor = Cursors.Default;
                    }                    
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnUpdateToDB_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtTANs != null)
                {
                    //Check if Shipment is duplicate
                    ShipmentMasterBO shipMaster = new ShipmentMasterBO();
                    shipMaster.ShipmentName = shipmentName;
                    shipMaster.Application = GlobalVariables.ApplicationName;
                    if (!ShipmentMasterDB.CheckForDuplicateShipment(shipMaster))
                    {
                        Cursor = Cursors.WaitCursor;

                        NarrShipmentMasterBO narrShipment = null;
                        foreach (DataRow row in dtTANs.Rows)
                        {
                            narrShipment = GetTANShipmentDataFromTables(row["TAN"].ToString());
                            if (narrShipment != null)
                            {
                                narrShipment.UR_ID = GlobalVariables.URID;

                                //Save Narr Shipment Data in the database
                                string strStatus = ShipmentMasterDB.UpdateNarrativesShipmentData(narrShipment);
                                row["DBStatus"] = strStatus;
                            }
                        }

                        Cursor = Cursors.Default;

                        MessageBox.Show("Narratives Shipment data saved successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Duplicate shipment", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       

        private DataTable GetShipmentTANsFromTextFile(string txtFilePath)
        {
            DataTable dtTans = null;
            try
            {
                if (File.Exists(txtFilePath))//tan-to-casreactCan.txt
                {
                    dtTans = new DataTable();
                    dtTans.Columns.Add("TAN");
                    dtTans.Columns.Add("CAN");
                    dtTans.Columns.Add("DOI");
                    dtTans.Columns.Add("RxnCount");
                    dtTans.Columns.Add("DBStatus");

                    string[] saLines = System.IO.File.ReadAllLines(txtFilePath);
                    if (saLines != null)
                    {
                        for (int i = 1; i < saLines.Length; i++)
                        {
                            var cols = saLines[i].Split('\t');
                            if (cols.Length == 4)
                            {
                                DataRow dr = dtTans.NewRow();
                                dr["TAN"] = cols[0];
                                dr["CAN"] = cols[1];
                                dr["DOI"] = cols[2];
                                dr["RxnCount"] = cols[3];
                                dr["DBStatus"] = "Not Loaded";
                                dtTans.Rows.Add(dr);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }

            return dtTans;
        }

        private DataTable GetTANFileNames_NumSeqsFromFolder(List<string> tansList, string dirPath, out DataTable rxnNumSeqData)
        {
            DataTable dtTANFiles = null;
            DataTable dtTANNum_Seq = null;
            try
            {
                if (tansList != null)
                {
                    dtTANFiles = new DataTable();
                    dtTANFiles.Columns.Add("TAN");
                    dtTANFiles.Columns.Add("File_Name");
                    dtTANFiles.Columns.Add("File_Type");

                    dtTANNum_Seq = new DataTable();
                    dtTANNum_Seq.Columns.Add("TAN");
                    dtTANNum_Seq.Columns.Add("RXN_NUM");
                    dtTANNum_Seq.Columns.Add("RXN_SEQ");

                    string[] saNumSeq = null;
                    string[] saDocs = null;
                    string strReactions = "";
                    string[] saNum_Seq = null;
                    foreach (string tan in lstUniqueTANs)
                    {
                        if (tan == "28572977Z")
                        { 
                        
                        }
                        
                        //Get TAN files
                        string[] saSubDir = Directory.GetDirectories(Path.Combine(dirPath, tan));
                        if (saSubDir != null)
                        {
                            foreach (string dirName in saSubDir)
                            {
                                if (Path.GetFileName(dirName).ToUpper() == "PRIMARY")//Primary Pdf
                                {
                                    saDocs = GetPdfFileNamesFromDirectory(dirName, "PRIMARY");
                                    if (saDocs != null)
                                    {
                                        for (int i = 0; i < saDocs.Length; i++)
                                        {
                                            DataRow dRow = dtTANFiles.NewRow();
                                            dRow["TAN"] = tan;
                                            dRow["File_Name"] = saDocs[i];
                                            dRow["File_Type"] = "PRIMARY";
                                            dtTANFiles.Rows.Add(dRow);
                                        }
                                    }

                                }
                                else if (Path.GetFileName(dirName).ToUpper() == "SUPPORTING")//Supporting PDF
                                {
                                    saDocs = GetPdfFileNamesFromDirectory(dirName, "SUPPORTING");
                                    if (saDocs != null)
                                    {
                                        for (int i = 0; i < saDocs.Length; i++)
                                        {
                                            DataRow dRow = dtTANFiles.NewRow();
                                            dRow["TAN"] = tan;
                                            dRow["File_Name"] = saDocs[i];
                                            dRow["File_Type"] = "SUPPORTING";
                                            dtTANFiles.Rows.Add(dRow);
                                        }
                                    }
                                }
                                else if (Path.GetFileName(dirName).ToUpper() == "TRANSCRIPT")//Reactions RTF file
                                {
                                    strReactions = GetTANReactionsFromRtfFile(Path.Combine(dirName, tan + ".rtf"));

                                    if (!string.IsNullOrEmpty(strReactions))
                                    {
                                        saNumSeq = strReactions.Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
                                        if (saNumSeq != null)
                                        {
                                            foreach (string numSeq in saNumSeq)
                                            {
                                                saNum_Seq = numSeq.Split(new string[] { "  " }, StringSplitOptions.RemoveEmptyEntries);
                                                if (saNum_Seq != null)
                                                {
                                                    DataRow dRow = dtTANNum_Seq.NewRow();
                                                    dRow["TAN"] = tan;
                                                    dRow["RXN_NUM"] = saNum_Seq[0].Trim();
                                                    dRow["RXN_SEQ"] = saNum_Seq[1].Trim();
                                                    dtTANNum_Seq.Rows.Add(dRow);
                                                }
                                            }
                                        }
                                    }
                                }
                                else
                                { 
                                
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            rxnNumSeqData = dtTANNum_Seq;
            return dtTANFiles;
        }

        private string[] GetPdfFileNamesFromDirectory(string dirPath, string fileType)
        {
            string[] saFilenames = null;
            try
            {
                if (Directory.Exists(dirPath))
                {
                    //For Primary document only PDF and for Supporting Documents Pdf/Doc/Docx/Xls/Xlsx
                    string strPattern = fileType.ToUpper() == "PRIMARY" ? @"^.+\.pdf$" : @"^.+\.(pdf|doc|docx|xls|xlsx)$";
                    saFilenames = Directory.GetFiles(dirPath).Where(file => Regex.IsMatch(file, strPattern, RegexOptions.IgnoreCase)).ToArray();            
                    
                    if (saFilenames != null)
                    {
                        if (saFilenames.Length > 0)
                        {
                            ArrayList al = new ArrayList();
                            for (int i = 0; i < saFilenames.Length; i++)
                            {
                                al.Add(System.IO.Path.GetFileName(saFilenames[i]));
                            }
                            al.Sort();
                            if (al.Count >= 7)
                            {

                            }
                            string[] strfiles = new string[al.Count];
                            for (int i = 0; i < al.Count; i++)
                            {
                                strfiles[i] = al[i].ToString();
                            }
                            return strfiles;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return null;
        }
        
        private string GetTANReactionsFromRtfFile(string tanfilepath)
        {
            string strrxnnumbers = "";
            try
            {
                string strTAN = Path.GetFileNameWithoutExtension(tanfilepath);

                #region Word code commented
                // Microsoft.Office.Interop.Word.Application application = new Microsoft.Office.Interop.Word.Application();                
                //object nullobj = System.Reflection.Missing.Value;
                //Document document = wordApp.Documents.Open(tanfilepath, ref nullobj, ref nullobj, ref nullobj, ref nullobj, ref nullobj,
                //                                             ref nullobj, ref nullobj, ref nullobj, ref nullobj, ref nullobj,
                //                                             ref nullobj, ref nullobj, ref nullobj, ref nullobj, ref nullobj);
                //string text = document.Content.Text;
                //wordApp.Documents.Close(); 
                #endregion
            
                richTextBox1.LoadFile(tanfilepath, RichTextBoxStreamType.RichText);
                string text = richTextBox1.Text;

                string strrxncount = "0";
                strrxnnumbers = GetReactionNumberfromString(text, strTAN, out strrxncount);         
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strrxnnumbers;
        }

        private string GetReactionNumberfromString(string strcontent, string strtannumber, out string _reactioncount)
        {
            ArrayList alreactionnums = new ArrayList();

            string[] strcontents = strcontent.Split(new string[1] { "\n" }, StringSplitOptions.None);
            if (strcontents != null && strcontents.Length > 0)
            {
                foreach (string strcon in strcontents)
                {
                    if (strcon.StartsWith(strtannumber) && strcon.Contains("RX("))
                    {
                        alreactionnums.Add(strcon.Trim());
                    }
                }

                if (alreactionnums != null && alreactionnums.Count > 0)
                {
                    string strrxnnumbers = "";
                    for (int i = 0; i < alreactionnums.Count; i++)
                    {
                        if (i == 0)
                            strrxnnumbers = GetRXNNUMBERfromString(alreactionnums[i].ToString());
                        else
                            strrxnnumbers += ";" + GetRXNNUMBERfromString(alreactionnums[i].ToString());

                    }
                    _reactioncount = alreactionnums.Count.ToString();
                    return strrxnnumbers;
                }

            }
            _reactioncount = "0";
            return "";
        }
        
        private string GetRXNNUMBERfromString(string _strrxnnumber)
        {
            string rxnnumber="";
            if (_strrxnnumber != null && _strrxnnumber.Length > 0)
            {
                string[] strrxnnumbers=_strrxnnumber.Split(new string[1]{"  "},StringSplitOptions.None);
                if(strrxnnumbers!=null && strrxnnumbers.Length>0)
                {
                    if(strrxnnumbers.Length > 3)
                    {
                        rxnnumber=strrxnnumbers[1] + " " + strrxnnumbers[2];
                    }                    
                } 
            }
            return rxnnumber;
        }

        private NarrShipmentMasterBO GetTANShipmentDataFromTables(string tan)
        {
            NarrShipmentMasterBO narrShipment = null;
            try
            {
                narrShipment = new NarrShipmentMasterBO();

                narrShipment.ShipmentName = shipmentName;
                narrShipment.Application = GlobalVariables.ApplicationName;

                //Get CAN, DOI info from dtTANs
                var rows = from r in dtTANs.AsEnumerable()
                           where r.Field<string>("TAN") == tan
                           select new
                           {
                               CAN = r.Field<string>("CAN"),
                               DOI = r.Field<string>("DOI")
                           };
                if (rows != null)
                {
                    foreach (var r in rows)
                    {
                        narrShipment.TAN = tan;
                        narrShipment.CAN = r.CAN;
                        narrShipment.DOI = r.DOI;
                        narrShipment.TANType = shipmentType;
                    }
                }

                //Get TAN File Names from dtTANFiles
                var fileNames = (from r in dtTANFiles.AsEnumerable()
                                 where r.Field<string>("TAN") == tan
                                 select r);

                if (fileNames != null)
                {
                    narrShipment.FileNameList = fileNames.AsEnumerable().Select(x => x["File_Name"].ToString()).ToList();
                    narrShipment.FileTypeList = fileNames.AsEnumerable().Select(x => x["File_Type"].ToString()).ToList();
                }

                //Get TAN NUM-Seq from dtTANNumSeq
                var numSeqs = (from r in dtTANNumSeq.AsEnumerable()
                               where r.Field<string>("TAN") == tan
                               select r);

                if (numSeqs != null)
                {
                    narrShipment.RXN_NUMList = numSeqs.AsEnumerable().Select(x => x["RXN_NUM"].ToString()).ToList();
                    narrShipment.RXN_SEQList = numSeqs.AsEnumerable().Select(x => x["RXN_SEQ"].ToString()).ToList();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return narrShipment;
        }
                
        #region Grid Row PostPaint Events
        
        private void dgvTANs_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvTANs.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvTANs.Font);

                if (dgvTANs.RowHeadersWidth < (int)(size.Width + 20)) dgvTANs.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvTANNumSeq_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvTANNumSeq.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvTANNumSeq.Font);

                if (dgvTANNumSeq.RowHeadersWidth < (int)(size.Width + 20)) dgvTANNumSeq.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvTANFiles_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvTANFiles.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvTANFiles.Font);

                if (dgvTANFiles.RowHeadersWidth < (int)(size.Width + 20)) dgvTANFiles.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        } 
        
        #endregion
    }
}
