﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Ionic.Zip;
using System.Net;
using IndxReactNarr.Generic;

namespace IndxReactNarr.DataDelivery
{
    public class IndexingDelivery
    {
        public static bool GenerateTANwiseFolders(string outputFolderPath, string pdfFolderPath, string batchName)
        {
            bool blStatus = false;
            try
            {
                if (!string.IsNullOrEmpty(pdfFolderPath))
                {
                    if (Directory.Exists(pdfFolderPath))
                    {
                        //Get distinct TANs from the pdf folder
                        List<string> lstTANs = GetDistinctTANsFromFolder(pdfFolderPath);

                        if (lstTANs != null)
                        {
                            string mainFolder = "";
                            string subFolder = "";
                            List<string> lstTANPdfs = null;
                            //Declare Zip file name
                            using (ZipFile zip = new ZipFile())
                            {
                                zip.CompressionLevel = Ionic.Zlib.CompressionLevel.Level5;
                                zip.AlternateEncoding = Encoding.UTF8;
                                zip.AlternateEncodingUsage = ZipOption.AsNecessary;
                                zip.UseZip64WhenSaving = Zip64Option.AsNecessary;

                                foreach (string tan in lstTANs)
                                {
                                    mainFolder = outputFolderPath + "\\" + tan;
                                    subFolder = outputFolderPath + "\\" + tan + "\\markup";
                                    Directory.CreateDirectory(mainFolder);
                                    Directory.CreateDirectory(subFolder);

                                    //Get TAN markup files
                                    lstTANPdfs = GetTANFileNames(tan, pdfFolderPath);
                                    if (lstTANPdfs != null)
                                    {
                                        if (lstTANPdfs.Count > 0)
                                        {
                                            for (int i = 0; i < lstTANPdfs.Count; i++)
                                            {
                                                File.Move(lstTANPdfs[i], subFolder + "\\Markup " + (i + 1) + "- doc analysis.pdf");
                                            }
                                        }
                                    }

                                    zip.AddDirectory(mainFolder, tan);
                                }

                                zip.Save(outputFolderPath + "\\" + "markups." + batchName + ".zip");
                                blStatus = true;
                            }

                            if (ZipFile.CheckZip(outputFolderPath + "\\" + "markups." + batchName + ".zip"))
                            {
                                blStatus = true;
                            }
                            else
                            {
                                blStatus = false;
                            }

                            ////Check UnZip   
                            //using (ZipFile zip = ZipFile.Read(outputFolderPath + "\\" + "markups." + batchName + ".zip"))
                            //{
                            //    Directory.CreateDirectory(outputFolderPath + "_Unzip");
                            //    zip.ExtractAll(outputFolderPath + "_Unzip", ExtractExistingFileAction.OverwriteSilently);
                            //}
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private static List<string> GetDistinctTANsFromFolder(string pdfFolderPath)
        {
            List<string> lstTANs = null;
            try
            {
                if (!string.IsNullOrEmpty(pdfFolderPath))
                {
                    DirectoryInfo dirInfo = new DirectoryInfo(pdfFolderPath);
                    FileInfo[] faFiles = dirInfo.GetFiles();
                    if (faFiles != null)
                    {
                        lstTANs = new List<string>();
                        //Filename format is TAN_Markup_N.pdf
                        string strTAN = "";
                        foreach (FileInfo f in faFiles)
                        {
                            string[] saFileNames = f.Name.Split(new char[] { '_' });
                            if (saFileNames != null)
                            {
                                if (saFileNames.Length > 0)
                                {
                                    strTAN = saFileNames[0].Trim().ToUpper().Replace(".PDF", "");
                                    if (!string.IsNullOrEmpty(strTAN))
                                    {
                                        if (!lstTANs.Contains(strTAN) && !strTAN.ToUpper().Contains("THUMB"))
                                        {
                                            lstTANs.Add(strTAN);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstTANs;
        }

        private static List<string> GetTANFileNames(string tan, string pdfFolder)
        {
            List<string> lstTANFiles = null;
            try
            {
                if (!string.IsNullOrEmpty(tan) && !string.IsNullOrEmpty(pdfFolder))
                {
                    if (Directory.Exists(pdfFolder))
                    {
                        string[] tanPdfs = Directory.GetFiles(pdfFolder, tan + "*.pdf");
                        if (tanPdfs != null)
                        {
                            lstTANFiles = tanPdfs.ToList();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstTANFiles;
        }

        public bool UploadOutputFilesToFtpServer(List<string> ftpFiles, out string statusMsg)
        {
            bool blStatus = false;
            string strStatus = "";

            FileStream fs = null;
            Stream rs = null;

            try
            {
                if (ftpFiles != null)
                {
                    foreach (string file in ftpFiles)
                    {
                        try
                        {
                            string uploadFileName = new FileInfo(file).Name;

                            string ftpName = "ftp://ftp.cas.org";
                            string ftpPath = "/vol/ftp10/guest/home/gvkbio/incoming/unifiedOrganicProcessing/";
                            string uploadUrl = Path.Combine(ftpName, ftpPath);

                            fs = new FileStream(file, FileMode.Open, FileAccess.Read);

                            string ftpUrl = string.Format("{0}/{1}", uploadUrl, uploadFileName);

                            FtpWebRequest requestObj = FtpWebRequest.Create(ftpUrl) as FtpWebRequest;

                            //Specify the command to be executed
                            requestObj.Method = WebRequestMethods.Ftp.UploadFile;
                            requestObj.KeepAlive = false;//true
                            requestObj.UseBinary = true;

                            //Provide the WebPermission Credintials
                            requestObj.Credentials = new NetworkCredential("usernam", "password");
                            rs = requestObj.GetRequestStream();

                            byte[] buffer = new byte[8092];
                            int read = 0;
                            while ((read = fs.Read(buffer, 0, buffer.Length)) != 0)
                            {
                                rs.Write(buffer, 0, read);
                            }
                            rs.Flush();
                        }
                        catch (Exception ex)
                        {
                            statusMsg = "File upload/transfer Failed.\r\nError Message:\r\n" + ex.Message;
                        }
                    }
                }       
            }
            catch (Exception ex)
            {
               
            }
            finally
            {
                if (fs != null)
                {
                    fs.Close();
                    fs.Dispose();
                }

                if (rs != null)
                {
                    rs.Close();
                    rs.Dispose();
                }
            }
            statusMsg = strStatus;
            return blStatus;
        }
    }
}
