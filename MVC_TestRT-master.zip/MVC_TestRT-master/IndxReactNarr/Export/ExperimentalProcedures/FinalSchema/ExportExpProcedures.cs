﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IndxReactNarr.ExperimentalProceduresExport_V6;
using System.Data;
using IndxReactNarr.Generic;
using IndxReactNarrDAL;
using System.Xml.Serialization;
using System.IO;
using IndxReactNarr.Export.Narratives;

namespace IndxReactNarr.Export.ExperimentalProceduresPilot.FinalSchema
{
    public class ExportExpProcedures
    {
        static DataTable XMLConvTbl = null;
        static DataTable TANsForExport = null;
        static DataTable TAN_Details = null;
        static DataTable TAN_Documents = null;
        static DataTable TAN_Reactions = null;
        static DataTable TAN_Substances = null;
        static DataTable TAN_RxnFindings = null;

        static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
        static string paraSplitter = "``PARA``";
        static string dataSplitter = "``DATA``";

        public static bool ExportTANsToXmlFiles(DataTable tansForExport, string outputFilesPath)
        {
            bool blStatus = true;
            try
            {
                if (tansForExport != null && tansForExport.Rows.Count > 0 && !string.IsNullOrEmpty(outputFilesPath))
                {
                    TANsForExport = tansForExport;
                        
                    //Get Xml Conversions data
                    DataTable xmlReplacements = IndxReactNarrDAL.NarrativesDB.GetSpecialCharsReplacementsOnApplication("NARRATIVES");//GlobalVariables.ApplicationName
                    XMLConvTbl = xmlReplacements.Select("USED_FOR = 'REPLACEMENT'").CopyToDataTable();

                    int tanID = 0;
                    for (int i = 0; i < TANsForExport.Rows.Count; i++)
                    {
                        int.TryParse(TANsForExport.Rows[i]["TAN_ID"].ToString(), out tanID);
                        if (tanID > 0)
                        {
                            TAN_Details = ReactDB.GetTANDetailsOnTANID(tanID);
                            TAN_Reactions = NarrativesDB.GetTANReactionsForExportOnTANID(tanID);
                            TAN_Documents = NarrativesDB.GetTANDocumentsOnTANID(tanID);

                            TAN_Substances = NarrativesDB.GetTANSubstancesOnTANID(tanID);
                            TAN_RxnFindings = NarrativesDB.GetTANFindingsOnTANID(tanID);

                            if (!ExportToXmlFile(outputFilesPath, TAN_Details, TAN_Reactions, TAN_Documents))
                            {
                                blStatus = false;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private static bool ExportToXmlFile(string outfilepath, DataTable tanDetails, DataTable tanReactions, DataTable tanDocuments)
        {
            bool blStatus = false;
            try
            {               
                if (tanDetails != null && tanDetails.Rows.Count > 0)
                {
                    string stTAN = Convert.ToString(tanDetails.Rows[0]["TAN_NAME"]);

                    //Get date and time in US Mountain Standard Time
                    DateTime dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);

                    experimentalprocedure objRxnNarr = new experimentalprocedure();

                    objRxnNarr.version = "1";
                    objRxnNarr.creationtimestamp = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
                    objRxnNarr.document = GetDocumentTypeFromTAN(tanDetails, tanDocuments);
                    objRxnNarr.reactions = GetReactionTypesFromTANReactions(tanReactions);
                    objRxnNarr.concurrentProcessing = false;//Generating with CASREACT simultaneously.

                    //XML Serialization
                    XmlSerializer xmlSer = new XmlSerializer(typeof(experimentalprocedure));

                    outfilepath = outfilepath + "\\" + stTAN + ".xml";
                    using (TextWriter txtWriter = new StreamWriter(outfilepath))
                    {
                        xmlSer.Serialize(txtWriter, objRxnNarr);
                        blStatus = true;

                        txtWriter.Close();
                        txtWriter.Dispose();

                        System.Xml.XmlDocument XDoc = new System.Xml.XmlDocument();

                        XDoc.Load(outfilepath);
                        System.Xml.XmlElement root = XDoc.DocumentElement;
                        root.SetAttribute("noNamespaceSchemaLocation", "http://www.w3.org/2001/XMLSchema-instance", "experimental-procedure-0.6.xsd");

                        XmlRawTextWriter rawWriter = new XmlRawTextWriter(outfilepath, Encoding.UTF8);
                        rawWriter.Formatting = System.Xml.Formatting.Indented;
                        rawWriter.Indentation = 1;
                        rawWriter.IndentChar = '\t';
                        XDoc.Save(rawWriter);

                        rawWriter.Close();

                        //<reactionNarratives xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="ReactionNarrative-1.8.xsd">
                    }

                    //Find and Replace "~~"
                    FindAndReplaceTextInFile(outfilepath);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private static void FindAndReplaceTextInFile(string _xmlfilepath)
        {
            try
            {
                if (!string.IsNullOrEmpty(_xmlfilepath.Trim()))
                {
                    StreamReader streamReader = null;
                    streamReader = File.OpenText(_xmlfilepath);
                    // Now, read the entire file into a strin
                    string contents = streamReader.ReadToEnd();
                    streamReader.Close();

                    // Write the modification into the same file
                    StreamWriter streamWriter = File.CreateText(_xmlfilepath);

                    contents = contents.Replace("~~", "");

                    //New code on 9th Nov 2015
                    contents = contents.Replace("<title />", "<title></title>");
                    contents = contents.Replace("<protocol />", "<protocol></protocol>");
                    contents = contents.Replace("<data-texts />", "<data-texts></data-texts>");

                    streamWriter.Write(contents);                   

                    streamWriter.Close();
                    streamWriter.Dispose();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private static string GetConvertedXmlString(string _xmltag)
        {
            string strConvXml = _xmltag;
            try
            {
                if (!string.IsNullOrEmpty(strConvXml))
                {
                    if (XMLConvTbl != null && XMLConvTbl.Rows.Count > 0)
                    {
                        for (int i = 0; i < XMLConvTbl.Rows.Count; i++)
                        {
                            strConvXml = strConvXml.Replace(XMLConvTbl.Rows[i]["SPECIAL_CHAR"].ToString(), XMLConvTbl.Rows[i]["REPLACEMENT_CHAR"].ToString());
                        }
                    }

                    //Convert < and > in text to junk test
                    strConvXml = strConvXml.Replace("&lt;","_&lt;_");
                    strConvXml = strConvXml.Replace("&gt;", "_&gt;_");

                    //Decode Html
                    strConvXml = System.Web.HttpUtility.HtmlDecode(strConvXml);

                    //Replace &
                    strConvXml = strConvXml.Replace("&", "&amp;");

                    ////Replace <
                    //strConvXml = strConvXml.Replace(" < ", " &lt; ");
                    //strConvXml = strConvXml.Replace("< ", "&lt; ");

                    ////Replace >
                    //strConvXml = strConvXml.Replace(" > ", " &gt; ");
                    //strConvXml = strConvXml.Replace(" >", " &gt;");

                    //Reconvert junk text to < and >
                    strConvXml = strConvXml.Replace("_<_", "&lt;");
                    strConvXml = strConvXml.Replace("_>_", "&gt;");
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strConvXml;
        }

        #region DocumentType Methods

        /// <summary>
        /// Get TAN document type element
        /// </summary>
        /// <param name="tanData"></param>
        /// <param name="tanDocuments"></param>
        /// <returns></returns>
        private static documentType GetDocumentTypeFromTAN(DataTable tanData, DataTable tanDocuments)
        {
            documentType docType = null;
            try
            {
                if (tanData != null && tanData.Rows.Count > 0)
                {
                    docType = new documentType();

                    //Add DocKeys
                    docType.dockeys = GetTANDocKeysInformation(tanData.Rows[0]);

                    //Add Doc Type
                    string tanType = tanData.Rows[0]["TAN_TYPE"].ToString().ToUpper();
                    if (tanType == publicationType.patent.ToString().ToUpper())
                    {
                        docType.doctype = publicationType.patent;
                    }
                    else if (tanType == publicationType.journal.ToString().ToUpper())
                    {
                        docType.doctype = publicationType.journal;
                    }
                    else if (tanType == publicationType.dissertation.ToString().ToUpper())
                    {
                        docType.doctype = publicationType.dissertation;
                    }

                    //Add Coden
                    docType.coden = tanData.Rows[0]["CODEN"].ToString();

                    //Add Publisher
                    docType.publisherfamily = tanData.Rows[0]["PUBLISHER"].ToString();

                    //Add TAN files
                    docType.files = GetTANFiles(tanDocuments);

                    #region Old code commented
                    //List<object> lstDocItems = new List<object>();
                    //List<supplementalType> lstSupplType = null;



                    //switch (tanType.Trim().ToUpper())
                    //{
                    //    case "JOURNAL":
                    //        journalArticleType journalType = GetJournalTypeFromRowData(tanData.Rows[0]);
                    //        lstDocItems.Add(journalType);

                    //        //Only Journals have Supporting documents
                    //        lstSupplType = GetSupplementTypeListFromTANDocuments(tanDocuments);
                    //        break;

                    //    case "PATENT":
                    //        patentType patType = GetpatentTypeFromRowData(tanData.Rows[0]);
                    //        lstDocItems.Add(patType);
                    //        break;

                    //    case "DISSERTATION":
                    //        dissertationType objDisserType = GetDissertationTypeFromRowData(tanData.Rows[0]);
                    //        lstDocItems.Add(objDisserType);
                    //        break;
                    //}

                    //if (lstSupplType != null)
                    //{
                    //    lstDocItems.AddRange(lstSupplType.Cast<object>().ToArray());
                    //}

                    //docType = new documentType();
                    //docType.Items = lstDocItems.Cast<object>().ToArray(); 
                    #endregion
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return docType;
        }

        /// <summary>
        /// Get TAN files
        /// </summary>
        /// <param name="tanDocuments"></param>
        /// <returns></returns>
        private static fileType[] GetTANFiles(DataTable tanDocuments)
        {
            fileType[] oaFiles = null;
            try
            {
                if (tanDocuments != null && tanDocuments.Rows.Count > 0)
                {
                    List<fileType> lstFileTypes = new List<fileType>();

                    foreach (DataRow dr in tanDocuments.Rows)
                    {
                        fileType objFileType = new fileType();
                        objFileType.type = dr["FILE_TYPE"].ToString() == fileTypeSpecifierType.primary.ToString() ? fileTypeSpecifierType.primary : fileTypeSpecifierType.supplemental;
                        objFileType.name = dr["FILE_NAME"].ToString();
                        objFileType.id = dr["FILE_IDENTIFIER"].ToString();

                        if (!string.IsNullOrEmpty(dr["FILE_UU_ID"].ToString()))
                        {
                            objFileType.uuid = dr["FILE_UU_ID"].ToString();
                        }

                        lstFileTypes.Add(objFileType);
                    }

                    //Convert to Array
                    if (lstFileTypes.Count > 0)
                    {
                        oaFiles = lstFileTypes.ToArray();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return oaFiles;
        }

        /// <summary>
        /// Doc Keys information
        /// </summary>
        /// <param name="tanDataRow"></param>
        /// <returns></returns>
        private static documentKeysType GetTANDocKeysInformation(DataRow tanDataRow)
        {
            documentKeysType docKeys = null;
            try
            {
                if (tanDataRow != null && tanDataRow.ItemArray.Length > 0)
                {
                    docKeys = new documentKeysType();
                    docKeys.tan = tanDataRow["TAN_NAME"].ToString();
                    docKeys.can = tanDataRow["CAN"].ToString();

                    if (!string.IsNullOrEmpty(tanDataRow["DOI"].ToString()))
                    {
                        docKeys.doi = tanDataRow["DOI"].ToString();
                    }
                    docKeys.docseq = tanDataRow["DOC_SEQ"].ToString();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return docKeys;
        }

        #endregion

        #region ReactionTypes Methods

        /// <summary>
        /// Get TAN Reactions
        /// </summary>
        /// <param name="tanReactions"></param>
        /// <returns></returns>       
        private static reactionForTemplateType[] GetReactionTypesFromTANReactions(DataTable tanReactions)
        {
            reactionForTemplateType[] oaRxnType = null;
            try
            {
                if (tanReactions != null && tanReactions.Rows.Count > 0)
                {
                    List<reactionForTemplateType> lstRxnType = new List<reactionForTemplateType>();
                    reactionForTemplateType objRxnType = null;

                    string strRxnNum = "";
                    string strRxnSeq = "";

                    int rxnID = 0;
                    int rxnNUM = 0;
                    int rxnSeq = 0;
                    int rxnIdentifier = 0;

                    for (int i = 0; i < tanReactions.Rows.Count; i++)
                    {
                        objRxnType = new reactionForTemplateType();

                        int.TryParse(tanReactions.Rows[i]["RXN_ID"].ToString().Trim(), out rxnID);
                        int.TryParse(tanReactions.Rows[i]["RXN_NUM"].ToString().Trim(), out rxnNUM);
                        int.TryParse(tanReactions.Rows[i]["RXN_SEQ"].ToString().Trim(), out rxnSeq);
                        int.TryParse(tanReactions.Rows[i]["RXN_IDENTIFIER"].ToString().Trim(), out rxnIdentifier);

                        strRxnNum = rxnNUM.ToString("D4");//001 format
                        strRxnSeq = rxnSeq.ToString("D4");

                        //Set Reaction attributes
                        objRxnType.num = strRxnNum;
                        objRxnType.seq = strRxnSeq;
                        objRxnType.rxnid = rxnIdentifier.ToString();

                        //Add Reaction Substances 
                        objRxnType.substances = GetReactionSubstances(rxnID);

                        //Add Reaction Procedure
                        objRxnType.procedure = GetReactionProcedure(tanReactions.Rows[i]);

                        //Add Reaction Template Procedure and DataText
                        objRxnType.template = GetReactionTempalteProcedureData(tanReactions.Rows[i]);


                        //objRxnType.docRef = tanReactions.Rows[i]["DOC_REF"].ToString().Trim();
                        //objRxnType.location = GetLocationTypeFromRowData(tanReactions.Rows[i]);
                        //objRxnType.docText = GetDocumentTextTypeFromRowData(tanReactions.Rows[i]);

                        lstRxnType.Add(objRxnType);
                    }

                    //Convert List to Array
                    if (lstRxnType.Count > 0)
                    {
                        oaRxnType = lstRxnType.ToArray();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return oaRxnType;
        } 
     
        //private static reactionForTemplateType[][] GetReactionTypesFromTANReactions(DataTable tanReactions)
        //{
        //    reactionForTemplateType[][] oaRxnType = null;

        //    try
        //    {
        //        if (tanReactions != null && tanReactions.Rows.Count > 0)
        //        {
        //            List<reactionForTemplateType> lstRxnType = new List<reactionForTemplateType>();
        //            reactionForTemplateType objRxnType = null;

        //            string strRxnNum = "";
        //            string strRxnSeq = "";

        //            int rxnID = 0;
        //            int rxnNUM = 0;
        //            int rxnSeq = 0;
        //            int rxnIdentifier = 0;

        //            oaRxnType = new reactionForTemplateType[1][];

        //            for (int i = 0; i < tanReactions.Rows.Count; i++)
        //            {
        //                objRxnType = new reactionForTemplateType();

        //                int.TryParse(tanReactions.Rows[i]["RXN_ID"].ToString().Trim(), out rxnID);
        //                int.TryParse(tanReactions.Rows[i]["RXN_NUM"].ToString().Trim(), out rxnNUM);
        //                int.TryParse(tanReactions.Rows[i]["RXN_SEQ"].ToString().Trim(), out rxnSeq);
        //                int.TryParse(tanReactions.Rows[i]["RXN_IDENTIFIER"].ToString().Trim(), out rxnIdentifier);

        //                strRxnNum = rxnNUM.ToString("D4");//001 format
        //                strRxnSeq = rxnSeq.ToString("D4");

        //                //Set Reaction attributes
        //                objRxnType.num = strRxnNum;
        //                objRxnType.seq = strRxnSeq;
        //                objRxnType.rxnid = rxnIdentifier.ToString();

        //                //Add Reaction Substances 
        //                objRxnType.substances = GetReactionSubstances(rxnID);

        //                //Add Reaction Procedure
        //                objRxnType.procedure = GetReactionProcedure(tanReactions.Rows[i]);

        //                //Add Reaction Template Procedure and DataText
        //                objRxnType.template = GetReactionTempalteProcedureData(tanReactions.Rows[i]);


        //                //objRxnType.docRef = tanReactions.Rows[i]["DOC_REF"].ToString().Trim();
        //                //objRxnType.location = GetLocationTypeFromRowData(tanReactions.Rows[i]);
        //                //objRxnType.docText = GetDocumentTextTypeFromRowData(tanReactions.Rows[i]);

        //                lstRxnType.Add(objRxnType);
        //            }

        //            //Convert List to Array
        //            if (lstRxnType.Count > 0)
        //            {
        //                oaRxnType[0] = lstRxnType.ToArray();
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return oaRxnType;
        //}

        /// <summary>
        /// Get Reaction Substances
        /// </summary>
        /// <param name="rxnID"></param>
        /// <returns></returns>
        private static substanceType[] GetReactionSubstances(int rxnID)
        {
            substanceType[] saRxnSubstances = null;
            try
            {
                if (TAN_Substances != null && TAN_Substances.Rows.Count > 0 && rxnID > 0)
                {
                    var rows = from r in TAN_Substances.AsEnumerable()
                               where r.Field<Decimal>("RXN_ID") == rxnID
                               select new
                               {
                                   SubstID = r.Field<string>("SUBST_IDENTIFIER"),
                                   SubstRegNo = r.Field<string>("SUBST_REG_NO"),
                                   SubstRole = r.Field<string>("SUBST_ROLE")

                               };

                    if (rows != null)
                    {
                        List<substanceType> lstRxnSubstances = new List<substanceType>();

                        foreach (var r in rows)
                        {
                            substanceType substType = new substanceType();

                            substType.id = r.SubstID;
                            substType.registrynumber = r.SubstRegNo;

                            switch (r.SubstRole.ToUpper())
                            {
                                case "PRODUCT":
                                    substType.role = substanceRoleType.product;
                                    break;
                                case "REACTANT":
                                    substType.role = substanceRoleType.reactant;
                                    break;
                                case "REAGENT":
                                    substType.role = substanceRoleType.reagent;
                                    break;
                                case "SOLVENT":
                                    substType.role = substanceRoleType.solvent;
                                    break;
                                case "CATALYST":
                                    substType.role = substanceRoleType.catalyst;
                                    break;
                            }

                            lstRxnSubstances.Add(substType);
                        }

                        //Convert list to array
                        saRxnSubstances = lstRxnSubstances.ToArray();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return saRxnSubstances;
        }

        /// <summary>
        /// Reaction Template Procedure Data
        /// </summary>
        /// <param name="rxnRow"></param>
        /// <returns></returns>
        private static templatedProcedureType GetReactionTempalteProcedureData(DataRow rxnRow)
        {
            templatedProcedureType rxnProcedure = null;
            try
            {
                if (rxnRow != null)
                {
                    string strRxnProc = rxnRow["PROCEDURE_TEXT"].ToString();
                    if (!string.IsNullOrEmpty(strRxnProc))
                    {
                        rxnProcedure = new templatedProcedureType();

                        //Add Reaction Procedure Title
                        inlineTextFormat inlinetxtFormat = new inlineTextFormat();
                        inlinetxtFormat.Text = new string[] { "Procedure" };
                        rxnProcedure.title = inlinetxtFormat;

                        //Add Reaction Procedure Steps
                        rxnProcedure.protocol = GetReactionProdedureSteps(strRxnProc);

                        //Add Reaction Prodecure Data Text
                        rxnProcedure.datatexts = GetReactionProcedureDataText(Convert.ToInt32(rxnRow["RXN_ID"]));
                    }
                    else if (rxnRow["NO_EXP_DETAILS"].ToString() == "Y")//New update on 7th Nov 2015
                    {
                        //New update on 7th Nov 2015
                        /*. No narrative – No protocol
                            When capturing Experimental Procedures there are two major components, Narrative and Data (characterization information on the product(s) of the reaction).  When converting Experimental Procedures to Reaction Protocols, and there is no narrative present, there will be no templated information to capture for the Reaction Protocol.  The xml for such a situation would simply be reported as:
                             <template>
                                 <protocol></protocol>
                                 <data-texts></data-texts>
                            </template>*/

                        rxnProcedure = new templatedProcedureType();
                        rxnProcedure.title = new inlineTextFormat() { Text = new string[] { "" } };
                        rxnProcedure.protocol = new procedureStepType[1];
                        rxnProcedure.datatexts = new templatedProcedureDataTextsType();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return rxnProcedure;
        }

        /// <summary>
        /// Get Reaction Procedure Steps
        /// </summary>
        /// <param name="procedureText"></param>
        /// <returns></returns>
        private static procedureStepType[] GetReactionProdedureSteps(string procedureText)
        {
            procedureStepType[] rxnProcSteps = null;
            try
            {
                if (!string.IsNullOrEmpty(procedureText))
                {
                    List<procedureStepType> lstRxnProcSteps = new List<procedureStepType>();

                    string[] saRxnProcedure = procedureText.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries);
                    if (saRxnProcedure != null && saRxnProcedure.Length > 0)
                    {
                        int intCntr = 0;
                        procedureStepType procStepType = null;
                        inlineTextFormat inlinetxtFormat = null;
                        string[] saProcSteps = null;

                        foreach (string s in saRxnProcedure)
                        {
                            if (s.Trim().ToUpper() != "NULL")
                            {
                                intCntr++;

                                procStepType = new procedureStepType();
                                procStepType.number = intCntr.ToString();

                                //Add Procedure step
                                saProcSteps = new string[1];
                                saProcSteps[0] = GetConvertedXmlString(s.Trim());                               

                                saProcSteps[0] = FirstCharToUpper(saProcSteps[0]);

                                inlinetxtFormat = new inlineTextFormat();
                                inlinetxtFormat.Text = saProcSteps;
                                inlinetxtFormat.ItemsElementName = new ItemsChoiceType[] { ItemsChoiceType.ital, ItemsChoiceType.bold, ItemsChoiceType.sub, ItemsChoiceType.sup, ItemsChoiceType.smallCap };

                                procStepType.description = inlinetxtFormat;

                                //Add Procedure step to list
                                lstRxnProcSteps.Add(procStepType);
                            }
                        }

                        //Convert List to Array
                        if (lstRxnProcSteps.Count > 0)
                        {
                            rxnProcSteps = lstRxnProcSteps.ToArray();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return rxnProcSteps;
        }

        public static string FirstCharToUpper(string input)
        {
            string strOutput = "";
            if (!String.IsNullOrEmpty(input))
            {
                strOutput = input.First().ToString().ToUpper() + String.Join("", input.Skip(1));
            }
            return strOutput;
        }

        /// <summary>
        /// Get Reaction Procedure Data Text elements
        /// </summary>
        /// <param name="rxnID"></param>
        /// <returns></returns>
        private static templatedProcedureDataTextsType GetReactionProcedureDataText(int rxnID)
        {
            templatedProcedureDataTextsType dataTextsType = new templatedProcedureDataTextsType(); 
           
            try
            {
                if (TAN_RxnFindings != null && TAN_RxnFindings.Rows.Count > 0 && rxnID > 0)
                {
                   // dataTextsType = new templatedProcedureDataTextsType();
                   
                    var rows = from r in TAN_RxnFindings.AsEnumerable()
                               where r.Field<Decimal>("RXN_ID") == rxnID
                               select new
                               {
                                   FindingType = r.Field<string>("FINDING_TYPE"),
                                   FindingValue = r.Field<string>("FINDING_VALUE"),
                                   RefSubstance = r.Field<string>("REFERENCE_SUBSTANCE")
                               };

                    if (rows != null)
                    {
                        List<templatedProcedureDataTextType> lstRxnProcDataText = new List<templatedProcedureDataTextType>();
                        templatedProcedureDataTextType objProcDataText = null;
                        int findingCntr = 0;

                        foreach (var r in rows)
                        {
                            findingCntr = 0;
                            
                            objProcDataText = null;
                            objProcDataText = new templatedProcedureDataTextType();
                            objProcDataText.Text = new string[] { GetConvertedXmlString(r.FindingValue) };
                            //objProcDataText.Text = new string[] { GetConvertedXmlString(r.FindingValue) };
                           
                            switch (r.FindingType.ToString().Trim().ToUpper())
                            {
                                case "SCALE":                                    
                                    objProcDataText.type = templatedProcedureDataItemType.scale;
                                    findingCntr++;
                                    break;

                                case "EQUIPMENT/MATERIALS":                                    
                                    objProcDataText.type = templatedProcedureDataItemType.equipmentmaterials;                                   
                                    findingCntr++;
                                    break;

                                case "SAFETY":                                    
                                    objProcDataText.type = templatedProcedureDataItemType.safety;                                  
                                    findingCntr++;
                                    break;

                                case "BP":                                   
                                    objProcDataText.type = templatedProcedureDataItemType.Bp;                                    
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "CRYSTAL STRUCTURE DATA":                                  
                                    objProcDataText.type = templatedProcedureDataItemType.crystalstructuredata;                                    
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "EE":                                   
                                    objProcDataText.type = templatedProcedureDataItemType.EE;                                   
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "ELEMENTAL ANALYSIS":                                   
                                    objProcDataText.type = templatedProcedureDataItemType.elementalanalysis;                                    
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "HRMS":                                    
                                    objProcDataText.type = templatedProcedureDataItemType.HRMS;                                   
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "IR":                                    
                                    objProcDataText.type = templatedProcedureDataItemType.IR;                               
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "11B NMR":                                    
                                    objProcDataText.type = templatedProcedureDataItemType.Item11BNMR;                                  
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "13C NMR":                                   
                                    objProcDataText.type = templatedProcedureDataItemType.Item13CNMR;                                   
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "15N NMR":                                    
                                    objProcDataText.type = templatedProcedureDataItemType.Item15NNMR;                                
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "19F NMR":                                   
                                    objProcDataText.type = templatedProcedureDataItemType.Item19FNMR;                                   
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "1H NMR":                                   
                                    objProcDataText.type = templatedProcedureDataItemType.Item1HNMR;                                   
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "29SI NMR":                                    
                                    objProcDataText.type = templatedProcedureDataItemType.Item29SiNMR;                                    
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "31P NMR":                                   
                                    objProcDataText.type = templatedProcedureDataItemType.Item31PNMR;                                
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "LD50":                                    
                                    objProcDataText.type = templatedProcedureDataItemType.LD50;                                   
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "LOGD":                                    
                                    objProcDataText.type = templatedProcedureDataItemType.logD;                                   
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "LOGP":                                    
                                    objProcDataText.type = templatedProcedureDataItemType.logP;                                   
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "MIC":                                    
                                    objProcDataText.type = templatedProcedureDataItemType.MIC;                                   
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "MP":                                    
                                    objProcDataText.type = templatedProcedureDataItemType.Mp;                                   
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "M/Z":                                   
                                    objProcDataText.type = templatedProcedureDataItemType.mz;                                   
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "PHYSICAL STATE":                                    
                                    objProcDataText.type = templatedProcedureDataItemType.physicalstate;                              
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "RT":                                   
                                    objProcDataText.type = templatedProcedureDataItemType.Rt;                                    
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "SOLUBILITY":                                   
                                    objProcDataText.type = templatedProcedureDataItemType.solubility;                                    
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "TG":                                   
                                    objProcDataText.type = templatedProcedureDataItemType.Tg;                                    
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "UV/VIS":                                   
                                    objProcDataText.type = templatedProcedureDataItemType.UVvis;                                    
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                //XRay removed in the latest 0.6 xsd
                                //case "XRAY":                                   
                                //    objProcDataText.type = templatedProcedureDataItemType.xray;                                   
                                //    objProcDataText.substanceref = r.RefSubstance;
                                //    findingCntr++;
                                //    break;

                                //case "YIELD":
                                //    objProcDataText = new templatedProcedureDataTextType();
                                //    objProcDataText.type = templatedProcedureDataItemType.yield;
                                //    objProcDataText.Text = new string[] { System.Web.HttpUtility.HtmlDecode((r.FindingValue)) };
                                //    objProcDataText.substanceref = r.RefSubstance;
                                //    break;

                                case "[α]D":
                                case "[A]D":
                                    objProcDataText.type = templatedProcedureDataItemType.αD;                                  
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "DEPT NMR":                                    
                                    objProcDataText.type = templatedProcedureDataItemType.DEPTNMR;                                   
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "DE":
                                    objProcDataText.type = templatedProcedureDataItemType.DE;                                   
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "RF":
                                    objProcDataText.type = templatedProcedureDataItemType.Rf;                                  
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "DEC":
                                    objProcDataText.type = templatedProcedureDataItemType.dec;                                    
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;

                                case "RAMAN":
                                    objProcDataText.type = templatedProcedureDataItemType.raman;                                   
                                    objProcDataText.substanceref = r.RefSubstance;
                                    findingCntr++;
                                    break;
                            }

                            //Add to list
                            if (findingCntr > 0)
                            {
                                lstRxnProcDataText.Add(objProcDataText);
                            }
                        }

                        //convert list to array
                        if (lstRxnProcDataText.Count > 0)
                        {
                             dataTextsType.datatext = lstRxnProcDataText.ToArray();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dataTextsType;
        }

        /// <summary>
        /// Get Reaction Procedure
        /// </summary>
        /// <param name="rxnRowData"></param>
        /// <returns></returns>
        private static procedureForTemplateType GetReactionProcedure(DataRow rxnRowData)
        {
            procedureForTemplateType rxnProcedure = null;
            try
            {
                if (rxnRowData != null)
                {
                    //Code commented on 11th March 2016, for handling empty reactions in Exp.Proc extension work
                    //rxnProcedure = new procedureForTemplateType();                                        
                    ////Get Reaction location
                    //rxnProcedure.location = GetLocationTypeFromRowData(rxnRowData);

                    ////Get Reaction Narrative / Para data
                    //rxnProcedure.narrative = GetNarrativeTypeFromRowData(rxnRowData);

                    ////Ger Reaction data
                    //rxnProcedure.data = GetDataParaTypeFromReactionData(rxnRowData);

                    locationForTemplateType rxnLoc = GetLocationTypeFromRowData(rxnRowData);
                    if (rxnLoc != null)
                    {
                        rxnProcedure = new procedureForTemplateType();

                        //Get Reaction location
                        rxnProcedure.location = rxnLoc;

                        //Get Reaction Narrative / Para data
                        rxnProcedure.narrative = GetNarrativeTypeFromRowData(rxnRowData);

                        //Ger Reaction data
                        rxnProcedure.data = GetDataParaTypeFromReactionData(rxnRowData);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return rxnProcedure;
        }

        #region Location Methods

        private static locationForTemplateType GetLocationTypeFromRowData(DataRow rxnRowData)
        {
            locationForTemplateType locType = null;
            try
            {
                if (rxnRowData != null)
                {
                    if (!string.IsNullOrEmpty(rxnRowData["DOC_REF"].ToString().Trim()) && rxnRowData["DOC_REF"].ToString().Trim() != "doc")
                    {
                        locType = new locationForTemplateType();
                        locType.docref = rxnRowData["DOC_REF"].ToString().Trim();

                        //locType.fileName = rxnRowData["FILE_NAME"].ToString().Trim();

                        pageType pgType = new pageType();
                        pgType.label = rxnRowData["PAGE_LABEL"].ToString().Trim();
                        pgType.number = rxnRowData["PAGE_NO"].ToString().Trim();

                        //X postion
                        pageCoordinateForTemplateType pgCoordTypeX = new pageCoordinateForTemplateType();
                        if (!string.IsNullOrEmpty(rxnRowData["OFFSET_X"].ToString().Trim()))
                        {
                            pgCoordTypeX.offset = Convert.ToDecimal(rxnRowData["OFFSET_X"].ToString().Trim());
                        }
                        if (!string.IsNullOrEmpty(rxnRowData["PAGE_SIZE_X"].ToString().Trim()))
                        {
                            pgCoordTypeX.pagesize = Convert.ToDecimal(rxnRowData["PAGE_SIZE_X"].ToString().Trim());
                        }

                        pgCoordTypeX.Item = GetLengthType("INCH");

                        //Y postion
                        pageCoordinateForTemplateType pgCoordTypeY = new pageCoordinateForTemplateType();
                        if (!string.IsNullOrEmpty(rxnRowData["OFFSET_Y"].ToString().Trim()))
                        {
                            pgCoordTypeY.offset = Convert.ToDecimal(rxnRowData["OFFSET_Y"].ToString().Trim());
                        }
                        if (!string.IsNullOrEmpty(rxnRowData["PAGE_SIZE_Y"].ToString().Trim()))
                        {
                            pgCoordTypeY.pagesize = Convert.ToDecimal(rxnRowData["PAGE_SIZE_Y"].ToString().Trim());
                        }

                        pgCoordTypeY.Item = GetLengthType("INCH");

                        positionForTemplateType posType = new positionForTemplateType();
                        posType.xpos = pgCoordTypeX;
                        posType.ypos = pgCoordTypeY;

                        locType.page = pgType;
                        locType.position = posType;

                        #region Code commented by Sairam on 7th Aug 2014
                        //TextLine
                        //string strTxt = GetConvertedXmlString(rxnRowData["textline"].ToString().Replace("\r\n", "").Replace("\n", "").Trim());
                        //int startB = strTxt.IndexOf("<bold>");
                        //int endB = strTxt.IndexOf("</bold>");
                        //if (startB >= 0 && endB > 0)
                        //{
                        //    string result = strTxt.Substring((startB + "<bold>".Length), (endB - (startB + "<bold>".Length)) - 1);

                        //    inlineTextFormat txtFormatBold = new inlineTextFormat();
                        //    txtFormatBold.ItemsElementName = new ItemsChoiceType[] { ItemsChoiceType.bold };
                        //    txtFormatBold.Text = new string[] { result };

                        //    inlineTextFormat inlinetxtFormat = new inlineTextFormat();
                        //    inlinetxtFormat.Items = new inlineTextFormat[] { txtFormatBold };
                        //    //locType.textLine = inlinetxtFormat;
                        //}
                        //else
                        //{
                        //    string[] saTextLine = new string[1];
                        //    saTextLine[0] = GetConvertedXmlString(rxnRowData["textline"].ToString().Replace("\r\n", "").Replace("\n", "").Trim());

                        //    inlineTextFormat inlinetxtFormat = new inlineTextFormat();
                        //    inlinetxtFormat.Text = saTextLine;                    
                        //    locType.textLine = inlinetxtFormat;               
                        //} 
                        #endregion

                        string[] saTextLine = new string[1];
                        saTextLine[0] = GetConvertedXmlString(rxnRowData["TEXT_LINE"].ToString().Replace("\r\n", "").Replace("\n", "").Trim());

                        inlineTextFormat inlinetxtFormat = new inlineTextFormat();
                        inlinetxtFormat.Text = saTextLine;
                        inlinetxtFormat.ItemsElementName = new ItemsChoiceType[] { ItemsChoiceType.ital, ItemsChoiceType.bold, ItemsChoiceType.sub, ItemsChoiceType.sup, ItemsChoiceType.smallCap };

                        locType.textline = inlinetxtFormat;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return locType;
        }

        private static lengthForTemplateType GetLengthType(string lenthUnits)
        {
            lengthForTemplateType lenType = null;
            try
            {
                if (!string.IsNullOrEmpty(lenthUnits))
                {
                    lenType = new lengthForTemplateType();

                    switch (lenthUnits.ToUpper())
                    {
                        case "INCH":
                            lenType.lenunits = lengthUnitType.inch;
                            break;
                        case "CENTIMETER":
                            lenType.lenunits = lengthUnitType.centimeter;
                            break;
                        case "MILLIMETER":
                            lenType.lenunits = lengthUnitType.millimeter;
                            break;
                        case "POINT":
                            lenType.lenunits = lengthUnitType.point;
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lenType;
        }

        #endregion

        #region Narrative Methods

        //private static docTextType GetDocumentTextTypeFromRowData(DataRow rxnRowData)
        //{
        //    docTextType docTextType = null;
        //    try
        //    {
        //        if (rxnRowData != null)
        //        {
        //            docTextType = new docTextType();
        //            docTextType.narrative = GetNarrativeTypeFromRowData(rxnRowData);
        //            docTextType.data = GetDataParaTypeFromReactionData(rxnRowData);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return docTextType;
        //}

        private static narrativeForTemplateType GetNarrativeTypeFromRowData(DataRow rxnRowData)
        {
            narrativeForTemplateType narrType = null;
            try
            {
                if (rxnRowData != null)
                {
                    string narID = rxnRowData["RXN_NAR_ID"].ToString();

                    narrType = new narrativeForTemplateType();
                    narrType.id = narID;

                    if (rxnRowData["IS_ANALOGOUS"].ToString() == "Y")//!narID.ToUpper().Contains("ANALOGOUSTO=")
                    {
                        int analogRxnID = 0;
                        int.TryParse(rxnRowData["ANALOGOUS_RXN_ID"].ToString(), out analogRxnID);

                        if (analogRxnID > 0)
                        {
                            narrType.analogousto = GetAnalogousRxnNarIDOnRxnID(analogRxnID);
                        }
                    }
                    #region MyRegion
                    //else//Analogous 
                    //{
                    //    //"nar8 analogousTo=nar7"
                    //    string[] saNarrVals = narID.Trim().Split(new string[] { "analogousTo=" }, StringSplitOptions.RemoveEmptyEntries);
                    //    if (saNarrVals != null)
                    //    {
                    //        if (saNarrVals.Length == 2)
                    //        {
                    //            narrType.id = saNarrVals[0].Trim();
                    //            narrType.analogousTo = saNarrVals[1].Trim();
                    //        }
                    //    }                        
                    //} 
                    #endregion

                    narrType.isgeneraltypical = rxnRowData["IS_GENERAL_TYPICAL"].ToString() == "Y" ? true : false;
                    narrType.para = GetParaDataFromReactionData(rxnRowData);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return narrType;
        }

        private static string GetAnalogousRxnNarIDOnRxnID(int anlogRxnID)
        {
            string analogRxnNarID = "";
            try
            {
                if (anlogRxnID > 0)
                {
                    var rows = from r in TAN_Reactions.AsEnumerable()
                               where r.Field<Int64>("RXN_ID") == anlogRxnID
                               select new
                               {
                                   AnalogNarID = r.Field<string>("RXN_NAR_ID")
                               };
                    if (rows != null)
                    {
                        foreach (var r in rows)
                        {
                            analogRxnNarID = r.AnalogNarID;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return analogRxnNarID;
        }

        private static paraForTemplateType[] GetParaDataFromReactionData(DataRow rxnRowData)
        {
            paraForTemplateType[] oaParaType = null;
            try
            {
                if (rxnRowData != null)
                {
                    List<paraForTemplateType> lstPara = lstPara = new List<paraForTemplateType>();
                    paraForTemplateType objPara = null;

                    //No Exp Details - Para 1 Should be empty if No Exp Details
                    if (rxnRowData["NO_EXP_DETAILS"].ToString() == "Y")
                    {
                        objPara = new paraForTemplateType();
                        objPara.Text = new string[] { "~~" };//Add blank para
                        lstPara.Add(objPara);
                    }

                    //Analogous Reaction - Para 1 should be empty and Para 2 should not be empty
                    if (rxnRowData["IS_ANALOGOUS"].ToString() == "Y")
                    {
                        objPara = new paraForTemplateType();
                        objPara.Text = new string[] { "~~" };
                        lstPara.Add(objPara);
                    }

                    string strPara = rxnRowData["PARA_TEXT"].ToString().Trim();

                    if (!string.IsNullOrEmpty(strPara))
                    {
                        string[] saParaVals = strPara.Split(new string[] { paraSplitter }, StringSplitOptions.RemoveEmptyEntries);//"&lt;PARA&gt;"//"\r\n", "\n" 
                        if (saParaVals != null)
                        {
                            foreach (string para in saParaVals)
                            {
                                objPara = new paraForTemplateType();
                                objPara.Text = new string[] { GetConvertedXmlString(para.Trim()) };                           
                                objPara.ItemsElementName = new ItemsChoiceType1[] { ItemsChoiceType1.ital, ItemsChoiceType1.bold, ItemsChoiceType1.sub, ItemsChoiceType1.sup, ItemsChoiceType1.smallCap };

                                lstPara.Add(objPara);
                            }
                        }
                    }
                    else
                    {
                        //In No Exp Details, if no Para is available, then PARA 2 also empty 
                        if (rxnRowData["NO_EXP_DETAILS"].ToString() == "Y")
                        {
                            objPara = new paraForTemplateType();
                            objPara.Text = new string[] { "~~" };//Add blank para
                            lstPara.Add(objPara);
                        }
                    }

                    //Yield Text
                    if (!string.IsNullOrEmpty(rxnRowData["YIELD_TEXT"].ToString().Trim()))
                    {
                        objPara = new paraForTemplateType();
                        objPara.substanceyieldtext = true;

                        objPara.Text = new string[] { GetConvertedXmlString(rxnRowData["YIELD_TEXT"].ToString().Trim()) };                       
                        objPara.ItemsElementName = new ItemsChoiceType1[] { ItemsChoiceType1.ital, ItemsChoiceType1.bold, ItemsChoiceType1.sub, ItemsChoiceType1.sup, ItemsChoiceType1.smallCap };

                        lstPara.Add(objPara);
                    }

                    if (lstPara != null)
                    {
                        oaParaType = lstPara.ToArray();
                    }

                    ////Write para1
                    //intArrIndx++;
                    //paraType para1Type = new paraType();
                    //para1Type.Text = new string[] { GetConvertedXmlString(rxnRowData["para1"].ToString().Trim()) };
                    //para1Type.ItemsElementName = new ItemsChoiceType1[] { ItemsChoiceType1.ital, ItemsChoiceType1.bold, ItemsChoiceType1.sub, ItemsChoiceType1.sup, ItemsChoiceType1.smallCap }; 
                    //oaParaType[intArrIndx] = para1Type;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return oaParaType;
        }

        private static paraType[] GetDataParaTypeFromReactionData(DataRow rxnRowData)
        {
            paraType[] oaDataPara = null;
            try
            {
                if (rxnRowData != null)
                {
                    List<paraType> lstData = null;
                    lstData = new List<paraType>();

                    string strPara = rxnRowData["DATA_TEXT"].ToString().Trim();
                    if (!string.IsNullOrEmpty(strPara))
                    {
                        string[] saParaVals = strPara.Split(new string[] { dataSplitter }, StringSplitOptions.RemoveEmptyEntries);// "\r\n", "\n"
                        if (saParaVals != null)
                        {
                            paraType dataPara = null;
                            foreach (string para in saParaVals)
                            {
                                if (para.Trim().ToUpper() != "NULL")
                                {
                                    dataPara = new paraType();
                                    dataPara.Text = new string[] { GetConvertedXmlString(para.Trim()) };
                                    //dataPara.Text = new string[] { GetConvertedXmlString(para.Trim()) };
                                    dataPara.ItemsElementName = new ItemsChoiceType2[] { ItemsChoiceType2.ital, ItemsChoiceType2.bold, ItemsChoiceType2.sub, ItemsChoiceType2.sup, ItemsChoiceType2.smallCap };

                                    lstData.Add(dataPara);
                                }
                            }
                        }
                    }
                    else
                    {
                        paraType dataPara = new paraType();
                        dataPara.Text = new string[] { "~~" };//Add blank para
                        lstData.Add(dataPara);
                    }

                    //Convert list To Array
                    if (lstData != null)
                    {
                        oaDataPara = lstData.ToArray();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return oaDataPara;
        }

        #endregion

        #endregion
    }
}
