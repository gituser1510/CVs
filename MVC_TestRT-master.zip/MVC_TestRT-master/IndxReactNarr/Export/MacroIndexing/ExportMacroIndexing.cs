﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IndxReactNarr.Generic;
using IndxReactNarr.Common;
using IndxReactNarrDAL;
using System.Data;
using System.IO;
using System.Drawing;
using IndxReactNarrBLL;

namespace IndxReactNarr.Export
{
    public class ExportMacroIndexing
    {
        #region Local & Instance Variables

        public static string textDelimiter = ":: ";
        public static DataTable SplCharReplData = null;
        public static System.Windows.Forms.Label lblFormat = null;
        static Validations objValidations = null;
   
        #endregion

        #region Public variables

        static DataTable dtTANDetails = null;
        static DataTable dtTANKeywords = null;
        static DataTable dtNUMsPAR = null;
        static DataTable dtNUMsCTH = null;
        static IndexingTANInfo objTANInfo = null;

        #endregion

        #region Export DAT file

        /// <summary>
        /// Exports List of TANs to DAT and REP files in the specified location
        /// </summary>
        /// <param name="tanIDsList"></param>
        /// <param name="outputFolderPath"></param>
        /// <param name="fileNameDAT"></param>
        /// <param name="fileNameREP"></param>
        /// <returns></returns>
        public static bool ExportArticleNUMsToDATFile(List<Int32> tanIDsList, string datFileName)
        {
            bool blStatus = false;
            try
            {
                if (tanIDsList != null && !string.IsNullOrEmpty(datFileName))
                {
                    if (tanIDsList.Count > 0)
                    {
                        //Get Greek letters replacements and save in a variable
                        SplCharReplData = NarrativesDB.GetSpecialCharsReplacementsOnApplication(GlobalVariables.ApplicationName);

                        dtTANDetails = null;
                        dtTANKeywords = null;
                        dtNUMsPAR = null;
                        dtNUMsCTH = null;
                        objTANInfo = null;

                        StreamWriter swTAN_DAT = new StreamWriter(datFileName, false, Encoding.UTF8);

                        StringBuilder sbAllTANs = new StringBuilder();
                        StringBuilder sbTANData = null;
                        int TANID = 0;

                        for (int i = 0; i < tanIDsList.Count; i++)
                        {
                            TANID = tanIDsList[i];

                            //Article Info
                            dtTANDetails = ReactDB.GetTANDetailsOnTANID(TANID);
                            if (dtTANDetails != null)
                            {
                                if (dtTANDetails.Rows.Count > 0)
                                {
                                    if (dtTANDetails.Rows[0]["QUERY_TAN"].ToString() == "N")
                                    {
                                        //Article NUMs
                                        dtNUMsPAR = OrganicIndexingDB.GetIndexingNUMsOnTANID(TANID, "NUM_PAR");
                                        dtNUMsCTH = OrganicIndexingDB.GetIndexingNUMsOnTANID(TANID, "NUM_CTH");

                                        if (dtTANDetails != null)
                                        {
                                            if (dtTANDetails.Rows.Count > 0)
                                            {
                                                //Get TAN data and write to DAT file
                                                sbTANData = GetTANInfoAndPARInfoForExport(dtTANDetails, dtTANKeywords, dtNUMsPAR, dtNUMsCTH);
                                                sbAllTANs.Append(sbTANData);
                                                //sbAllTANs.AppendLine(string.Empty);
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        //Write StringBuilder objects data to StreamWriter objects
                        lblFormat = new System.Windows.Forms.Label();
                        lblFormat.Font = new Font("Courier New", 10.0f, FontStyle.Regular);
                        lblFormat.Text = sbAllTANs.ToString();

                        swTAN_DAT.WriteLine(lblFormat.Text.Trim());
                        
                        //Close StreamWriter objects
                        swTAN_DAT.Close();
                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }
        
        /// <summary>
        /// Gets TAN KeyWords
        /// </summary>
        /// <param name="tanKeyWords"></param>
        /// <param name="isReviewTAN"></param>
        /// <returns></returns>
        private static string GetKeywordsStringFromTANKeywords(DataTable tanKeyWords)
        {
            string strKeywords = "";
            try
            {
                if (tanKeyWords != null)
                {          
                    string strKey = "";
                    for (int i = 0; i < tanKeyWords.Rows.Count; i++)
                    {
                        if (tanKeyWords.Rows[i]["KEYWORD"] != null)
                        {
                            if (!string.IsNullOrEmpty(tanKeyWords.Rows[i]["KEYWORD"].ToString().Trim()))
                            {
                                strKey = "KEY" + textDelimiter + tanKeyWords.Rows[i]["KEYWORD"].ToString().Trim();

                                strKeywords = strKeywords.Trim() + "\r\n" + strKey;                                
                            }
                        }
                    }                   
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strKeywords.Trim();
        }
                
        /// <summary>
        /// Gets TAN info StringBuilder
        /// </summary>
        /// <param name="tanDetails"></param>
        /// <param name="tanKeyWords"></param>
        /// <param name="tanPARs"></param>
        /// <returns></returns>
        public static StringBuilder GetTANInfoAndPARInfoForExport(DataTable tanDetails, DataTable tanKeyWords, DataTable tanNUMsPAR, DataTable tanNUMsCTH)
        {
            StringBuilder sbTANData = new StringBuilder();
            try
            {
                if (tanDetails != null)
                {
                    if (tanDetails.Rows.Count > 0)
                    {
                        if (objValidations == null)
                        {
                            objValidations = new Validations();
                        }
                        
                        //Get Greek letters replacements and save in a variable
                        if (SplCharReplData == null)
                        {
                            SplCharReplData = NarrativesDB.GetSpecialCharsReplacementsOnApplication(GlobalVariables.ApplicationName);
                        }

                        //TAN
                        sbTANData.AppendLine("TAN" + textDelimiter + tanDetails.Rows[0]["TAN_NAME"].ToString());
                        sbTANData.AppendLine(string.Empty);

                        //Section-Sub.Section
                        sbTANData.AppendLine("SEC-SUB" + textDelimiter + tanDetails.Rows[0]["TAN_SECTION"].ToString() + "-" + tanDetails.Rows[0]["SUB_SECTION"].ToString().Trim());
                        
                        //Cross Reference
                        if (!string.IsNullOrEmpty(tanDetails.Rows[0]["CROSS_REFERENCE"].ToString()))
                        {
                            sbTANData.AppendLine("CRF" + textDelimiter + tanDetails.Rows[0]["CROSS_REFERENCE"].ToString().Trim());                            
                        }

                        //SPA: HDR
                        if (!string.IsNullOrEmpty(tanDetails.Rows[0]["SPA_HDR"].ToString()))
                        {
                            //if (Convert.ToBoolean(tanDetails.Rows[0]["SPA_HDR"].ToString()))
                            if (tanDetails.Rows[0]["SPA_HDR"].ToString().ToUpper() == "Y")
                            {
                                sbTANData.AppendLine("SPA" + textDelimiter + "HDR");
                            }
                            else//If no graphic issues add empty SPA
                            {
                                sbTANData.AppendLine("SPA" + textDelimiter);
                            }
                        }
                        else//If no graphic issues add empty SPA
                        {
                            sbTANData.AppendLine("SPA" + textDelimiter);
                        }

                        //Title
                        if (!string.IsNullOrEmpty(tanDetails.Rows[0]["TITLE"].ToString()))
                        {
                            //sbTANData.AppendLine("TTL" + textDelimiter + Validations.ConvertSpecialChars(htmlRtfConv.GetRTFfromHTMLString(tanDetails.Rows[0]["TITLE"].ToString().Trim())));
                            sbTANData.AppendLine("TTL" + textDelimiter + Html_RtfConversions.Instance.GetExportFormatStringFromHtmlString(tanDetails.Rows[0]["TITLE"].ToString().Trim()));
                        }

                        //Abstract
                        if (!string.IsNullOrEmpty(tanDetails.Rows[0]["ABSTRACT"].ToString()))
                        {
                            string[] saValues = tanDetails.Rows[0]["ABSTRACT"].ToString().Trim().Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
                            if (saValues != null)
                            {
                                if (saValues.Length > 0)
                                {
                                    foreach (string abs in saValues)
                                    {
                                        if (!string.IsNullOrEmpty(abs))
                                        {
                                            sbTANData.AppendLine("ABS" + textDelimiter + Html_RtfConversions.Instance.GetExportFormatStringFromHtmlString(abs.Trim()));
                                        }
                                    }
                                }
                            }
                        }

                        //Keys
                        tanKeyWords = GetKeysTableFromString(tanDetails.Rows[0]["KEYWORDS"].ToString().Trim());
                        sbTANData.AppendLine(GetKeywordsStringFromTANKeywords(tanKeyWords));
                        sbTANData.AppendLine(string.Empty);
                        
                        //TMD                        
                        string strTMD = "";
                        if (!string.IsNullOrEmpty(tanDetails.Rows[0]["TMD"].ToString()))
                        {
                            strTMD = Html_RtfConversions.Instance.GetExportFormatStringFromHtmlString(tanDetails.Rows[0]["TMD"].ToString().Trim());
                        }

                        string strHMD = "";

                        int tempNUMNote = 0;

                        //NUMs - Regular Series
                        if (tanNUMsPAR != null && tanNUMsPAR.Rows.Count > 0)
                        {
                            for (int i = 0; i < tanNUMsPAR.Rows.Count; i++)
                            {
                                strHMD = "";

                                //NUM
                                sbTANData.AppendLine("NUM" + textDelimiter + tanNUMsPAR.Rows[i]["NUM"].ToString());

                                #region PAR Old code commented
                                //if (!string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["par"].ToString()))
                                //{
                                //    sbTANData.AppendLine("PAR" + textDelimiter + Validations.ConvertSpecialChars(tanNUMsPAR.Rows[i]["par"].ToString()));// RemoveSpecialCharsInString(tanPARs.Rows[i]["PAR"].ToString()));
                                //}
                                //else 
                                //{
                                //    //An index entry for a substance must contain either a PAR field or a NOT field.  
                                //    //If you do not supply the substance name in the PAR field, you must add the NOT field and place “NN” in that filed indicating that no-name is being supplied.

                                //    sbTANData.AppendLine("NOT" + textDelimiter + "NN");
                                //} 
                                #endregion

                                //PAR
                                //PAR/REG/MOL for substances - 27th March 2014
                                //1.If a REG is returned, leave the PAR field blank and add NOT:: NN (required for a blank PAR field)
                                //2.If a MOL file is returned, leave the PAR field blank and add NOT:: NN (required for a blank PAR field)
                                //3.If the substance is in the exclusion list (no REG and no MOL file is returned), add the name to the PAR field. Please note the substance name should be as accurate as possible, including substituent groups and spaces. Please note usually the addition editing is required if the substance names from authors are used.
                                //In all cases, NMO:: NNM is always required

                                //An index entry for a substance must contain either a PAR field or a NOT field.  
                                //If you do not supply the substance name in the PAR field, you must add the NOT field and place “NN” in that filed indicating that no-name is being supplied.

                                #region Code commented on 28th Aug 2014, Need to finalize
                                // if (!string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["REG_NO"].ToString()) || !string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["MOL_FILE"].ToString())
                                //     || tanNUMsPAR.Rows[i]["IS_POLYMER"].ToString() == "Y")
                                // {                                       
                                //     sbTANData.AppendLine("NOT" + textDelimiter + "NN");
                                // }
                                //// else if (tanNUMsPAR.Rows[i]["NO_STRUCT"].ToString().ToUpper() == "Y")
                                //// {
                                //     sbTANData.AppendLine("PAR" + textDelimiter + htmlRtfConv.GetExportFormatStringFromHtmlString(tanNUMsPAR.Rows[i]["PAR"].ToString().Trim()));                                      
                                //// }  
                                #endregion

                                //If RegNo is not available NOT is mandatory - means regular compound
                                //If RegNo, MolFile and PAR fields are blank and Note field exist, then NMO::NN, PRO::FR should not exist
                                if ((string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["REG_NO"].ToString()) && string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["PAR"].ToString()) &&
                                   string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["MOL_FILE"].ToString())) && !string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["NUM_NOTE"].ToString()))
                                {
                                    sbTANData.AppendLine("NOT" + textDelimiter + tanNUMsPAR.Rows[i]["NUM_NOTE"].ToString());
                                }
                                else if (string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["REG_NO"].ToString()) && tanNUMsPAR.Rows[i]["IS_TRADE_NAME_POLYMER"].ToString() == "N")
                                {
                                    //17th Dec 2015, If Reg.No is null and Note contains Reg.No, PAR should exits
                                    tempNUMNote = 0;
                                    if (!int.TryParse(tanNUMsPAR.Rows[i]["NUM_NOTE"].ToString(), out tempNUMNote))
                                    {
                                        sbTANData.AppendLine("NOT" + textDelimiter + "NN");
                                    }
                                                                        
                                    //sbTANData.AppendLine("NOT" + textDelimiter + "NN");
                                }

                                //New modification on 18th Sep 2014
                                //PRO::FR is for Trade Name Polymer & Reg.No is Null
                                if (tanNUMsPAR.Rows[i]["IS_TRADE_NAME_POLYMER"].ToString() == "Y" && tanNUMsPAR.Rows[i]["IS_CROSS_REF"].ToString() == "Y")
                                {
                                    //sbTANData.AppendLine("PRO" + textDelimiter + "FR");

                                    //New modification on 11th March 2015
                                    //Trade Named Polymers: 
                                    //Case I: PRO:: FR Tag for PAR with Trade Name and NOT field with text
                                    //Case II: No PRO:: FR Tag for PAR with Trade Name and NOT field with REG number
                                    tempNUMNote = 0;
                                    if (!int.TryParse(tanNUMsPAR.Rows[i]["NUM_NOTE"].ToString(), out tempNUMNote))
                                    {
                                        sbTANData.AppendLine("PRO" + textDelimiter + "FR");
                                    }
                                }
                                else if (tanNUMsPAR.Rows[i]["IS_TRADE_NAME_POLYMER"].ToString() == "Y")//New validation on 28th Apr 2015
                                {
                                    //Case I: PRO:: FR Tag for PAR with Trade Name and NOT field with text (Trade Name Polymer is flagged) 
                                    //Case II: No PRO:: FR Tag for PAR with Trade Name and NOT field with REG number (Trade Name Polymer is flagged) 

                                    tempNUMNote = 0;
                                    if (!int.TryParse(tanNUMsPAR.Rows[i]["NUM_NOTE"].ToString(), out tempNUMNote) &&
                                        !tanNUMsPAR.Rows[i]["NUM_NOTE"].ToString().ToUpper().StartsWith("FR,"))//FR - validation on 13th May 2015
                                    {
                                        sbTANData.AppendLine("PRO" + textDelimiter + "FR");
                                    }
                                }

                                //Code commented on 16th Apr 2015
                                ////PAR is mandatory
                                //sbTANData.AppendLine("PAR" + textDelimiter + htmlRtfConv.GetExportFormatStringFromHtmlString(tanNUMsPAR.Rows[i]["PAR"].ToString().Trim()));

                                //Organic Indexing validation note
                                //An index entry for a substance must contain either a PAR field or a NOT field. --This validation should be removed for Macro Indexing - 17th Apr 2015
                                //If you do not supply the substance name in the PAR field, you must add the NOT field and place “NN” in that filed indicating that no-name is being supplied.

                                //New modifiation on 16the Apr 2015
                                //We have noticed that often an index entry is provided to us with both a name in the PAR field as well as a mol file. 
                                //Please note that a chemical name should not be present in the PAR field if a mol file or registry number is returned for that index entry.
                                //If the index entry contains an excluded substance (a blank mol file), the PAR field should only be used for correctly formatted polymer names, as appropriate.  
                                //Please use author nomenclature for monomers used in polymer names in the PAR field, and do not use monomer names constructed from systematic names found in STN or SciFinder. 
                                //Any other necessary structural information for excluded substances should be indicated in the NOT field. Please let us know if you have any questions or concerns about this format.

                                //New validation on 17th Apr 2015
                                //If Polymer flag or No Structure flag is there PAR field or NOT field is mandatory, even if it contains reg.no or not. (mandatory-first requirement).
                                //If Reg.No is there then PAR field and NOT field is not required.
                                //If SDF/MOL is there PAR and NOT not required.
                                //If PAR, Reg.No., SDF/MOL not there NOT field should be visible.

                                if (tanNUMsPAR.Rows[i]["IS_POLYMER"].ToString() == "Y" || tanNUMsPAR.Rows[i]["NO_STRUCT"].ToString().ToUpper() == "Y")
                                {
                                    if (!string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["PAR"].ToString()))
                                    {
                                        sbTANData.AppendLine("PAR" + textDelimiter + Html_RtfConversions.Instance.GetExportFormatStringFromHtmlString(tanNUMsPAR.Rows[i]["PAR"].ToString().Trim()));
                                    }
                                    //else if (!string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["NUM_NOTE"].ToString()))//removed on 25th Aug 2015
                                    //{                                        
                                    //    sbTANData.AppendLine("NOT" + textDelimiter + tanNUMsPAR.Rows[i]["NUM_NOTE"].ToString());
                                    //}
                                }
                                else if (string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["REG_NO"].ToString()))//17th Dec 2015, If Reg.No is null and Note contains Reg.No, PAR should exits
                                {
                                    tempNUMNote = 0;
                                    if (int.TryParse(tanNUMsPAR.Rows[i]["NUM_NOTE"].ToString(), out tempNUMNote) && !string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["PAR"].ToString()))
                                    {
                                        sbTANData.AppendLine("PAR" + textDelimiter + Html_RtfConversions.Instance.GetExportFormatStringFromHtmlString(tanNUMsPAR.Rows[i]["PAR"].ToString().Trim()));
                                    }
                                }

                                //else if (!string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["REG_NO"].ToString()) || !string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["MOL_FILE"].ToString()))
                                //{
                                //    sbTANData.AppendLine("NOT" + textDelimiter + "NN");
                                //}
                                //else if (tanNUMsPAR.Rows[i]["NO_STRUCT"].ToString().ToUpper() == "Y")
                                //{
                                //    sbTANData.AppendLine("PAR" + textDelimiter + htmlRtfConv.GetExportFormatStringFromHtmlString(tanNUMsPAR.Rows[i]["PAR"].ToString().Trim()));
                                //}   

                                //HMD
                                if (!string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["HMD"].ToString()))
                                {
                                    strHMD = Validations.ConvertSpecialChars(tanNUMsPAR.Rows[i]["HMD"].ToString().Trim());
                                    sbTANData.AppendLine("HMD" + textDelimiter + strHMD);
                                }

                                //AMD
                                if (!string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["AMD"].ToString()))
                                {
                                    sbTANData.AppendLine("AMD" + textDelimiter + Validations.ConvertSpecialChars(tanNUMsPAR.Rows[i]["AMD"].ToString().Trim()));
                                }

                                //New modification on 18th Sep 2014
                                //NOT:: if for Trade Name Polymer and Cross Referenced to CROSS_REF_POLYMER
                                if (tanNUMsPAR.Rows[i]["IS_CROSS_REF"].ToString() == "Y")
                                {
                                    string crossRefPoly = Validations.ConvertSpecialChars(tanNUMsPAR.Rows[i]["CROSS_REF_POLYMER"].ToString().Trim());

                                    string strNote = "";
                                    //If Cross Referenced and RegNo is not null, then keep RegNo in Note
                                    strNote = !string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["REG_NO"].ToString()) ? tanNUMsPAR.Rows[i]["REG_NO"].ToString() : "NN";

                                    strNote = !string.IsNullOrEmpty(strNote.Trim()) ? strNote.Trim() + "," + " x-ref " + strHMD + " to " + crossRefPoly : " x-ref " + strHMD + " to " + crossRefPoly;
                                    sbTANData.AppendLine("NOT" + textDelimiter + strNote.Trim());
                                }
                                else if (tanNUMsPAR.Rows[i]["IS_TRADE_NAME_POLYMER"].ToString() == "Y" && tanNUMsPAR.Rows[i]["IS_CROSS_REF"].ToString() == "N")
                                {
                                    string strNote = "";
                                    strNote = !string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["REG_NO"].ToString()) ? tanNUMsPAR.Rows[i]["REG_NO"].ToString() : "";

                                    strNote = !string.IsNullOrEmpty(strNote.Trim()) ? strNote.Trim() + "," + tanNUMsPAR.Rows[i]["NUM_NOTE"].ToString() : tanNUMsPAR.Rows[i]["NUM_NOTE"].ToString();

                                    sbTANData.AppendLine("NOT" + textDelimiter + strNote);
                                }
                                else if (string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["REG_NO"].ToString()))//17th Dec 2015, If Reg.No is null and Note contains Reg.No, PAR should exits
                                {
                                    tempNUMNote = 0;
                                    if (int.TryParse(tanNUMsPAR.Rows[i]["NUM_NOTE"].ToString(), out tempNUMNote)) 
                                    {
                                        sbTANData.AppendLine("NOT" + textDelimiter + tanNUMsPAR.Rows[i]["NUM_NOTE"].ToString());
                                    }
                                }

                                //Role
                                if (!string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["NUM_ROLE"].ToString()))
                                {
                                    sbTANData.AppendLine("ROL" + textDelimiter + tanNUMsPAR.Rows[i]["NUM_ROLE"].ToString().Trim());
                                }

                                //If NUM TMD is available then take NUM TMD else regular TMD
                                if (!string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["NUM_TMD"].ToString()))
                                {
                                    //TMD
                                    sbTANData.AppendLine("TMD" + textDelimiter + Html_RtfConversions.Instance.GetExportFormatStringFromHtmlString(tanNUMsPAR.Rows[i]["NUM_TMD"].ToString().Trim()));
                                }
                                else //if CTH type is MolStructure/Crystal Structure, add CTH TMD
                                {
                                    sbTANData.AppendLine("TMD" + textDelimiter + strTMD);
                                }

                                //RegistryNo
                                if (!string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["REG_NO"].ToString()))
                                {
                                    //RegistryNo
                                    if (tanNUMsPAR.Rows[i]["IS_TRADE_NAME_POLYMER"].ToString() == "N" || tanNUMsPAR.Rows[i]["IS_CROSS_REF"].ToString() == "N")
                                    {
                                        sbTANData.AppendLine("REG" + textDelimiter + tanNUMsPAR.Rows[i]["REG_NO"].ToString().Trim());
                                    }

                                    //DPT RS
                                    if (!string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["DPT_RS"].ToString()))
                                    {
                                        if (tanNUMsPAR.Rows[i]["DPT_RS"].ToString().ToUpper() == "Y")
                                        {
                                            sbTANData.AppendLine("DPT" + textDelimiter + "RS");
                                        }
                                    }
                                }

                                //NMO NNM
                                //For NUM-PAR, add NMO::NNM   
                                //If TradeName Polymer, then we require NMO flag, else not required - 15th Oct 2014
                                if (tanNUMsPAR.Rows[i]["IS_TRADE_NAME_POLYMER"].ToString() == "Y")
                                {
                                    //sbTANData.AppendLine("NMO" + textDelimiter + "NNM");

                                    //New validation on 03July2015
                                    //When trade name in PAR field, REG no. in NOT field and no PRO:: FR Tag, then NMO:: NNM should not be there.
                                    tempNUMNote = 0;
                                    if (!int.TryParse(tanNUMsPAR.Rows[i]["NUM_NOTE"].ToString(), out tempNUMNote))
                                    {
                                        sbTANData.AppendLine("NMO" + textDelimiter + "NNM");
                                    }
                                }

                                //Add empty line
                                sbTANData.AppendLine(string.Empty);
                            }
                        }

                        //NUMs - 800 series
                        #region NUMs - 800 series

                        if (tanNUMsCTH != null && tanNUMsCTH.Rows.Count > 0)
                        {
                            int cthNUM = 800;//CTH NUMs should Start with 800
                            for (int i = 0; i < tanNUMsCTH.Rows.Count; i++)
                            {
                                strHMD = "";

                                //Increment cthNUM
                                cthNUM++;

                                //NUM
                                sbTANData.AppendLine("NUM" + textDelimiter + cthNUM);//tanNUMsCTH.Rows[i]["NUM"].ToString()

                                //New modification on 18th Sep 2014
                                //NMO::NN is for Require File Review
                                if (tanNUMsCTH.Rows[i]["IS_REQ_FILE_REVIEW"].ToString() == "Y")
                                {
                                    sbTANData.AppendLine("NMO" + textDelimiter + "NNM");
                                }

                                //CTH
                                if (!string.IsNullOrEmpty(tanNUMsCTH.Rows[i]["CTH"].ToString()))
                                {
                                    sbTANData.AppendLine("CTH" + textDelimiter + tanNUMsCTH.Rows[i]["CTH"].ToString().Trim());
                                }

                                //HMD
                                if (!string.IsNullOrEmpty(tanNUMsCTH.Rows[i]["HMD"].ToString()))
                                {
                                    strHMD = Validations.ConvertSpecialChars(tanNUMsCTH.Rows[i]["HMD"].ToString().Trim());
                                    sbTANData.AppendLine("HMD" + textDelimiter + strHMD);
                                }

                                //New modification on 18th Sep 2014
                                //NOT:: is for Trade Name Polymer and Cross Reference to CTH
                                if (tanNUMsCTH.Rows[i]["IS_TRADE_NAME_POLYMER"].ToString() == "Y")
                                {
                                    //sbTANData.AppendLine("NOT" + textDelimiter + "x-ref " + strHMD + " to " + tanNUMsCTH.Rows[i]["CROSS_REF_POLYMER"].ToString().Trim());

                                    //New modification on 21DEC2015
                                    /*CAS:  Please use the format stated in the feedback for trade names that should be cross referred to CTH. With the indexing below, the trade name will always be placed into the CTH and HMD regardless if the trade name has been cross referred or not. 
                                    CTH: RockFrac NEDA
                                    HMD: RockFrac NEDA
                                    NOT: FR, xrf RockFrac NEDA to CTH: Cement”
                                    NMO: NNM*/
                                    //For Trade Name polymers/regular compounds to be indexed in CTH and cross-referred, add the FR Tag in NOT field and the NMO::NNM Tag and make the highlighted field editable.
                                    sbTANData.AppendLine("NOT" + textDelimiter + "FR, x-ref " + tanNUMsCTH.Rows[i]["CTH"].ToString().Trim() + " to " + tanNUMsCTH.Rows[i]["CROSS_REF_POLYMER"].ToString().Trim());
                                }

                                //Role
                                if (!string.IsNullOrEmpty(tanNUMsCTH.Rows[i]["NUM_ROLE"].ToString()))
                                {
                                    sbTANData.AppendLine("ROL" + textDelimiter + tanNUMsCTH.Rows[i]["NUM_ROLE"].ToString().Trim());
                                }

                                //If CTH Type is General, add regular TMD
                                if (tanNUMsCTH.Rows[i]["CTH_TYPE"].ToString().ToUpper() == "GENERAL")
                                {
                                    //TMD
                                    sbTANData.AppendLine("TMD" + textDelimiter + strTMD);
                                }
                                else //if CTH type is MolStructure/Crystal Structure, add CTH TMD
                                {
                                    //CTH-TMD
                                    if (!string.IsNullOrEmpty(tanNUMsCTH.Rows[i]["NUM_TMD"].ToString()))
                                    {
                                        sbTANData.AppendLine("TMD" + textDelimiter + Html_RtfConversions.Instance.GetExportFormatStringFromHtmlString(tanNUMsCTH.Rows[i]["NUM_TMD"].ToString().Trim()));
                                    }
                                }

                                //Add empty line
                                sbTANData.AppendLine(string.Empty);
                            }
                        }

#endregion
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return sbTANData;
        }

        private static DataTable GetKeysTableFromString(string keywords)
        {
            DataTable dtKeys = null;
            try
            {
                if (!string.IsNullOrEmpty(keywords.Trim()))
                {
                    string[] saKeys = keywords.Trim().Split(new string[] { "``" }, StringSplitOptions.RemoveEmptyEntries);
                    if (saKeys != null)
                    {
                        if (saKeys.Length > 0)
                        {
                            dtKeys = new DataTable();
                            
                            DataColumn colKey = new DataColumn("TK_ID");
                            colKey.DataType = System.Type.GetType("System.Int32");
                            colKey.AutoIncrement = true;
                            colKey.AutoIncrementSeed = 1;

                            dtKeys.Columns.Add(colKey);
                            dtKeys.Columns.Add("KEYWORD");

                            foreach (string key in saKeys)
                            {
                                DataRow dtRow = dtKeys.NewRow();
                                dtRow["KEYWORD"] = key.Trim();
                                dtKeys.Rows.Add(dtRow);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtKeys;
        }

        /// <summary>
        /// Remove special chars in PAR stirng 
        /// </summary>
        /// <param name="par"></param>
        /// <returns></returns>
        private static string RemoveSpecialCharsInString(string par)
        {
            string strPAR = "";
            try
            {
                if (!string.IsNullOrEmpty(par) && SplCharReplData != null)
                {
                    StringBuilder sbPAR = new StringBuilder();
                    //for (int i = 0; i < par.Length; i++)
                    //{
                    //    sbPAR.Append(GetReplacementCharForSpecialChar(par[i].ToString()));
                    //}
                    sbPAR.Append(GetReplacementCharForSpecialChar(par));
                    strPAR = sbPAR.ToString();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strPAR;
        }

        /// <summary>
        /// Replacement of special chars
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        private static string GetReplacementCharForSpecialChar(string source)
        {
            string strReplChar = "";
            try
            {
                if (!string.IsNullOrEmpty(source))
                {
                    strReplChar = source;
                    strReplChar = Validations.ConvertSpecialChars(source);
                    //if (SplCharReplData != null)
                    //{
                    //    for (int rIndx = 0; rIndx < SplCharReplData.Rows.Count; rIndx++)
                    //    {
                    //        if (source == SplCharReplData.Rows[rIndx]["SPECIAL_CHAR"].ToString())
                    //        {
                    //            strReplChar = SplCharReplData.Rows[rIndx]["REPLACEMENT_CHAR"].ToString();
                    //            break;
                    //        }
                    //    }
                    //}
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strReplChar;
        }

        #endregion  
      
        #region Export to REP file

        /// <summary>
        /// Export REP file 
        /// </summary>
        /// <param name="tansList"></param>
        /// <param name="repFileName"></param>
        /// <returns></returns>
        public static bool ExportQueryTANsToREPFile(List<Int32> tanIDsList, string repFileName)
        {
            bool blStatus = false;
            try
            {
                if (tanIDsList != null && !string.IsNullOrEmpty(repFileName))
                {
                    if (tanIDsList.Count > 0)
                    {
                       //Get Query TANs info in the TANs list 
                        DataTable dtQryTANs = IndxReactNarrDAL.OrganicIndexingDB.GetMacroIndexingQueryTANs(tanIDsList);
                        if (dtQryTANs != null)
                        {
                            if (dtQryTANs.Rows.Count > 0)
                            {
                                StreamWriter swTAN_REP = new StreamWriter(repFileName, false, Encoding.UTF8);
                                StringBuilder sbRepTANs = new StringBuilder();

                                for (int i = 0; i < dtQryTANs.Rows.Count; i++)
                                {
                                    //Only Query TANs will be copied to REP file
                                    if (dtQryTANs.Rows[i]["QUERY_TAN"].ToString().ToUpper() == "Y" || dtQryTANs.Rows[i]["REP_INCLUDE"].ToString().ToUpper() == "Y")
                                    {
                                        if (dtQryTANs.Rows[i]["COMMENT_TYPE"].ToString() == "MACRO_INDEXING")
                                        {
                                            sbRepTANs.AppendLine(dtQryTANs.Rows[i]["TAN_NAME"].ToString() + " " + dtQryTANs.Rows[i]["TAN_COMMENT"].ToString());
                                        }
                                    }
                                }

                                //Write StringBuilder objects data to StreamWriter objects
                                lblFormat = new System.Windows.Forms.Label();
                                lblFormat.Font = new Font("Courier New", 10.0f, FontStyle.Regular);
                                lblFormat.Text = sbRepTANs.ToString();

                                swTAN_REP.WriteLine(lblFormat.Text.Trim());

                                //Close StreamWriter objects
                                swTAN_REP.Close();
                            }
                            else//Empty REP File
                            {
                                StreamWriter swTAN_REP = new StreamWriter(repFileName, false, Encoding.UTF8);
                                swTAN_REP.Close();
                            }
                        }                
                    }
                    blStatus = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        #endregion
    }
}

