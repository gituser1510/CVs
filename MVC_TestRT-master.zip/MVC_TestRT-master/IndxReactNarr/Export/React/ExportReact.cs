﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using IndxReactNarr.Common;
using System.IO;
using IndxReactNarrBLL;
using System.Data;
using IndxReactNarrDAL;
using System.Collections;
using IndxReactNarr.Generic;
using System.Text.RegularExpressions;

namespace IndxReactNarr.Export
{
    public class ExportReact
    {
        #region Property Procedures

        public DataTable TANInfoTbl
        { get; set; }

        public DataTable TANCommentsTbl
        { get; set; }

        public DataTable ProductsTbl
        { get; set; }

        public DataTable ReactionsTbl
        { get; set; }

        public DataTable ReactantsTbl
        { get; set; }

        public DataTable AgentsTbl
        { get; set; }

        public DataTable SolventsTbl
        { get; set; }

        public DataTable CatalystsTbl
        { get; set; }

        public DataTable ConditionsTbl
        { get; set; }

        public DataTable RSNTbl
        { get; set; }

        public DataTable StagesTbl
        { get; set; }

        public DataTable Ser8500Tbl
        { get; set; }

        public DataTable Ser8000Tbl
        { get; set; }

        public DataTable Ser9000Tbl
        { get; set; }

        #endregion        
           
        ArrayList alstSer8000_Vals = null;
        Random rdm = new Random();
        public bool WriteXmlFileUsingXSD(string outfilepath)
        {
            try
            {
                //Get RXNFILE elements
                RXNFILE rxnFile = Get_RXNFILE_ElementDetails();

                //XML Serialization
                XmlSerializer xmlSer = new XmlSerializer(typeof(RXNFILE));

                using (TextWriter txtWriter = new StreamWriter(outfilepath))
                {
                    xmlSer.Serialize(txtWriter, rxnFile);

                    txtWriter.Close();
                    txtWriter.Dispose();

                    //Find and replace ~~ character in the file. ~~ is used for empty element value
                    Find_ReplaceTextInFile(outfilepath);

                    //Find and replace <STAGE /> tag with <STAGE></STAGE>
                    Find_ReplaceEmptyStageTAGInFile(outfilepath);

                    return true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return false;
        }

        private RXNFILE Get_RXNFILE_ElementDetails()
        {
            try
            {
                if (TANInfoTbl != null)
                {
                    if (TANInfoTbl.Rows.Count > 0)
                    {
                        RXNFILE rxnFile = new RXNFILE();
                        rxnFile.SOURCE = TANInfoTbl.Rows[0]["source"].ToString();
                        rxnFile.VERSION = TANInfoTbl.Rows[0]["version"].ToString();
                        
                        string strFileName = TANInfoTbl.Rows[0]["filename"].ToString();
                        strFileName = strFileName.Replace("rxnfile.","");
                        rxnFile.FILENUM = strFileName.Trim();
                        
                        DOCUMENT[] docArr = new DOCUMENT[1];
                        docArr[0] = GetDOCUMENTElementDetails();
                        rxnFile.DOCUMENT = docArr;

                        return rxnFile;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return null;
        }

        public DOCUMENT GetDOCUMENTElementDetails()
        {
            try
            {
                if (TANInfoTbl != null)
                {
                    if (TANInfoTbl.Rows.Count > 0)
                    {
                        DOCUMENT rxnDoc = new DOCUMENT();
                        rxnDoc.VIEW = viewType.RXN;
                        rxnDoc.ANALYST = rdm.Next(8001, 8020).ToString(); // TANInfoTbl.Rows[0]["CLIENT_ANALYST_ID"].ToString();
                        rxnDoc.CAN = !string.IsNullOrEmpty(TANInfoTbl.Rows[0]["CAN"].ToString()) ? TANInfoTbl.Rows[0]["CAN"].ToString().Trim() : "~~";
                        rxnDoc.TAN = TANInfoTbl.Rows[0]["TAN_NAME"].ToString();
                        #region Comments code moved to function - 10th May 2013
                        //if (PatentTbl.Rows[0]["comments"].ToString() != "")
                        //{
                        //    string strComments = PatentTbl.Rows[0]["comments"].ToString();//.Replace("\r\n", ", ");
                        //    if (strComments.Trim().StartsWith("~~reaction"))
                        //    {
                        //        strComments = strComments.Remove(0, 2);
                        //    }

                        //    //Default comments removal -20th Apr 2013
                        //    strComments = strComments.Replace("8000 and 8500 used as reactant", "@#$");
                        //    strComments = strComments.Replace("8000 and 8500 used as product", "@#$");
                        //    strComments = strComments.Replace("8000 used as product and reactant", "@#$");
                        //    strComments = strComments.Replace("8500 used as product and reactant", "@#$");
                        //    strComments = strComments.Replace("8000 used as reactant", "@#$");
                        //    strComments = strComments.Replace("8500 used as reactant", "@#$");
                        //    strComments = strComments.Replace("8000 used as product", "@#$");
                        //    strComments = strComments.Replace("8500 used as product", "@#$");
                        //    strComments = strComments.Replace("@#$, @#$", "");
                        //    strComments = strComments.Replace("@#$,@#$", "");
                        //    strComments = strComments.Replace("@#$.", "");
                        //    strComments = strComments.Replace("@#$", "");

                        //    if (strComments.Trim().StartsWith("`"))
                        //    {
                        //        strComments = strComments.Replace("`", "");
                        //    }

                        //    if (strComments.Trim().StartsWith("~~"))
                        //    {
                        //        strComments = strComments.Replace("~~", "");
                        //    }

                        //    strComments = strComments.Replace("~~", ". ");
                        //    strComments = strComments.Replace("`", ". ");

                        //    if (string.IsNullOrEmpty(strComments))
                        //    {
                        //        strComments = "~~";
                        //    }
                        //    rxnDoc.COMMENTS = strComments.Trim();
                        //}
                        //else
                        //{
                        //    rxnDoc.COMMENTS = "~~";
                        //} 
                        #endregion
                        rxnDoc.COMMENTS = GetFormattedComments_New(); //GetFormattedComments(TANInfoTbl.Rows[0]["comments"].ToString());

                        RXNGRP objRXNGrp = Get_RXNGRP_ElementDetails();
                        if (objRXNGrp != null)
                        {
                            rxnDoc.RXNGRP = objRXNGrp;
                        }
                        return rxnDoc;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return null;
        }

        #region RXNGRP Methods

        private RXNGRP Get_RXNGRP_ElementDetails()
        {
            RXNGRP objRxnGrp = null;
            try
            {
                if (ReactionsTbl != null)
                {
                    if (ReactionsTbl.Rows.Count > 0)
                    {                                               
                        objRxnGrp = new RXNGRP();
                        RXN[] rxnArr = Get_RXN_Array_ElementDetails();
                        if (rxnArr != null)
                        {
                            objRxnGrp.RXN = rxnArr;
                        }                       
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return objRxnGrp;
        }

        private RXN[] Get_RXN_Array_ElementDetails()
        {
            RXN[] rxnArr = null;
            try
            {
                if (ReactionsTbl != null)
                {
                    if (ReactionsTbl.Rows.Count > 0)
                    {
                        //RXN[] rxnArr = new RXN[ReactionsTbl.Rows.Count];

                        List<RXN> lstRXN = new List<RXN>();

                        RXN objRXN = null;
                        string strRSD = "";

                        RXNID objRxnID = null;
                        XREFGRP objXRefGrp = null;
                        SUBDESC objSubDesc = null;
                        RXNPROCESS objRxnProc = null;
                        int rxnID = 0;

                        for (int rindx = 0; rindx < ReactionsTbl.Rows.Count; rindx++)
                        {
                            objRXN = new RXN();
                            objRXN.NO = rindx + 1;
                            objRXN.NOSpecified = true;

                            int.TryParse(ReactionsTbl.Rows[rindx]["RXN_ID"].ToString(), out rxnID);      

                            objRxnID = Get_RXNID_ElementDetails(rindx);
                            if (objRxnID != null)
                            {
                                objRXN.RXNID = objRxnID;
                            }

                            strRSD = Get_RSD_ElementDetails(rxnID);
                            if (strRSD.Trim() != "")
                            {
                                objRXN.RSD = strRSD;
                            }

                            objXRefGrp = Get_XREFGRP_ElementDetails(rxnID);
                            if (objXRefGrp != null)
                            {
                                objRXN.XREFGRP = objXRefGrp;
                            }

                            objSubDesc = Get_SUBDESC_ElementDetails(rxnID);
                            if (objSubDesc != null)
                            {
                                objRXN.SUBDESC = objSubDesc;
                            }

                            objRxnProc = Get_RXNPROCESS_ElementDetails(rxnID);
                            if (objRxnProc != null)
                            {
                                objRXN.RXNPROCESS = objRxnProc;
                            }

                            //rxnArr[rindx] = objRXN;

                            //Add RXN to List
                            lstRXN.Add(objRXN);
                        }

                        if (lstRXN.Count > 0)
                        {
                            rxnArr = lstRXN.ToArray();
                        }                       
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return rxnArr;
        }

        private RXNID Get_RXNID_ElementDetails(int _rowindex)
        {
            RXNID objRxnID = null;
            try
            {
                if (ReactionsTbl != null)
                {
                    if (ReactionsTbl.Rows.Count > 0)
                    {
                        objRxnID = new RXNID();
                        //For React, Product NUM should be RXN_NUM
                        objRxnID.RXNNUM = GlobalVariables.ApplicationName == Enums.ApplicationName.REACT.ToString() ? ReactionsTbl.Rows[_rowindex]["RXN_NUM"].ToString() : (_rowindex + 1).ToString(); 

                        //For Organic/Macro Indexing RXN_SEQ always 1
                        objRxnID.RXNSEQ = GlobalVariables.ApplicationName == Enums.ApplicationName.REACT.ToString() ? ReactionsTbl.Rows[_rowindex]["RXN_SEQ"].ToString() : "1";                
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return objRxnID;
        }

        private string Get_RSD_ElementDetails(int reactionid)
        {
            try
            {
                if (reactionid > 0)
                {
                    string strRSD = "";
                    strRSD = GenerateRSD.GetRSDString(reactionid, ProductsTbl, ReactantsTbl, AgentsTbl, SolventsTbl, CatalystsTbl,RSNTbl,StagesTbl);
                                      
                    return strRSD;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return "";
        }

        #endregion

        #region XREFGRP Methods

        private XREFGRP Get_XREFGRP_ElementDetails(int _reactionid)
        {
            try
            {
                if (_reactionid > 0)
                {
                    XREFGRPNRN[] xRefGrpNRNArr = Get_XREFGRPNRN_Array_ElementDetails(_reactionid);
                    if (xRefGrpNRNArr != null)
                    {
                        //All stages Participants NRN info should goto XREFGRP Element
                        XREFGRP objXRefGrp = new XREFGRP();
                        objXRefGrp.NRN = xRefGrpNRNArr;

                        return objXRefGrp;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return null;
        }

        private XREFGRPNRN[] Get_XREFGRPNRN_Array_ElementDetails(int _reactionid)
        {
            XREFGRPNRN[] xRefGrpArr = null;
            try
            {
                if (_reactionid > 0)
                {                   
                    ArrayList aLstNUMS = new ArrayList();
                    List<XREFGRPNRN> lstXrefGrp = new List<XREFGRPNRN>();
                          
                    //Product NRN
                    XREFGRPNRN[] xRefNrnArr_P = Get_Partpant_NRN_Array_Dtls(ProductsTbl, _reactionid, ref aLstNUMS);
                    if (xRefNrnArr_P != null)
                    {
                        if (xRefNrnArr_P.Length > 0)
                        {
                            lstXrefGrp.AddRange(xRefNrnArr_P);
                        }
                    }

                    //Reactant NRN
                    XREFGRPNRN[] xRefNrnArr_R = Get_Partpant_NRN_Array_Dtls(ReactantsTbl, _reactionid, ref aLstNUMS);
                    if (xRefNrnArr_R != null)
                    {
                        if (xRefNrnArr_R.Length > 0)
                        {
                            lstXrefGrp.AddRange(xRefNrnArr_R);
                        }
                    }

                    //Agent NRN
                    XREFGRPNRN[] xRefNrnArr_A = Get_Partpant_NRN_Array_Dtls(AgentsTbl, _reactionid, ref aLstNUMS);
                    if (xRefNrnArr_A != null)
                    {
                        if (xRefNrnArr_A.Length > 0)
                        {
                            lstXrefGrp.AddRange(xRefNrnArr_A);
                        }
                    }

                    //Solvent NRN
                    XREFGRPNRN[] xRefNrnArr_S = Get_Partpant_NRN_Array_Dtls(SolventsTbl, _reactionid, ref aLstNUMS);
                    if (xRefNrnArr_S != null)
                    {
                        if (xRefNrnArr_S.Length > 0)
                        {
                            lstXrefGrp.AddRange(xRefNrnArr_S);
                        }
                    }

                    //Catalyst NRN
                    XREFGRPNRN[] xRefNrnArr_C = Get_Partpant_NRN_Array_Dtls(CatalystsTbl, _reactionid, ref aLstNUMS);
                    if (xRefNrnArr_C != null)
                    {
                        if (xRefNrnArr_C.Length > 0)
                        {
                            lstXrefGrp.AddRange(xRefNrnArr_C);
                        }
                    }

                    //Convert List to Array
                    if (lstXrefGrp.Count > 0)
                    {
                        xRefGrpArr = lstXrefGrp.ToArray();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return xRefGrpArr;
        }

        private XREFGRPNRN[] Get_Partpant_NRN_Array_Dtls(DataTable _partpnttbl, int _reactionid, ref ArrayList _alstNrnNums)
        {
            XREFGRPNRN[] xRefGrpArr = null;
            try
            {
                if (_reactionid > 0)
                {          
                    if (_partpnttbl != null)
                    {
                        if (_partpnttbl.Rows.Count > 0)
                        {
                            DataView dtView = new DataView(_partpnttbl);
                            dtView.RowFilter = "RXN_ID = " + _reactionid + " and SER_TYPE <> '8000'";

                            DataTable dtRes_Partpnt = dtView.ToTable();

                            if (dtRes_Partpnt != null)
                            {
                                if (dtRes_Partpnt.Rows.Count > 0)
                                {
                                    List<XREFGRPNRN> lstXRefGrp = new List<XREFGRPNRN>();        

                                    DataRow[] dtRArr_NUM = dtRes_Partpnt.Select("SERIES_NUM > 0 AND REG_NO > 0");
                                  
                                    if (dtRArr_NUM != null)
                                    {
                                        if (dtRArr_NUM.Length > 0)
                                        {
                                            int intNrnNum = 0;
                                            int intNrnReg = 0;
                                            for (int i = 0; i < dtRArr_NUM.Length; i++)
                                            {
                                                intNrnNum = 0;
                                                int.TryParse(dtRArr_NUM[i]["SERIES_NUM"].ToString(), out intNrnNum);

                                                intNrnReg = 0;
                                                int.TryParse(dtRArr_NUM[i]["REG_NO"].ToString(), out intNrnReg);

                                                if (intNrnNum > 0)
                                                {
                                                    //Load only Unique NUMs, from Product, Reactant, Agent, Solvent and Catalyst
                                                    if (!_alstNrnNums.Contains(intNrnNum))
                                                    {
                                                        _alstNrnNums.Add(intNrnNum);

                                                        XREFGRPNRN _xgrpNRN = new XREFGRPNRN();
                                                        _xgrpNRN.NRNNUM = intNrnNum.ToString();
                                                        _xgrpNRN.NRNREG = intNrnReg.ToString();

                                                        lstXRefGrp.Add(_xgrpNRN);                                                       
                                                    }
                                                }
                                            }

                                            //Convert List to Array
                                            if (lstXRefGrp.Count > 0)
                                            {
                                                xRefGrpArr = lstXRefGrp.ToArray();
                                            }
                                        }
                                    }                                    
                                }
                            }
                        }
                    }                   
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return xRefGrpArr;
        }

        #endregion

        #region SUBDESC Methods

        private SUBDESC Get_SUBDESC_ElementDetails(int _reactionid)
        {
            try
            {
                if (_reactionid > 0)
                {
                    SUBDESCSUBDEFN[] subDefnArr = GetSUBDESCDEFNElements(_reactionid);
                    if (subDefnArr != null)
                    {
                        //All stages Participants SUBDESC info should goto XREFGRP Element
                        SUBDESC objSubDesc = new SUBDESC();
                        objSubDesc.SUBDEFN = subDefnArr;

                        return objSubDesc;
                    }
                }                                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return null;
        }

        private SUBDESCSUBDEFN[] GetSUBDESCDEFNElements(int _reactionid)
        {
            SUBDESCSUBDEFN[] subDefnArr = null;
            try
            {
                ArrayList alstSer8000 = new ArrayList();
                              
                List<SUBDESCSUBDEFN> lstSubDescDefn = new List<SUBDESCSUBDEFN>();

                //Product SUBDEFN
                SUBDESCSUBDEFN[] subDefnArr_P = GetPartpantSUBDEFNArrayDtls(ProductsTbl, "PRODUCT", _reactionid, ref alstSer8000);//ref alstSer8000_Vals
                if (subDefnArr_P != null)
                {
                    if (subDefnArr_P.Length > 0)
                    {
                        lstSubDescDefn.AddRange(subDefnArr_P);
                    }
                }

                //Reactant SUBDEFN
                SUBDESCSUBDEFN[] subDefnArr_R = GetPartpantSUBDEFNArrayDtls(ReactantsTbl, "REACTANT", _reactionid, ref alstSer8000);//ref alstSer8000_Vals
                if (subDefnArr_R != null)
                {
                    if (subDefnArr_R.Length > 0)
                    {
                        lstSubDescDefn.AddRange(subDefnArr_R);
                    }
                }

                //Agent SUBDEFN
                SUBDESCSUBDEFN[] subDefnArr_A = GetPartpantSUBDEFNArrayDtls(AgentsTbl, "AGENT", _reactionid, ref alstSer8000);//ref alstSer8000_Vals
                if (subDefnArr_A != null)
                {
                    if (subDefnArr_A.Length > 0)
                    {
                        lstSubDescDefn.AddRange(subDefnArr_A);
                    }
                }

                //Solvent SUBDEFN
                SUBDESCSUBDEFN[] subDefnArr_S = GetPartpantSUBDEFNArrayDtls(SolventsTbl, "SOLVENT", _reactionid, ref alstSer8000);//ref alstSer8000_Vals
                if (subDefnArr_S != null)
                {
                    if (subDefnArr_S.Length > 0)
                    {
                        lstSubDescDefn.AddRange(subDefnArr_S);
                    }
                }

                //Catalyst SUBDEFN
                SUBDESCSUBDEFN[] subDefnArr_C = GetPartpantSUBDEFNArrayDtls(CatalystsTbl, "CATALYST", _reactionid, ref alstSer8000);//ref alstSer8000_Vals
                if (subDefnArr_C != null)
                {
                    if (subDefnArr_C.Length > 0)
                    {
                        lstSubDescDefn.AddRange(subDefnArr_C);
                    }
                }

                //Convert List to Array
                if (lstSubDescDefn.Count > 0)
                {
                    subDefnArr = lstSubDescDefn.ToArray();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return subDefnArr;
        }

        private SUBDESCSUBDEFN[] GetPartpantSUBDEFNArrayDtls(DataTable _partpnttbl, string _partpntType, int _reactionid, ref ArrayList _tan_ser8000vals)
        {
            SUBDESCSUBDEFN[] objSubDefnArr = null;
            try
            {
                if (_reactionid > 0)
                {
                    List<SUBDESCSUBDEFN> lstSubDescDefn = new List<SUBDESCSUBDEFN>();

                    if (_partpnttbl != null && _partpnttbl.Rows.Count > 0)
                    {
                        DataView dtView = new DataView(_partpnttbl);
                        dtView.RowFilter = "RXN_ID = " + _reactionid + " and SER_TYPE = '8000' and PP_TYPE = '" + _partpntType + "'";
                        //dtView.RowFilter = "RXN_ID = " + _reactionid + " and SER_TYPE = 'NUM' and PP_TYPE = '" + _partpntType + "'";
                        DataTable dtRes_Partpnt = dtView.ToTable(true, "SER_TAN_NUM_ID");

                        if (dtRes_Partpnt != null && dtRes_Partpnt.Rows.Count > 0)
                        {
                            for (int k = 0; k < dtRes_Partpnt.Rows.Count; k++)
                            {
                                if (!string.IsNullOrEmpty(dtRes_Partpnt.Rows[k][0].ToString()))
                                {
                                    DataRow[] dtRArr_8000 = _partpnttbl.Select("SER_TAN_NUM_ID = " + dtRes_Partpnt.Rows[k][0] + " and REG_NO is null"); //Ser8000Tbl.Select("TS_ID = " + dtRes_Partpnt.Rows[k][0]);

                                    if (dtRArr_8000 != null && dtRArr_8000.Length > 0)
                                    {
                                        int intNrnNum = 0;
                                        SUBDESCSUBDEFN subDefn = null;

                                        for (int i = 0; i < 1; i++)//dtRArr_8000.Length
                                        {
                                            intNrnNum = 0;
                                            int.TryParse(dtRArr_8000[i]["SERIES_NUM"].ToString(), out intNrnNum);//SERIES_8000

                                            if (intNrnNum > 0)
                                            {
                                                //Commented on 23rd March. Client asked to provide
                                                //All the 8000 SUBDESC, not distinct 8000 SUBDESC

                                                if (!_tan_ser8000vals.Contains(intNrnNum))
                                                {
                                                    _tan_ser8000vals.Add(intNrnNum);

                                                    subDefn = new SUBDESCSUBDEFN();
                                                    subDefn.NRNNUM = intNrnNum.ToString();

                                                    //if (dtRArr_8000[i]["SUBST_LOC"].ToString().Trim() != "")
                                                    //{
                                                    //From Jan 2014, no need to send SUBLOC information
                                                    subDefn.SUBLOC = "";// dtRArr_8000[i]["Subst_Loc"].ToString();
                                                    //}

                                                    //After adding Author and Other Names
                                                    subDefn.SUBNAME = new string[] { dtRArr_8000[i]["PP_NAME"].ToString().Trim() };// GetSubstanceNameArray(dtRArr_8000[i]);

                                                    lstSubDescDefn.Add(subDefn);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    //Convert List to Array
                    if (lstSubDescDefn.Count > 0)
                    {
                        objSubDefnArr = lstSubDescDefn.ToArray();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return objSubDefnArr;
        }

        private string[] GetSubstanceNameArray(DataRow _substrow)
        {
            string[] strSubNameArr = null;
            try
            {
                if (_substrow != null)
                {
                    ArrayList alstSubName = new ArrayList();
                    
                    if (_substrow["SUBST_NAME"].ToString().Trim() != "")
                    {
                        alstSubName.Add(_substrow["SUBST_NAME"].ToString().Trim());
                    }
                    if (_substrow["SUBST_AUTHOR_NAME"].ToString().Trim() != "")
                    {
                        alstSubName.Add("author " + _substrow["SUBST_AUTHOR_NAME"].ToString().Trim());
                    }
                    if (_substrow["SUBST_OTHER_NAME"].ToString().Trim() != "")
                    {
                        alstSubName.Add(_substrow["SUBST_OTHER_NAME"].ToString().Trim());
                    }

                    if (alstSubName != null)
                    {
                        if (alstSubName.Count > 0)
                        {
                            strSubNameArr = alstSubName.ToArray(typeof(string)) as string[];
                        }
                    }
                    return strSubNameArr;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strSubNameArr;
        }

        #endregion

        #region RXNPROCESS Methods

        private RXNPROCESS Get_RXNPROCESS_ElementDetails(int _reactionid)
        {
            try
            {
                if (_reactionid > 0)
                {
                    //All stages RSN & Stage info should goto RXNPROCESS Element
                    RXNPROCESS objRxnProc = null;

                    RSN[] objRsnArr = Get_Global_RSN_Array_ElementDetails(_reactionid);
                    if (objRsnArr != null)
                    {
                        if (objRxnProc == null)
                        {
                            objRxnProc = new RXNPROCESS();
                        }
                        objRxnProc.RSN = objRsnArr;
                    }

                    STAGE[] objStgArr = GetSTAGE_Elements(_reactionid);
                    if (objStgArr != null)
                    {
                        if (objRxnProc == null)
                        {
                            objRxnProc = new RXNPROCESS();
                        }
                        objRxnProc.STAGE = objStgArr;
                    }

                    return objRxnProc;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return null;
        }

        private RSN[] Get_Global_RSN_Array_ElementDetails(int _reactionid)
        {
            RSN[] objRsnArr = null;
            try
            {
                if (RSNTbl != null)
                {
                    if (RSNTbl.Rows.Count > 0)
                    {                                               
                        DataTable dtRxn_RSN = null;

                        if (StagesTbl != null)
                        {
                            if (StagesTbl.Rows.Count > 0)
                            {
                                DataView dvRxnStgs = new DataView(StagesTbl);
                                dvRxnStgs.RowFilter = "RXN_ID = " + _reactionid + "";
                                DataTable dtRxn_Stgs = dvRxnStgs.ToTable();

                                if (dtRxn_Stgs != null)
                                {
                                    DataView dtView = new DataView(RSNTbl);

                                    if (dtRxn_Stgs.Rows.Count == 1)//If Stage count is 1 then Stage RSN should be global RSN
                                    {
                                        dtView.RowFilter = "RXN_ID = " + _reactionid + "";                                                          
                                    }
                                    else if (dtRxn_Stgs.Rows.Count > 1)
                                    {                                      
                                        dtView.RowFilter = "RXN_ID = " + _reactionid + " and NOTE_LEVEL = 'Reaction'";                                                                   
                                    }

                                    dtRxn_RSN = dtView.ToTable();       
                                }
                            }
                        }

                        if (dtRxn_RSN != null)
                        {
                            if (dtRxn_RSN.Rows.Count > 0)
                            {
                                List<RSN> lstRSN = new List<RSN>();
                          
                                for (int i = 0; i < dtRxn_RSN.Rows.Count; i++)
                                {
                                    if (!string.IsNullOrEmpty(dtRxn_RSN.Rows[i]["CVT"].ToString().Trim()) && !string.IsNullOrEmpty(dtRxn_RSN.Rows[i]["FREE_TEXT"].ToString().Trim()))
                                    {
                                        RSN objRsn_Comb = new RSN();
                                        objRsn_Comb.TYPE = dtRxn_RSN.Rows[i]["CVT"].ToString().Trim();
                                        string[] tmpRsn_C = { dtRxn_RSN.Rows[i]["FREE_TEXT"].ToString().Trim() };
                                        objRsn_Comb.Text = tmpRsn_C;
                                        lstRSN.Add(objRsn_Comb);
                                    }
                                    else if (!string.IsNullOrEmpty(dtRxn_RSN.Rows[i]["CVT"].ToString().Trim()) && string.IsNullOrEmpty(dtRxn_RSN.Rows[i]["FREE_TEXT"].ToString().Trim()))
                                    {
                                        RSN objRsn_CVT = new RSN();
                                        objRsn_CVT.TYPE = dtRxn_RSN.Rows[i]["CVT"].ToString().Trim();
                                        string[] tmpRsn_CVT = { "~~" };
                                        objRsn_CVT.Text = tmpRsn_CVT;
                                        lstRSN.Add(objRsn_CVT);
                                    }
                                    else if (!string.IsNullOrEmpty(dtRxn_RSN.Rows[i]["FREE_TEXT"].ToString().Trim()) && string.IsNullOrEmpty(dtRxn_RSN.Rows[i]["CVT"].ToString().Trim()))
                                    {
                                        RSN objRsn_FT = new RSN();
                                        objRsn_FT.TYPE = "FREE";
                                        string[] tmpRsn_FT = { dtRxn_RSN.Rows[i]["FREE_TEXT"].ToString().Trim() };
                                        objRsn_FT.Text = tmpRsn_FT;
                                        lstRSN.Add(objRsn_FT);
                                    }
                                }

                                //Convert List to Array
                                if (lstRSN.Count > 0)
                                {
                                    objRsnArr = lstRSN.ToArray();
                                }
                            }
                        }                        
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return objRsnArr;
        }

        private STAGE[] GetSTAGE_Elements(int _reactionid)
        {
            STAGE[] rxnStageArr = null;
            try
            {
                if (_reactionid > 0)
                {
                    if (StagesTbl != null)
                    {
                        if (StagesTbl.Rows.Count > 0)
                        {
                            List<STAGE> lstStage = new List<STAGE>();

                            DataView dtView = new DataView(StagesTbl);
                            dtView.RowFilter = "RXN_ID = " + _reactionid + "";
                            dtView.Sort = "DISPLAY_ORDER asc";

                            DataTable dtStages = dtView.ToTable();
                            int rxnStageID = 0;

                            if (dtStages != null)
                            {
                                if (dtStages.Rows.Count > 0)
                                {
                                    STAGE objStage = null;
                                    RSN[] objRSNArr = null;
                                    SUBSTAGE[] objSubStgArr = null;

                                    for (int i = 0; i < dtStages.Rows.Count; i++)
                                    {
                                        objStage = new STAGE();

                                        int.TryParse(dtStages.Rows[i]["RXN_STAGE_ID"].ToString(), out rxnStageID);

                                        if (dtStages.Rows.Count > 1)//If stage count >1 then write Stage RSN. If stage count is 1 then Stage RSN will be Global RSN
                                        {
                                            objRSNArr = GetStageLevelRSNElements(rxnStageID);
                                            if (objRSNArr != null)
                                            {
                                                objStage.RSN = objRSNArr;
                                            }
                                        }

                                        objSubStgArr = GetStageLevelSUBSTAGE_Elements(rxnStageID);//Get_Stage_SUBSTAGE_Array_ElementDetails
                                        if (objSubStgArr != null)
                                        {
                                            objStage.SUBSTAGE = objSubStgArr;
                                        }

                                        //Add STAGE to List
                                        lstStage.Add(objStage);
                                    }
                                }
                                else//empty Stage tag
                                {
                                    STAGE objStage = new STAGE();
                                    lstStage.Add(objStage);
                                }

                                //Convert List to Array
                                rxnStageArr = lstStage.ToArray();
                            }
                        }
                    }

                    //Code commented on 12th Aug 2014
                    #region MyRegion
                    //ArrayList alstStgIDs = GetStageIDsOnRxnID(_reactionid);
                    //if (alstStgIDs != null)
                    //{
                    //    if (alstStgIDs.Count > 0)
                    //    {

                    //        ArrayList alstStage_Final = new ArrayList();
                    //        int intStageLen = GetStageArrayLength(alstStgIDs, ref alstStage_Final);

                    //        if (intStageLen > 0)
                    //        {
                    //            STAGE objStage = null;
                    //            RSN[] objRSNArr = null;
                    //            SUBSTAGE[] objSubStgArr = null;                               

                    //            if (alstStage_Final.Count > 0)
                    //            {
                    //                for (int i = 0; i < alstStage_Final.Count; i++)
                    //                {
                    //                    objStage = new STAGE();

                    //                    //Test Condition on 28Sep2010
                    //                    if (alstStage_Final.Count > 1)//If stage count >1 then write Stage RSN. If stage count is 1 then Stage RSN will be Global RSN
                    //                    {
                    //                        objRSNArr = GetStageLevelRSNElements(alstStage_Final[i].ToString());
                    //                        if (objRSNArr != null)
                    //                        {
                    //                            objStage.RSN = objRSNArr;
                    //                        }
                    //                    }

                    //                    objSubStgArr = GetStageLevelSUBSTAGE_Elements(Convert.ToInt32(alstStage_Final[i].ToString()));//Get_Stage_SUBSTAGE_Array_ElementDetails
                    //                    if (objSubStgArr != null)
                    //                    {
                    //                        objStage.SUBSTAGE = objSubStgArr;
                    //                    }

                    //                    //Add STAGE to List
                    //                    lstStage.Add(objStage);
                    //                }                          
                    //            }                                
                    //        }
                    //        else//empty Stage tag
                    //        {                               
                    //            STAGE objStage = new STAGE();
                    //            lstStage.Add(objStage);                              
                    //        }

                    //        //Convert List to Array
                    //        rxnStageArr = lstStage.ToArray();
                    //    }
                    //} 
                    #endregion
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return rxnStageArr;
        }
                            
        private RSN[] GetStageLevelRSNElements(int rxnStageID)
        {
            RSN[] rsnStageArr = null;
            try
            {
                if (RSNTbl != null)
                {
                    if (RSNTbl.Rows.Count > 0)
                    {
                        DataView dtView = new DataView(RSNTbl);
                        dtView.RowFilter = "RXN_STAGE_ID = " + rxnStageID + " and  NOTE_LEVEL   = 'Stage'";
                        DataTable dtStage_RSN = dtView.ToTable();

                        if (dtStage_RSN != null)
                        {
                            if (dtStage_RSN.Rows.Count > 0)
                            {
                                List<RSN> lstRSN = new List<RSN>();

                                for (int i = 0; i < dtStage_RSN.Rows.Count; i++)
                                {
                                    if (!string.IsNullOrEmpty(dtStage_RSN.Rows[i]["CVT"].ToString().Trim()) && !string.IsNullOrEmpty(dtStage_RSN.Rows[i]["FREE_TEXT"].ToString().Trim()))
                                    {
                                        RSN objRsn_Comb = new RSN();
                                        objRsn_Comb.TYPE = dtStage_RSN.Rows[i]["CVT"].ToString().Trim();
                                        string[] tmpRsn_C = { dtStage_RSN.Rows[i]["FREE_TEXT"].ToString().Trim() };
                                        objRsn_Comb.Text = tmpRsn_C;
                                        lstRSN.Add(objRsn_Comb);

                                        #region Code Commented
                                        //RSN objRsn_CVT = new RSN();
                                        //objRsn_CVT.TYPE = dtRes_RSN.Rows[i]["rsn_cvt"].ToString();
                                        //string[] tmpRsn_CVT = { "~" };
                                        //objRsn_CVT.Text = tmpRsn_CVT;
                                        //objRsnArr[arrIndex] = objRsn_CVT;
                                        //arrIndex++;

                                        //RSN objRsn_FT = new RSN();
                                        //objRsn_FT.TYPE = "FREE";
                                        //string[] tmpRsn_FT = { dtRes_RSN.Rows[i]["rsn_free_text"].ToString() };
                                        //objRsn_FT.Text = tmpRsn_FT;
                                        //objRsnArr[arrIndex] = objRsn_FT;
                                        //arrIndex++; 
                                        #endregion
                                    }
                                    else if (!string.IsNullOrEmpty(dtStage_RSN.Rows[i]["CVT"].ToString().Trim()) && string.IsNullOrEmpty(dtStage_RSN.Rows[i]["FREE_TEXT"].ToString().Trim()))
                                    {
                                        RSN objRsn_CVT = new RSN();
                                        objRsn_CVT.TYPE = dtStage_RSN.Rows[i]["CVT"].ToString().Trim();
                                        string[] tmpRsn_CVT = { "~~" };
                                        objRsn_CVT.Text = tmpRsn_CVT;
                                        lstRSN.Add(objRsn_CVT);
                                    }
                                    else if (!string.IsNullOrEmpty(dtStage_RSN.Rows[i]["FREE_TEXT"].ToString().Trim()) && string.IsNullOrEmpty(dtStage_RSN.Rows[i]["CVT"].ToString().Trim()))
                                    {
                                        RSN objRsn_FT = new RSN();
                                        objRsn_FT.TYPE = "FREE";
                                        string[] tmpRsn_FT = { dtStage_RSN.Rows[i]["FREE_TEXT"].ToString().Trim() };
                                        objRsn_FT.Text = tmpRsn_FT;
                                        lstRSN.Add(objRsn_FT);
                                    }
                                }

                                if (lstRSN.Count > 0)
                                {
                                    rsnStageArr = lstRSN.ToArray();
                                }
                                return rsnStageArr;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return rsnStageArr;
        }      
                   
        private SUBSTAGE[] GetStageLevelSUBSTAGE_Elements(int _rxnStageID)
        {
            SUBSTAGE[] oaSubStage = null;
            try
            {
                if (ConditionsTbl != null)
                {
                    if (ConditionsTbl.Rows.Count > 0)
                    {
                        DataView dtView = new DataView(ConditionsTbl);
                        dtView.RowFilter = "RXN_STAGE_ID = " + _rxnStageID + "";
                        DataTable dtRes_Conds = dtView.ToTable();

                        if (dtRes_Conds != null)
                        {
                            if (dtRes_Conds.Rows.Count > 0)
                            {
                                List<SUBSTAGE> lstSubStage = new List<SUBSTAGE>();

                                for (int i = 0; i < dtRes_Conds.Rows.Count; i++)
                                {
                                    SUBSTAGE _subStage = new SUBSTAGE();
                                    List<COND> lstCond = new List<COND>();

                                    if (!string.IsNullOrEmpty(dtRes_Conds.Rows[i]["TEMPERATURE"].ToString().Trim()))
                                    {
                                        COND objCond = new COND();
                                        objCond.TYPE = condType.TP;
                                        objCond.TYPESpecified = true;

                                        string strTemprature = dtRes_Conds.Rows[i]["TEMPERATURE"].ToString().Trim();

                                        //If Temp Type is 'PLUS_MINUS', write only first value. Ex. 28+/-6, only 28 to be in xml
                                        //New modification on 26th April 2012
                                        if (dtRes_Conds.Rows[i]["TEMP_TYPE"].ToString().Trim().ToUpper() == "PLUS_MINUS")
                                        {
                                            string[] splter = { "+/-" };
                                            string[] saTempVals = strTemprature.Split(splter, StringSplitOptions.RemoveEmptyEntries);
                                            if (saTempVals != null)
                                            {
                                                if (saTempVals.Length > 0)
                                                {
                                                    strTemprature = saTempVals[0].Trim();
                                                }
                                            }
                                        }

                                        string[] condtxt = { strTemprature };
                                        objCond.Text = condtxt;
                                        lstCond.Add(objCond);
                                    }
                                    if (!string.IsNullOrEmpty(dtRes_Conds.Rows[i]["PRESSURE"].ToString().Trim()))
                                    {
                                        COND objCond = new COND();
                                        objCond.TYPE = condType.PR;
                                        objCond.TYPESpecified = true;
                                        string[] condtxt = { dtRes_Conds.Rows[i]["PRESSURE"].ToString().Trim() };
                                        objCond.Text = condtxt;
                                        lstCond.Add(objCond);
                                    }
                                    if (!string.IsNullOrEmpty(dtRes_Conds.Rows[i]["PH"].ToString().Trim()))
                                    {
                                        COND objCond = new COND();
                                        objCond.TYPE = condType.PH;
                                        objCond.TYPESpecified = true;
                                        string[] condtxt = { dtRes_Conds.Rows[i]["PH"].ToString().Trim() };
                                        objCond.Text = condtxt;
                                        lstCond.Add(objCond);
                                    }
                                    if (!string.IsNullOrEmpty(dtRes_Conds.Rows[i]["RC_TIME"].ToString().Trim()))
                                    {
                                        COND objCond = new COND();
                                        objCond.TYPE = condType.TM;
                                        objCond.TYPESpecified = true;
                                        string[] condtxt = { dtRes_Conds.Rows[i]["RC_TIME"].ToString().Trim() };
                                        objCond.Text = condtxt;
                                        lstCond.Add(objCond);
                                    }

                                    //Convert List to Array
                                    if (lstCond.Count > 0)
                                    {
                                        //Add COND to List
                                        _subStage.COND = lstCond.ToArray();
                                    }

                                    //Add SUBSTAGE to List
                                    lstSubStage.Add(_subStage);
                                }

                                //Convert List to Array
                                if (lstSubStage.Count > 0)
                                {
                                    oaSubStage = lstSubStage.ToArray();
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return oaSubStage;
        }
                 
        #endregion        

        #region Helper Methods

        ArrayList alstNums = null;

        private int GetPartpntNRNLength(DataTable _dtpartpnt, string _srcgrid, string _reactionid,ref ArrayList _lstNrnNums)
        {
            try
            {
                if (_reactionid.Trim() != "")
                {
                    int intLen = 0;
                    if (_dtpartpnt != null)
                    {
                        if (_dtpartpnt.Rows.Count > 0)
                        {
                            DataView dtView = new DataView(_dtpartpnt);
                            dtView.RowFilter = "RXN_ID = '" + _reactionid + "'";

                            DataTable dtRes_Partpnt = dtView.ToTable();

                            if (dtRes_Partpnt != null)
                            {
                                if (dtRes_Partpnt.Rows.Count > 0)
                                {
                                    alstNums = new ArrayList();

                                    DataRow[] dtRArr_NUM = dtRes_Partpnt.Select("SERIES_NUM > 0");
                                    //DataRow[] dtRArr_9000 = dtRes_Partpnt.Select("P_9000 > 0");
                                    //DataRow[] dtRArr_8500 = dtRes_Partpnt.Select("P_8500 > 0");

                                    if (dtRArr_NUM != null)
                                    {
                                        if (dtRArr_NUM.Length > 0)
                                        {
                                            for (int i = 0; i < dtRArr_NUM.Length; i++)
                                            {
                                                //if (!alstNums.Contains(dtRArr_NUM[i]["P_NUM"].ToString()))
                                                //{
                                                //    alstNums.Add(dtRArr_NUM[i]["P_NUM"].ToString());
                                                //}
                                                if (!_lstNrnNums.Contains(dtRArr_NUM[i]["SERIES_NUM"].ToString()))
                                                {
                                                    _lstNrnNums.Add(dtRArr_NUM[i]["SERIES_NUM"].ToString());

                                                    if (!alstNums.Contains(dtRArr_NUM[i]["SERIES_NUM"].ToString()))
                                                    {
                                                        alstNums.Add(dtRArr_NUM[i]["SERIES_NUM"].ToString());
                                                    }
                                                }
                                            }
                                            //  intLen = dtRArr_NUM.Length;
                                        }
                                    }
                                    //if (dtRArr_9000 != null)
                                    //{
                                    //    if (dtRArr_9000.Length > 0)
                                    //    {
                                    //        for (int i = 0; i < dtRArr_9000.Length; i++)
                                    //        {
                                    //            //if (!alstNums.Contains(dtRArr_9000[i]["P_9000"].ToString()))
                                    //            //{
                                    //            //    alstNums.Add(dtRArr_9000[i]["P_9000"].ToString());
                                    //            //}
                                    //            if (!_lstNrnNums.Contains(dtRArr_9000[i]["P_9000"].ToString()))
                                    //            {
                                    //                _lstNrnNums.Add(dtRArr_9000[i]["P_9000"].ToString());

                                    //                if (!alstNums.Contains(dtRArr_9000[i]["P_9000"].ToString()))
                                    //                {
                                    //                    alstNums.Add(dtRArr_9000[i]["P_9000"].ToString());
                                    //                }
                                    //            }
                                    //        }                                            
                                    //        // intLen = intLen + dtRArr_9000.Length;
                                    //    }
                                    //}
                                    //if (dtRArr_8500 != null)
                                    //{
                                    //    if (dtRArr_8500.Length > 0)
                                    //    {
                                    //        for (int i = 0; i < dtRArr_8500.Length; i++)
                                    //        {
                                    //            //if (!alstNums.Contains(dtRArr_8500[i]["P_8500"].ToString()))
                                    //            //{
                                    //            //    alstNums.Add(dtRArr_8500[i]["P_8500"].ToString());
                                    //            //}
                                    //            if (!_lstNrnNums.Contains(dtRArr_8500[i]["P_8500"].ToString()))
                                    //            {
                                    //                _lstNrnNums.Add(dtRArr_8500[i]["P_8500"].ToString());

                                    //                if (!alstNums.Contains(dtRArr_8500[i]["P_8500"].ToString()))
                                    //                {
                                    //                    alstNums.Add(dtRArr_8500[i]["P_8500"].ToString());
                                    //                }
                                    //            }
                                    //        }  
                                    //        // intLen = intLen + dtRArr_8500.Length;
                                    //    }
                                    //}

                                    intLen = alstNums.Count;
                                }
                            }
                        }
                    }
                    return intLen;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return 0;
        }

        private int GetPartpntSUBDEFNLength(DataTable _dtpartpnt, string _srcgrid,string _reactionid,ref ArrayList _lst8000vals)
        {
            int intLen = 0;
            try
            {
                if (_reactionid != "")
                {                    
                    if (_dtpartpnt != null)
                    {
                        if (_dtpartpnt.Rows.Count > 0)
                        {
                            DataView dtView = new DataView(_dtpartpnt);
                            dtView.RowFilter = "RXN_ID = '" + _reactionid + "'";
                            DataTable dtRes_Partpnt = dtView.ToTable();

                            if (dtRes_Partpnt != null)
                            {
                                if (dtRes_Partpnt.Rows.Count > 0)
                                {
                                    DataRow[] dtRArr_8000 = dtRes_Partpnt.Select("SER_TYPE = '8000'");
                                    if (dtRArr_8000 != null)
                                    {
                                        if (dtRArr_8000.Length > 0)
                                        {
                                            //ArrayList lstSer8000 = new ArrayList();
                                            int intPartpntLen = 0;
                                            for (int i = 0; i < dtRArr_8000.Length; i++)
                                            {
                                                //Commented code on 23rd March 2011, Client asked to provide all the 8000 SUBDESC, not distinct 8000 SUBDESC
                                                // if (!_lst8000vals.Contains(dtRArr_8000[i]["P_8000"].ToString()))
                                                // {
                                                //   _lst8000vals.Add(dtRArr_8000[i]["P_8000"].ToString());

                                                if (!_lst8000vals.Contains(dtRArr_8000[i]["SERIES_NUM"].ToString()))
                                                {
                                                    _lst8000vals.Add(dtRArr_8000[i]["SERIES_NUM"].ToString());
                                                    intPartpntLen = intPartpntLen + 1;
                                                }
                                                // }
                                            }
                                            intLen = intPartpntLen;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    return intLen;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return intLen;
        }        

        #endregion

        #region Comments Methods       

        private string GetFormattedComments_New()
        {
            string strComments = "";
            try
            {
                if (TANCommentsTbl != null)
                {
                    if (TANCommentsTbl.Rows.Count > 0)
                    {
                        //Get CAS consulted for comments
                        strComments = strComments.Trim() + " " + GetCommentsOnCommentsType(Enums.CommentsType.CAS.ToString());

                        //Get Author Error comments
                        strComments = strComments.Trim() + " " + GetCommentsOnCommentsType(Enums.CommentsType.AUTHOR.ToString());

                        //Get Indexing Error comments
                        strComments = strComments.Trim() + " " + GetCommentsOnCommentsType(Enums.CommentsType.INDEXING.ToString());

                        //Get Other comments
                        strComments = strComments.Trim() + " " + GetCommentsOnCommentsType(Enums.CommentsType.TEMPERATURE.ToString());

                        //Get Other comments
                        strComments = strComments.Trim() + " " + GetCommentsOnCommentsType(Enums.CommentsType.OTHER.ToString());

                        //Get Default comments
                        strComments = strComments.Trim() + " " + GetCommentsOnCommentsType(Enums.CommentsType.DEFAULT.ToString());  
                    }
                }

                if (string.IsNullOrEmpty(strComments.Trim()))
                {
                    strComments = "~~";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strComments.Trim();
        }

        private string GetCommentsOnCommentsType(string commentsType)
        {
            string strComments = "";
            try
            {
                if (TANCommentsTbl != null)
                {
                    if (TANCommentsTbl.Rows.Count > 0)
                    {
                        string strDelimiter = "";
                        switch (commentsType.ToUpper())
                        {
                            case "CAS":
                                strDelimiter = "CAS consulted for ";
                                break;

                            case "INDEXING":
                                strDelimiter = "Indexing error: ";
                                break;

                            case "AUTHOR":
                                strDelimiter = "Author error: ";
                                break;

                            case "OTHER":
                            case "TEMPERATURE":
                            case "DEFAULT":
                                strDelimiter = "Other comment: ";
                                break;
                        }

                        var rows = from r in TANCommentsTbl.AsEnumerable()
                                   where r.Field<string>("COMMENT_TYPE") == commentsType
                                   select new
                                   {
                                       Comments = r.Field<string>("TAN_COMMENT")
                                   };
                        
                        if (rows != null)
                        {
                            foreach (var r in rows)
                            {
                                strComments = string.IsNullOrEmpty(strComments) ? strDelimiter + r.Comments.Trim() : r.Comments.Trim();
                                //End with .
                                strComments = !strComments.Trim().EndsWith(".") ? strComments.Trim() + "." : r.Comments.Trim();
                            }
                        }                        
                    }                    
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strComments.Trim();
        }

        #endregion

        #region Find/Replace Methods      

        private static void Find_ReplaceTextInFile(string _xmlfilepath)
        {
            try
            {
                if (_xmlfilepath.Trim() != "")
                {
                    StreamReader streamReader = null;
                    streamReader = File.OpenText(_xmlfilepath);
                    // Now, read the entire file into a strin
                    string contents = streamReader.ReadToEnd();
                    streamReader.Close();

                    // Write the modification into the same file
                    StreamWriter streamWriter = File.CreateText(_xmlfilepath);

                    streamWriter.Write(contents.Replace("~~", ""));                    

                    streamWriter.Close();
                    streamWriter.Dispose();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private static void Find_ReplaceEmptyStageTAGInFile(string _xmlfilepath)
        {
            try
            {
                if (_xmlfilepath.Trim() != "")
                {
                    StreamReader streamReader = null;
                    streamReader = File.OpenText(_xmlfilepath);
                    // Now, read the entire file into a strin
                    string contents = streamReader.ReadToEnd();
                    streamReader.Close();

                    // Write the modification into the same fil
                    StreamWriter streamWriter = File.CreateText(_xmlfilepath);

                    contents = contents.Replace("<STAGE />", "<STAGE></STAGE>");
                    contents = contents.Replace("<SUBLOC />", "<SUBLOC></SUBLOC>");

                    streamWriter.Write(contents);

                    //streamWriter.Write(contents.Replace("<SUBLOC />", "<SUBLOC></SUBLOC>"));//New code for Xmls delivery from Jan 2014

                    streamWriter.Close();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion
    }
}
