﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;
using System.Data;
using IndxReactNarrDAL;
using IndxReactNarr.Generic;
using IndxReactNarrBll;

namespace IndxReactNarr.Export
{
    public class ExportReactBatch
    {                      
        static DataTable TansForExport = null;
        static string Source = "";
        static string FileVersion = "";
        static string FileName = "";   

        public static bool ExportToXmlFile(DataTable tansForExport, string outFilePath, string outFileName, bool trimXml)
        {
            bool blStatus = false;
            try
            {
                if (tansForExport != null && !string.IsNullOrEmpty(outFilePath) && !string.IsNullOrEmpty(outFileName))
                {
                    TansForExport = tansForExport;
                    Source = "GVKbio";
                    FileVersion = "2";
                    FileName = outFileName;

                    string strOutFileName = outFilePath + "\\" + outFileName.ToLower();// +".xml";

                    //Get RXNFILE elements
                    RXNFILE rxnFile = Get_RXNFILE_ElementDetails();

                    //XML Serialization
                    XmlSerializer xmlSer = new XmlSerializer(typeof(RXNFILE));
                    TextWriter txtWriter = new StreamWriter(strOutFileName);
                    xmlSer.Serialize(txtWriter, rxnFile);

                    txtWriter.Close();
                    txtWriter.Dispose();

                    //Find and replace ~~.~~ is used for empty element value
                    Find_ReplaceTextInFile(strOutFileName);

                    //Find and replace <STAGE /> tag with <STAGE></STAGE>
                    Find_ReplaceEmptyStageTAGInFile(strOutFileName);

                    if (trimXml)
                    {
                        TrimXmlFile(strOutFileName);
                    }

                    blStatus = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private static RXNFILE Get_RXNFILE_ElementDetails()
        {
            try
            {
                RXNFILE rxnFile = new RXNFILE();
                rxnFile.SOURCE = Source;
                rxnFile.VERSION = FileVersion;
                FileName = FileName.ToLower().Replace("rxnfile.", "");
                rxnFile.FILENUM = FileName.Replace("_trim","").Replace(".xml","").Trim();
                rxnFile.DOCUMENT = GetTANDocumentArrayDetails();

                return rxnFile;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return null;
        }

        private static DOCUMENT[] GetTANDocumentArrayDetails()
        {
            try
            {
                if (TansForExport != null)
                {
                    if (TansForExport.Rows.Count > 0)
                    {
                        string strTAN = "";
                        int TAN_ID = 0;
                        DataTable dtTANDtls = null;
                        DataTable dtTANComments = null;   
                        DataTable dtReactions = null;
                        DataTable dtProdData = null;
                        DataTable dtRSNData = null;
                        DataTable dtCondData = null;
                        DataTable dtPartpntData = null;
                        DataTable dtStages = null;
                        DataTable dtSer8000Data = null;
                        DataTable dtSer8500Data = null;

                        DataTable dtReact = null;
                        DataTable dtAgent = null;
                        DataTable dtSolv = null;
                        DataTable dtCatl = null;

                        DataView dView_R = null;
                        DataView dView_A = null;
                        DataView dView_S = null;
                        DataView dView_C = null;

                        ExportReact objWriteXml = null;
                        List<DOCUMENT> lstDocuments = new List<DOCUMENT>();
                        DOCUMENT objDocument = null;

                        for (int i = 0; i < TansForExport.Rows.Count; i++)
                        {
                            if (TansForExport.Rows[i]["QUERY_TAN"].ToString() == "N")//For query TANs no 
                            {
                                strTAN = TansForExport.Rows[i]["TAN_NAME"].ToString();
                                TAN_ID = Convert.ToInt32(TansForExport.Rows[i]["TAN_ID"].ToString());

                                dtTANDtls = ReactDB.GetTANDetailsOnTANIDForExport(TAN_ID);//GetTANDetailsOnTANID(TAN_ID);
                                dtTANComments = ReactDB.GetTANCommentsOnTANID(TAN_ID);
                                dtReactions = ReactDB.GetReactionsOnTANID(TAN_ID);
                                dtRSNData = ReactDB.GetRSNDetailsOnTAN(TAN_ID);
                                dtCondData = ReactDB.GetConditionDataOnTAN(TAN_ID);
                                dtStages = ReactDB.GetStagesOnTAN(TAN_ID);
                                dtPartpntData = ReactDB.GetProduct_ParticipantsDataOnTAN(TAN_ID);
                                dtSer8000Data = ReactDB.GetSeries8000DetailsOnTAN(TAN_ID);
                                dtSer8500Data = ReactDB.GetSeries8500DetailsOnTAN(TAN_ID);

                                if (dtPartpntData != null)
                                {
                                    DataView dvTemp = dtPartpntData.DefaultView;
                                    dvTemp.RowFilter = "PP_TYPE = 'PRODUCT'";
                                    dtProdData = dvTemp.ToTable();
                                }

                                if (dtPartpntData != null)
                                {
                                    dView_R = dtPartpntData.DefaultView;
                                    dView_R.RowFilter = "PP_TYPE = 'REACTANT'";
                                    dtReact = dView_R.ToTable();

                                    dView_A = dtPartpntData.DefaultView;
                                    dView_A.RowFilter = "PP_TYPE = 'AGENT'";
                                    dtAgent = dView_A.ToTable();

                                    dView_S = dtPartpntData.DefaultView;
                                    dView_S.RowFilter = "PP_TYPE = 'SOLVENT'";
                                    dtSolv = dView_S.ToTable();

                                    dView_C = dtPartpntData.DefaultView;
                                    dView_C.RowFilter = "PP_TYPE = 'CATALYST'";
                                    dtCatl = dView_C.ToTable();
                                }

                                objWriteXml = new ExportReact();
                                objWriteXml.TANInfoTbl = dtTANDtls;
                                objWriteXml.TANCommentsTbl = dtTANComments;
                                objWriteXml.ProductsTbl = dtProdData;
                                objWriteXml.ReactionsTbl = dtReactions;
                                objWriteXml.ReactantsTbl = dtReact;
                                objWriteXml.AgentsTbl = dtAgent;
                                objWriteXml.SolventsTbl = dtSolv;
                                objWriteXml.CatalystsTbl = dtCatl;
                                objWriteXml.RSNTbl = dtRSNData;
                                objWriteXml.ConditionsTbl = dtCondData;
                                objWriteXml.StagesTbl = dtStages;

                                objWriteXml.Ser8000Tbl = dtSer8000Data;
                                objWriteXml.Ser8500Tbl = dtSer8500Data;

                                //Get Document Details
                                objDocument = objWriteXml.GetDOCUMENTElementDetails();
                                if (objDocument != null)
                                {
                                    //Add document to list
                                    lstDocuments.Add(objDocument);
                                }
                            }
                        }

                        //Convert List to Array
                        if (lstDocuments != null)
                        {
                            if (lstDocuments.Count > 0)
                            {
                                return lstDocuments.ToArray();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return null;            
        }

        private static void Find_ReplaceTextInFile(string _xmlfilepath)
        {
            try
            {
                if (_xmlfilepath.Trim() != "")
                {
                    StreamReader streamReader = null;
                    streamReader = File.OpenText(_xmlfilepath);
                    // Now, read the entire file into a strin
                    string contents = streamReader.ReadToEnd();
                    streamReader.Close();

                    // Write the modification into the same fil
                    StreamWriter streamWriter = File.CreateText(_xmlfilepath);
                    
                    streamWriter.Write(contents.Replace("~~", ""));
                    
                    streamWriter.Close();
                    streamWriter.Dispose();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private static void Find_ReplaceEmptyStageTAGInFile(string _xmlfilepath)
        {
            try
            {
                if (_xmlfilepath.Trim() != "")
                {
                    StreamReader streamReader = null;
                    streamReader = File.OpenText(_xmlfilepath);
                    // Now, read the entire file into a strin
                    string contents = streamReader.ReadToEnd();
                    streamReader.Close();

                    // Write the modification into the same fil
                    StreamWriter streamWriter = File.CreateText(_xmlfilepath);

                    contents = contents.Replace("<STAGE />", "<STAGE></STAGE>");
                    contents = contents.Replace("<SUBLOC />", "<SUBLOC></SUBLOC>");

                    streamWriter.Write(contents);

                    streamWriter.Close();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private static void TrimXmlFile(string _xmlfilepath)
        {
            try
            {
                string strDir = Path.GetDirectoryName(_xmlfilepath);
                string strFileName = Path.GetFileName(_xmlfilepath);
                //strFileName = strFileName.Replace(".xml", "_Trim.xml");
                strFileName = strFileName.ToLower().Replace("_trim.xml", ".xml");

                string strNewFile = strDir + "\\" + strFileName;

                StreamReader objSRdr = new StreamReader(_xmlfilepath);
                string strFDtls = objSRdr.ReadToEnd();

                objSRdr.Close();
                objSRdr.Dispose();

                string strXmlTag =@"<?xml version=""1.0"" encoding=""utf-8""?>";
                string strREACTTag = @"<RXNFILE xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns=""CAS_React_Schema.xsd"">";

                strFDtls = strFDtls.Replace(strXmlTag, "");
                strFDtls = strFDtls.Replace(strREACTTag, "<RXNFILE>");        
                strFDtls = strFDtls.Replace("\r\n              ", "");
                strFDtls = strFDtls.Replace("\r\n            ", "");
                strFDtls = strFDtls.Replace("\r\n          ", "");
                strFDtls = strFDtls.Replace("\r\n        ", "");
                strFDtls = strFDtls.Replace("\r\n      ", "");
                strFDtls = strFDtls.Replace("\r\n    ", "");
                strFDtls = strFDtls.Replace("\r\n  ", "");
                strFDtls = strFDtls.Replace("\r\n ", "");
                strFDtls = strFDtls.Replace("\r\n", "");
                strFDtls = strFDtls.Replace("> <", "><");
                strFDtls = strFDtls.Replace("  ", " ");

                using (StreamWriter objSWriter = new StreamWriter(strNewFile))
                {
                    objSWriter.Write(strFDtls);

                    objSWriter.Close();
                    objSWriter.Dispose();
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       
    }
}
