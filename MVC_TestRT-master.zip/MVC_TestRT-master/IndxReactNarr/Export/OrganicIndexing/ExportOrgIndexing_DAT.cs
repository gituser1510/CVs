﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IndxReactNarr.Generic;
using IndxReactNarr.Common;
using IndxReactNarrDAL;
using System.Data;
using System.IO;
using System.Drawing;
using IndxReactNarrBLL;

namespace IndxReactNarr.Export
{
    public class ExportOrgIndexing
    {
        #region Local & Instance Variables

        public static string textDelimiter = ":: ";
        public static DataTable SplCharReplData = null;
        public static System.Windows.Forms.Label lblFormat = null;
        static Validations objValidations = null;
     
        #endregion

        #region Public variables

        static DataTable dtTANDetails = null;
        static DataTable dtTANKeywords = null;
        static DataTable dtNUMsPAR = null;
        static DataTable dtNUMsCTH = null;
        static IndexingTANInfo objTANInfo = null;

        #endregion

        #region Export DAT file

        /// <summary>
        /// Exports List of TANs to DAT and REP files in the specified location
        /// </summary>
        /// <param name="tanIDsList"></param>
        /// <param name="outputFolderPath"></param>
        /// <param name="fileNameDAT"></param>
        /// <param name="fileNameREP"></param>
        /// <returns></returns>
        public static bool ExportArticleNUMsToDATFile(List<Int32> tanIDsList, string datFileName)
        {
            bool blStatus = false;
            try
            {
                if (tanIDsList != null && !string.IsNullOrEmpty(datFileName))
                {
                    if (tanIDsList.Count > 0)
                    {
                        //Get Greek letters replacements and save in a variable
                        SplCharReplData = NarrativesDB.GetSpecialCharsReplacementsOnApplication(GlobalVariables.ApplicationName);

                        dtTANDetails = null;
                        dtTANKeywords = null;
                        dtNUMsPAR = null;
                        dtNUMsCTH = null;
                        objTANInfo = null;

                        StreamWriter swTAN_DAT = new StreamWriter(datFileName, false, Encoding.UTF8);

                        StringBuilder sbAllTANs = new StringBuilder();
                        StringBuilder sbTANData = null;
                        int TANID = 0;

                        for (int i = 0; i < tanIDsList.Count; i++)
                        {
                            TANID = tanIDsList[i];

                            //Article Info
                            dtTANDetails = ReactDB.GetTANDetailsOnTANID(TANID);
                            if (dtTANDetails != null)
                            {
                                if (dtTANDetails.Rows.Count > 0)
                                {
                                    if (dtTANDetails.Rows[0]["QUERY_TAN"].ToString() == "N")
                                    {
                                        //Article NUMs
                                        dtNUMsPAR = OrganicIndexingDB.GetIndexingNUMsOnTANID(TANID, "NUM_PAR");
                                        dtNUMsCTH = OrganicIndexingDB.GetIndexingNUMsOnTANID(TANID, "NUM_CTH");
                                        
                                        //Get TAN data and write to DAT file
                                        sbTANData = GetTANInfoAndPARInfoForExport(dtTANDetails, dtTANKeywords, dtNUMsPAR, dtNUMsCTH);
                                        sbAllTANs.Append(sbTANData);                                        
                                    }
                                }
                            }
                        }

                        //Write StringBuilder objects data to StreamWriter objects
                        lblFormat = new System.Windows.Forms.Label();
                        lblFormat.Font = new Font("Courier New", 10.0f, FontStyle.Regular);
                        lblFormat.Text = sbAllTANs.ToString();

                        swTAN_DAT.WriteLine(lblFormat.Text.Trim());
                        
                        //Close StreamWriter objects
                        swTAN_DAT.Close();
                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }
        
        /// <summary>
        /// Gets TAN KeyWords
        /// </summary>
        /// <param name="tanKeyWords"></param>
        /// <param name="isReviewTAN"></param>
        /// <returns></returns>
        private static string GetKeywordsStringFromTANKeywords(DataTable tanKeyWords)
        {
            string strKeywords = "";
            try
            {
                if (tanKeyWords != null)
                {          
                    string strKey = "";
                    for (int i = 0; i < tanKeyWords.Rows.Count; i++)
                    {
                        if (tanKeyWords.Rows[i]["KEYWORD"] != null)
                        {
                            if (!string.IsNullOrEmpty(tanKeyWords.Rows[i]["KEYWORD"].ToString().Trim()))
                            {
                                strKey = "KEY" + textDelimiter + tanKeyWords.Rows[i]["KEYWORD"].ToString().Trim();

                                strKeywords = strKeywords.Trim() + "\r\n" + strKey;                                
                            }
                        }
                    }                   
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strKeywords.Trim();
        }
                
        /// <summary>
        /// Gets TAN info StringBuilder
        /// </summary>
        /// <param name="tanDetails"></param>
        /// <param name="tanKeyWords"></param>
        /// <param name="tanPARs"></param>
        /// <returns></returns>
        public static StringBuilder GetTANInfoAndPARInfoForExport(DataTable tanDetails, DataTable tanKeyWords, DataTable tanNUMsPAR, DataTable tanNUMsCTH)
        {
            StringBuilder sbTANData = new StringBuilder();
            try
            {
                if (tanDetails != null)
                {
                    if (tanDetails.Rows.Count > 0)
                    {
                        if (objValidations == null)
                        {
                            objValidations = new Validations();
                        }
                                                
                        //Get Greek letters replacements and save in a variable
                        if (SplCharReplData == null)
                        {
                            SplCharReplData = NarrativesDB.GetSpecialCharsReplacementsOnApplication(GlobalVariables.ApplicationName);
                        }

                        //TAN
                        sbTANData.AppendLine("TAN" + textDelimiter + tanDetails.Rows[0]["TAN_NAME"].ToString());
                        sbTANData.AppendLine(string.Empty);

                        //Section-Sub.Section
                        sbTANData.AppendLine("SEC-SUB" + textDelimiter + tanDetails.Rows[0]["TAN_SECTION"].ToString() + "-" + tanDetails.Rows[0]["SUB_SECTION"].ToString().Trim());
                        
                        //Cross Reference
                        if (!string.IsNullOrEmpty(tanDetails.Rows[0]["CROSS_REFERENCE"].ToString()))
                        {
                            sbTANData.AppendLine("CRF" + textDelimiter + tanDetails.Rows[0]["CROSS_REFERENCE"].ToString().Trim());                            
                        }

                        //SPA: HDR
                        if (!string.IsNullOrEmpty(tanDetails.Rows[0]["SPA_HDR"].ToString()))
                        {
                            //if (Convert.ToBoolean(tanDetails.Rows[0]["SPA_HDR"].ToString()))
                            if (tanDetails.Rows[0]["SPA_HDR"].ToString().ToUpper() == "Y")
                            {
                                sbTANData.AppendLine("SPA" + textDelimiter + "HDR");
                            }
                            else//If no graphic issues add empty SPA
                            {
                                sbTANData.AppendLine("SPA" + textDelimiter);
                            }
                        }
                        else//If no graphic issues add empty SPA
                        {
                            sbTANData.AppendLine("SPA" + textDelimiter);
                        }

                        //Title
                        if (!string.IsNullOrEmpty(tanDetails.Rows[0]["TITLE"].ToString()))
                        {
                            //sbTANData.AppendLine("TTL" + textDelimiter + Validations.ConvertSpecialChars(htmlRtfConv.GetRTFfromHTMLString(tanDetails.Rows[0]["TITLE"].ToString().Trim())));
                            sbTANData.AppendLine("TTL" + textDelimiter + Html_RtfConversions.Instance.GetExportFormatStringFromHtmlString(tanDetails.Rows[0]["TITLE"].ToString().Trim()));
                        }

                        //Abstract
                        if (!string.IsNullOrEmpty(tanDetails.Rows[0]["ABSTRACT"].ToString()))
                        {
                            string[] saValues = tanDetails.Rows[0]["ABSTRACT"].ToString().Trim().Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
                            if (saValues != null)
                            {
                                if (saValues.Length > 0)
                                {
                                    foreach (string abs in saValues)
                                    {
                                        if (!string.IsNullOrEmpty(abs))
                                        {
                                            sbTANData.AppendLine("ABS" + textDelimiter + Html_RtfConversions.Instance.GetExportFormatStringFromHtmlString(abs.Trim()));
                                        }
                                    }
                                }
                            }
                        }

                        //Keys
                        tanKeyWords = GetKeysTableFromString(tanDetails.Rows[0]["KEYWORDS"].ToString().Trim());
                        sbTANData.AppendLine(GetKeywordsStringFromTANKeywords(tanKeyWords));
                        sbTANData.AppendLine(string.Empty);
                        
                        //TMD                        
                        string strTMD = "";
                        if (!string.IsNullOrEmpty(tanDetails.Rows[0]["TMD"].ToString()))
                        {
                            strTMD = Html_RtfConversions.Instance.GetExportFormatStringFromHtmlString(tanDetails.Rows[0]["TMD"].ToString().Trim());
                        }
                          
                        //NUMs - Regular Series
                        if (tanNUMsPAR != null)
                        {
                            if (tanNUMsPAR.Rows.Count > 0)
                            {
                                for (int i = 0; i < tanNUMsPAR.Rows.Count; i++)
                                {
                                    //NUM
                                    sbTANData.AppendLine("NUM" + textDelimiter + tanNUMsPAR.Rows[i]["NUM"].ToString());

                                    #region PAR Old code commented
                                    //if (!string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["par"].ToString()))
                                    //{
                                    //    sbTANData.AppendLine("PAR" + textDelimiter + Validations.ConvertSpecialChars(tanNUMsPAR.Rows[i]["par"].ToString()));// RemoveSpecialCharsInString(tanPARs.Rows[i]["PAR"].ToString()));
                                    //}
                                    //else 
                                    //{
                                    //    //An index entry for a substance must contain either a PAR field or a NOT field.  
                                    //    //If you do not supply the substance name in the PAR field, you must add the NOT field and place “NN” in that filed indicating that no-name is being supplied.

                                    //    sbTANData.AppendLine("NOT" + textDelimiter + "NN");
                                    //} 
                                    #endregion

                                    //PAR
                                    //PAR/REG/MOL for substances - 27th March 2014
                                    //1.If a REG is returned, leave the PAR field blank and add NOT:: NN (required for a blank PAR field)
                                    //2.If a MOL file is returned, leave the PAR field blank and add NOT:: NN (required for a blank PAR field)
                                    //3.If the substance is in the exclusion list (no REG and no MOL file is returned), add the name to the PAR field. Please note the substance name should be as accurate as possible, including substituent groups and spaces. Please note usually the addition editing is required if the substance names from authors are used.
                                    //In all cases, NMO:: NNM is always required

                                    //An index entry for a substance must contain either a PAR field or a NOT field. 
                                    //If you do not supply the substance name in the PAR field, you must add the NOT field and place “NN” in that filed indicating that no-name is being supplied.

                                    if (!string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["REG_NO"].ToString()) || !string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["MOL_FILE"].ToString()))
                                    {                                       
                                        sbTANData.AppendLine("NOT" + textDelimiter + "NN");
                                    }
                                    else if (tanNUMsPAR.Rows[i]["NO_STRUCT"].ToString().ToUpper() == "Y")
                                    {
                                        sbTANData.AppendLine("PAR" + textDelimiter + Html_RtfConversions.Instance.GetExportFormatStringFromHtmlString(tanNUMsPAR.Rows[i]["PAR"].ToString().Trim()));                                      
                                    }                                    
                                    
                                    //HMD
                                    if (!string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["HMD"].ToString()))
                                    {
                                        sbTANData.AppendLine("HMD" + textDelimiter + Validations.ConvertSpecialChars(tanNUMsPAR.Rows[i]["HMD"].ToString().Trim()));
                                    }

                                    //AMD
                                    if (!string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["AMD"].ToString()))
                                    {
                                        sbTANData.AppendLine("AMD" + textDelimiter + Validations.ConvertSpecialChars(tanNUMsPAR.Rows[i]["AMD"].ToString().Trim()));
                                    }

                                    //Role
                                    if (!string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["NUM_ROLE"].ToString()))
                                    {
                                        sbTANData.AppendLine("ROL" + textDelimiter + tanNUMsPAR.Rows[i]["NUM_ROLE"].ToString().Trim());
                                    }  
                                 
                                    //TMD
                                    //if (!string.IsNullOrEmpty(strTMD))
                                    //{
                                    //    sbTANData.AppendLine("TMD" + textDelimiter + strTMD);
                                    //}

                                    //If NUM TMD is available then take NUM TMD else regular TMD
                                    if (!string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["NUM_TMD"].ToString()))
                                    {
                                        //TMD
                                        sbTANData.AppendLine("TMD" + textDelimiter + Html_RtfConversions.Instance.GetExportFormatStringFromHtmlString(tanNUMsPAR.Rows[i]["NUM_TMD"].ToString().Trim()));
                                    }
                                    else //if CTH type is MolStructure/Crystal Structure, add CTH TMD
                                    {
                                        sbTANData.AppendLine("TMD" + textDelimiter + strTMD);
                                    } 

                                    //RegistryNo
                                    if (!string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["REG_NO"].ToString()))
                                    {                                       
                                        //RegistryNo
                                        sbTANData.AppendLine("REG" + textDelimiter + tanNUMsPAR.Rows[i]["REG_NO"].ToString().Trim());

                                        //DPT RS
                                        if (!string.IsNullOrEmpty(tanNUMsPAR.Rows[i]["DPT_RS"].ToString()))
                                        {
                                            if (tanNUMsPAR.Rows[i]["DPT_RS"].ToString().ToUpper() == "Y")
                                            {                                               
                                                sbTANData.AppendLine("DPT" + textDelimiter + "RS");
                                            }
                                        }                                        
                                    }

                                    //NMO NNM
                                    //For NUM-PAR, add NMO::NNM                                    
                                    sbTANData.AppendLine("NMO" + textDelimiter + "NNM");
                                    
                                    //Add empty line
                                    sbTANData.AppendLine(string.Empty);
                                }
                            }
                        }

                        //NUMs - 800 series
                        if (tanNUMsCTH != null)
                        {
                            if (tanNUMsCTH.Rows.Count > 0)
                            {
                                int cthNUM = 800;//CTH NUMs should Start with 800
                                for (int i = 0; i < tanNUMsCTH.Rows.Count; i++)
                                {
                                    //Increment cthNUM
                                    cthNUM++;

                                    //NUM
                                    sbTANData.AppendLine("NUM" + textDelimiter + cthNUM);//tanNUMsCTH.Rows[i]["NUM"].ToString()

                                    //CTH
                                    if (!string.IsNullOrEmpty(tanNUMsCTH.Rows[i]["CTH"].ToString()))
                                    {
                                        sbTANData.AppendLine("CTH" + textDelimiter + tanNUMsCTH.Rows[i]["CTH"].ToString().Trim());
                                    }

                                    //HMD
                                    if (!string.IsNullOrEmpty(tanNUMsCTH.Rows[i]["HMD"].ToString()))
                                    {
                                        sbTANData.AppendLine("HMD" + textDelimiter + Validations.ConvertSpecialChars(tanNUMsCTH.Rows[i]["HMD"].ToString().Trim()));
                                    }

                                    //Role
                                    if (!string.IsNullOrEmpty(tanNUMsCTH.Rows[i]["NUM_ROLE"].ToString()))
                                    {
                                        sbTANData.AppendLine("ROL" + textDelimiter + tanNUMsCTH.Rows[i]["NUM_ROLE"].ToString().Trim());
                                    }

                                    //If CTH Type is General, add regular TMD
                                    if (tanNUMsCTH.Rows[i]["CTH_TYPE"].ToString().ToUpper() == "GENERAL")
                                    {
                                        //TMD
                                        sbTANData.AppendLine("TMD" + textDelimiter + strTMD);
                                    }
                                    else //if CTH type is MolStructure/Crystal Structure, add CTH TMD
                                    {
                                        //CTH-TMD
                                        if (!string.IsNullOrEmpty(tanNUMsCTH.Rows[i]["NUM_TMD"].ToString()))
                                        {
                                            sbTANData.AppendLine("TMD" + textDelimiter + (Html_RtfConversions.Instance.GetExportFormatStringFromHtmlString(tanNUMsCTH.Rows[i]["NUM_TMD"].ToString().Trim())));
                                        }
                                    }                                    

                                    ////If NUM-PAR is null then add TMD
                                    //if (tanNUMsPAR.Rows.Count == 0)
                                    //{
                                    //    //TMD
                                    //    sbTANData.AppendLine("TMD" + textDelimiter + strTMD);
                                    //}

                                    //Add empty line
                                    sbTANData.AppendLine(string.Empty);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return sbTANData;
        }

        private static DataTable GetKeysTableFromString(string keywords)
        {
            DataTable dtKeys = null;
            try
            {
                if (!string.IsNullOrEmpty(keywords.Trim()))
                {
                    string[] saKeys = keywords.Trim().Split(new string[] { "``" }, StringSplitOptions.RemoveEmptyEntries);
                    if (saKeys != null)
                    {
                        if (saKeys.Length > 0)
                        {
                            dtKeys = new DataTable();
                            
                            DataColumn colKey = new DataColumn("TK_ID");
                            colKey.DataType = System.Type.GetType("System.Int32");
                            colKey.AutoIncrement = true;
                            colKey.AutoIncrementSeed = 1;

                            dtKeys.Columns.Add(colKey);
                            dtKeys.Columns.Add("KEYWORD");

                            foreach (string key in saKeys)
                            {
                                DataRow dtRow = dtKeys.NewRow();
                                dtRow["KEYWORD"] = key.Trim();
                                dtKeys.Rows.Add(dtRow);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtKeys;
        }

        /// <summary>
        /// Remove special chars in PAR stirng 
        /// </summary>
        /// <param name="par"></param>
        /// <returns></returns>
        private static string RemoveSpecialCharsInString(string par)
        {
            string strPAR = "";
            try
            {
                if (!string.IsNullOrEmpty(par) && SplCharReplData != null)
                {
                    StringBuilder sbPAR = new StringBuilder();
                    //for (int i = 0; i < par.Length; i++)
                    //{
                    //    sbPAR.Append(GetReplacementCharForSpecialChar(par[i].ToString()));
                    //}
                    sbPAR.Append(GetReplacementCharForSpecialChar(par));
                    strPAR = sbPAR.ToString();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strPAR;
        }

        /// <summary>
        /// Replacement of special chars
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        private static string GetReplacementCharForSpecialChar(string source)
        {
            string strReplChar = "";
            try
            {
                if (!string.IsNullOrEmpty(source))
                {
                    strReplChar = source;
                    strReplChar = Validations.ConvertSpecialChars(source);
                    //if (SplCharReplData != null)
                    //{
                    //    for (int rIndx = 0; rIndx < SplCharReplData.Rows.Count; rIndx++)
                    //    {
                    //        if (source == SplCharReplData.Rows[rIndx]["SPECIAL_CHAR"].ToString())
                    //        {
                    //            strReplChar = SplCharReplData.Rows[rIndx]["REPLACEMENT_CHAR"].ToString();
                    //            break;
                    //        }
                    //    }
                    //}
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strReplChar;
        }

        #endregion  
      
        #region Export to REP file

        /// <summary>
        /// Export REP file 
        /// </summary>
        /// <param name="tansList"></param>
        /// <param name="repFileName"></param>
        /// <returns></returns>
        public static bool ExportQueryTANsToREPFile(List<Int32> tanIDsList, string repFileName)
        {
            bool blStatus = false;
            try
            {
                if (tanIDsList != null && !string.IsNullOrEmpty(repFileName))
                {
                    if (tanIDsList.Count > 0)
                    {
                       //Get Query TANs info in the TANs list 
                        DataTable dtQryTANs = OrganicIndexingDB.GetIndexingQueryTANs(tanIDsList);
                        if (dtQryTANs != null)
                        {
                            if (dtQryTANs.Rows.Count > 0)
                            {
                                StreamWriter swTAN_REP = new StreamWriter(repFileName, false, Encoding.UTF8);
                                StringBuilder sbRepTANs = new StringBuilder();

                                for (int i = 0; i < dtQryTANs.Rows.Count; i++)
                                {
                                    //Only Query TANs will be copied to REP file
                                    if (dtQryTANs.Rows[i]["QUERY_TAN"].ToString().ToUpper() == "Y")
                                    {
                                        if (dtQryTANs.Rows[i]["TAN_COMMENT"].ToString().ToUpper() != "NO REACTIONS IN THE ARTICLE")
                                        {
                                            sbRepTANs.AppendLine(dtQryTANs.Rows[i]["TAN_NAME"].ToString() + " " + dtQryTANs.Rows[i]["TAN_COMMENT"].ToString());
                                        }
                                    }
                                }

                                //Write StringBuilder objects data to StreamWriter objects
                                lblFormat = new System.Windows.Forms.Label();
                                lblFormat.Font = new Font("Courier New", 10.0f, FontStyle.Regular);
                                lblFormat.Text = sbRepTANs.ToString();

                                swTAN_REP.WriteLine(lblFormat.Text.Trim());

                                //Close StreamWriter objects
                                swTAN_REP.Close();
                            }
                            else//Empty REP File
                            {
                                ////Write StringBuilder objects data to StreamWriter objects
                                //lblFormat = new System.Windows.Forms.Label();
                                //lblFormat.Font = new Font("Courier New", 10.0f, FontStyle.Regular);
                                //lblFormat.Text = "30029383N TAN transferred from organic indexing; CAS consulted";
                                //StreamWriter swTAN_REP = new StreamWriter(repFileName, false, Encoding.UTF8);
                                //swTAN_REP.WriteLine(lblFormat.Text.Trim());
                                //swTAN_REP.Close();

                                StreamWriter swTAN_REP = new StreamWriter(repFileName, false, Encoding.UTF8);                               
                                swTAN_REP.Close();
                            }
                        }                
                    }
                    blStatus = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        #endregion
    }
}

