﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using java.io;
using chemaxon.formats;
using chemaxon.util;
using chemaxon.struc;
using IndxReactNarrDAL;

namespace IndxReactNarr.Export
{
    public class ExportToSDF
    {
        public static bool ExportTANNUMsToSDF(List<Int32> tanIDsList,string outFileName)
        {
            bool blWriteStatus = false;            
            try
            {
                if (tanIDsList != null && !string.IsNullOrEmpty(outFileName.Trim()))
                {
                    if (tanIDsList.Count > 0)
                    {
                        DataTable dtNUMs = null;
                        DataTable dtTANDtls = null;

                        using (FileOutputStream fOutStream = new FileOutputStream(outFileName, true))
                        {
                            MolExporter objmExporter = new MolExporter(fOutStream, "sdf");

                            MolHandler objmHandler = null;
                            Molecule objMol = null;
                            string strTNK = "";

                            foreach (int tanid in tanIDsList)
                            {
                                dtTANDtls = ReactDB.GetTANDetailsOnTANID(tanid);
                                dtNUMs = OrganicIndexingDB.GetIndexingNUMsOnTANIDForSdfExport(tanid);

                                if (dtNUMs != null && dtTANDtls != null)
                                {
                                    if (dtNUMs.Rows.Count > 0 && dtTANDtls.Rows.Count > 0)
                                    {
                                        objmHandler = null;
                                        objMol = null;
                                        strTNK = "";

                                        for (int rIndx = 0; rIndx < dtNUMs.Rows.Count; rIndx++)
                                        {
                                            if (!string.IsNullOrEmpty(dtNUMs.Rows[rIndx]["MOL_FILE"].ToString()))//Empty Mol files should not be exported
                                            {
                                                //Molecule
                                                objmHandler = new MolHandler(dtNUMs.Rows[rIndx]["MOL_FILE"].ToString());
                                                objMol = objmHandler.getMolecule();

                                                //TAN
                                                objMol.setProperty("TAN", dtTANDtls.Rows[0]["TAN_NAME"].ToString());

                                                //NUM
                                                objMol.setProperty("NUM", dtNUMs.Rows[rIndx]["NUM"].ToString());

                                                //a chemical name should not be present in the PAR field if a mol file or registry number is returned for that index entry
                                                //PAR is not required in the SDF - Code commented on 25Nov2015
                                                ////PAR
                                                //if (!string.IsNullOrEmpty(dtNUMs.Rows[rIndx]["PAR"].ToString()))
                                                //{
                                                //    objMol.setProperty("PAR", dtNUMs.Rows[rIndx]["PAR"].ToString());
                                                //}

                                                //NOT
                                                if (!string.IsNullOrEmpty(dtNUMs.Rows[rIndx]["NUM_NOTE"].ToString()))
                                                {
                                                    objMol.setProperty("NOT", dtNUMs.Rows[rIndx]["NUM_NOTE"].ToString());
                                                }

                                                //TNK
                                                strTNK = dtTANDtls.Rows[0]["TAN_NAME"].ToString().Trim() + "_" + Convert.ToInt32(dtNUMs.Rows[rIndx]["NUM"].ToString()).ToString("0000");
                                                objMol.setProperty("TNK", strTNK);

                                                objmExporter.write(objMol);
                                            }
                                        }
                                    }
                                }
                            }

                            fOutStream.close();
                            objmExporter.close();
                            
                            blWriteStatus = true;
                            return blWriteStatus;
                        }
                    }            
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blWriteStatus;
        }       
    }
}
