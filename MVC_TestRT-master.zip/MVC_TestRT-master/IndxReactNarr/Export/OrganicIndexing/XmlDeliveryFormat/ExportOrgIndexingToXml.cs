﻿using System;
using System.Collections.Generic;
using IndxReactNarr.Generic;
using IndxReactNarr.Common;
using IndxReactNarrDAL;
using System.Data;
using System.IO;
using System.Xml.Serialization;
using IndxReactNarr.IndexingExport;
using IndxReactNarr.OrgIndxExport_DocInfo;
using IndxReactNarr.Export.Narratives;

namespace IndxReactNarr.Export.OrganicIndexing.XmlDelivery
{
    public static class ExportOrgIndexingToXml
    {
        #region Public variables

        static DataTable dtTANDetails = null;
        //static DataTable dtTANKeywords = null;
        static DataTable dtNUMsPAR = null;
        static DataTable dtNUMsCTH = null;
        //static IndexingTANInfo objTANInfo = null;
               
        static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");

        #endregion

        public static int ExportTANsToDocumentAndIdxXmlFiles(List<Int32> tanIDsList, string folderPath)
        {
            int succTANCnt = 0;
            try
            {
                if (tanIDsList != null && tanIDsList.Count > 0 && !string.IsNullOrEmpty(folderPath))
                {
                    dtTANDetails = null;
                    dtNUMsPAR = null;
                    dtNUMsCTH = null;
                    int TANID = 0;

                    string tanName = string.Empty;
                    string analystID = string.Empty;
                    string docXmlFileName = string.Empty;
                    string idxXmlFileName = string.Empty;
                    string strTMD = string.Empty;
                    bool blDocXmlStatus = false;
                    bool blIdxXmlStatus = false;                    

                    for (int i = 0; i < tanIDsList.Count; i++)
                    {
                        TANID = tanIDsList[i];

                        //Article Info
                        dtTANDetails = ReactDB.GetTANDetailsOnTANID(TANID);

                        //Article NUMs
                        dtNUMsPAR = OrganicIndexingDB.GetIndexingNUMsOnTANID(TANID, "NUM_PAR");
                        dtNUMsCTH = OrganicIndexingDB.GetIndexingNUMsOnTANID(TANID, "NUM_CTH");

                        if (dtTANDetails != null && dtTANDetails.Rows.Count > 0)
                        {
                            //Non-Query TANs to be exported
                            if (dtTANDetails.Rows[0]["QUERY_TAN"].ToString() == "N")
                            {
                                tanName = Convert.ToString(dtTANDetails.Rows[0]["TAN_NAME"]);
                                analystID = rdm.Next(8051, 8060).ToString();

                                docXmlFileName = folderPath + "\\" + "document." + tanName + ".xml";
                                idxXmlFileName = folderPath + "\\" + "idxEntries." + tanName + ".xml";
                                
                                //TAN level TMD
                                strTMD = Convert.ToString(dtTANDetails.Rows[0]["TMD"]);
                                strTMD = Html_RtfConversions.Instance.GetConvertedXmlValueFromHtmlString(strTMD);

                                //Export TAN info to document.{tan}.xml
                                blDocXmlStatus = ExportArticleInfoToDocumentXml(dtTANDetails, docXmlFileName, analystID);
                                
                                //Export Index entries to idxEntries.{tan}.xml
                                blIdxXmlStatus = ExportNUMsToIdxEntriesXml(tanName, dtNUMsPAR, dtNUMsCTH, strTMD, idxXmlFileName, analystID);

                                if (blDocXmlStatus && blIdxXmlStatus)
                                {
                                    succTANCnt++;
                                }
                            }                        
                        }
                    }                    
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return succTANCnt;
        }
       
        /// <summary>
        /// To EXPORT NUMS INFORMATION TO XML
        /// </summary>
        /// <param name="dtNUMsPAR"></param>
        /// <param name="outputFile"></param>
        /// <returns></returns>
        private static bool ExportNUMsToIdxEntriesXml(string tanName, DataTable dtNUMsPAR, DataTable dtNUMsCTH, string tmdHtml, string outputFile, string analystID)
        {
            bool blStatus = false;
            try
            {
                if (dtNUMsPAR != null && dtNUMsCTH != null)
                {
                    findings objfindings = new findings();
                  
                    //Get TAN findings
                    objfindings.findinglist = GetTANFindings(tanName, dtNUMsPAR, dtNUMsCTH, tmdHtml, analystID);
                   
                    //XML Serialization
                    XmlSerializer xmlSer = new XmlSerializer(typeof(findings));
                    using (TextWriter txtWriter = new StreamWriter(outputFile))
                    {
                        xmlSer.Serialize(txtWriter, objfindings);
                        txtWriter.Close();
                        txtWriter.Dispose();

                        System.Xml.XmlDocument XDoc = new System.Xml.XmlDocument();
                        XDoc.Load(outputFile);
                        System.Xml.XmlElement root = XDoc.DocumentElement;

                        XmlRawTextWriter rawWriter = new XmlRawTextWriter(outputFile, System.Text.Encoding.UTF8);
                        rawWriter.Formatting = System.Xml.Formatting.Indented;
                        rawWriter.Indentation = 1;
                        rawWriter.IndentChar = '\t';
                        XDoc.Save(rawWriter);

                        rawWriter.Close();
                    }

                    //Find replace special terms
                    FindAndReplaceSpecialTerms(outputFile);

                    //Trim Index entries
                    TrimIndexEntriesXmlFile(outputFile);

                    blStatus = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        #region document.xml related methods
        
        static Random rdm = new Random();
        public static bool ExportArticleInfoToDocumentXml(DataTable dtTANDetails, string xmlFileName, string analystID)
        {
            bool blStatus = false;
            try
            {
                if (dtTANDetails != null && dtTANDetails.Rows.Count > 0)
                {
                    //string xmlFileName = folderPath + "\\" + "document." + Convert.ToString(dtTANDetails.Rows[0]["TAN_NAME"]) + ".xml";
                    
                    documentInformation docInfo = new documentInformation();
                    docInfo.prodDocID = "2";
                    docInfo.transCode = transCodeRplDelType.rpl;
                    docInfo.dateTimeStamp = "";
                    docInfo.schemaVersion = "";

                    source_Type srcType = new source_Type();
                    srcType.analyst = analystID;//rdm.Next(8051, 8060).ToString();

                    //New modification on 20th Nov 2015
                    //Please replace GVKBIO into GVK in the doc xml for provider
                    srcType.provider = "GVK";// "GVKBIO";

                    docInfo.uri = "http://www.altova.com";
                    docInfo.source = srcType;

                    //TAN, CAN information
                    docInfo.identityGroup = GetDocumentIdentityGroupInfo(dtTANDetails.Rows[0]);

                    //Issue Graphic
                    if (dtTANDetails.Rows[0]["SPA_HDR"].ToString() == "Y")
                    {
                        docInfo.issuegraphicflag = "Y";
                    }

                    //Title information
                    docInfo.documentTitle = GetDocumentTitleInfo(Convert.ToString(dtTANDetails.Rows[0]["TITLE"]));

                    //Abstract information
                    string docAbstract = Convert.ToString(dtTANDetails.Rows[0]["ABSTRACT"]);
                    if (!string.IsNullOrEmpty(docAbstract))
                    {
                        docInfo.@abstract = GetDocumentAbstractInfo(docAbstract);
                    }

                    //Keywords                    
                    docInfo.keywords = GetDocumentKeywords(Convert.ToString(dtTANDetails.Rows[0]["KEYWORDS"]));

                    //XML Serialization
                    XmlSerializer xmlSer = new XmlSerializer(typeof(documentInformation));
                    using (TextWriter txtWriter = new StreamWriter(xmlFileName))
                    {
                        xmlSer.Serialize(txtWriter, docInfo);
                        txtWriter.Close();
                        txtWriter.Dispose();
                                   
                        System.Xml.XmlDocument XDoc = new System.Xml.XmlDocument();
                        XDoc.Load(xmlFileName);
                        System.Xml.XmlElement root = XDoc.DocumentElement;
                        XmlRawTextWriter rawWriter = new XmlRawTextWriter(xmlFileName, System.Text.Encoding.UTF8);
                        rawWriter.Formatting = System.Xml.Formatting.Indented;
                        rawWriter.Indentation = 1;
                        rawWriter.IndentChar = '\t';
                        XDoc.Save(rawWriter);                        
                        rawWriter.Close();

                        blStatus = true;
                    }

                    //Find and Replace <issuegraphicflag>Y</issuegraphicflag> to <issuegraphicflag/> - New modification on 20NOV2015
                    FindAndReplaceSpecialTerms(xmlFileName);

                    //Trim Document xml file
                    TrimDocumentXmlFile(xmlFileName);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }
        
        private static documentTitle GetDocumentTitleInfo(string titleInfo)
        {
            documentTitle docTitle = null;
            try
            {
                if (!string.IsNullOrEmpty(titleInfo))
                {
                    documentTitleCASDocumentTitle docCASTitle = new documentTitleCASDocumentTitle();
                    docCASTitle.isMachineTranslated = false;
                    docCASTitle.Text = new string[] { titleInfo };

                    docTitle = new documentTitle();
                    docTitle.isMachineTranslated = false;
                    docTitle.Items = new object[] { docCASTitle };
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return docTitle;
        }

        private static IndxReactNarr.OrgIndxExport_DocInfo.CaText_Type[][] GetDocumentKeywords(string docKeywords)
        {
            IndxReactNarr.OrgIndxExport_DocInfo.CaText_Type[][] cttDocKeywords = null;
            try
            {
                if (!string.IsNullOrEmpty(docKeywords))
                {
                    string[] saKeywords = docKeywords.Trim().Split(new string[] { "``" }, StringSplitOptions.RemoveEmptyEntries);
                    if (saKeywords != null && saKeywords.Length > 0)
                    {
                        cttDocKeywords = new OrgIndxExport_DocInfo.CaText_Type[saKeywords.Length][];
                        
                        int keyIndx = 0;
                        foreach (string key in saKeywords)
                        {
                            List<IndxReactNarr.OrgIndxExport_DocInfo.CaText_Type> lstKeys = new List<OrgIndxExport_DocInfo.CaText_Type>();

                            string[] saWords = key.Trim().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                            if (saWords != null && saWords.Length > 0)
                            {
                                foreach (string word in saWords)
                                {
                                    IndxReactNarr.OrgIndxExport_DocInfo.CaText_Type caTTKey = new OrgIndxExport_DocInfo.CaText_Type();
                                    caTTKey.Text = new string[] { word };
                                    lstKeys.Add(caTTKey);
                                }
                            }
                            cttDocKeywords[keyIndx] = lstKeys.ToArray();
                            keyIndx++;
                        }            
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return cttDocKeywords;
        }

        private static documentInformationAbstract GetDocumentAbstractInfo(string tanAbstract)
        {
            documentInformationAbstract docInfoAbstract = null;
            try
            {
                if (!string.IsNullOrEmpty(tanAbstract))
                {
                    docInfoAbstract = new documentInformationAbstract();

                    string[] saValues = tanAbstract.Trim().Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
                    if (saValues != null && saValues.Length > 0)
                    {
                        List<IndxReactNarr.OrgIndxExport_DocInfo.CaText_Type> lstCaTxtType = new List<OrgIndxExport_DocInfo.CaText_Type>();
                        List<ItemsChoiceType9> itemCh = new List<ItemsChoiceType9>();
                        foreach (string abs in saValues)
                        {
                            if (!string.IsNullOrEmpty(abs))
                            {
                                OrgIndxExport_DocInfo.CaText_Type caTxtType = new OrgIndxExport_DocInfo.CaText_Type();
                                //caTxtType.Text = new string[] { abs };
                                caTxtType.Text = new string[] { Html_RtfConversions.Instance.GetConvertedXmlValueFromHtmlString(abs) };
                                caTxtType.ItemsElementName = new ItemsChoiceType1[] { ItemsChoiceType1.bold, ItemsChoiceType1.ital, ItemsChoiceType1.sub, ItemsChoiceType1.sup };
                                itemCh.Add(ItemsChoiceType9.sentence);
                                //Add to list
                                lstCaTxtType.Add(caTxtType);
                            }
                        }
                      
                        docInfoAbstract.Items = lstCaTxtType.ToArray();
                        docInfoAbstract.ItemsElementName = itemCh.ToArray();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return docInfoAbstract;
        }

        private static documentInformationIdentityGroup GetDocumentIdentityGroupInfo(DataRow tanRowData)
        {
            documentInformationIdentityGroup identityGrp = null;
            try
            {
                if (tanRowData != null && tanRowData.ItemArray.Length > 0)
                {
                    identityGrp = new documentInformationIdentityGroup();

                    string tanName = Convert.ToString(tanRowData["TAN_NAME"]);
                    string tanSec = Convert.ToString(tanRowData["TAN_SECTION"]);
                    string tanSubSec = Convert.ToString(tanRowData["SUB_SECTION"]);
                    string tanCrossRefSec = Convert.ToString(tanRowData["CROSS_REFERENCE"]);

                    identityGrp.section = GetTANSectionInfo(tanSec, tanSubSec, tanCrossRefSec);
                    identityGrp.casIdentity = GetTANInfo(tanName);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return identityGrp;
        }

        private static documentInformationIdentityGroupSection GetTANSectionInfo(string tanSection, string subSection, string crossrefSection)
        {
            documentInformationIdentityGroupSection secInfo = null;
            try
            {
                if (!string.IsNullOrEmpty(tanSection))
                {
                    secInfo = new documentInformationIdentityGroupSection();
                    secInfo.caSection = tanSection;
                    secInfo.caSubSection = subSection;

                    if (!string.IsNullOrEmpty(crossrefSection))
                    {
                        string[] saCrossRef = crossrefSection.Trim().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                        secInfo.caSectionXref = saCrossRef;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return secInfo;
        }

        private static documentInformationIdentityGroupCasIdentity[] GetTANInfo(string tanName)
        {
            documentInformationIdentityGroupCasIdentity[] oaCasIdentInfo = null;
            try
            {
                if (!string.IsNullOrEmpty(tanName))
                {
                    List<documentInformationIdentityGroupCasIdentity> lstCasIdenInfo = new List<documentInformationIdentityGroupCasIdentity>();
                    documentInformationIdentityGroupCasIdentity casIdentInfo = new documentInformationIdentityGroupCasIdentity();
                    casIdentInfo.tan = tanName;

                    lstCasIdenInfo.Add(casIdentInfo);

                    if (lstCasIdenInfo != null)
                    {
                        oaCasIdentInfo = lstCasIdenInfo.ToArray();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return oaCasIdentInfo;
        } 

        #endregion

        #region idxEntries.xml related mehtods

        private static FindingList_Type[] GetTANFindings(string tanName, DataTable dtNUMsPAR, DataTable dtNUMsCTH, string tmdHtml, string analystID)
        {
            FindingList_Type[] oaFindingLstType = null;
            try
            {
                if (dtNUMsPAR != null && dtNUMsCTH != null)
                {
                    List<FindingList_Type> lstFindingLstType = new List<FindingList_Type>();
                    
                    FindingList_Type findingLstType = new FindingList_Type();

                    //New modification on 20NOV2015
                    //1. Please replace GVKBIO to /finder-robot/gvk in the ie xml for source and
                    //2. Please replace GVKBIO into GVK in the doc xml for provider

                    findingLstType.source = "/finder-robot/gvk";// "GVKBIO";

                    //Get TAN properties
                    findingLstType.properties = GetTANPropertiesList(tanName, analystID);

                    //Get TAN findings
                    findingLstType.finding = GetTANFindingsListFromPARs_CTHs(dtNUMsPAR, dtNUMsCTH, tmdHtml);

                    //Add findings to list
                    lstFindingLstType.Add(findingLstType);

                    //Convert List to Array
                    oaFindingLstType = lstFindingLstType.ToArray();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return oaFindingLstType;
        }

        //Get TAN Properties for idxEntries.xml
        private static PropertyList_TypeProperty[] GetTANPropertiesList(string tanName, string analystID)
        {
            PropertyList_TypeProperty[] oaPropListType = null;
            try
            {
                List<PropertyList_TypeProperty> lstPropLstType = new List<PropertyList_TypeProperty>();
                IndxReactNarr.IndexingExport.CaText_Type caTextType = new IndxReactNarr.IndexingExport.CaText_Type();

                //TAN Name                
                PropertyList_TypeProperty tpTAN = new PropertyList_TypeProperty();
                tpTAN.name = "tan";                                
                caTextType.Text = new string[] { tanName };
                tpTAN.value = caTextType;
                lstPropLstType.Add(tpTAN);

                //Analyst
                caTextType = new IndxReactNarr.IndexingExport.CaText_Type();
                caTextType.Text = new string[] { "GVK." + analystID };
                PropertyList_TypeProperty tpAnalyst = new PropertyList_TypeProperty();
                tpAnalyst.name = "provider-analyst";
                tpAnalyst.value = caTextType;
                lstPropLstType.Add(tpAnalyst);

                //Date-Time
                caTextType = new IndxReactNarr.IndexingExport.CaText_Type();           
                PropertyList_TypeProperty tpDateTime = new PropertyList_TypeProperty();
                tpDateTime.name = "datetime";
                caTextType.Text = new string[] { GetDateTimeString() }; //dateTime.ToString("yyyy-MM-dd HH:MM:ss EDT") };

                tpDateTime.value = caTextType;
                lstPropLstType.Add(tpDateTime);

                //Convert List to Array
                oaPropListType = lstPropLstType.ToArray();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return oaPropListType;
        }

        private static Finding_Type[] GetTANFindingsListFromPARs_CTHs(DataTable dtNUMsPAR, DataTable dtNUMsCTH, string tmdHtml)
        {
            Finding_Type[] oaFindingType = null;

            try
            {
                List<Finding_Type> lstTANFindings = new List<Finding_Type>();

                //PAR NUMs
                List<Finding_Type> lstFindingType_PAR = GetPARNUMsFindingsList(dtNUMsPAR, tmdHtml);

                //CTH NUMs
                List<Finding_Type> lstFindingType_CTH = GetCTHNUMsFindingsList(dtNUMsCTH, tmdHtml);

                if (lstFindingType_PAR != null)
                {
                    lstTANFindings.AddRange(lstFindingType_PAR);
                }

                if (lstFindingType_CTH != null)
                {
                    lstTANFindings.AddRange(lstFindingType_CTH);
                }

                //Convert list to Array
                if (lstTANFindings.Count > 0)
                {
                    oaFindingType = lstTANFindings.ToArray();
                }               
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return oaFindingType;
        }

        private static List<Finding_Type> GetPARNUMsFindingsList(DataTable dtNUMsPAR, string tmdHtml)
        {
            List<Finding_Type> lstFindingType = null;
            try
            {
                if (dtNUMsPAR != null && dtNUMsPAR.Rows.Count > 0)
                {
                    lstFindingType = new List<Finding_Type>();

                    List<PropertyList_TypeProperty> lstPropListTypes = null;
                    PropertyList_TypeProperty propLstType = null;                                   
                    Finding_Type findingType = null;
                    string srcDocGUID = "";

                    //NUM PARs
                    foreach (DataRow dr in dtNUMsPAR.Rows)
                    {
                        //Source document Index term
                        if (!string.IsNullOrEmpty(dr["SOURCE_DOC_INDEX_TERM"].ToString()))//SRC_INDEX_TERM //dr["NUM"].ToString().Trim()
                        {
                            lstPropListTypes = new List<PropertyList_TypeProperty>();

                            //Generate version 4 GUID
                            srcDocGUID = Guid.NewGuid().ToString();

                            //Define findingType and add attribute as 'manual-base-text'
                            findingType = new Finding_Type();
                            findingType.findingtype = "manual-base-text";
                            findingType.id = srcDocGUID;
                            findingType.Item = GetSourceIndexTermLocationType(dr["FILE_UU_ID"].ToString());

                            //Add DateTime 
                            propLstType = GetPropertyListTypeForColumnValue("datetime", GetDateTimeString());
                            lstPropListTypes.Add(propLstType);

                            //Source document Index term
                            propLstType = GetPropertyListTypeForColumnValue("text", dr["SOURCE_DOC_INDEX_TERM"].ToString().Trim());
                            lstPropListTypes.Add(propLstType);

                            //Add properties to FindingType
                            findingType.properties = lstPropListTypes.ToArray();

                            //Add finding type to list
                            lstFindingType.Add(findingType);
                        }

                        findingType = new Finding_Type();
                        findingType.findingtype = "manual-analysis-approved";
                        findingType.id = Guid.NewGuid().ToString();
                        lstPropListTypes = new List<PropertyList_TypeProperty>();                     
                        propLstType = null;                       

                        //Add DateTime    
                        propLstType = GetPropertyListTypeForColumnValue("datetime", GetDateTimeString());
                        lstPropListTypes.Add(propLstType);

                        //NUM
                        if (!string.IsNullOrEmpty(dr["NUM"].ToString().Trim()))
                        {                           
                            propLstType = GetPropertyListTypeForColumnValue("NUM", dr["NUM"].ToString().Trim());
                            lstPropListTypes.Add(propLstType);
                        }

                        //New validation on 12th Aug 2015
                        //If PAR and molfile exists NOT:: should be NN in DAT file [because NOT information will go to client in SDF file for mol files].
                        if (!string.IsNullOrEmpty(dr["PAR"].ToString()) && !string.IsNullOrEmpty(dr["MOL_FILE"].ToString()))
                        {
                            //sbTANData.AppendLine("NOT" + textDelimiter + "NN");

                            propLstType = GetPropertyListTypeForColumnValue("NOT", dr["NUM_NOTE"].ToString()); //GetPropertyListTypeForColumnValue("NOT", "NN");
                            lstPropListTypes.Add(propLstType);
                        }
                        else if (!string.IsNullOrEmpty(dr["REG_NO"].ToString()) || !string.IsNullOrEmpty(dr["MOL_FILE"].ToString()))
                        {
                            // sbTANData.AppendLine("NOT" + textDelimiter + "NN");

                            if (!string.IsNullOrEmpty(dr["NUM_NOTE"].ToString()))//New validation on 7th Aug 2015
                            {
                                //sbTANData.AppendLine("NOT" + textDelimiter + dr["NUM_NOTE"].ToString());
                                
                                propLstType = GetPropertyListTypeForColumnValue("NOT", dr["NUM_NOTE"].ToString());
                                lstPropListTypes.Add(propLstType);
                            }
                            else
                            {
                                //sbTANData.AppendLine("NOT" + textDelimiter + "NN");
                                
                                propLstType = GetPropertyListTypeForColumnValue("NOT", "NN");  
                                lstPropListTypes.Add(propLstType);
                            }
                        }
                        else if (dr["NO_STRUCT"].ToString().ToUpper() == "Y")
                        {
                            //sbTANData.AppendLine("PAR" + textDelimiter + Html_RtfConversions.Instance.GetExportFormatStringFromHtmlString(tanNUMsPAR.Rows[i]["PAR"].ToString().Trim()));                                      

                            //New validaion on 7th Aug 2015
                            if (!string.IsNullOrEmpty(dr["PAR"].ToString()))
                            {
                                //sbTANData.AppendLine("PAR" + textDelimiter + Html_RtfConversions.Instance.GetExportFormatStringFromHtmlString(dr["PAR"].ToString().Trim()));

                                propLstType = GetPropertyListTypeForColumnValue("PAR", dr["PAR"].ToString().Trim());  
                                lstPropListTypes.Add(propLstType);
                            }
                            else if (!string.IsNullOrEmpty(dr["NUM_NOTE"].ToString()))
                            {
                                //sbTANData.AppendLine("NOT" + textDelimiter + dr["NUM_NOTE"].ToString());
                                                              
                                propLstType = GetPropertyListTypeForColumnValue("NOT", dr["NUM_NOTE"].ToString().Trim());  
                                lstPropListTypes.Add(propLstType);
                            }
                        }
                        
                        //HMD
                        if (!string.IsNullOrEmpty(dr["HMD"].ToString()))
                        {
                            propLstType = GetPropertyListTypeForColumnValue("HMD", dr["HMD"].ToString().Trim());                            
                            lstPropListTypes.Add(propLstType);
                        }

                        //AMD
                        if (!string.IsNullOrEmpty(dr["AMD"].ToString()))
                        {
                            propLstType = GetPropertyListTypeForColumnValue("AMD", dr["AMD"].ToString().Trim());                           
                            lstPropListTypes.Add(propLstType);
                        }

                        //Role
                        if (!string.IsNullOrEmpty(dr["NUM_ROLE"].ToString()))
                        {
                            propLstType = GetPropertyListTypeForColumnValue("ROL", dr["NUM_ROLE"].ToString().Trim());                            
                            lstPropListTypes.Add(propLstType);
                        }

                        //If NUM TMD is available then take NUM TMD else regular TMD
                        if (!string.IsNullOrEmpty(dr["NUM_TMD"].ToString()))
                        {
                            //TMD
                            propLstType = GetPropertyListTypeForColumnValue("TMD", dr["NUM_TMD"].ToString().Trim());                           
                            lstPropListTypes.Add(propLstType);
                        }
                        else 
                        {
                            if (!string.IsNullOrEmpty(tmdHtml))
                            {
                                propLstType = GetPropertyListTypeForColumnValue("TMD", tmdHtml);                                
                                lstPropListTypes.Add(propLstType);
                            }
                        }

                        //RegistryNo
                        if (!string.IsNullOrEmpty(dr["REG_NO"].ToString()))
                        {
                            //RegistryNo
                            propLstType = GetPropertyListTypeForColumnValue("REG", dr["REG_NO"].ToString().Trim());                           
                            lstPropListTypes.Add(propLstType);

                            //DPT RS
                            if (dr["DPT_RS"].ToString().ToUpper() == "Y")
                            {
                                propLstType = GetPropertyListTypeForColumnValue("DPT", "RS");                                
                                lstPropListTypes.Add(propLstType);
                            }
                        }

                        //NMO NNM
                        //For NUM-PAR, add NMO::NNM 
                        propLstType = GetPropertyListTypeForColumnValue("NMO", "NNM");                         
                        lstPropListTypes.Add(propLstType);

                        //Add properties to FindingType
                        findingType.properties = lstPropListTypes.ToArray();

                        //Add references to FindingType                        
                        findingType.Item = GetIndexTermFindingReferenceType(srcDocGUID);

                        //Add finding type to list
                        lstFindingType.Add(findingType);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstFindingType;
        }

        private static List<Finding_Type> GetCTHNUMsFindingsList(DataTable dtNUMsCTH, string tmdHtml)
        {
            List<Finding_Type> lstFindingType = null;
            try
            {
                if (dtNUMsCTH != null && dtNUMsCTH.Rows.Count > 0)
                {
                    lstFindingType = new List<Finding_Type>();

                    List<PropertyList_TypeProperty> lstPropListTypes = null;
                    PropertyList_TypeProperty propLstType = null;                  
                    Finding_Type findingType = null;
                    string srcDocGUID = "";

                    int cthNUM = 800;//CTH NUMs should Start with 800

                    //NUM CTHs
                    foreach (DataRow dr in dtNUMsCTH.Rows)
                    {
                        //Source document Index term
                        if (!string.IsNullOrEmpty(dr["SOURCE_DOC_INDEX_TERM"].ToString()))//SRC_INDEX_TERM //dr["NUM"].ToString().Trim()
                        {
                            lstPropListTypes = new List<PropertyList_TypeProperty>();

                            //Generate version 4 GUID
                            srcDocGUID = Guid.NewGuid().ToString();

                            //Define findingType and add attribute as 'manual-base-text'
                            findingType = new Finding_Type();
                            findingType.findingtype = "manual-base-text";
                            findingType.id = srcDocGUID;
                            findingType.Item = GetSourceIndexTermLocationType(dr["FILE_UU_ID"].ToString());

                            //Add DateTime  
                            propLstType = GetPropertyListTypeForColumnValue("datetime", GetDateTimeString());
                            lstPropListTypes.Add(propLstType);

                            //Source document Index term
                            propLstType = GetPropertyListTypeForColumnValue("text", dr["SOURCE_DOC_INDEX_TERM"].ToString().Trim());
                            lstPropListTypes.Add(propLstType);

                            //Add properties to FindingType
                            findingType.properties = lstPropListTypes.ToArray();

                            //Add finding type to list
                            lstFindingType.Add(findingType);
                        }

                        findingType = new Finding_Type();
                        findingType.findingtype = "manual-analysis-approved";
                        findingType.id = Guid.NewGuid().ToString();
                        lstPropListTypes = new List<PropertyList_TypeProperty>();
                        propLstType = null;                      

                        //Add DateTime                
                        propLstType = GetPropertyListTypeForColumnValue("datetime", GetDateTimeString());
                        lstPropListTypes.Add(propLstType);

                        //NUM
                        cthNUM++;                        
                        propLstType = GetPropertyListTypeForColumnValue("NUM", cthNUM.ToString().Trim());
                        lstPropListTypes.Add(propLstType);
                        
                        //CTH
                        if (!string.IsNullOrEmpty(dr["CTH"].ToString()))
                        {                           
                            propLstType = GetPropertyListTypeForColumnValue("CTH", dr["CTH"].ToString().Trim());
                            lstPropListTypes.Add(propLstType);
                        }

                        //HMD
                        if (!string.IsNullOrEmpty(dr["HMD"].ToString()))
                        {                          
                            propLstType = GetPropertyListTypeForColumnValue("HMD", dr["HMD"].ToString().Trim());
                            lstPropListTypes.Add(propLstType);
                        }

                        //Role
                        if (!string.IsNullOrEmpty(dr["NUM_ROLE"].ToString()))
                        {                         
                            propLstType = GetPropertyListTypeForColumnValue("ROL", dr["NUM_ROLE"].ToString().Trim());
                            lstPropListTypes.Add(propLstType);
                        }

                        //If CTH Type is General, add regular TMD
                        if (dr["CTH_TYPE"].ToString().ToUpper() == "GENERAL")
                        {
                            if (!string.IsNullOrEmpty(tmdHtml))
                            {
                                propLstType = GetPropertyListTypeForColumnValue("TMD", tmdHtml);                               
                                lstPropListTypes.Add(propLstType);
                            }
                        }
                        else //if CTH type is MolStructure/Crystal Structure, add CTH TMD
                        {                           
                            if (!string.IsNullOrEmpty(dr["NUM_TMD"].ToString()))
                            {                                                        
                                propLstType = GetPropertyListTypeForColumnValue("TMD", dr["NUM_TMD"].ToString().Trim()); 
                                lstPropListTypes.Add(propLstType);
                            }
                        }                        
                        
                        //Add properties to FindingType
                        findingType.properties = lstPropListTypes.ToArray();

                        //Add references to FindingType                        
                        findingType.Item = GetIndexTermFindingReferenceType(srcDocGUID);

                        //Add finding type to list
                        lstFindingType.Add(findingType);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstFindingType;
        }

        private static PropertyList_TypeProperty GetPropertyListTypeForColumnValue(string colName, string colValue)
        {
            PropertyList_TypeProperty propLstType = null;
            try
            {
                if (!string.IsNullOrEmpty(colName) && !string.IsNullOrEmpty(colValue))
                {
                    propLstType = new PropertyList_TypeProperty();
                    IndxReactNarr.IndexingExport.CaText_Type objCaText = new IndxReactNarr.IndexingExport.CaText_Type();

                    propLstType.name = colName;
                    objCaText.Text = new string[] { Html_RtfConversions.Instance.GetConvertedXmlValueFromHtmlString(colValue) };
                    propLstType.value = objCaText;                    
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return propLstType;
        }

        private static ReferenceList_Type GetIndexTermFindingReferenceType(string srcIndxTermUUID)
        {
            ReferenceList_Type lstRefenceType = null;
            try
            {
                if (!string.IsNullOrEmpty(srcIndxTermUUID))
                {
                    lstRefenceType = new ReferenceList_Type();

                    Reference_Type refType = new Reference_Type();
                    refType.target = srcIndxTermUUID;
                    lstRefenceType.reference = new Reference_Type[] { refType };
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstRefenceType;
        }

        private static Location_Type GetSourceIndexTermLocationType(string srcArticleURI)
        {
            Location_Type locType = null;
            try
            {
                if (!string.IsNullOrEmpty(srcArticleURI))
                {
                    BaseFile_Type fileLocType = new BaseFile_Type();
                    fileLocType.uri = "content-item/" + srcArticleURI;

                    locType = new Location_Type();
                    locType.@base = fileLocType;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return locType;
        }

        private static string GetDateTimeString()
        {
            string strDateTime = "";
            try
            {
                //DateTime.UtcNow.ToString("yyyy-MM-ddTHH\\:mm\\:ssZ") }; //dateTime.ToString("yyyy-MM-dd HH:MM:ss EDT") };

               strDateTime = DateTime.UtcNow.ToString("yyyy-MM-ddTHH\\:mm\\:ssZ");
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
           
            return strDateTime;
        }

        #endregion

        private static void FindAndReplaceSpecialTerms(string _xmlfilepath)
        {
            try
            {
                if (!string.IsNullOrEmpty(_xmlfilepath.Trim()))
                {
                    using (StreamReader streamReader = File.OpenText(_xmlfilepath))
                    {
                        // Now, read the entire file into a strin
                        string contents = streamReader.ReadToEnd();
                        streamReader.Close();

                        // Write the modification into the same fil
                        using (StreamWriter streamWriter = File.CreateText(_xmlfilepath))
                        {
                            //New modification on 20NOV2015
                            //Please designate the presence of issue graphics with a flag tag, i.e. “<issuegraphicflag/>”. Do not use longer XML notation or put “Y” or “N” designators within the tag. If no issue graphic structure is present, please omit the tag entirely. 
                            //Please use regular “ascii hypen” with Unicode U+002D, instead of “en dash” (U+2013)

                            contents = contents.Replace("–", "-");
                            contents = contents.Replace("<issuegraphicflag>Y</issuegraphicflag>", "<issuegraphicflag/>");

                            streamWriter.Write(contents);
                            streamWriter.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
               
        private static void TrimDocumentXmlFile(string _xmlfilepath)
        {
            try
            {
                string strDir = Path.GetDirectoryName(_xmlfilepath);
                string strFileName = Path.GetFileName(_xmlfilepath);     
               
                string strNewFile = strDir + "\\" + strFileName;

                using (StreamReader objSRdr = new StreamReader(_xmlfilepath))
                {
                    string strFDtls = objSRdr.ReadToEnd();

                    objSRdr.Close();
                    objSRdr.Dispose();

                    string strXmlTag = @"<?xml version=""1.0"" encoding=""utf-8""?>";
                    //string strREACTTag = @"<RXNFILE xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns=""CAS_React_Schema.xsd"">";
                    string strdocInfoTag = @"<documentInformation xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" dataDomain=""CASEditorial"" dataView=""CASFileLoading"" prodDocID=""2"" dateTimeStamp="""" schemaVersion="""">";

                    strFDtls = strFDtls.Replace(strXmlTag, "");
                    strFDtls = strFDtls.Replace(strdocInfoTag, "<documentInformation>");
                    strFDtls = strFDtls.Replace("\r\n              ", "");
                    strFDtls = strFDtls.Replace("\r\n            ", "");
                    strFDtls = strFDtls.Replace("\r\n          ", "");
                    strFDtls = strFDtls.Replace("\r\n        ", "");
                    strFDtls = strFDtls.Replace("\r\n      ", "");
                    strFDtls = strFDtls.Replace("\r\n    ", "");
                    strFDtls = strFDtls.Replace("\r\n  ", "");
                    strFDtls = strFDtls.Replace("\r\n ", "");
                    strFDtls = strFDtls.Replace("\r\n", "");
                    strFDtls = strFDtls.Replace("\t\t\t", "");
                    strFDtls = strFDtls.Replace("\t\t", "");
                    strFDtls = strFDtls.Replace("\t", "");
                    strFDtls = strFDtls.Replace("> <", "><");
                    strFDtls = strFDtls.Replace("  ", " ");

                    using (StreamWriter objSWriter = new StreamWriter(strNewFile))
                    {
                        objSWriter.Write(strFDtls);

                        objSWriter.Close();
                        objSWriter.Dispose();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private static void TrimIndexEntriesXmlFile(string _xmlfilepath)
        {
            try
            {
                string strDir = Path.GetDirectoryName(_xmlfilepath);
                string strFileName = Path.GetFileName(_xmlfilepath);

                string strNewFile = strDir + "\\" + strFileName;

                using (StreamReader objSRdr = new StreamReader(_xmlfilepath))
                {
                    string strFDtls = objSRdr.ReadToEnd();

                    objSRdr.Close();
                    objSRdr.Dispose();

                    string strXmlTag = @"<?xml version=""1.0"" encoding=""utf-8""?>";
                    //string strREACTTag = @"<RXNFILE xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns=""CAS_React_Schema.xsd"">";
                    string strfindingsTag = @"<findings xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">";

                    strFDtls = strFDtls.Replace(strXmlTag, "");
                    strFDtls = strFDtls.Replace(strfindingsTag, "<findings>");
                    strFDtls = strFDtls.Replace("\r\n              ", "");
                    strFDtls = strFDtls.Replace("\r\n            ", "");
                    strFDtls = strFDtls.Replace("\r\n          ", "");
                    strFDtls = strFDtls.Replace("\r\n        ", "");
                    strFDtls = strFDtls.Replace("\r\n      ", "");
                    strFDtls = strFDtls.Replace("\r\n    ", "");
                    strFDtls = strFDtls.Replace("\r\n  ", "");
                    strFDtls = strFDtls.Replace("\r\n ", "");
                    strFDtls = strFDtls.Replace("\r\n", "");
                    strFDtls = strFDtls.Replace("\t\t\t", "");
                    strFDtls = strFDtls.Replace("\t\t", "");
                    strFDtls = strFDtls.Replace("\t", "");
                    strFDtls = strFDtls.Replace("> <", "><");
                    strFDtls = strFDtls.Replace("  ", " ");

                    using (StreamWriter objSWriter = new StreamWriter(strNewFile))
                    {
                        objSWriter.Write(strFDtls);

                        objSWriter.Close();
                        objSWriter.Dispose();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       
    }
}
