﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using IndxReactNarr.Generic;
using Ionic.Zip;
using System.IO;
using IndxReactNarr.Export.ExperimentalProceduresPilot;
using IndxReactNarr.Export.ExperimentalProceduresPilot.FinalSchema;

namespace IndxReactNarr.Export
{
    public class INR_Export
    {
        public DataTable TANsForExport { get; set; }
        public string ApplicationName { get; set; }
        public bool TrimReactXml { get; set; }
        public string OutputFileName { get; set; }
        public string OutputFilesPath { get; set; }
        public string MarkUpFilesPath { get; set; }

        public bool ExportTANsDataToFiles()
        {
            bool blStatus = false;
            try
            {
                //Set Xml file name
                string strXmlName = "";
                if (!OutputFileName.Trim().ToUpper().StartsWith("RXNFILE."))
                {
                    strXmlName = "rxnfile." + OutputFileName.ToLower().Trim() + "_trim.xml";
                }
                else
                {
                    strXmlName = OutputFileName.ToLower().Trim() + "_trim.xml";
                }

                string xmlFileName = OutputFilesPath + "\\" + strXmlName;
                string sdFilePath = "";
                string datFilePath = "";
                string repFilePath = "";
                string batchName = OutputFileName.Trim().Replace("rxnfile.", "");
                string markupsFilePath = OutputFilesPath + "\\" + "markups." + batchName + ".zip";
                string zipFilePath = OutputFilesPath + "\\" + "main." + batchName + ".zip";
                string strTANCnt = TANsForExport != null ? TANsForExport.Rows.Count.ToString() : "0";

                //Export Reactions to Xml file
                if (ApplicationName.ToUpper() == Enums.ApplicationName.REACT.ToString())
                {
                    ExportReactBatch.ExportToXmlFile(TANsForExport, OutputFilesPath, strXmlName, TrimReactXml);

                    //Generate TAN wise Pdfs & Zip
                    if (!string.IsNullOrEmpty(MarkUpFilesPath))
                    {
                        DataDelivery.IndexingDelivery.GenerateTANwiseFolders(OutputFilesPath, MarkUpFilesPath, batchName);
                    }
                    blStatus = true;
                }

                //Export Narratives to Xml files
                if (ApplicationName.ToUpper() == Enums.ApplicationName.NARRATIVES.ToString())
                {
                    ExportNarratives.ExportTANsToXmlFiles(TANsForExport, OutputFilesPath);
                    blStatus = true;
                }

                //Export Experimental Procedures to Xml files
                if (ApplicationName.ToUpper() == Enums.ApplicationName.EXPPROCEDURES.ToString())
                {
                    //ExportExpProcedures_Pilot.ExportTANsToXmlFiles(TANsForExport, OutputFilesPath);
                    ExportExpProcedures.ExportTANsToXmlFiles(TANsForExport, OutputFilesPath);
                    blStatus = true;
                }

                //Export Organic Indexing to DAT, REP & SDF files
                if (ApplicationName.ToUpper() == Enums.ApplicationName.ORGANIC.ToString() || ApplicationName.ToUpper() == Enums.ApplicationName.MACRO.ToString())
                {
                    //Set Indexing file names
                    sdFilePath = Path.Combine(OutputFilesPath, "structures." + batchName + ".sdf");
                    datFilePath = Path.Combine(OutputFilesPath, "idxEntries." + batchName + ".DAT");
                    repFilePath = Path.Combine(OutputFilesPath, "idxEntries." + batchName + ".REP");

                    //Export to React Xml file
                    ExportReactBatch.ExportToXmlFile(TANsForExport, OutputFilesPath, strXmlName, TrimReactXml);

                    List<int> lstTANs = (from row in TANsForExport.AsEnumerable()
                                         select row.Field<int>("TAN_ID")).ToList<int>();

                    //Export to DAT file
                    if (ApplicationName.ToUpper() == Enums.ApplicationName.ORGANIC.ToString())
                    {
                        IndxReactNarr.Export.ExportOrgIndexing.ExportArticleNUMsToDATFile(lstTANs, datFilePath);
                        //Export to REP file
                        IndxReactNarr.Export.ExportOrgIndexing.ExportQueryTANsToREPFile(lstTANs, repFilePath);

                        //New Xml format from rxnfile.980070 shipment onwards
                        IndxReactNarr.Export.OrganicIndexing.XmlDelivery.ExportOrgIndexingToXml.ExportTANsToDocumentAndIdxXmlFiles(lstTANs, OutputFilesPath);
                    }
                    else if (ApplicationName.ToUpper() == Enums.ApplicationName.MACRO.ToString())
                    {
                        IndxReactNarr.Export.ExportMacroIndexing.ExportArticleNUMsToDATFile(lstTANs, datFilePath);
                        
                        //Export to REP file
                        IndxReactNarr.Export.ExportMacroIndexing.ExportQueryTANsToREPFile(lstTANs, repFilePath);

                        //New Xml format from rxnfile.980071 shipment onwards
                        IndxReactNarr.Export.MacroIndexing.ExportMacroIndexingToXml.ExportTANsToDocumentAndIdxXmlFiles(lstTANs, OutputFilesPath);
                    }

                    //Generate SD file and Zip the file
                    GenerateIndexingSDFile(lstTANs, sdFilePath);
                       
                    //Generate TAN wise Pdfs & Zip
                    if (!string.IsNullOrEmpty(MarkUpFilesPath))
                    {
                        DataDelivery.IndexingDelivery.GenerateTANwiseFolders(OutputFilesPath, MarkUpFilesPath, batchName);
                    }

                    //Zip DAT & REP Files   
                    string repDATZipFile = repFilePath.Replace(".REP", ".zip");
                    using (ZipFile zip = new ZipFile())
                    {
                        if (File.Exists(datFilePath))
                        {
                            zip.AddFile(datFilePath, "");
                        }
                        if (File.Exists(repFilePath))
                        {
                            zip.AddFile(repFilePath, "");
                        }
                        zip.Save(repDATZipFile);
                    }

                    //ZIP Xml File   
                
                    string strXmlfile = xmlFileName.ToLower().Replace("_trim.xml", ".xml");
                    string xmlZipName = strXmlfile.Replace(".xml", ".zip");
                    using (ZipFile zip = new ZipFile())
                    {
                        zip.AddFile(strXmlfile, "");
                        zip.Save(xmlZipName);
                    }

                    //Zip all the files               
                    using (ZipFile zip = new ZipFile())
                    {
                        //Zip SD file
                        if (File.Exists(sdFilePath))
                        {
                            zip.AddFile(sdFilePath.Replace(".sdf", ".zip"), "");
                        }                        

                        if (File.Exists(repDATZipFile))
                        {
                            zip.AddFile(repDATZipFile, "");
                        }

                        //Zip Xml file                      
                        if (File.Exists(xmlZipName))
                        {                           
                            zip.AddFile(xmlZipName, "");
                        }

                        //Zip Marup PDFs
                        if (File.Exists(markupsFilePath))
                        {
                            zip.AddFile(markupsFilePath, "");
                        }

                        zip.Save(zipFilePath);

                        blStatus = true;
                    }
                }               

                //Send confiramtion mail to Supervisors       
                //string mailSubject = "Organic Indexing - Batch " + batchName + " output/delivery report";
                //EmailManager.SendOutputStatusMail(mailSubject, batchName, strTANCnt, zipFilePath, datFilePath, sdFilePath, xmlFileName, markupsFilePath, outFilePath);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }
                      
        #region Organic Indexing Export Methods
              
        //Export to SD file
        private bool GenerateIndexingSDFile(List<int> lstTANs, string sdFilePath)
        {
            bool blStatus = false;
            try
            {
                if (lstTANs != null && !string.IsNullOrEmpty(sdFilePath))
                {
                    if (lstTANs.Count > 0)
                    {
                        string zipFileName = sdFilePath.Replace(".sdf", ".zip");
                        if (ExportToSDF.ExportTANNUMsToSDF(lstTANs, sdFilePath))
                        {
                            blStatus = true;

                            //Zip the SDF file
                            using (ZipFile zip = new ZipFile())
                            {
                                // add this map file into the "images" directory in the zip archive                              
                                zip.AddFile(sdFilePath, "");
                                zip.Save(zipFileName);
                            }
                        }
                        else
                        {
                            blStatus = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        #endregion        
    }
}
