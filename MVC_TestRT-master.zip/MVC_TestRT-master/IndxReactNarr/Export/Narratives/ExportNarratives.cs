﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using IndxReactNarrDAL;
using System.Xml.Serialization;
using IndxReactNarr.Generic;
using IndxReactNarr.NarrExport;
using System.Xml;
using IndxReactNarr.Export.Narratives;

namespace IndxReactNarr.Export
{
    public class ExportNarratives
    {
        static DataTable XMLConvTbl = null;
        static DataTable TANsForExport = null;

        static DataTable TAN_Details = null;
        static DataTable TAN_Documents = null;
        static DataTable TAN_Reactions = null;
                
        static string paraSplitter = "``PARA``";
        static string dataSplitter = "``DATA``";

        public static bool ExportTANsToXmlFiles(DataTable tansForExport, string outputFilesPath)
        {
            bool blStatus = true;
            try
            {
                if (tansForExport != null && !string.IsNullOrEmpty(outputFilesPath))
                {
                    TANsForExport = tansForExport;

                    if (TANsForExport!= null && TANsForExport.Rows.Count > 0)
                    {
                        //Get Xml Conversions data
                        DataTable xmlReplacements = IndxReactNarrDAL.NarrativesDB.GetSpecialCharsReplacementsOnApplication(GlobalVariables.ApplicationName);
                        XMLConvTbl = xmlReplacements.Select("USED_FOR = 'REPLACEMENT'").CopyToDataTable();

                        int tanID = 0;
                        for (int i = 0; i < TANsForExport.Rows.Count; i++)
                        {
                            int.TryParse(TANsForExport.Rows[i]["TAN_ID"].ToString(), out tanID);
                            if (tanID > 0)
                            {
                                TAN_Details = ReactDB.GetTANDetailsOnTANID(tanID);
                                TAN_Reactions = NarrativesDB.GetTANReactionsForExportOnTANID(tanID);
                                TAN_Documents = NarrativesDB.GetTANDocumentsOnTANID(tanID);
                                
                                if (!ExportToXmlFile(outputFilesPath, TAN_Details, TAN_Reactions, TAN_Documents))
                                {
                                    blStatus = false;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private static bool ExportToXmlFile(string outfilepath, DataTable tanDetails, DataTable tanReactions, DataTable tanDocuments)
        {
            bool blStatus = false;
            try
            {
                // DataTable dtTANData = NarrativesDB.GetTANReportView(tan, "TAN");

                if (tanDetails != null)
                {
                    if (tanDetails.Rows.Count > 0)
                    {
                        string stTAN = tanDetails.Rows[0]["TAN_NAME"].ToString();

                        reactionNarratives objRxnNarr = new reactionNarratives();

                        //objRxnNarr.concurrentProcessing = false;//Generating with CASREACT simultaneously.

                        objRxnNarr.documents = GetDocumentTypeFromTAN(tanDetails, tanDocuments);
                        objRxnNarr.reaction = GetReactionTypesFromTANReactions(tanReactions);

                        //XML Serialization
                        XmlSerializer xmlSer = new XmlSerializer(typeof(reactionNarratives));

                        outfilepath = outfilepath + "\\" + stTAN + ".xml";
                        using (TextWriter txtWriter = new StreamWriter(outfilepath))
                        {
                            xmlSer.Serialize(txtWriter, objRxnNarr);
                            blStatus = true;

                            txtWriter.Close();
                            txtWriter.Dispose();

                            //string oldText = File.ReadAllText(outfilepath);
                            //string newText = oldText.Replace("&amp;", "&");
                            //newText = oldText.Replace("&lt;", "<").Replace("&gt;",">");
                            //File.WriteAllText(outfilepath, newText, Encoding.UTF8);

                            System.Xml.XmlDocument XDoc = new System.Xml.XmlDocument();

                            XDoc.Load(outfilepath);
                            System.Xml.XmlElement root = XDoc.DocumentElement;
                            root.SetAttribute("noNamespaceSchemaLocation", "http://www.w3.org/2001/XMLSchema-instance", "ReactionNarrative-1.8.xsd");
                            //XDoc.Save(outfilepath);

                            XmlRawTextWriter rawWriter = new XmlRawTextWriter(outfilepath, Encoding.UTF8);
                            rawWriter.Formatting = Formatting.Indented;
                            rawWriter.Indentation = 1;
                            rawWriter.IndentChar = '\t';
                            XDoc.Save(rawWriter);

                            rawWriter.Close();
                            //<reactionNarratives xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="ReactionNarrative-1.8.xsd">
                        }                                               

                        //==============================

                        #region code commented
                        //XmlWriterSettings xmlWriterSettings = new XmlWriterSettings
                        //{
                        //    Indent = true,
                        //    OmitXmlDeclaration = false,
                        //    Encoding = Encoding.UTF8
                        //};

                        ////using (MemoryStream memoryStream = new MemoryStream())
                        //using (XmlWriter xmlWriter = XmlWriter.Create(outfilepath, xmlWriterSettings))
                        //{
                        //    var x = new System.Xml.Serialization.XmlSerializer(objRxnNarr.GetType());
                        //    x.Serialize(xmlWriter, objRxnNarr);

                        //    //// we just output back to the console for this demo.
                        //    //memoryStream.Position = 0; // rewind the stream before reading back.
                        //    //using (StreamReader sr = new StreamReader(memoryStream))
                        //    //{
                        //    //    Console.WriteLine(sr.ReadToEnd());
                        //    //} // note memory stream disposed by StreamReaders Dispose()
                        //} 
                        #endregion

                        //================================

                        //Find and Replace "~~"
                        FindAndReplaceTextInFile(outfilepath);
                        
                        #region Code commented, Dont' delete
                        //Close TextWriter                            
                        //txtWriter.Close();
                        //txtWriter.Flush();
                        //txtWriter.Dispose();

                        //XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
                        //ns.Add("", "");
                        //System.Xml.XmlWriterSettings settings = new System.Xml.XmlWriterSettings();
                        //settings.OmitXmlDeclaration = true;
                        //settings.Encoding = new UTF8Encoding(false);
                        //settings.Indent = true;
                        //XmlSerializer xs = new XmlSerializer(typeof(reactionNarratives));
                        //MemoryStream ms = new MemoryStream();

                        //outfilepath = outfilepath + "\\" + tan + ".xml";
                        //System.Xml.XmlWriter writer = System.Xml.XmlWriter.Create(ms, settings);
                        //xs.Serialize(writer, null, ns);

                        //string strTemp = Encoding.UTF8.GetString(ms.ToArray());   
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private static void FindAndReplaceTextInFile(string _xmlfilepath)
        {
            try
            {
                if (!string.IsNullOrEmpty(_xmlfilepath.Trim()))
                {
                    StreamReader streamReader = null;
                    streamReader = File.OpenText(_xmlfilepath);
                    // Now, read the entire file into a strin
                    string contents = streamReader.ReadToEnd();
                    streamReader.Close();

                    // Write the modification into the same file
                    using (StreamWriter streamWriter = File.CreateText(_xmlfilepath))
                    {
                        //contents = contents.Replace("&lt;", "<").Replace("&gt;", ">");
                        streamWriter.Write(contents.Replace("~~", ""));
                        streamWriter.Close();
                        streamWriter.Dispose();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private static string SanitizeXml(string source)
        {
            if (string.IsNullOrEmpty(source))
            {
                return source;
            }
            if (source.IndexOf('&') < 0)
            {
                return source;
            }
            StringBuilder result = new StringBuilder(source);
            result = result.Replace("&lt;", "<").Replace("&gt;", ">");
            return result.ToString();
        }

        private static string GetConvertedXmlString(string _xmltag)
        {
            string strConvXml = _xmltag;
            try
            {
                if (!string.IsNullOrEmpty(strConvXml))
                {
                    if (XMLConvTbl != null)
                    {
                        if (XMLConvTbl.Rows.Count > 0)
                        {
                            for (int i = 0; i < XMLConvTbl.Rows.Count; i++)
                            {
                                strConvXml = strConvXml.Replace(XMLConvTbl.Rows[i]["SPECIAL_CHAR"].ToString(), XMLConvTbl.Rows[i]["REPLACEMENT_CHAR"].ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strConvXml;
        }

        #region DocumentType Methods

        private static documentsType GetDocumentTypeFromTAN(DataTable tanData,DataTable tanDocuments)
        {
            documentsType docType = null;
            try
            {
                if (tanData != null)
                {
                    if (tanData.Rows.Count > 0)
                    {
                        List<object> lstDocItems = new List<object>();
                        List<supplementalType> lstSupplType = null;

                        string tanType = tanData.Rows[0]["TAN_TYPE"].ToString();

                        switch (tanType.Trim().ToUpper())
                        {
                            case "JOURNAL":
                                journalArticleType journalType = GetJournalTypeFromRowData(tanData.Rows[0]);
                                lstDocItems.Add(journalType);

                                //Only Journals have Supporting documents
                                lstSupplType = GetSupplementTypeListFromTANDocuments(tanDocuments);
                                break;

                            case "PATENT":
                                patentType patType = GetpatentTypeFromRowData(tanData.Rows[0]);
                                lstDocItems.Add(patType);
                                break;

                            case "DISSERTATION":
                                dissertationType objDisserType = GetDissertationTypeFromRowData(tanData.Rows[0]);
                                lstDocItems.Add(objDisserType);
                                break;
                        }
                                              
                       if (lstSupplType != null)
                       {
                           lstDocItems.AddRange(lstSupplType.Cast<object>().ToArray());
                       }

                       docType = new documentsType();
                       docType.Items = lstDocItems.Cast<object>().ToArray();                       
                    }
                }               
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return docType;
        }

        //Dissertation is Research Article
        private static dissertationType GetDissertationTypeFromRowData(DataRow rowData)
        {
            dissertationType disserType = null;
            try
            {
                if (rowData != null)
                {
                    disserType = new dissertationType();
                    disserType.tan = rowData["TAN_NAME"].ToString();
                    disserType.can = rowData["CAN"].ToString();
                    disserType.doi = rowData["DOI"].ToString();
                    disserType.id = "doc1";// rowData["journalarticleid"].ToString();
                    disserType.lang = languageType.en;
                    disserType.langSpecified = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return disserType;
        }

        private static patentType GetpatentTypeFromRowData(DataRow rowData)
        {
            patentType patType = null;
            try
            {
                if (rowData != null)
                {
                    patType = new patentType();
                    patType.tan = rowData["TAN_NAME"].ToString();
                    patType.can = rowData["CAN"].ToString();
                    //patType.doi = rowData["doi"].ToString();//DOI is not available for Patent
                    patType.id = "doc1";// rowData["journalarticleid"].ToString();
                    patType.lang = languageType.en;
                    patType.langSpecified = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return patType;
        }

        private static journalArticleType GetJournalTypeFromRowData(DataRow rowData)
        {
            journalArticleType journalType = null;
            try
            {
                if (rowData != null)
                {
                    journalType = new journalArticleType();
                    journalType.tan = rowData["TAN_NAME"].ToString();
                    journalType.can = rowData["CAN"].ToString();
                    journalType.doi = rowData["DOI"].ToString();
                    journalType.id = "doc1";// rowData["journalarticleid"].ToString();
                    journalType.lang = languageType.en;
                    journalType.langSpecified = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return journalType;
        }

        private static List<supplementalType> GetSupplementTypeListFromTANDocuments(DataTable tanDocuments)
        {
            List<supplementalType> lstSupplmntType = null;
            try
            {
                //Only Journals have Supporting documents
                if (tanDocuments != null)
                {
                    lstSupplmntType = new List<supplementalType>();
                    supplementalType objSupplType = null;
                    
                    //var rows = from r in tanDocuments.AsEnumerable()
                    //           where r.Field<string>("FILE_TYPE") == "SUPPORTING"
                    //           select r;
                    //if (rows != null)
                    //{                        
                    //    for(int i = 0; i < rows.Count();i++)
                    //    {
                    //        objSupplType = new supplementalType();
                    //        objSupplType.id = rows[i]["DOC_REF"];// "doc" + (i + 1);

                    //        lstSupplmntType.Add(objSupplType);
                    //    }
                    //}

                    foreach (DataRow dr in tanDocuments.Rows)
                    {
                        if (dr["FILE_TYPE"].ToString() == "SUPPORTING")
                        {
                            objSupplType = new supplementalType();
                            objSupplType.id = dr["FILE_TYPE1"].ToString().Replace(" ","");

                            lstSupplmntType.Add(objSupplType);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstSupplmntType;
        }

        #endregion

        #region ReactionTypes Methods

        private static reactionType[] GetReactionTypesFromTANReactions(DataTable tanReactions)
        {
            reactionType[] oaRxnType = null;
            try
            {
                if (tanReactions != null)
                {
                    if (tanReactions.Rows.Count > 0)
                    {
                        oaRxnType = new reactionType[tanReactions.Rows.Count];
                        reactionType objRxnType = null;

                        string strRxnNum = "";
                        string strRxnSeq = "";                        

                        int rxnNUM = 0;
                        int rxnSeq = 0;

                        for (int i = 0; i < tanReactions.Rows.Count; i++)
                        {
                            objRxnType = new reactionType();
                                                        
                            int.TryParse(tanReactions.Rows[i]["RXN_NUM"].ToString().Trim(), out rxnNUM);
                            int.TryParse(tanReactions.Rows[i]["RXN_SEQ"].ToString().Trim(), out rxnSeq);

                            strRxnNum = rxnNUM.ToString("D4");//001 format
                            strRxnSeq = rxnSeq.ToString("D4");
                                                        
                            objRxnType.num = strRxnNum;
                            objRxnType.seq = strRxnSeq;
                            objRxnType.docRef = tanReactions.Rows[i]["DOC_REF"].ToString().Trim(); 

                            objRxnType.location = GetLocationTypeFromRowData(tanReactions.Rows[i]);
                            objRxnType.docText = GetDocumentTextTypeFromRowData(tanReactions.Rows[i]);

                            oaRxnType[i] = objRxnType;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return oaRxnType;
        }

        #region Location Methods

        private static locationType GetLocationTypeFromRowData(DataRow rxnRowData)
        {
            locationType locType = null;
            try
            {
                if (rxnRowData != null)
                {                    
                    locType = new locationType();
                    locType.fileName = rxnRowData["FILE_NAME"].ToString().Trim();

                    pageType pgType = new pageType();
                    pgType.label = rxnRowData["PAGE_LABEL"].ToString().Trim();
                    pgType.number = rxnRowData["PAGE_NO"].ToString().Trim();
                       
                    //X postion
                    pageCoordinateType pgCoordTypeX = new pageCoordinateType();
                    if (!string.IsNullOrEmpty(rxnRowData["OFFSET_X"].ToString().Trim()))
                    {
                        pgCoordTypeX.offset = Convert.ToDecimal(rxnRowData["OFFSET_X"].ToString().Trim());
                    }
                    if (!string.IsNullOrEmpty(rxnRowData["PAGE_SIZE_X"].ToString().Trim()))
                    {
                        pgCoordTypeX.pageSize = Convert.ToDecimal(rxnRowData["PAGE_SIZE_X"].ToString().Trim());
                    }

                    pgCoordTypeX.Item =  GetLengthType("INCH");
                   
                    //Y postion
                    pageCoordinateType pgCoordTypeY = new pageCoordinateType();
                    if (!string.IsNullOrEmpty(rxnRowData["OFFSET_Y"].ToString().Trim()))
                    {
                        pgCoordTypeY.offset = Convert.ToDecimal(rxnRowData["OFFSET_Y"].ToString().Trim());
                    }
                    if (!string.IsNullOrEmpty(rxnRowData["PAGE_SIZE_Y"].ToString().Trim()))
                    {
                        pgCoordTypeY.pageSize = Convert.ToDecimal(rxnRowData["PAGE_SIZE_Y"].ToString().Trim());
                    }
       
                    pgCoordTypeY.Item =GetLengthType("INCH");
                       
                    positionType posType = new positionType();
                    posType.xPos = pgCoordTypeX;
                    posType.yPos = pgCoordTypeY;

                    locType.page = pgType;                    
                    locType.position = posType;

                    #region Code commented by Sairam on 7th Aug 2014
                    //TextLine
                    //string strTxt = GetConvertedXmlString(rxnRowData["textline"].ToString().Replace("\r\n", "").Replace("\n", "").Trim());
                    //int startB = strTxt.IndexOf("<bold>");
                    //int endB = strTxt.IndexOf("</bold>");
                    //if (startB >= 0 && endB > 0)
                    //{
                    //    string result = strTxt.Substring((startB + "<bold>".Length), (endB - (startB + "<bold>".Length)) - 1);

                    //    inlineTextFormat txtFormatBold = new inlineTextFormat();
                    //    txtFormatBold.ItemsElementName = new ItemsChoiceType[] { ItemsChoiceType.bold };
                    //    txtFormatBold.Text = new string[] { result };

                    //    inlineTextFormat inlinetxtFormat = new inlineTextFormat();
                    //    inlinetxtFormat.Items = new inlineTextFormat[] { txtFormatBold };
                    //    //locType.textLine = inlinetxtFormat;
                    //}
                    //else
                    //{
                    //    string[] saTextLine = new string[1];
                    //    saTextLine[0] = GetConvertedXmlString(rxnRowData["textline"].ToString().Replace("\r\n", "").Replace("\n", "").Trim());

                    //    inlineTextFormat inlinetxtFormat = new inlineTextFormat();
                    //    inlinetxtFormat.Text = saTextLine;                    
                    //    locType.textLine = inlinetxtFormat;               
                    //} 
                    #endregion

                    string[] saTextLine = new string[1];
                    //saTextLine[0] = System.Web.HttpUtility.HtmlDecode((rxnRowData["TEXT_LINE"].ToString().Replace("\r\n", "").Replace("\n", "").Trim()));
                    saTextLine[0] = rxnRowData["TEXT_LINE"].ToString().Replace("\r\n", "").Replace("\n", "").Trim();
                                   
                    inlineTextFormat inlinetxtFormat = new inlineTextFormat();
                    inlinetxtFormat.Text = saTextLine;                    
                    inlinetxtFormat.ItemsElementName = new ItemsChoiceType[] { ItemsChoiceType.bold, ItemsChoiceType.sub, ItemsChoiceType.sup, ItemsChoiceType.smallCap }; 
                    locType.textLine = inlinetxtFormat;    
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return locType;
        }

        private static lengthType GetLengthType(string lenthUnits)
        {
            lengthType lenType = null;
            try
            {
                if (!string.IsNullOrEmpty(lenthUnits))
                {
                    lenType = new lengthType();

                    switch (lenthUnits.ToUpper())
                    {
                        case "INCH":
                            lenType.lenUnits = lengthUnitType.inch;
                            break;
                        case "CENTIMETER":
                            lenType.lenUnits = lengthUnitType.centimeter;
                            break;
                        case "MILLIMETER":
                            lenType.lenUnits = lengthUnitType.millimeter;
                            break;
                        case "POINT":
                            lenType.lenUnits = lengthUnitType.point;
                            break;
                    }                                  
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lenType;
        }

        #endregion

        #region DocText Methods

        private static docTextType GetDocumentTextTypeFromRowData(DataRow rxnRowData)
        {
            docTextType docTextType = null;
            try
            {
                if (rxnRowData != null)
                {
                    docTextType = new docTextType();
                    docTextType.narrative = GetNarrativeTypeFromRowData(rxnRowData);
                    docTextType.data = GetDataParaTypeFromReactionData(rxnRowData);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return docTextType;
        }

        private static narrativeType GetNarrativeTypeFromRowData(DataRow rxnRowData)
        {
            narrativeType narrType = null;
            try
            {
                if (rxnRowData != null)
                {
                    string narID = rxnRowData["RXN_NAR_ID"].ToString();

                    narrType = new narrativeType();                    
                    narrType.id = narID;

                    if (rxnRowData["IS_ANALOGOUS"].ToString() == "Y")//!narID.ToUpper().Contains("ANALOGOUSTO=")
                    {
                        int analogRxnID = 0;
                        int.TryParse(rxnRowData["ANALOGOUS_RXN_ID"].ToString(), out analogRxnID);                     

                        if (analogRxnID > 0)
                        {
                            narrType.analogousTo = GetAnalogousRxnNarIDOnRxnID(analogRxnID);
                        }
                    }
                    #region MyRegion
                    //else//Analogous 
                    //{
                    //    //"nar8 analogousTo=nar7"
                    //    string[] saNarrVals = narID.Trim().Split(new string[] { "analogousTo=" }, StringSplitOptions.RemoveEmptyEntries);
                    //    if (saNarrVals != null)
                    //    {
                    //        if (saNarrVals.Length == 2)
                    //        {
                    //            narrType.id = saNarrVals[0].Trim();
                    //            narrType.analogousTo = saNarrVals[1].Trim();
                    //        }
                    //    }                        
                    //} 
                    #endregion

                    narrType.isGeneralTypical = rxnRowData["IS_GENERAL_TYPICAL"].ToString() == "Y" ? true : false;
                    narrType.para = GetParaDataFromReactionData(rxnRowData);
                   
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return narrType;
        }

        private static string GetAnalogousRxnNarIDOnRxnID(int anlogRxnID)
        {
            string analogRxnNarID = "";
            try
            {
                if (anlogRxnID > 0)
                {
                    var rows = from r in TAN_Reactions.AsEnumerable()
                               where r.Field<Int64>("RXN_ID") == anlogRxnID
                               select new
                               {
                                   AnalogNarID = r.Field<string>("RXN_NAR_ID")
                               };
                    if (rows != null)
                    {
                        foreach (var r in rows)
                        {
                            analogRxnNarID = r.AnalogNarID;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return analogRxnNarID;
        }

        private static paraType[] GetParaDataFromReactionData(DataRow rxnRowData)
        {
            paraType[] oaParaType = null;
            try
            {
                if (rxnRowData != null)
                {
                    List<paraType> lstPara = lstPara = new List<paraType>();
                    paraType objPara = null;

                    //No Exp Details - Para 1 Should be empty if No Exp Details
                    if (rxnRowData["NO_EXP_DETAILS"].ToString() == "Y")
                    {
                        objPara = new paraType();
                        objPara.Text = new string[] {"~~"};//Add blank para
                        lstPara.Add(objPara);
                    }

                    //Analogous Reaction - Para 1 should be empty and Para 2 should not be empty
                    if (rxnRowData["IS_ANALOGOUS"].ToString() == "Y")
                    {
                        objPara = new paraType();
                        objPara.Text = new string[] { "~~" };
                        lstPara.Add(objPara);
                    }

                    string strPara = rxnRowData["PARA_TEXT"].ToString().Trim();

                    if (!string.IsNullOrEmpty(strPara))
                    {
                        string[] saParaVals = strPara.Split(new string[1] { paraSplitter }, StringSplitOptions.RemoveEmptyEntries);//"&lt;PARA&gt;"
                        if (saParaVals != null)
                        {
                            foreach (string para in saParaVals)
                            {
                                if (!string.IsNullOrEmpty(para))
                                {
                                    //string convHtml = System.Web.HttpUtility.HtmlDecode(GetConvertedXmlString(para.Trim()));
                                    string convHtml = GetConvertedXmlString(para.Trim());
                                   
                                    
                                    objPara = new paraType();
                                    objPara.Text = new string[] { convHtml };
                                    objPara.ItemsElementName = new ItemsChoiceType1[] { ItemsChoiceType1.ital, ItemsChoiceType1.bold, ItemsChoiceType1.sub, ItemsChoiceType1.sup, ItemsChoiceType1.smallCap };
                                    
                                    //dataPara.Text = new string[] { System.Web.HttpUtility.HtmlDecode(GetConvertedXmlString(para.Trim())) };
                                    //dataPara.ItemsElementName = new ItemsChoiceType1[] { ItemsChoiceType1.ital, ItemsChoiceType1.bold, ItemsChoiceType1.sub, ItemsChoiceType1.sup, ItemsChoiceType1.smallCap };

                                    //Data InlineText format
                                    //string[] saData = new string[1];
                                    //saData[0] = System.Web.HttpUtility.HtmlDecode(GetConvertedXmlString(para.Trim()));

                                    //inlineTextFormat iltItal = new inlineTextFormat();
                                    //iltItal.Text = new string[] { convHtml };
                                    //iltItal.ItemsElementName = new ItemsChoiceType[] { ItemsChoiceType.ital, ItemsChoiceType.bold, ItemsChoiceType.sub, ItemsChoiceType.sup };
                                    
                                    //inlineTextFormat iltBold = new inlineTextFormat();
                                    //iltBold.Items = new inlineTextFormat[] { iltItal };
                                    //iltBold.ItemsElementName = new ItemsChoiceType[] { ItemsChoiceType.bold, };

                                    //inlineTextFormat iltSub = new inlineTextFormat();
                                    //iltSub.Items = new inlineTextFormat[] { iltBold };
                                    //iltSub.ItemsElementName = new ItemsChoiceType[] { ItemsChoiceType.sub };

                                    //inlineTextFormat iltSup = new inlineTextFormat();
                                    //iltSup.Items = new inlineTextFormat[] { iltSub };
                                    //iltSup.ItemsElementName = new ItemsChoiceType[] { ItemsChoiceType.sup };

                                    //objPara.Items = new inlineTextFormat[] { iltSup };
                                    
                                    lstPara.Add(objPara);
                                }
                            }
                        }
                    }
                    else 
                    {
                        //In No Exp Details, if no Para is available, then PARA 2 also empty 
                        if (rxnRowData["NO_EXP_DETAILS"].ToString() == "Y")
                        {
                            objPara = new paraType();
                            objPara.Text = new string[] { "~~" };//Add blank para
                            lstPara.Add(objPara);
                        }
                    }

                    if (lstPara != null)
                    {
                        oaParaType = lstPara.ToArray();
                    }

                    ////Write para1
                    //intArrIndx++;
                    //paraType para1Type = new paraType();
                    //para1Type.Text = new string[] { GetConvertedXmlString(rxnRowData["para1"].ToString().Trim()) };
                    //para1Type.ItemsElementName = new ItemsChoiceType1[] { ItemsChoiceType1.ital, ItemsChoiceType1.bold, ItemsChoiceType1.sub, ItemsChoiceType1.sup, ItemsChoiceType1.smallCap }; 
                    //oaParaType[intArrIndx] = para1Type;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return oaParaType;
        }

        private static paraType[] GetDataParaTypeFromReactionData(DataRow rxnRowData)
        {
            paraType[] oaDataPara = null;
            try
            {
                if (rxnRowData != null)
                {
                    List<paraType> lstData = null;
                    lstData = new List<paraType>();

                    string strPara = rxnRowData["DATA_TEXT"].ToString().Trim();
                    if (!string.IsNullOrEmpty(strPara))
                    {
                        string[] saParaVals = strPara.Split(new string[1] { dataSplitter }, StringSplitOptions.RemoveEmptyEntries);
                        if (saParaVals != null)
                        {
                            paraType dataPara = null;
                            foreach (string para in saParaVals)
                            {
                                string[] saData = new string[1];
                                saData[0] = GetConvertedXmlString(para.Trim());

                                dataPara = new paraType();
                                dataPara.Text = saData;//new string[] { System.Web.HttpUtility.HtmlDecode(GetConvertedXmlString(para.Trim())) };
                                //dataPara.ItemsElementName = new ItemsChoiceType1[] { ItemsChoiceType1.ital, ItemsChoiceType1.bold, ItemsChoiceType1.sub, ItemsChoiceType1.sup, ItemsChoiceType1.smallCap };

                                //Data InlineText format                              

                                inlineTextFormat inlinetxtFormat = new inlineTextFormat();
                                inlinetxtFormat.Text = saData;
                                inlinetxtFormat.ItemsElementName = new ItemsChoiceType[] { ItemsChoiceType.ital, ItemsChoiceType.bold, ItemsChoiceType.sub, ItemsChoiceType.sup, ItemsChoiceType.smallCap };

                                lstData.Add(dataPara);
                            }
                        }                       
                    }
                    else
                    {
                        paraType dataPara = new paraType();
                        dataPara.Text = new string[] { "~~" };//Add blank para
                        lstData.Add(dataPara);
                    }

                    //Convert list To Array
                    if (lstData != null)
                    {
                        oaDataPara = lstData.ToArray();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return oaDataPara;
        }

        #endregion        

        #endregion
    }
}
