﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace IndxReactNarr.Export.Narratives
{
    public class XmlRawTextWriter : System.Xml.XmlTextWriter
    {
        public XmlRawTextWriter(Stream w, Encoding encoding)
            : base(w, encoding)
        {
        }

        public XmlRawTextWriter(String filename, Encoding encoding)
            : base(filename, encoding)
        {
        }

        public override void WriteString(string text)
        {
            base.WriteRaw(text);
        }
    }
}
