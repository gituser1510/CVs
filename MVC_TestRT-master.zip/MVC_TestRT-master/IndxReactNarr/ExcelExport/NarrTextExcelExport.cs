﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using IndxReactNarr.Generic;

namespace IndxReactNarr
{
    public static class NarrTextExcelExport
    {
        public static bool ExportNarrDataToExcelFile(string tan, string can, DataTable narRxnsData, DataTable tanDocuments, string fileName)
        {
            bool blStatus = false;
            try
            {
                StringBuilder swexcel = new StringBuilder();
                StreamWriter sw = new StreamWriter(fileName);
                if (narRxnsData != null)
                {
                    string rxnNUM = "";
                    string rxnSeq = "";
                    string docRef = "";
                    string docFileName = "";
                    string pageNo = "";
                    string pageLabel = "";
                    string xPageSize = "";
                    string xOffset = "";
                    string yPageSize = "";
                    string yOffset = "";
                    string textLine = "";
                    string strnarid = "";
                    string strpara1 = "";
                    string strpara2 = "";
                    string dataValue = "";
                    string genTypical = "";
                    string noExpDetails = "";

                    string fldSep = "\t";
                    int tanDocID = 0;

                    swexcel.Append("CAN\tTAN\tRXNNO\tRXNSEQ\tDOCREF\tFilename\tPagenumber\tPageLabel\tXPagesize\tYPageSize\tXOffset\tYOffset\tTextLine\tNarID\tPara1\tPara2\tData\tIsGeneralTypical\tNoExperimentalDetails");
                    sw.WriteLine(swexcel);
                    foreach (DataRow drow in narRxnsData.Rows)
                    {
                        strpara1 = "";
                        strpara2 = "";
                        docRef = "";
                        docFileName = "";
                        strnarid = "";

                        int.TryParse(drow["TAN_DOC_ID"].ToString(), out tanDocID);
                        if (tanDocID > 0)
                        {
                            var rxnDocs = from row in tanDocuments.AsEnumerable()
                                          where row.Field<Int64?>("TAN_DOC_ID") == Convert.ToInt32(drow["TAN_DOC_ID"])
                                          select row;
                            if (rxnDocs != null)
                            {
                                foreach (var r in rxnDocs)
                                {
                                    docRef = r["FILE_TYPE1"].ToString();
                                    docFileName = r["FILE_NAME"].ToString();
                                }
                            }
                        }
                        
                        rxnNUM = Convert.ToInt32(drow["RXN_NUM"]).ToString("0000");
                        rxnSeq = Convert.ToInt32(drow["RXN_SEQ"]).ToString("0000");
                       
                        pageNo = drow["PAGE_NO"].ToString();
                        pageLabel = drow["PAGE_LABEL"].ToString();

                        xPageSize = drow["PAGE_SIZE_X"].ToString();
                        xOffset = drow["OFFSET_X"].ToString();

                        yPageSize = drow["PAGE_SIZE_Y"].ToString();
                        yOffset = drow["OFFSET_Y"].ToString();

                        textLine = drow["TEXT_LINE"].ToString().Replace("\r\n", "").TrimEnd();
                        
                        strnarid = drow["RXN_NAR_ID"].ToString();

                        if (drow["IS_ANALOGOUS"].ToString() == "Y")
                        {
                            if (!System.DBNull.Value.Equals(drow["ANALOGOUS_RXN_ID"]))
                            {
                                int analogRxnID = 0;
                                int.TryParse(drow["ANALOGOUS_RXN_ID"].ToString(), out analogRxnID);
                                if (analogRxnID > 0)
                                {
                                    var a = ((from row in narRxnsData.AsEnumerable().Where(r => r.Field<Int64>("RXN_ID") == analogRxnID)
                                              select row.Field<string>("RXN_NAR_ID")).First());
                                    strnarid += " analogousTo=" + a;
                                }
                            }
                        }
                                                

                        string[] saParas = drow["PARA_TEXT"].ToString().Split(new string[] { "``PARA``" }, StringSplitOptions.RemoveEmptyEntries);
                        if (saParas != null)
                        {
                            if (saParas.Length == 1)
                            {
                                strpara1 = saParas[0].Trim().Replace("\r\n", "").TrimEnd();
                            }
                            else
                            {

                                //First paras should be in Para1
                                for (int i = 0; i < saParas.Length - 1; i++)
                                {
                                    if (saParas.Length > 0)
                                    {
                                        strpara1 = string.IsNullOrEmpty(strpara1.Trim()) ? saParas[i].Trim().Replace("\r\n", "").Trim() : strpara1.Trim() + "<PARA>" + saParas[i].Trim().Replace("\r\n", "").Trim();
                                    }
                                }

                                //Last para should be in Para2
                                if (saParas.Length > 1)
                                {
                                    strpara2 = saParas[saParas.Length - 1].Trim().Replace("\r\n", "").TrimEnd();
                                }
                            }
                        }
                      
                        dataValue = drow["DATA_TEXT"].ToString();
                        genTypical = drow["IS_GENERAL_TYPICAL"].ToString();
                        noExpDetails = drow["NO_EXP_DETAILS"].ToString();

                        sw.WriteLine(can + fldSep + tan + fldSep + rxnNUM + fldSep + rxnSeq + fldSep + docRef + fldSep + docFileName + fldSep + pageNo + fldSep + pageLabel + fldSep + xPageSize + fldSep + yPageSize + fldSep + xOffset + fldSep + yOffset + fldSep + textLine + fldSep + strnarid + fldSep + strpara1 + fldSep + strpara2 + fldSep + dataValue + fldSep + genTypical + fldSep + noExpDetails);

                    }

                    sw.Flush();
                    sw.Close();

                    blStatus = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        public static bool ExportNarrDataToTextFile(string tan, string can, DataTable narRxnsData, DataTable tanDocuments, string fileName)
        {
            bool blStatus = false;
            try
            {
                StringBuilder swexcel = new StringBuilder();
                StreamWriter sw = new StreamWriter(fileName);
                if (narRxnsData != null)
                {
                    string rxnNUM = "";
                    string rxnSeq = "";
                    string docRef = "";
                    string docFileName = "";
                    string pageNo = "";
                    string pageLabel = "";
                    string xPageSize = "";
                    string xOffset = "";
                    string yPageSize = "";
                    string yOffset = "";
                    string textLine = "";
                    string strnarid = "";
                    string strpara1 = "";
                    string strpara2 = "";
                    string dataValue = "";
                    string genTypical = "";
                    string noExpDetails = "";

                    string fldSep = "    ";
                    int tanDocID = 0;

                    sw.WriteLine("CAN :" + can);
                    sw.WriteLine("TAN :" + tan);

                    foreach (DataRow drow in narRxnsData.Rows)
                    {
                        strpara1 = "";
                        strpara2 = "";
                        docRef = "";
                        docFileName = "";
                        strnarid = "";

                        int.TryParse(drow["TAN_DOC_ID"].ToString(), out tanDocID);
                        if (tanDocID > 0)
                        {
                            var rxnDocs = from row in tanDocuments.AsEnumerable()
                                          where row.Field<Int64?>("TAN_DOC_ID") == Convert.ToInt32(drow["TAN_DOC_ID"])
                                          select row;
                            if (rxnDocs != null)
                            {
                                foreach (var r in rxnDocs)
                                {
                                    docRef = r["FILE_TYPE1"].ToString();
                                    docFileName = r["FILE_NAME"].ToString();
                                }
                            }
                        }
                        else
                        {
                            docRef = "";
                            docFileName = "";
                        }

                        rxnNUM = Convert.ToInt32(drow["RXN_NUM"]).ToString("0000");
                        rxnSeq = Convert.ToInt32(drow["RXN_SEQ"]).ToString("0000");

                        pageNo = drow["PAGE_NO"].ToString();
                        pageLabel = drow["PAGE_LABEL"].ToString();

                        xPageSize = drow["PAGE_SIZE_X"].ToString();
                        xOffset = drow["OFFSET_X"].ToString();

                        yPageSize = drow["PAGE_SIZE_Y"].ToString();
                        yOffset = drow["OFFSET_Y"].ToString();

                        textLine = drow["TEXT_LINE"].ToString().Replace("\r\n", "").TrimEnd();
                        strnarid = drow["RXN_NAR_ID"].ToString().Replace(" ", "").Trim();

                        if (drow["IS_ANALOGOUS"].ToString() == "Y")
                        {
                            if (!System.DBNull.Value.Equals(drow["ANALOGOUS_RXN_ID"]))
                            {
                                int analogRxnID = 0;
                                int.TryParse(drow["ANALOGOUS_RXN_ID"].ToString(), out analogRxnID);
                                if (analogRxnID > 0)
                                {
                                    var a = ((from row in narRxnsData.AsEnumerable().Where(r => r.Field<Int64>("RXN_ID") == analogRxnID)
                                              select row.Field<string>("RXN_NAR_ID")).First());
                                    strnarid += " analogousTo=" + a.Replace(" ", "").Trim();
                                }
                            }
                        }
                        
                        string[] saParas = drow["PARA_TEXT"].ToString().Split(new string[] { "``PARA``" }, StringSplitOptions.RemoveEmptyEntries);
                        if (saParas != null)
                        {
                            //First paras should be in Para1
                            for (int i = 0; i < saParas.Length - 1; i++)
                            {
                                if (saParas.Length > 0)
                                {
                                    strpara1 = string.IsNullOrEmpty(strpara1.Trim()) ? saParas[i].Trim().Replace("\r\n", "").Trim() : strpara1.Trim() + "<PARA>" + saParas[i].Trim().Replace("\r\n", "").Trim();
                                }
                            }

                            //Last para should be in Para2
                            if (saParas.Length > 1)
                            {
                                strpara2 = saParas[saParas.Length - 1].Trim().Replace("\r\n", "").TrimEnd();
                            }
                        }

                        dataValue = drow["DATA_TEXT"].ToString();
                        genTypical = drow["IS_GENERAL_TYPICAL"].ToString();
                        noExpDetails = drow["NO_EXP_DETAILS"].ToString();

                        sw.WriteLine(rxnNUM + fldSep + docRef + fldSep + docFileName + fldSep + pageNo + fldSep + pageLabel + fldSep + xPageSize + fldSep + xOffset + fldSep + yPageSize + fldSep + yOffset + fldSep + noExpDetails);

                        sw.WriteLine("Textline : " + textLine);
                        sw.WriteLine("Nar ID : " + strnarid);
                        sw.WriteLine("Para1 : " + strpara1);
                        if (!string.IsNullOrEmpty(strpara2))
                        {
                            sw.WriteLine("Para2: " + strpara2);
                        }
                        sw.WriteLine("Data : " + dataValue);                      

                    }

                    sw.Flush();
                    sw.Close();

                    blStatus = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        public static bool ExportExperimentalProcedureDataToExcelFile(string tan, string can, DataTable narRxnsData, DataTable tanDocuments, string fileName)
        {
            bool blStatus = false;
            try
            {
                StringBuilder swexcel = new StringBuilder();
                StreamWriter sw = new StreamWriter(fileName);
                if (narRxnsData != null)
                {
                    string rxnNUM = "";
                    string rxnSeq = "";
                    string docRef = "";
                    string docFileName = "";
                    string pageNo = "";
                    string pageLabel = "";
                    string xPageSize = "";
                    string xOffset = "";
                    string yPageSize = "";
                    string yOffset = "";
                    string textLine = "";
                    string yieldText = "";
                    string strnarid = "";
                    string strpara1 = "";
                    string strpara2 = "";
                    string dataValue = "";
                    string procedureText = "";
                    string genTypical = "";
                    string noExpDetails = "";

                    string fldSep = "\t";
                    int tanDocID = 0;

                    swexcel.Append("CAN\tTAN\tRXNNO\tRXNSEQ\tDOCREF\tFilename\tPagenumber\tPageLabel\tXPagesize\tYPageSize\tXOffset\tYOffset\tTextLine\tYeildText\tNarID\tPara1\tPara2\tData\tProcedureText\tIsGeneralTypical\tNoExperimentalDetails");
                    sw.WriteLine(swexcel);
                    foreach (DataRow drow in narRxnsData.Rows)
                    {
                        strpara1 = "";
                        strpara2 = "";
                        docRef = "";
                        docFileName = "";
                        strnarid = "";

                        int.TryParse(drow["TAN_DOC_ID"].ToString(), out tanDocID);
                        if (tanDocID > 0)
                        {
                            var rxnDocs = from row in tanDocuments.AsEnumerable()
                                          where row.Field<Int64?>("TAN_DOC_ID") == Convert.ToInt32(drow["TAN_DOC_ID"])
                                          select row;
                            if (rxnDocs != null)
                            {
                                foreach (var r in rxnDocs)
                                {
                                    docRef = r["FILE_TYPE1"].ToString();
                                    docFileName = r["FILE_NAME"].ToString();
                                }
                            }
                        }

                        rxnNUM = Convert.ToInt32(drow["RXN_NUM"]).ToString("0000");
                        rxnSeq = Convert.ToInt32(drow["RXN_SEQ"]).ToString("0000");

                        pageNo = drow["PAGE_NO"].ToString();
                        pageLabel = drow["PAGE_LABEL"].ToString();

                        xPageSize = drow["PAGE_SIZE_X"].ToString();
                        xOffset = drow["OFFSET_X"].ToString();

                        yPageSize = drow["PAGE_SIZE_Y"].ToString();
                        yOffset = drow["OFFSET_Y"].ToString();

                        textLine = drow["TEXT_LINE"].ToString().Replace("\r\n", "").TrimEnd();
                        yieldText = drow["YIELD_TEXT"].ToString().Replace("\r\n", "").TrimEnd();
                        procedureText = drow["PROCEDURE_TEXT"].ToString();

                        strnarid = drow["RXN_NAR_ID"].ToString();

                        if (drow["IS_ANALOGOUS"].ToString() == "Y")
                        {
                            if (!System.DBNull.Value.Equals(drow["ANALOGOUS_RXN_ID"]))
                            {
                                int analogRxnID = 0;
                                int.TryParse(drow["ANALOGOUS_RXN_ID"].ToString(), out analogRxnID);
                                if (analogRxnID > 0)
                                {
                                    var a = ((from row in narRxnsData.AsEnumerable().Where(r => r.Field<Int64>("RXN_ID") == analogRxnID)
                                              select row.Field<string>("RXN_NAR_ID")).First());
                                    strnarid += " analogousTo=" + a;
                                }
                            }
                        }


                        string[] saParas = drow["PARA_TEXT"].ToString().Split(new string[] { "``PARA``" }, StringSplitOptions.RemoveEmptyEntries);
                        if (saParas != null)
                        {
                            if (saParas.Length == 1)
                            {
                                strpara1 = saParas[0].Trim().Replace("\r\n", "").TrimEnd();
                            }
                            else
                            {

                                //First paras should be in Para1
                                for (int i = 0; i < saParas.Length - 1; i++)
                                {
                                    if (saParas.Length > 0)
                                    {
                                        strpara1 = string.IsNullOrEmpty(strpara1.Trim()) ? saParas[i].Trim().Replace("\r\n", "").Trim() : strpara1.Trim() + "<PARA>" + saParas[i].Trim().Replace("\r\n", "").Trim();
                                    }
                                }

                                //Last para should be in Para2
                                if (saParas.Length > 1)
                                {
                                    strpara2 = saParas[saParas.Length - 1].Trim().Replace("\r\n", "").TrimEnd();
                                }
                            }
                        }

                        dataValue = drow["DATA_TEXT"].ToString();
                        genTypical = drow["IS_GENERAL_TYPICAL"].ToString();
                        noExpDetails = drow["NO_EXP_DETAILS"].ToString();

                        sw.WriteLine(can + fldSep + tan + fldSep + rxnNUM + fldSep + rxnSeq + fldSep + docRef + fldSep + docFileName + fldSep + pageNo + fldSep + pageLabel + fldSep + xPageSize + fldSep + yPageSize + fldSep + xOffset + fldSep + yOffset + fldSep + textLine + fldSep + yieldText + fldSep + strnarid + fldSep + strpara1 + fldSep + strpara2 + fldSep + dataValue + fldSep + procedureText + fldSep + genTypical + fldSep + noExpDetails);

                    }

                    sw.Flush();
                    sw.Close();

                    blStatus = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        public static bool ExportExperimentalProcedureDataToTextFile(string tan, string can, DataTable narRxnsData, DataTable tanDocuments, string fileName)
        {
            bool blStatus = false;
            try
            {
                StringBuilder swexcel = new StringBuilder();
                StreamWriter sw = new StreamWriter(fileName);
                if (narRxnsData != null)
                {
                    string rxnNUM = "";
                    string rxnSeq = "";
                    string docRef = "";
                    string docFileName = "";
                    string pageNo = "";
                    string pageLabel = "";
                    string xPageSize = "";
                    string xOffset = "";
                    string yPageSize = "";
                    string yOffset = "";
                    string textLine = "";
                    string yieldText = "";
                    string strnarid = "";
                    string strpara1 = "";
                    string strpara2 = "";
                    string dataValue = "";
                    string procedureText = "";
                    string genTypical = "";
                    string noExpDetails = "";

                    string fldSep = "    ";
                    int tanDocID = 0;

                    sw.WriteLine("CAN :" + can);
                    sw.WriteLine("TAN :" + tan);

                    foreach (DataRow drow in narRxnsData.Rows)
                    {
                        strpara1 = "";
                        strpara2 = "";
                        docRef = "";
                        docFileName = "";
                        strnarid = "";

                        int.TryParse(drow["TAN_DOC_ID"].ToString(), out tanDocID);
                        if (tanDocID > 0)
                        {
                            var rxnDocs = from row in tanDocuments.AsEnumerable()
                                          where row.Field<Int64?>("TAN_DOC_ID") == Convert.ToInt32(drow["TAN_DOC_ID"])
                                          select row;
                            if (rxnDocs != null)
                            {
                                foreach (var r in rxnDocs)
                                {
                                    docRef = r["FILE_TYPE1"].ToString();
                                    docFileName = r["FILE_NAME"].ToString();
                                }
                            }
                        }
                        else
                        {
                            docRef = "";
                            docFileName = "";
                        }

                        rxnNUM = Convert.ToInt32(drow["RXN_NUM"]).ToString("0000");
                        rxnSeq = Convert.ToInt32(drow["RXN_SEQ"]).ToString("0000");

                        pageNo = drow["PAGE_NO"].ToString();
                        pageLabel = drow["PAGE_LABEL"].ToString();

                        xPageSize = drow["PAGE_SIZE_X"].ToString();
                        xOffset = drow["OFFSET_X"].ToString();

                        yPageSize = drow["PAGE_SIZE_Y"].ToString();
                        yOffset = drow["OFFSET_Y"].ToString();

                        textLine = drow["TEXT_LINE"].ToString().Replace("\r\n", "").TrimEnd();
                        yieldText = drow["YIELD_TEXT"].ToString().Replace("\r\n", "").TrimEnd();
                        procedureText = drow["PROCEDURE_TEXT"].ToString().Replace("\r\n", "").TrimEnd();

                        strnarid = drow["RXN_NAR_ID"].ToString().Replace(" ", "").Trim();

                        if (drow["IS_ANALOGOUS"].ToString() == "Y")
                        {
                            if (!System.DBNull.Value.Equals(drow["ANALOGOUS_RXN_ID"]))
                            {
                                int analogRxnID = 0;
                                int.TryParse(drow["ANALOGOUS_RXN_ID"].ToString(), out analogRxnID);
                                if (analogRxnID > 0)
                                {
                                    var a = ((from row in narRxnsData.AsEnumerable().Where(r => r.Field<Int64>("RXN_ID") == analogRxnID)
                                              select row.Field<string>("RXN_NAR_ID")).First());
                                    strnarid += " analogousTo=" + a.Replace(" ", "").Trim();
                                }
                            }
                        }

                        string[] saParas = drow["PARA_TEXT"].ToString().Split(new string[] { "``PARA``" }, StringSplitOptions.RemoveEmptyEntries);
                        if (saParas != null)
                        {
                            //First paras should be in Para1
                            for (int i = 0; i < saParas.Length - 1; i++)
                            {
                                if (saParas.Length > 0)
                                {
                                    strpara1 = string.IsNullOrEmpty(strpara1.Trim()) ? saParas[i].Trim().Replace("\r\n", "").Trim() : strpara1.Trim() + "<PARA>" + saParas[i].Trim().Replace("\r\n", "").Trim();
                                }
                            }

                            //Last para should be in Para2
                            if (saParas.Length > 1)
                            {
                                strpara2 = saParas[saParas.Length - 1].Trim().Replace("\r\n", "").TrimEnd();
                            }
                        }

                        dataValue = drow["DATA_TEXT"].ToString();
                        genTypical = drow["IS_GENERAL_TYPICAL"].ToString();
                        noExpDetails = drow["NO_EXP_DETAILS"].ToString();

                        sw.WriteLine(rxnNUM + fldSep + docRef + fldSep + docFileName + fldSep + pageNo + fldSep + pageLabel + fldSep + xPageSize + fldSep + xOffset + fldSep + yPageSize + fldSep + yOffset + fldSep + noExpDetails);

                        sw.WriteLine("Textline : " + textLine);
                        sw.WriteLine("YieldText : " + yieldText);
                        sw.WriteLine("Nar ID : " + strnarid);
                        sw.WriteLine("Para1 : " + strpara1);
                        if (!string.IsNullOrEmpty(strpara2))
                        {
                            sw.WriteLine("Para2: " + strpara2);
                        }
                        sw.WriteLine("Data : " + dataValue);
                        sw.WriteLine("Procedure Text : " + procedureText);
                    }

                    sw.Flush();
                    sw.Close();

                    blStatus = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }
    }
}

