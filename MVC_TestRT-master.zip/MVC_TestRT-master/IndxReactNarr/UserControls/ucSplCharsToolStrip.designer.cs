﻿namespace IndxReactNarr
{
    partial class ucSplCharsToolStrip
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucSplCharsToolStrip));
            this.tsSpecialChars = new System.Windows.Forms.ToolStrip();
            this.tsbAlpha = new System.Windows.Forms.ToolStripButton();
            this.tsbBeta = new System.Windows.Forms.ToolStripButton();
            this.tsbGamma = new System.Windows.Forms.ToolStripButton();
            this.tsbDelta = new System.Windows.Forms.ToolStripButton();
            this.tsbEpsilon = new System.Windows.Forms.ToolStripButton();
            this.tsbZeta = new System.Windows.Forms.ToolStripButton();
            this.tsbEta = new System.Windows.Forms.ToolStripButton();
            this.tsbTheta = new System.Windows.Forms.ToolStripButton();
            this.tsbIota = new System.Windows.Forms.ToolStripButton();
            this.tsbKappa = new System.Windows.Forms.ToolStripButton();
            this.tsbLamda = new System.Windows.Forms.ToolStripButton();
            this.tsbMu = new System.Windows.Forms.ToolStripButton();
            this.tsbNu = new System.Windows.Forms.ToolStripButton();
            this.tsbXi = new System.Windows.Forms.ToolStripButton();
            this.tsbOmicron = new System.Windows.Forms.ToolStripButton();
            this.tsbPi = new System.Windows.Forms.ToolStripButton();
            this.tsbRho = new System.Windows.Forms.ToolStripButton();
            this.tsbSigma = new System.Windows.Forms.ToolStripButton();
            this.tsbTau = new System.Windows.Forms.ToolStripButton();
            this.tsbUpsolin = new System.Windows.Forms.ToolStripButton();
            this.tsupsilon = new System.Windows.Forms.ToolStripButton();
            this.tsbPhi = new System.Windows.Forms.ToolStripButton();
            this.tsbChi = new System.Windows.Forms.ToolStripButton();
            this.tsbPsi = new System.Windows.Forms.ToolStripButton();
            this.tsbOmega = new System.Windows.Forms.ToolStripButton();
            this.tsbDegree = new System.Windows.Forms.ToolStripButton();
            this.tsbPipe = new System.Windows.Forms.ToolStripButton();
            this.tsbApprox = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton99 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton100 = new System.Windows.Forms.ToolStripButton();
            this.tsbCopyright = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton102 = new System.Windows.Forms.ToolStripButton();
            this.tsbRegister = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton104 = new System.Windows.Forms.ToolStripButton();
            this.tsbPlusMinus = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton106 = new System.Windows.Forms.ToolStripButton();
            this.tsbFunction = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton108 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton109 = new System.Windows.Forms.ToolStripButton();
            this.tsbDot = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton111 = new System.Windows.Forms.ToolStripButton();
            this.tsbLessThanEqual = new System.Windows.Forms.ToolStripButton();
            this.tsbGreaterthanEqual = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton114 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton115 = new System.Windows.Forms.ToolStripButton();
            this.tsbSigma_Upper = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton117 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton118 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton119 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton120 = new System.Windows.Forms.ToolStripButton();
            this.ts1triplebond = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton14 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton15 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton16 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton19 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton17 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton18 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton20 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton21 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton22 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton23 = new System.Windows.Forms.ToolStripButton();
            this.tsFontStyles = new System.Windows.Forms.ToolStrip();
            this.tsbFindReplace = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbBold = new System.Windows.Forms.ToolStripButton();
            this.tsbUnderline = new System.Windows.Forms.ToolStripButton();
            this.tsbItalic = new System.Windows.Forms.ToolStripButton();
            this.tsbStrikeout = new System.Windows.Forms.ToolStripButton();
            this.tsbRegular = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbSuperscript = new System.Windows.Forms.ToolStripButton();
            this.tsbSubscript = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbSmallCaps = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbUndo = new System.Windows.Forms.ToolStripButton();
            this.tsbRedo = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbConvFormula = new System.Windows.Forms.ToolStripButton();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.tsSpecialChars.SuspendLayout();
            this.tsFontStyles.SuspendLayout();
            this.SuspendLayout();
            // 
            // tsSpecialChars
            // 
            this.tsSpecialChars.BackColor = System.Drawing.Color.White;
            this.tsSpecialChars.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsSpecialChars.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbAlpha,
            this.tsbBeta,
            this.tsbGamma,
            this.tsbDelta,
            this.tsbEpsilon,
            this.tsbZeta,
            this.tsbEta,
            this.tsbTheta,
            this.tsbIota,
            this.tsbKappa,
            this.tsbLamda,
            this.tsbMu,
            this.tsbNu,
            this.tsbXi,
            this.tsbOmicron,
            this.tsbPi,
            this.tsbRho,
            this.tsbSigma,
            this.tsbTau,
            this.tsbUpsolin,
            this.tsupsilon,
            this.tsbPhi,
            this.tsbChi,
            this.tsbPsi,
            this.tsbOmega,
            this.tsbDegree,
            this.tsbPipe,
            this.tsbApprox,
            this.toolStripButton99,
            this.toolStripButton100,
            this.tsbCopyright,
            this.toolStripButton102,
            this.tsbRegister,
            this.toolStripButton104,
            this.tsbPlusMinus,
            this.toolStripButton106,
            this.tsbFunction,
            this.toolStripButton108,
            this.toolStripButton109,
            this.tsbDot,
            this.toolStripButton111,
            this.tsbLessThanEqual,
            this.tsbGreaterthanEqual,
            this.toolStripButton114,
            this.toolStripButton115,
            this.tsbSigma_Upper,
            this.toolStripButton117,
            this.toolStripButton118,
            this.toolStripButton119,
            this.toolStripButton120,
            this.ts1triplebond,
            this.toolStripButton14,
            this.toolStripButton15,
            this.toolStripButton16,
            this.toolStripButton19,
            this.toolStripButton17,
            this.toolStripButton18,
            this.toolStripButton20,
            this.toolStripButton21,
            this.toolStripButton22,
            this.toolStripButton23});
            this.tsSpecialChars.Location = new System.Drawing.Point(0, 0);
            this.tsSpecialChars.Name = "tsSpecialChars";
            this.tsSpecialChars.Size = new System.Drawing.Size(1156, 25);
            this.tsSpecialChars.TabIndex = 45;
            this.tsSpecialChars.Tag = "XC";
            this.tsSpecialChars.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.tsSpecialChars_ItemClicked);
            // 
            // tsbAlpha
            // 
            this.tsbAlpha.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbAlpha.Image = ((System.Drawing.Image)(resources.GetObject("tsbAlpha.Image")));
            this.tsbAlpha.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAlpha.Name = "tsbAlpha";
            this.tsbAlpha.Size = new System.Drawing.Size(23, 22);
            this.tsbAlpha.Tag = "&#945;";
            this.tsbAlpha.Text = "α";
            // 
            // tsbBeta
            // 
            this.tsbBeta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbBeta.Image = ((System.Drawing.Image)(resources.GetObject("tsbBeta.Image")));
            this.tsbBeta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbBeta.Name = "tsbBeta";
            this.tsbBeta.Size = new System.Drawing.Size(23, 22);
            this.tsbBeta.Tag = "&beta;";
            this.tsbBeta.Text = "β";
            // 
            // tsbGamma
            // 
            this.tsbGamma.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbGamma.Image = ((System.Drawing.Image)(resources.GetObject("tsbGamma.Image")));
            this.tsbGamma.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbGamma.Name = "tsbGamma";
            this.tsbGamma.Size = new System.Drawing.Size(23, 22);
            this.tsbGamma.Tag = "&#947; ";
            this.tsbGamma.Text = "γ";
            // 
            // tsbDelta
            // 
            this.tsbDelta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbDelta.Image = ((System.Drawing.Image)(resources.GetObject("tsbDelta.Image")));
            this.tsbDelta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDelta.Name = "tsbDelta";
            this.tsbDelta.Size = new System.Drawing.Size(23, 22);
            this.tsbDelta.Tag = "&#948;";
            this.tsbDelta.Text = "δ";
            // 
            // tsbEpsilon
            // 
            this.tsbEpsilon.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbEpsilon.Image = ((System.Drawing.Image)(resources.GetObject("tsbEpsilon.Image")));
            this.tsbEpsilon.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbEpsilon.Name = "tsbEpsilon";
            this.tsbEpsilon.Size = new System.Drawing.Size(23, 22);
            this.tsbEpsilon.Tag = "&#949;";
            this.tsbEpsilon.Text = "ε";
            // 
            // tsbZeta
            // 
            this.tsbZeta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbZeta.Image = ((System.Drawing.Image)(resources.GetObject("tsbZeta.Image")));
            this.tsbZeta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbZeta.Name = "tsbZeta";
            this.tsbZeta.Size = new System.Drawing.Size(23, 22);
            this.tsbZeta.Tag = "&#950";
            this.tsbZeta.Text = "ζ";
            // 
            // tsbEta
            // 
            this.tsbEta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbEta.Image = ((System.Drawing.Image)(resources.GetObject("tsbEta.Image")));
            this.tsbEta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbEta.Name = "tsbEta";
            this.tsbEta.Size = new System.Drawing.Size(23, 22);
            this.tsbEta.Tag = "&#951;";
            this.tsbEta.Text = "η";
            // 
            // tsbTheta
            // 
            this.tsbTheta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbTheta.Image = ((System.Drawing.Image)(resources.GetObject("tsbTheta.Image")));
            this.tsbTheta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbTheta.Name = "tsbTheta";
            this.tsbTheta.Size = new System.Drawing.Size(23, 22);
            this.tsbTheta.Tag = "&#952;";
            this.tsbTheta.Text = "θ";
            // 
            // tsbIota
            // 
            this.tsbIota.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbIota.Image = ((System.Drawing.Image)(resources.GetObject("tsbIota.Image")));
            this.tsbIota.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbIota.Name = "tsbIota";
            this.tsbIota.Size = new System.Drawing.Size(23, 22);
            this.tsbIota.Tag = "&#953;";
            this.tsbIota.Text = "ι";
            // 
            // tsbKappa
            // 
            this.tsbKappa.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbKappa.Image = ((System.Drawing.Image)(resources.GetObject("tsbKappa.Image")));
            this.tsbKappa.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbKappa.Name = "tsbKappa";
            this.tsbKappa.Size = new System.Drawing.Size(23, 22);
            this.tsbKappa.Tag = "&#954;";
            this.tsbKappa.Text = "κ";
            // 
            // tsbLamda
            // 
            this.tsbLamda.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbLamda.Image = ((System.Drawing.Image)(resources.GetObject("tsbLamda.Image")));
            this.tsbLamda.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLamda.Name = "tsbLamda";
            this.tsbLamda.Size = new System.Drawing.Size(23, 22);
            this.tsbLamda.Tag = "&#955;";
            this.tsbLamda.Text = "λ";
            // 
            // tsbMu
            // 
            this.tsbMu.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbMu.Image = ((System.Drawing.Image)(resources.GetObject("tsbMu.Image")));
            this.tsbMu.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbMu.Name = "tsbMu";
            this.tsbMu.Size = new System.Drawing.Size(23, 22);
            this.tsbMu.Tag = "&#956;";
            this.tsbMu.Text = "μ";
            // 
            // tsbNu
            // 
            this.tsbNu.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbNu.Image = ((System.Drawing.Image)(resources.GetObject("tsbNu.Image")));
            this.tsbNu.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbNu.Name = "tsbNu";
            this.tsbNu.Size = new System.Drawing.Size(23, 22);
            this.tsbNu.Tag = "&#957;";
            this.tsbNu.Text = "ν";
            // 
            // tsbXi
            // 
            this.tsbXi.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbXi.Image = ((System.Drawing.Image)(resources.GetObject("tsbXi.Image")));
            this.tsbXi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbXi.Name = "tsbXi";
            this.tsbXi.Size = new System.Drawing.Size(23, 22);
            this.tsbXi.Tag = "&#958;";
            this.tsbXi.Text = "ξ";
            // 
            // tsbOmicron
            // 
            this.tsbOmicron.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbOmicron.Image = ((System.Drawing.Image)(resources.GetObject("tsbOmicron.Image")));
            this.tsbOmicron.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbOmicron.Name = "tsbOmicron";
            this.tsbOmicron.Size = new System.Drawing.Size(23, 22);
            this.tsbOmicron.Tag = "&#959;";
            this.tsbOmicron.Text = "ο";
            // 
            // tsbPi
            // 
            this.tsbPi.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPi.Image = ((System.Drawing.Image)(resources.GetObject("tsbPi.Image")));
            this.tsbPi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPi.Name = "tsbPi";
            this.tsbPi.Size = new System.Drawing.Size(23, 22);
            this.tsbPi.Tag = "&#960;";
            this.tsbPi.Text = "π";
            this.tsbPi.Visible = false;
            // 
            // tsbRho
            // 
            this.tsbRho.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbRho.Image = ((System.Drawing.Image)(resources.GetObject("tsbRho.Image")));
            this.tsbRho.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRho.Name = "tsbRho";
            this.tsbRho.Size = new System.Drawing.Size(23, 22);
            this.tsbRho.Tag = "&#961;";
            this.tsbRho.Text = "ρ";
            // 
            // tsbSigma
            // 
            this.tsbSigma.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbSigma.Image = ((System.Drawing.Image)(resources.GetObject("tsbSigma.Image")));
            this.tsbSigma.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSigma.Name = "tsbSigma";
            this.tsbSigma.Size = new System.Drawing.Size(23, 22);
            this.tsbSigma.Tag = "&#962;";
            this.tsbSigma.Text = "ς";
            // 
            // tsbTau
            // 
            this.tsbTau.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbTau.Image = ((System.Drawing.Image)(resources.GetObject("tsbTau.Image")));
            this.tsbTau.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbTau.Name = "tsbTau";
            this.tsbTau.Size = new System.Drawing.Size(23, 22);
            this.tsbTau.Tag = "&#963;";
            this.tsbTau.Text = "σ";
            // 
            // tsbUpsolin
            // 
            this.tsbUpsolin.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbUpsolin.Image = ((System.Drawing.Image)(resources.GetObject("tsbUpsolin.Image")));
            this.tsbUpsolin.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbUpsolin.Name = "tsbUpsolin";
            this.tsbUpsolin.Size = new System.Drawing.Size(23, 22);
            this.tsbUpsolin.Tag = "&#964;";
            this.tsbUpsolin.Text = "τ";
            // 
            // tsupsilon
            // 
            this.tsupsilon.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsupsilon.Image = ((System.Drawing.Image)(resources.GetObject("tsupsilon.Image")));
            this.tsupsilon.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsupsilon.Name = "tsupsilon";
            this.tsupsilon.Size = new System.Drawing.Size(23, 22);
            this.tsupsilon.Tag = "&#965;";
            this.tsupsilon.Text = "υ";
            // 
            // tsbPhi
            // 
            this.tsbPhi.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPhi.Image = ((System.Drawing.Image)(resources.GetObject("tsbPhi.Image")));
            this.tsbPhi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPhi.Name = "tsbPhi";
            this.tsbPhi.Size = new System.Drawing.Size(23, 22);
            this.tsbPhi.Tag = "&#966;";
            this.tsbPhi.Text = "φ";
            // 
            // tsbChi
            // 
            this.tsbChi.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbChi.Image = ((System.Drawing.Image)(resources.GetObject("tsbChi.Image")));
            this.tsbChi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbChi.Name = "tsbChi";
            this.tsbChi.Size = new System.Drawing.Size(23, 22);
            this.tsbChi.Tag = "&#967;";
            this.tsbChi.Text = "χ";
            // 
            // tsbPsi
            // 
            this.tsbPsi.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPsi.Image = ((System.Drawing.Image)(resources.GetObject("tsbPsi.Image")));
            this.tsbPsi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPsi.Name = "tsbPsi";
            this.tsbPsi.Size = new System.Drawing.Size(23, 22);
            this.tsbPsi.Tag = "&#936;";
            this.tsbPsi.Text = "ψ";
            // 
            // tsbOmega
            // 
            this.tsbOmega.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbOmega.Image = ((System.Drawing.Image)(resources.GetObject("tsbOmega.Image")));
            this.tsbOmega.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbOmega.Name = "tsbOmega";
            this.tsbOmega.Size = new System.Drawing.Size(23, 22);
            this.tsbOmega.Tag = "&#969;";
            this.tsbOmega.Text = "ω";
            // 
            // tsbDegree
            // 
            this.tsbDegree.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbDegree.Image = ((System.Drawing.Image)(resources.GetObject("tsbDegree.Image")));
            this.tsbDegree.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDegree.Name = "tsbDegree";
            this.tsbDegree.Size = new System.Drawing.Size(23, 22);
            this.tsbDegree.Tag = "&#176;";
            this.tsbDegree.Text = "°";
            this.tsbDegree.ToolTipText = "degree";
            // 
            // tsbPipe
            // 
            this.tsbPipe.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPipe.Image = ((System.Drawing.Image)(resources.GetObject("tsbPipe.Image")));
            this.tsbPipe.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPipe.Name = "tsbPipe";
            this.tsbPipe.Size = new System.Drawing.Size(23, 22);
            this.tsbPipe.Tag = "&#124;";
            this.tsbPipe.Text = "|";
            // 
            // tsbApprox
            // 
            this.tsbApprox.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbApprox.Image = ((System.Drawing.Image)(resources.GetObject("tsbApprox.Image")));
            this.tsbApprox.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbApprox.Name = "tsbApprox";
            this.tsbApprox.Size = new System.Drawing.Size(23, 22);
            this.tsbApprox.Tag = "&#126;";
            this.tsbApprox.Text = "~";
            // 
            // toolStripButton99
            // 
            this.toolStripButton99.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton99.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton99.Image")));
            this.toolStripButton99.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton99.Name = "toolStripButton99";
            this.toolStripButton99.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton99.Tag = "&#165;";
            this.toolStripButton99.Text = "¥";
            // 
            // toolStripButton100
            // 
            this.toolStripButton100.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton100.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton100.Image")));
            this.toolStripButton100.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton100.Name = "toolStripButton100";
            this.toolStripButton100.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton100.Tag = "&#167;";
            this.toolStripButton100.Text = "§";
            // 
            // tsbCopyright
            // 
            this.tsbCopyright.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbCopyright.Image = ((System.Drawing.Image)(resources.GetObject("tsbCopyright.Image")));
            this.tsbCopyright.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCopyright.Name = "tsbCopyright";
            this.tsbCopyright.Size = new System.Drawing.Size(24, 22);
            this.tsbCopyright.Tag = "&#169;";
            this.tsbCopyright.Text = "©";
            // 
            // toolStripButton102
            // 
            this.toolStripButton102.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton102.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton102.Image")));
            this.toolStripButton102.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton102.Name = "toolStripButton102";
            this.toolStripButton102.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton102.Tag = "&#171;";
            this.toolStripButton102.Text = "«";
            // 
            // tsbRegister
            // 
            this.tsbRegister.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbRegister.Image = ((System.Drawing.Image)(resources.GetObject("tsbRegister.Image")));
            this.tsbRegister.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRegister.Name = "tsbRegister";
            this.tsbRegister.Size = new System.Drawing.Size(24, 22);
            this.tsbRegister.Tag = "&#174;";
            this.tsbRegister.Text = "®";
            // 
            // toolStripButton104
            // 
            this.toolStripButton104.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton104.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton104.Image")));
            this.toolStripButton104.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton104.Name = "toolStripButton104";
            this.toolStripButton104.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton104.Tag = "&#182;";
            this.toolStripButton104.Text = "¶";
            // 
            // tsbPlusMinus
            // 
            this.tsbPlusMinus.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPlusMinus.Image = ((System.Drawing.Image)(resources.GetObject("tsbPlusMinus.Image")));
            this.tsbPlusMinus.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPlusMinus.Name = "tsbPlusMinus";
            this.tsbPlusMinus.Size = new System.Drawing.Size(23, 22);
            this.tsbPlusMinus.Tag = "&#177;";
            this.tsbPlusMinus.Text = "±";
            // 
            // toolStripButton106
            // 
            this.toolStripButton106.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton106.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton106.Image")));
            this.toolStripButton106.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton106.Name = "toolStripButton106";
            this.toolStripButton106.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton106.Tag = "&#216;";
            this.toolStripButton106.Text = "Ø";
            // 
            // tsbFunction
            // 
            this.tsbFunction.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbFunction.Image = ((System.Drawing.Image)(resources.GetObject("tsbFunction.Image")));
            this.tsbFunction.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbFunction.Name = "tsbFunction";
            this.tsbFunction.Size = new System.Drawing.Size(23, 22);
            this.tsbFunction.Tag = "&#402;";
            this.tsbFunction.Text = "ƒ";
            // 
            // toolStripButton108
            // 
            this.toolStripButton108.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton108.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton108.Image")));
            this.toolStripButton108.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton108.Name = "toolStripButton108";
            this.toolStripButton108.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton108.Tag = "&#8224;";
            this.toolStripButton108.Text = "†";
            // 
            // toolStripButton109
            // 
            this.toolStripButton109.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton109.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton109.Image")));
            this.toolStripButton109.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton109.Name = "toolStripButton109";
            this.toolStripButton109.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton109.Tag = "&#8225;";
            this.toolStripButton109.Text = "‡";
            // 
            // tsbDot
            // 
            this.tsbDot.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbDot.Image = ((System.Drawing.Image)(resources.GetObject("tsbDot.Image")));
            this.tsbDot.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDot.Name = "tsbDot";
            this.tsbDot.Size = new System.Drawing.Size(23, 22);
            this.tsbDot.Tag = "&#149;";
            this.tsbDot.Text = "•";
            // 
            // toolStripButton111
            // 
            this.toolStripButton111.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton111.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton111.Image")));
            this.toolStripButton111.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton111.Name = "toolStripButton111";
            this.toolStripButton111.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton111.Tag = "&#94;";
            this.toolStripButton111.Text = "^";
            // 
            // tsbLessThanEqual
            // 
            this.tsbLessThanEqual.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbLessThanEqual.Image = ((System.Drawing.Image)(resources.GetObject("tsbLessThanEqual.Image")));
            this.tsbLessThanEqual.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLessThanEqual.Name = "tsbLessThanEqual";
            this.tsbLessThanEqual.Size = new System.Drawing.Size(23, 22);
            this.tsbLessThanEqual.Tag = "&#8804;";
            this.tsbLessThanEqual.Text = "≤";
            // 
            // tsbGreaterthanEqual
            // 
            this.tsbGreaterthanEqual.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbGreaterthanEqual.Image = ((System.Drawing.Image)(resources.GetObject("tsbGreaterthanEqual.Image")));
            this.tsbGreaterthanEqual.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbGreaterthanEqual.Name = "tsbGreaterthanEqual";
            this.tsbGreaterthanEqual.Size = new System.Drawing.Size(23, 22);
            this.tsbGreaterthanEqual.Tag = "&#8805;";
            this.tsbGreaterthanEqual.Text = "≥";
            // 
            // toolStripButton114
            // 
            this.toolStripButton114.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton114.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton114.Image")));
            this.toolStripButton114.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton114.Name = "toolStripButton114";
            this.toolStripButton114.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton114.Tag = "&#8747;";
            this.toolStripButton114.Text = "∫";
            // 
            // toolStripButton115
            // 
            this.toolStripButton115.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton115.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton115.Image")));
            this.toolStripButton115.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton115.Name = "toolStripButton115";
            this.toolStripButton115.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton115.Tag = "&#8719;";
            this.toolStripButton115.Text = "∏";
            // 
            // tsbSigma_Upper
            // 
            this.tsbSigma_Upper.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbSigma_Upper.Image = ((System.Drawing.Image)(resources.GetObject("tsbSigma_Upper.Image")));
            this.tsbSigma_Upper.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSigma_Upper.Name = "tsbSigma_Upper";
            this.tsbSigma_Upper.Size = new System.Drawing.Size(23, 22);
            this.tsbSigma_Upper.Tag = "&#8721;";
            this.tsbSigma_Upper.Text = "∑";
            // 
            // toolStripButton117
            // 
            this.toolStripButton117.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton117.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton117.Image")));
            this.toolStripButton117.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton117.Name = "toolStripButton117";
            this.toolStripButton117.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton117.Tag = "&#131;";
            this.toolStripButton117.Text = "ƒ";
            // 
            // toolStripButton118
            // 
            this.toolStripButton118.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton118.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton118.Image")));
            this.toolStripButton118.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton118.Name = "toolStripButton118";
            this.toolStripButton118.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton118.Tag = "&#8710;";
            this.toolStripButton118.Text = "∆";
            // 
            // toolStripButton119
            // 
            this.toolStripButton119.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton119.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton119.Image")));
            this.toolStripButton119.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton119.Name = "toolStripButton119";
            this.toolStripButton119.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton119.Tag = "&#197; ";
            this.toolStripButton119.Text = "Å";
            // 
            // toolStripButton120
            // 
            this.toolStripButton120.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton120.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton120.Image")));
            this.toolStripButton120.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton120.Name = "toolStripButton120";
            this.toolStripButton120.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton120.Tag = "&#248;";
            this.toolStripButton120.Text = "ø";
            // 
            // ts1triplebond
            // 
            this.ts1triplebond.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ts1triplebond.Font = new System.Drawing.Font("Symbol", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.ts1triplebond.Image = ((System.Drawing.Image)(resources.GetObject("ts1triplebond.Image")));
            this.ts1triplebond.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ts1triplebond.Name = "ts1triplebond";
            this.ts1triplebond.Size = new System.Drawing.Size(23, 4);
            this.ts1triplebond.Tag = "&#8801;";
            this.ts1triplebond.ToolTipText = "Triple Bond";
            // 
            // toolStripButton14
            // 
            this.toolStripButton14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton14.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton14.Image")));
            this.toolStripButton14.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton14.Name = "toolStripButton14";
            this.toolStripButton14.Size = new System.Drawing.Size(23, 20);
            this.toolStripButton14.Tag = "&#226;";
            this.toolStripButton14.Text = "â";
            // 
            // toolStripButton15
            // 
            this.toolStripButton15.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton15.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton15.Image")));
            this.toolStripButton15.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton15.Name = "toolStripButton15";
            this.toolStripButton15.Size = new System.Drawing.Size(23, 20);
            this.toolStripButton15.Tag = "&#937;";
            this.toolStripButton15.Text = "Ω";
            // 
            // toolStripButton16
            // 
            this.toolStripButton16.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton16.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton16.Image")));
            this.toolStripButton16.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton16.Name = "toolStripButton16";
            this.toolStripButton16.Size = new System.Drawing.Size(23, 20);
            this.toolStripButton16.Tag = "&#228;";
            this.toolStripButton16.Text = "ä";
            // 
            // toolStripButton19
            // 
            this.toolStripButton19.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton19.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton19.Name = "toolStripButton19";
            this.toolStripButton19.Size = new System.Drawing.Size(23, 20);
            this.toolStripButton19.Tag = "&#252;";
            this.toolStripButton19.Text = "ü";
            // 
            // toolStripButton17
            // 
            this.toolStripButton17.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton17.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton17.Image")));
            this.toolStripButton17.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton17.Name = "toolStripButton17";
            this.toolStripButton17.Size = new System.Drawing.Size(23, 20);
            this.toolStripButton17.Text = "π";
            this.toolStripButton17.ToolTipText = "Lowercase Pi";
            // 
            // toolStripButton18
            // 
            this.toolStripButton18.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton18.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton18.Name = "toolStripButton18";
            this.toolStripButton18.Size = new System.Drawing.Size(23, 4);
            this.toolStripButton18.Tag = "&#x03BD;&#x0303;";
            this.toolStripButton18.Text = "ν̃";
            // 
            // toolStripButton20
            // 
            this.toolStripButton20.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton20.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton20.Image")));
            this.toolStripButton20.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton20.Name = "toolStripButton20";
            this.toolStripButton20.Size = new System.Drawing.Size(23, 20);
            this.toolStripButton20.Tag = "&#x2245;";
            // 
            // toolStripButton21
            // 
            this.toolStripButton21.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton21.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton21.Image")));
            this.toolStripButton21.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton21.Name = "toolStripButton21";
            this.toolStripButton21.Size = new System.Drawing.Size(23, 4);
            this.toolStripButton21.Tag = "&#xFFFD;";
            // 
            // toolStripButton22
            // 
            this.toolStripButton22.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton22.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton22.Image")));
            this.toolStripButton22.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton22.Name = "toolStripButton22";
            this.toolStripButton22.Size = new System.Drawing.Size(23, 20);
            this.toolStripButton22.Tag = "&#x2248;";
            this.toolStripButton22.Text = "≈";
            // 
            // toolStripButton23
            // 
            this.toolStripButton23.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton23.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton23.Image")));
            this.toolStripButton23.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton23.Name = "toolStripButton23";
            this.toolStripButton23.Size = new System.Drawing.Size(23, 4);
            this.toolStripButton23.Tag = "&#xFFFD;";
            // 
            // tsFontStyles
            // 
            this.tsFontStyles.BackColor = System.Drawing.Color.White;
            this.tsFontStyles.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tsFontStyles.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsFontStyles.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbFindReplace,
            this.toolStripSeparator3,
            this.tsbBold,
            this.tsbUnderline,
            this.tsbItalic,
            this.tsbStrikeout,
            this.tsbRegular,
            this.toolStripSeparator1,
            this.tsbSuperscript,
            this.tsbSubscript,
            this.toolStripSeparator2,
            this.tsbSmallCaps,
            this.toolStripSeparator5,
            this.tsbUndo,
            this.tsbRedo,
            this.toolStripSeparator4,
            this.tsbConvFormula});
            this.tsFontStyles.Location = new System.Drawing.Point(0, 26);
            this.tsFontStyles.Name = "tsFontStyles";
            this.tsFontStyles.Size = new System.Drawing.Size(1156, 25);
            this.tsFontStyles.TabIndex = 46;
            this.tsFontStyles.Tag = "XC";
            // 
            // tsbFindReplace
            // 
            this.tsbFindReplace.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbFindReplace.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsbFindReplace.Image = ((System.Drawing.Image)(resources.GetObject("tsbFindReplace.Image")));
            this.tsbFindReplace.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbFindReplace.Name = "tsbFindReplace";
            this.tsbFindReplace.Size = new System.Drawing.Size(105, 22);
            this.tsbFindReplace.Text = "Find and &Replace";
            this.tsbFindReplace.Visible = false;
           
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbBold
            // 
            this.tsbBold.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbBold.Image = ((System.Drawing.Image)(resources.GetObject("tsbBold.Image")));
            this.tsbBold.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbBold.Name = "tsbBold";
            this.tsbBold.Size = new System.Drawing.Size(23, 22);
            this.tsbBold.Text = "Bold";
            this.tsbBold.Click += new System.EventHandler(this.tsbBold_Click);
            // 
            // tsbUnderline
            // 
            this.tsbUnderline.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbUnderline.Image = ((System.Drawing.Image)(resources.GetObject("tsbUnderline.Image")));
            this.tsbUnderline.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbUnderline.Name = "tsbUnderline";
            this.tsbUnderline.Size = new System.Drawing.Size(23, 22);
            this.tsbUnderline.Text = "Underline";
            this.tsbUnderline.Click += new System.EventHandler(this.tsbUnderline_Click);
            // 
            // tsbItalic
            // 
            this.tsbItalic.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbItalic.Image = ((System.Drawing.Image)(resources.GetObject("tsbItalic.Image")));
            this.tsbItalic.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbItalic.Name = "tsbItalic";
            this.tsbItalic.Size = new System.Drawing.Size(23, 22);
            this.tsbItalic.Text = "italic";
            this.tsbItalic.Click += new System.EventHandler(this.tsbItalic_Click);
            // 
            // tsbStrikeout
            // 
            this.tsbStrikeout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbStrikeout.Image = ((System.Drawing.Image)(resources.GetObject("tsbStrikeout.Image")));
            this.tsbStrikeout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbStrikeout.Name = "tsbStrikeout";
            this.tsbStrikeout.Size = new System.Drawing.Size(23, 22);
            this.tsbStrikeout.Text = "StrikeOut";
            this.tsbStrikeout.Visible = false;
            // 
            // tsbRegular
            // 
            this.tsbRegular.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbRegular.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsbRegular.Image = ((System.Drawing.Image)(resources.GetObject("tsbRegular.Image")));
            this.tsbRegular.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRegular.Name = "tsbRegular";
            this.tsbRegular.Size = new System.Drawing.Size(23, 22);
            this.tsbRegular.Text = "R";
            this.tsbRegular.ToolTipText = "Regular";
            this.tsbRegular.Click += new System.EventHandler(this.tsbRegular_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            this.toolStripSeparator1.Visible = false;
            // 
            // tsbSuperscript
            // 
            this.tsbSuperscript.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSuperscript.Image = ((System.Drawing.Image)(resources.GetObject("tsbSuperscript.Image")));
            this.tsbSuperscript.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSuperscript.Name = "tsbSuperscript";
            this.tsbSuperscript.Size = new System.Drawing.Size(23, 22);
            this.tsbSuperscript.Text = "Superscript";
            this.tsbSuperscript.Click += new System.EventHandler(this.tsbSuperscript_Click);
            // 
            // tsbSubscript
            // 
            this.tsbSubscript.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSubscript.Image = ((System.Drawing.Image)(resources.GetObject("tsbSubscript.Image")));
            this.tsbSubscript.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSubscript.Name = "tsbSubscript";
            this.tsbSubscript.Size = new System.Drawing.Size(23, 22);
            this.tsbSubscript.Text = "Subscript";
            this.tsbSubscript.Click += new System.EventHandler(this.tsbSubscript_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            this.toolStripSeparator2.Visible = false;
            // 
            // tsbSmallCaps
            // 
            this.tsbSmallCaps.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSmallCaps.Image = ((System.Drawing.Image)(resources.GetObject("tsbSmallCaps.Image")));
            this.tsbSmallCaps.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSmallCaps.Name = "tsbSmallCaps";
            this.tsbSmallCaps.Size = new System.Drawing.Size(23, 22);
            this.tsbSmallCaps.Text = "toolStripButton1";
            this.tsbSmallCaps.ToolTipText = "Small Caps";
            this.tsbSmallCaps.Visible = false;
            this.tsbSmallCaps.Click += new System.EventHandler(this.tsbSmallCaps_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            this.toolStripSeparator5.Visible = false;
            // 
            // tsbUndo
            // 
            this.tsbUndo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbUndo.Image = ((System.Drawing.Image)(resources.GetObject("tsbUndo.Image")));
            this.tsbUndo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbUndo.Name = "tsbUndo";
            this.tsbUndo.Size = new System.Drawing.Size(23, 22);
            this.tsbUndo.Text = "Undo";
            this.tsbUndo.Visible = false;
            this.tsbUndo.Click += new System.EventHandler(this.tsbUndo_Click);
            // 
            // tsbRedo
            // 
            this.tsbRedo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRedo.Image = ((System.Drawing.Image)(resources.GetObject("tsbRedo.Image")));
            this.tsbRedo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRedo.Name = "tsbRedo";
            this.tsbRedo.Size = new System.Drawing.Size(23, 22);
            this.tsbRedo.Text = "Redo";
            this.tsbRedo.Visible = false;
            this.tsbRedo.Click += new System.EventHandler(this.tsbRedo_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbConvFormula
            // 
            this.tsbConvFormula.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbConvFormula.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsbConvFormula.Image = ((System.Drawing.Image)(resources.GetObject("tsbConvFormula.Image")));
            this.tsbConvFormula.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbConvFormula.Name = "tsbConvFormula";
            this.tsbConvFormula.Size = new System.Drawing.Size(102, 22);
            this.tsbConvFormula.Text = "Convert Formula";
            this.tsbConvFormula.Visible = false;
            this.tsbConvFormula.Click += new System.EventHandler(this.tsbConvFormula_Click);
            // 
            // ucSplCharsToolStrip
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.tsFontStyles);
            this.Controls.Add(this.tsSpecialChars);
            this.Name = "ucSplCharsToolStrip";
            this.Size = new System.Drawing.Size(1156, 51);
            this.tsSpecialChars.ResumeLayout(false);
            this.tsSpecialChars.PerformLayout();
            this.tsFontStyles.ResumeLayout(false);
            this.tsFontStyles.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.ToolStrip tsSpecialChars;
        private System.Windows.Forms.ToolStripButton tsbAlpha;
        private System.Windows.Forms.ToolStripButton tsbBeta;
        private System.Windows.Forms.ToolStripButton tsbGamma;
        private System.Windows.Forms.ToolStripButton tsbDelta;
        private System.Windows.Forms.ToolStripButton tsbEpsilon;
        private System.Windows.Forms.ToolStripButton tsbZeta;
        private System.Windows.Forms.ToolStripButton tsbEta;
        private System.Windows.Forms.ToolStripButton tsbTheta;
        private System.Windows.Forms.ToolStripButton tsbIota;
        private System.Windows.Forms.ToolStripButton tsbKappa;
        private System.Windows.Forms.ToolStripButton tsbLamda;
        private System.Windows.Forms.ToolStripButton tsbMu;
        private System.Windows.Forms.ToolStripButton tsbNu;
        private System.Windows.Forms.ToolStripButton tsbXi;
        private System.Windows.Forms.ToolStripButton tsbOmicron;
        private System.Windows.Forms.ToolStripButton tsbPi;
        private System.Windows.Forms.ToolStripButton tsbRho;
        private System.Windows.Forms.ToolStripButton tsbSigma;
        private System.Windows.Forms.ToolStripButton tsbTau;
        private System.Windows.Forms.ToolStripButton tsbUpsolin;
        private System.Windows.Forms.ToolStripButton tsupsilon;
        private System.Windows.Forms.ToolStripButton tsbPhi;
        private System.Windows.Forms.ToolStripButton tsbChi;
        private System.Windows.Forms.ToolStripButton tsbPsi;
        private System.Windows.Forms.ToolStripButton tsbOmega;
        private System.Windows.Forms.ToolStripButton tsbDegree;
        private System.Windows.Forms.ToolStripButton tsbPipe;
        private System.Windows.Forms.ToolStripButton tsbApprox;
        private System.Windows.Forms.ToolStripButton toolStripButton99;
        private System.Windows.Forms.ToolStripButton toolStripButton100;
        private System.Windows.Forms.ToolStripButton tsbCopyright;
        private System.Windows.Forms.ToolStripButton toolStripButton102;
        private System.Windows.Forms.ToolStripButton tsbRegister;
        private System.Windows.Forms.ToolStripButton toolStripButton104;
        private System.Windows.Forms.ToolStripButton tsbPlusMinus;
        private System.Windows.Forms.ToolStripButton toolStripButton106;
        private System.Windows.Forms.ToolStripButton tsbFunction;
        private System.Windows.Forms.ToolStripButton toolStripButton108;
        private System.Windows.Forms.ToolStripButton toolStripButton109;
        private System.Windows.Forms.ToolStripButton tsbDot;
        private System.Windows.Forms.ToolStripButton toolStripButton111;
        private System.Windows.Forms.ToolStripButton tsbLessThanEqual;
        private System.Windows.Forms.ToolStripButton tsbGreaterthanEqual;
        private System.Windows.Forms.ToolStripButton toolStripButton114;
        private System.Windows.Forms.ToolStripButton toolStripButton115;
        private System.Windows.Forms.ToolStripButton tsbSigma_Upper;
        private System.Windows.Forms.ToolStripButton toolStripButton117;
        private System.Windows.Forms.ToolStripButton toolStripButton118;
        private System.Windows.Forms.ToolStripButton toolStripButton119;
        private System.Windows.Forms.ToolStripButton toolStripButton120;
        private System.Windows.Forms.ToolStripButton ts1triplebond;
        private System.Windows.Forms.ToolStripButton toolStripButton14;
        private System.Windows.Forms.ToolStripButton toolStripButton15;
        private System.Windows.Forms.ToolStripButton toolStripButton16;
        private System.Windows.Forms.ToolStripButton toolStripButton19;
        private System.Windows.Forms.ToolStripButton toolStripButton17;
        private System.Windows.Forms.ToolStripButton toolStripButton18;
        private System.Windows.Forms.ToolStripButton toolStripButton20;
        private System.Windows.Forms.ToolStripButton toolStripButton21;
        private System.Windows.Forms.ToolStripButton toolStripButton22;
        private System.Windows.Forms.ToolStripButton toolStripButton23;
        private System.Windows.Forms.ToolStrip tsFontStyles;
        private System.Windows.Forms.ToolStripButton tsbFindReplace;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton tsbBold;
        private System.Windows.Forms.ToolStripButton tsbUnderline;
        private System.Windows.Forms.ToolStripButton tsbItalic;
        private System.Windows.Forms.ToolStripButton tsbStrikeout;
        private System.Windows.Forms.ToolStripButton tsbRegular;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tsbSuperscript;
        private System.Windows.Forms.ToolStripButton tsbSubscript;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton tsbSmallCaps;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton tsbUndo;
        private System.Windows.Forms.ToolStripButton tsbRedo;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.FontDialog fontDialog1;
        public System.Windows.Forms.ToolStripButton tsbConvFormula;
    }
}
