﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using CADViewLib;
using IndxReactNarr.Generic;
using IndxReactNarr.Common;

namespace IndxReactNarr
{
    public partial class ucNUMDetails : UserControl
    {
        public ucNUMDetails()
        {
            InitializeComponent();
        }

        #region Property Procedures

        private string _nrnnum = "";
        public string NrnNum
        {
            get
            { return _nrnnum; }
            set
            {
                _nrnnum = value;
                lblNUMVal.Text = _nrnnum;
            }
        }

        private string _regno = "";
        public string RegNo
        {
            get
            { return _regno; }
            set
            {
                _regno = value;
                lblRegNoVal.Text = _regno;
            }
        }        

        private string _iupacname = "";
        public string IUPACName
        {
            get
            { return _iupacname; }
            set
            {
                _iupacname = value;
                txtIUPAC.Text = _iupacname;
            }
        }

        private string _molformula = "";
        public string MolFormula
        {
            get
            { return _molformula; }
            set
            {
                _molformula = value;
                lblMolFormulaVal.Text = _molformula;
            }
        }      

        private string _synonyms = "";
        public string Synonyms
        {
            get
            { return _synonyms; }
            set
            {
                _synonyms = value;
                txtSynonyms.Text = _synonyms;
            }
        }

        private string[] _molformarr = null;
        public string[] MolFormulaArr
        {
            get
            { return _molformarr; }
            set
            {
                _molformarr = value;               
            }
        }      

        private string[] _hexcode_arr = null;
        public string[] HexCodeArr
        {
            get
            {
                return _hexcode_arr;
            }
            set
            {
                _hexcode_arr = value;
            }
        }

        private string[] _stereochem_arr = null;
        public string[] StereoChemArr
        {
            get
            {
                return _stereochem_arr;
            }
            set
            {
                _stereochem_arr = value;
            }
        }

        private string _peptideseq = "";
        public string PeptideSeq
        {
            get
            { return _peptideseq; }
            set
            {
                _peptideseq = value;
                txtPeptideSeq.Text = _peptideseq;
            }
        }

        private string _nuclicacidseq = "";
        public string NuclicAcidSeq
        {
            get
            { return _nuclicacidseq; }
            set
            {
                _nuclicacidseq = value;
                txtNuclicAcidSeq.Text = _nuclicacidseq;
            }
        }

        public object MolStructure
        {
            get;
            set;
        }

        #endregion

        private void ucNUMDetails_Load(object sender, EventArgs e)
        {
            try
            {
                if (HexCodeArr != null)
                {
                    if (HexCodeArr.Length > 0)
                    {
                        ucStructure_Image objStructImg = null;

                        tlPnlChemImage.ColumnCount = HexCodeArr.Length;
                        tlPnlChemImage.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;                       
                        tlPnlChemImage.AutoScroll = true;
                        for (int i = 0; i < tlPnlChemImage.ColumnCount; i++)
                        {
                            ColumnStyle cStyle = new ColumnStyle();
                            cStyle.SizeType = SizeType.Absolute;
                            cStyle.Width = 360;
                            tlPnlChemImage.ColumnStyles.Add(cStyle);
                        }                        
                        for (int i = 0; i < HexCodeArr.Length; i++)
                        {
                            objStructImg = new ucStructure_Image();
                            objStructImg.Dock = DockStyle.Fill;
                            try
                            {
                                objStructImg.StereoChem = StereoChemArr[i];                                
                            }
                            catch
                            {
                                objStructImg.StereoChem = "";
                            }

                            try
                            {
                                objStructImg.MolFormula = MolFormulaArr[i];
                            }
                            catch
                            {
                                objStructImg.MolFormula = "";
                            }

                            objStructImg.ChemImage = HexCodeToStructureImage.GetChemImageOnHexCode(HexCodeArr[i], RegNo);
                            tlPnlChemImage.Controls.Add(objStructImg, i, 0);
                            tlPnlChemImage.ColumnStyles[i].SizeType = SizeType.Absolute;
                            tlPnlChemImage.ColumnStyles[i].Width = 360;
                        }                       
                    }
                }
                else if (MolStructure != null)
                {
                    Image chemImage = null;
                    using (MDL.Draw.Renditor.Renditor ChemRenditor = new MDL.Draw.Renditor.Renditor())
                    {
                        ChemRenditor.MolfileString = MolStructure.ToString();
                        chemImage = ChemRenditor.Image;
                    }

                    tlPnlChemImage.ColumnCount = 1;
                    tlPnlChemImage.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
                    tlPnlChemImage.AutoScroll = true;

                    ColumnStyle cStyle = new ColumnStyle();
                    cStyle.SizeType = SizeType.Absolute;
                    cStyle.Width = 360;
                    tlPnlChemImage.ColumnStyles.Add(cStyle);

                    ucStructure_Image objStructImg = new ucStructure_Image();
                    objStructImg.Dock = DockStyle.Fill;

                    objStructImg.ChemImage = chemImage;
                    tlPnlChemImage.Controls.Add(objStructImg, 0, 0);
                    tlPnlChemImage.ColumnStyles[0].SizeType = SizeType.Absolute;
                    tlPnlChemImage.ColumnStyles[0].Width = 360;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
              
    }
}
