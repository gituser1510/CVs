﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using System.IO;
using System.Xml;
using System.Text.RegularExpressions;

using CADViewLib;
using System.Collections;
using MarkupConverter;
using IndxReactNarr.Common;

namespace IndxReactNarr
{
    public partial class ucGetReaction : UserControl
    {
        #region Constructor

        private IMarkupConverter markupConverter;
        public ucGetReaction()
        {
            InitializeComponent();
            markupConverter = new MarkupConverter.MarkupConverter();
        }

        #endregion

        #region Property Procedures

        private string _serialno = "";
        public string SerialNo
        {
            get
            { return _serialno; }
            set
            {
                _serialno = value;
            }
        }

        private string _prodnum = "";
        public string ProdNUM
        {
            get
            { return _prodnum; }
            set
            {
                _prodnum = value;
            }
        }
        
        private DataTable _prodtbl = null;
        public DataTable ProductTbl
        {
            get
            { return _prodtbl; }
            set
            {
                _prodtbl = value;
            }
        }

        private DataTable _reactanttbl = null;
        public DataTable ReactantTbl
        {
            get
            { return _reactanttbl; }
            set
            {
                _reactanttbl = value;
            }
        }

        private DataTable _partpntstbl = null;
        public DataTable PartpntsTbl
        {
            get
            { return _partpntstbl; }
            set
            {
                _partpntstbl = value;
            }
        }

        private DataTable _cgmdatatbl = null;
        public DataTable CGMDataTbl
        {
            get
            { return _cgmdatatbl; }
            set
            {
                _cgmdatatbl = value;
            }
        }

        #endregion

        public void GetReactionData_BindToPanel()
        {
            try
            {
                lblSnoVal.Text = SerialNo;
                lblProdVal.Text = ProdNUM;          

                if (ReactantTbl != null)
                {
                    if (ReactantTbl.Rows.Count > 0)
                    {
                        tlpnlProd.RowCount = 1;

                        int intReactCnt = GetPanelControlsLength(ReactantTbl, "REACTANT");
                        int intProdCnt = GetPanelControlsLength(ProductTbl, "PRODUCT");

                        int intTotColCnt = intReactCnt + intProdCnt;
                        tlpnlProd.ColumnCount = intTotColCnt;

                        int colCnt = intTotColCnt;
                        for (int i = 0; i < colCnt; i++)
                        {
                            ColumnStyle cStyle = new ColumnStyle();
                            cStyle.SizeType = SizeType.AutoSize;
                            cStyle.Width = 70;

                            tlpnlProd.ColumnStyles.Add(cStyle);
                        }

                        ucProd_Reactant objUC = null;
                        ucPlus objPlus = null;
                        int colIndx = 0;

                        for (int i = 0; i < ReactantTbl.Rows.Count; i++)
                        {
                            if (ReactantTbl.Rows[i]["nrnreg"].ToString() != "")
                            {
                                object objStruct = ReactantTbl.Rows[i]["structure"].ToString();
                                if (objStruct.ToString() != "")
                                { 
                                    objUC = new ucProd_Reactant();
                                    objUC.Dock = DockStyle.Fill;
                                    objUC.NrnNum = ReactantTbl.Rows[i]["num"].ToString();
                                    objUC.StageName = ReactantTbl.Rows[i]["Stage"].ToString();

                                    ChemRenditor.MolfileString = objStruct.ToString();
                                    objUC.ChemImage = ChemRenditor.Image;

                                    if (tlpnlProd.Controls.Count > 0)
                                    {
                                        if (tlpnlProd.Controls[colIndx - 1].Name.ToUpper() != "UCPLUS")
                                        {
                                            objPlus = new ucPlus();
                                            objPlus.Dock = DockStyle.Fill;

                                            tlpnlProd.Controls.Add(objPlus, colIndx, 0);
                                            tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                            tlpnlProd.ColumnStyles[colIndx].Width = 30;
                                            colIndx++;
                                        }
                                    }
                                    tlpnlProd.Controls.Add(objUC, colIndx, 0);
                                    tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                    tlpnlProd.ColumnStyles[colIndx].Width = 290;
                                    colIndx++;
                                }
                                else
                                {
                                    int regno = Convert.ToInt32(ReactantTbl.Rows[i]["nrnreg"].ToString());
                                    string[] strHexArr = GetHexCodeOnRegNo(regno);
                                    if (strHexArr != null)
                                    {
                                        if (strHexArr.Length > 0)
                                        {
                                            if (tlpnlProd.Controls.Count > 0 && i < ReactantTbl.Rows.Count)
                                            {
                                                if (tlpnlProd.Controls[colIndx - 1].Name.ToUpper() != "UCPLUS")
                                                {
                                                    objPlus = new ucPlus();
                                                    objPlus.Dock = DockStyle.Fill;

                                                    tlpnlProd.Controls.Add(objPlus, colIndx, 0);
                                                    tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                                    tlpnlProd.ColumnStyles[colIndx].Width = 30;
                                                    colIndx++;
                                                }
                                            }
                                            
                                            for (int hIndx = 0; hIndx < strHexArr.Length; hIndx++)
                                            {
                                                objUC = new ucProd_Reactant();
                                                objUC.Dock = DockStyle.Fill;
                                                objUC.StageName = ReactantTbl.Rows[i]["Stage"].ToString();
                                                objUC.NrnNum = ReactantTbl.Rows[i]["num"].ToString();
                                                objUC.ChemHexCode = strHexArr[hIndx];
                                                objUC.ChemImage = HexCodeToStructureImage.GetChemImageOnHexCode(strHexArr[hIndx], regno.ToString());

                                                tlpnlProd.Controls.Add(objUC, colIndx, 0);
                                                tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                                tlpnlProd.ColumnStyles[colIndx].Width = 290;
                                                colIndx++;
                                            }
                                        }
                                    }
                                    else //Hex array NULL for series 8500 RegNos
                                    {
                                        if (tlpnlProd.Controls.Count > 0 && i < ReactantTbl.Rows.Count)
                                        {
                                            if (tlpnlProd.Controls[colIndx - 1].Name.ToUpper() != "UCPLUS")
                                            {
                                                objPlus = new ucPlus();
                                                objPlus.Dock = DockStyle.Fill;

                                                tlpnlProd.Controls.Add(objPlus, colIndx, 0);
                                                tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                                tlpnlProd.ColumnStyles[colIndx].Width = 30;
                                                colIndx++;
                                            }
                                        }    

                                        objUC = new ucProd_Reactant();
                                        objUC.Dock = DockStyle.Fill;
                                        objUC.StageName = ReactantTbl.Rows[i]["Stage"].ToString();
                                        objUC.NrnNum = ReactantTbl.Rows[i]["num"].ToString();
                                        objUC.ChemImage = null;
                                        
                                        tlpnlProd.Controls.Add(objUC, colIndx, 0);
                                        tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                        tlpnlProd.ColumnStyles[colIndx].Width = 290;
                                        colIndx++;
                                    }
                                }
                            }
                        }

                        //Arrow Control
                        if (tlpnlProd.Controls.Count > 0)
                        {
                            ucArrow objArrow = new ucArrow();
                            objArrow.Dock = DockStyle.Fill;
                            tlpnlProd.Controls.Add(objArrow, colIndx, 0);
                            tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                            tlpnlProd.ColumnStyles[colIndx].Width = 90;
                            colIndx++;
                        }

                        //Product Control
                        for (int i = 0; i < ProductTbl.Rows.Count; i++)
                        {
                            if (ProductTbl.Rows[i]["nrnreg"].ToString() != "")
                            {
                                object objStruct = ProductTbl.Rows[i]["structure"].ToString();
                                if (objStruct.ToString() != "")
                                {
                                    objUC = new ucProd_Reactant();
                                    objUC.Dock = DockStyle.Fill;
                                    objUC.NrnNum = ProductTbl.Rows[i]["num"].ToString();

                                    ChemRenditor.MolfileString = objStruct.ToString();
                                    objUC.ChemImage = ChemRenditor.Image;

                                    tlpnlProd.Controls.Add(objUC, colIndx, 0);
                                    tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                    tlpnlProd.ColumnStyles[colIndx].Width = 290;
                                    colIndx++;

                                    if (colIndx <= colCnt - 2)
                                    {
                                        objPlus = new ucPlus();
                                        objPlus.Dock = DockStyle.Fill;

                                        tlpnlProd.Controls.Add(objPlus, colIndx, 0);
                                        tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                        tlpnlProd.ColumnStyles[colIndx].Width = 30;
                                        colIndx++;
                                    }
                                }
                                else
                                {
                                    int regno = Convert.ToInt32(ProductTbl.Rows[i]["nrnreg"].ToString());
                                    string[] strHexArr = GetHexCodeOnRegNo(regno);
                                    if (strHexArr != null)
                                    {
                                        for (int hIndx = 0; hIndx < strHexArr.Length; hIndx++)
                                        {
                                            objUC = new ucProd_Reactant();
                                            objUC.Dock = DockStyle.Fill;
                                            objUC.NrnNum = ProductTbl.Rows[i]["num"].ToString();
                                            objUC.ChemImage =HexCodeToStructureImage.GetChemImageOnHexCode(strHexArr[hIndx], regno.ToString());
                                            objUC.ChemHexCode = strHexArr[hIndx];
                                            tlpnlProd.Controls.Add(objUC, colIndx, 0);
                                            tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                            tlpnlProd.ColumnStyles[colIndx].Width = 290;
                                            colIndx++;
                                        }

                                        if (i < ProductTbl.Rows.Count - 1)
                                        {
                                            objPlus = new ucPlus();
                                            objPlus.Dock = DockStyle.Fill;
                                            tlpnlProd.Controls.Add(objPlus, colIndx, 0);
                                            tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                            tlpnlProd.ColumnStyles[colIndx].Width = 30;
                                            colIndx++;
                                        }
                                    }
                                    else // Empty structure in cgm file
                                    {
                                        objUC = new ucProd_Reactant();
                                        objUC.Dock = DockStyle.Fill;
                                        objUC.NrnNum = ProductTbl.Rows[i]["num"].ToString();
                                        objUC.ChemImage = null;

                                        tlpnlProd.Controls.Add(objUC, colIndx, 0);
                                        tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                        tlpnlProd.ColumnStyles[colIndx].Width = 290;
                                        colIndx++;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        tlpnlProd.Controls.Clear();
                    }
                }

                //Get participants Data & bind to RichTextBox
                GetPartpntsData_BindToTextBox();                        
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        //Give first preference to CGM, next Database while getting Structure
        //New modification on 6th April 2011
        public void GetReactionData_BindToPanel_New()
        {
            try
            {
                lblSnoVal.Text = SerialNo;
                lblProdVal.Text = ProdNUM;

                if (ReactantTbl != null)
                {
                    if (ReactantTbl.Rows.Count > 0)
                    {
                        tlpnlProd.RowCount = 1;

                        int intReactCnt = GetPanelControlsLength(ReactantTbl, "REACTANT");
                        int intProdCnt = GetPanelControlsLength(ProductTbl, "PRODUCT");

                        int intTotColCnt = intReactCnt + intProdCnt;
                        tlpnlProd.ColumnCount = intTotColCnt;

                        int colCnt = intTotColCnt;
                        for (int i = 0; i < colCnt; i++)
                        {
                            ColumnStyle cStyle = new ColumnStyle();
                            cStyle.SizeType = SizeType.AutoSize;
                            cStyle.Width = 70;

                            tlpnlProd.ColumnStyles.Add(cStyle);
                        }

                        ucProd_Reactant objUC = null;
                        ucPlus objPlus = null;
                        int colIndx = 0;

                        for (int i = 0; i < ReactantTbl.Rows.Count; i++)
                        {
                            if (ReactantTbl.Rows[i]["REG_NO"].ToString() != "")
                            {
                                object objStruct = ReactantTbl.Rows[i]["STRUCTURE"].ToString();

                                int regno = Convert.ToInt32(ReactantTbl.Rows[i]["REG_NO"].ToString());
                                string[] strHexArr = GetHexCodeOnRegNo(regno);

                                if (strHexArr != null)//First preference is to Cgm data
                                {
                                    if (strHexArr.Length > 0)
                                    {
                                        if (tlpnlProd.Controls.Count > 0 && i < ReactantTbl.Rows.Count)
                                        {
                                            if (tlpnlProd.Controls[colIndx - 1].Name.ToUpper() != "UCPLUS")
                                            {
                                                objPlus = new ucPlus();
                                                objPlus.Dock = DockStyle.Fill;
                                                objPlus.TabStop = false;

                                                tlpnlProd.Controls.Add(objPlus, colIndx, 0);
                                                tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                                tlpnlProd.ColumnStyles[colIndx].Width = 30;
                                                colIndx++;
                                            }
                                        }

                                        for (int hIndx = 0; hIndx < strHexArr.Length; hIndx++)
                                        {
                                            objUC = new ucProd_Reactant();
                                            objUC.Dock = DockStyle.Fill;
                                            objUC.TabStop = false;

                                            objUC.StageName = ReactantTbl.Rows[i]["Stage"].ToString();
                                            objUC.NrnNum = ReactantTbl.Rows[i]["num"].ToString();
                                            objUC.ChemHexCode = strHexArr[hIndx];
                                            objUC.ChemImage = HexCodeToStructureImage.GetChemImageOnHexCode(strHexArr[hIndx], regno.ToString());

                                            tlpnlProd.Controls.Add(objUC, colIndx, 0);
                                            tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                            tlpnlProd.ColumnStyles[colIndx].Width = 290;
                                            colIndx++;
                                        }
                                    }
                                }
                                else if (objStruct.ToString().Trim() != "")//Second preference to Database
                                {
                                    objUC = new ucProd_Reactant();
                                    objUC.Dock = DockStyle.Fill;
                                    objUC.TabStop = false;

                                    objUC.NrnNum = ReactantTbl.Rows[i]["num"].ToString();
                                    objUC.StageName = ReactantTbl.Rows[i]["Stage"].ToString();

                                    ChemRenditor.MolfileString = objStruct.ToString();
                                    objUC.ChemImage = ChemRenditor.Image;

                                    if (tlpnlProd.Controls.Count > 0)
                                    {
                                        if (tlpnlProd.Controls[colIndx - 1].Name.ToUpper() != "UCPLUS")
                                        {
                                            objPlus = new ucPlus();
                                            objPlus.Dock = DockStyle.Fill;
                                            objPlus.TabStop = false;

                                            tlpnlProd.Controls.Add(objPlus, colIndx, 0);
                                            tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                            tlpnlProd.ColumnStyles[colIndx].Width = 30;
                                            colIndx++;
                                        }
                                    }

                                    tlpnlProd.Controls.Add(objUC, colIndx, 0);
                                    tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                    tlpnlProd.ColumnStyles[colIndx].Width = 290;
                                    colIndx++;
                                }
                                else //Empty structure in cgm file and Database for 8500 series RegNos
                                {
                                    if (tlpnlProd.Controls.Count > 0 && i < ReactantTbl.Rows.Count)
                                    {
                                        if (tlpnlProd.Controls[colIndx - 1].Name.ToUpper() != "UCPLUS")
                                        {
                                            objPlus = new ucPlus();
                                            objPlus.Dock = DockStyle.Fill;
                                            objPlus.TabStop = false;

                                            tlpnlProd.Controls.Add(objPlus, colIndx, 0);
                                            tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                            tlpnlProd.ColumnStyles[colIndx].Width = 30;
                                            colIndx++;
                                        }
                                    }

                                    objUC = new ucProd_Reactant();
                                    objUC.Dock = DockStyle.Fill;
                                    objUC.TabStop = false;

                                    objUC.StageName = ReactantTbl.Rows[i]["Stage"].ToString();
                                    objUC.NrnNum = ReactantTbl.Rows[i]["num"].ToString();
                                    objUC.ChemImage = null;

                                    tlpnlProd.Controls.Add(objUC, colIndx, 0);
                                    tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                    tlpnlProd.ColumnStyles[colIndx].Width = 290;
                                    colIndx++;
                                }                 
                            }
                        }

                        //Arrow Control
                        if (tlpnlProd.Controls.Count > 0)
                        {
                            ucArrow objArrow = new ucArrow();
                            objArrow.Dock = DockStyle.Fill;
                            objArrow.TabStop = false;

                            tlpnlProd.Controls.Add(objArrow, colIndx, 0);
                            tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                            tlpnlProd.ColumnStyles[colIndx].Width = 90;
                            colIndx++;
                        }

                        //Product Control
                        for (int i = 0; i < ProductTbl.Rows.Count; i++)
                        {
                            if (ProductTbl.Rows[i]["nrnreg"].ToString() != "")
                            {
                                object objStruct = ProductTbl.Rows[i]["structure"].ToString();

                                int regno = Convert.ToInt32(ProductTbl.Rows[i]["nrnreg"].ToString());
                                string[] strHexArr = GetHexCodeOnRegNo(regno);

                                if (strHexArr != null)//First preference to Cgm file data
                                {
                                    for (int hIndx = 0; hIndx < strHexArr.Length; hIndx++)
                                    {
                                        objUC = new ucProd_Reactant();
                                        objUC.Dock = DockStyle.Fill;
                                        objUC.TabStop = false;

                                        objUC.NrnNum = ProductTbl.Rows[i]["num"].ToString();
                                        objUC.ChemHexCode = strHexArr[hIndx];
                                        objUC.ChemImage = HexCodeToStructureImage.GetChemImageOnHexCode(strHexArr[hIndx], regno.ToString());

                                        tlpnlProd.Controls.Add(objUC, colIndx, 0);
                                        tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                        tlpnlProd.ColumnStyles[colIndx].Width = 290;
                                        colIndx++;
                                    }

                                    if (i < ProductTbl.Rows.Count - 1)
                                    {
                                        objPlus = new ucPlus();
                                        objPlus.Dock = DockStyle.Fill;
                                        objPlus.TabStop = false;

                                        tlpnlProd.Controls.Add(objPlus, colIndx, 0);
                                        tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                        tlpnlProd.ColumnStyles[colIndx].Width = 30;
                                        colIndx++;
                                    }
                                }
                                else if (objStruct.ToString().Trim() != "")//Second preference is to Database
                                {
                                    objUC = new ucProd_Reactant();
                                    objUC.Dock = DockStyle.Fill;
                                    objUC.NrnNum = ProductTbl.Rows[i]["num"].ToString();

                                    ChemRenditor.MolfileString = objStruct.ToString();
                                    objUC.ChemImage = ChemRenditor.Image;
                                    objUC.TabStop = false;

                                    tlpnlProd.Controls.Add(objUC, colIndx, 0);
                                    tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                    tlpnlProd.ColumnStyles[colIndx].Width = 290;
                                    colIndx++;

                                    if (colIndx <= colCnt - 2)
                                    {
                                        objPlus = new ucPlus();
                                        objPlus.Dock = DockStyle.Fill;
                                        objPlus.TabStop = false;

                                        tlpnlProd.Controls.Add(objPlus, colIndx, 0);
                                        tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                        tlpnlProd.ColumnStyles[colIndx].Width = 30;
                                        colIndx++;
                                    }
                                }
                                else //Empty structure in cgm file and Database for series 8500 RegNos
                                {
                                    objUC = new ucProd_Reactant();
                                    objUC.Dock = DockStyle.Fill;
                                    objUC.NrnNum = ProductTbl.Rows[i]["num"].ToString();
                                    objUC.ChemImage = null;
                                    objUC.TabStop = false;

                                    tlpnlProd.Controls.Add(objUC, colIndx, 0);
                                    tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                    tlpnlProd.ColumnStyles[colIndx].Width = 290;
                                    colIndx++;
                                }                   
                            }
                        }
                    }
                    else
                    {
                        tlpnlProd.Controls.Clear();
                    }
                }

                //Get participants Data & bind to RichTextBox
                GetPartpntsData_BindToTextBox();                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public void GetReactionDataAndBindToPanel_IRN()
        {
            try
            {
                lblSnoVal.Text = SerialNo;
                lblProdVal.Text = ProdNUM;

                if (ReactantTbl != null)
                {
                    if (ReactantTbl.Rows.Count > 0)
                    {
                        tlpnlProd.RowCount = 1;

                        int intReactCnt = ReactantTbl.Rows.Count + (ReactantTbl.Rows.Count - 1);
                        int intProdCnt = ProductTbl.Rows.Count + (ProductTbl.Rows.Count - 1);

                        int intTotColCnt = intReactCnt + 1 + intProdCnt;
                        tlpnlProd.ColumnCount = intTotColCnt;

                        int colCnt = intTotColCnt;
                        for (int i = 0; i < colCnt; i++)
                        {
                            ColumnStyle cStyle = new ColumnStyle();
                            cStyle.SizeType = SizeType.AutoSize;
                            cStyle.Width = 70;

                            tlpnlProd.ColumnStyles.Add(cStyle);
                        }

                        ucProd_Reactant objUC = null;
                        ucPlus objPlus = null;
                        int colIndx = 0;

                        for (int i = 0; i < ReactantTbl.Rows.Count; i++)
                        {
                            if (!string.IsNullOrEmpty(ReactantTbl.Rows[i]["NUM"].ToString()))
                            {
                                if (tlpnlProd.Controls.Count > 0 && i < ReactantTbl.Rows.Count)
                                {
                                    if (tlpnlProd.Controls[colIndx - 1].Name.ToUpper() != "UCPLUS")
                                    {
                                        objPlus = new ucPlus();
                                        objPlus.Dock = DockStyle.Fill;
                                        objPlus.TabStop = false;

                                        tlpnlProd.Controls.Add(objPlus, colIndx, 0);
                                        tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                        tlpnlProd.ColumnStyles[colIndx].Width = 30;
                                        colIndx++;
                                    }
                                }

                                objUC = new ucProd_Reactant();
                                objUC.Dock = DockStyle.Fill;
                                objUC.TabStop = false;

                                objUC.StageName = ReactantTbl.Rows[i]["STAGE"].ToString();
                                objUC.NrnNum = ReactantTbl.Rows[i]["NUM"].ToString();
                                // objUC.ChemHexCode = strHexArr[hIndx];
                                if (ReactantTbl.Rows[i]["STRUCTURE"] != null)
                                {
                                    objUC.ChemImage = ReactantTbl.Rows[i]["STRUCTURE"] as Image;// GetChemImageOnHexCode(strHexArr[hIndx], regno.ToString());
                                    try
                                    {
                                        if (objUC.ChemImage == null)
                                        {
                                            objUC.ChemImage = DataConversions.ByteArrayToImage(ReactantTbl.Rows[i]["STRUCTURE"] as byte[]);
                                        }
                                    }
                                    catch
                                    { 
                                    
                                    }
                                }
                                tlpnlProd.Controls.Add(objUC, colIndx, 0);
                                tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                tlpnlProd.ColumnStyles[colIndx].Width = 290;
                                colIndx++;

                            }
                        }

                        //Arrow Control
                        if (tlpnlProd.Controls.Count > 0)
                        {
                            ucArrow objArrow = new ucArrow();
                            objArrow.Dock = DockStyle.Fill;
                            objArrow.TabStop = false;

                            tlpnlProd.Controls.Add(objArrow, colIndx, 0);
                            tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                            tlpnlProd.ColumnStyles[colIndx].Width = 90;
                            colIndx++;
                        }

                        //Product Control
                        for (int i = 0; i < ProductTbl.Rows.Count; i++)
                        {
                            if (!string.IsNullOrEmpty(ProductTbl.Rows[i]["NUM"].ToString()))
                            {

                                objUC = new ucProd_Reactant();
                                objUC.Dock = DockStyle.Fill;
                                objUC.TabStop = false;

                                objUC.NrnNum = ProductTbl.Rows[i]["NUM"].ToString();
                                //objUC.ChemHexCode = strHexArr[hIndx];

                                if (ProductTbl.Rows[i]["STRUCTURE"] != null)
                                {                                  
                                    objUC.ChemImage = ProductTbl.Rows[i]["STRUCTURE"] as Image;// GetChemImageOnHexCode(strHexArr[hIndx], regno.ToString());
                                    try
                                    {
                                        if (objUC.ChemImage == null)
                                        {
                                            objUC.ChemImage = DataConversions.ByteArrayToImage(ProductTbl.Rows[i]["STRUCTURE"] as byte[]);
                                        }
                                    }
                                    catch
                                    {

                                    }
                                }
                                tlpnlProd.Controls.Add(objUC, colIndx, 0);
                                tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                tlpnlProd.ColumnStyles[colIndx].Width = 290;
                                colIndx++;
                                
                                if (i < ProductTbl.Rows.Count - 1)
                                {
                                    objPlus = new ucPlus();
                                    objPlus.Dock = DockStyle.Fill;
                                    objPlus.TabStop = false;

                                    tlpnlProd.Controls.Add(objPlus, colIndx, 0);
                                    tlpnlProd.ColumnStyles[colIndx].SizeType = SizeType.Absolute;
                                    tlpnlProd.ColumnStyles[colIndx].Width = 30;
                                    colIndx++;
                                }
                            }
                        }
                    }
                    else
                    {
                        tlpnlProd.Controls.Clear();
                    }
                }

                //Get participants Data & bind to RichTextBox
                GetPartpntsData_BindToTextBox();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetPartpntsData_BindToTextBox()
        {
            try
            {
                //Participants, Conditions and RSN Information
                rtxtPartpnts.Text = GetParticipantsFromTable();
                if (strRSN_CVT_Rxn.Trim() != "")
                {
                    string strFinalVal = rtxtPartpnts.Text.Trim() + "\r\nRSN REACTION:\r\n             " + strRSN_CVT_Rxn.Trim();
                    rtxtPartpnts.Text = strFinalVal;
                }
                if (strRSN_FT_Rxn.Trim() != "")
                {
                    if (strRSN_CVT_Rxn.Trim() != "")
                    {
                        rtxtPartpnts.Text = rtxtPartpnts.Text.Trim() + "\r\n           " + strRSN_FT_Rxn.Trim();
                    }
                    else
                    {
                        rtxtPartpnts.Text = rtxtPartpnts.Text.Trim() + "\r\nRSN REACTION:\r\n             " + strRSN_FT_Rxn.Trim();
                    }
                }
                if (strRSN_FT_Stage.Trim() != "")
                {
                    if (strRSN_FT_Rxn.Trim() == "")
                    {
                        rtxtPartpnts.Text = rtxtPartpnts.Text.Trim() + "\r\n" + strRSN_FT_Stage.Trim();
                    }
                    else
                    {
                        rtxtPartpnts.Text = rtxtPartpnts.Text.Trim() + "\r\n" + strRSN_FT_Stage.Trim();
                    }
                }

                //Replace New line with junk characters before coloring and replace the same with new line after coloring
                rtxtPartpnts.Rtf = rtxtPartpnts.Rtf.Replace("\r\n", "_|0|_");
                ColourRrbText(rtxtPartpnts);
                rtxtPartpnts.Rtf = rtxtPartpnts.Rtf.Replace("_|0|_", "\r\n");
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        string strRSN_CVT_Rxn = "";
        string strRSN_FT_Rxn = "";
        string strRSN_FT_Stage = "";
        private string GetParticipantsFromTable()
        {
            string strPartpnt = "";
            try
            {
                if (PartpntsTbl != null)
                {
                    if (PartpntsTbl.Rows.Count > 0)
                    {
                        for (int i = 0; i < PartpntsTbl.Rows.Count; i++)
                        {
                            if (PartpntsTbl.Rows[i]["Agents"].ToString().Trim() != "" ||
                                PartpntsTbl.Rows[i]["Solvents"].ToString().Trim() != "" ||
                                PartpntsTbl.Rows[i]["Catalysts"].ToString().Trim() != "" ||
                                PartpntsTbl.Rows[i]["Temperature"].ToString().Trim() != "" ||
                                PartpntsTbl.Rows[i]["Time"].ToString().Trim() != "" ||
                                PartpntsTbl.Rows[i]["Pressure"].ToString().Trim() != "" ||
                                PartpntsTbl.Rows[i]["pH"].ToString().Trim() != "")
                            {
                                if (strPartpnt.Trim() == "")
                                {
                                    strPartpnt = PartpntsTbl.Rows[i]["Stage"].ToString() + " - ";
                                }
                                else
                                {
                                    strPartpnt = strPartpnt + "\r\n" + PartpntsTbl.Rows[i]["Stage"].ToString() + " - ";
                                }

                                if (PartpntsTbl.Rows[i]["Agents"].ToString().Trim() != "")
                                {
                                    strPartpnt = strPartpnt.Trim() + "  " + PartpntsTbl.Rows[i]["Agents"].ToString().Trim();
                                }
                                if (PartpntsTbl.Rows[i]["Solvents"].ToString().Trim() != "")
                                {
                                    strPartpnt = strPartpnt.Trim() + "  " + PartpntsTbl.Rows[i]["Solvents"].ToString().Trim();
                                }
                                if (PartpntsTbl.Rows[i]["Catalysts"].ToString().Trim() != "")
                                {
                                    strPartpnt = strPartpnt.Trim() + "  " + PartpntsTbl.Rows[i]["Catalysts"].ToString().Trim();
                                }
                                if (PartpntsTbl.Rows[i]["Temperature"].ToString().Trim() != "")
                                {
                                    strPartpnt = strPartpnt.Trim() + "  " + PartpntsTbl.Rows[i]["Temperature"].ToString().Trim();
                                }
                                if (PartpntsTbl.Rows[i]["Time"].ToString().Trim() != "")
                                {
                                    strPartpnt = strPartpnt.Trim() + "  " + PartpntsTbl.Rows[i]["Time"].ToString().Trim();
                                }
                                if (PartpntsTbl.Rows[i]["Pressure"].ToString().Trim() != "")
                                {
                                    strPartpnt = strPartpnt.Trim() + "  " + PartpntsTbl.Rows[i]["Pressure"].ToString().Trim();
                                }
                                if (PartpntsTbl.Rows[i]["pH"].ToString().Trim() != "")
                                {
                                    strPartpnt = strPartpnt.Trim() + "  " + PartpntsTbl.Rows[i]["pH"].ToString().Trim();
                                }
                            }
                            else//No Agent/Solvent/Catalyst/Conditions are available
                            {
                                if (strPartpnt.Trim() == "")
                                {
                                    strPartpnt = PartpntsTbl.Rows[i]["Stage"].ToString() + " - ";
                                }
                                else
                                {
                                    strPartpnt = strPartpnt + "\r\n" + PartpntsTbl.Rows[i]["Stage"].ToString() + " - ";
                                }

                                strPartpnt = strPartpnt + " No Agent / Catalyst / Solent / Conditions are available";
                            }

                            if (PartpntsTbl.Rows[i]["RSN_CVT"].ToString().Trim() != "")
                            {
                                if (strRSN_CVT_Rxn.Trim() == "")
                                {
                                    strRSN_CVT_Rxn = "CVT: " + PartpntsTbl.Rows[i]["RSN_CVT"].ToString().Trim();
                                }
                                else
                                {
                                    strRSN_CVT_Rxn = strRSN_CVT_Rxn + ", " + PartpntsTbl.Rows[i]["RSN_CVT"].ToString().Trim();
                                }
                            }
                            if (PartpntsTbl.Rows[i]["RSN_FT_Reaction"].ToString().Trim() != "")
                            {
                                if (strRSN_FT_Rxn.Trim() == "")
                                {
                                    strRSN_FT_Rxn = "FREE: " + PartpntsTbl.Rows[i]["RSN_FT_Reaction"].ToString().Trim();
                                }
                                else
                                {
                                    strRSN_FT_Rxn = strRSN_FT_Rxn + ", " + PartpntsTbl.Rows[i]["RSN_FT_Reaction"].ToString().Trim();
                                }
                            }
                            if (PartpntsTbl.Rows[i]["RSN_FT_Stage"].ToString().Trim() != "")
                            {
                                if (strRSN_FT_Stage.Trim() == "")
                                {
                                    strRSN_FT_Stage = "RSN STAGE: " + PartpntsTbl.Rows[i]["RSN_FT_Stage"].ToString().Trim();
                                }
                                else
                                {
                                    strRSN_FT_Stage = strRSN_FT_Stage + ", " + PartpntsTbl.Rows[i]["RSN_FT_Stage"].ToString().Trim();
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strPartpnt;
        }

        private int GetPanelControlsLength(DataTable dt_prod_react, string _srcgrid)
        {
            int intLen = 0;
            try
            {
                if (dt_prod_react != null)
                {
                    if (dt_prod_react.Rows.Count > 0)
                    {
                        DataTable dtCgm = GlobalVariables.CGMTbl_ForRxns.Copy();// CGMDataTbl.Copy();

                        for (int i = 0; i < dt_prod_react.Rows.Count; i++)
                        {
                            int intRegNo = Convert.ToInt32(dt_prod_react.Rows[i]["nrnreg"].ToString());
                            if (intRegNo > 0)
                            {
                                string strFCond = "<SUBSTANC><RN ID=" + "\"" + intRegNo + "\"" + ">*";
                                try
                                {
                                    DataTable dtoutput = dtCgm.AsEnumerable().Where(a => Regex.IsMatch(a[dtCgm.Columns[0].ColumnName].ToString(), strFCond)).CopyToDataTable();
                                    if (dtoutput != null)
                                    {
                                        if (dtoutput.Rows.Count > 0)
                                        {
                                            string cellValue = dtoutput.Rows[0][0].ToString();
                                            if (cellValue.Contains("<SIM>"))//Single structure
                                            {
                                                if (_srcgrid.ToUpper() == "REACTANT")
                                                {
                                                    intLen = intLen + 2;
                                                }
                                                else
                                                {
                                                    intLen = intLen + 1;
                                                }
                                            }
                                            else if (cellValue.Contains("<CSIM>"))//Multiple strucrures
                                            {
                                                string[] splitter = { "<CSIM>" };
                                                string[] strVals = cellValue.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                                                if (strVals != null)
                                                {
                                                    if (strVals.Length > 0)
                                                    {
                                                        //if (i == 0 && dt_prod_react.Rows.Count >= 1)
                                                        //{
                                                        //    intLen = intLen + strVals.Length;
                                                        //}
                                                        //else
                                                        //{
                                                            if (_srcgrid.ToUpper() == "REACTANT")
                                                            {
                                                                intLen = intLen + strVals.Length;
                                                            }
                                                            else
                                                            {
                                                                intLen = intLen + (strVals.Length - 1);
                                                            }
                                                        //}
                                                    }
                                                }
                                            }
                                            else //No Structure
                                            {
                                                if (_srcgrid.ToUpper() == "REACTANT")
                                                {
                                                    intLen = intLen + 2;
                                                }
                                                else
                                                {
                                                    intLen = intLen + 1;
                                                }
                                            }
                                        }
                                    }
                                }
                                catch//Exception for 8500 
                                {
                                    intLen = intLen + 2;
                                }
                            }
                            else// 8000 series Product
                            {
                                if (_srcgrid.ToUpper() == "PRODUCT")
                                {
                                    intLen = intLen + 1;
                                }
                                else if (_srcgrid.ToUpper() == "REACTANT")
                                {
                                    intLen = intLen + 2;
                                }
                            }
                        }
                        if (_srcgrid.ToUpper() == "PRODUCT" && dt_prod_react.Rows.Count > 1)
                        {
                            intLen = intLen + 1;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return intLen;
        }

        private string[] GetHexCodeOnRegNo(int _regno)
        {
            string[] strHexArr = null;
            try
            {
                if (GlobalVariables.CGMTbl_ForRxns != null)
                {
                    if (GlobalVariables.CGMTbl_ForRxns.Rows.Count > 0)
                    {
                        DataTable dtcdm = GlobalVariables.CGMTbl_ForRxns.Copy();// CGMDataTbl.Copy();
                        DataTable dt = new DataTable();

                        string strFCond = "<SUBSTANC><RN ID=" + "\"" + _regno + "\"" + ">*";
                        try
                        {
                            DataTable dtoutput = dtcdm.AsEnumerable().Where(a => Regex.IsMatch(a[dtcdm.Columns[0].ColumnName].ToString(), strFCond)).CopyToDataTable();
                            if (dtoutput != null)
                            {
                                if (dtoutput.Rows.Count > 0)
                                {
                                    string cellValue = dtoutput.Rows[0][0].ToString();
                                    if (cellValue.Contains("<SIM>"))//Single structure
                                    {
                                        string strSIM = cellValue.Substring(cellValue.IndexOf("<SIM>") + ("<SIM>".Length), ((cellValue.IndexOf("</SIM>") + 1) - cellValue.IndexOf("<SIM>")) - ("</SIM>".Length));
                                        strHexArr = new string[1];
                                        strHexArr[0] = strSIM;
                                        return strHexArr;
                                    }
                                    else if (cellValue.Contains("<CSIM>"))//Multiple strucrures
                                    {
                                        string[] splitter = { "<CSIM>" };
                                        string[] strValues = cellValue.Split(splitter,StringSplitOptions.RemoveEmptyEntries);

                                        ArrayList alstVals = new ArrayList();
                                        if (strValues != null)
                                        {
                                            if (strValues.Length > 0)
                                            {
                                                string[] splitter_End = { "</CSIM>" }; 
                                                for (int i = 0; i < strValues.Length; i++)
                                                {
                                                    if (!strValues[i].StartsWith("<SUBSTANC"))
                                                    {
                                                        string[] strValues_Hex = strValues[i].Split(splitter_End, StringSplitOptions.RemoveEmptyEntries);
                                                        if (strValues_Hex != null)
                                                        {
                                                            if (strValues_Hex.Length > 0)
                                                            {
                                                                alstVals.Add(strValues_Hex[0]);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        if (alstVals != null)
                                        {
                                            if (alstVals.Count > 0)
                                            {
                                                strHexArr = (String[])alstVals.ToArray(typeof(string));
                                            }
                                        }
                                        
                                        //object[] objArr = new object[1];
                                        //string strXml = @"<?xml version=""1.0"" encoding=""UTF-8""?>";
                                        //cellValue = strXml + "\r\n" + cellValue;
                                        //objArr[0] = cellValue;

                                        //XmlDocument xDoc = new XmlDocument();
                                        //xDoc.LoadXml(cellValue);

                                        //XmlNodeList xNdLst = xDoc.SelectNodes("SUBSTANC/COMP/CSIM");
                                        //if (xNdLst.Count > 0)
                                        //{
                                        //    strHexArr = new string[xNdLst.Count];
                                        //    for (int i = 0; i < xNdLst.Count; i++)
                                        //    {
                                        //        strHexArr[i] = xNdLst[i].InnerText;
                                        //    }
                                        //}
                                    }
                                }
                            }
                        }
                        catch //Exception for series 8500 RegNos
                        {

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strHexArr;
        }
              
        private void ColourRrbText(RichTextBox rtb)
        {
            try
            {
                Regex regEx_Stg = new Regex("Stage [0-9]{0,3}");
                foreach (Match match in regEx_Stg.Matches(rtb.Text))
                {
                    rtb.Select(match.Index, match.Length);
                    rtb.SelectionColor = Color.DarkOrange;
                }

                Regex regEx_Empty = new Regex("No Agent / Catalyst / Solent / Conditions are available");
                foreach (Match match in regEx_Empty.Matches(rtb.Text))
                {
                    rtb.Select(match.Index, match.Length);
                    rtb.SelectionColor = Color.LightGray;
                }

                Regex regEx_C = new Regex("TP:|TM:|PR:|PH:");
                foreach (Match match in regEx_C.Matches(rtb.Text))
                {
                    rtb.Select(match.Index, match.Length);
                    rtb.SelectionColor = Color.Red;
                }

                Regex regEx_P = new Regex("AGENT|SOLVENT|CATALYST");
                foreach (Match match in regEx_P.Matches(rtb.Text))
                {
                    rtb.Select(match.Index, match.Length);
                    rtb.SelectionColor = Color.LimeGreen;
                }

                Regex regEx_R = new Regex("RSN REACTION|RSN STAGE");
                foreach (Match match in regEx_R.Matches(rtb.Text))
                {
                    rtb.Select(match.Index, match.Length);
                    rtb.SelectionColor = Color.DarkViolet;
                }                

                Regex regEx_CVT = new Regex("CVT|FREE");
                foreach (Match match in regEx_CVT.Matches(rtb.Text))
                {
                    rtb.Select(match.Index, match.Length);
                    rtb.SelectionColor = Color.DeepPink;
                }              
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        frmReactCuration objRxnForm = null;
        private void lnkEdit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(lblSno.Text.Trim()))
                {
                    frmGetAllRxns objAllRxns = (frmGetAllRxns)this.Parent.Parent.Parent;
                    if (objAllRxns != null)
                    {
                        objAllRxns.NUM_ScrollPos = objAllRxns.tlpnl_AllRxns.VerticalScroll.Value;
                    }

                    int intRxnSNo = Convert.ToInt32(lblSnoVal.Text.Trim());
                    if (intRxnSNo > 0)
                    {
                        objRxnForm = null;
                        FormCollection collForms = Application.OpenForms;
                        foreach (Form frmChk in collForms)
                        {
                            if (frmChk.Name.ToUpper() == "FRMRXNENTRYSCREEN")
                            {
                                objRxnForm = (frmReactCuration)frmChk;
                            }
                        }
                        if (objRxnForm != null)
                        {
                            objRxnForm.BringToFront();
                            objRxnForm.numGotoRecord.Value = intRxnSNo;
                        }
                        else
                        {
                            MessageBox.Show("Reactions form is not in open state", "Go to Reaction", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        frmGetAllRxns objAllRxns = null;
        private void pnlNUM_Click(object sender, EventArgs e)
        {
            try
            {
                objAllRxns = (frmGetAllRxns)this.Parent.Parent.Parent;
                if (objAllRxns != null)
                {
                    objAllRxns.tlpnl_AllRxns.HorizontalScroll.Enabled = false;
                    objAllRxns.tlpnl_AllRxns.HorizontalScroll.Visible = false;
                    objAllRxns.tlpnl_AllRxns.AutoScroll = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnPdf_Click(object sender, EventArgs e)
        {
            //ExportReactionsToPDF("F:\\ReactionExport.pdf");
        }

        private void ExportReactionsToPDF(string _filepath)
        {
            try
            {
                iTextSharp.text.Document doc = new iTextSharp.text.Document();
                iTextSharp.text.pdf.PdfWriter.GetInstance(doc, new FileStream(_filepath, FileMode.Create));
                doc.Open();

                for (int i = 0; i < tlpnlProd.ColumnCount; i++)
                {
                    iTextSharp.text.Image chemimg = null;
                    iTextSharp.text.Paragraph paragraph;

                    Control cntrl = tlpnlProd.GetControlFromPosition(i, 0);
                    if (cntrl != null)
                    {
                        try
                        {
                            ucProd_Reactant objChem = cntrl as ucProd_Reactant;                            
                            if (objChem != null)
                            {
                                Image img = null;
                                try
                                {
                                    //img = objChem.pbChemImg.Image;

                                    if (!string.IsNullOrEmpty(objChem.ChemHexCode))
                                    {
                                        chemimg = HexCodeToStructureImage.GetITextImageOnHexCode(objChem.ChemHexCode, "123");//iTextSharp.text.Image.GetInstance(img, System.Drawing.Imaging.ImageFormat.Emf);
                                    }
                                    else
                                    {
                                        chemimg = iTextSharp.text.Image.GetInstance(objChem.ChemImage, System.Drawing.Imaging.ImageFormat.Jpeg);
                                    }
                                    chemimg.ScaleToFit(100f, 100f);
                                    chemimg.ScaleAbsolute((float)100f, (float)100f);
                                    chemimg.Alignment = iTextSharp.text.Image.TEXTWRAP | iTextSharp.text.Image.ALIGN_JUSTIFIED_ALL;
                                   
                                    //chemimg.IndentationLeft = 9f;
                                    //chemimg.SpacingAfter = 20f;
                                    //chemimg.SpacingBefore = 15f;
                                    
                                    chemimg.Border = iTextSharp.text.Rectangle.BOX;
                                    chemimg.BorderColor = iTextSharp.text.BaseColor.BLACK;
                                    chemimg.BorderWidth = 1f;
                                    chemimg.SpacingAfter = 8f;
                                    chemimg.SpacingBefore = 8f;
                                                                                                            
                                    //Give some space after the image 
                                    //chemimg.SpacingAfter = 1f;
                                    //chemimg.Alignment = iTextSharp.text.Image.ALIGN_JUSTIFIED_ALL;

                                    doc.Add(chemimg);
                                }
                                catch
                                {
                                    #region MyRegion
                                    //img = objChem.pbChemImg.Image;
                                    //chemimg = iTextSharp.text.Image.GetInstance(img, System.Drawing.Imaging.ImageFormat.Bmp);
                                    //chemimg.ScaleToFit(250f, 250f);
                                    //chemimg.Alignment = iTextSharp.text.Image.TEXTWRAP | iTextSharp.text.Image.ALIGN_RIGHT;
                                    //chemimg.IndentationLeft = 9f;
                                    //chemimg.SpacingAfter = 9f;
                                    //chemimg.BorderWidthTop = 36f;
                                    //chemimg.BorderColorTop = iTextSharp.text.Color.WHITE;
                                    //doc.Add(chemimg); 
                                    #endregion
                                }
                            }
                        }
                        catch
                        {
                            
                        }

                        try
                        {
                            ucPlus objPlus = cntrl as ucPlus;
                            if (objPlus != null)
                            {
                                System.Drawing.Image image = System.Drawing.Image.FromFile(@"F:\Project BackUps\CASREACT\Version2.0\11May2011_BeforePTT\CASRxnTool\CASRxnTool\bin\Debug\AddRCT1.png");
                                iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(image, System.Drawing.Imaging.ImageFormat.Jpeg);
                                jpg.Alignment = iTextSharp.text.Image.TEXTWRAP | iTextSharp.text.Image.ALIGN_JUSTIFIED_ALL;
                                jpg.ScaleToFit(15f, 100f);
                                jpg.ScaleAbsolute(15f, 100f);
                                //chemimg.IndentationLeft = 9f;
                                jpg.SpacingAfter = 8f;
                                jpg.SpacingBefore = 8f;

                                doc.Add(jpg);
                                //paragraph = new iTextSharp.text.Paragraph("+");
                               
                                //paragraph.Alignment = iTextSharp.text.Element.ALIGN_JUSTIFIED;
                                //doc.Add(paragraph);
                            }
                        }
                        catch
                        {

                        }

                        try
                        {
                            ucArrow objArrow = cntrl as ucArrow;
                            if (objArrow != null)
                            {
                                //paragraph = new iTextSharp.text.Paragraph("==>");
                                ////paragraph.Alignment = iTextSharp.text.Element.ALIGN_JUSTIFIED;
                                //doc.Add(paragraph);

                                System.Drawing.Image image = System.Drawing.Image.FromFile(@"F:\Project BackUps\CASREACT\Version2.0\11May2011_BeforePTT\CASRxnTool\CASRxnTool\bin\Debug\RedArrow.jpg");
                                iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(image, System.Drawing.Imaging.ImageFormat.Jpeg);
                                jpg.Alignment = iTextSharp.text.Image.TEXTWRAP | iTextSharp.text.Image.JPEG;
                                jpg.ScaleToFit(15f, 100f);
                                jpg.ScaleAbsolute(15f, 100f);
                                //chemimg.IndentationLeft = 9f;
                                jpg.SpacingAfter = 8f;
                                jpg.SpacingBefore = 8f;

                                doc.Add(jpg);
                            }
                        }
                        catch
                        {

                        }

                        #region MyRegion
                        //iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(imagepath + "/Sunset.jpg");
                        //iTextSharp.text.Paragraph paragraph = new iTextSharp.text.Paragraph(@"Test 123456");
                        //paragraph.Alignment = iTextSharp.text.Element.ALIGN_JUSTIFIED;
                        //if (jpg != null)
                        //{
                        //    //jpg.ScaleToFit(250f, 250f);
                        //    jpg.Alignment = iTextSharp.text.Image.TEXTWRAP | iTextSharp.text.Image.ALIGN_RIGHT;
                        //    jpg.IndentationLeft = 9f;
                        //    jpg.SpacingAfter = 9f;
                        //    jpg.BorderWidthTop = 36f;
                        //    jpg.BorderColorTop = iTextSharp.text.Color.WHITE;
                        //    doc.Add(jpg);
                        //}
                        //doc.Add(paragraph); 
                        #endregion
                    }
                }

                //Write Stages information
                //iTextSharp.text.Paragraph prgStageInfo = new iTextSharp.text.Paragraph(rtxtPartpnts.Rtf);
                //paragraph.Alignment = iTextSharp.text.Element.ALIGN_JUSTIFIED;
                //markupConverter.ConvertRtfToHtml(rtxtPartpnts.Rtf);

                //iTextSharp.text.html.simpleparser.StyleSheet styles = new iTextSharp.text.html.simpleparser.StyleSheet();

                doc.Add(iTextSharp.text.Chunk.NEWLINE);
                doc.Add(iTextSharp.text.Chunk.NEWLINE);
                doc.Add(iTextSharp.text.Chunk.NEWLINE);
                doc.Add(iTextSharp.text.Chunk.NEWLINE);
                doc.Add(iTextSharp.text.Chunk.NEWLINE);
                doc.Add(iTextSharp.text.Chunk.NEWLINE);
                doc.Add(iTextSharp.text.Chunk.NEWLINE);
                doc.Add(iTextSharp.text.Chunk.NEWLINE);

                //Cell cell = new Cell();
                //cell.AddElement(new Chunk(Image.GetInstance(IMAGE1_PATH), 0, 0));
                //cell.AddElement(new Chunk(Image.GetInstance(IMAGE2_PATH), 0, 0));
                //table.AddCell(cell);

                iTextSharp.text.html.simpleparser.HTMLWorker hw = new iTextSharp.text.html.simpleparser.HTMLWorker(doc);
                //hw.Parse(new StringReader("<DIV STYLE=\"text-align:Left;font-family:Tahoma;font-style:normal;font-weight:normal;font-size:6;color:#000000;\"><P STYLE=\"font-family:Times New Roman;font-size:5;margin:0 0 0 0;\"><SPAN STYLE=\"color:#FF8C00;\"><SPAN>Stage 1</SPAN></SPAN><SPAN STYLE=\"color:#0000FF;\"><SPAN> -  </SPAN></SPAN><SPAN STYLE=\"color:#32CD32;\"><SPAN>AGENT</SPAN></SPAN><SPAN STYLE=\"color:#0000FF;\"><SPAN>= Hydrochloric acid (Gas)  </SPAN></SPAN><SPAN STYLE=\"color:#32CD32;\"><SPAN>SOLVENT</SPAN></SPAN><SPAN STYLE=\"color:#0000FF;\"><SPAN>= Methanol  </SPAN></SPAN><SPAN STYLE=\"color:#FF0000;\"><SPAN>TP:</SPAN></SPAN><SPAN STYLE=\"color:#0000FF;\"><SPAN> a,a  </SPAN></SPAN><SPAN STYLE=\"color:#FF0000;\"><SPAN>TM:</SPAN></SPAN><SPAN STYLE=\"color:#0000FF;\"><SPAN> 25m,3</SPAN></SPAN></P><P STYLE=\"font-family:Times New Roman;font-size:5;margin:0 0 0 0;\"><SPAN STYLE=\"color:#FF8C00;\"><SPAN>Stage 2</SPAN></SPAN><SPAN STYLE=\"color:#0000FF;\"><SPAN> -  </SPAN></SPAN><SPAN STYLE=\"color:#32CD32;\"><SPAN>AGENT</SPAN></SPAN><SPAN STYLE=\"color:#0000FF;\"><SPAN>= NaHCO3 (Solid)  </SPAN></SPAN><SPAN STYLE=\"color:#32CD32;\"><SPAN>SOLVENT</SPAN></SPAN><SPAN STYLE=\"color:#0000FF;\"><SPAN>= Water  </SPAN></SPAN><SPAN STYLE=\"color:#FF0000;\"><SPAN>PH:</SPAN></SPAN><SPAN STYLE=\"color:#0000FF;\"><SPAN> 8-9</SPAN></SPAN></P><P STYLE=\"font-family:Times New Roman;font-size:5;margin:0 0 0 0;\"><SPAN STYLE=\"color:#9400D3;\"><SPAN>RSN STAGE</SPAN></SPAN><SPAN STYLE=\"color:#0000FF;\"><SPAN>: HCl gas used (stage 1)</SPAN></SPAN></P><P /></DIV>"));
                hw.Parse(new StringReader(markupConverter.ConvertRtfToHtml(rtxtPartpnts.Rtf)));
                
                //doc.Add(new iTextSharp.text.Paragraph(rtxtPartpnts.Rtf));
                doc.Close();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
