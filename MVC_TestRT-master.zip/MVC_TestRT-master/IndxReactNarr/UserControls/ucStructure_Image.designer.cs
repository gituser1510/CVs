﻿namespace IndxReactNarr
{
    partial class ucStructure_Image
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbChemImg = new System.Windows.Forms.PictureBox();
            this.lblStereoChem = new System.Windows.Forms.Label();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.lblMolFormula = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbChemImg)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pbChemImg
            // 
            this.pbChemImg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbChemImg.Location = new System.Drawing.Point(0, 21);
            this.pbChemImg.Name = "pbChemImg";
            this.pbChemImg.Size = new System.Drawing.Size(352, 225);
            this.pbChemImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbChemImg.TabIndex = 0;
            this.pbChemImg.TabStop = false;
            // 
            // lblStereoChem
            // 
            this.lblStereoChem.AutoSize = true;
            this.lblStereoChem.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblStereoChem.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStereoChem.Location = new System.Drawing.Point(0, 0);
            this.lblStereoChem.Name = "lblStereoChem";
            this.lblStereoChem.Size = new System.Drawing.Size(42, 17);
            this.lblStereoChem.TabIndex = 1;
            this.lblStereoChem.Text = "label1";
            // 
            // pnlTop
            // 
            this.pnlTop.Controls.Add(this.lblMolFormula);
            this.pnlTop.Controls.Add(this.lblStereoChem);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(352, 21);
            this.pnlTop.TabIndex = 2;
            // 
            // lblMolFormula
            // 
            this.lblMolFormula.AutoSize = true;
            this.lblMolFormula.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblMolFormula.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMolFormula.Location = new System.Drawing.Point(310, 0);
            this.lblMolFormula.Name = "lblMolFormula";
            this.lblMolFormula.Size = new System.Drawing.Size(42, 17);
            this.lblMolFormula.TabIndex = 2;
            this.lblMolFormula.Text = "label1";
            // 
            // ucStructure_Image
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pbChemImg);
            this.Controls.Add(this.pnlTop);
            this.Name = "ucStructure_Image";
            this.Size = new System.Drawing.Size(352, 246);
            ((System.ComponentModel.ISupportInitialize)(this.pbChemImg)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbChemImg;
        private System.Windows.Forms.Label lblStereoChem;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Label lblMolFormula;
    }
}
