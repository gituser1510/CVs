﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;

namespace IndxReactNarr.UserControls
{
    public partial class ucRxnFinding : UserControl
    {
        public ucRxnFinding()
        {
            InitializeComponent();

            this.cmbFindingType.MouseWheel += new MouseEventHandler(ComboBox_MouseWheel);
            this.cmbFindingRefCompound.MouseWheel += new MouseEventHandler(ComboBox_MouseWheel);
            this.cmbFindingMaterials.MouseWheel += new MouseEventHandler(ComboBox_MouseWheel);
        }

        #region Public Properties
        
        public DataTable RxnSubstances { get; set; }
        public string FindingValue { get; set; }
        public string FindingTypeRefSubst { get; set; }
        public string SeltdFindingType { get; set; } 
        
        #endregion

        public void BindFindingTypesAndSubstancesToControls()
        {
            try
            {
                if (RxnSubstances != null)
                {
                    cmbFindingRefCompound.DataSource = RxnSubstances;
                    cmbFindingRefCompound.DisplayMember = "SUBST_IDENTIFIER";
                    cmbFindingRefCompound.ValueMember = "SUBST_IDENTIFIER";
                }

                if (GlobalVariables.FindingTypesData != null)
                {
                    cmbFindingType.DataSource = GlobalVariables.FindingTypesData.Copy();
                    cmbFindingType.DisplayMember = "FINDING_TYPE_NAME";
                    cmbFindingType.ValueMember = "FINDING_TYPE_NAME";
                }                
               
                //Finding Type reference compound
                if (!string.IsNullOrEmpty(FindingTypeRefSubst))
                {
                    cmbFindingRefCompound.Text = FindingTypeRefSubst;
                }
                else
                {
                    cmbFindingRefCompound.SelectedIndex = RxnSubstances.Rows.Count == 1 ? 0 : -1;
                }

                //Selected findingtype
                cmbFindingType.Text = SeltdFindingType;

                //Bind Finding value to control

                if (!string.IsNullOrEmpty(SeltdFindingType) && SeltdFindingType.ToUpper() == "EQUIPMENT/MATERIALS")
                {
                    uchrtbFindingData.hrtbPara.Clear();
                    uchrtbFindingData.Visible = false;
                    cmbFindingMaterials.Visible = true;

                    BindEquipment_ScaleMasterData("EQUIPMENT/MATERIALS");

                    cmbFindingMaterials.Text = FindingValue;
                }
                else if (!string.IsNullOrEmpty(SeltdFindingType) && SeltdFindingType.ToUpper() == "SCALE")
                {
                    uchrtbFindingData.hrtbPara.Clear();
                    uchrtbFindingData.Visible = false;
                    cmbFindingMaterials.Visible = true;

                    BindEquipment_ScaleMasterData("SCALE");

                    cmbFindingMaterials.Text = FindingValue;
                }
                else
                {
                    uchrtbFindingData.hrtbPara.Clear();
                    uchrtbFindingData.Visible = true;
                    cmbFindingMaterials.Visible = false;

                    uchrtbFindingData.BindDataToControl(FindingValue);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindEquipment_ScaleMasterData(string findingType)
        {
            try
            {
                cmbFindingMaterials.DataSource = null;
                if (findingType.ToUpper() == "EQUIPMENT/MATERIALS")
                {
                    cmbFindingMaterials.DataSource = GlobalVariables.MaterialsData;
                    cmbFindingMaterials.DisplayMember = "MATERIAL_NAME";
                    cmbFindingMaterials.ValueMember = "MATERIAL_NAME";
                }
                else if (findingType.ToUpper() == "SCALE")
                {
                    List<string> lstScale = new List<string>();
                    lstScale.Add("milligram");
                    lstScale.Add("gram");
                    lstScale.Add("kilogram");
                    cmbFindingMaterials.DataSource = lstScale;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
              
                
        private void cmbFindingType_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbFindingType.SelectedItem != null)
                {
                    if (cmbFindingType.SelectedValue.ToString().ToUpper() == "EQUIPMENT/MATERIALS")
                    {
                        uchrtbFindingData.hrtbPara.Clear();
                        uchrtbFindingData.Visible = false;
                        cmbFindingMaterials.Visible = true;

                        cmbFindingRefCompound.SelectedIndex = -1;
                        cmbFindingRefCompound.Enabled = false;

                        BindEquipment_ScaleMasterData("EQUIPMENT/MATERIALS");
                    }
                    else if (cmbFindingType.SelectedValue.ToString().ToUpper() == "SCALE")
                    {
                        uchrtbFindingData.hrtbPara.Clear();
                        uchrtbFindingData.Visible = false;
                        cmbFindingMaterials.Visible = true;

                        cmbFindingRefCompound.SelectedIndex = -1;
                        cmbFindingRefCompound.Enabled = false;

                        BindEquipment_ScaleMasterData("SCALE");
                    }
                    else if (cmbFindingType.SelectedValue.ToString().ToUpper() == "SAFETY")
                    {
                        uchrtbFindingData.hrtbPara.Clear();
                        uchrtbFindingData.Visible = true;
                        cmbFindingMaterials.Visible = false;

                        cmbFindingRefCompound.SelectedIndex = -1;
                        cmbFindingRefCompound.Enabled = false;
                    }
                    else
                    {
                        uchrtbFindingData.Visible = true;
                        cmbFindingMaterials.Visible = false;
                        cmbFindingMaterials.DataSource = null;

                        cmbFindingRefCompound.Enabled = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        void ComboBox_MouseWheel(object sender, MouseEventArgs e)
        {
            try
            {
                ((HandledMouseEventArgs)e).Handled = true;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
