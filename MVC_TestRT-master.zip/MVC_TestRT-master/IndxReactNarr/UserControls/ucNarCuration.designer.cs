﻿namespace IndxReactNarr
{
    partial class ucNarCuration
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucNarCuration));
            this.pnlMain = new System.Windows.Forms.Panel();
            this.rbnMissingRxn = new System.Windows.Forms.RadioButton();
            this.rbnExpProcedure = new System.Windows.Forms.RadioButton();
            this.rbnAnalogousTo = new System.Windows.Forms.RadioButton();
            this.rbnNoExpDetails = new System.Windows.Forms.RadioButton();
            this.rbnGeneralTypical = new System.Windows.Forms.RadioButton();
            this.ucHrtbTextLine = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.pnlNumInfo = new System.Windows.Forms.Panel();
            this.txtDocRefFileName = new System.Windows.Forms.TextBox();
            this.lblSeq = new System.Windows.Forms.Label();
            this.lblreactioncasreactonnumber = new System.Windows.Forms.Label();
            this.txtRxnNum = new System.Windows.Forms.TextBox();
            this.lblPageNumber = new System.Windows.Forms.Label();
            this.txtDocRef = new System.Windows.Forms.TextBox();
            this.txtPageNo = new System.Windows.Forms.TextBox();
            this.lblpglabel = new System.Windows.Forms.Label();
            this.txtRxnSeq = new System.Windows.Forms.TextBox();
            this.txtPageLabel = new System.Windows.Forms.TextBox();
            this.txtOffset_Y = new System.Windows.Forms.TextBox();
            this.lbldocref = new System.Windows.Forms.Label();
            this.lblYoffSet = new System.Windows.Forms.Label();
            this.txtOffset_X = new System.Windows.Forms.TextBox();
            this.lblfilename = new System.Windows.Forms.Label();
            this.lblXoffSet = new System.Windows.Forms.Label();
            this.lblXPageSize = new System.Windows.Forms.Label();
            this.lblYPageSize = new System.Windows.Forms.Label();
            this.txtPageSize_Y = new System.Windows.Forms.TextBox();
            this.txtPageSize_X = new System.Windows.Forms.TextBox();
            this.lblTextLine = new System.Windows.Forms.Label();
            this.cmbAnalogousTo = new System.Windows.Forms.ComboBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.splCntparaData = new System.Windows.Forms.SplitContainer();
            this.flPnlPara = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlParaHdr = new System.Windows.Forms.Panel();
            this.tsPara = new System.Windows.Forms.ToolStrip();
            this.tsbtnDeletePara = new System.Windows.Forms.ToolStripButton();
            this.lblParaCnt = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lnkAddPara = new System.Windows.Forms.LinkLabel();
            this.splDataData2 = new System.Windows.Forms.SplitContainer();
            this.flPnlData = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlDataHdr = new System.Windows.Forms.Panel();
            this.tsData = new System.Windows.Forms.ToolStrip();
            this.tsbtnDeleteData = new System.Windows.Forms.ToolStripButton();
            this.lblDataCnt = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lnkData = new System.Windows.Forms.LinkLabel();
            this.lblData2 = new System.Windows.Forms.Label();
            this.rtxtdata1 = new HtmlRichText.HtmlRichTextBox();
            this.txtNarrID = new System.Windows.Forms.TextBox();
            this.lblNarId = new System.Windows.Forms.Label();
            this.tb1rtxteditor = new onlyconnect.HtmlEditor();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.copyXYOffsetsTSMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.pnlMain.SuspendLayout();
            this.pnlNumInfo.SuspendLayout();
            this.splCntparaData.Panel1.SuspendLayout();
            this.splCntparaData.Panel2.SuspendLayout();
            this.splCntparaData.SuspendLayout();
            this.pnlParaHdr.SuspendLayout();
            this.tsPara.SuspendLayout();
            this.splDataData2.Panel1.SuspendLayout();
            this.splDataData2.Panel2.SuspendLayout();
            this.splDataData2.SuspendLayout();
            this.pnlDataHdr.SuspendLayout();
            this.tsData.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.rbnMissingRxn);
            this.pnlMain.Controls.Add(this.rbnExpProcedure);
            this.pnlMain.Controls.Add(this.rbnAnalogousTo);
            this.pnlMain.Controls.Add(this.rbnNoExpDetails);
            this.pnlMain.Controls.Add(this.rbnGeneralTypical);
            this.pnlMain.Controls.Add(this.ucHrtbTextLine);
            this.pnlMain.Controls.Add(this.pnlNumInfo);
            this.pnlMain.Controls.Add(this.lblTextLine);
            this.pnlMain.Controls.Add(this.cmbAnalogousTo);
            this.pnlMain.Controls.Add(this.btnDelete);
            this.pnlMain.Controls.Add(this.splCntparaData);
            this.pnlMain.Controls.Add(this.txtNarrID);
            this.pnlMain.Controls.Add(this.lblNarId);
            this.pnlMain.Controls.Add(this.tb1rtxteditor);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1027, 430);
            this.pnlMain.TabIndex = 0;
            // 
            // rbnMissingRxn
            // 
            this.rbnMissingRxn.AutoSize = true;
            this.rbnMissingRxn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnMissingRxn.Location = new System.Drawing.Point(857, 35);
            this.rbnMissingRxn.Name = "rbnMissingRxn";
            this.rbnMissingRxn.Size = new System.Drawing.Size(126, 20);
            this.rbnMissingRxn.TabIndex = 12;
            this.rbnMissingRxn.Text = "Missing Reaction";
            this.rbnMissingRxn.UseVisualStyleBackColor = true;
            this.rbnMissingRxn.CheckedChanged += new System.EventHandler(this.rbnMissingRxn_CheckedChanged);
            // 
            // rbnExpProcedure
            // 
            this.rbnExpProcedure.AutoSize = true;
            this.rbnExpProcedure.Checked = true;
            this.rbnExpProcedure.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnExpProcedure.Location = new System.Drawing.Point(365, 35);
            this.rbnExpProcedure.Name = "rbnExpProcedure";
            this.rbnExpProcedure.Size = new System.Drawing.Size(165, 20);
            this.rbnExpProcedure.TabIndex = 9;
            this.rbnExpProcedure.TabStop = true;
            this.rbnExpProcedure.Text = "Experimental Procedure";
            this.rbnExpProcedure.UseVisualStyleBackColor = true;
            // 
            // rbnAnalogousTo
            // 
            this.rbnAnalogousTo.AutoSize = true;
            this.rbnAnalogousTo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnAnalogousTo.Location = new System.Drawing.Point(136, 35);
            this.rbnAnalogousTo.Name = "rbnAnalogousTo";
            this.rbnAnalogousTo.Size = new System.Drawing.Size(104, 20);
            this.rbnAnalogousTo.TabIndex = 8;
            this.rbnAnalogousTo.Text = "Analogous To";
            this.rbnAnalogousTo.UseVisualStyleBackColor = true;
            this.rbnAnalogousTo.CheckedChanged += new System.EventHandler(this.rbnAnalogousTo_CheckedChanged);
            // 
            // rbnNoExpDetails
            // 
            this.rbnNoExpDetails.AutoSize = true;
            this.rbnNoExpDetails.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnNoExpDetails.Location = new System.Drawing.Point(671, 35);
            this.rbnNoExpDetails.Name = "rbnNoExpDetails";
            this.rbnNoExpDetails.Size = new System.Drawing.Size(166, 20);
            this.rbnNoExpDetails.TabIndex = 11;
            this.rbnNoExpDetails.Text = "No Experimental Details";
            this.rbnNoExpDetails.UseVisualStyleBackColor = true;
            // 
            // rbnGeneralTypical
            // 
            this.rbnGeneralTypical.AutoSize = true;
            this.rbnGeneralTypical.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnGeneralTypical.Location = new System.Drawing.Point(536, 35);
            this.rbnGeneralTypical.Name = "rbnGeneralTypical";
            this.rbnGeneralTypical.Size = new System.Drawing.Size(115, 20);
            this.rbnGeneralTypical.TabIndex = 10;
            this.rbnGeneralTypical.Text = "General Typical";
            this.rbnGeneralTypical.UseVisualStyleBackColor = true;
            this.rbnGeneralTypical.CheckedChanged += new System.EventHandler(this.rbnGeneralTypical_CheckedChanged);
            // 
            // ucHrtbTextLine
            // 
            this.ucHrtbTextLine.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ucHrtbTextLine.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ucHrtbTextLine.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ucHrtbTextLine.Location = new System.Drawing.Point(56, 61);
            this.ucHrtbTextLine.Name = "ucHrtbTextLine";
            this.ucHrtbTextLine.Size = new System.Drawing.Size(967, 51);
            this.ucHrtbTextLine.TabIndex = 13;
            // 
            // pnlNumInfo
            // 
            this.pnlNumInfo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlNumInfo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlNumInfo.Controls.Add(this.txtDocRefFileName);
            this.pnlNumInfo.Controls.Add(this.lblSeq);
            this.pnlNumInfo.Controls.Add(this.lblreactioncasreactonnumber);
            this.pnlNumInfo.Controls.Add(this.txtRxnNum);
            this.pnlNumInfo.Controls.Add(this.lblPageNumber);
            this.pnlNumInfo.Controls.Add(this.txtDocRef);
            this.pnlNumInfo.Controls.Add(this.txtPageNo);
            this.pnlNumInfo.Controls.Add(this.lblpglabel);
            this.pnlNumInfo.Controls.Add(this.txtRxnSeq);
            this.pnlNumInfo.Controls.Add(this.txtPageLabel);
            this.pnlNumInfo.Controls.Add(this.txtOffset_Y);
            this.pnlNumInfo.Controls.Add(this.lbldocref);
            this.pnlNumInfo.Controls.Add(this.lblYoffSet);
            this.pnlNumInfo.Controls.Add(this.txtOffset_X);
            this.pnlNumInfo.Controls.Add(this.lblfilename);
            this.pnlNumInfo.Controls.Add(this.lblXoffSet);
            this.pnlNumInfo.Controls.Add(this.lblXPageSize);
            this.pnlNumInfo.Controls.Add(this.lblYPageSize);
            this.pnlNumInfo.Controls.Add(this.txtPageSize_Y);
            this.pnlNumInfo.Controls.Add(this.txtPageSize_X);
            this.pnlNumInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlNumInfo.Location = new System.Drawing.Point(0, 0);
            this.pnlNumInfo.Name = "pnlNumInfo";
            this.pnlNumInfo.Size = new System.Drawing.Size(1027, 30);
            this.pnlNumInfo.TabIndex = 201;
            // 
            // txtDocRefFileName
            // 
            this.txtDocRefFileName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDocRefFileName.BackColor = System.Drawing.Color.FloralWhite;
            this.txtDocRefFileName.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDocRefFileName.Location = new System.Drawing.Point(231, 3);
            this.txtDocRefFileName.Name = "txtDocRefFileName";
            this.txtDocRefFileName.ReadOnly = true;
            this.txtDocRefFileName.Size = new System.Drawing.Size(131, 21);
            this.txtDocRefFileName.TabIndex = 2;
            // 
            // lblSeq
            // 
            this.lblSeq.AutoSize = true;
            this.lblSeq.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSeq.ForeColor = System.Drawing.Color.Crimson;
            this.lblSeq.Location = new System.Drawing.Point(70, 6);
            this.lblSeq.Name = "lblSeq";
            this.lblSeq.Size = new System.Drawing.Size(29, 15);
            this.lblSeq.TabIndex = 10;
            this.lblSeq.Text = "Seq";
            // 
            // lblreactioncasreactonnumber
            // 
            this.lblreactioncasreactonnumber.AutoSize = true;
            this.lblreactioncasreactonnumber.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblreactioncasreactonnumber.ForeColor = System.Drawing.Color.Crimson;
            this.lblreactioncasreactonnumber.Location = new System.Drawing.Point(-2, 6);
            this.lblreactioncasreactonnumber.Name = "lblreactioncasreactonnumber";
            this.lblreactioncasreactonnumber.Size = new System.Drawing.Size(34, 15);
            this.lblreactioncasreactonnumber.TabIndex = 4;
            this.lblreactioncasreactonnumber.Text = "Num";
            this.lblreactioncasreactonnumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtRxnNum
            // 
            this.txtRxnNum.BackColor = System.Drawing.Color.FloralWhite;
            this.txtRxnNum.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRxnNum.ForeColor = System.Drawing.Color.Blue;
            this.txtRxnNum.Location = new System.Drawing.Point(35, 3);
            this.txtRxnNum.Name = "txtRxnNum";
            this.txtRxnNum.ReadOnly = true;
            this.txtRxnNum.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtRxnNum.Size = new System.Drawing.Size(32, 21);
            this.txtRxnNum.TabIndex = 100;
            this.txtRxnNum.Text = "0";
            // 
            // lblPageNumber
            // 
            this.lblPageNumber.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblPageNumber.AutoSize = true;
            this.lblPageNumber.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageNumber.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblPageNumber.Location = new System.Drawing.Point(370, 6);
            this.lblPageNumber.Name = "lblPageNumber";
            this.lblPageNumber.Size = new System.Drawing.Size(58, 15);
            this.lblPageNumber.TabIndex = 0;
            this.lblPageNumber.Text = "Page No.";
            // 
            // txtDocRef
            // 
            this.txtDocRef.BackColor = System.Drawing.Color.FloralWhite;
            this.txtDocRef.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDocRef.Location = new System.Drawing.Point(162, 3);
            this.txtDocRef.Name = "txtDocRef";
            this.txtDocRef.ReadOnly = true;
            this.txtDocRef.Size = new System.Drawing.Size(44, 21);
            this.txtDocRef.TabIndex = 1;
            // 
            // txtPageNo
            // 
            this.txtPageNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPageNo.BackColor = System.Drawing.Color.White;
            this.txtPageNo.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPageNo.Location = new System.Drawing.Point(431, 4);
            this.txtPageNo.MaxLength = 3;
            this.txtPageNo.Multiline = true;
            this.txtPageNo.Name = "txtPageNo";
            this.txtPageNo.Size = new System.Drawing.Size(41, 20);
            this.txtPageNo.TabIndex = 2;
            this.txtPageNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtpagenumber_KeyPress);
            // 
            // lblpglabel
            // 
            this.lblpglabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblpglabel.AutoSize = true;
            this.lblpglabel.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpglabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblpglabel.Location = new System.Drawing.Point(479, 5);
            this.lblpglabel.Name = "lblpglabel";
            this.lblpglabel.Size = new System.Drawing.Size(70, 15);
            this.lblpglabel.TabIndex = 0;
            this.lblpglabel.Text = "Page Label";
            // 
            // txtRxnSeq
            // 
            this.txtRxnSeq.BackColor = System.Drawing.Color.FloralWhite;
            this.txtRxnSeq.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRxnSeq.ForeColor = System.Drawing.Color.Blue;
            this.txtRxnSeq.Location = new System.Drawing.Point(101, 3);
            this.txtRxnSeq.Name = "txtRxnSeq";
            this.txtRxnSeq.ReadOnly = true;
            this.txtRxnSeq.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtRxnSeq.Size = new System.Drawing.Size(31, 21);
            this.txtRxnSeq.TabIndex = 102;
            this.txtRxnSeq.Text = "0";
            // 
            // txtPageLabel
            // 
            this.txtPageLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPageLabel.BackColor = System.Drawing.Color.White;
            this.txtPageLabel.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPageLabel.Location = new System.Drawing.Point(552, 3);
            this.txtPageLabel.MaxLength = 5;
            this.txtPageLabel.Name = "txtPageLabel";
            this.txtPageLabel.Size = new System.Drawing.Size(39, 21);
            this.txtPageLabel.TabIndex = 3;
            // 
            // txtOffset_Y
            // 
            this.txtOffset_Y.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOffset_Y.BackColor = System.Drawing.Color.PapayaWhip;
            this.txtOffset_Y.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOffset_Y.Location = new System.Drawing.Point(982, 4);
            this.txtOffset_Y.Multiline = true;
            this.txtOffset_Y.Name = "txtOffset_Y";
            this.txtOffset_Y.ReadOnly = true;
            this.txtOffset_Y.Size = new System.Drawing.Size(40, 20);
            this.txtOffset_Y.TabIndex = 7;
            this.txtOffset_Y.Click += new System.EventHandler(this.txtOffset_X_Click);
            this.txtOffset_Y.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtyoffset_KeyPress);
            // 
            // lbldocref
            // 
            this.lbldocref.AutoSize = true;
            this.lbldocref.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldocref.ForeColor = System.Drawing.Color.Crimson;
            this.lbldocref.Location = new System.Drawing.Point(133, 6);
            this.lbldocref.Name = "lbldocref";
            this.lbldocref.Size = new System.Drawing.Size(29, 15);
            this.lbldocref.TabIndex = 5;
            this.lbldocref.Text = "Doc";
            // 
            // lblYoffSet
            // 
            this.lblYoffSet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblYoffSet.AutoSize = true;
            this.lblYoffSet.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYoffSet.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblYoffSet.Location = new System.Drawing.Point(928, 7);
            this.lblYoffSet.Name = "lblYoffSet";
            this.lblYoffSet.Size = new System.Drawing.Size(53, 15);
            this.lblYoffSet.TabIndex = 7;
            this.lblYoffSet.Text = "Y Off Set";
            // 
            // txtOffset_X
            // 
            this.txtOffset_X.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOffset_X.BackColor = System.Drawing.Color.PapayaWhip;
            this.txtOffset_X.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOffset_X.Location = new System.Drawing.Point(887, 4);
            this.txtOffset_X.Multiline = true;
            this.txtOffset_X.Name = "txtOffset_X";
            this.txtOffset_X.ReadOnly = true;
            this.txtOffset_X.Size = new System.Drawing.Size(40, 20);
            this.txtOffset_X.TabIndex = 6;
            this.txtOffset_X.Click += new System.EventHandler(this.txtOffset_X_Click);
            this.txtOffset_X.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtxoffset_KeyPress);
            // 
            // lblfilename
            // 
            this.lblfilename.AutoSize = true;
            this.lblfilename.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfilename.ForeColor = System.Drawing.Color.Crimson;
            this.lblfilename.Location = new System.Drawing.Point(205, 6);
            this.lblfilename.Name = "lblfilename";
            this.lblfilename.Size = new System.Drawing.Size(27, 15);
            this.lblfilename.TabIndex = 8;
            this.lblfilename.Text = "File";
            // 
            // lblXoffSet
            // 
            this.lblXoffSet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblXoffSet.AutoSize = true;
            this.lblXoffSet.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblXoffSet.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblXoffSet.Location = new System.Drawing.Point(833, 6);
            this.lblXoffSet.Name = "lblXoffSet";
            this.lblXoffSet.Size = new System.Drawing.Size(53, 15);
            this.lblXoffSet.TabIndex = 7;
            this.lblXoffSet.Text = "X Off Set";
            // 
            // lblXPageSize
            // 
            this.lblXPageSize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblXPageSize.AutoSize = true;
            this.lblXPageSize.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblXPageSize.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblXPageSize.Location = new System.Drawing.Point(596, 6);
            this.lblXPageSize.Name = "lblXPageSize";
            this.lblXPageSize.Size = new System.Drawing.Size(72, 15);
            this.lblXPageSize.TabIndex = 6;
            this.lblXPageSize.Text = "X Page Size";
            // 
            // lblYPageSize
            // 
            this.lblYPageSize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblYPageSize.AutoSize = true;
            this.lblYPageSize.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYPageSize.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblYPageSize.Location = new System.Drawing.Point(713, 6);
            this.lblYPageSize.Name = "lblYPageSize";
            this.lblYPageSize.Size = new System.Drawing.Size(72, 15);
            this.lblYPageSize.TabIndex = 6;
            this.lblYPageSize.Text = "Y Page Size";
            // 
            // txtPageSize_Y
            // 
            this.txtPageSize_Y.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPageSize_Y.BackColor = System.Drawing.Color.MistyRose;
            this.txtPageSize_Y.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPageSize_Y.Location = new System.Drawing.Point(787, 4);
            this.txtPageSize_Y.Multiline = true;
            this.txtPageSize_Y.Name = "txtPageSize_Y";
            this.txtPageSize_Y.ReadOnly = true;
            this.txtPageSize_Y.Size = new System.Drawing.Size(40, 20);
            this.txtPageSize_Y.TabIndex = 5;
            this.txtPageSize_Y.Click += new System.EventHandler(this.txtPageSize_X_Click);
            this.txtPageSize_Y.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtypagesize_KeyPress);
            // 
            // txtPageSize_X
            // 
            this.txtPageSize_X.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPageSize_X.BackColor = System.Drawing.Color.MistyRose;
            this.txtPageSize_X.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPageSize_X.Location = new System.Drawing.Point(669, 4);
            this.txtPageSize_X.Multiline = true;
            this.txtPageSize_X.Name = "txtPageSize_X";
            this.txtPageSize_X.ReadOnly = true;
            this.txtPageSize_X.Size = new System.Drawing.Size(40, 20);
            this.txtPageSize_X.TabIndex = 4;
            this.txtPageSize_X.Click += new System.EventHandler(this.txtPageSize_X_Click);
            this.txtPageSize_X.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtxpagesize_KeyPress);
            // 
            // lblTextLine
            // 
            this.lblTextLine.AutoSize = true;
            this.lblTextLine.BackColor = System.Drawing.Color.White;
            this.lblTextLine.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTextLine.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblTextLine.Location = new System.Drawing.Point(1, 64);
            this.lblTextLine.Name = "lblTextLine";
            this.lblTextLine.Size = new System.Drawing.Size(54, 15);
            this.lblTextLine.TabIndex = 57;
            this.lblTextLine.Text = "Text line";
            // 
            // cmbAnalogousTo
            // 
            this.cmbAnalogousTo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbAnalogousTo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAnalogousTo.BackColor = System.Drawing.Color.White;
            this.cmbAnalogousTo.Enabled = false;
            this.cmbAnalogousTo.FormattingEnabled = true;
            this.cmbAnalogousTo.Location = new System.Drawing.Point(244, 33);
            this.cmbAnalogousTo.Name = "cmbAnalogousTo";
            this.cmbAnalogousTo.Size = new System.Drawing.Size(102, 24);
            this.cmbAnalogousTo.TabIndex = 9;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.White;
            this.btnDelete.Enabled = false;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.Location = new System.Drawing.Point(1002, 35);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(21, 23);
            this.btnDelete.TabIndex = 68;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Visible = false;
            // 
            // splCntparaData
            // 
            this.splCntparaData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splCntparaData.BackColor = System.Drawing.Color.White;
            this.splCntparaData.Location = new System.Drawing.Point(2, 113);
            this.splCntparaData.Name = "splCntparaData";
            this.splCntparaData.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splCntparaData.Panel1
            // 
            this.splCntparaData.Panel1.Controls.Add(this.flPnlPara);
            this.splCntparaData.Panel1.Controls.Add(this.pnlParaHdr);
            // 
            // splCntparaData.Panel2
            // 
            this.splCntparaData.Panel2.Controls.Add(this.splDataData2);
            this.splCntparaData.Size = new System.Drawing.Size(1022, 314);
            this.splCntparaData.SplitterDistance = 169;
            this.splCntparaData.TabIndex = 67;
            // 
            // flPnlPara
            // 
            this.flPnlPara.AutoScroll = true;
            this.flPnlPara.BackColor = System.Drawing.Color.WhiteSmoke;
            this.flPnlPara.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flPnlPara.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flPnlPara.Location = new System.Drawing.Point(0, 23);
            this.flPnlPara.Name = "flPnlPara";
            this.flPnlPara.Size = new System.Drawing.Size(1022, 146);
            this.flPnlPara.TabIndex = 1;
            this.flPnlPara.SizeChanged += new System.EventHandler(this.flPnlPara_SizeChanged);
            // 
            // pnlParaHdr
            // 
            this.pnlParaHdr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlParaHdr.Controls.Add(this.tsPara);
            this.pnlParaHdr.Controls.Add(this.lblParaCnt);
            this.pnlParaHdr.Controls.Add(this.label1);
            this.pnlParaHdr.Controls.Add(this.lnkAddPara);
            this.pnlParaHdr.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlParaHdr.Location = new System.Drawing.Point(0, 0);
            this.pnlParaHdr.Name = "pnlParaHdr";
            this.pnlParaHdr.Size = new System.Drawing.Size(1022, 23);
            this.pnlParaHdr.TabIndex = 0;
            // 
            // tsPara
            // 
            this.tsPara.Dock = System.Windows.Forms.DockStyle.None;
            this.tsPara.GripMargin = new System.Windows.Forms.Padding(0);
            this.tsPara.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tsPara.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbtnDeletePara});
            this.tsPara.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.tsPara.Location = new System.Drawing.Point(49, -3);
            this.tsPara.Name = "tsPara";
            this.tsPara.Size = new System.Drawing.Size(26, 24);
            this.tsPara.TabIndex = 73;
            this.tsPara.Text = "toolStrip1";
            // 
            // tsbtnDeletePara
            // 
            this.tsbtnDeletePara.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbtnDeletePara.Image = global::IndxReactNarr.Properties.Resources.close_box_red;
            this.tsbtnDeletePara.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbtnDeletePara.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnDeletePara.Margin = new System.Windows.Forms.Padding(1);
            this.tsbtnDeletePara.Name = "tsbtnDeletePara";
            this.tsbtnDeletePara.Padding = new System.Windows.Forms.Padding(1);
            this.tsbtnDeletePara.Size = new System.Drawing.Size(23, 22);
            this.tsbtnDeletePara.Text = "toolStripButton1";
            this.tsbtnDeletePara.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tsbtnDeletePara.ToolTipText = "Delete selected Para";
            this.tsbtnDeletePara.Click += new System.EventHandler(this.tsbtnDeletePara_Click);
            // 
            // lblParaCnt
            // 
            this.lblParaCnt.AutoSize = true;
            this.lblParaCnt.BackColor = System.Drawing.Color.White;
            this.lblParaCnt.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParaCnt.ForeColor = System.Drawing.Color.Red;
            this.lblParaCnt.Location = new System.Drawing.Point(195, 3);
            this.lblParaCnt.Name = "lblParaCnt";
            this.lblParaCnt.Size = new System.Drawing.Size(15, 15);
            this.lblParaCnt.TabIndex = 72;
            this.lblParaCnt.Text = "--";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(114, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 15);
            this.label1.TabIndex = 71;
            this.label1.Text = "Para Count: ";
            // 
            // lnkAddPara
            // 
            this.lnkAddPara.AutoSize = true;
            this.lnkAddPara.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lnkAddPara.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkAddPara.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkAddPara.Location = new System.Drawing.Point(2, 2);
            this.lnkAddPara.Name = "lnkAddPara";
            this.lnkAddPara.Size = new System.Drawing.Size(50, 16);
            this.lnkAddPara.TabIndex = 14;
            this.lnkAddPara.TabStop = true;
            this.lnkAddPara.Text = "Para +";
            this.toolTip1.SetToolTip(this.lnkAddPara, "Add Para");
            this.lnkAddPara.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkAddPara_LinkClicked);
            // 
            // splDataData2
            // 
            this.splDataData2.BackColor = System.Drawing.Color.White;
            this.splDataData2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splDataData2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splDataData2.Location = new System.Drawing.Point(0, 0);
            this.splDataData2.Name = "splDataData2";
            this.splDataData2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splDataData2.Panel1
            // 
            this.splDataData2.Panel1.Controls.Add(this.flPnlData);
            this.splDataData2.Panel1.Controls.Add(this.pnlDataHdr);
            // 
            // splDataData2.Panel2
            // 
            this.splDataData2.Panel2.Controls.Add(this.lblData2);
            this.splDataData2.Panel2.Controls.Add(this.rtxtdata1);
            this.splDataData2.Panel2Collapsed = true;
            this.splDataData2.Size = new System.Drawing.Size(1022, 141);
            this.splDataData2.SplitterDistance = 84;
            this.splDataData2.TabIndex = 21;
            // 
            // flPnlData
            // 
            this.flPnlData.AutoScroll = true;
            this.flPnlData.BackColor = System.Drawing.Color.WhiteSmoke;
            this.flPnlData.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flPnlData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flPnlData.Location = new System.Drawing.Point(0, 23);
            this.flPnlData.Name = "flPnlData";
            this.flPnlData.Size = new System.Drawing.Size(1020, 116);
            this.flPnlData.TabIndex = 2;
            this.flPnlData.SizeChanged += new System.EventHandler(this.flPnlData_SizeChanged);
            // 
            // pnlDataHdr
            // 
            this.pnlDataHdr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlDataHdr.Controls.Add(this.tsData);
            this.pnlDataHdr.Controls.Add(this.lblDataCnt);
            this.pnlDataHdr.Controls.Add(this.label3);
            this.pnlDataHdr.Controls.Add(this.lnkData);
            this.pnlDataHdr.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlDataHdr.Location = new System.Drawing.Point(0, 0);
            this.pnlDataHdr.Name = "pnlDataHdr";
            this.pnlDataHdr.Size = new System.Drawing.Size(1020, 23);
            this.pnlDataHdr.TabIndex = 1;
            // 
            // tsData
            // 
            this.tsData.Dock = System.Windows.Forms.DockStyle.None;
            this.tsData.GripMargin = new System.Windows.Forms.Padding(0);
            this.tsData.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tsData.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbtnDeleteData});
            this.tsData.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.tsData.Location = new System.Drawing.Point(49, -2);
            this.tsData.Name = "tsData";
            this.tsData.Size = new System.Drawing.Size(26, 24);
            this.tsData.TabIndex = 75;
            this.tsData.Text = "toolStrip1";
            // 
            // tsbtnDeleteData
            // 
            this.tsbtnDeleteData.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbtnDeleteData.Image = global::IndxReactNarr.Properties.Resources.close_box_red;
            this.tsbtnDeleteData.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbtnDeleteData.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnDeleteData.Margin = new System.Windows.Forms.Padding(1);
            this.tsbtnDeleteData.Name = "tsbtnDeleteData";
            this.tsbtnDeleteData.Padding = new System.Windows.Forms.Padding(1);
            this.tsbtnDeleteData.Size = new System.Drawing.Size(23, 22);
            this.tsbtnDeleteData.Text = "toolStripButton1";
            this.tsbtnDeleteData.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tsbtnDeleteData.ToolTipText = "Delete selected Data";
            this.tsbtnDeleteData.Click += new System.EventHandler(this.tsbtnDeleteData_Click);
            // 
            // lblDataCnt
            // 
            this.lblDataCnt.AutoSize = true;
            this.lblDataCnt.BackColor = System.Drawing.Color.White;
            this.lblDataCnt.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataCnt.ForeColor = System.Drawing.Color.Red;
            this.lblDataCnt.Location = new System.Drawing.Point(195, 3);
            this.lblDataCnt.Name = "lblDataCnt";
            this.lblDataCnt.Size = new System.Drawing.Size(15, 15);
            this.lblDataCnt.TabIndex = 74;
            this.lblDataCnt.Text = "--";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(114, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 15);
            this.label3.TabIndex = 73;
            this.label3.Text = "Data Count: ";
            // 
            // lnkData
            // 
            this.lnkData.AutoSize = true;
            this.lnkData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lnkData.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkData.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkData.Location = new System.Drawing.Point(2, 2);
            this.lnkData.Name = "lnkData";
            this.lnkData.Size = new System.Drawing.Size(49, 16);
            this.lnkData.TabIndex = 15;
            this.lnkData.TabStop = true;
            this.lnkData.Text = "Data +";
            this.toolTip1.SetToolTip(this.lnkData, "Add Data");
            this.lnkData.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkData_LinkClicked);
            // 
            // lblData2
            // 
            this.lblData2.AutoSize = true;
            this.lblData2.BackColor = System.Drawing.Color.White;
            this.lblData2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblData2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblData2.Location = new System.Drawing.Point(6, 0);
            this.lblData2.Name = "lblData2";
            this.lblData2.Size = new System.Drawing.Size(46, 14);
            this.lblData2.TabIndex = 63;
            this.lblData2.Text = "Data2 : ";
            // 
            // rtxtdata1
            // 
            this.rtxtdata1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rtxtdata1.BackColor = System.Drawing.Color.White;
            this.rtxtdata1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rtxtdata1.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtxtdata1.Location = new System.Drawing.Point(4, 15);
            this.rtxtdata1.Name = "rtxtdata1";
            this.rtxtdata1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.rtxtdata1.Size = new System.Drawing.Size(785, 89);
            this.rtxtdata1.TabIndex = 20;
            this.rtxtdata1.Text = "";
            // 
            // txtNarrID
            // 
            this.txtNarrID.BackColor = System.Drawing.Color.FloralWhite;
            this.txtNarrID.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNarrID.ForeColor = System.Drawing.Color.Blue;
            this.txtNarrID.Location = new System.Drawing.Point(56, 35);
            this.txtNarrID.Name = "txtNarrID";
            this.txtNarrID.ReadOnly = true;
            this.txtNarrID.Size = new System.Drawing.Size(56, 22);
            this.txtNarrID.TabIndex = 103;
            this.txtNarrID.Text = "nar";
            // 
            // lblNarId
            // 
            this.lblNarId.AutoSize = true;
            this.lblNarId.BackColor = System.Drawing.Color.White;
            this.lblNarId.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNarId.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblNarId.Location = new System.Drawing.Point(7, 38);
            this.lblNarId.Name = "lblNarId";
            this.lblNarId.Size = new System.Drawing.Size(46, 15);
            this.lblNarId.TabIndex = 58;
            this.lblNarId.Text = "Narr ID";
            // 
            // tb1rtxteditor
            // 
            this.tb1rtxteditor.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb1rtxteditor.BackColor = System.Drawing.Color.White;
            this.tb1rtxteditor.DefaultComposeSettings.BackColor = System.Drawing.Color.White;
            this.tb1rtxteditor.DefaultComposeSettings.DefaultFont = new System.Drawing.Font("Arial", 10F);
            this.tb1rtxteditor.DefaultComposeSettings.Enabled = false;
            this.tb1rtxteditor.DefaultComposeSettings.ForeColor = System.Drawing.Color.Black;
            this.tb1rtxteditor.DocumentEncoding = onlyconnect.EncodingType.WindowsCurrent;
            this.tb1rtxteditor.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb1rtxteditor.IsDesignMode = true;
            this.tb1rtxteditor.Location = new System.Drawing.Point(117, 181);
            this.tb1rtxteditor.Margin = new System.Windows.Forms.Padding(10);
            this.tb1rtxteditor.Name = "tb1rtxteditor";
            this.tb1rtxteditor.OpenLinksInNewWindow = true;
            this.tb1rtxteditor.SelectionAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb1rtxteditor.SelectionBackColor = System.Drawing.Color.Empty;
            this.tb1rtxteditor.SelectionBullets = false;
            this.tb1rtxteditor.SelectionFont = null;
            this.tb1rtxteditor.SelectionForeColor = System.Drawing.Color.Empty;
            this.tb1rtxteditor.SelectionNumbering = false;
            this.tb1rtxteditor.Size = new System.Drawing.Size(793, 69);
            this.tb1rtxteditor.TabIndex = 66;
            this.tb1rtxteditor.Tag = "";
            this.tb1rtxteditor.Visible = false;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.BackColor = System.Drawing.Color.White;
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyXYOffsetsTSMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(160, 26);
            // 
            // copyXYOffsetsTSMenuItem
            // 
            this.copyXYOffsetsTSMenuItem.BackColor = System.Drawing.Color.White;
            this.copyXYOffsetsTSMenuItem.Name = "copyXYOffsetsTSMenuItem";
            this.copyXYOffsetsTSMenuItem.Size = new System.Drawing.Size(159, 22);
            this.copyXYOffsetsTSMenuItem.Text = "Copy XY Offsets";
            this.copyXYOffsetsTSMenuItem.Click += new System.EventHandler(this.copyXYOffsetsTSMenuItem_Click);
            // 
            // ucNarCuration
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ContextMenuStrip = this.contextMenuStrip2;
            this.Controls.Add(this.pnlMain);
            this.Name = "ucNarCuration";
            this.Size = new System.Drawing.Size(1027, 430);
            this.Load += new System.EventHandler(this.uccasnartool_Load);
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.pnlNumInfo.ResumeLayout(false);
            this.pnlNumInfo.PerformLayout();
            this.splCntparaData.Panel1.ResumeLayout(false);
            this.splCntparaData.Panel2.ResumeLayout(false);
            this.splCntparaData.ResumeLayout(false);
            this.pnlParaHdr.ResumeLayout(false);
            this.pnlParaHdr.PerformLayout();
            this.tsPara.ResumeLayout(false);
            this.tsPara.PerformLayout();
            this.splDataData2.Panel1.ResumeLayout(false);
            this.splDataData2.Panel2.ResumeLayout(false);
            this.splDataData2.Panel2.PerformLayout();
            this.splDataData2.ResumeLayout(false);
            this.pnlDataHdr.ResumeLayout(false);
            this.pnlDataHdr.PerformLayout();
            this.tsData.ResumeLayout(false);
            this.tsData.PerformLayout();
            this.contextMenuStrip2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblNarId;
        private System.Windows.Forms.Label lblTextLine;
        private System.Windows.Forms.Label lblYoffSet;
        private System.Windows.Forms.Label lblpglabel;
        private System.Windows.Forms.Label lblYPageSize;
        private System.Windows.Forms.Label lblXoffSet;
        private System.Windows.Forms.Label lblXPageSize;
        private System.Windows.Forms.Label lblPageNumber;
        private System.Windows.Forms.Label lblreactioncasreactonnumber;
        private System.Windows.Forms.Label lbldocref;
        private System.Windows.Forms.Label lblfilename;
        private System.Windows.Forms.Label lblSeq;
        public System.Windows.Forms.TextBox txtNarrID;
        public System.Windows.Forms.TextBox txtOffset_Y;
        public System.Windows.Forms.TextBox txtPageSize_Y;
        public System.Windows.Forms.TextBox txtPageLabel;
        public System.Windows.Forms.TextBox txtOffset_X;
        public System.Windows.Forms.TextBox txtPageSize_X;
        public System.Windows.Forms.TextBox txtPageNo;
        public System.Windows.Forms.TextBox txtRxnSeq;
        public System.Windows.Forms.TextBox txtRxnNum;
        public System.Windows.Forms.TextBox txtDocRefFileName;
        public System.Windows.Forms.TextBox txtDocRef;
        private onlyconnect.HtmlEditor tb1rtxteditor;
        public System.Windows.Forms.Panel pnlMain;
        public System.Windows.Forms.SplitContainer splCntparaData;
        public HtmlRichText.HtmlRichTextBox rtxtdata1;
        private System.Windows.Forms.Label lblData2;
        public System.Windows.Forms.SplitContainer splDataData2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem copyXYOffsetsTSMenuItem;
        public System.Windows.Forms.ComboBox cmbAnalogousTo;
        private System.Windows.Forms.Panel pnlNumInfo;
        public System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Panel pnlParaHdr;
        private System.Windows.Forms.FlowLayoutPanel flPnlPara;
        private System.Windows.Forms.LinkLabel lnkAddPara;
        private System.Windows.Forms.Panel pnlDataHdr;
        private System.Windows.Forms.LinkLabel lnkData;
        private System.Windows.Forms.FlowLayoutPanel flPnlData;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label lblParaCnt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblDataCnt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolStrip tsPara;
        private System.Windows.Forms.ToolStripButton tsbtnDeletePara;
        private System.Windows.Forms.ToolStrip tsData;
        private System.Windows.Forms.ToolStripButton tsbtnDeleteData;
        public UserControls.ucHtmlRichText ucHrtbTextLine;
        private System.Windows.Forms.RadioButton rbnMissingRxn;
        private System.Windows.Forms.RadioButton rbnExpProcedure;
        private System.Windows.Forms.RadioButton rbnAnalogousTo;
        private System.Windows.Forms.RadioButton rbnNoExpDetails;
        private System.Windows.Forms.RadioButton rbnGeneralTypical;
    }
}
