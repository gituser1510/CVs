﻿namespace IndxReactNarr
{
    partial class ucNUMDetails
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tlPnlChemImage = new System.Windows.Forms.TableLayoutPanel();
            this.lblMForm = new System.Windows.Forms.Label();
            this.lblRegNo = new System.Windows.Forms.Label();
            this.txtSynonyms = new System.Windows.Forms.TextBox();
            this.lblSynonyms = new System.Windows.Forms.Label();
            this.txtIUPAC = new System.Windows.Forms.TextBox();
            this.lblIUPACName = new System.Windows.Forms.Label();
            this.lblNum = new System.Windows.Forms.Label();
            this.splCont = new System.Windows.Forms.SplitContainer();
            this.lblMolFormulaVal = new System.Windows.Forms.Label();
            this.lblRegNoVal = new System.Windows.Forms.Label();
            this.lblNUMVal = new System.Windows.Forms.Label();
            this.txtPeptideSeq = new System.Windows.Forms.TextBox();
            this.lblPepSeq = new System.Windows.Forms.Label();
            this.txtNuclicAcidSeq = new System.Windows.Forms.TextBox();
            this.lblNuclicSeq = new System.Windows.Forms.Label();
            this.splCont.Panel1.SuspendLayout();
            this.splCont.Panel2.SuspendLayout();
            this.splCont.SuspendLayout();
            this.SuspendLayout();
            // 
            // tlPnlChemImage
            // 
            this.tlPnlChemImage.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tlPnlChemImage.ColumnCount = 1;
            this.tlPnlChemImage.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlPnlChemImage.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlPnlChemImage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlPnlChemImage.Location = new System.Drawing.Point(0, 0);
            this.tlPnlChemImage.Name = "tlPnlChemImage";
            this.tlPnlChemImage.RowCount = 1;
            this.tlPnlChemImage.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlPnlChemImage.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlPnlChemImage.Size = new System.Drawing.Size(420, 400);
            this.tlPnlChemImage.TabIndex = 16;
            // 
            // lblMForm
            // 
            this.lblMForm.AutoSize = true;
            this.lblMForm.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMForm.Location = new System.Drawing.Point(1, 26);
            this.lblMForm.Name = "lblMForm";
            this.lblMForm.Size = new System.Drawing.Size(56, 17);
            this.lblMForm.TabIndex = 14;
            this.lblMForm.Text = "Formula";
            // 
            // lblRegNo
            // 
            this.lblRegNo.AutoSize = true;
            this.lblRegNo.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegNo.Location = new System.Drawing.Point(147, 3);
            this.lblRegNo.Name = "lblRegNo";
            this.lblRegNo.Size = new System.Drawing.Size(83, 17);
            this.lblRegNo.TabIndex = 11;
            this.lblRegNo.Text = "Registry No.";
            // 
            // txtSynonyms
            // 
            this.txtSynonyms.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSynonyms.BackColor = System.Drawing.Color.White;
            this.txtSynonyms.ForeColor = System.Drawing.Color.Blue;
            this.txtSynonyms.Location = new System.Drawing.Point(4, 316);
            this.txtSynonyms.Multiline = true;
            this.txtSynonyms.Name = "txtSynonyms";
            this.txtSynonyms.ReadOnly = true;
            this.txtSynonyms.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtSynonyms.Size = new System.Drawing.Size(399, 84);
            this.txtSynonyms.TabIndex = 10;
            // 
            // lblSynonyms
            // 
            this.lblSynonyms.AutoSize = true;
            this.lblSynonyms.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSynonyms.Location = new System.Drawing.Point(1, 297);
            this.lblSynonyms.Name = "lblSynonyms";
            this.lblSynonyms.Size = new System.Drawing.Size(88, 17);
            this.lblSynonyms.TabIndex = 9;
            this.lblSynonyms.Text = "Other Names";
            // 
            // txtIUPAC
            // 
            this.txtIUPAC.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtIUPAC.BackColor = System.Drawing.Color.White;
            this.txtIUPAC.ForeColor = System.Drawing.Color.Blue;
            this.txtIUPAC.Location = new System.Drawing.Point(4, 69);
            this.txtIUPAC.Multiline = true;
            this.txtIUPAC.Name = "txtIUPAC";
            this.txtIUPAC.ReadOnly = true;
            this.txtIUPAC.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtIUPAC.Size = new System.Drawing.Size(399, 92);
            this.txtIUPAC.TabIndex = 4;
            // 
            // lblIUPACName
            // 
            this.lblIUPACName.AutoSize = true;
            this.lblIUPACName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIUPACName.Location = new System.Drawing.Point(2, 49);
            this.lblIUPACName.Name = "lblIUPACName";
            this.lblIUPACName.Size = new System.Drawing.Size(94, 17);
            this.lblIUPACName.TabIndex = 3;
            this.lblIUPACName.Text = "IUPAC Name";
            // 
            // lblNum
            // 
            this.lblNum.AutoSize = true;
            this.lblNum.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum.Location = new System.Drawing.Point(1, 3);
            this.lblNum.Name = "lblNum";
            this.lblNum.Size = new System.Drawing.Size(43, 17);
            this.lblNum.TabIndex = 0;
            this.lblNum.Text = "NUM";
            // 
            // splCont
            // 
            this.splCont.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splCont.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splCont.Location = new System.Drawing.Point(0, 0);
            this.splCont.Name = "splCont";
            // 
            // splCont.Panel1
            // 
            this.splCont.Panel1.Controls.Add(this.txtNuclicAcidSeq);
            this.splCont.Panel1.Controls.Add(this.lblNuclicSeq);
            this.splCont.Panel1.Controls.Add(this.txtPeptideSeq);
            this.splCont.Panel1.Controls.Add(this.lblPepSeq);
            this.splCont.Panel1.Controls.Add(this.lblMolFormulaVal);
            this.splCont.Panel1.Controls.Add(this.lblRegNoVal);
            this.splCont.Panel1.Controls.Add(this.lblNUMVal);
            this.splCont.Panel1.Controls.Add(this.txtSynonyms);
            this.splCont.Panel1.Controls.Add(this.lblSynonyms);
            this.splCont.Panel1.Controls.Add(this.lblNum);
            this.splCont.Panel1.Controls.Add(this.txtIUPAC);
            this.splCont.Panel1.Controls.Add(this.lblMForm);
            this.splCont.Panel1.Controls.Add(this.lblIUPACName);
            this.splCont.Panel1.Controls.Add(this.lblRegNo);
            // 
            // splCont.Panel2
            // 
            this.splCont.Panel2.Controls.Add(this.tlPnlChemImage);
            this.splCont.Size = new System.Drawing.Size(835, 404);
            this.splCont.SplitterDistance = 407;
            this.splCont.TabIndex = 17;
            // 
            // lblMolFormulaVal
            // 
            this.lblMolFormulaVal.AutoSize = true;
            this.lblMolFormulaVal.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMolFormulaVal.ForeColor = System.Drawing.Color.Red;
            this.lblMolFormulaVal.Location = new System.Drawing.Point(63, 26);
            this.lblMolFormulaVal.Name = "lblMolFormulaVal";
            this.lblMolFormulaVal.Size = new System.Drawing.Size(23, 17);
            this.lblMolFormulaVal.TabIndex = 18;
            this.lblMolFormulaVal.Text = "---";
            // 
            // lblRegNoVal
            // 
            this.lblRegNoVal.AutoSize = true;
            this.lblRegNoVal.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegNoVal.ForeColor = System.Drawing.Color.Red;
            this.lblRegNoVal.Location = new System.Drawing.Point(236, 3);
            this.lblRegNoVal.Name = "lblRegNoVal";
            this.lblRegNoVal.Size = new System.Drawing.Size(16, 17);
            this.lblRegNoVal.TabIndex = 17;
            this.lblRegNoVal.Text = "0";
            // 
            // lblNUMVal
            // 
            this.lblNUMVal.AutoSize = true;
            this.lblNUMVal.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNUMVal.ForeColor = System.Drawing.Color.Red;
            this.lblNUMVal.Location = new System.Drawing.Point(50, 3);
            this.lblNUMVal.Name = "lblNUMVal";
            this.lblNUMVal.Size = new System.Drawing.Size(16, 17);
            this.lblNUMVal.TabIndex = 16;
            this.lblNUMVal.Text = "0";
            // 
            // txtPeptideSeq
            // 
            this.txtPeptideSeq.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPeptideSeq.BackColor = System.Drawing.Color.White;
            this.txtPeptideSeq.ForeColor = System.Drawing.Color.Blue;
            this.txtPeptideSeq.Location = new System.Drawing.Point(3, 184);
            this.txtPeptideSeq.Multiline = true;
            this.txtPeptideSeq.Name = "txtPeptideSeq";
            this.txtPeptideSeq.ReadOnly = true;
            this.txtPeptideSeq.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtPeptideSeq.Size = new System.Drawing.Size(399, 44);
            this.txtPeptideSeq.TabIndex = 20;
            // 
            // lblPepSeq
            // 
            this.lblPepSeq.AutoSize = true;
            this.lblPepSeq.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPepSeq.Location = new System.Drawing.Point(1, 164);
            this.lblPepSeq.Name = "lblPepSeq";
            this.lblPepSeq.Size = new System.Drawing.Size(113, 17);
            this.lblPepSeq.TabIndex = 19;
            this.lblPepSeq.Text = "Peptide Sequence";
            // 
            // txtNuclicAcidSeq
            // 
            this.txtNuclicAcidSeq.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNuclicAcidSeq.BackColor = System.Drawing.Color.White;
            this.txtNuclicAcidSeq.ForeColor = System.Drawing.Color.Blue;
            this.txtNuclicAcidSeq.Location = new System.Drawing.Point(3, 251);
            this.txtNuclicAcidSeq.Multiline = true;
            this.txtNuclicAcidSeq.Name = "txtNuclicAcidSeq";
            this.txtNuclicAcidSeq.ReadOnly = true;
            this.txtNuclicAcidSeq.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtNuclicAcidSeq.Size = new System.Drawing.Size(399, 44);
            this.txtNuclicAcidSeq.TabIndex = 22;
            // 
            // lblNuclicSeq
            // 
            this.lblNuclicSeq.AutoSize = true;
            this.lblNuclicSeq.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNuclicSeq.Location = new System.Drawing.Point(1, 231);
            this.lblNuclicSeq.Name = "lblNuclicSeq";
            this.lblNuclicSeq.Size = new System.Drawing.Size(146, 17);
            this.lblNuclicSeq.TabIndex = 21;
            this.lblNuclicSeq.Text = "Nucleic Acid Sequence";
            // 
            // ucNUMDetails
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.splCont);
            this.Name = "ucNUMDetails";
            this.Size = new System.Drawing.Size(835, 404);
            this.Load += new System.EventHandler(this.ucNUMDetails_Load);
            this.splCont.Panel1.ResumeLayout(false);
            this.splCont.Panel1.PerformLayout();
            this.splCont.Panel2.ResumeLayout(false);
            this.splCont.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblNum;
        private System.Windows.Forms.TextBox txtIUPAC;
        private System.Windows.Forms.Label lblIUPACName;
        private System.Windows.Forms.TextBox txtSynonyms;
        private System.Windows.Forms.Label lblSynonyms;
        private System.Windows.Forms.Label lblRegNo;
        private System.Windows.Forms.Label lblMForm;
        private System.Windows.Forms.TableLayoutPanel tlPnlChemImage;
        private System.Windows.Forms.SplitContainer splCont;
        private System.Windows.Forms.Label lblRegNoVal;
        private System.Windows.Forms.Label lblNUMVal;
        private System.Windows.Forms.Label lblMolFormulaVal;
        private System.Windows.Forms.TextBox txtNuclicAcidSeq;
        private System.Windows.Forms.Label lblNuclicSeq;
        private System.Windows.Forms.TextBox txtPeptideSeq;
        private System.Windows.Forms.Label lblPepSeq;
    }
}
