﻿namespace IndxReactNarr
{
    partial class ucArrow
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblArrow = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblArrow
            // 
            this.lblArrow.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblArrow.BackColor = System.Drawing.Color.White;
            this.lblArrow.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArrow.Location = new System.Drawing.Point(0, 102);
            this.lblArrow.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblArrow.Name = "lblArrow";
            this.lblArrow.Size = new System.Drawing.Size(75, 31);
            this.lblArrow.TabIndex = 1;
            this.lblArrow.Text = "===>";
            this.lblArrow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ucArrow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.lblArrow);
            this.Name = "ucArrow";
            this.Size = new System.Drawing.Size(73, 234);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblArrow;
    }
}
