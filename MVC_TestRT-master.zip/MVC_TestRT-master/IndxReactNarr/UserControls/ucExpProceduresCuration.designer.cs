﻿namespace IndxReactNarr
{
    partial class ucExpProceduresCuration
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucExpProceduresCuration));
            this.pnlMain = new System.Windows.Forms.Panel();
            this.splContNarrCntrl_Tabs = new System.Windows.Forms.SplitContainer();
            this.lblNarId = new System.Windows.Forms.Label();
            this.txtNarrID = new System.Windows.Forms.TextBox();
            this.uchrtbYieldText = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.btnDelete = new System.Windows.Forms.Button();
            this.rbnMissingRxn = new System.Windows.Forms.RadioButton();
            this.cmbAnalogousTo = new System.Windows.Forms.ComboBox();
            this.rbnExpProcedure = new System.Windows.Forms.RadioButton();
            this.rbnNoExpDetails = new System.Windows.Forms.RadioButton();
            this.ucHrtbTextLine = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.rbnGeneralTypical = new System.Windows.Forms.RadioButton();
            this.lblYieldText = new System.Windows.Forms.Label();
            this.lblTextLine = new System.Windows.Forms.Label();
            this.rbnAnalogousTo = new System.Windows.Forms.RadioButton();
            this.tcProc_DataText = new System.Windows.Forms.TabControl();
            this.tpPara = new System.Windows.Forms.TabPage();
            this.flPnlPara = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tsControls_Para = new System.Windows.Forms.ToolStrip();
            this.tsbtnAddPara = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbtnDeletePara = new System.Windows.Forms.ToolStripButton();
            this.tpData = new System.Windows.Forms.TabPage();
            this.flPnlData = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlDataCntrls = new System.Windows.Forms.Panel();
            this.tsControls_Data = new System.Windows.Forms.ToolStrip();
            this.tsbtnAddData = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbtnDeleteData = new System.Windows.Forms.ToolStripButton();
            this.tpProcedure = new System.Windows.Forms.TabPage();
            this.splContProcSteps = new System.Windows.Forms.SplitContainer();
            this.uchrtbReferencePara = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.lblRefPara = new System.Windows.Forms.Label();
            this.uchrtbProcSteps = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.label6 = new System.Windows.Forms.Label();
            this.tpRxnFindings_New = new System.Windows.Forms.TabPage();
            this.splContRxnFindingsNew = new System.Windows.Forms.SplitContainer();
            this.uchrtbDataForFindings_New = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.label7 = new System.Windows.Forms.Label();
            this.flPnlRxnFindings = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlFindingsBtns = new System.Windows.Forms.Panel();
            this.btnHelpFindings = new System.Windows.Forms.Button();
            this.tsRxnFindings = new System.Windows.Forms.ToolStrip();
            this.tsbAddFinding = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbDeleteFinding = new System.Windows.Forms.ToolStripButton();
            this.btnAutoFindingsNew = new System.Windows.Forms.Button();
            this.pnlCounts = new System.Windows.Forms.Panel();
            this.chkMappingUpdate = new System.Windows.Forms.CheckBox();
            this.lblRxnFindingsCnt = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblProcStepCount = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblDataCnt = new System.Windows.Forms.Label();
            this.lblParaCnt = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pnlNumInfo = new System.Windows.Forms.Panel();
            this.chkEmptyPgLabel = new System.Windows.Forms.CheckBox();
            this.txtDocRefFileName = new System.Windows.Forms.TextBox();
            this.lblSeq = new System.Windows.Forms.Label();
            this.lblreactioncasreactonnumber = new System.Windows.Forms.Label();
            this.txtRxnNum = new System.Windows.Forms.TextBox();
            this.txtDocRef = new System.Windows.Forms.TextBox();
            this.txtPageNo = new System.Windows.Forms.TextBox();
            this.txtRxnSeq = new System.Windows.Forms.TextBox();
            this.txtPageLabel = new System.Windows.Forms.TextBox();
            this.txtOffset_Y = new System.Windows.Forms.TextBox();
            this.lbldocref = new System.Windows.Forms.Label();
            this.lblYoffSet = new System.Windows.Forms.Label();
            this.txtOffset_X = new System.Windows.Forms.TextBox();
            this.lblfilename = new System.Windows.Forms.Label();
            this.lblXoffSet = new System.Windows.Forms.Label();
            this.txtPageSize_Y = new System.Windows.Forms.TextBox();
            this.txtPageSize_X = new System.Windows.Forms.TextBox();
            this.lblYPageSize = new System.Windows.Forms.Label();
            this.lblPageNumber = new System.Windows.Forms.Label();
            this.lblpglabel = new System.Windows.Forms.Label();
            this.lblXPageSize = new System.Windows.Forms.Label();
            this.tb1rtxteditor = new onlyconnect.HtmlEditor();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.copyXYOffsetsTSMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splContNarrCntrl_Tabs)).BeginInit();
            this.splContNarrCntrl_Tabs.Panel1.SuspendLayout();
            this.splContNarrCntrl_Tabs.Panel2.SuspendLayout();
            this.splContNarrCntrl_Tabs.SuspendLayout();
            this.tcProc_DataText.SuspendLayout();
            this.tpPara.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tsControls_Para.SuspendLayout();
            this.tpData.SuspendLayout();
            this.pnlDataCntrls.SuspendLayout();
            this.tsControls_Data.SuspendLayout();
            this.tpProcedure.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splContProcSteps)).BeginInit();
            this.splContProcSteps.Panel1.SuspendLayout();
            this.splContProcSteps.Panel2.SuspendLayout();
            this.splContProcSteps.SuspendLayout();
            this.tpRxnFindings_New.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splContRxnFindingsNew)).BeginInit();
            this.splContRxnFindingsNew.Panel1.SuspendLayout();
            this.splContRxnFindingsNew.Panel2.SuspendLayout();
            this.splContRxnFindingsNew.SuspendLayout();
            this.pnlFindingsBtns.SuspendLayout();
            this.tsRxnFindings.SuspendLayout();
            this.pnlCounts.SuspendLayout();
            this.pnlNumInfo.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.splContNarrCntrl_Tabs);
            this.pnlMain.Controls.Add(this.pnlCounts);
            this.pnlMain.Controls.Add(this.pnlNumInfo);
            this.pnlMain.Controls.Add(this.tb1rtxteditor);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1027, 492);
            this.pnlMain.TabIndex = 0;
            // 
            // splContNarrCntrl_Tabs
            // 
            this.splContNarrCntrl_Tabs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splContNarrCntrl_Tabs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContNarrCntrl_Tabs.Location = new System.Drawing.Point(0, 30);
            this.splContNarrCntrl_Tabs.Name = "splContNarrCntrl_Tabs";
            this.splContNarrCntrl_Tabs.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splContNarrCntrl_Tabs.Panel1
            // 
            this.splContNarrCntrl_Tabs.Panel1.Controls.Add(this.lblNarId);
            this.splContNarrCntrl_Tabs.Panel1.Controls.Add(this.txtNarrID);
            this.splContNarrCntrl_Tabs.Panel1.Controls.Add(this.uchrtbYieldText);
            this.splContNarrCntrl_Tabs.Panel1.Controls.Add(this.btnDelete);
            this.splContNarrCntrl_Tabs.Panel1.Controls.Add(this.rbnMissingRxn);
            this.splContNarrCntrl_Tabs.Panel1.Controls.Add(this.cmbAnalogousTo);
            this.splContNarrCntrl_Tabs.Panel1.Controls.Add(this.rbnExpProcedure);
            this.splContNarrCntrl_Tabs.Panel1.Controls.Add(this.rbnNoExpDetails);
            this.splContNarrCntrl_Tabs.Panel1.Controls.Add(this.ucHrtbTextLine);
            this.splContNarrCntrl_Tabs.Panel1.Controls.Add(this.rbnGeneralTypical);
            this.splContNarrCntrl_Tabs.Panel1.Controls.Add(this.lblYieldText);
            this.splContNarrCntrl_Tabs.Panel1.Controls.Add(this.lblTextLine);
            this.splContNarrCntrl_Tabs.Panel1.Controls.Add(this.rbnAnalogousTo);
            // 
            // splContNarrCntrl_Tabs.Panel2
            // 
            this.splContNarrCntrl_Tabs.Panel2.Controls.Add(this.tcProc_DataText);
            this.splContNarrCntrl_Tabs.Size = new System.Drawing.Size(1027, 437);
            this.splContNarrCntrl_Tabs.SplitterDistance = 88;
            this.splContNarrCntrl_Tabs.SplitterWidth = 2;
            this.splContNarrCntrl_Tabs.TabIndex = 205;
            // 
            // lblNarId
            // 
            this.lblNarId.AutoSize = true;
            this.lblNarId.BackColor = System.Drawing.Color.White;
            this.lblNarId.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNarId.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblNarId.Location = new System.Drawing.Point(10, 6);
            this.lblNarId.Name = "lblNarId";
            this.lblNarId.Size = new System.Drawing.Size(46, 15);
            this.lblNarId.TabIndex = 58;
            this.lblNarId.Text = "Narr ID";
            // 
            // txtNarrID
            // 
            this.txtNarrID.BackColor = System.Drawing.Color.FloralWhite;
            this.txtNarrID.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNarrID.ForeColor = System.Drawing.Color.Blue;
            this.txtNarrID.Location = new System.Drawing.Point(58, 3);
            this.txtNarrID.Name = "txtNarrID";
            this.txtNarrID.ReadOnly = true;
            this.txtNarrID.Size = new System.Drawing.Size(56, 22);
            this.txtNarrID.TabIndex = 103;
            this.txtNarrID.Text = "nar";
            // 
            // uchrtbYieldText
            // 
            this.uchrtbYieldText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uchrtbYieldText.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.uchrtbYieldText.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uchrtbYieldText.HighlightMaterials = false;
            this.uchrtbYieldText.Location = new System.Drawing.Point(57, 63);
            this.uchrtbYieldText.Name = "uchrtbYieldText";
            this.uchrtbYieldText.PreserveMultiLines = false;
            this.uchrtbYieldText.Size = new System.Drawing.Size(966, 23);
            this.uchrtbYieldText.TabIndex = 202;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.White;
            this.btnDelete.Enabled = false;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.Location = new System.Drawing.Point(996, 4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(21, 23);
            this.btnDelete.TabIndex = 68;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Visible = false;
            // 
            // rbnMissingRxn
            // 
            this.rbnMissingRxn.AutoSize = true;
            this.rbnMissingRxn.Location = new System.Drawing.Point(851, 5);
            this.rbnMissingRxn.Name = "rbnMissingRxn";
            this.rbnMissingRxn.Size = new System.Drawing.Size(126, 20);
            this.rbnMissingRxn.TabIndex = 12;
            this.rbnMissingRxn.Text = "Missing Reaction";
            this.rbnMissingRxn.UseVisualStyleBackColor = true;
            this.rbnMissingRxn.CheckedChanged += new System.EventHandler(this.rbnMissingRxn_CheckedChanged);
            // 
            // cmbAnalogousTo
            // 
            this.cmbAnalogousTo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbAnalogousTo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAnalogousTo.BackColor = System.Drawing.Color.White;
            this.cmbAnalogousTo.Enabled = false;
            this.cmbAnalogousTo.FormattingEnabled = true;
            this.cmbAnalogousTo.Location = new System.Drawing.Point(238, 3);
            this.cmbAnalogousTo.Name = "cmbAnalogousTo";
            this.cmbAnalogousTo.Size = new System.Drawing.Size(102, 24);
            this.cmbAnalogousTo.TabIndex = 9;
            this.cmbAnalogousTo.SelectionChangeCommitted += new System.EventHandler(this.cmbAnalogousTo_SelectionChangeCommitted);
            // 
            // rbnExpProcedure
            // 
            this.rbnExpProcedure.AutoSize = true;
            this.rbnExpProcedure.Checked = true;
            this.rbnExpProcedure.Location = new System.Drawing.Point(359, 5);
            this.rbnExpProcedure.Name = "rbnExpProcedure";
            this.rbnExpProcedure.Size = new System.Drawing.Size(165, 20);
            this.rbnExpProcedure.TabIndex = 9;
            this.rbnExpProcedure.TabStop = true;
            this.rbnExpProcedure.Text = "Experimental Procedure";
            this.rbnExpProcedure.UseVisualStyleBackColor = true;
            // 
            // rbnNoExpDetails
            // 
            this.rbnNoExpDetails.AutoSize = true;
            this.rbnNoExpDetails.Location = new System.Drawing.Point(665, 5);
            this.rbnNoExpDetails.Name = "rbnNoExpDetails";
            this.rbnNoExpDetails.Size = new System.Drawing.Size(166, 20);
            this.rbnNoExpDetails.TabIndex = 11;
            this.rbnNoExpDetails.Text = "No Experimental Details";
            this.rbnNoExpDetails.UseVisualStyleBackColor = true;
            // 
            // ucHrtbTextLine
            // 
            this.ucHrtbTextLine.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ucHrtbTextLine.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ucHrtbTextLine.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ucHrtbTextLine.HighlightMaterials = false;
            this.ucHrtbTextLine.Location = new System.Drawing.Point(57, 29);
            this.ucHrtbTextLine.Name = "ucHrtbTextLine";
            this.ucHrtbTextLine.PreserveMultiLines = false;
            this.ucHrtbTextLine.Size = new System.Drawing.Size(966, 33);
            this.ucHrtbTextLine.TabIndex = 13;
            // 
            // rbnGeneralTypical
            // 
            this.rbnGeneralTypical.AutoSize = true;
            this.rbnGeneralTypical.Location = new System.Drawing.Point(537, 5);
            this.rbnGeneralTypical.Name = "rbnGeneralTypical";
            this.rbnGeneralTypical.Size = new System.Drawing.Size(115, 20);
            this.rbnGeneralTypical.TabIndex = 10;
            this.rbnGeneralTypical.Text = "General Typical";
            this.rbnGeneralTypical.UseVisualStyleBackColor = true;
            // 
            // lblYieldText
            // 
            this.lblYieldText.AutoSize = true;
            this.lblYieldText.BackColor = System.Drawing.Color.White;
            this.lblYieldText.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYieldText.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblYieldText.Location = new System.Drawing.Point(-2, 67);
            this.lblYieldText.Name = "lblYieldText";
            this.lblYieldText.Size = new System.Drawing.Size(61, 15);
            this.lblYieldText.TabIndex = 203;
            this.lblYieldText.Text = "Yield Text";
            // 
            // lblTextLine
            // 
            this.lblTextLine.AutoSize = true;
            this.lblTextLine.BackColor = System.Drawing.Color.White;
            this.lblTextLine.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTextLine.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblTextLine.Location = new System.Drawing.Point(5, 32);
            this.lblTextLine.Name = "lblTextLine";
            this.lblTextLine.Size = new System.Drawing.Size(54, 15);
            this.lblTextLine.TabIndex = 57;
            this.lblTextLine.Text = "Text line";
            // 
            // rbnAnalogousTo
            // 
            this.rbnAnalogousTo.AutoSize = true;
            this.rbnAnalogousTo.Location = new System.Drawing.Point(136, 5);
            this.rbnAnalogousTo.Name = "rbnAnalogousTo";
            this.rbnAnalogousTo.Size = new System.Drawing.Size(104, 20);
            this.rbnAnalogousTo.TabIndex = 8;
            this.rbnAnalogousTo.Text = "Analogous To";
            this.rbnAnalogousTo.UseVisualStyleBackColor = true;
            this.rbnAnalogousTo.CheckedChanged += new System.EventHandler(this.rbnAnalogousTo_CheckedChanged);
            // 
            // tcProc_DataText
            // 
            this.tcProc_DataText.Controls.Add(this.tpPara);
            this.tcProc_DataText.Controls.Add(this.tpData);
            this.tcProc_DataText.Controls.Add(this.tpProcedure);
            this.tcProc_DataText.Controls.Add(this.tpRxnFindings_New);
            this.tcProc_DataText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcProc_DataText.HotTrack = true;
            this.tcProc_DataText.Location = new System.Drawing.Point(0, 0);
            this.tcProc_DataText.Name = "tcProc_DataText";
            this.tcProc_DataText.Padding = new System.Drawing.Point(0, 0);
            this.tcProc_DataText.SelectedIndex = 0;
            this.tcProc_DataText.Size = new System.Drawing.Size(1025, 345);
            this.tcProc_DataText.TabIndex = 0;
            this.tcProc_DataText.SelectedIndexChanged += new System.EventHandler(this.tcProc_DataText_SelectedIndexChanged);
            // 
            // tpPara
            // 
            this.tpPara.Controls.Add(this.flPnlPara);
            this.tpPara.Controls.Add(this.panel1);
            this.tpPara.Location = new System.Drawing.Point(4, 25);
            this.tpPara.Margin = new System.Windows.Forms.Padding(0);
            this.tpPara.Name = "tpPara";
            this.tpPara.Size = new System.Drawing.Size(1017, 316);
            this.tpPara.TabIndex = 3;
            this.tpPara.Text = "Para";
            this.tpPara.UseVisualStyleBackColor = true;
            // 
            // flPnlPara
            // 
            this.flPnlPara.AutoScroll = true;
            this.flPnlPara.BackColor = System.Drawing.Color.WhiteSmoke;
            this.flPnlPara.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flPnlPara.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flPnlPara.Location = new System.Drawing.Point(0, 27);
            this.flPnlPara.Name = "flPnlPara";
            this.flPnlPara.Size = new System.Drawing.Size(1017, 289);
            this.flPnlPara.TabIndex = 2;
            this.flPnlPara.SizeChanged += new System.EventHandler(this.flPnlPara_SizeChanged);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.tsControls_Para);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1017, 27);
            this.panel1.TabIndex = 1;
            // 
            // tsControls_Para
            // 
            this.tsControls_Para.Dock = System.Windows.Forms.DockStyle.Left;
            this.tsControls_Para.GripMargin = new System.Windows.Forms.Padding(0);
            this.tsControls_Para.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tsControls_Para.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbtnAddPara,
            this.toolStripSeparator1,
            this.tsbtnDeletePara});
            this.tsControls_Para.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.tsControls_Para.Location = new System.Drawing.Point(0, 0);
            this.tsControls_Para.Name = "tsControls_Para";
            this.tsControls_Para.Size = new System.Drawing.Size(189, 25);
            this.tsControls_Para.TabIndex = 74;
            this.tsControls_Para.Text = "toolStrip1";
            // 
            // tsbtnAddPara
            // 
            this.tsbtnAddPara.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsbtnAddPara.Image = global::IndxReactNarr.Properties.Resources.add;
            this.tsbtnAddPara.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnAddPara.Name = "tsbtnAddPara";
            this.tsbtnAddPara.Size = new System.Drawing.Size(82, 20);
            this.tsbtnAddPara.Text = "Add Para";
            this.tsbtnAddPara.Click += new System.EventHandler(this.tsbtnAddPara_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 23);
            // 
            // tsbtnDeletePara
            // 
            this.tsbtnDeletePara.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsbtnDeletePara.Image = global::IndxReactNarr.Properties.Resources.close_box_red;
            this.tsbtnDeletePara.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbtnDeletePara.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnDeletePara.Margin = new System.Windows.Forms.Padding(1);
            this.tsbtnDeletePara.Name = "tsbtnDeletePara";
            this.tsbtnDeletePara.Padding = new System.Windows.Forms.Padding(1);
            this.tsbtnDeletePara.Size = new System.Drawing.Size(98, 22);
            this.tsbtnDeletePara.Text = "Delete Para";
            this.tsbtnDeletePara.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tsbtnDeletePara.ToolTipText = "Delete selected Para";
            this.tsbtnDeletePara.Click += new System.EventHandler(this.tsbtnDeletePara_Click);
            // 
            // tpData
            // 
            this.tpData.Controls.Add(this.flPnlData);
            this.tpData.Controls.Add(this.pnlDataCntrls);
            this.tpData.Location = new System.Drawing.Point(4, 25);
            this.tpData.Margin = new System.Windows.Forms.Padding(0);
            this.tpData.Name = "tpData";
            this.tpData.Size = new System.Drawing.Size(1017, 316);
            this.tpData.TabIndex = 4;
            this.tpData.Text = "Data";
            this.tpData.UseVisualStyleBackColor = true;
            // 
            // flPnlData
            // 
            this.flPnlData.AutoScroll = true;
            this.flPnlData.BackColor = System.Drawing.Color.WhiteSmoke;
            this.flPnlData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flPnlData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flPnlData.Location = new System.Drawing.Point(0, 27);
            this.flPnlData.Name = "flPnlData";
            this.flPnlData.Size = new System.Drawing.Size(1017, 289);
            this.flPnlData.TabIndex = 3;
            this.flPnlData.SizeChanged += new System.EventHandler(this.flPnlData_SizeChanged);
            // 
            // pnlDataCntrls
            // 
            this.pnlDataCntrls.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlDataCntrls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlDataCntrls.Controls.Add(this.tsControls_Data);
            this.pnlDataCntrls.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlDataCntrls.Location = new System.Drawing.Point(0, 0);
            this.pnlDataCntrls.Name = "pnlDataCntrls";
            this.pnlDataCntrls.Size = new System.Drawing.Size(1017, 27);
            this.pnlDataCntrls.TabIndex = 2;
            // 
            // tsControls_Data
            // 
            this.tsControls_Data.Dock = System.Windows.Forms.DockStyle.Left;
            this.tsControls_Data.GripMargin = new System.Windows.Forms.Padding(0);
            this.tsControls_Data.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tsControls_Data.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbtnAddData,
            this.toolStripSeparator2,
            this.tsbtnDeleteData});
            this.tsControls_Data.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.tsControls_Data.Location = new System.Drawing.Point(0, 0);
            this.tsControls_Data.Name = "tsControls_Data";
            this.tsControls_Data.Size = new System.Drawing.Size(189, 25);
            this.tsControls_Data.TabIndex = 74;
            this.tsControls_Data.Text = "toolStrip1";
            // 
            // tsbtnAddData
            // 
            this.tsbtnAddData.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsbtnAddData.Image = global::IndxReactNarr.Properties.Resources.add;
            this.tsbtnAddData.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnAddData.Name = "tsbtnAddData";
            this.tsbtnAddData.Size = new System.Drawing.Size(82, 20);
            this.tsbtnAddData.Text = "Add Data";
            this.tsbtnAddData.Click += new System.EventHandler(this.tsbtnAddData_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 23);
            // 
            // tsbtnDeleteData
            // 
            this.tsbtnDeleteData.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsbtnDeleteData.Image = global::IndxReactNarr.Properties.Resources.close_box_red;
            this.tsbtnDeleteData.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbtnDeleteData.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnDeleteData.Margin = new System.Windows.Forms.Padding(1);
            this.tsbtnDeleteData.Name = "tsbtnDeleteData";
            this.tsbtnDeleteData.Padding = new System.Windows.Forms.Padding(1);
            this.tsbtnDeleteData.Size = new System.Drawing.Size(98, 22);
            this.tsbtnDeleteData.Text = "Delete Data";
            this.tsbtnDeleteData.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tsbtnDeleteData.ToolTipText = "Delete selected Data";
            this.tsbtnDeleteData.Click += new System.EventHandler(this.tsbtnDeleteData_Click);
            // 
            // tpProcedure
            // 
            this.tpProcedure.Controls.Add(this.splContProcSteps);
            this.tpProcedure.Location = new System.Drawing.Point(4, 25);
            this.tpProcedure.Margin = new System.Windows.Forms.Padding(0);
            this.tpProcedure.Name = "tpProcedure";
            this.tpProcedure.Size = new System.Drawing.Size(1017, 316);
            this.tpProcedure.TabIndex = 0;
            this.tpProcedure.Text = "Procedure Steps";
            this.tpProcedure.UseVisualStyleBackColor = true;
            // 
            // splContProcSteps
            // 
            this.splContProcSteps.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splContProcSteps.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContProcSteps.Location = new System.Drawing.Point(0, 0);
            this.splContProcSteps.Name = "splContProcSteps";
            this.splContProcSteps.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splContProcSteps.Panel1
            // 
            this.splContProcSteps.Panel1.Controls.Add(this.uchrtbReferencePara);
            this.splContProcSteps.Panel1.Controls.Add(this.lblRefPara);
            // 
            // splContProcSteps.Panel2
            // 
            this.splContProcSteps.Panel2.Controls.Add(this.uchrtbProcSteps);
            this.splContProcSteps.Panel2.Controls.Add(this.label6);
            this.splContProcSteps.Size = new System.Drawing.Size(1017, 316);
            this.splContProcSteps.SplitterDistance = 109;
            this.splContProcSteps.TabIndex = 4;
            // 
            // uchrtbReferencePara
            // 
            this.uchrtbReferencePara.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.uchrtbReferencePara.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uchrtbReferencePara.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uchrtbReferencePara.HighlightMaterials = false;
            this.uchrtbReferencePara.Location = new System.Drawing.Point(0, 23);
            this.uchrtbReferencePara.Name = "uchrtbReferencePara";
            this.uchrtbReferencePara.PreserveMultiLines = true;
            this.uchrtbReferencePara.Size = new System.Drawing.Size(1015, 84);
            this.uchrtbReferencePara.TabIndex = 16;
            // 
            // lblRefPara
            // 
            this.lblRefPara.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblRefPara.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRefPara.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblRefPara.Location = new System.Drawing.Point(0, 0);
            this.lblRefPara.Name = "lblRefPara";
            this.lblRefPara.Size = new System.Drawing.Size(1015, 23);
            this.lblRefPara.TabIndex = 17;
            this.lblRefPara.Text = "Reference Para";
            this.lblRefPara.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uchrtbProcSteps
            // 
            this.uchrtbProcSteps.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.uchrtbProcSteps.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uchrtbProcSteps.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uchrtbProcSteps.HighlightMaterials = true;
            this.uchrtbProcSteps.Location = new System.Drawing.Point(0, 23);
            this.uchrtbProcSteps.Name = "uchrtbProcSteps";
            this.uchrtbProcSteps.PreserveMultiLines = true;
            this.uchrtbProcSteps.Size = new System.Drawing.Size(1015, 178);
            this.uchrtbProcSteps.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.FloralWhite;
            this.label6.Dock = System.Windows.Forms.DockStyle.Top;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(0, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(1015, 23);
            this.label6.TabIndex = 18;
            this.label6.Text = "Procedure Steps";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tpRxnFindings_New
            // 
            this.tpRxnFindings_New.Controls.Add(this.splContRxnFindingsNew);
            this.tpRxnFindings_New.Location = new System.Drawing.Point(4, 25);
            this.tpRxnFindings_New.Name = "tpRxnFindings_New";
            this.tpRxnFindings_New.Size = new System.Drawing.Size(1017, 316);
            this.tpRxnFindings_New.TabIndex = 5;
            this.tpRxnFindings_New.Text = "Reaction Findings";
            this.tpRxnFindings_New.UseVisualStyleBackColor = true;
            // 
            // splContRxnFindingsNew
            // 
            this.splContRxnFindingsNew.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splContRxnFindingsNew.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContRxnFindingsNew.Location = new System.Drawing.Point(0, 0);
            this.splContRxnFindingsNew.Name = "splContRxnFindingsNew";
            this.splContRxnFindingsNew.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splContRxnFindingsNew.Panel1
            // 
            this.splContRxnFindingsNew.Panel1.Controls.Add(this.uchrtbDataForFindings_New);
            this.splContRxnFindingsNew.Panel1.Controls.Add(this.label7);
            // 
            // splContRxnFindingsNew.Panel2
            // 
            this.splContRxnFindingsNew.Panel2.Controls.Add(this.flPnlRxnFindings);
            this.splContRxnFindingsNew.Panel2.Controls.Add(this.pnlFindingsBtns);
            this.splContRxnFindingsNew.Size = new System.Drawing.Size(1017, 316);
            this.splContRxnFindingsNew.SplitterDistance = 87;
            this.splContRxnFindingsNew.TabIndex = 4;
            // 
            // uchrtbDataForFindings_New
            // 
            this.uchrtbDataForFindings_New.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.uchrtbDataForFindings_New.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uchrtbDataForFindings_New.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uchrtbDataForFindings_New.HighlightMaterials = false;
            this.uchrtbDataForFindings_New.Location = new System.Drawing.Point(0, 23);
            this.uchrtbDataForFindings_New.Name = "uchrtbDataForFindings_New";
            this.uchrtbDataForFindings_New.PreserveMultiLines = true;
            this.uchrtbDataForFindings_New.Size = new System.Drawing.Size(1015, 62);
            this.uchrtbDataForFindings_New.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label7.Dock = System.Windows.Forms.DockStyle.Top;
            this.label7.Location = new System.Drawing.Point(0, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(1015, 23);
            this.label7.TabIndex = 15;
            this.label7.Text = "Reference Data";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // flPnlRxnFindings
            // 
            this.flPnlRxnFindings.AutoScroll = true;
            this.flPnlRxnFindings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flPnlRxnFindings.Location = new System.Drawing.Point(0, 27);
            this.flPnlRxnFindings.Name = "flPnlRxnFindings";
            this.flPnlRxnFindings.Size = new System.Drawing.Size(1015, 196);
            this.flPnlRxnFindings.TabIndex = 17;
            this.flPnlRxnFindings.SizeChanged += new System.EventHandler(this.flPnlRxnFindings_SizeChanged);
            // 
            // pnlFindingsBtns
            // 
            this.pnlFindingsBtns.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlFindingsBtns.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlFindingsBtns.Controls.Add(this.btnHelpFindings);
            this.pnlFindingsBtns.Controls.Add(this.tsRxnFindings);
            this.pnlFindingsBtns.Controls.Add(this.btnAutoFindingsNew);
            this.pnlFindingsBtns.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlFindingsBtns.Location = new System.Drawing.Point(0, 0);
            this.pnlFindingsBtns.Name = "pnlFindingsBtns";
            this.pnlFindingsBtns.Size = new System.Drawing.Size(1015, 27);
            this.pnlFindingsBtns.TabIndex = 18;
            // 
            // btnHelpFindings
            // 
            this.btnHelpFindings.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHelpFindings.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHelpFindings.Location = new System.Drawing.Point(291, 0);
            this.btnHelpFindings.Name = "btnHelpFindings";
            this.btnHelpFindings.Size = new System.Drawing.Size(31, 24);
            this.btnHelpFindings.TabIndex = 209;
            this.btnHelpFindings.Text = "?";
            this.toolTip1.SetToolTip(this.btnHelpFindings, "Finding Types Help");
            this.btnHelpFindings.UseVisualStyleBackColor = true;
            this.btnHelpFindings.Click += new System.EventHandler(this.btnHelpFindings_Click);
            // 
            // tsRxnFindings
            // 
            this.tsRxnFindings.Dock = System.Windows.Forms.DockStyle.Left;
            this.tsRxnFindings.GripMargin = new System.Windows.Forms.Padding(0);
            this.tsRxnFindings.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tsRxnFindings.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbAddFinding,
            this.toolStripSeparator3,
            this.tsbDeleteFinding});
            this.tsRxnFindings.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.tsRxnFindings.Location = new System.Drawing.Point(0, 0);
            this.tsRxnFindings.Name = "tsRxnFindings";
            this.tsRxnFindings.Size = new System.Drawing.Size(273, 25);
            this.tsRxnFindings.TabIndex = 74;
            this.tsRxnFindings.Text = "toolStrip1";
            // 
            // tsbAddFinding
            // 
            this.tsbAddFinding.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsbAddFinding.Image = global::IndxReactNarr.Properties.Resources.add;
            this.tsbAddFinding.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAddFinding.Name = "tsbAddFinding";
            this.tsbAddFinding.Size = new System.Drawing.Size(124, 20);
            this.tsbAddFinding.Text = "Add Rxn Finding";
            this.tsbAddFinding.Click += new System.EventHandler(this.tsbAddFinding_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 23);
            // 
            // tsbDeleteFinding
            // 
            this.tsbDeleteFinding.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsbDeleteFinding.Image = global::IndxReactNarr.Properties.Resources.close_box_red;
            this.tsbDeleteFinding.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbDeleteFinding.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDeleteFinding.Margin = new System.Windows.Forms.Padding(1);
            this.tsbDeleteFinding.Name = "tsbDeleteFinding";
            this.tsbDeleteFinding.Padding = new System.Windows.Forms.Padding(1);
            this.tsbDeleteFinding.Size = new System.Drawing.Size(140, 22);
            this.tsbDeleteFinding.Text = "Delete Rxn Finding";
            this.tsbDeleteFinding.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tsbDeleteFinding.ToolTipText = "Delete selected Finding";
            this.tsbDeleteFinding.Click += new System.EventHandler(this.tsbDeleteFinding_Click);
            // 
            // btnAutoFindingsNew
            // 
            this.btnAutoFindingsNew.Image = global::IndxReactNarr.Properties.Resources.split;
            this.btnAutoFindingsNew.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnAutoFindingsNew.Location = new System.Drawing.Point(333, 0);
            this.btnAutoFindingsNew.Name = "btnAutoFindingsNew";
            this.btnAutoFindingsNew.Size = new System.Drawing.Size(166, 24);
            this.btnAutoFindingsNew.TabIndex = 16;
            this.btnAutoFindingsNew.Text = "Auto Findings Testing";
            this.btnAutoFindingsNew.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.toolTip1.SetToolTip(this.btnAutoFindingsNew, "Auto Findings");
            this.btnAutoFindingsNew.UseVisualStyleBackColor = true;
            this.btnAutoFindingsNew.Click += new System.EventHandler(this.btnAutoFindingsNew_Click);
            // 
            // pnlCounts
            // 
            this.pnlCounts.BackColor = System.Drawing.Color.Ivory;
            this.pnlCounts.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCounts.Controls.Add(this.chkMappingUpdate);
            this.pnlCounts.Controls.Add(this.lblRxnFindingsCnt);
            this.pnlCounts.Controls.Add(this.label4);
            this.pnlCounts.Controls.Add(this.lblProcStepCount);
            this.pnlCounts.Controls.Add(this.label1);
            this.pnlCounts.Controls.Add(this.label5);
            this.pnlCounts.Controls.Add(this.lblDataCnt);
            this.pnlCounts.Controls.Add(this.lblParaCnt);
            this.pnlCounts.Controls.Add(this.label3);
            this.pnlCounts.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlCounts.Location = new System.Drawing.Point(0, 467);
            this.pnlCounts.Name = "pnlCounts";
            this.pnlCounts.Size = new System.Drawing.Size(1027, 25);
            this.pnlCounts.TabIndex = 204;
            // 
            // chkMappingUpdate
            // 
            this.chkMappingUpdate.AutoSize = true;
            this.chkMappingUpdate.Dock = System.Windows.Forms.DockStyle.Right;
            this.chkMappingUpdate.Location = new System.Drawing.Point(897, 0);
            this.chkMappingUpdate.Name = "chkMappingUpdate";
            this.chkMappingUpdate.Size = new System.Drawing.Size(128, 23);
            this.chkMappingUpdate.TabIndex = 77;
            this.chkMappingUpdate.Text = "Mapping Updated";
            this.chkMappingUpdate.UseVisualStyleBackColor = true;
            // 
            // lblRxnFindingsCnt
            // 
            this.lblRxnFindingsCnt.AutoSize = true;
            this.lblRxnFindingsCnt.BackColor = System.Drawing.Color.Transparent;
            this.lblRxnFindingsCnt.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnFindingsCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblRxnFindingsCnt.Location = new System.Drawing.Point(666, 4);
            this.lblRxnFindingsCnt.Name = "lblRxnFindingsCnt";
            this.lblRxnFindingsCnt.Size = new System.Drawing.Size(15, 15);
            this.lblRxnFindingsCnt.TabIndex = 76;
            this.lblRxnFindingsCnt.Text = "--";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(509, 4);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(149, 15);
            this.label4.TabIndex = 75;
            this.label4.Text = "Reaction Findings Count: ";
            // 
            // lblProcStepCount
            // 
            this.lblProcStepCount.AutoSize = true;
            this.lblProcStepCount.BackColor = System.Drawing.Color.Transparent;
            this.lblProcStepCount.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProcStepCount.ForeColor = System.Drawing.Color.Blue;
            this.lblProcStepCount.Location = new System.Drawing.Point(453, 4);
            this.lblProcStepCount.Name = "lblProcStepCount";
            this.lblProcStepCount.Size = new System.Drawing.Size(15, 15);
            this.lblProcStepCount.TabIndex = 72;
            this.lblProcStepCount.Text = "--";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(3, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 15);
            this.label1.TabIndex = 71;
            this.label1.Text = "Para Count: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(312, 4);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(141, 15);
            this.label5.TabIndex = 71;
            this.label5.Text = "Procedure Steps Count: ";
            // 
            // lblDataCnt
            // 
            this.lblDataCnt.AutoSize = true;
            this.lblDataCnt.BackColor = System.Drawing.Color.Transparent;
            this.lblDataCnt.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblDataCnt.Location = new System.Drawing.Point(251, 4);
            this.lblDataCnt.Name = "lblDataCnt";
            this.lblDataCnt.Size = new System.Drawing.Size(15, 15);
            this.lblDataCnt.TabIndex = 74;
            this.lblDataCnt.Text = "--";
            // 
            // lblParaCnt
            // 
            this.lblParaCnt.AutoSize = true;
            this.lblParaCnt.BackColor = System.Drawing.Color.Transparent;
            this.lblParaCnt.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParaCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblParaCnt.Location = new System.Drawing.Point(84, 4);
            this.lblParaCnt.Name = "lblParaCnt";
            this.lblParaCnt.Size = new System.Drawing.Size(15, 15);
            this.lblParaCnt.TabIndex = 72;
            this.lblParaCnt.Text = "--";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(170, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 15);
            this.label3.TabIndex = 73;
            this.label3.Text = "Data Count: ";
            // 
            // pnlNumInfo
            // 
            this.pnlNumInfo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlNumInfo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlNumInfo.Controls.Add(this.chkEmptyPgLabel);
            this.pnlNumInfo.Controls.Add(this.txtDocRefFileName);
            this.pnlNumInfo.Controls.Add(this.lblSeq);
            this.pnlNumInfo.Controls.Add(this.lblreactioncasreactonnumber);
            this.pnlNumInfo.Controls.Add(this.txtRxnNum);
            this.pnlNumInfo.Controls.Add(this.txtDocRef);
            this.pnlNumInfo.Controls.Add(this.txtPageNo);
            this.pnlNumInfo.Controls.Add(this.txtRxnSeq);
            this.pnlNumInfo.Controls.Add(this.txtPageLabel);
            this.pnlNumInfo.Controls.Add(this.txtOffset_Y);
            this.pnlNumInfo.Controls.Add(this.lbldocref);
            this.pnlNumInfo.Controls.Add(this.lblYoffSet);
            this.pnlNumInfo.Controls.Add(this.txtOffset_X);
            this.pnlNumInfo.Controls.Add(this.lblfilename);
            this.pnlNumInfo.Controls.Add(this.lblXoffSet);
            this.pnlNumInfo.Controls.Add(this.txtPageSize_Y);
            this.pnlNumInfo.Controls.Add(this.txtPageSize_X);
            this.pnlNumInfo.Controls.Add(this.lblYPageSize);
            this.pnlNumInfo.Controls.Add(this.lblPageNumber);
            this.pnlNumInfo.Controls.Add(this.lblpglabel);
            this.pnlNumInfo.Controls.Add(this.lblXPageSize);
            this.pnlNumInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlNumInfo.Location = new System.Drawing.Point(0, 0);
            this.pnlNumInfo.Name = "pnlNumInfo";
            this.pnlNumInfo.Size = new System.Drawing.Size(1027, 30);
            this.pnlNumInfo.TabIndex = 201;
            // 
            // chkEmptyPgLabel
            // 
            this.chkEmptyPgLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chkEmptyPgLabel.AutoSize = true;
            this.chkEmptyPgLabel.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkEmptyPgLabel.Location = new System.Drawing.Point(554, 5);
            this.chkEmptyPgLabel.Name = "chkEmptyPgLabel";
            this.chkEmptyPgLabel.Size = new System.Drawing.Size(94, 19);
            this.chkEmptyPgLabel.TabIndex = 103;
            this.chkEmptyPgLabel.Text = "No Pg.Label";
            this.chkEmptyPgLabel.UseVisualStyleBackColor = true;
            this.chkEmptyPgLabel.CheckedChanged += new System.EventHandler(this.chkEmptyPgLabel_CheckedChanged);
            // 
            // txtDocRefFileName
            // 
            this.txtDocRefFileName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDocRefFileName.BackColor = System.Drawing.Color.FloralWhite;
            this.txtDocRefFileName.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDocRefFileName.Location = new System.Drawing.Point(231, 3);
            this.txtDocRefFileName.Name = "txtDocRefFileName";
            this.txtDocRefFileName.ReadOnly = true;
            this.txtDocRefFileName.Size = new System.Drawing.Size(118, 21);
            this.txtDocRefFileName.TabIndex = 2;
            // 
            // lblSeq
            // 
            this.lblSeq.AutoSize = true;
            this.lblSeq.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSeq.ForeColor = System.Drawing.Color.Crimson;
            this.lblSeq.Location = new System.Drawing.Point(70, 6);
            this.lblSeq.Name = "lblSeq";
            this.lblSeq.Size = new System.Drawing.Size(29, 15);
            this.lblSeq.TabIndex = 10;
            this.lblSeq.Text = "Seq";
            // 
            // lblreactioncasreactonnumber
            // 
            this.lblreactioncasreactonnumber.AutoSize = true;
            this.lblreactioncasreactonnumber.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblreactioncasreactonnumber.ForeColor = System.Drawing.Color.Crimson;
            this.lblreactioncasreactonnumber.Location = new System.Drawing.Point(-2, 6);
            this.lblreactioncasreactonnumber.Name = "lblreactioncasreactonnumber";
            this.lblreactioncasreactonnumber.Size = new System.Drawing.Size(34, 15);
            this.lblreactioncasreactonnumber.TabIndex = 4;
            this.lblreactioncasreactonnumber.Text = "Num";
            this.lblreactioncasreactonnumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtRxnNum
            // 
            this.txtRxnNum.BackColor = System.Drawing.Color.FloralWhite;
            this.txtRxnNum.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRxnNum.ForeColor = System.Drawing.Color.Blue;
            this.txtRxnNum.Location = new System.Drawing.Point(35, 3);
            this.txtRxnNum.Name = "txtRxnNum";
            this.txtRxnNum.ReadOnly = true;
            this.txtRxnNum.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtRxnNum.Size = new System.Drawing.Size(32, 21);
            this.txtRxnNum.TabIndex = 100;
            this.txtRxnNum.Text = "0";
            // 
            // txtDocRef
            // 
            this.txtDocRef.BackColor = System.Drawing.Color.FloralWhite;
            this.txtDocRef.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDocRef.ForeColor = System.Drawing.Color.Blue;
            this.txtDocRef.Location = new System.Drawing.Point(162, 3);
            this.txtDocRef.Name = "txtDocRef";
            this.txtDocRef.ReadOnly = true;
            this.txtDocRef.Size = new System.Drawing.Size(44, 21);
            this.txtDocRef.TabIndex = 1;
            // 
            // txtPageNo
            // 
            this.txtPageNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPageNo.BackColor = System.Drawing.Color.White;
            this.txtPageNo.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPageNo.Location = new System.Drawing.Point(408, 4);
            this.txtPageNo.MaxLength = 3;
            this.txtPageNo.Multiline = true;
            this.txtPageNo.Name = "txtPageNo";
            this.txtPageNo.Size = new System.Drawing.Size(32, 20);
            this.txtPageNo.TabIndex = 2;
            this.txtPageNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtpagenumber_KeyPress);
            // 
            // txtRxnSeq
            // 
            this.txtRxnSeq.BackColor = System.Drawing.Color.FloralWhite;
            this.txtRxnSeq.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRxnSeq.ForeColor = System.Drawing.Color.Blue;
            this.txtRxnSeq.Location = new System.Drawing.Point(101, 3);
            this.txtRxnSeq.Name = "txtRxnSeq";
            this.txtRxnSeq.ReadOnly = true;
            this.txtRxnSeq.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtRxnSeq.Size = new System.Drawing.Size(31, 21);
            this.txtRxnSeq.TabIndex = 102;
            this.txtRxnSeq.Text = "0";
            // 
            // txtPageLabel
            // 
            this.txtPageLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPageLabel.BackColor = System.Drawing.Color.White;
            this.txtPageLabel.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPageLabel.Location = new System.Drawing.Point(512, 3);
            this.txtPageLabel.MaxLength = 8;
            this.txtPageLabel.Name = "txtPageLabel";
            this.txtPageLabel.Size = new System.Drawing.Size(39, 21);
            this.txtPageLabel.TabIndex = 3;
            // 
            // txtOffset_Y
            // 
            this.txtOffset_Y.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOffset_Y.BackColor = System.Drawing.Color.PapayaWhip;
            this.txtOffset_Y.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOffset_Y.Location = new System.Drawing.Point(982, 4);
            this.txtOffset_Y.Multiline = true;
            this.txtOffset_Y.Name = "txtOffset_Y";
            this.txtOffset_Y.ReadOnly = true;
            this.txtOffset_Y.Size = new System.Drawing.Size(40, 20);
            this.txtOffset_Y.TabIndex = 7;
            this.txtOffset_Y.Click += new System.EventHandler(this.txtOffset_X_Click);
            this.txtOffset_Y.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtyoffset_KeyPress);
            // 
            // lbldocref
            // 
            this.lbldocref.AutoSize = true;
            this.lbldocref.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldocref.ForeColor = System.Drawing.Color.Crimson;
            this.lbldocref.Location = new System.Drawing.Point(133, 6);
            this.lbldocref.Name = "lbldocref";
            this.lbldocref.Size = new System.Drawing.Size(29, 15);
            this.lbldocref.TabIndex = 5;
            this.lbldocref.Text = "Doc";
            // 
            // lblYoffSet
            // 
            this.lblYoffSet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblYoffSet.AutoSize = true;
            this.lblYoffSet.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYoffSet.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblYoffSet.Location = new System.Drawing.Point(933, 7);
            this.lblYoffSet.Name = "lblYoffSet";
            this.lblYoffSet.Size = new System.Drawing.Size(49, 15);
            this.lblYoffSet.TabIndex = 7;
            this.lblYoffSet.Text = "Y Offset";
            // 
            // txtOffset_X
            // 
            this.txtOffset_X.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOffset_X.BackColor = System.Drawing.Color.PapayaWhip;
            this.txtOffset_X.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOffset_X.Location = new System.Drawing.Point(892, 4);
            this.txtOffset_X.Multiline = true;
            this.txtOffset_X.Name = "txtOffset_X";
            this.txtOffset_X.ReadOnly = true;
            this.txtOffset_X.Size = new System.Drawing.Size(40, 20);
            this.txtOffset_X.TabIndex = 6;
            this.txtOffset_X.Click += new System.EventHandler(this.txtOffset_X_Click);
            this.txtOffset_X.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtxoffset_KeyPress);
            // 
            // lblfilename
            // 
            this.lblfilename.AutoSize = true;
            this.lblfilename.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfilename.ForeColor = System.Drawing.Color.Crimson;
            this.lblfilename.Location = new System.Drawing.Point(205, 6);
            this.lblfilename.Name = "lblfilename";
            this.lblfilename.Size = new System.Drawing.Size(27, 15);
            this.lblfilename.TabIndex = 8;
            this.lblfilename.Text = "File";
            // 
            // lblXoffSet
            // 
            this.lblXoffSet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblXoffSet.AutoSize = true;
            this.lblXoffSet.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblXoffSet.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblXoffSet.Location = new System.Drawing.Point(843, 6);
            this.lblXoffSet.Name = "lblXoffSet";
            this.lblXoffSet.Size = new System.Drawing.Size(49, 15);
            this.lblXoffSet.TabIndex = 7;
            this.lblXoffSet.Text = "X Offset";
            // 
            // txtPageSize_Y
            // 
            this.txtPageSize_Y.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPageSize_Y.BackColor = System.Drawing.Color.MistyRose;
            this.txtPageSize_Y.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPageSize_Y.Location = new System.Drawing.Point(803, 4);
            this.txtPageSize_Y.Multiline = true;
            this.txtPageSize_Y.Name = "txtPageSize_Y";
            this.txtPageSize_Y.ReadOnly = true;
            this.txtPageSize_Y.Size = new System.Drawing.Size(40, 20);
            this.txtPageSize_Y.TabIndex = 5;
            this.txtPageSize_Y.Click += new System.EventHandler(this.txtPageSize_X_Click);
            this.txtPageSize_Y.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtypagesize_KeyPress);
            // 
            // txtPageSize_X
            // 
            this.txtPageSize_X.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPageSize_X.BackColor = System.Drawing.Color.MistyRose;
            this.txtPageSize_X.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPageSize_X.Location = new System.Drawing.Point(705, 4);
            this.txtPageSize_X.Multiline = true;
            this.txtPageSize_X.Name = "txtPageSize_X";
            this.txtPageSize_X.ReadOnly = true;
            this.txtPageSize_X.Size = new System.Drawing.Size(40, 20);
            this.txtPageSize_X.TabIndex = 4;
            this.txtPageSize_X.Click += new System.EventHandler(this.txtPageSize_X_Click);
            this.txtPageSize_X.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtxpagesize_KeyPress);
            // 
            // lblYPageSize
            // 
            this.lblYPageSize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblYPageSize.AutoSize = true;
            this.lblYPageSize.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYPageSize.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblYPageSize.Location = new System.Drawing.Point(747, 6);
            this.lblYPageSize.Name = "lblYPageSize";
            this.lblYPageSize.Size = new System.Drawing.Size(58, 15);
            this.lblYPageSize.TabIndex = 6;
            this.lblYPageSize.Text = "Y Pg.Size";
            // 
            // lblPageNumber
            // 
            this.lblPageNumber.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblPageNumber.AutoSize = true;
            this.lblPageNumber.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageNumber.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblPageNumber.Location = new System.Drawing.Point(351, 6);
            this.lblPageNumber.Name = "lblPageNumber";
            this.lblPageNumber.Size = new System.Drawing.Size(58, 15);
            this.lblPageNumber.TabIndex = 0;
            this.lblPageNumber.Text = "Page No.";
            // 
            // lblpglabel
            // 
            this.lblpglabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblpglabel.AutoSize = true;
            this.lblpglabel.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpglabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblpglabel.Location = new System.Drawing.Point(443, 6);
            this.lblpglabel.Name = "lblpglabel";
            this.lblpglabel.Size = new System.Drawing.Size(70, 15);
            this.lblpglabel.TabIndex = 0;
            this.lblpglabel.Text = "Page Label";
            // 
            // lblXPageSize
            // 
            this.lblXPageSize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblXPageSize.AutoSize = true;
            this.lblXPageSize.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblXPageSize.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblXPageSize.Location = new System.Drawing.Point(649, 6);
            this.lblXPageSize.Name = "lblXPageSize";
            this.lblXPageSize.Size = new System.Drawing.Size(58, 15);
            this.lblXPageSize.TabIndex = 6;
            this.lblXPageSize.Text = "X Pg.Size";
            // 
            // tb1rtxteditor
            // 
            this.tb1rtxteditor.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb1rtxteditor.BackColor = System.Drawing.Color.White;
            this.tb1rtxteditor.DefaultComposeSettings.BackColor = System.Drawing.Color.White;
            this.tb1rtxteditor.DefaultComposeSettings.DefaultFont = new System.Drawing.Font("Arial", 10F);
            this.tb1rtxteditor.DefaultComposeSettings.Enabled = false;
            this.tb1rtxteditor.DefaultComposeSettings.ForeColor = System.Drawing.Color.Black;
            this.tb1rtxteditor.DocumentEncoding = onlyconnect.EncodingType.WindowsCurrent;
            this.tb1rtxteditor.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb1rtxteditor.IsDesignMode = true;
            this.tb1rtxteditor.Location = new System.Drawing.Point(117, 181);
            this.tb1rtxteditor.Margin = new System.Windows.Forms.Padding(10);
            this.tb1rtxteditor.Name = "tb1rtxteditor";
            this.tb1rtxteditor.OpenLinksInNewWindow = true;
            this.tb1rtxteditor.SelectionAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb1rtxteditor.SelectionBackColor = System.Drawing.Color.Empty;
            this.tb1rtxteditor.SelectionBullets = false;
            this.tb1rtxteditor.SelectionFont = null;
            this.tb1rtxteditor.SelectionForeColor = System.Drawing.Color.Empty;
            this.tb1rtxteditor.SelectionNumbering = false;
            this.tb1rtxteditor.Size = new System.Drawing.Size(793, 131);
            this.tb1rtxteditor.TabIndex = 66;
            this.tb1rtxteditor.Visible = false;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.BackColor = System.Drawing.Color.White;
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyXYOffsetsTSMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(160, 26);
            // 
            // copyXYOffsetsTSMenuItem
            // 
            this.copyXYOffsetsTSMenuItem.BackColor = System.Drawing.Color.White;
            this.copyXYOffsetsTSMenuItem.Name = "copyXYOffsetsTSMenuItem";
            this.copyXYOffsetsTSMenuItem.Size = new System.Drawing.Size(159, 22);
            this.copyXYOffsetsTSMenuItem.Text = "Copy XY Offsets";
            this.copyXYOffsetsTSMenuItem.Click += new System.EventHandler(this.copyXYOffsetsTSMenuItem_Click);
            // 
            // ucExpProceduresCuration
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ContextMenuStrip = this.contextMenuStrip2;
            this.Controls.Add(this.pnlMain);
            this.Name = "ucExpProceduresCuration";
            this.Size = new System.Drawing.Size(1027, 492);
            this.pnlMain.ResumeLayout(false);
            this.splContNarrCntrl_Tabs.Panel1.ResumeLayout(false);
            this.splContNarrCntrl_Tabs.Panel1.PerformLayout();
            this.splContNarrCntrl_Tabs.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splContNarrCntrl_Tabs)).EndInit();
            this.splContNarrCntrl_Tabs.ResumeLayout(false);
            this.tcProc_DataText.ResumeLayout(false);
            this.tpPara.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tsControls_Para.ResumeLayout(false);
            this.tsControls_Para.PerformLayout();
            this.tpData.ResumeLayout(false);
            this.pnlDataCntrls.ResumeLayout(false);
            this.pnlDataCntrls.PerformLayout();
            this.tsControls_Data.ResumeLayout(false);
            this.tsControls_Data.PerformLayout();
            this.tpProcedure.ResumeLayout(false);
            this.splContProcSteps.Panel1.ResumeLayout(false);
            this.splContProcSteps.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splContProcSteps)).EndInit();
            this.splContProcSteps.ResumeLayout(false);
            this.tpRxnFindings_New.ResumeLayout(false);
            this.splContRxnFindingsNew.Panel1.ResumeLayout(false);
            this.splContRxnFindingsNew.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splContRxnFindingsNew)).EndInit();
            this.splContRxnFindingsNew.ResumeLayout(false);
            this.pnlFindingsBtns.ResumeLayout(false);
            this.pnlFindingsBtns.PerformLayout();
            this.tsRxnFindings.ResumeLayout(false);
            this.tsRxnFindings.PerformLayout();
            this.pnlCounts.ResumeLayout(false);
            this.pnlCounts.PerformLayout();
            this.pnlNumInfo.ResumeLayout(false);
            this.pnlNumInfo.PerformLayout();
            this.contextMenuStrip2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblNarId;
        private System.Windows.Forms.Label lblTextLine;
        private System.Windows.Forms.Label lblYoffSet;
        private System.Windows.Forms.Label lblpglabel;
        private System.Windows.Forms.Label lblYPageSize;
        private System.Windows.Forms.Label lblXoffSet;
        private System.Windows.Forms.Label lblXPageSize;
        private System.Windows.Forms.Label lblPageNumber;
        private System.Windows.Forms.Label lblreactioncasreactonnumber;
        private System.Windows.Forms.Label lbldocref;
        private System.Windows.Forms.Label lblfilename;
        private System.Windows.Forms.Label lblSeq;
        public System.Windows.Forms.TextBox txtNarrID;
        public System.Windows.Forms.TextBox txtOffset_Y;
        public System.Windows.Forms.TextBox txtPageSize_Y;
        public System.Windows.Forms.TextBox txtPageLabel;
        public System.Windows.Forms.TextBox txtOffset_X;
        public System.Windows.Forms.TextBox txtPageSize_X;
        public System.Windows.Forms.TextBox txtPageNo;
        public System.Windows.Forms.TextBox txtRxnSeq;
        public System.Windows.Forms.TextBox txtRxnNum;
        public System.Windows.Forms.TextBox txtDocRefFileName;
        public System.Windows.Forms.TextBox txtDocRef;
        private onlyconnect.HtmlEditor tb1rtxteditor;
        public System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem copyXYOffsetsTSMenuItem;
        public System.Windows.Forms.ComboBox cmbAnalogousTo;
        private System.Windows.Forms.Panel pnlNumInfo;
        public System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label lblParaCnt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblDataCnt;
        private System.Windows.Forms.Label label3;
        public UserControls.ucHtmlRichText ucHrtbTextLine;
        private System.Windows.Forms.RadioButton rbnMissingRxn;
        private System.Windows.Forms.RadioButton rbnExpProcedure;
        private System.Windows.Forms.RadioButton rbnAnalogousTo;
        private System.Windows.Forms.RadioButton rbnNoExpDetails;
        private System.Windows.Forms.RadioButton rbnGeneralTypical;
        private System.Windows.Forms.Label lblYieldText;
        public UserControls.ucHtmlRichText uchrtbYieldText;
        private System.Windows.Forms.TabControl tcProc_DataText;
        private System.Windows.Forms.TabPage tpProcedure;
        private UserControls.ucHtmlRichText uchrtbProcSteps;
        private System.Windows.Forms.TabPage tpPara;
        private System.Windows.Forms.Label lblProcStepCount;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel pnlCounts;
        private System.Windows.Forms.Label lblRxnFindingsCnt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabPage tpData;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStrip tsControls_Para;
        private System.Windows.Forms.ToolStripButton tsbtnDeletePara;
        private System.Windows.Forms.FlowLayoutPanel flPnlPara;
        private System.Windows.Forms.ToolStripButton tsbtnAddPara;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.Panel pnlDataCntrls;
        private System.Windows.Forms.ToolStrip tsControls_Data;
        private System.Windows.Forms.ToolStripButton tsbtnAddData;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton tsbtnDeleteData;
        private System.Windows.Forms.FlowLayoutPanel flPnlData;
        private System.Windows.Forms.SplitContainer splContNarrCntrl_Tabs;
        private System.Windows.Forms.SplitContainer splContProcSteps;
        public UserControls.ucHtmlRichText uchrtbReferencePara;
        private System.Windows.Forms.Label lblRefPara;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnHelpFindings;
        private System.Windows.Forms.TabPage tpRxnFindings_New;
        private System.Windows.Forms.SplitContainer splContRxnFindingsNew;
        public UserControls.ucHtmlRichText uchrtbDataForFindings_New;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnAutoFindingsNew;
        private System.Windows.Forms.FlowLayoutPanel flPnlRxnFindings;
        private System.Windows.Forms.Panel pnlFindingsBtns;
        private System.Windows.Forms.ToolStrip tsRxnFindings;
        private System.Windows.Forms.ToolStripButton tsbAddFinding;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton tsbDeleteFinding;
        public System.Windows.Forms.CheckBox chkEmptyPgLabel;
        public System.Windows.Forms.CheckBox chkMappingUpdate;
    }
}
