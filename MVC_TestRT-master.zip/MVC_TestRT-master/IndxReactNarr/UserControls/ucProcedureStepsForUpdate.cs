﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;

namespace IndxReactNarr.UserControls
{
    public partial class ucProcedureStepsForUpdate : UserControl
    {
        public ucProcedureStepsForUpdate()
        {
            InitializeComponent();
        }

        public int RxnID { get; set; }

        public DataTable RxnSubstances { get; set; }

        public string ProcedureStepsValue { get; set; }

        public void BindProcedureStepsDataToControls()
        {
            try
            {
                uchrtbProcedureSteps.BindDataToControl(ProcedureStepsValue);

                if (RxnSubstances != null)
                {
                    dgvRxnSubsts.AutoGenerateColumns = false;
                    dgvRxnSubsts.DataSource = RxnSubstances;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
