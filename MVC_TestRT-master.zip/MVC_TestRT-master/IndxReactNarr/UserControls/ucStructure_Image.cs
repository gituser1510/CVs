﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace IndxReactNarr
{
    public partial class ucStructure_Image : UserControl
    {
        public ucStructure_Image()
        {
            InitializeComponent();
        }

        private string _absstereo = "";
        public string StereoChem
        {
            get
            { return _absstereo; }
            set
            {
                _absstereo = value;
                lblStereoChem.Text = _absstereo;
            }
        }

        private string _molformula = "";
        public string MolFormula
        {
            get
            { return _molformula; }
            set
            {
                _molformula = value;
                lblMolFormula.Text = _molformula;
            }
        }

        private Image _chemimage = null;
        public Image ChemImage
        {
            get
            { return _chemimage; }
            set
            {
                _chemimage = value;
                pbChemImg.Image = _chemimage;
            }
        }
    }
}
