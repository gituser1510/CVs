﻿
#region Namespaces

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarrDAL;
using IndxReactNarr.Common;
using IndxReactNarr.Generic;
using IndxReactNarrBll;

#endregion

namespace IndxReactNarr
{
    public partial class ucParticipants : UserControl
    {
        #region Constructor
        
        public ucParticipants()
        {
            InitializeComponent();
        }

        #endregion

        #region Property Procedures

        public int RxnStageID
        {
            get;
            set;
        }

        public int ReactionID
        {
            get;
            set;
        }

        public int TAN_ID
        {
            get;
            set;
        }

        public string TAN_Name
        {
            get; set;
        }

        public int RXNNUM
        {
            get; set;
        }

        public string StageName
        {
            get;
            set;
        }
               
        public DataTable NUM_RegNosTbl
        { get; set; }

        public bool TAN_Freezed
        {
            get;
            set;
        }

        #endregion
      
        #region public variables
      
        public DataTable dtAgent = null;
        public DataTable dtSolvent = null;
        public DataTable dtCatalyst = null;
        public DataTable dtRSN = null;
        public DataTable dtConditions = null;
        public DataTable dtReactant = null;

        public TextBox txtReactNRNReg;
        public TextBox txtReactNRNNum;
        public TextBox txtReactNRN_Name;

        #endregion
       
        #region Load Event
        
        private void ucParticipants_Load(object sender, EventArgs e)
        {
            try
            {
                BindParticipantsDataToGrids();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }          
        }

        #endregion
        
        #region Methods
                                 
        public void BindParticipantsDataToGrids()
        {
            try
            {
                //Reactants Data
                if (dtReactant == null)
                {
                    dtReactant = GetParticipantsTableDefinition();
                }
                                                 
                dtReactant.TableName = Generic.Enums.ParticipantType.REACTANT.ToString();
                BindDataToParticipantGrid(dgvReactant, dtReactant, "R");
                
                //Agents Data
                if (dtAgent == null)
                {
                    dtAgent = GetParticipantsTableDefinition();
                }
                dtAgent.TableName = Generic.Enums.ParticipantType.AGENT.ToString();
                BindDataToParticipantGrid(dgvAgent, dtAgent, "A");
                

                //Catalyst Data
                if (dtCatalyst == null)
                {
                    dtCatalyst = GetParticipantsTableDefinition();
                }
                dtCatalyst.TableName = Generic.Enums.ParticipantType.CATALYST.ToString();
                BindDataToParticipantGrid(dgvCatalyst, dtCatalyst, "C");
                

                //Solvents Data
                if (dtSolvent == null)
                {
                    dtSolvent = GetParticipantsTableDefinition();
                }
                dtSolvent.TableName = Generic.Enums.ParticipantType.SOLVENT.ToString();
                BindDataToParticipantGrid(dgvSolvent, dtSolvent, "S");
               
                //Conditions Data
                if (dtConditions == null)
                {
                    dtConditions = GetConditionsTableDefinition();
                }
                BindDataToConditionsGrid(dtConditions);
               
                //RSN Data
                if (dtRSN == null)
                {
                    dtRSN = GetRSNTableDefinition();
                }
                BindDataToRSNGrid(dtRSN);

                //Once TAN is Freezed user can't modify anything in the TAN, Only Administrator can modify
                if (TAN_Freezed)
                {
                    if (GlobalVariables.RoleName.ToUpper() == RolesMaster.ADMIN.ToUpper())
                    {
                        this.Enabled = true;
                    }
                    else
                    {
                        this.Enabled = false;
                    }
                }
                else
                {
                    this.Enabled = true;
                }

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindDataToParticipantGrid(DataGridView partpntgrid, DataTable partpantsata,string srcgrid)
        {
            try
            {
                if (partpantsata != null)
                {
                    partpntgrid.AutoGenerateColumns = false;
                    partpntgrid.DataSource = partpantsata;

                    #region Main code commented
                    //partpntgrid.Columns[srcgrid + "_RPP_ID"].DataPropertyName = "RPP_ID";

                    //partpntgrid.Columns[srcgrid + "_Name"].DataPropertyName = "PP_NAME";
                    //partpntgrid.Columns[srcgrid + "_Name"].ReadOnly = true;                    

                    //partpntgrid.Columns[srcgrid + "_Num"].DataPropertyName = "SERIES_NUM";
                    //partpntgrid.Columns[srcgrid + "_Num"].ReadOnly = true;                   

                    //partpntgrid.Columns[srcgrid + "_9000"].DataPropertyName = "SERIES_9000";
                    //partpntgrid.Columns[srcgrid + "_9000"].ReadOnly = true;                   

                    //partpntgrid.Columns[srcgrid + "_8500"].DataPropertyName = "SERIES_8500";
                    //partpntgrid.Columns[srcgrid + "_8500"].ReadOnly = true;                    

                    //partpntgrid.Columns[srcgrid + "_8000"].DataPropertyName = "SERIES_8000";
                    //partpntgrid.Columns[srcgrid + "_8000"].ReadOnly = true;

                    //partpntgrid.Columns[srcgrid + "_Mol"].DataPropertyName = srcgrid + "_Mol";
                    //partpntgrid.Columns[srcgrid + "_NrnReg"].DataPropertyName = "REG_NO";
                    ////partpntgrid.Columns[srcgrid + "_Subst_Num"].DataPropertyName = "subst_num";
                    //partpntgrid.Columns[srcgrid + "_Subst_Name"].DataPropertyName = "SUBST_NAME";
                    //partpntgrid.Columns[srcgrid + "_Subst_Loc"].DataPropertyName = "SUBST_LOC";
                    //partpntgrid.Columns[srcgrid + "_Subst_Molecule"].DataPropertyName = "SUBST_MOLECULE";
                    //partpntgrid.Columns[srcgrid + "_Subst_Mol_Img"].DataPropertyName = "STRUCT_IMAGE";
                    //partpntgrid.Columns[srcgrid + "_Author_Name"].DataPropertyName = "SUBST_AUTHOR_NAME";
                    //partpntgrid.Columns[srcgrid + "_Other_Name"].DataPropertyName = "SUBST_OTHER_NAME"; 
                    #endregion

                    partpntgrid.Columns[srcgrid + "_RPP_ID"].DataPropertyName = "RPP_ID";
                    partpntgrid.Columns[srcgrid + "_Name"].DataPropertyName = "PP_NAME";
                    partpntgrid.Columns[srcgrid + "_Name"].ReadOnly = true;

                    partpntgrid.Columns[srcgrid + "_Num"].DataPropertyName = "SERIES_NUM";
                    partpntgrid.Columns[srcgrid + "_Num"].ReadOnly = true;
                    partpntgrid.Columns[srcgrid + "_NumType"].DataPropertyName = "SER_TYPE";
                    partpntgrid.Columns[srcgrid + "_SER_NUM_ID"].DataPropertyName = "SER_TAN_NUM_ID";

                    partpntgrid.Columns[srcgrid + "_NrnReg"].DataPropertyName = "REG_NO";
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void BindDataToRSNGrid(DataTable rsndata)
        {
            try
            {
                if (rsndata != null)
                {
                    dgvRSN.AutoGenerateColumns = false;
                    dgvRSN.DataSource = rsndata;

                    colRSN_ID.DataPropertyName = "RSN_ID";
                    colRSN_ID.Visible = false;

                    colCVT.DataPropertyName = "CVT";
                    colFreeText.DataPropertyName = "FREE_TEXT";
                    colRSNLevel.DataPropertyName = "NOTE_LEVEL";                     
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void BindDataToConditionsGrid(DataTable condsdata)
        {
            try
            {
                if (condsdata != null)
                {
                    dgvConditions.AutoGenerateColumns = false;
                    dgvConditions.DataSource = condsdata;

                    colTemperature.DataPropertyName = "TEMPERATURE";
                    colTime.DataPropertyName = "RC_TIME";
                    colPressure.DataPropertyName = "PRESSURE";
                    colPH.DataPropertyName = "PH";         
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        #region Get Participant/Conditions/RSN Table Definitions

        private DataTable GetParticipantsTableDefinition()
        {
            DataTable dtPartspnt = new DataTable();
            try
            {
                dtPartspnt.Columns.Add("RPP_ID", typeof(Int32));
                dtPartspnt.Columns.Add("RXN_ID", typeof(Int32));                
                dtPartspnt.Columns.Add("RXN_STAGE_ID", typeof(Int32));
                dtPartspnt.Columns.Add("PP_TYPE", typeof(string));
                dtPartspnt.Columns.Add("PP_NAME", typeof(string));
                dtPartspnt.Columns.Add("SER_TYPE", typeof(string));
                dtPartspnt.Columns.Add("REG_NO", typeof(string));
                dtPartspnt.Columns.Add("SERIES_NUM", typeof(Int32));
                dtPartspnt.Columns.Add("SER_TAN_NUM_ID", typeof(Int32));
                dtPartspnt.Columns.Add("DISPLAY_ORDER", typeof(Int32));
                return dtPartspnt;         

                #region Old code commented on 26th June 2014
                //dtPartspnt.Columns.Add("STRUCT_MOLFILE", typeof(object));
                //dtPartspnt.Columns.Add(_chemcol, typeof(Image));
                //dtPartspnt.Columns.Add("REG_NO", typeof(string));
                //dtPartspnt.Columns.Add("PP_TYPE", typeof(string));
                //dtPartspnt.Columns.Add("SERIES_NUM", typeof(Int32));
                //dtPartspnt.Columns.Add("SERIES_9000", typeof(Int32));
                //dtPartspnt.Columns.Add("SERIES_8500", typeof(Int32));
                //dtPartspnt.Columns.Add("SERIES_8000", typeof(Int32));                
                ////dtPartspnt.Columns.Add("Subst_num", typeof(Int32));
                //dtPartspnt.Columns.Add("SUBST_NAME", typeof(string));
                //dtPartspnt.Columns.Add("SUBST_LOC", typeof(string));
                //dtPartspnt.Columns.Add("SUBST_AUTHOR_NAME", typeof(string));
                //dtPartspnt.Columns.Add("SUBST_OTHER_NAME", typeof(string));
                //dtPartspnt.Columns.Add("SUBST_MOLECULE", typeof(object));
                //dtPartspnt.Columns.Add("STRUCT_IMAGE", typeof(Image)); 
                #endregion             
                                      
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtPartspnt;
        }

        private DataTable GetConditionsTableDefinition()
        {
            DataTable dtConditions = new DataTable();
            try
            {
                dtConditions.Columns.Add("RXN_ID", typeof(Int32));
                dtConditions.Columns.Add("RC_ID", typeof(Int32));
                dtConditions.Columns.Add("RXN_STAGE_ID", typeof(Int32));              
                dtConditions.Columns.Add("TEMPERATURE", typeof(string));
                dtConditions.Columns.Add("PRESSURE", typeof(string));
                dtConditions.Columns.Add("PH", typeof(string));
                dtConditions.Columns.Add("RC_TIME", typeof(string));

                dtConditions.Columns.Add("TEMP_TYPE", typeof(string));
                dtConditions.Columns.Add("TIME_TYPE", typeof(string));
                dtConditions.Columns.Add("PH_TYPE", typeof(string));
                dtConditions.Columns.Add("PRESSURE_TYPE", typeof(string));

                dtConditions.Columns.Add("DISPLAY_ORDER", typeof(Int32));

                return dtConditions;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtConditions;
        }

        private DataTable GetRSNTableDefinition()
        {
            DataTable dtRSN = new DataTable();
            try
            {
                dtRSN.Columns.Add("RXN_ID", typeof(Int32));
                dtRSN.Columns.Add("RXN_STAGE_ID", typeof(Int32));
                dtRSN.Columns.Add("RSN_ID", typeof(Int32));
                dtRSN.Columns.Add("CVT", typeof(string));
                dtRSN.Columns.Add("FREE_TEXT", typeof(string));
                dtRSN.Columns.Add("NOTE_LEVEL", typeof(string));
                dtRSN.Columns.Add("DISPLAY_ORDER", typeof(Int32));

                return dtRSN;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtRSN;
        }

        #endregion

        #endregion
               
        private void ChemRenditor_EditorReturned(object sender, MDL.Draw.Renditor.EditorReturnedEventArgs e)
        {
            try
            {
                if (Molcol == Generic.Enums.ParticipantsMOlColumnNames.R_MOL)
                {
                    dtReactant.Rows[rowindex]["R_MOL"] = (object)chemRenditor.Image;
                    dtReactant.Rows[rowindex]["molecule_sketch"] = chemRenditor.MolfileString;
                }
                else if (Molcol == Generic.Enums.ParticipantsMOlColumnNames.A_MOL)
                {
                    dtAgent.Rows[rowindex]["A_MOL"] = (object)chemRenditor.Image;
                    dtAgent.Rows[rowindex]["molecule_sketch"] = chemRenditor.MolfileString;
                }
                else if (Molcol == Generic.Enums.ParticipantsMOlColumnNames.C_MOL)
                {
                    dtCatalyst.Rows[rowindex]["C_MOL"] = (object)chemRenditor.Image;
                    dtCatalyst.Rows[rowindex]["molecule_sketch"] = chemRenditor.MolfileString;
                }
                else if (Molcol == Generic.Enums.ParticipantsMOlColumnNames.S_MOL)
                {
                    dtSolvent.Rows[rowindex]["S_MOL"] = (object)chemRenditor.Image;
                    dtSolvent.Rows[rowindex]["molecule_sketch"] = chemRenditor.MolfileString;
                }

                else if (Molcol == Generic.Enums.ParticipantsMOlColumnNames.R_SUBST_MOL)
                {
                    dtReactant.Rows[rowindex]["Subst_Mol_Image"] = (object)chemRenditor.Image;
                    dtReactant.Rows[rowindex]["subst_molecule"] = chemRenditor.MolfileString;
                }
                else if (Molcol == Generic.Enums.ParticipantsMOlColumnNames.A_SUBST_MOL)
                {
                    dtAgent.Rows[rowindex]["Subst_Mol_Image"] = (object)chemRenditor.Image;
                    dtAgent.Rows[rowindex]["subst_molecule"] = chemRenditor.MolfileString;
                }                
                else if (Molcol == Generic.Enums.ParticipantsMOlColumnNames.S_SUBST_MOL)
                {
                    dtSolvent.Rows[rowindex]["Subst_Mol_Image"] = (object)chemRenditor.Image;
                    dtSolvent.Rows[rowindex]["subst_molecule"] = chemRenditor.MolfileString;
                }
                else if (Molcol == Generic.Enums.ParticipantsMOlColumnNames.C_SUBST_MOL)
                {
                    dtCatalyst.Rows[rowindex]["Subst_Mol_Image"] = (object)chemRenditor.Image;
                    dtCatalyst.Rows[rowindex]["subst_molecule"] = chemRenditor.MolfileString;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
                     
        private void DeleteRowFromPartpntTables_New(int _rowindex, string _parpnttype)
        {
            try
            {
                if (_parpnttype != "")
                {
                    if (_parpnttype.ToUpper() == "AGENT")
                    {
                        if (dtAgent != null)
                        {
                            if (dtAgent.Rows.Count > 0)
                            {
                                dtAgent.Rows[_rowindex].Delete();
                                dtAgent.AcceptChanges();
                            }
                            dtAgent = ChangeDisplayOrderInParticipantTable(dtAgent, _rowindex, "DELETE");
                        }
                    }
                    else if (_parpnttype.ToUpper() == "REACTANT")
                    {
                        if (dtReactant != null)
                        {
                            if (dtReactant.Rows.Count > 0)
                            {
                                dtReactant.Rows[_rowindex].Delete();
                                dtReactant.AcceptChanges();
                            }

                            dtReactant = ChangeDisplayOrderInParticipantTable(dtReactant, _rowindex, "DELETE");
                        }
                    }
                    else if (_parpnttype.ToUpper() == "SOLVENT")
                    {
                        if (dtSolvent != null)
                        {
                            if (dtSolvent.Rows.Count > 0)
                            {
                                dtSolvent.Rows[_rowindex].Delete();
                                dtSolvent.AcceptChanges();
                            }
                            dtSolvent = ChangeDisplayOrderInParticipantTable(dtSolvent, _rowindex, "DELETE");
                        }
                    }
                    else if (_parpnttype.ToUpper() == "CATALYST")
                    {
                        if (dtCatalyst != null)
                        {
                            if (dtCatalyst.Rows.Count > 0)
                            {
                                dtCatalyst.Rows[_rowindex].Delete();
                                dtCatalyst.AcceptChanges();
                            }
                            dtCatalyst = ChangeDisplayOrderInParticipantTable(dtCatalyst, _rowindex, "DELETE");
                        }
                    }
                    #region MyRegion
                    //else if (_parpnttype.ToUpper() == "CONDITION")
                    //{
                    //    if (dtConditions != null)
                    //    {
                    //        if (dtConditions.Rows.Count > 0)
                    //        {
                    //            dtConditions.Rows[_rowindex].Delete();
                    //            dtConditions.AcceptChanges();
                    //        }
                    //    }
                    //} 
                    #endregion
                    else if (_parpnttype.ToUpper() == "RSN")
                    {
                        if (dtRSN != null)
                        {
                            if (dtRSN.Rows.Count > 0)
                            {
                                dtRSN.Rows[_rowindex].Delete();
                                dtRSN.AcceptChanges();
                            }
                            dtRSN = ChangeDisplayOrderInParticipantTable(dtRSN, _rowindex, "DELETE");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }      

        public void AddRecToParticipantTables_New(string partpnttype, int rowindex,string before_after)
        {
            try
            {
                int intNewParpntID = 0;

                switch (partpnttype.Trim().ToUpper())
                {
                    case "AGENT":
                        //intNewParpntID = CASRxnDataAccess.Insert_Get_RxnNewParticipantID(partpnttype, RxnStageID, rowindex + 1, before_after, GlobalVariables.URID);
                        intNewParpntID = ReactDB.GetReactionNewParticipantID(partpnttype, ReactionID,RxnStageID, rowindex + 1, before_after, GlobalVariables.URID);
                        if (intNewParpntID > 0)
                        {
                            if (dtAgent != null)
                            {
                                DataRow drA = dtAgent.NewRow();
                                drA["PP_NAME"] = "No Agent";
                                drA["RXN_ID"] = ReactionID;
                                drA["RXN_STAGE_ID"] = RxnStageID;
                                drA["RPP_ID"] = intNewParpntID;
                                //dtAgent.Rows.Add(drA);

                                if (before_after == "BEFORE" || before_after == "END")
                                {
                                    drA["DISPLAY_ORDER"] = rowindex + 1;
                                    dtAgent.Rows.InsertAt(drA, rowindex);
                                }
                                else if (before_after == "AFTER")
                                {
                                    drA["DISPLAY_ORDER"] = rowindex + 2;
                                    dtAgent.Rows.InsertAt(drA, rowindex + 1);
                                }
                                //Change Display order in Agent table
                                dtAgent = ChangeDisplayOrderInParticipantTable(dtAgent, rowindex + 1, before_after);
                            }
                            else
                            {
                                dtAgent = GetParticipantsTableDefinition();
                                DataRow drA = dtAgent.NewRow();

                                drA["PP_NAME"] = "No Agent";
                                drA["RXN_ID"] = ReactionID;
                                drA["RXN_STAGE_ID"] = RxnStageID;
                                drA["RPP_ID"] = intNewParpntID;
                                drA["DISPLAY_ORDER"] = rowindex + 1;
                                dtAgent.Rows.Add(drA);

                                dtAgent.TableName = Generic.Enums.ParticipantType.AGENT.ToString();
                                dgvAgent.DataSource = dtAgent;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Error in adding Agent", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        break;

                    case "REACTANT":
                        intNewParpntID = ReactDB.GetReactionNewParticipantID(partpnttype,ReactionID, RxnStageID, rowindex + 1, before_after, GlobalVariables.URID);
                        if (intNewParpntID > 0)
                        {
                            if (dtReactant != null)
                            {                               
                                DataRow drR = dtReactant.NewRow();
                                drR["PP_NAME"] = "No Reactant";
                                drR["RXN_ID"] = ReactionID;
                                drR["RXN_STAGE_ID"] = RxnStageID;
                                drR["RPP_ID"] = intNewParpntID;

                                if (before_after == "BEFORE" || before_after == "END")
                                {
                                    drR["DISPLAY_ORDER"] = rowindex + 1;
                                    dtReactant.Rows.InsertAt(drR, rowindex);
                                }
                                else if (before_after == "AFTER")
                                {
                                    drR["DISPLAY_ORDER"] = rowindex + 2;
                                    dtReactant.Rows.InsertAt(drR, rowindex + 1);
                                }

                                //Change Display order in Reactants table
                                dtReactant = ChangeDisplayOrderInParticipantTable(dtReactant, rowindex + 1, before_after);
                            }
                            else
                            {
                                dtReactant = GetParticipantsTableDefinition();
                                DataRow drR = dtReactant.NewRow();
                                drR["PP_NAME"] = "No Reactant";
                                drR["RXN_ID"] = ReactionID;
                                drR["RXN_STAGE_ID"] = RxnStageID;
                                drR["RPP_ID"] = intNewParpntID;
                                drR["DISPLAY_ORDER"] = rowindex + 1;
                                dtReactant.Rows.Add(drR);

                                dtReactant.TableName = Generic.Enums.ParticipantType.REACTANT.ToString();
                                dgvReactant.DataSource = dtReactant;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Error in adding Reactant", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        break;

                    case "CATALYST":
                        intNewParpntID = ReactDB.GetReactionNewParticipantID(partpnttype, ReactionID, RxnStageID, rowindex + 1, before_after, GlobalVariables.URID);
                        if (intNewParpntID > 0)
                        {
                            if (dtCatalyst != null)
                            {
                                DataRow drC = dtCatalyst.NewRow();
                                drC["PP_NAME"] = "No Catalyst";
                                drC["RXN_ID"] = ReactionID;
                                drC["RXN_STAGE_ID"] = RxnStageID;
                                drC["RPP_ID"] = intNewParpntID;
                                //dtCatalyst.Rows.Add(drC);

                                if (before_after == "BEFORE" || before_after == "END")
                                {
                                    drC["DISPLAY_ORDER"] = rowindex + 1;
                                    dtCatalyst.Rows.InsertAt(drC, rowindex);
                                }
                                else if (before_after == "AFTER")
                                {
                                    drC["DISPLAY_ORDER"] = rowindex + 2;
                                    dtCatalyst.Rows.InsertAt(drC, rowindex + 1);
                                }
                                //Change Display order in Catalyst table
                                dtCatalyst = ChangeDisplayOrderInParticipantTable(dtCatalyst, rowindex + 1, before_after);
                            }
                            else
                            {
                                dtCatalyst = GetParticipantsTableDefinition();
                                DataRow drC = dtCatalyst.NewRow();
                                drC["PP_NAME"] = "No Catalyst";
                                drC["RXN_ID"] = ReactionID;
                                drC["RXN_STAGE_ID"] = RxnStageID;
                                drC["RPP_ID"] = intNewParpntID;
                                drC["DISPLAY_ORDER"] = rowindex + 1;
                                dtCatalyst.Rows.Add(drC);

                                dtCatalyst.TableName = Generic.Enums.ParticipantType.CATALYST.ToString();
                                dgvCatalyst.DataSource = dtCatalyst;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Error in adding Catalyst", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        break;

                    case "SOLVENT":
                        intNewParpntID = ReactDB.GetReactionNewParticipantID(partpnttype,ReactionID, RxnStageID, rowindex + 1, before_after, GlobalVariables.URID);
                        if (intNewParpntID > 0)
                        {
                            if (dtSolvent != null)
                            {
                                DataRow drS = dtSolvent.NewRow();
                                drS["PP_NAME"] = "No Solvent";
                                drS["RXN_ID"] = ReactionID;
                                drS["RXN_STAGE_ID"] = RxnStageID;
                                drS["RPP_ID"] = intNewParpntID;
                                //dtSolvent.Rows.Add(drS);

                                if (before_after == "BEFORE" || before_after == "END")
                                {
                                    drS["DISPLAY_ORDER"] = rowindex + 1;
                                    dtSolvent.Rows.InsertAt(drS, rowindex);
                                }
                                else if (before_after == "AFTER")
                                {
                                    drS["DISPLAY_ORDER"] = rowindex + 2;
                                    dtSolvent.Rows.InsertAt(drS, rowindex + 1);
                                }
                                //Change Display order in Solvent table
                                dtSolvent = ChangeDisplayOrderInParticipantTable(dtSolvent, rowindex + 1, before_after);
                            }
                            else
                            {
                                dtSolvent = GetParticipantsTableDefinition();
                                DataRow drS = dtSolvent.NewRow();
                                drS["PP_NAME"] = "No Solvent";
                                drS["RXN_ID"] = ReactionID;
                                drS["RXN_STAGE_ID"] = RxnStageID;
                                drS["RPP_ID"] = intNewParpntID;
                                drS["DISPLAY_ORDER"] = rowindex + 1;
                                dtSolvent.Rows.Add(drS);

                                dtSolvent.TableName = Generic.Enums.ParticipantType.SOLVENT.ToString();
                                dgvSolvent.DataSource = dtSolvent;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Error in adding Solvent", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        break;                   
                }                            
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
                
        public void AddNewRowToRSNTable(string partpnttype,int disporder,string before_after)
        {
            try
            {   
                if (dtRSN == null)
                {
                    dtRSN = GetRSNTableDefinition();
                }

                int intNewParpntID = ReactDB.GetReactionNewParticipantID(partpnttype, ReactionID, RxnStageID, disporder, before_after, GlobalVariables.URID);
                if (intNewParpntID > 0)
                {
                    DataRow drRSN = dtRSN.NewRow();
                    drRSN["RXN_STAGE_ID"] = RxnStageID;
                    drRSN["RSN_ID"] = intNewParpntID;
                    drRSN["NOTE_LEVEL"] = StageName.ToUpper() == "STAGE 1" ? "Reaction" : "Stage";
                    dtRSN.Rows.Add(drRSN);
                }

                #region Old code commented by Sairam on 13th June 2014
                //if (dtRSN != null)
                //{                   
                //    if (StageName.ToUpper() == "STAGE 1")
                //    {
                //        if (dtRSN.Rows.Count > 0)
                //        {                            
                //           // intNewParpntID = CASRxnDataAccess.Insert_Get_RxnNewParticipantID(_partpnttype, RxnStageID, _disporder, _before_after, GlobalVariables.URID);
                //            intNewParpntID = CASRxnDataAccess.GetNewParticipantID(partpnttype, RxnStageID, disporder, before_after, GlobalVariables.URID);

                //            DataRow drRSN = dtRSN.NewRow();
                //            drRSN["rxn_stage_id"] = RxnStageID;
                //            drRSN["id"] = intNewParpntID;

                //            drRSN["rsn_combined"] = "Reaction";
                //            dtRSN.Rows.Add(drRSN);
                //            // }
                //        }
                //        else
                //        {
                //            intNewParpntID = CASRxnDataAccess.Insert_Get_RxnNewParticipantID(partpnttype, RxnStageID, disporder, before_after, GlobalVariables.URID);

                //            DataRow drRSN = dtRSN.NewRow();
                //            drRSN["rxn_stage_id"] = RxnStageID;
                //            drRSN["id"] = intNewParpntID;

                //            drRSN["rsn_combined"] = "Reaction";
                //            dtRSN.Rows.Add(drRSN);
                //        }
                //    }
                //    else if (dtRSN.Rows.Count == 0)
                //    {
                //        intNewParpntID = CASRxnDataAccess.Insert_Get_RxnNewParticipantID(partpnttype, RxnStageID, disporder, before_after, GlobalVariables.URID);

                //        DataRow drRSN = dtRSN.NewRow();
                //        drRSN["rxn_stage_id"] = RxnStageID;
                //        drRSN["id"] = intNewParpntID;

                //        drRSN["rsn_combined"] = "Stage";
                //        dtRSN.Rows.Add(drRSN);
                //    }
                //    else
                //    {
                //        MessageBox.Show("Maximum allowed rows are 1 only", "RSN", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //    }
                //}
                //else
                //{
                //    intNewParpntID = CASRxnDataAccess.Insert_Get_RxnNewParticipantID(partpnttype, RxnStageID, disporder, before_after, GlobalVariables.URID);

                //    dtRSN = GetRSNTableDefinition();
                //    DataRow drRSN = dtRSN.NewRow();
                //    drRSN["rxn_stage_id"] = RxnStageID;
                //    drRSN["id"] = intNewParpntID;

                //    if (StageName.ToUpper() == "STAGE 1")
                //    {
                //        drRSN["rsn_combined"] = "Reaction";
                //    }
                //    else
                //    {
                //        drRSN["rsn_combined"] = "Stage";
                //    }
                //    dtRSN.Rows.Add(drRSN);
                //} 
                #endregion
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private DataTable ChangeDisplayOrderInParticipantTable(DataTable partpnttbl, int rowindex, string insertOpt)
        {
            DataTable dtPartpnt = partpnttbl;
            try
            {
                if (dtPartpnt != null)
                {
                    if (dtPartpnt.Rows.Count > 0)
                    {
                        if (insertOpt == "BEFORE" || insertOpt == "AFTER")
                        {
                            int rIndx = 0;
                            if (insertOpt == "AFTER")
                            {
                                rIndx = rowindex + 1;
                            }
                            else if (insertOpt == "BEFORE")
                            {
                                rIndx = rowindex;
                            }
                            for (int i = rIndx; i < dtPartpnt.Rows.Count; i++)
                            {
                                dtPartpnt.Rows[i]["DISPLAY_ORDER"] = Convert.ToInt32(dtPartpnt.Rows[i]["DISPLAY_ORDER"].ToString()) + 1;
                            }
                            dtPartpnt.AcceptChanges();
                        }
                        else if (insertOpt == "DELETE")
                        {
                            int rIndx = rowindex;
                            for (int i = rIndx; i < dtPartpnt.Rows.Count; i++)
                            {
                                dtPartpnt.Rows[i]["DISPLAY_ORDER"] = Convert.ToInt32(dtPartpnt.Rows[i]["DISPLAY_ORDER"].ToString()) - 1;
                            }
                            dtPartpnt.AcceptChanges();
                        }
                    }
                }
                return dtPartpnt;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtPartpnt;
        }

        #region Participants Context Menus Events

        private void addReactantAfterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                int intRowIndx = 0;
                string strInsOpt = "AFTER";
                if (dgvReactant.CurrentCell != null)
                {
                    intRowIndx = dgvReactant.CurrentCell.RowIndex;
                }
                else
                {
                    strInsOpt = "END";
                }
                AddRecToParticipantTables_New("REACTANT", intRowIndx, strInsOpt);
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void addReactantBeforeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                int intRowIndx = 0;
                string strInsOpt = "BEFORE";
                if (dgvReactant.CurrentCell != null)
                {
                    intRowIndx = dgvReactant.CurrentCell.RowIndex;
                }
                else
                {
                    strInsOpt = "END";
                }
                AddRecToParticipantTables_New("REACTANT", intRowIndx, strInsOpt);
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        

        private void deleteReactantToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvReactant != null)
                {
                    if (dgvReactant.CurrentCell != null)
                    {
                        int selRowIndex = dgvReactant.CurrentCell.RowIndex;
                        if (selRowIndex >= 0)
                        {
                            if (dtReactant != null)
                            {
                                if (dtReactant.Rows.Count > 0)
                                {
                                    DialogResult diaRes = MessageBox.Show("Do you want to delete the reactant?", "Delete Reactant", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                                    if (diaRes == DialogResult.Yes)
                                    {
                                        if (dtReactant.Rows[selRowIndex]["RPP_ID"].ToString() != "")
                                        {
                                            int intPartpntID = 0;
                                            int.TryParse(dtReactant.Rows[selRowIndex]["RPP_ID"].ToString(), out intPartpntID);

                                            if (intPartpntID > 0)
                                            {
                                                if (ReactDB.DeleteReactionParticipant(intPartpntID, "REACTANT"))
                                                {
                                                    DeleteRowFromPartpntTables_New(selRowIndex, "REACTANT");

                                                    //Check and set default Comments
                                                    CheckAndSetTANComments();
                                                }
                                                else
                                                {
                                                    MessageBox.Show("Error in delete reactant", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
                                
        private void addAgentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                int intRowIndx = 0;
                string strInsOpt = "AFTER";
                if (dgvAgent.CurrentCell != null)
                {
                    intRowIndx = dgvAgent.CurrentCell.RowIndex;
                }
                else
                {
                    strInsOpt = "END";
                }
                AddRecToParticipantTables_New("AGENT", intRowIndx, strInsOpt);
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void addAgentBeforeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                int intRowIndx = 0;
                string strInsOpt = "BEFORE";
                if (dgvAgent.CurrentCell != null)
                {
                    intRowIndx = dgvAgent.CurrentCell.RowIndex;
                }
                else
                {
                    strInsOpt = "END";
                }
                AddRecToParticipantTables_New("AGENT", intRowIndx, strInsOpt);
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void deleteAgentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvAgent != null)
                {
                    if (dgvAgent.CurrentCell != null)
                    {
                        int selRowIndex = dgvAgent.CurrentCell.RowIndex;
                        if (selRowIndex >= 0)
                        {
                            if (dtAgent != null)
                            {
                                if (dtAgent.Rows.Count > 0)
                                {
                                    DialogResult diaRes = MessageBox.Show("Do you want to delete the agent?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                                    if (diaRes == DialogResult.Yes)
                                    {
                                        if (dtAgent.Rows[selRowIndex]["RPP_ID"].ToString() != "")
                                        {
                                            int intPartpntID = 0;
                                            int.TryParse(dtAgent.Rows[selRowIndex]["RPP_ID"].ToString(), out intPartpntID);

                                            if (intPartpntID > 0)
                                            {
                                                if (ReactDB.DeleteReactionParticipant(intPartpntID, "AGENT"))
                                                {
                                                    DeleteRowFromPartpntTables_New(selRowIndex, "AGENT");
                                                }
                                                else
                                                {
                                                    MessageBox.Show("Error in delete agent", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void addSolventToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                int intRowIndx = 0;
                string strInsOpt = "AFTER";
                if (dgvSolvent.CurrentCell != null)
                {
                    intRowIndx = dgvSolvent.CurrentCell.RowIndex;
                }
                else
                {
                    strInsOpt = "END";
                }
                AddRecToParticipantTables_New("SOLVENT", intRowIndx, strInsOpt);
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void addSolventBeforeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                int intRowIndx = 0;
                string strInsOpt = "BEFORE";
                if (dgvSolvent.CurrentCell != null)
                {
                    intRowIndx = dgvSolvent.CurrentCell.RowIndex;
                }
                else
                {
                    strInsOpt = "END";
                }
                AddRecToParticipantTables_New("SOLVENT", intRowIndx, strInsOpt);
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        

        private void deleteSolventToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvSolvent != null)
                {
                    if (dgvSolvent.CurrentCell != null)
                    {
                        int selRowIndex = dgvSolvent.CurrentCell.RowIndex;
                        if (selRowIndex >= 0)
                        {
                            if (dtSolvent != null)
                            {
                                if (dtSolvent.Rows.Count > 0)
                                {
                                    DialogResult diaRes = MessageBox.Show("Do you want to delete the solvent?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                                    if (diaRes == DialogResult.Yes)
                                    {
                                        if (dtSolvent.Rows[selRowIndex]["RPP_ID"].ToString() != "")
                                        {
                                            int intPartpntID = 0;
                                            int.TryParse(dtSolvent.Rows[selRowIndex]["RPP_ID"].ToString(), out intPartpntID);

                                            if (intPartpntID > 0)
                                            {
                                                if (ReactDB.DeleteReactionParticipant(intPartpntID, "SOLVENT"))
                                                {
                                                    DeleteRowFromPartpntTables_New(selRowIndex, "SOLVENT");
                                                }
                                                else
                                                {
                                                    MessageBox.Show("Error in delete solvent", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void addCatalystToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                int intRowIndx = 0;
                string strInsOpt = "AFTER";
                if (dgvCatalyst.CurrentCell != null)
                {
                    intRowIndx = dgvCatalyst.CurrentCell.RowIndex;
                }
                else
                {
                    strInsOpt = "END";
                }
                AddRecToParticipantTables_New("CATALYST", intRowIndx, strInsOpt);
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void addCatalystBeforeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                int intRowIndx = 0;
                string strInsOpt = "BEFORE";
                if (dgvCatalyst.CurrentCell != null)
                {
                    intRowIndx = dgvCatalyst.CurrentCell.RowIndex;
                }
                else
                {
                    strInsOpt = "END";
                }
                AddRecToParticipantTables_New("CATALYST", intRowIndx, strInsOpt);
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        

        private void deleteCatalystToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvCatalyst != null)
                {
                    if (dgvCatalyst.CurrentCell != null)
                    {
                        int selRowIndex = dgvCatalyst.CurrentCell.RowIndex;
                        if (selRowIndex >= 0)
                        {
                            if (dtCatalyst != null)
                            {
                                if (dtCatalyst.Rows.Count > 0)
                                {
                                    DialogResult diaRes = MessageBox.Show("Do you want to delete the catalyst?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                                    if (diaRes == DialogResult.Yes)
                                    {
                                        if (dtCatalyst.Rows[selRowIndex]["RPP_ID"].ToString() != "")
                                        {
                                            int intPartpntID = 0;
                                            int.TryParse(dtCatalyst.Rows[selRowIndex]["RPP_ID"].ToString(), out intPartpntID);

                                            if (intPartpntID > 0)
                                            {
                                                if (ReactDB.DeleteReactionParticipant(intPartpntID, "CATALYST"))
                                                {
                                                    DeleteRowFromPartpntTables_New(selRowIndex, "CATALYST");
                                                }
                                                else
                                                {
                                                    MessageBox.Show("Error in delete catalyst", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       
                     
        #endregion  
        
        #region Grid CellEnter Events

        int int8000 = 0;
        int int9000 = 0;
        int int8500 = 0;
        int intNum = 0;
        int intNRNReg = 0;
        private void EnableDisbaleParticipantGridCells(DataGridView selectedgrid, int rowindex, int colindex, string _srcgrid)
        {
            try
            {
                if (selectedgrid.Columns[colindex].Name.ToUpper() == _srcgrid + "_NAME")
                {
                    int8000 = 0;
                    int.TryParse(selectedgrid.Rows[rowindex].Cells[_srcgrid + "_8000"].Value.ToString(), out int8000);
                    if (int8000 > 0)
                    {
                        selectedgrid.Columns[_srcgrid + "_NAME"].ReadOnly = true;
                    }
                    else
                    {
                        int.TryParse(selectedgrid.Rows[rowindex].Cells[_srcgrid + "_NUM"].Value.ToString(), out intNum);
                        int.TryParse(selectedgrid.Rows[rowindex].Cells[_srcgrid + "_9000"].Value.ToString(), out int9000);
                        int.TryParse(selectedgrid.Rows[rowindex].Cells[_srcgrid + "_8500"].Value.ToString(), out int8500);
                        if (intNum > 0 || int9000 > 0 || int8500 > 0)
                        {
                            selectedgrid.Columns[_srcgrid + "_NAME"].ReadOnly = true;
                        }
                        else
                        {
                            selectedgrid.Columns[_srcgrid + "_NAME"].ReadOnly = false;
                        }             
                    }
                }
                else if (selectedgrid.Columns[colindex].Name.ToUpper() == _srcgrid + "_NUM")
                {
                    if (selectedgrid.Rows[rowindex].Cells[_srcgrid + "_Num"].Value != null)
                    {                                             
                        int8000 = 0;
                        int.TryParse(selectedgrid.Rows[rowindex].Cells[_srcgrid + "_8000"].Value.ToString(), out int8000);
                        if (int8000 > 0)
                        {
                            selectedgrid.Columns[_srcgrid + "_Num"].ReadOnly = true;
                        }
                        else
                        {
                            int.TryParse(selectedgrid.Rows[rowindex].Cells[_srcgrid + "_9000"].Value.ToString(), out int9000);
                            int.TryParse(selectedgrid.Rows[rowindex].Cells[_srcgrid + "_8500"].Value.ToString(), out int8500);

                            if (int9000 > 0 || int8500 > 0)
                            {
                                selectedgrid.Columns[_srcgrid + "_Num"].ReadOnly = true;
                            }
                            else
                            {
                                selectedgrid.Columns[_srcgrid + "_Num"].ReadOnly = false;
                            }            
                        }
                    }
                }
                else if (selectedgrid.Columns[colindex].Name.ToUpper() == _srcgrid + "_9000")
                {
                    if (selectedgrid.Rows[rowindex].Cells[_srcgrid + "_9000"].Value != null)
                    {
                        int8000 = 0;
                        int.TryParse(selectedgrid.Rows[rowindex].Cells[_srcgrid + "_8000"].Value.ToString(), out int8000);
                        if (int8000 > 0)
                        {
                            selectedgrid.Columns[_srcgrid + "_9000"].ReadOnly = true;
                        }
                        else
                        {                           
                            int.TryParse(selectedgrid.Rows[rowindex].Cells[_srcgrid + "_NUM"].Value.ToString(), out intNum);
                            int.TryParse(selectedgrid.Rows[rowindex].Cells[_srcgrid + "_8500"].Value.ToString(), out int8500);

                            if (intNum > 0 || int8500 > 0)
                            {
                                selectedgrid.Columns[_srcgrid + "_9000"].ReadOnly = true;
                            }
                            else
                            {
                                selectedgrid.Columns[_srcgrid + "_9000"].ReadOnly = false;
                            }
                        }
                    }
                }
                else if (selectedgrid.Columns[colindex].Name.ToUpper() == _srcgrid + "_8500")
                {
                    if (selectedgrid.Rows[rowindex].Cells[_srcgrid + "_8500"].Value != null)
                    {
                        int8500 = 0;
                        int.TryParse(selectedgrid.Rows[rowindex].Cells[_srcgrid + "_8000"].Value.ToString(), out int8500);
                        if (int8500 > 0)
                        {
                            selectedgrid.Columns[_srcgrid + "_8500"].ReadOnly = true;
                        }
                        else
                        {
                            int.TryParse(selectedgrid.Rows[rowindex].Cells[_srcgrid + "_NUM"].Value.ToString(), out intNum);
                            int.TryParse(selectedgrid.Rows[rowindex].Cells[_srcgrid + "_9000"].Value.ToString(), out int9000);
                            
                            if (intNum > 0 || int9000 > 0)
                            {
                                selectedgrid.Columns[_srcgrid + "_8500"].ReadOnly = true;
                            }
                            else
                            {
                                selectedgrid.Columns[_srcgrid + "_8500"].ReadOnly = false;
                            }        
                        }
                    }
                }
                else if (selectedgrid.Columns[colindex].Name.ToUpper() == _srcgrid + "_8000")
                {
                    intNum = 0;
                    int9000 = 0;
                    int8500 = 0;
                    intNRNReg = 0;

                    int.TryParse(selectedgrid.Rows[rowindex].Cells[_srcgrid + "_Num"].Value.ToString(), out intNum);
                    int.TryParse(selectedgrid.Rows[rowindex].Cells[_srcgrid + "_9000"].Value.ToString(), out int9000);
                    int.TryParse(selectedgrid.Rows[rowindex].Cells[_srcgrid + "_8500"].Value.ToString(), out int8500);

                    int.TryParse(selectedgrid.Rows[rowindex].Cells[_srcgrid + "_NRNREG"].Value.ToString(), out intNRNReg);

                    if (intNum == 0 && int9000 == 0 && int8500 == 0 && intNRNReg == 0)
                    {
                        selectedgrid.Columns[colindex].ReadOnly = false;
                    }
                    else
                    {
                        selectedgrid.Rows[rowindex].Cells[colindex].Value = 0;
                        selectedgrid.Columns[colindex].ReadOnly = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
                
        private void dgvAgent_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex < 0)
                {
                    return;
                }
                if (e.ColumnIndex < 0)
                {
                    return;
                }
               // EnableDisbaleParticipantGridCells(dgvAgent, e.RowIndex, e.ColumnIndex,"A");
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvReactant_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex < 0)
                {
                    return;
                }
                if (e.ColumnIndex < 0)
                {
                    return;
                }
                //EnableDisbaleParticipantGridCells(dgvReactant, e.RowIndex, e.ColumnIndex,"R");
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvSolvent_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex < 0)
                {
                    return;
                }
                if (e.ColumnIndex < 0)
                {
                    return;
                }
               // EnableDisbaleParticipantGridCells(dgvSolvent, e.RowIndex, e.ColumnIndex,"S");
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvCatalyst_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex < 0)
                {
                    return;
                }
                if (e.ColumnIndex < 0)
                {
                    return;
                }
               // EnableDisbaleParticipantGridCells(dgvCatalyst, e.RowIndex, e.ColumnIndex,"C");
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvRSN_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dgvRSN.Columns[e.ColumnIndex].Name.ToUpper() == "CVT")
                {
                    if (dgvRSN.Rows[e.RowIndex].Cells["NOTE_LEVEL"].Value != null)
                    {
                        if (dgvRSN.Rows[e.RowIndex].Cells["NOTE_LEVEL"].Value.ToString().ToUpper() == "STAGE")
                        {
                            dgvRSN.Rows[e.RowIndex].Cells[e.ColumnIndex].ReadOnly = true;
                        }
                        else
                        {
                            dgvRSN.Rows[e.RowIndex].Cells[e.ColumnIndex].ReadOnly = false;
                        }
                    }
                }
                else if (dgvRSN.Columns[e.ColumnIndex].Name.ToUpper() == "COMBINED")
                {
                    if (StageName.ToUpper() == "STAGE 1")
                    {
                        dgvRSN.Rows[e.RowIndex].Cells[e.ColumnIndex].ReadOnly = false;
                    }
                    else
                    {
                        dgvRSN.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = "Stage";
                        dgvRSN.Rows[e.RowIndex].Cells[e.ColumnIndex].ReadOnly = true;
                    }                   
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        private void dgRSN_CellLeave(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dgvRSN.Columns[e.ColumnIndex].Name.ToUpper() == "FREETEXT")
                {
                    if (dgvRSN.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString().ToUpper().Contains("INCREMENTAL ADDITION"))
                    {
                        MessageBox.Show("For incremental additions, add the times together instead of recording each addition separately",GlobalVariables.MessageCaption,MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        int NrnRegVal = 0;
               
        private void OpenChemControl_CGMWhenCellDoubleClicked(DataGridView _dgSelected, int _rowindex, int _colindex, string _srcgrid, ref DataTable _srcDataTable)
        {
            try
            {
                if (_dgSelected != null)
                {
                    if (_dgSelected.Rows.Count > 0)
                    {
                        rowindex = _rowindex;

                        int intNrnReg = 0;
                        int intNrnNUM = 0;
                        string strColName = _dgSelected.Columns[_colindex].Name.ToString().ToUpper();

                        if (strColName == "R_SUBST_MOL_IMG" || strColName == "A_SUBST_MOL_IMG" || strColName == "S_SUBST_MOL_IMG" || strColName == "C_SUBST_MOL_IMG")
                        {
                            if (_srcDataTable.Rows[_rowindex]["subst_molecule"] != null)
                            {
                                if (!string.IsNullOrEmpty(_srcDataTable.Rows[_rowindex]["subst_molecule"].ToString()))
                                {
                                    frmSubstMolImg objSubstMolImg = new frmSubstMolImg();
                                    objSubstMolImg.MolFile = _srcDataTable.Rows[_rowindex]["subst_molecule"].ToString();
                                    objSubstMolImg.ShowDialog();
                                }
                            }
                        }
                        else if (strColName == "R_NUM" || strColName == "A_NUM" || strColName == "S_NUM" || strColName == "C_NUM")
                        {
                            string strRegNoCol = "";
                            string strNUMCol = "";
                            string strNumTypeCol = "";
                            string strSerNumIDCol = "";//R_SER_NUM_ID
                            switch (strColName)
                            {
                                case "R_NUM":
                                    strRegNoCol = "r_nrnreg";
                                    strNUMCol = "r_num";
                                    strNumTypeCol = "R_NumType";
                                    strSerNumIDCol = "R_SER_NUM_ID";
                                  break;
                                case "A_NUM":
                                  strRegNoCol = "a_nrnreg";
                                  strNUMCol = "a_num";
                                  strNumTypeCol = "A_NumType";
                                  strSerNumIDCol = "A_SER_NUM_ID";
                                  break;
                                case "S_NUM":
                                  strRegNoCol = "s_nrnreg";
                                  strNUMCol = "s_num";
                                  strNumTypeCol = "S_NumType";
                                  strSerNumIDCol = "S_SER_NUM_ID";
                                  break;
                                case "C_NUM":
                                  strRegNoCol = "c_nrnreg";
                                  strNUMCol = "c_num";
                                  strNumTypeCol = "C_NumType";
                                  strSerNumIDCol = "C_SER_NUM_ID";
                                  break;
                            }
                            if (!string.IsNullOrEmpty(strRegNoCol) && !string.IsNullOrEmpty(strNUMCol))
                            {
                                int.TryParse(_dgSelected.Rows[_rowindex].Cells[strRegNoCol].Value.ToString(), out intNrnReg);
                                int.TryParse(_dgSelected.Rows[_rowindex].Cells[strNUMCol].Value.ToString(), out intNrnNUM);
                                // GetNUMInfoFromNUMsTable(intNrnReg, intNrnNUM);
                                int serNumID = 0;
                                int.TryParse(_dgSelected.Rows[_rowindex].Cells[strSerNumIDCol].Value.ToString(), out serNumID);
                                string colSerType = _dgSelected.Rows[_rowindex].Cells[strNumTypeCol].Value.ToString().ToUpper();

                                //Get Structure properties on SerNumID & SeriesType
                                ChemStructure objChemStruct = GetStructurePropertiesOnSeriesNumID(serNumID, colSerType);
                                if (objChemStruct != null)
                                {
                                    BindStructurePropsToNumsInfo(objChemStruct);
                                }
                            }
                        }
                        #region Main Code Commented
                        //switch (strColName)
                        //{
                        //    #region Code commented
                        //    //case "R_MOL":

                        //    //    Molcol = Generic.Enums.ParticipantsMOlColumnNames.R_MOL;
                        //    //    if (_srcDataTable.Rows[_rowindex]["molecule_sketch"] != null)
                        //    //    {
                        //    //        chemRenditor.MolfileString = _srcDataTable.Rows[_rowindex]["molecule_sketch"].ToString();
                        //    //        chemRenditor.FireEditor();
                        //    //    }
                        //    //    break;
                        //    //case "A_MOL":

                        //    //    Molcol = Generic.Enums.ParticipantsMOlColumnNames.A_MOL;
                        //    //    if (_srcDataTable.Rows[_rowindex]["molecule_sketch"] != null)
                        //    //    {
                        //    //        chemRenditor.MolfileString = _srcDataTable.Rows[_rowindex]["molecule_sketch"].ToString();
                        //    //        chemRenditor.FireEditor();
                        //    //    }
                        //    //    break;
                        //    //case "S_MOL":

                        //    //    Molcol = Generic.Enums.ParticipantsMOlColumnNames.S_MOL;
                        //    //    if (_srcDataTable.Rows[_rowindex]["molecule_sketch"] != null)
                        //    //    {
                        //    //        chemRenditor.MolfileString = _srcDataTable.Rows[_rowindex]["molecule_sketch"].ToString();
                        //    //        chemRenditor.FireEditor();
                        //    //    }
                        //    //    break;
                        //    //case "C_MOL":

                        //    //    Molcol = Generic.Enums.ParticipantsMOlColumnNames.C_MOL;
                        //    //    if (_srcDataTable.Rows[_rowindex]["molecule_sketch"] != null)
                        //    //    {
                        //    //        chemRenditor.MolfileString = _srcDataTable.Rows[_rowindex]["molecule_sketch"].ToString();
                        //    //        chemRenditor.FireEditor();
                        //    //    }
                        //    //    break; 
                        //    #endregion
                        //    case "R_SUBST_MOL_IMG":                            

                        //        if (_srcDataTable.Rows[_rowindex]["subst_molecule"] != null)
                        //        {
                        //            if (_srcDataTable.Rows[_rowindex]["subst_molecule"].ToString() != "")
                        //            {
                        //                frmSubstMolImg objSubstMolImg = new frmSubstMolImg();
                        //                objSubstMolImg.MolFile = _srcDataTable.Rows[_rowindex]["subst_molecule"].ToString();
                        //                objSubstMolImg.ShowDialog();
                        //            }
                        //        }
                        //        break;
                        //    case "A_SUBST_MOL_IMG":

                        //        if (_srcDataTable.Rows[_rowindex]["subst_molecule"] != null)
                        //        {
                        //            if (_srcDataTable.Rows[_rowindex]["subst_molecule"].ToString() != "")
                        //            {
                        //                frmSubstMolImg objSubstMolImg = new frmSubstMolImg();
                        //                objSubstMolImg.MolFile = _srcDataTable.Rows[_rowindex]["subst_molecule"].ToString();
                        //                objSubstMolImg.ShowDialog();
                        //            }
                        //        }
                        //        break;
                        //    case "S_SUBST_MOL_IMG":

                        //        if (_srcDataTable.Rows[_rowindex]["subst_molecule"] != null)
                        //        {
                        //            if (_srcDataTable.Rows[_rowindex]["subst_molecule"].ToString() != "")
                        //            {
                        //                frmSubstMolImg objSubstMolImg = new frmSubstMolImg();
                        //                objSubstMolImg.MolFile = _srcDataTable.Rows[_rowindex]["subst_molecule"].ToString();
                        //                objSubstMolImg.ShowDialog();
                        //            }
                        //        }
                        //        break;
                        //    case "C_SUBST_MOL_IMG":

                        //        if (_srcDataTable.Rows[_rowindex]["subst_molecule"] != null)
                        //        {
                        //            if (_srcDataTable.Rows[_rowindex]["subst_molecule"].ToString() != "")
                        //            {
                        //                frmSubstMolImg objSubstMolImg = new frmSubstMolImg();
                        //                objSubstMolImg.MolFile = _srcDataTable.Rows[_rowindex]["subst_molecule"].ToString();
                        //                objSubstMolImg.ShowDialog();
                        //            }
                        //        }                            
                        //        break;

                        //    case "R_NUM":                            
                        //            int.TryParse(_dgSelected.Rows[_rowindex].Cells["r_nrnreg"].Value.ToString(), out intNrnReg);
                        //            int.TryParse(_dgSelected.Rows[_rowindex].Cells["r_num"].Value.ToString(), out intNrnNUM);
                        //            GetNUMInfoFromCGM(intNrnReg, intNrnNUM);                               
                        //        break;
                        //    case "A_NUM":
                        //        int.TryParse(_dgSelected.Rows[_rowindex].Cells["a_nrnreg"].Value.ToString(), out intNrnReg);
                        //        int.TryParse(_dgSelected.Rows[_rowindex].Cells["a_num"].Value.ToString(), out intNrnNUM);
                        //        GetNUMInfoFromCGM(intNrnReg, intNrnNUM);
                        //        break;
                        //    case "S_NUM":
                        //        int.TryParse(_dgSelected.Rows[_rowindex].Cells["s_nrnreg"].Value.ToString(), out intNrnReg);
                        //        int.TryParse(_dgSelected.Rows[_rowindex].Cells["s_num"].Value.ToString(), out intNrnNUM);
                        //        GetNUMInfoFromCGM(intNrnReg, intNrnNUM);
                        //        break;
                        //    case "C_NUM":
                        //        int.TryParse(_dgSelected.Rows[_rowindex].Cells["c_nrnreg"].Value.ToString(), out intNrnReg);
                        //        int.TryParse(_dgSelected.Rows[_rowindex].Cells["c_num"].Value.ToString(), out intNrnNUM);
                        //        GetNUMInfoFromCGM(intNrnReg, intNrnNUM);
                        //        break;
                        //} 
                        #endregion                                               
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        int rowindex = 0;
        Generic.Enums.ParticipantsMOlColumnNames Molcol;

        #region Grid CellDoubleClick Events

        private void dgvReactant_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex < 0 || e.ColumnIndex < 0)
                    return;
                OpenChemControl_CGMWhenCellDoubleClicked(dgvReactant, e.RowIndex, e.ColumnIndex, "R", ref dtReactant);    
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvAgent_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex < 0 || e.ColumnIndex < 0)
                    return;

                OpenChemControl_CGMWhenCellDoubleClicked(dgvAgent, e.RowIndex, e.ColumnIndex, "A", ref dtAgent);
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvSolvent_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex < 0 || e.ColumnIndex < 0)
                    return;

                OpenChemControl_CGMWhenCellDoubleClicked(dgvSolvent, e.RowIndex, e.ColumnIndex, "S", ref dtSolvent);
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvCatalyst_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex < 0 || e.ColumnIndex < 0)
                    return;

                OpenChemControl_CGMWhenCellDoubleClicked(dgvCatalyst, e.RowIndex, e.ColumnIndex, "C", ref dtCatalyst);
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        private void ParticipantTextBox_KeyPress(System.Object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            try
            {
                if (((e.KeyChar >= 48 && e.KeyChar <= 57) || e.KeyChar == 8) != true)
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void TextBox_KeyPress(System.Object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            try
            {
                #region Code Commented
                ////---if textbox is empty and user pressed a decimal char---
                //if (((TextBox)sender).Text == string.Empty & e.KeyChar == (char)46)
                //{
                //    e.Handled = true;
                //    return;
                //}
                ////---if textbox already has a decimal point---
                //if (((TextBox)sender).Text.Contains(Convert.ToString((char)46)) & e.KeyChar == (char)46)
                //{
                //    e.Handled = true;
                //    return;
                //}
                ////if (!(char.IsDigit(e.KeyChar).ToString() ==","))
                //if (!(e.KeyChar == 44) & !(e.KeyChar == 45))
                //{
                //    if ((!(char.IsDigit(e.KeyChar) | char.IsControl(e.KeyChar) | (e.KeyChar == (char)46))))
                //    {
                //        e.Handled = true;
                //    }
                //} 
                #endregion

                if (e.KeyChar == 44 || e.KeyChar == 59) //Comma and ; not allowed Comma ASCII is 44
                {
                    e.Handled = true;
                }                
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
                
        string strGridName = "";
                              
        private bool CheckAndSetTANComments()
        {
            bool blStatus = false;
            try
            {
                int _p8000 = 0;
                int _p8500 = 0;
                int _r8000 = 0;
                int _r8500 = 0;
                int int8000Len_P = 0;
                int int8500Len_P = 0;
                int int8000Len_R = 0;
                int int8500Len_R = 0;

                DataTable dt8000_8500 = ReactDB.Get8000And8500ValuesOnTAN_ID(TAN_ID);

                if (dt8000_8500 != null)
                {
                    if (dt8000_8500.Rows.Count > 0)
                    {
                        int8000Len_P = Get8000_8500_Val_Length(dt8000_8500, "p_8000");
                        if (int8000Len_P > 0)
                        {
                            _p8000 = 8000;
                        }
                        else
                        {
                            frmReactCuration objParent = (frmReactCuration)this.Parent.Parent.Parent.Parent.Parent;
                            if (objParent != null)
                            {
                                DataTable dtprod = objParent.RxnProductsTbl;
                                if (dtprod != null)
                                {
                                    if (dtprod.Rows.Count > 0)
                                    {
                                        int8000Len_P = Get8000_8500_Val_Length(dtprod, "p_8000");
                                        if (int8000Len_P > 0)
                                        {
                                            _p8000 = 8000;
                                        }                                       
                                    }
                                }
                            }
                        }

                        int8500Len_P = Get8000_8500_Val_Length(dt8000_8500, "p_8500");
                        if (int8500Len_P > 0)
                        {
                            _p8500 = 8500;
                        }
                        else
                        {
                            frmReactCuration objParent = (frmReactCuration)this.Parent.Parent.Parent.Parent.Parent;
                            if (objParent != null)
                            {
                                DataTable dtprod = objParent.RxnProductsTbl;
                                if (dtprod != null)
                                {
                                    if (dtprod.Rows.Count > 0)
                                    {
                                        int8500Len_P = Get8000_8500_Val_Length(dtprod, "p_8500");
                                        if (int8500Len_P > 0)
                                        {
                                            _p8500 = 8500;
                                        }
                                    }
                                }
                            }
                        }

                        int8000Len_R = Get8000_8500_Val_Length(dt8000_8500, "p_8000");
                        if (int8000Len_R > 0)
                        {
                            _r8000 = 8000;
                        }
                        else
                        {
                           frmReactCuration objParent = (frmReactCuration)this.Parent.Parent.Parent.Parent.Parent;
                           if (objParent != null)
                           {
                               ucParticipants ucparpnt = null;
                               DataTable dtTemp_R = null;
                               for (int i = 0; i < objParent.tcStages.TabPages.Count; i++)
                               {
                                   ucparpnt = (ucParticipants)objParent.tcStages.TabPages[i].Controls["ucParticipants"];
                                   if (ucparpnt != null)
                                   {
                                       dtTemp_R = ucparpnt.dtReactant.DefaultView.ToTable().Copy();
                                       if (dtTemp_R != null)
                                       {
                                           if (dtTemp_R.Rows.Count > 0)
                                           {
                                               int8000Len_R = Get8000_8500_Val_Length(dtTemp_R, "p_8000");
                                               if (int8000Len_R > 0)
                                               {
                                                   _r8000 = 8000;
                                                   break;
                                               }
                                           }
                                       }
                                   }
                               }
                           }
                        }

                        int8500Len_R = Get8000_8500_Val_Length(dt8000_8500, "R_8500");
                        if (int8500Len_R > 0)
                        {
                            _r8500 = 8500;
                        }
                        else
                        {
                           frmReactCuration objParent = (frmReactCuration)this.Parent.Parent.Parent.Parent.Parent;
                           if (objParent != null)
                           {
                               ucParticipants ucparpnt = null;
                               DataTable dtTemp_R = null;
                               for (int i = 0; i < objParent.tcStages.TabPages.Count; i++)
                               {
                                   ucparpnt = (ucParticipants)objParent.tcStages.TabPages[i].Controls["ucParticipants"];
                                   if (ucparpnt != null)
                                   {
                                       dtTemp_R = ucparpnt.dtReactant;
                                       if (dtTemp_R != null)
                                       {
                                           if (dtTemp_R.Rows.Count > 0)
                                           {
                                               int8500Len_R = Get8000_8500_Val_Length(dtTemp_R, "p_8500");
                                               if (int8500Len_R > 0)
                                               {
                                                   _r8500 = 8500;
                                                   break;
                                               }
                                           }
                                       }
                                   }
                               }
                           }
                        }
                    }
                    else
                    {
                        frmReactCuration objParent = (frmReactCuration)this.Parent.Parent.Parent.Parent.Parent;
                        if (objParent != null)
                        {
                            DataTable dtprod = objParent.RxnProductsTbl;
                            if (dtprod != null)
                            {
                                if (dtprod.Rows.Count > 0)
                                {
                                    int8000Len_P = Get8000_8500_Val_Length(dtprod, "p_8000");
                                    if (int8000Len_P > 0)
                                    {
                                        _p8000 = 8000;
                                    }

                                    int8500Len_P = Get8000_8500_Val_Length(dtprod, "p_8500");
                                    if (int8500Len_P > 0)
                                    {
                                        _p8500 = 8500;
                                    }
                                }
                            }
                            if (objParent.tcStages.TabPages.Count > 0)
                            {
                                ucParticipants ucparpnt = null;
                                DataTable dtTemp_R = null;
                                for (int i = 0; i < objParent.tcStages.TabPages.Count; i++)
                                {
                                    ucparpnt = (ucParticipants)objParent.tcStages.TabPages[i].Controls["ucParticipants"];
                                    if (ucparpnt != null)
                                    {
                                        dtTemp_R = ucparpnt.dtReactant;
                                        if (dtTemp_R != null)
                                        {
                                            if (dtTemp_R.Rows.Count > 0)
                                            {
                                                int8000Len_R = Get8000_8500_Val_Length(dtTemp_R, "p_8000");
                                                if (int8000Len_R > 0)
                                                {
                                                    _r8000 = 8000;
                                                }

                                                int8500Len_R = Get8000_8500_Val_Length(dtTemp_R, "p_8500");
                                                if (int8500Len_R > 0)
                                                {
                                                    _r8500 = 8500;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } 

                string strComments = GenerateComments.GetComments_On_8000_8500(_p8000, _p8500, _r8000, _r8500);

                frmReactCuration objRxnParent = (frmReactCuration)this.Parent.Parent.Parent.Parent.Parent;
                if (objRxnParent != null)
                {
                    objRxnParent.DefaultComments = strComments;
                }              

                blStatus = true;
                return blStatus;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private int Get8000_8500_Val_Length(DataTable dtTarget, string _srcCol)
        {
            int intLen = 0;
            try
            {
                DataRow[] dtRArr = dtTarget.DefaultView.ToTable().Select(_srcCol + " > 0");
                if (dtRArr != null)
                {
                    if (dtRArr.Length > 0)
                    {
                        intLen = dtRArr.Length;
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return intLen;
        }

        private void ShowMessageIfNRNREGMatch(int _nrnreg)
        {
            try
            {
                if (_nrnreg > 0)
                {
                    if (_nrnreg == 50000)
                    {
                        MessageBox.Show("Use RSN as ' paraformaldehyde used 'for paraformaldehyde not for formaldehyde");
                    }
                    else if (_nrnreg == 7440020)
                    {
                        MessageBox.Show("RSN should be ' Raney nickel used '");
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        #region Grid RowPostPaint Events

        private void dgvReactant_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvReactant.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvReactant.Font);

                if (dgvReactant.RowHeadersWidth < (int)(size.Width + 20)) dgvReactant.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvAgent_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvAgent.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvAgent.Font);

                if (dgvAgent.RowHeadersWidth < (int)(size.Width + 20)) dgvAgent.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvSolvent_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvSolvent.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvSolvent.Font);

                if (dgvSolvent.RowHeadersWidth < (int)(size.Width + 20)) dgvSolvent.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvCatalyst_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvCatalyst.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvCatalyst.Font);

                if (dgvCatalyst.RowHeadersWidth < (int)(size.Width + 20)) dgvCatalyst.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvConditions_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvConditions.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvConditions.Font);

                if (dgvConditions.RowHeadersWidth < (int)(size.Width + 20)) dgvConditions.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvRSN_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvRSN.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvRSN.Font);

                if (dgvRSN.RowHeadersWidth < (int)(size.Width + 20)) dgvRSN.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        #region Grid Cell ContentClick Events and Methods
        int Nrn8500Val = 0;
        private void EditSelectedGridCellData(DataGridView selectedGrid, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex < 0 || e.ColumnIndex < 0)
                    return;

                string strParent = selectedGrid.Name;
                string strSrc = "";

                switch (strParent.ToUpper())
                {
                    case "DGVREACTANT":
                        strSrc = "R";
                        strGridName = "REACTANT";
                        break;
                    case "DGVAGENT":
                        strSrc = "A";
                        strGridName = "AGENT";
                        break;
                    case "DGVSOLVENT":
                         strSrc = "S";
                         strGridName = "SOLVENT";
                        break;
                    case "DGVCATALYST":
                        strSrc = "C";
                        strGridName = "CATALYST";
                        break;
                }                

                string strErrMsg = "";

                if (selectedGrid.Columns[e.ColumnIndex].Name.ToString().ToUpper() == strSrc + "_NUM")
                {
                    string numSeriesType = selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_NUMTYPE"].Value != null ? selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_NUMTYPE"].Value.ToString() : "";

                    frmNUMs objNUMs = new frmNUMs();
                    objNUMs.TAN_NUMsTbl = NUM_RegNosTbl;
                    objNUMs.SeriesType = numSeriesType;
                    objNUMs.SrcParticipant = strGridName;
                    objNUMs.SrcStageName = StageName;

                    if (objNUMs.ShowDialog() == DialogResult.OK)
                    {
                        if (objNUMs.Sel_NUM > 0)
                        {
                            if (!Validate_All_NRNNUM_Validations(objNUMs.Sel_NUM, "_NUM", strSrc, strGridName, out strErrMsg))
                            {                               
                                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_NUM"].Value = objNUMs.Sel_NUM;
                                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_NRNREG"].Value = objNUMs.Sel_RegNo;
                                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_NAME"].Value = objNUMs.Sel_Name;
                                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_NUMTYPE"].Value = objNUMs.SeriesType;
                                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_SER_NUM_ID"].Value = objNUMs.Sel_Ser_NUM_ID;
                                #region MyRegion
                                //selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_9000"].Value = 0;
                                //selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_8000"].Value = 0;
                                //selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_8500"].Value = 0;                               

                                //selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_name"].Value = "";
                                //selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_loc"].Value = "";
                                //selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Author_Name"].Value = "";
                                //selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Other_Name"].Value = "";
                                //selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_Molecule"].Value = "";
                                //selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_Mol_Img"].Value = null; 
                                #endregion

                                //Show corresponding messages if NrnReg matches
                                ShowMessageIfNRNREGMatch(objNUMs.Sel_RegNo);
                            }
                            else
                            {
                                if (strErrMsg.Trim() != "")
                                {
                                    MessageBox.Show(strErrMsg, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_NUM"].Value = 0;
                                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_NRNREG"].Value = 0;
                            }
                        }
                        else
                        {
                            //_dgvPartpant.CurrentCell.Style.Font = new Font("Arial", 10, FontStyle.Regular);

                            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_num"].Value = 0;
                            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_nrnreg"].Value = 0;
                        }
                    }
                   // selectedGrid.Update();
                    selectedGrid.CommitEdit(DataGridViewDataErrorContexts.Commit);              
                }
                #region Old code commented
                //else if (selectedGrid.Columns[e.ColumnIndex].Name.ToString().ToUpper() == strSrc + "_9000")
                //{
                //    frmSeries9000 obj9000 = new frmSeries9000();
                //    obj9000.SrcGrid = strGridName;
                //    if (obj9000.ShowDialog() == DialogResult.OK)
                //    {
                //        if (obj9000.Sel_9000 > 0)
                //        {
                //            if (!Validate_All_NRNNUM_Validations(obj9000.Sel_9000, "_9000", strSrc, strGridName, out strErrMsg))
                //            {
                //                if (obj9000.Sel_NrnReg > 0)
                //                {
                //                    int NrnNum = CAS_Classes.Get_TAN_Nrn_Reg_Data.Get_NrnNum(NUM_RegNosTbl, obj9000.Sel_NrnReg);
                //                    if (NrnNum > 0)
                //                    {
                //                        if (!Validate_All_NRNNUM_Validations(NrnNum, "_NUM", strSrc, strGridName, out strErrMsg))
                //                        {
                //                            //_dgvPartpant.CurrentCell.Style.Font = new Font("Arial", 10, FontStyle.Bold);

                //                            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_num"].Value = NrnNum;
                //                            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_9000"].Value = 0;
                //                            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_nrnreg"].Value = obj9000.Sel_NrnReg;
                //                            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_name"].Value = "";

                //                            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_8500"].Value = 0;

                //                            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_8000"].Value = 0;
                //                            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_name"].Value = "";
                //                            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_loc"].Value = "";
                //                            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Author_Name"].Value = "";
                //                            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Other_Name"].Value = "";
                //                            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_Molecule"].Value = "";
                //                            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_Mol_Img"].Value = null;
                //                        }
                //                        else
                //                        {
                //                            MessageBox.Show(strErrMsg, "", MessageBoxButtons.OK, MessageBoxIcon.Error);

                //                            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_num"].Value = 0;
                //                            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_9000"].Value = 0;
                //                            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_nrnreg"].Value = 0;
                //                            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_name"].Value = "";
                //                        }
                //                    }
                //                    else
                //                    {
                //                        //_dgvPartpant.CurrentCell.Style.Font = new Font("Arial", 10, FontStyle.Regular);

                //                        selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_9000"].Value = obj9000.Sel_9000;
                //                        selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_nrnreg"].Value = obj9000.Sel_NrnReg;
                //                        selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_name"].Value = obj9000.Sel_Name;

                //                        selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_num"].Value = 0;
                //                        selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_8000"].Value = 0;
                //                        selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_8500"].Value = 0;

                //                        selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_name"].Value = "";
                //                        selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_loc"].Value = "";
                //                        selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Author_Name"].Value = "";
                //                        selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Other_Name"].Value = "";
                //                        selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_Molecule"].Value = "";
                //                        selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_Mol_Img"].Value = null;
                //                    }
                //                }
                //            }
                //            else
                //            {
                //                if (strErrMsg.Trim() != "")
                //                {
                //                    MessageBox.Show(strErrMsg, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //                }
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_9000"].Value = 0;
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_nrnreg"].Value = 0;
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_name"].Value = "";
                //            }
                //        }
                //        else
                //        {
                //            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_9000"].Value = 0;
                //            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_nrnreg"].Value = 0;
                //            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_name"].Value = "";
                //        }
                //    }
                //    selectedGrid.CommitEdit(DataGridViewDataErrorContexts.Commit);
                //}
                //else if (selectedGrid.Columns[e.ColumnIndex].Name.ToString().ToUpper() == strSrc + "_8500")
                //{
                //    frmSeries8500 obj8500 = new frmSeries8500();
                //    obj8500.TANID = TAN_Name;
                //    if (obj8500.ShowDialog() == DialogResult.OK)
                //    {
                //        if (obj8500.Sel_8500 > 0)
                //        {
                //            if (!Validate_All_NRNNUM_Validations(obj8500.Sel_8500, "_8500", strSrc, strGridName, out strErrMsg))
                //            {
                //                //_dgvPartpant.CurrentCell.Style.Font = new Font("Arial", 10, FontStyle.Bold);

                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_8500"].Value = obj8500.Sel_8500;
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_nrnreg"].Value = obj8500.Sel_NrnReg;
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_name"].Value = obj8500.Sel_Name;

                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_num"].Value = 0;
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_8000"].Value = 0;
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_9000"].Value = 0;

                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_name"].Value = "";
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_loc"].Value = "";
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Author_Name"].Value = "";
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Other_Name"].Value = "";
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_Molecule"].Value = "";
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_Mol_Img"].Value = null;


                //                if (strSrc.ToUpper() == "S" && NrnRegVal == 77929)//77929 can't be Solvent
                //                {
                //                    MessageBox.Show(Nrn8500Val + " - " + NrnRegVal + " can't be a SOLVENT", "Manage 8500 series", MessageBoxButtons.OK, MessageBoxIcon.Error);

                //                    selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_8500"].Value = 0;
                //                    selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_nrnreg"].Value = 0;
                //                    selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_name"].Value = "";
                //                }
                //            }
                //            else
                //            {
                //                if (strErrMsg.Trim() != "")
                //                {
                //                    MessageBox.Show(strErrMsg, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //                }
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_8500"].Value = 0;
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_nrnreg"].Value = 0;
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_name"].Value = "";
                //            }
                //        }
                //        else
                //        {
                //            //_dgvPartpant.CurrentCell.Style.Font = new Font("Arial", 10, FontStyle.Regular);

                //            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_8500"].Value = 0;
                //            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_nrnreg"].Value = 0;
                //            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_name"].Value = "";
                //        }
                //    }
                //    selectedGrid.CommitEdit(DataGridViewDataErrorContexts.Commit);
                //}
                //else if (selectedGrid.Columns[e.ColumnIndex].Name.ToString().ToUpper() == strSrc + "_8000")
                //{
                //    frmSeries8000 obj8000 = new frmSeries8000();
                //    obj8000.TANID = TAN_Name;
                //    if (obj8000.ShowDialog() == DialogResult.OK)
                //    {
                //        if (obj8000.Sel_8000 > 0)
                //        {
                //            if (!Validate_All_NRNNUM_Validations(obj8000.Sel_8000, "_8000", strSrc, strGridName, out strErrMsg))
                //            {
                //                //_dgvPartpant.CurrentCell.Style.Font = new Font("Arial", 10, FontStyle.Bold);

                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_8000"].Value = obj8000.Sel_8000;
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_name"].Value = obj8000.SubstName;
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_loc"].Value = obj8000.SubstLoc;
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Author_Name"].Value = obj8000.AuthorName;
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Other_Name"].Value = obj8000.OtherName;
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_Molecule"].Value = obj8000.SubstMol;
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_Mol_Img"].Value = obj8000.SubstImage;

                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_num"].Value = 0;
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_8500"].Value = 0;
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_9000"].Value = 0;

                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_nrnreg"].Value = 0;
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_name"].Value = "";
                //            }
                //            else
                //            {
                //                MessageBox.Show(strErrMsg, "", MessageBoxButtons.OK, MessageBoxIcon.Error);

                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_8000"].Value = 0;
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_name"].Value = "";
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_loc"].Value = "";
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Author_Name"].Value = "";
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Other_Name"].Value = "";
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_Molecule"].Value = "";
                //                selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_Mol_Img"].Value = null;
                //            }
                //        }
                //        else
                //        {
                //            //_dgvPartpant.CurrentCell.Style.Font = new Font("Arial", 10, FontStyle.Regular);

                //            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_8000"].Value = 0;
                //            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_name"].Value = "";
                //            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_loc"].Value = "";
                //            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Author_Name"].Value = "";
                //            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Other_Name"].Value = "";
                //            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_Molecule"].Value = "";
                //            selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Subst_Mol_Img"].Value = null;
                //        }
                //    }
                //    selectedGrid.CommitEdit(DataGridViewDataErrorContexts.Commit);
                //} 
                #endregion
                else if (selectedGrid.Columns[e.ColumnIndex].Name.ToString().ToUpper() == strSrc + "_NRNREG")
                {
                    if (selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_nrnreg"].Value.ToString() != "0")
                    {
                        frmSrch_RegNo objSrchRegNo = new frmSrch_RegNo();
                        objSrchRegNo.TAN_ID = TAN_ID;
                        objSrchRegNo.TAN_Name = TAN_Name;
                        objSrchRegNo.RegNo = Convert.ToInt32(selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_nrnreg"].Value);
                        objSrchRegNo.SeriesType = selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_NumType"].Value.ToString(); 
                        objSrchRegNo.SeriesNumID = Convert.ToInt32(selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_SER_NUM_ID"].Value);
                        objSrchRegNo.ShowDialog();
                    }
                }
                else if (selectedGrid.Columns[e.ColumnIndex].Name.ToString().ToUpper() == strSrc + "_NAME")
                {
                    if (selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Name"].Value.ToString() != "") 
                    {
                        frmSrch_RegNo objSrchRegNo = new frmSrch_RegNo();
                        objSrchRegNo.TAN_ID = TAN_ID;
                        objSrchRegNo.TAN_Name = TAN_Name;
                        objSrchRegNo.RegNo = 0;
                        objSrchRegNo.PP_Name = selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_Name"].Value.ToString();
                        objSrchRegNo.SeriesType = selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_NumType"].Value.ToString();
                        objSrchRegNo.SeriesNumID = Convert.ToInt32(selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_SER_NUM_ID"].Value);
                        objSrchRegNo.ShowDialog();
                    }
                }
                else if (selectedGrid.Columns[e.ColumnIndex].Name.ToString().ToUpper() == strSrc + "_DELETE")//Delete Participant
                {
                    DialogResult diaRes = MessageBox.Show("Do you want to delete?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                    if (diaRes == DialogResult.Yes)
                    {
                       int intRppID = Convert.ToInt32(selectedGrid.Rows[e.RowIndex].Cells[strSrc + "_RPP_ID"].Value);

                       if (intRppID > 0)
                       {
                           if (ReactDB.DeleteReactionParticipant(intRppID, strGridName))
                           {
                               DeleteRowFromPartpntTables_New(e.RowIndex, strGridName);

                               //Check and set default Comments
                               //Code commented on 23Aug 2014 by Sairam, default comments not required.
                               //CheckAndSetTANComments();
                           }
                           else
                           {
                               MessageBox.Show("Error in delete", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                           }
                       }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvReactant_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                EditSelectedGridCellData((DataGridView)sender, e);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvAgent_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                EditSelectedGridCellData((DataGridView)sender, e);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvSolvent_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                EditSelectedGridCellData((DataGridView)sender, e);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvCatalyst_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                EditSelectedGridCellData((DataGridView)sender, e);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion
        
        private bool CheckIfNumUsedInProduct(int _nrnnum,string _srcCol)
        {
            bool blStatus = false;
            try
            {
                frmReactCuration objRxn_Parent = (frmReactCuration)this.Parent.Parent.Parent.Parent.Parent.Parent.Parent.Parent.Parent;
                if (objRxn_Parent != null)
                {
                    DataTable dtProduct = objRxn_Parent.RxnProductsTbl;
                    if (dtProduct != null)
                    {
                        if (dtProduct.Rows.Count > 0)
                        {
                            DataRow[] dtRowArr = null;
                            if (_srcCol.ToUpper() == "_NUM")
                            {
                                dtRowArr = dtProduct.Select("SERIES_NUM = " + _nrnnum);
                            }
                            //else if (_srcCol.ToUpper() == "_9000")
                            //{
                            //    dtRowArr = dtProduct.Select("P_9000= " + _nrnnum);
                            //}
                            //else if (_srcCol.ToUpper() == "_8500")
                            //{
                            //    dtRowArr = dtProduct.Select("P_8500= " + _nrnnum);
                            //}
                            //else if (_srcCol.ToUpper() == "_8000")
                            //{
                            //    dtRowArr = dtProduct.Select("P_8000= " + _nrnnum);
                            //}
                            if (dtRowArr.Length > 0)
                            {
                                blStatus = true;
                                return blStatus;
                            }                            
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckIfNumUsedInReactant(int _nrnnum, string _srcCol,out string _errmsg)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                TabControl tbParent = (TabControl)this.Parent.Parent;
                ucParticipants ucPartpnt = null;
                foreach (TabPage tp in tbParent.TabPages)
                {
                    ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                    if (ucPartpnt != null)
                    {
                       DataTable dtRtant = ucPartpnt.dtReactant;
                       if (dtRtant != null)
                        {
                            if (dtRtant.Rows.Count > 0)
                            {
                                DataRow[] dtRArr = dtRtant.Select("p" + _srcCol + " = " + _nrnnum);
                                if (dtRArr != null)
                                {
                                    if (dtRArr.Length > 0)
                                    {
                                        blStatus = true;
                                        strErrMsg = "already used in the " + ucPartpnt.StageName + " - REACTANT of the Reaction";
                                        _errmsg = strErrMsg;
                                        return blStatus;
                                    }
                                }
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg;
            return blStatus;
        }

        private bool CheckForAgent_Catalyst_Validataion(int _nrnnum, string _srccol,string _srcgrid, out string _errmsg)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                TabControl tbParent = (TabControl)this.Parent.Parent;
                ucParticipants ucPartpnt = null;
                foreach (TabPage tp in tbParent.TabPages)
                {
                    ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                    if (ucPartpnt != null)
                    {
                        DataTable _dtAgnt = ucPartpnt.dtAgent;
                        DataTable _dtCatlst = ucPartpnt.dtCatalyst;

                        if (_srcgrid.ToUpper() == "AGENT")
                        {
                            if (_dtCatlst != null)
                            {
                                if (_dtCatlst.Rows.Count > 0)
                                {
                                    DataRow[] dtRArr = _dtCatlst.Select("p" + _srccol + " = " + _nrnnum);
                                    if (dtRArr != null)
                                    {
                                        if (dtRArr.Length > 0)
                                        {
                                            if (Generic.GlobalVariables.RoleName.Trim().ToUpper() == "CURATOR" || Generic.GlobalVariables.RoleName.Trim().ToUpper() == "REVIEWER")//Don't allow Curator/Reviewer to add already used Reactant
                                            {
                                                blStatus = true;
                                                strErrMsg = "already used in the " + ucPartpnt.StageName + " - CATALYST of the Reaction.\r\n\r\nValue used in CATALYST can not be used in AGENT";
                                                _errmsg = strErrMsg;
                                                return blStatus;
                                            }
                                            else if (Generic.GlobalVariables.RoleName.Trim().ToUpper() == "SUPERVISOR" || Generic.GlobalVariables.RoleName.Trim().ToUpper() == "QUALITY CHECK")//Allow Supervisor to add already used Reactant
                                            {
                                                DialogResult diaRes = MessageBox.Show(_nrnnum + " already used in the " + ucPartpnt.StageName + " - CATALYST of the Reaction. Do you want to continue?", "AGENT - CATALYST", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                                                if (diaRes == DialogResult.Yes)
                                                {
                                                    _errmsg = strErrMsg;
                                                    return blStatus;
                                                }
                                                else
                                                {
                                                    blStatus = true;
                                                    _errmsg = strErrMsg;
                                                    return blStatus;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else if (_srcgrid.ToUpper() == "CATALYST")
                        {
                            if (_dtAgnt != null)
                            {
                                if (_dtAgnt.Rows.Count > 0)
                                {
                                    DataRow[] dtRArr = _dtAgnt.Select("p" + _srccol + " = " + _nrnnum);
                                    if (dtRArr != null)
                                    {
                                        if (dtRArr.Length > 0)
                                        {
                                            blStatus = true;
                                            strErrMsg = "already used in the " + ucPartpnt.StageName + " - AGENT of the Reaction.\r\n\r\nValue used in AGENT can not be used in CATALYST";
                                            _errmsg = strErrMsg;
                                            return blStatus;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg;
            return blStatus;
        }

        private bool CheckForReactant_Agent_Validation(int _nrnnum, string _srccol, string _srcgrid)
        {
            bool blStatus = false;
            try
            {
                DataTable dtTarget = null;

                if (_srcgrid.Trim().ToUpper() == "AGENT")
                {
                    dtTarget = dtReactant;
                }
                else if (_srcgrid.Trim().ToUpper() == "REACTANT")
                {
                    dtTarget = dtAgent;
                }               

                if (dtTarget != null)
                {
                    if (dtTarget.Rows.Count > 0)
                    {
                        DataRow[] dtRArr = dtTarget.Select("SERIES_NUM = " + _nrnnum);
                        if (dtRArr != null)
                        {
                            if (dtRArr.Length > 0)
                            {
                                blStatus = true;
                                return blStatus;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private bool CheckIfNumUsedInTable(int _nrnnum,string _srccol,string _srcgrid)
        {
            bool blStatus = false;           
            try 
            {
                DataTable dtTarget = null;
              
                if (_srcgrid.Trim().ToUpper() == "AGENT")
                {
                    dtTarget = dtAgent.Copy();
                }
                else if (_srcgrid.Trim().ToUpper() == "CATALYST")
                {
                    dtTarget = dtCatalyst.Copy();
                }
                else if (_srcgrid.Trim().ToUpper() == "SOLVENT")
                {
                    dtTarget = dtSolvent.Copy();
                }

                if (dtTarget != null)
                {
                    if (dtTarget.Rows.Count > 1)
                    {
                        DataRow[] dtRArr = dtTarget.Select("SERIES_NUM = " + _nrnnum);
                        if (dtRArr != null)
                        {
                            if (dtRArr.Length > 0)
                            {
                                blStatus = true;                                
                                return blStatus;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }           
            return blStatus;
        }

        //Value used in Catalyst Can't be used in anywhere in the Reaction,
        //Except it can be used in the any stage Catalyst in the Reaction
        private bool CheckForCatalyst_Reac_Solvent_Valdation(int _nrnnum, string _srccol, string _srcgrid, out string _errmsg)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                TabControl tbParent = (TabControl)this.Parent.Parent;
                ucParticipants ucPartpnt = null;
                foreach (TabPage tp in tbParent.TabPages)
                {
                    ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                    if (ucPartpnt != null)
                    {
                        DataTable dtRtant = ucPartpnt.dtReactant;
                        DataTable dtAgnt = ucPartpnt.dtAgent;
                        DataTable dtSvant = ucPartpnt.dtSolvent;
                        DataTable dtCatlst = ucPartpnt.dtCatalyst;

                        if (_srcgrid.ToUpper() == "REACTANT" || _srcgrid.ToUpper() == "AGENT" || _srcgrid.ToUpper() == "SOLVENT")
                        {
                            if (dtCatlst != null)
                            {
                                if (dtCatlst.Rows.Count > 0)
                                {
                                    DataRow[] dtRArr = dtCatlst.Select("SERIES_NUM = " + _nrnnum);
                                    if (dtRArr != null)
                                    {
                                        if (dtRArr.Length > 0)
                                        {
                                            if (Generic.GlobalVariables.RoleName.Trim().ToUpper() == "CURATOR" || Generic.GlobalVariables.RoleName.Trim().ToUpper() == "REVIEWER")//Don't allow Curator/Reviewer to add already used Reactant
                                            {
                                                blStatus = true;
                                                strErrMsg = "already used in the " + ucPartpnt.StageName + " - CATALYST of the Reaction.\r\n\r\nValue used in CATALYST can't be used anywhere in the Reaction";
                                                _errmsg = strErrMsg;
                                                return blStatus;
                                            }
                                            else if (Generic.GlobalVariables.RoleName.Trim().ToUpper() == "SUPERVISOR" || Generic.GlobalVariables.RoleName.Trim().ToUpper() == "QUALITY CHECK")//Allow Supervisor to add already used Reactant
                                            {
                                                DialogResult diaRes = MessageBox.Show(_nrnnum + " already used in the " + ucPartpnt.StageName + " - CATALYST of the Reaction. Do you want to continue?", "REACTANT / AGENT / SOLVENT - CATALYST", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                                                if (diaRes == DialogResult.Yes)
                                                {
                                                    _errmsg = strErrMsg;
                                                    return blStatus;
                                                }
                                                else
                                                {
                                                    blStatus = true;
                                                    _errmsg = strErrMsg;
                                                    return blStatus;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else if (_srcgrid.ToUpper() == "CATALYST")
                        {
                            if (dtRtant != null)
                            {
                                if (dtRtant.Rows.Count > 0)
                                {
                                    DataRow[] dtRArr = dtRtant.Select("SERIES_NUM = " + _nrnnum);
                                    if (dtRArr != null)
                                    {
                                        if (dtRArr.Length > 0)
                                        {
                                            if (Generic.GlobalVariables.RoleName.Trim().ToUpper() == "CURATOR" || Generic.GlobalVariables.RoleName.Trim().ToUpper() == "REVIEWER")//Don't allow Curator/Reviewer to add already used Reactant
                                            {
                                                blStatus = true;
                                                strErrMsg = "already used in the " + ucPartpnt.StageName + " - REACTANT of the Reaction.\r\n\r\nValue used in CATALYST can't be used anywhere in the Reaction";
                                                _errmsg = strErrMsg;
                                                return blStatus;
                                            }
                                            else if (Generic.GlobalVariables.RoleName.Trim().ToUpper() == "SUPERVISOR" || Generic.GlobalVariables.RoleName.Trim().ToUpper() == "QUALITY CHECK")//Allow Supervisor to add already used Reactant
                                            {
                                                DialogResult diaRes = MessageBox.Show(_nrnnum + " already used in the " + ucPartpnt.StageName + " - REACTANT of the Reaction. Do you want to continue?", "REACTANT - CATALYST", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                                                if (diaRes == DialogResult.Yes)
                                                {
                                                    _errmsg = strErrMsg;
                                                    return blStatus;
                                                }
                                                else
                                                {
                                                    blStatus = true;
                                                    _errmsg = strErrMsg;
                                                    return blStatus;
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            if (dtAgnt != null)
                            {
                                if (dtAgnt.Rows.Count > 0)
                                {
                                    DataRow[] dtRArr = dtAgnt.Select("SERIES_NUM = " + _nrnnum);
                                    if (dtRArr != null)
                                    {
                                        if (dtRArr.Length > 0)
                                        {
                                            if (Generic.GlobalVariables.RoleName.Trim().ToUpper() == "CURATOR" || Generic.GlobalVariables.RoleName.Trim().ToUpper() == "REVIEWER")//Don't allow Curator/Reviewer to add already used Reactant
                                            {
                                                blStatus = true;
                                                strErrMsg = "already used in the " + ucPartpnt.StageName + " - AGENT of the Reaction.\r\n\r\nValue used in CATALYST can't be used anywhere in the Reaction";
                                                _errmsg = strErrMsg;
                                                return blStatus;
                                            }
                                            else if (Generic.GlobalVariables.RoleName.Trim().ToUpper() == "SUPERVISOR" || Generic.GlobalVariables.RoleName.Trim().ToUpper() == "QUALITY CHECK")//Allow Supervisor to add already used Reactant
                                            {
                                                DialogResult diaRes = MessageBox.Show(_nrnnum + " already used in the " + ucPartpnt.StageName + " - AGENT of the Reaction. Do you want to continue?", "AGENT - CATALYST", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                                                if (diaRes == DialogResult.Yes)
                                                {
                                                    _errmsg = strErrMsg;
                                                    return blStatus;
                                                }
                                                else
                                                {
                                                    blStatus = true;
                                                    _errmsg = strErrMsg;
                                                    return blStatus;
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            if (dtSvant != null)
                            {
                                if (dtSvant.Rows.Count > 0)
                                {
                                    DataRow[] dtRArr = dtSvant.Select("SERIES_NUM = " + _nrnnum);
                                    if (dtRArr != null)
                                    {
                                        if (dtRArr.Length > 0)
                                        {
                                            if (Generic.GlobalVariables.RoleName.Trim().ToUpper() == "CURATOR" || Generic.GlobalVariables.RoleName.Trim().ToUpper() == "REVIEWER")//Don't allow Curator/Reviewer to add already used Reactant
                                            {
                                                blStatus = true;
                                                strErrMsg = "already used in the " + ucPartpnt.StageName + " - SOLVENT of the Reaction.\r\n\r\nValue used in CATALYST can't be used anywhere in the Reaction";
                                                _errmsg = strErrMsg;
                                                return blStatus;
                                            }
                                            else if (Generic.GlobalVariables.RoleName.Trim().ToUpper() == "SUPERVISOR" || Generic.GlobalVariables.RoleName.Trim().ToUpper() == "QUALITY CHECK")//Allow Supervisor to add already used Reactant
                                            {
                                                DialogResult diaRes = MessageBox.Show(_nrnnum + " already used in the " + ucPartpnt.StageName + " - SOLVENT of the Reaction. Do you want to continue?", "SOLVENT - CATALYST", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                                                if (diaRes == DialogResult.Yes)
                                                {
                                                    _errmsg = strErrMsg;
                                                    return blStatus;
                                                }
                                                else
                                                {
                                                    blStatus = true;
                                                    _errmsg = strErrMsg;
                                                    return blStatus;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg;
            return blStatus;
        }

        private bool CheckIfNumUsedIn_Any_Stage_Reactant(int _nrnnum, string _srcCol,string _partpnt, out string _errmsg)
        {
            bool blStatus = false;
            string strErrMsg = "";
            try
            {
                if (_partpnt.ToUpper() == "REACTANT")
                {
                    if (dtReactant != null)
                    {
                        if (dtReactant.Rows.Count > 0)
                        {
                            DataView dvTemp = dtReactant.Copy().DefaultView;
                            dvTemp.RowFilter = "SERIES_NUM = " + _nrnnum;

                            DataTable dtR = dvTemp.ToTable();
                            if (dtR != null)
                            {
                                if (dtR.Rows.Count > 0 && dtReactant.Rows.Count > 1)
                                {
                                    blStatus = true;
                                    _errmsg = _nrnnum + " already used in this stage";
                                    return blStatus;
                                }
                            }
                        }
                    }

                    TabControl tbParent = (TabControl)this.Parent.Parent;
                    ucParticipants ucPartpnt = null;
                    foreach (TabPage tp in tbParent.TabPages)
                    {
                        ucPartpnt = (ucParticipants)tp.Controls["ucParticipants"];
                        if (ucPartpnt != null)
                        {
                            if (ucPartpnt.StageName.ToUpper() != StageName.ToUpper())
                            {
                                DataTable dtRtant = ucPartpnt.dtReactant;
                                if (dtRtant != null)
                                {
                                    if (dtRtant.Rows.Count > 0)
                                    {
                                        DataRow[] dtRArr = dtRtant.Select("SERIES_NUM = " + _nrnnum);
                                        if (dtRArr != null)
                                        {
                                            if (dtRArr.Length > 0)
                                            {
                                                //Don't allow Curator/Reviewer to add already used Reactant
                                                if (Generic.GlobalVariables.RoleName.Trim().ToUpper() == "CURATOR" ||
                                                    Generic.GlobalVariables.RoleName.Trim().ToUpper() == "REVIEWER")
                                                {

                                                    blStatus = true;
                                                    strErrMsg = "already used in the " + ucPartpnt.StageName + " - REACTANT of the Reaction";
                                                    _errmsg = strErrMsg;
                                                    return blStatus;
                                                }
                                                else if (Generic.GlobalVariables.RoleName.Trim().ToUpper() == "SUPERVISOR" || Generic.GlobalVariables.RoleName.Trim().ToUpper() == "QUALITY CHECK")//Allow Supervisor to add already used Reactant
                                                {
                                                   DialogResult diaRes = MessageBox.Show(_nrnnum + " already used in the " + ucPartpnt.StageName + " - REACTANT of the Reaction. Do you want to continue?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                                                   if (diaRes == DialogResult.Yes)
                                                   {
                                                       _errmsg = strErrMsg;
                                                       return blStatus;
                                                   }
                                                   else
                                                   {
                                                       blStatus = true;
                                                       _errmsg = strErrMsg;
                                                       return blStatus;
                                                   }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg = strErrMsg;
            return blStatus;
        }

        private bool Validate_All_NRNNUM_Validations(int _nrnnum, string _srcCol,string _srccolprfix, string _partpntgrid, out string _errmsg_out)
        {
            bool blStatus = false;
            string strErrMsg = "";
            string strErrMsg_Out = "";
            try
            {
                //Check if NUM already used in Product
                if (CheckIfNumUsedInProduct(_nrnnum, _srcCol))
                {
                    blStatus = true;
                    strErrMsg = _nrnnum + "(" + _srccolprfix + _srcCol + ") value already used in the PRODUCT";
                   
                    _errmsg_out = strErrMsg;
                    return blStatus;
                }

                //Check if Num already used in the Table
                if (CheckIfNumUsedInTable(_nrnnum, _srcCol, strGridName))
                {
                    blStatus = true;
                    strErrMsg = _nrnnum + "(" + _srccolprfix + _srcCol + ") already used in this stage";

                    _errmsg_out = strErrMsg;
                    return blStatus;
                }

                //Reactant Vs Agent Validataion. Value used in Reactant can't be used in Agent and Vice-Versa
                if ((_partpntgrid.ToUpper() == "REACTANT" || _partpntgrid.ToUpper() == "AGENT")
                    && CheckForReactant_Agent_Validation(_nrnnum, _srcCol, _partpntgrid))
                {
                    blStatus = true;
                    strErrMsg = _nrnnum + "(" + _srccolprfix + _srcCol + ") is not valid. Reactant can't be Agent and vice-versa";
                    
                    _errmsg_out = strErrMsg;
                    return blStatus;
                }

                //Check if NUM already used in any stage Reactant
                if (CheckIfNumUsedIn_Any_Stage_Reactant(_nrnnum, _srcCol, _partpntgrid, out strErrMsg_Out))
                {
                    blStatus = true;
                    if (strErrMsg_Out.Trim() != "")
                    {
                        strErrMsg = _nrnnum + "(" + _srccolprfix + _srcCol + ") " + strErrMsg_Out;
                    }                    
                    _errmsg_out = strErrMsg;
                    return blStatus;
                }

                ////Agent Vs Catalyst validataion. Value used in Agent Can't be used in Catalyst and Vice-versa
                //if ((_partpntgrid.ToUpper() == "AGENT" || _partpntgrid.ToUpper() == "CATALYST")
                //    && (CheckForAgent_Catalyst_Validataion(_nrnnum, _srcCol, _partpntgrid, out strErrMsg_Out)))
                //{
                //    blStatus = true;
                //    strErrMsg = _nrnnum + "(" + _srccolprfix + _srcCol + ") " + strErrMsg_Out;
                    
                //    _errmsg_out = strErrMsg;
                //    return blStatus;
                //}

                //NUM used in Catalyst should not be in Anywhere in the Reaction
                if (CheckForCatalyst_Reac_Solvent_Valdation(_nrnnum, _srcCol, _partpntgrid, out strErrMsg_Out))
                {
                    blStatus = true;
                    if (strErrMsg_Out.Trim() != "")
                    {
                        strErrMsg = _nrnnum + "(" + _srccolprfix + _srcCol + ") " + strErrMsg_Out;
                    }
                    
                    _errmsg_out = strErrMsg;
                    return blStatus;
                }      
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _errmsg_out = strErrMsg;
            return blStatus;
        }
        
        private DataTable GetPrevStageRxnConditions(string _stagename,out string _prevstagename)
        {
            DataTable dtConds = null;
            string strPrevStage = "";
            try
            {
                frmReactCuration objParent = (frmReactCuration)this.Parent.Parent.Parent.Parent.Parent.Parent.Parent.Parent.Parent;
                if (objParent != null)
                {
                    if (objParent.tcStages != null)
                    {
                        if (objParent.tcStages.TabCount > 0)
                        {
                            for (int i = 0; i < objParent.tcStages.TabCount; i++)
                            {
                                if (objParent.tcStages.TabPages[i].Text.Trim().ToUpper() == _stagename.ToUpper())
                                {
                                    if (i > 0)
                                    {
                                        ucParticipants ucPartpnt = (ucParticipants)objParent.tcStages.TabPages[i-1].Controls["ucParticipants"];
                                        if (ucPartpnt != null)
                                        {
                                            strPrevStage = ucPartpnt.StageName;
                                            dtConds = ucPartpnt.dtConditions;
                                            _prevstagename = strPrevStage;
                                            return dtConds;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _prevstagename = strPrevStage;
            return dtConds;
        }      
                    
        private void GetNUMInfoFromNUMsTable(int serNumID, string numType)
        {
            //try
            //{
            //    if (serNumID > 0 && !string.IsNullOrEmpty(numType))
            //    {
            //        frmNUMInfo objNumInfo = new frmNUMInfo();
            //        objNumInfo.BindDataToStructurePanel(nrnreg, nrnnum);
            //        objNumInfo.ShowDialog();
            //    }
            //}
            //catch (Exception ex)
            //{
            //    ErrorHandling.WriteErrorLog(ex.ToString());
            //}
        }

        private void BindStructurePropsToNumsInfo(ChemStructure chemStruct)
        {
            try
            {
                if (chemStruct != null)
                {
                    frmNUMInfo objNumInfo = new frmNUMInfo();
                    objNumInfo.BindStructureDataToPanel(chemStruct);
                    objNumInfo.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private ChemStructure GetStructurePropertiesOnSeriesNumID(int serNumID, string serNumType)
        {
            ChemStructure chemStruct = null;
            try
            {
                if (serNumID > 0 && !string.IsNullOrEmpty(serNumType))
                {
                    if (serNumType.ToUpper() == "NUM")
                    {
                        var rows = NUM_RegNosTbl.AsEnumerable().Where(r => r.Field<Int64>("TAN_NUM_ID") == serNumID);
                        if (rows != null)
                        {
                            if (rows.Count() > 0)
                            {
                                foreach (DataRow dr in rows)
                                {
                                    chemStruct = new ChemStructure();
                                    chemStruct.SeriesNum = dr["NUM"].ToString();
                                    chemStruct.RegNo = dr["REG_NO"].ToString();
                                    chemStruct.MolFormula = dr["FORMULA"].ToString();
                                    chemStruct.MolName = dr["IUPAC_NAME"].ToString();
                                    chemStruct.MolStructure = dr["MOL_FILE"].ToString();
                                    chemStruct.MolSynonym = dr["OTHER_NAMES"].ToString();
                                    chemStruct.MolHexArr = new string[] { dr["MOL_HEX_CODE"].ToString() };
                                    chemStruct.PeptideSeq = dr["PEPTIDE_SEQ"].ToString();
                                    chemStruct.NuclicAcidSeq = dr["NUCLIC_ACID_SEQ"].ToString();
                                    //chemStruct.AbsoluteStrereo = new string[] { dr["MOL_HEX_CODE"].ToString() }; 
                                }
                            }
                        }
                    }
                    else if (serNumType.ToUpper() == "9000")
                    {
                        var rows = GlobalVariables.Ser9000OrgRefData.AsEnumerable().Where(r => r.Field<Int64>("ORGREF_ID") == serNumID);
                        if (rows != null)
                        {
                            if (rows.Count() > 0)
                            {
                                foreach (DataRow dr in rows)
                                {
                                    chemStruct = new ChemStructure();
                                    chemStruct.SeriesNum = dr["NUM"].ToString();
                                    chemStruct.RegNo = dr["REG_NO"].ToString();
                                    chemStruct.MolName = dr["ORGREF_NAME"].ToString();
                                    chemStruct.MolStructure =  dr["MOL_FILE"].ToString();                                       
                                }
                            }
                        }
                    }
                    else if (serNumType.ToUpper() == "8500")
                    {
                        var rows = GlobalVariables.Ser8500OrgrefData.AsEnumerable().Where(r => r.Field<Int64>("ORGREF_ID") == serNumID);
                        if (rows != null)
                        {
                            if (rows.Count() > 0)
                            {
                                if (rows.Count() > 0)
                                {
                                    foreach (DataRow dr in rows)
                                    {
                                        chemStruct = new ChemStructure();
                                        chemStruct.SeriesNum = dr["NUM"].ToString();
                                        chemStruct.RegNo = dr["REG_NO"].ToString();
                                        chemStruct.MolName = dr["ORGREF_NAME"].ToString();
                                        chemStruct.MolStructure = dr["MOL_FILE"].ToString();                                
                                    }
                                }
                            }
                        }
                    }
                    else if (serNumType.ToUpper() == "8000")
                    {
                        var rows = GlobalVariables.TAN_Series8000Data.AsEnumerable().Where(r => r.Field<Int64>("TS_ID") == serNumID);
                        if (rows != null)
                        {
                            if (rows.Count() > 0)
                            {
                                foreach (DataRow dr in rows)
                                {
                                    chemStruct = new ChemStructure();
                                    chemStruct.SeriesNum = dr["SERIES_8000"].ToString();                                 
                                    chemStruct.MolName = dr["SUBST_NAME"].ToString();
                                    chemStruct.MolStructure = dr["SUBST_MOLECULE"].ToString();
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return chemStruct;
        }

        private void lnkEditRSN_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                if (RxnStageID > 0 && ReactionID > 0)
                {
                    using (frmRSN objRSN = new frmRSN())
                    {
                        objRSN.StageName = StageName;
                        objRSN.ReactionID = ReactionID;
                        objRSN.StageID = RxnStageID;
                        objRSN.RSNData = dtRSN.Copy();
                        objRSN.StageName = StageName;
                        objRSN.TabCntrl_Stages = (TabControl)this.Parent.Parent;
                                              
                        if (objRSN.ShowDialog() == DialogResult.OK)
                        {
                            dtRSN = objRSN.RSNData;
                            BindDataToRSNGrid(dtRSN);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
                              
        #region Edit Participants LinkClicked Events

        public void AddRecToParticipantTables_IRN(string partpnttype, int newpartpntid,string regno, int seriesnumid,int seriesnum, string partpntname,string seriestype, int rowindex, string before_after, int rxnid, int rxnstageid)
        {
            try
            {
                if (newpartpntid > 0)
                {
                    switch (partpnttype.Trim().ToUpper())
                    {
                        case "AGENT":

                            if (dtAgent == null)
                            {
                                dtAgent = GetParticipantsTableDefinition();
                            }

                            DataRow drA = dtAgent.NewRow();
                            drA["RPP_ID"] = newpartpntid;                           
                            drA["RXN_ID"] = rxnid;
                            drA["RXN_STAGE_ID"] = rxnstageid;
                            drA["PP_NAME"] = partpntname;
                            drA["REG_NO"] = regno;
                            drA["SERIES_NUM"] = seriesnum;
                            drA["SER_TAN_NUM_ID"] = seriesnumid;
                            drA["SER_TYPE"] = seriestype;

                            if (before_after == "BEFORE" || before_after == "END")
                            {
                                drA["DISPLAY_ORDER"] = rowindex + 1;
                                dtAgent.Rows.InsertAt(drA, rowindex);
                            }
                            else if (before_after == "AFTER")
                            {
                                drA["DISPLAY_ORDER"] = rowindex + 2;
                                dtAgent.Rows.InsertAt(drA, rowindex + 1);
                            }

                            //Change Display order in Agent table
                            dtAgent = ChangeDisplayOrderInParticipantTable(dtAgent, rowindex + 1, before_after);
                            dtAgent.TableName = Generic.Enums.ParticipantType.AGENT.ToString();
                            dgvAgent.DataSource = dtAgent;

                            break;

                        case "REACTANT":

                            if (dtReactant == null)
                            {
                                dtReactant = GetParticipantsTableDefinition();
                            }
                            DataRow drR = dtReactant.NewRow();
                            drR["RPP_ID"] = newpartpntid;
                            drR["RXN_ID"] = rxnid;
                            drR["RXN_STAGE_ID"] = rxnstageid;
                            drR["PP_NAME"] = partpntname;
                            drR["REG_NO"] = regno;
                            drR["SERIES_NUM"] = seriesnum;
                            drR["SER_TAN_NUM_ID"] = seriesnumid;
                            drR["SER_TYPE"] = seriestype;

                            if (before_after == "BEFORE" || before_after == "END")
                            {
                                drR["DISPLAY_ORDER"] = rowindex + 1;
                                dtReactant.Rows.InsertAt(drR, rowindex);
                            }
                            else if (before_after == "AFTER")
                            {
                                drR["DISPLAY_ORDER"] = rowindex + 2;
                                dtReactant.Rows.InsertAt(drR, rowindex + 1);
                            }

                            //Change Display order in Reactants table
                            dtReactant = ChangeDisplayOrderInParticipantTable(dtReactant, rowindex + 1, before_after);
                            dtReactant.TableName = Generic.Enums.ParticipantType.REACTANT.ToString();
                            dgvReactant.DataSource = dtReactant;
                            break;

                        case "CATALYST":

                            if (dtCatalyst == null)
                            {
                                dtCatalyst = GetParticipantsTableDefinition();
                            }

                            DataRow drC = dtCatalyst.NewRow();
                            drC["RPP_ID"] = newpartpntid;
                            drC["RXN_ID"] = rxnid;
                            drC["RXN_STAGE_ID"] = rxnstageid;
                            drC["PP_NAME"] = partpntname;
                            drC["REG_NO"] = regno;
                            drC["SERIES_NUM"] = seriesnum;
                            drC["SER_TAN_NUM_ID"] = seriesnumid;
                            drC["SER_TYPE"] = seriestype;

                            if (before_after == "BEFORE" || before_after == "END")
                            {
                                drC["DISPLAY_ORDER"] = rowindex + 1;
                                dtCatalyst.Rows.InsertAt(drC, rowindex);
                            }
                            else if (before_after == "AFTER")
                            {
                                drC["DISPLAY_ORDER"] = rowindex + 2;
                                dtCatalyst.Rows.InsertAt(drC, rowindex + 1);
                            }
                            //Change Display order in Catalyst table
                            dtCatalyst = ChangeDisplayOrderInParticipantTable(dtCatalyst, rowindex + 1, before_after);

                            dtCatalyst.TableName = Generic.Enums.ParticipantType.CATALYST.ToString();
                            dgvCatalyst.DataSource = dtCatalyst;
                            break;

                        case "SOLVENT":

                            if (dtSolvent == null)
                            {
                                dtSolvent = GetParticipantsTableDefinition();
                            }

                            DataRow drS = dtSolvent.NewRow();
                            drS["RPP_ID"] = newpartpntid;
                            drS["RXN_ID"] = rxnid;
                            drS["RXN_STAGE_ID"] = rxnstageid;
                            drS["PP_NAME"] = partpntname;
                            drS["REG_NO"] = regno;
                            drS["SERIES_NUM"] = seriesnum;
                            drS["SER_TAN_NUM_ID"] = seriesnumid;
                            drS["SER_TYPE"] = seriestype;

                            if (before_after == "BEFORE" || before_after == "END")
                            {
                                drS["DISPLAY_ORDER"] = rowindex + 1;
                                dtSolvent.Rows.InsertAt(drS, rowindex);
                            }
                            else if (before_after == "AFTER")
                            {
                                drS["DISPLAY_ORDER"] = rowindex + 2;
                                dtSolvent.Rows.InsertAt(drS, rowindex + 1);
                            }
                            //Change Display order in Solvent table
                            dtSolvent = ChangeDisplayOrderInParticipantTable(dtSolvent, rowindex + 1, before_after);
                            dtSolvent.TableName = Generic.Enums.ParticipantType.SOLVENT.ToString();
                            dgvSolvent.DataSource = dtSolvent;
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void lnlReactant_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                int intRowIndx = 0;
                string strInsOpt = "AFTER";

                string partpntType = "";
                LinkLabel lnk = sender as LinkLabel;
                if (lnk != null)
                {
                    DataTable partpntData = null;
                    DataTable rctOrAgentData = null;
                    switch (lnk.Tag.ToString().ToUpper())
                    {
                        case "REACTANT":
                            partpntType = "REACTANT";
                            strInsOpt = dgvReactant.CurrentCell != null ? "AFTER" : "END";
                            intRowIndx = dgvReactant.CurrentCell != null ? dgvReactant.CurrentCell.RowIndex : 0;
                            partpntData = dtReactant;
                            rctOrAgentData = dtAgent;
                            break;
                        case "AGENT":
                            partpntType = "AGENT";
                            strInsOpt = dgvAgent.CurrentCell != null ? "AFTER" : "END";
                            intRowIndx = dgvAgent.CurrentCell != null ? dgvAgent.CurrentCell.RowIndex : 0;
                            partpntData = dtAgent;
                            rctOrAgentData = dtReactant;
                            break;
                        case "CATALYST":
                            partpntType = "CATALYST";
                            strInsOpt = dgvCatalyst.CurrentCell != null ? "AFTER" : "END";
                            intRowIndx = dgvCatalyst.CurrentCell != null ? dgvCatalyst.CurrentCell.RowIndex : 0;
                            partpntData = dtCatalyst;
                            break;
                        case "SOLVENT":
                            partpntType = "SOLVENT";
                            strInsOpt = dgvSolvent.CurrentCell != null ? "AFTER" : "END";
                            intRowIndx = dgvSolvent.CurrentCell != null ? dgvSolvent.CurrentCell.RowIndex : 0;
                            partpntData = dtSolvent;
                            break;
                    }

                    if (!string.IsNullOrEmpty(partpntType))
                    {
                        using (frmNUMs objNUMs = new frmNUMs())
                        {
                            objNUMs.TAN_NUMsTbl = NUM_RegNosTbl;
                            objNUMs.SrcParticipant = partpntType;
                            objNUMs.SrcPartpntData = partpntData;
                            objNUMs.SrcStageName = StageName;
                            objNUMs.RctOrAgentData = rctOrAgentData;

                            if (objNUMs.ShowDialog(this) == DialogResult.OK)
                            {
                                if (objNUMs.Sel_NUM > 0)
                                {
                                    //Validate all NUM validations
                                    //Check if NUM already used in Product
                                    //Check if Num already used in the Table
                                    //Reactant Vs Agent Validataion. Value used in Reactant can't be used in Agent and Vice-Versa
                                    //Check if NUM already used in any stage Reactant
                                    //NUM used in Catalyst should not be in Anywhere in the Reaction

                                    //Get New participant ID
                                    int intNewParpntID = ReactDB.GetReactionNewParticipantID(partpntType, ReactionID, RxnStageID, rowindex + 1, strInsOpt, GlobalVariables.URID);

                                    //Add to Participant table
                                    AddRecToParticipantTables_IRN(partpntType, intNewParpntID, objNUMs.Sel_RegNo.ToString(), objNUMs.Sel_Ser_NUM_ID, objNUMs.Sel_NUM, objNUMs.Sel_Name, objNUMs.SeriesType, rowindex + 1, strInsOpt, ReactionID, RxnStageID);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }    
        
       #endregion

        private void lnkEditCondition_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                string strPrevStage = "";

                frmConditions objConds = new frmConditions();
                objConds.StageName = StageName;
                objConds.ReactionID = ReactionID;
                objConds.RxnStageID = RxnStageID;
                objConds.ConditionsTbl = dtConditions;
                objConds.PrevStgCondsTbl = GetPrevStageRxnConditions(StageName, out strPrevStage);//Get previous stage last condition
                objConds.PrevStageName = strPrevStage;
                if (objConds.ShowDialog() == DialogResult.OK)
                {
                    dtConditions = objConds.ConditionsTbl;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
