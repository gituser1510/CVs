﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using IndxReactNarr.Generic;
using HtmlRichText;

namespace IndxReactNarr.UserControls
{
    public partial class ucHtmlRichText : UserControl
    {
        public ucHtmlRichText()
        {
            InitializeComponent();
            try
            {
                rapidSpellAsYouType1.DictFilePath = System.IO.Path.Combine(Application.StartupPath, "DICT-EN-US-USEnglish.dict");
                rapidSpellAsYouType1.RapidSpellChecker.ShareDictionary = true;
            }
            catch
            { }
        }
              
        public bool PreserveMultiLines { get; set; }

        public bool HighlightMaterials { get; set; }

        private void hrtbPara_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.F9)//Format Text
                {
                    FormatAndHighLightControlText();
                }
                else if (e.KeyCode == Keys.F2)//Set Subscript
                {
                    if (!hrtbPara.IsSubScript())
                    {
                        hrtbPara.SetSuperScript(false);
                        hrtbPara.SetSubScript(true);
                    }
                    else
                    {
                        hrtbPara.SetSubScript(false);
                    }
                }
                else if (e.KeyCode == Keys.F3)//Set Superscript
                {
                    if (!hrtbPara.IsSuperScript())
                    {
                        hrtbPara.SetSuperScript(true);
                        hrtbPara.SetSubScript(false);
                    }
                    else
                    {
                        hrtbPara.SetSuperScript(false);
                    }
                }
                else if (e.KeyCode == Keys.F4)//Set Italic
                {
                    if (hrtbPara.SelectedText != null)
                    {
                        if (hrtbPara.SelectionFont == null)
                            hrtbPara.SelectionFont = new Font(hrtbPara.Font, hrtbPara.Font.Style ^ FontStyle.Italic);
                        else
                            hrtbPara.SelectionFont = new Font(hrtbPara.SelectionFont, hrtbPara.SelectionFont.Style ^ FontStyle.Italic);
                    }
                }
                else if (e.KeyCode == Keys.F5)//Set Bold
                {
                    if (hrtbPara.SelectedText != null)
                    {
                        if (hrtbPara.SelectionFont == null)
                            hrtbPara.SelectionFont = new Font(hrtbPara.Font, hrtbPara.Font.Style ^ FontStyle.Bold);
                        else
                            hrtbPara.SelectionFont = new Font(hrtbPara.SelectionFont, hrtbPara.SelectionFont.Style ^ FontStyle.Bold);
                    }
                }
                else if (e.KeyCode == Keys.F6)//Convert to Formula
                {
                    if (hrtbPara.SelectedText != null)
                    {
                        using (HtmlRichTextBox hrtb = new HtmlRichTextBox())
                        {
                            hrtb.Text = hrtbPara.SelectedText;
                            int startposition = hrtbPara.SelectionStart;
                            int endpostion = hrtbPara.SelectionLength;
                            string strtext = hrtbPara.SelectedText;
                            string a = strtext;
                         
                            for (int i = 0; i < a.Length; i++)
                            {

                                string x = a.Substring(i, 1);

                                if (char.IsNumber(Convert.ToChar(x)))
                                {
                                    hrtb.Select(i, 1);
                                    hrtb.SetSubScript(true);
                                    hrtb.SetSuperScript(false);
                                }
                            }
                            hrtb.SelectAll();
                            hrtbPara.SelectedRtf = hrtb.SelectedRtf;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public void BindDataToControl(string htmlvalue)
        {
            try
            {
                if (!string.IsNullOrEmpty(htmlvalue) && hrtbPara != null && !hrtbPara.IsDisposed)
                {
                    hrtbPara.Rtf = Html_RtfConversions.Instance.GetRTFfromHTMLString(htmlvalue, PreserveMultiLines);

                    HighLightSpecialWordsInText();

                    if (HighlightMaterials)
                    {
                        HighLightEquipmentsInProcedureText();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public string GetHtmlStringFromControl()
        {
            string strHtml = "";
            try
            {
                if (!string.IsNullOrEmpty(hrtbPara.Text))
                {
                    strHtml = Html_RtfConversions.Instance.GetHTMLFromRTFString(hrtbPara.Rtf);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strHtml.Trim();
        }

        private void FormatAndHighLightControlText()
        {
            try
            {
                if (GlobalVariables.ApplicationName.ToString() == Enums.ApplicationName.NARRATIVES.ToString() ||
                    GlobalVariables.ApplicationName.ToString() == Enums.ApplicationName.EXPPROCEDURES.ToString())
                {
                    //Auto replace specified words
                    ReplaceSpecificWordsInText();

                    //Replace specified words and highlight words
                    HighLightSpecialWordsInText();

                    if (HighlightMaterials)
                    {
                        HighLightEquipmentsInProcedureText();
                    }
                }
                else
                {
                    hrtbPara.Rtf = Html_RtfConversions.Instance.GetFormattedRtfFromRtf(hrtbPara.Rtf, PreserveMultiLines);
                }  
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        int indexOfSearchText = 0;
        private void HighlightUnknowSymbols(HtmlRichText.HtmlRichTextBox rtf)
        {
            try
            {
                ArrayList ht = new ArrayList();
                ht.Add("ä");
                ht.Add("");
                ht.Add("_");
                ht.Add("(()");
                ht.Add("íL");
                ht.Add("−");
                ht.Add("â");
                ht.Add("î");
                ht.Add("è");
                ht.Add("í");
                ht.Add("¢");//ãåö×ÃÄÅ
                ht.Add("é");
                ht.Add("ê");
                ht.Add("ë");
                ht.Add("ì");
                ht.Add("í");
                ht.Add("î");
                ht.Add("ï");
                ht.Add("ð");
                ht.Add("â");
                ht.Add("Á");
                ht.Add("À");
                ht.Add("Æ");
                ht.Add("¶");
                ht.Add("£");
                ht.Add("ø");
                ht.Add("À");
                ht.Add("Â");
                ht.Add("ù");
                ht.Add("ú");
                ht.Add("û");
                ht.Add("ü");
                
                for (int i = 0; i < ht.Count; i++)
                {
                    if (rtf.Text.Contains(ht[i].ToString()))
                    {
                        bool blnloop = false;
                        int startindex = 0;
                        indexOfSearchText = 0;
                        int start = 0;
                        while (blnloop == false)
                        {
                            if (ht[i].ToString().Length > 0)
                            {
                                startindex = FindMyText(ht[i].ToString(), start, rtf.Text.Length, rtf);
                                if (startindex == -1)
                                {
                                    blnloop = true;
                                }
                            }

                            if (startindex >= 0)
                            {
                                // Set the highlight color as red
                                int endindex = ht[i].ToString().Length;
                                // Highlight the search string
                                rtf.Select(startindex, endindex);

                                rtf.SelectionBackColor = Color.Red;

                                start = startindex + endindex;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        int HeighlightSearchIndex = 0;
        private void HighLightSpecialWordsInText()
        {
            try
            {
                //Highlight specified words
                string Word = null;
                int startindex = 0;

                if (GlobalVariables.NarrHighLightingData != null)
                {
                    for (int i = 0; i < Generic.GlobalVariables.NarrHighLightingData.Rows.Count; i++)
                    {
                        Word = Generic.GlobalVariables.NarrHighLightingData.Rows[i]["SPECIAL_CHAR"].ToString();//lstSpecialChar[i].ToString();
                        HeighlightSearchIndex = 0;
                        int SourceStringStartIndex = 0;
                        startindex = FindMyText(hrtbPara, Word, SourceStringStartIndex, hrtbPara.TextLength);
                        while (startindex >= 0)
                        {
                            // Setting Heighlight color.
                            hrtbPara.SelectionBackColor = Color.Orange;

                            // Find the end index. End Index = number of characters in textbox
                            int endindex = Word.Length;

                            // select the search string
                            hrtbPara.Select(startindex, endindex);

                            SourceStringStartIndex = startindex + endindex;
                            startindex = FindMyText(hrtbPara, Word, SourceStringStartIndex, hrtbPara.TextLength);
                        }
                    }
                }
                hrtbPara.Select(hrtbPara.TextLength, 0);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        //int FindSearchIndex = 0;
        public void HighLightSpecialWordsInText_QuickFind(string findWord)
        {
            try
            {
                //Highlight specified words
                string Word = findWord;
                int startindex = 0;
                if (!string.IsNullOrEmpty(hrtbPara.Text))
                {
                    //FormatAndHighLightControlText();
                    hrtbPara.Rtf = Html_RtfConversions.Instance.GetFormattedRtfFromRtf(hrtbPara.Rtf, PreserveMultiLines);

                    HeighlightSearchIndex = 0;
                    int SourceStringStartIndex = 0;
                    startindex = FindMyText(hrtbPara, Word, SourceStringStartIndex, hrtbPara.TextLength);
                    while (startindex >= 0)
                    {
                        // Setting Heighlight color.
                        hrtbPara.SelectionBackColor = Color.Aqua;

                        // Find the end index. End Index = number of characters in textbox
                        int endindex = Word.Length;

                        // select the search string
                        hrtbPara.Select(startindex, endindex);

                        SourceStringStartIndex = startindex + endindex;
                        startindex = FindMyText(hrtbPara, Word, SourceStringStartIndex, hrtbPara.TextLength);
                    }

                    hrtbPara.Select(hrtbPara.TextLength, 0);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        //Highlight Equipments
        private void HighLightEquipmentsInProcedureText()
        {
            try
            {
                //Highlight specified words
                string Word = null;
                int startindex = 0;

                if (GlobalVariables.MaterialsData != null && GlobalVariables.MaterialsData.Rows.Count > 0 && !string.IsNullOrEmpty(hrtbPara.Text))
                {
                    for (int i = 0; i < Generic.GlobalVariables.MaterialsData.Rows.Count; i++)
                    {
                        Word = Generic.GlobalVariables.MaterialsData.Rows[i]["MATERIAL_NAME"].ToString();//lstSpecialChar[i].ToString();
                        HeighlightSearchIndex = 0;
                        int SourceStringStartIndex = 0;
                        startindex = FindMyText(hrtbPara, Word, SourceStringStartIndex, hrtbPara.TextLength);
                        while (startindex >= 0)
                        {
                            // Setting Heighlight color.
                            hrtbPara.SelectionBackColor = Color.LightGreen;

                            // Find the end index. End Index = number of characters in textbox
                            int endindex = Word.Length;

                            // select the search string
                            hrtbPara.Select(startindex, endindex);

                            SourceStringStartIndex = startindex + endindex;
                            startindex = FindMyText(hrtbPara, Word, SourceStringStartIndex, hrtbPara.TextLength);
                        }
                    }
                }
                hrtbPara.Select(hrtbPara.TextLength, 0);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void ReplaceSpecificWordsInText()
        {
            try
            {              
                //Replace specified words
                if (GlobalVariables.NarrReplacementData != null)
                {
                    string htmlStr = Html_RtfConversions.Instance.GetHTMLFromRTFString(hrtbPara.Rtf);

                    for (int i = 0; i < GlobalVariables.NarrReplacementData.Rows.Count; i++)
                    {
                        if (htmlStr.Contains(GlobalVariables.NarrReplacementData.Rows[i]["SPECIAL_CHAR"].ToString()))
                        {
                            htmlStr = htmlStr.Replace(GlobalVariables.NarrReplacementData.Rows[i]["SPECIAL_CHAR"].ToString(), GlobalVariables.NarrReplacementData.Rows[i]["REPLACEMENT_CHAR"].ToString());
                        }
                    }

                    hrtbPara.Rtf = Html_RtfConversions.Instance.GetRTFfromHTMLString(htmlStr, PreserveMultiLines);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public int FindMyText(string txtToSearch, int searchStart, int searchEnd, HtmlRichText.HtmlRichTextBox rtb)
        {
            // Unselect the previously searched string
            //if (searchStart > 0 && searchEnd > 0 && indexOfSearchText >= 0)
            //{
            //    return -1;
            //   // rtb.Undo();
            //}

            // Set the return value to -1 by default.
            int retVal = -1;

            // A valid starting index should be specified.
            // if indexOfSearchText = -1, the end of search
            if (searchStart >= 0 && indexOfSearchText >= 0)
            {
                // A valid ending index
                if (searchEnd > searchStart || searchEnd == -1)
                {
                    rtb.Refresh();
                    // Find the position of search string in RichTextBox
                    indexOfSearchText = rtb.Find(txtToSearch, searchStart, searchEnd, RichTextBoxFinds.None);
                    //indexOfSearchText = rtb.Find(txtToSearch);
                    // Determine whether the text was found in richTextBox1.
                    //if (indexOfSearchText != searchStart)
                    //{
                    // Return the index to the specified search text.
                    retVal = indexOfSearchText;
                    //}
                    //else
                    //{
                    //    return -1;
                    //}
                }
            }
            return retVal;
        }

        public int FindMyText(HtmlRichTextBox item, string txtToSearch, int searchStart, int searchEnd)
        {
            // Set the return value to -1 by default.
            int retVal = -1;

            try
            {               

                // A valid starting index should be specified.
                // if indexOfSearchText = -1, the end of search
                if (searchStart >= 0 && HeighlightSearchIndex >= 0)
                {
                    // A valid ending index
                    if (searchEnd > searchStart || searchEnd == -1)
                    {
                        // Find the position of search string in RichTextBox
                        HeighlightSearchIndex = item.Find(txtToSearch, searchStart, searchEnd, RichTextBoxFinds.MatchCase);
                        // Determine whether the text was found in richTextBox1.
                        if (HeighlightSearchIndex != -1)
                        {
                            // Return the index to the specified search text.
                            retVal = HeighlightSearchIndex;
                        }
                    }
                }                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return retVal;
        }

        public bool ValidateUniCodes(out string errMsg_Out)
        {
            bool blStatus = true;
            string strErr = "";
            try
            {
                if (Common.Validations.ValidateUnicodeCharactersInString(hrtbPara.Text.Trim(), out strErr))//New validation on 10th Sep 2014
                {
                    blStatus = false;
                    strErr = "contains invalid characters " + strErr.Trim();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsg_Out = strErr;
            return blStatus;
        }

        public bool IsASCII()
        {
            bool blStatus = false;
            try
            {
                // ASCII encoding replaces non-ascii with question marks, so we use UTF8 to see if multi-byte sequences are there
                blStatus = Encoding.UTF8.GetByteCount(hrtbPara.Text) == hrtbPara.Text.Length;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;            
        }
    }
}
