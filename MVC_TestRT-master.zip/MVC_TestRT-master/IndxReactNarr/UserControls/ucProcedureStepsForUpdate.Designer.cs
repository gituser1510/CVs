﻿namespace IndxReactNarr.UserControls
{
    partial class ucProcedureStepsForUpdate
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlProcSteps = new System.Windows.Forms.Panel();
            this.splContProcSteps = new System.Windows.Forms.SplitContainer();
            this.uchrtbProcedureSteps = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.dgvRxnSubsts = new System.Windows.Forms.DataGridView();
            this.colSubstID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSubstRegNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSubstRole = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblProcSteps = new System.Windows.Forms.Label();
            this.lblNarID = new System.Windows.Forms.Label();
            this.pnlMain.SuspendLayout();
            this.pnlProcSteps.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splContProcSteps)).BeginInit();
            this.splContProcSteps.Panel1.SuspendLayout();
            this.splContProcSteps.Panel2.SuspendLayout();
            this.splContProcSteps.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRxnSubsts)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlMain.Controls.Add(this.pnlProcSteps);
            this.pnlMain.Controls.Add(this.lblNarID);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(978, 227);
            this.pnlMain.TabIndex = 0;
            // 
            // pnlProcSteps
            // 
            this.pnlProcSteps.Controls.Add(this.splContProcSteps);
            this.pnlProcSteps.Controls.Add(this.lblProcSteps);
            this.pnlProcSteps.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlProcSteps.Location = new System.Drawing.Point(0, 23);
            this.pnlProcSteps.Name = "pnlProcSteps";
            this.pnlProcSteps.Size = new System.Drawing.Size(976, 202);
            this.pnlProcSteps.TabIndex = 2;
            // 
            // splContProcSteps
            // 
            this.splContProcSteps.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContProcSteps.Location = new System.Drawing.Point(0, 23);
            this.splContProcSteps.Name = "splContProcSteps";
            // 
            // splContProcSteps.Panel1
            // 
            this.splContProcSteps.Panel1.Controls.Add(this.uchrtbProcedureSteps);
            // 
            // splContProcSteps.Panel2
            // 
            this.splContProcSteps.Panel2.Controls.Add(this.dgvRxnSubsts);
            this.splContProcSteps.Size = new System.Drawing.Size(976, 179);
            this.splContProcSteps.SplitterDistance = 732;
            this.splContProcSteps.TabIndex = 3;
            // 
            // uchrtbProcedureSteps
            // 
            this.uchrtbProcedureSteps.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.uchrtbProcedureSteps.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uchrtbProcedureSteps.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uchrtbProcedureSteps.Location = new System.Drawing.Point(0, 0);
            this.uchrtbProcedureSteps.Name = "uchrtbProcedureSteps";
            this.uchrtbProcedureSteps.PreserveMultiLines = true;
            this.uchrtbProcedureSteps.Size = new System.Drawing.Size(732, 179);
            this.uchrtbProcedureSteps.TabIndex = 1;
            // 
            // dgvRxnSubsts
            // 
            this.dgvRxnSubsts.AllowUserToAddRows = false;
            this.dgvRxnSubsts.AllowUserToDeleteRows = false;
            this.dgvRxnSubsts.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvRxnSubsts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvRxnSubsts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRxnSubsts.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSubstID,
            this.colSubstRegNo,
            this.colSubstRole});
            this.dgvRxnSubsts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvRxnSubsts.Location = new System.Drawing.Point(0, 0);
            this.dgvRxnSubsts.MultiSelect = false;
            this.dgvRxnSubsts.Name = "dgvRxnSubsts";
            this.dgvRxnSubsts.ReadOnly = true;
            this.dgvRxnSubsts.RowHeadersVisible = false;
            this.dgvRxnSubsts.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRxnSubsts.Size = new System.Drawing.Size(240, 179);
            this.dgvRxnSubsts.TabIndex = 3;
            // 
            // colSubstID
            // 
            this.colSubstID.DataPropertyName = "SUBST_IDENTIFIER";
            this.colSubstID.HeaderText = "Substance";
            this.colSubstID.Name = "colSubstID";
            this.colSubstID.ReadOnly = true;
            this.colSubstID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colSubstRegNo
            // 
            this.colSubstRegNo.DataPropertyName = "SUBST_REG_NO";
            this.colSubstRegNo.HeaderText = "Reg.No";
            this.colSubstRegNo.Name = "colSubstRegNo";
            this.colSubstRegNo.ReadOnly = true;
            this.colSubstRegNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colSubstRole
            // 
            this.colSubstRole.DataPropertyName = "SUBST_ROLE";
            this.colSubstRole.HeaderText = "Role";
            this.colSubstRole.Name = "colSubstRole";
            this.colSubstRole.ReadOnly = true;
            this.colSubstRole.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // lblProcSteps
            // 
            this.lblProcSteps.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblProcSteps.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblProcSteps.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblProcSteps.Location = new System.Drawing.Point(0, 0);
            this.lblProcSteps.Name = "lblProcSteps";
            this.lblProcSteps.Size = new System.Drawing.Size(976, 23);
            this.lblProcSteps.TabIndex = 2;
            this.lblProcSteps.Text = "Procedure Steps";
            this.lblProcSteps.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNarID
            // 
            this.lblNarID.BackColor = System.Drawing.Color.OldLace;
            this.lblNarID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblNarID.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblNarID.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNarID.ForeColor = System.Drawing.Color.Blue;
            this.lblNarID.Location = new System.Drawing.Point(0, 0);
            this.lblNarID.Name = "lblNarID";
            this.lblNarID.Size = new System.Drawing.Size(976, 23);
            this.lblNarID.TabIndex = 0;
            this.lblNarID.Text = "Nar - ";
            this.lblNarID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ucProcedureStepsForUpdate
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.pnlMain);
            this.Name = "ucProcedureStepsForUpdate";
            this.Size = new System.Drawing.Size(978, 227);
            this.pnlMain.ResumeLayout(false);
            this.pnlProcSteps.ResumeLayout(false);
            this.splContProcSteps.Panel1.ResumeLayout(false);
            this.splContProcSteps.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splContProcSteps)).EndInit();
            this.splContProcSteps.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRxnSubsts)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlProcSteps;
        private System.Windows.Forms.Label lblProcSteps;
        public ucHtmlRichText uchrtbProcedureSteps;
        public System.Windows.Forms.Label lblNarID;
        private System.Windows.Forms.SplitContainer splContProcSteps;
        private System.Windows.Forms.DataGridView dgvRxnSubsts;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSubstID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSubstRegNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSubstRole;
    }
}
