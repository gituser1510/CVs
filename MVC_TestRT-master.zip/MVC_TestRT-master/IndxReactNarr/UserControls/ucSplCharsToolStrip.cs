﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Collections;
using HtmlRichText;
using IndxReactNarr.Generic;
using IndxReactNarr.Curation.Narratives;

namespace IndxReactNarr
{
    public partial class ucSplCharsToolStrip : UserControl
    {
        public ucSplCharsToolStrip()
        {
            InitializeComponent();
        }

        frmOrganicIndexing frmIndexing = null;
        frmMacroIndexing frmMIndexing = null;
       

        HtmlRichTextBox htrtfbox = null;
        
        private void tsSpecialChars_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            try
            {
                Button btnSender = sender as Button;
                if (sender != null)
                {
                    htrtfbox = GetActiveControlFromParentForm();
                    if (htrtfbox != null)
                    {
                        //string strtext = objHRTB.Text;
                        //int start = objHRTB.SelectionStart;
                        //objHRTB.SelectionFont = new Font(objHRTB.Font.Name, objHRTB.Font.Size);
                        //objHRTB.Select(start, 1);
                        //objHRTB.SelectedText = btnSender.Text;

                        Hashtable hts = new Hashtable();
                        hts.Add("171", "&#8596;");
                        hts.Add("175", "&#8595;");
                        hts.Add("174", "&#8594;");
                        hts.Add("173", "&#8593;");
                        hts.Add("172", "&#8592;");
                        hts.Add("222", "&#8658;");
                        hts.Add("219", "&#8660;");
                        hts.Add("187", "&#8776;");
                        hts.Add("204", "&#8834;");
                        hts.Add("201", "&#8835;");
                        //hts.Add("110", "&#957;");

                        if (!hts.ContainsValue(e.ClickedItem.Tag))
                        {
                            if (e.ClickedItem.Name.ToUpper() != "TS1TRIPLEBOND" && e.ClickedItem.Name.ToUpper() != "TOOLSTRIPBUTTON61" && e.ClickedItem.Tag.ToString() != "&#957;")
                            {
                                string strtext = htrtfbox.Text;
                                int start = htrtfbox.SelectionStart;
                                htrtfbox.SelectionFont = new Font(htrtfbox.Font.Name, htrtfbox.Font.Size);
                                htrtfbox.Select(start, 0);
                                htrtfbox.SelectedText = e.ClickedItem.Text;
                            }
                        }

                        if (e.ClickedItem.Tag.ToString() == "&#8801;")
                        {
                            int start = htrtfbox.SelectionStart;
                            htrtfbox.Select(start, 0);
                            htrtfbox.SelectedRtf = @"{\rtf1\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil\fcharset128 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\cf1\f0\fs17\'81\'df\f1\fs20\cf0\fs17\par}";
                            htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8596;")
                        {
                            int start = htrtfbox.SelectionStart;
                            htrtfbox.Select(start, 0);
                            htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                            htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8596?\cf0\f1\fs17\par}";
                            htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8595;")
                        {
                            int start = htrtfbox.SelectionStart;
                            htrtfbox.Select(start, 0);
                            htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                            htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fswiss\fprq2\fcharset0 Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8595?\cf0\f1\fs17\par}";
                            htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8594;")
                        {
                            int start = htrtfbox.SelectionStart;
                            htrtfbox.Select(start, 0);
                            htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8594?\cf0\f1\fs17\par}";
                            htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8593;")
                        {
                            int start = htrtfbox.SelectionStart;
                            htrtfbox.Select(start, 0);
                            htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                            htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8593?\cf0\f1\fs17\par}";
                            htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8592;")
                        {
                            int start = htrtfbox.SelectionStart;
                            htrtfbox.Select(start, 0);
                            htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                            htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8592?\cf0\f1\fs17\par}";
                            htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8658;")
                        {
                            int start = htrtfbox.SelectionStart;
                            htrtfbox.Select(start, 0);
                            htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                            htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset2 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\ltrpar\f0\fs22\'de\f1\fs17\par}";
                            htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8660;")
                        {
                            int start = htrtfbox.SelectionStart;
                            htrtfbox.Select(start, 0);

                            htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset0 Cambria Math;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8660?\cf0\f1\fs17\par}";
                            htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8776;")
                        {
                            int start = htrtfbox.SelectionStart;
                            htrtfbox.Select(start, 0);

                            htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset2 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\ltrpar\sa200\sl276\slmult1\sub\b\f0\fs32\'bb\nosupersub\b0\f1\fs17\par}";
                            htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8834;")
                        {
                            int start = htrtfbox.SelectionStart;
                            htrtfbox.Select(start, 0);

                            htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset2 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\ltrpar\sa200\sl276\slmult1\f0\fs22\'cc\f1\fs17\par}";
                            htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8835;")
                        {
                            int start = htrtfbox.SelectionStart;
                            htrtfbox.Select(start, 0);

                            htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset2 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\ltrpar\sa200\sl276\slmult1\f0\fs22\'c9\f1\fs17\par}";
                            htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#957;")
                        {
                            int start = htrtfbox.SelectionStart;
                            htrtfbox.Select(start, 0);

                            htrtfbox.SelectedRtf = @"{\rtf1\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil\fcharset161 Microsoft Sans Serif;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\f0\fs17\'ed\f1\par}";
                            htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8745;")
                        {
                            int start = htrtfbox.SelectionStart;
                            htrtfbox.Select(start, 0);

                            htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fswiss\fprq2\fcharset0 Arial;}}{\colortbl ;\red0\green0\blue0;}\uc1\pard\ltrpar\cf1\f0\fs22\u8745?}";
                            htrtfbox.SelectionFont = new Font("Arial", htrtfbox.Font.Size);
                        }
                        else if (e.ClickedItem.Tag.ToString() == "&#8869;")
                        {
                            int start = htrtfbox.SelectionStart;
                            htrtfbox.Select(start, 0);

                            htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset0 Cambria Math;}}{\colortbl ;\red0\green0\blue0;}\uc1\pard\ltrpar\cf1\f0\fs22\u8869?}";
                            htrtfbox.SelectionFont = new Font("Cambria Math", htrtfbox.Font.Size);
                        }
                        //else if (e.ClickedItem.Tag.ToString() == "&#x03BD;&#x0303;")
                        //{
                        //    int start = htrtfbox.SelectionStart;
                        //    htrtfbox.Select(start, 0);

                        //    htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fscript\fprq2\fcharset161 Comic Sans MS Greek;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue153;}\uc1\pard\ltrpar\cf1\f0\fs18\'ed\f1\u771?}";
                        //    htrtfbox.SelectionFont = new Font("Comic Sans MS Greek", htrtfbox.Font.Size);

                        //}
                        else if (e.ClickedItem.Tag.ToString() == "&#x2245;")
                        {
                            int start = htrtfbox.SelectionStart;
                            htrtfbox.Select(start, 0);

                            htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset2 Symbol;}}{\colortbl ;\red0\green0\blue0;}\uc1\pard\ltrpar\cf1\f0\fs22 @}";
                            htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetIndexingCurationForm()
        {
            #region MyRegion
            //foreach (Form form in Application.OpenForms)
            //{
            //    if (form.IsMdiContainer)
            //    {
            //        mdiMain objMdi = form as mdiMain;
            //        Form[] childforms = objMdi.MdiChildren;
            //        for (int i = 0; i < objMdi.dockPanel.Contents.Count; i++)
            //        {
            //            if (objMdi.dockPanel.Contents[i].DockHandler.Form.Name.ToUpper() == "FRMINDEXINGCURATION" && objMdi.dockPanel.Contents[i].DockHandler.IsActivated)
            //            {
            //                frmIndexing = objMdi.dockPanel.Contents[i].DockHandler.Form as frmIndexingCuration;
            //                if (lstHtmlControls.Count == 0)
            //                {
            //                    lstHtmlControls = GetAllHtmlControls(objMdi.dockPanel.Contents[i].DockHandler.Form);
            //                }
            //                break;
            //            }
            //        }
            //    }
            //}         
            #endregion    
            frmIndexing = this.Parent.Parent as frmOrganicIndexing;
        }

        private HtmlRichTextBox GetActiveControlFromParentForm()
        {
            HtmlRichTextBox hrtbActive = null;
            try
            {
               
                    frmIndexing = this.Parent.Parent as frmOrganicIndexing;
                    if (frmIndexing != null)
                    {
                        hrtbActive = frmIndexing.GetActiveControlFromForm();
                        return hrtbActive;
                    }

                    frmMIndexing = this.Parent.Parent as frmMacroIndexing;
                    if (frmMIndexing != null)
                    {
                        hrtbActive = frmMIndexing.GetActiveControlFromForm();
                        return hrtbActive;
                    }

                    try
                    {
                        frmNarrCuration_New frmNarratives = this.Parent.Parent.Parent.Parent.Parent.Parent as frmNarrCuration_New;
                        if (frmNarratives != null)
                        {
                            hrtbActive = frmNarratives.ucNarCuration1.GetActiveControl();
                            return hrtbActive;
                        }
                    }
                    catch
                    {

                    }
                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return hrtbActive;
        }

        public Hashtable GetHTMLReplacementsForSpecialCharsToolStripItems()
        {
            Hashtable htSplChars = new Hashtable();
            try
            {
                foreach (ToolStripItem i in tsSpecialChars.Items)
                {
                    if (!string.IsNullOrEmpty(i.Text))//Code by Sairam on 25Sep 2013
                    {
                        if (!htSplChars.ContainsKey(i.Text))
                        {
                            htSplChars.Add(i.Text, i.Tag);
                        }
                    }
                }
                if (!htSplChars.ContainsKey("≡"))
                {
                    htSplChars.Add("≡", "&#8801;");
                }
                if (!htSplChars.ContainsKey("&#8801;"))
                {
                    htSplChars.Add("&#8801;", "≡");
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return htSplChars;
        }

        List<Control> lstHtmlControls = new List<Control>();

        private List<Control> GetAllHtmlControls(Control container)
        {
            foreach (Control c in container.Controls)
            {
                GetAllHtmlControls(c);
                if (c is HtmlRichTextBox) lstHtmlControls.Add(c);
            }
            return lstHtmlControls;
        }
                
        #region Format

        private void ConvertHtmlToRtf(string strtext, HtmlRichText.HtmlRichTextBox rtfxcontrol)
        {
            strtext = strtext.Replace("<bold>", "<b>");
            strtext = strtext.Replace("</bold>", "</b>");
            strtext = strtext.Replace("<ital>", "<I>");
            strtext = strtext.Replace("</ital>", "</I>");
            strtext = strtext.Replace("<sup>", "<SUP>");
            strtext = strtext.Replace("</sup>", "</SUP>");
            strtext = strtext.Replace("<sub>", "<SUB>");
            strtext = strtext.Replace("</sub>", "</SUB>");
            try
            {

                SautinSoft.HtmlToRtf h = new SautinSoft.HtmlToRtf();


                //specify some options
                h.OutputFormat = SautinSoft.HtmlToRtf.eOutputFormat.Rtf;
                h.Encoding = SautinSoft.HtmlToRtf.eEncoding.AutoSelect;
                h.PageStyle.PageSize.Letter();


                string htmlstring = strtext;
                string rtf = h.ConvertString(htmlstring);

                rtfxcontrol.Rtf = rtf;

                string strremovetext = rtfxcontrol.Rtf;
                rtfxcontrol.Rtf = strremovetext;// RemoveTrialVersionstring(strremovetext).Trim();

                RemoveTrialVersionstring("", rtfxcontrol);
            }
            catch (Exception ex)
            {
                //  ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        int indexOfSearchText = 0;
        int start = 0;
        public int FindMyText(string txtToSearch, int searchStart, int searchEnd, HtmlRichText.HtmlRichTextBox rtb)
        {

            // Set the return value to -1 by default.
            int retVal = -1;

            // A valid starting index should be specified.
            // if indexOfSearchText = -1, the end of search
            if (searchStart >= 0 && indexOfSearchText >= 0)
            {
                // A valid ending index
                if (searchEnd > searchStart || searchEnd == -1)
                {
                    rtb.Refresh();
                    // Find the position of search string in RichTextBox
                    indexOfSearchText = rtb.Find(txtToSearch, searchStart, searchEnd, RichTextBoxFinds.MatchCase);

                    retVal = indexOfSearchText;

                }
            }
            return retVal;
        }

        private void RemoveTrialVersionstring(string strrtfstring, HtmlRichText.HtmlRichTextBox rtbox)
        {
            string str1 = "________________________________________________________";
            string str2 = "Trial version converts only first 100000 characters. Evaluation only.";
            string str3 = "Converted by HTML-to-RTF Pro DLL .Net 3.5.4.21.";
            string str4 = "(Licensed version doesn't display this notice!)";
            string str5 = "- Get license for the HTML-to-RTF Pro DLL .Net <http://www.sautinsoft.com/products/html-to-rtf/order.php>";
            string str6 = "\n\n\n\n\n\n";

            string[] strvalues = new string[6] { str1, str2, str3, str4, str5, str6 };
            try
            {

                foreach (string str in strvalues)
                {
                    if (rtbox.Text.Contains(str))
                    {
                        bool blnloop = false;
                        int startindex = 0;

                        indexOfSearchText = 0;
                        start = 0;
                        while (blnloop == false)
                        {

                            if (str.Length > 0)
                            {
                                startindex = FindMyText(str.Trim(), start, rtbox.Text.Length, rtbox);
                                if (startindex == -1)
                                {
                                    blnloop = true;
                                }
                            }

                            if (startindex >= 0)
                            {
                                // Set the highlight color as red
                                int endindex = str.Length;
                                // Highlight the search string
                                rtbox.Select(startindex, endindex);
                                rtbox.SelectedRtf = "";
                                blnloop = true;
                                rtbox.SelectAll();
                                //start = startindex + endindex;
                                // continue;

                            }
                        }
                        continue;

                    }
                }
            }
            catch (Exception ex)
            {
                // ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        HtmlRichTextBox rtfformula = new HtmlRichTextBox();
           
        private void tsbBold_Click(object sender, EventArgs e)
        {
            try
            {
                htrtfbox = GetActiveControlFromParentForm();
                if (htrtfbox != null)
                {
                    SetSeletedTextBold(htrtfbox);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbItalic_Click(object sender, EventArgs e)
        {
            try
            {
                htrtfbox = GetActiveControlFromParentForm();
                if (htrtfbox != null)
                {
                    SetSelectedTextItalic(htrtfbox);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbUnderline_Click(object sender, EventArgs e)
        {
            try
            {
                htrtfbox = GetActiveControlFromParentForm();
                if (htrtfbox != null)
                {
                    SetSelectedTextUnderLine(htrtfbox);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbRegular_Click(object sender, EventArgs e)
        {
            try
            {
                htrtfbox = GetActiveControlFromParentForm();
                if (htrtfbox != null)
                {
                    SetSelectedTextRegular(htrtfbox);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbSuperscript_Click(object sender, EventArgs e)
        {
            try
            {
                htrtfbox = GetActiveControlFromParentForm();
                if (htrtfbox != null)
                {
                    SetSelectedTextSuperScript(htrtfbox);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbSubscript_Click(object sender, EventArgs e)
        {
            try
            {
                htrtfbox = GetActiveControlFromParentForm();
                if (htrtfbox != null)
                {
                    SetSelectedTextSubScript(htrtfbox);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbSmallCaps_Click(object sender, EventArgs e)
        {
            try
            {
                htrtfbox = GetActiveControlFromParentForm();
                if (htrtfbox != null)
                {
                    SetSelectedTextSmallCaps(htrtfbox);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbUndo_Click(object sender, EventArgs e)
        {
            try
            {
                htrtfbox = GetActiveControlFromParentForm();
                if (htrtfbox != null)
                {
                    htrtfbox.Undo();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbRedo_Click(object sender, EventArgs e)
        {
            try
            {
                htrtfbox = GetActiveControlFromParentForm();
                if (htrtfbox != null)
                {
                    htrtfbox.Redo();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbConvFormula_Click(object sender, EventArgs e)
        {
            try
            {
                htrtfbox = GetActiveControlFromParentForm();
                if (htrtfbox != null)
                {
                    ConvertSelectedTextToFormula(htrtfbox);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public static void SetSeletedTextBold(HtmlRichText.HtmlRichTextBox htrtfbox)
        {
            try
            {
                if (htrtfbox != null)
                {

                    if (htrtfbox.SelectedText != null)
                    {
                        if (htrtfbox.SelectionFont == null)
                            htrtfbox.SelectionFont = new Font(htrtfbox.Font, htrtfbox.Font.Style ^ FontStyle.Bold);
                        else
                            htrtfbox.SelectionFont = new Font(htrtfbox.SelectionFont, htrtfbox.SelectionFont.Style ^ FontStyle.Bold);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        public static void SetSelectedTextUnderLine(HtmlRichText.HtmlRichTextBox htrtfbox)
        {
            try
            {
                if (htrtfbox != null)
                {
                    if (htrtfbox.SelectedText != null)
                    {
                        if (htrtfbox.SelectionFont == null)
                            htrtfbox.SelectionFont = new Font(htrtfbox.Font, htrtfbox.Font.Style ^ FontStyle.Underline);
                        else
                            htrtfbox.SelectionFont = new Font(htrtfbox.SelectionFont, htrtfbox.SelectionFont.Style ^ FontStyle.Underline);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public static void SetSelectedTextItalic(HtmlRichText.HtmlRichTextBox htrtfbox)
        {
            try
            {
                if (htrtfbox != null)
                {
                    if (htrtfbox.SelectedText != null)
                    {
                        if (htrtfbox.SelectionFont == null)
                            htrtfbox.SelectionFont = new Font(htrtfbox.Font, htrtfbox.Font.Style ^ FontStyle.Italic);
                        else
                            htrtfbox.SelectionFont = new Font(htrtfbox.SelectionFont, htrtfbox.SelectionFont.Style ^ FontStyle.Italic);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        public static void SetSelectedTextRegular(HtmlRichText.HtmlRichTextBox htrtfbox)
        {
            try
            {
                if (htrtfbox != null)
                {
                    if (htrtfbox.SelectedText != null)
                    {
                        if (htrtfbox.SelectionFont == null)
                            htrtfbox.SelectionFont = new Font(htrtfbox.Font, htrtfbox.Font.Style ^ FontStyle.Regular);
                        else
                            htrtfbox.SelectionFont = new Font(htrtfbox.SelectionFont, htrtfbox.SelectionFont.Style ^ FontStyle.Regular);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public static void SetSelectedTextSuperScript(HtmlRichText.HtmlRichTextBox htrtfbox)
        {
            try
            {
                if (htrtfbox != null)
                {
                    if (!htrtfbox.IsSuperScript())
                    {
                        htrtfbox.SetSuperScript(true);
                        htrtfbox.SetSubScript(false);
                    }
                    else
                        htrtfbox.SetSuperScript(false);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public static void SetSelectedTextSubScript(HtmlRichText.HtmlRichTextBox htrtfbox)
        {
            try
            {
                if (htrtfbox != null)
                {
                    if (!htrtfbox.IsSubScript())
                    {
                        htrtfbox.SetSubScript(true);
                        htrtfbox.SetSuperScript(false);
                    }
                    else
                        htrtfbox.SetSubScript(false);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public void SetSelectedTextSmallCaps(HtmlRichText.HtmlRichTextBox htrtfbox)
        {
            try
            {
                if (htrtfbox != null)
                {

                    if (htrtfbox.SelectionFont != null)
                        fontDialog1.Font = htrtfbox.SelectionFont;
                    else
                        fontDialog1.Font = htrtfbox.Font;

                    if (fontDialog1.ShowDialog() == DialogResult.OK)
                    {
                        if (htrtfbox.SelectionFont != null)
                        {
                            htrtfbox.SelectionFont = fontDialog1.Font;
                        }
                        else
                        {
                            if (htrtfbox.SelectedText != null)
                            {
                                htrtfbox.SelectionFont = fontDialog1.Font;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        public void ConvertSelectedTextToFormula(HtmlRichText.HtmlRichTextBox htrtfbox)
        {
            try
            {
                if (htrtfbox != null)
                {
                    if (htrtfbox.SelectedText != null)
                    {

                        rtfformula.Text = "";
                        rtfformula.Rtf = htrtfbox.SelectedRtf;
                        int startposition = htrtfbox.SelectionStart;
                        int endpostion = htrtfbox.SelectionLength;
                        string a = htrtfbox.SelectedText;
                        for (int i = 0; i < a.Length; i++)
                        {
                            string x = a.Substring(i, 1);

                            if (char.IsNumber(Convert.ToChar(x)))
                            {
                                rtfformula.Select(i, 1);
                                rtfformula.SetSubScript(true);
                                rtfformula.SetSuperScript(false);
                            }
                        }
                        //Zero First Test
                        for (int i = 0; i < a.Length; i++)
                        {
                            string x = a.Substring(i, 1);
                            bool iszerofirst = false;
                            int zerofirstindex = 0;
                            bool isafterzeronumber = false;
                            if (char.IsNumber(Convert.ToChar(x)))
                            {
                                if (Convert.ToInt32(x) == 0)
                                {
                                    iszerofirst = true;
                                    zerofirstindex = i;
                                    Char[] ca = a.ToCharArray();
                                    if (ca != null && ca.Length > 0)
                                    {
                                        if (ca.Length > zerofirstindex + 1)
                                        {
                                            string _strvalue = ca[zerofirstindex].ToString() + ca[zerofirstindex + 1].ToString();
                                            if (char.IsNumber(ca[zerofirstindex + 1]))
                                            {
                                                if (MessageBox.Show("Zero exists before numeric value in formula, value is " + _strvalue + " . Is it correct?", "CAS Narrative", MessageBoxButtons.YesNo, MessageBoxIcon.Information) != DialogResult.Yes)
                                                {
                                                    return;
                                                }
                                                else
                                                    break;

                                            }
                                        }
                                    }
                                }
                            }

                        }

                        //If c repeates in formula more than one times
                        int ccount = 0;
                        bool isnumber = false;
                        for (int i = 0; i < a.Length; i++)
                        {

                            string x = a.Substring(i, 1);
                            if (x.ToString().ToUpper() == "C")
                            {
                                if (a.Length > i + 1)
                                {
                                    string y = a.Substring(i + 1, 1);
                                    if (char.IsNumber(Convert.ToChar(y)))
                                    {
                                        ccount++;
                                    }
                                }
                            }
                        }
                        if (ccount > 1)
                        {
                            if (MessageBox.Show("C repeates " + ccount + " times in formula, is it correct formula?", "CAS Narrative", MessageBoxButtons.YesNo, MessageBoxIcon.Information) != DialogResult.Yes)
                            {
                                return;
                            }

                        }

                        if (rtfformula.SelectedText != null)
                        {
                            for (int i = 0; i < rtfformula.Text.Length; i++)
                            {
                                if (rtfformula.Text.Substring(i, 1) == "0")
                                {
                                    rtfformula.Select(i, 1);
                                    rtfformula.SelectionBackColor = Color.Red;

                                }
                            }
                        }
                        rtfformula.SelectAll();
                        htrtfbox.SelectedRtf = rtfformula.SelectedRtf.Replace("\r\n", "");
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
