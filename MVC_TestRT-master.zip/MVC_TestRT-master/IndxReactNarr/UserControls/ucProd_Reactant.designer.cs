﻿namespace IndxReactNarr
{
    partial class ucProd_Reactant
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlChemImg = new System.Windows.Forms.Panel();
            this.pbChemImg = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblStage = new System.Windows.Forms.Label();
            this.lblNrnNum = new System.Windows.Forms.Label();
            this.lblText = new System.Windows.Forms.Label();
            this.pnlMain.SuspendLayout();
            this.pnlChemImg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbChemImg)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlMain.Controls.Add(this.pnlChemImg);
            this.pnlMain.Controls.Add(this.panel1);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(286, 234);
            this.pnlMain.TabIndex = 0;
            // 
            // pnlChemImg
            // 
            this.pnlChemImg.Controls.Add(this.pbChemImg);
            this.pnlChemImg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlChemImg.Location = new System.Drawing.Point(0, 21);
            this.pnlChemImg.Name = "pnlChemImg";
            this.pnlChemImg.Size = new System.Drawing.Size(284, 211);
            this.pnlChemImg.TabIndex = 2;
            // 
            // pbChemImg
            // 
            this.pbChemImg.BackColor = System.Drawing.Color.White;
            this.pbChemImg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbChemImg.Location = new System.Drawing.Point(0, 0);
            this.pbChemImg.Name = "pbChemImg";
            this.pbChemImg.Size = new System.Drawing.Size(284, 211);
            this.pbChemImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbChemImg.TabIndex = 0;
            this.pbChemImg.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.lblStage);
            this.panel1.Controls.Add(this.lblNrnNum);
            this.panel1.Controls.Add(this.lblText);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(284, 21);
            this.panel1.TabIndex = 3;
            // 
            // lblStage
            // 
            this.lblStage.AutoSize = true;
            this.lblStage.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblStage.ForeColor = System.Drawing.Color.Blue;
            this.lblStage.Location = new System.Drawing.Point(284, 0);
            this.lblStage.Name = "lblStage";
            this.lblStage.Size = new System.Drawing.Size(0, 17);
            this.lblStage.TabIndex = 2;
            this.lblStage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNrnNum
            // 
            this.lblNrnNum.AutoSize = true;
            this.lblNrnNum.BackColor = System.Drawing.Color.White;
            this.lblNrnNum.ForeColor = System.Drawing.Color.Blue;
            this.lblNrnNum.Location = new System.Drawing.Point(47, 3);
            this.lblNrnNum.Name = "lblNrnNum";
            this.lblNrnNum.Size = new System.Drawing.Size(15, 17);
            this.lblNrnNum.TabIndex = 1;
            this.lblNrnNum.Text = "0";
            this.lblNrnNum.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblText
            // 
            this.lblText.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblText.Location = new System.Drawing.Point(0, 0);
            this.lblText.Name = "lblText";
            this.lblText.Size = new System.Drawing.Size(43, 21);
            this.lblText.TabIndex = 0;
            this.lblText.Text = "NUM";
            this.lblText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ucProd_Reactant
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.pnlMain);
            this.Name = "ucProd_Reactant";
            this.Size = new System.Drawing.Size(286, 234);
            this.pnlMain.ResumeLayout(false);
            this.pnlChemImg.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbChemImg)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Label lblText;
        private System.Windows.Forms.Label lblNrnNum;
        private System.Windows.Forms.Panel pnlChemImg;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblStage;
        public System.Windows.Forms.PictureBox pbChemImg;
    }
}
