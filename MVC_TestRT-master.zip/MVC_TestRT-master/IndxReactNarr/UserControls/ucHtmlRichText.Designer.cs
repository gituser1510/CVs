﻿namespace IndxReactNarr.UserControls
{
    partial class ucHtmlRichText
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.hrtbPara = new HtmlRichText.HtmlRichTextBox();
            this.rapidSpellAsYouType1 = new Keyoti.RapidSpell.RapidSpellAsYouType(this.components);
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.hrtbPara);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1073, 69);
            this.pnlMain.TabIndex = 0;
            // 
            // hrtbPara
            // 
            this.hrtbPara.BackColor = System.Drawing.Color.White;
            this.hrtbPara.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hrtbPara.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hrtbPara.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hrtbPara.Location = new System.Drawing.Point(0, 0);
            this.hrtbPara.Name = "hrtbPara";
            this.hrtbPara.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.hrtbPara.Size = new System.Drawing.Size(1073, 69);
            this.hrtbPara.TabIndex = 60;
            this.hrtbPara.Text = "";
            this.hrtbPara.KeyDown += new System.Windows.Forms.KeyEventHandler(this.hrtbPara_KeyDown);
            // 
            // rapidSpellAsYouType1
            // 
            this.rapidSpellAsYouType1.AddMenuText = "Add";
            this.rapidSpellAsYouType1.AllowAnyCase = false;
            this.rapidSpellAsYouType1.AllowMixedCase = false;
            this.rapidSpellAsYouType1.AutoCorrectEnabled = true;
            this.rapidSpellAsYouType1.CheckAsYouType = true;
            this.rapidSpellAsYouType1.CheckCompoundWords = false;
            this.rapidSpellAsYouType1.CheckDisabledTextBoxes = false;
            this.rapidSpellAsYouType1.CheckReadOnlyTextBoxes = false;
            this.rapidSpellAsYouType1.ConsiderationRange = 500;
            this.rapidSpellAsYouType1.ContextMenuStripEnabled = true;
            this.rapidSpellAsYouType1.DictFilePath = "";
            this.rapidSpellAsYouType1.FindCapitalizedSuggestions = false;
            this.rapidSpellAsYouType1.GUILanguage = Keyoti.RapidSpell.LanguageType.ENGLISH;
            this.rapidSpellAsYouType1.IgnoreAllMenuText = "Ignore All";
            this.rapidSpellAsYouType1.IgnoreCapitalizedWords = false;
            this.rapidSpellAsYouType1.IgnoreURLsAndEmailAddresses = true;
            this.rapidSpellAsYouType1.IgnoreWordsWithDigits = true;
            this.rapidSpellAsYouType1.IgnoreXML = false;
            this.rapidSpellAsYouType1.IncludeUserDictionaryInSuggestions = true;
            this.rapidSpellAsYouType1.LanguageParser = Keyoti.RapidSpell.LanguageType.ENGLISH;
            this.rapidSpellAsYouType1.LookIntoHyphenatedText = true;
            this.rapidSpellAsYouType1.OptionsEnabled = true;
            this.rapidSpellAsYouType1.OptionsFileName = "RapidSpell_UserSettings.xml";
            this.rapidSpellAsYouType1.OptionsStorageLocation = Keyoti.RapidSpell.Options.UserOptions.StorageType.IsolatedStorage;
            this.rapidSpellAsYouType1.RemoveDuplicateWordText = "Remove duplicate word";
            this.rapidSpellAsYouType1.SeparateHyphenWords = false;
            this.rapidSpellAsYouType1.ShowAddMenuOption = true;
            this.rapidSpellAsYouType1.ShowCutCopyPasteMenuOnTextBoxBase = true;
            this.rapidSpellAsYouType1.ShowSuggestionsContextMenu = true;
            this.rapidSpellAsYouType1.ShowSuggestionsWhenTextIsSelected = false;
            this.rapidSpellAsYouType1.SuggestionsMethod = Keyoti.RapidSpell.SuggestionsMethodType.HashingSuggestions;
            this.rapidSpellAsYouType1.SuggestSplitWords = true;
            this.rapidSpellAsYouType1.TextBoxBase = this.hrtbPara;
            this.rapidSpellAsYouType1.TextComponent = null;
            this.rapidSpellAsYouType1.UnderlineColor = System.Drawing.Color.Red;
            this.rapidSpellAsYouType1.UnderlineStyle = Keyoti.RapidSpell.UnderlineStyle.Wavy;
            this.rapidSpellAsYouType1.UpdateAllTextBoxes = true;
            this.rapidSpellAsYouType1.UserDictionaryFile = "";
            this.rapidSpellAsYouType1.V2Parser = true;
            this.rapidSpellAsYouType1.WarnDuplicates = true;
            // 
            // ucHtmlRichText
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.Controls.Add(this.pnlMain);
            this.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "ucHtmlRichText";
            this.Size = new System.Drawing.Size(1073, 69);
            this.pnlMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        public HtmlRichText.HtmlRichTextBox hrtbPara;
        private Keyoti.RapidSpell.RapidSpellAsYouType rapidSpellAsYouType1;
    }
}
