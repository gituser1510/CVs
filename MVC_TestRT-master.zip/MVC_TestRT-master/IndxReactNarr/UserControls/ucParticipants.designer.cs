﻿using IndxReactNarr.Common;
using System.Windows.Forms;
namespace IndxReactNarr
{
    partial class ucParticipants
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            MDL.Draw.Chemistry.Molecule molecule1 = new MDL.Draw.Chemistry.Molecule();
            MDL.Draw.Renderer.Preferences.DisplayPreferences displayPreferences1 = new MDL.Draw.Renderer.Preferences.DisplayPreferences();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.splContPartpnts_CndRSN = new System.Windows.Forms.SplitContainer();
            this.splContPartpnts = new System.Windows.Forms.SplitContainer();
            this.splContRct_Solv = new System.Windows.Forms.SplitContainer();
            this.pnlReactant = new System.Windows.Forms.Panel();
            this.dgvReactant = new System.Windows.Forms.DataGridView();
            this.R_RPP_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.R_SER_NUM_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.R_NumType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.R_Num = new System.Windows.Forms.DataGridViewLinkColumn();
            this.R_NrnReg = new System.Windows.Forms.DataGridViewLinkColumn();
            this.R_Name = new System.Windows.Forms.DataGridViewLinkColumn();
            this.R_Delete = new System.Windows.Forms.DataGridViewImageColumn();
            this.lnlReactant = new System.Windows.Forms.LinkLabel();
            this.pnlAgent = new System.Windows.Forms.Panel();
            this.dgvAgent = new System.Windows.Forms.DataGridView();
            this.A_RPP_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.A_SER_NUM_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.A_NumType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.A_Num = new System.Windows.Forms.DataGridViewLinkColumn();
            this.A_NrnReg = new System.Windows.Forms.DataGridViewLinkColumn();
            this.A_Name = new System.Windows.Forms.DataGridViewLinkColumn();
            this.A_Delete = new System.Windows.Forms.DataGridViewImageColumn();
            this.lnkAgent = new System.Windows.Forms.LinkLabel();
            this.splContAgt_Catly = new System.Windows.Forms.SplitContainer();
            this.pnlSolvent = new System.Windows.Forms.Panel();
            this.dgvSolvent = new System.Windows.Forms.DataGridView();
            this.S_RPP_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.S_SER_NUM_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.S_NumType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.S_Num = new System.Windows.Forms.DataGridViewLinkColumn();
            this.S_NrnReg = new System.Windows.Forms.DataGridViewLinkColumn();
            this.S_Name = new System.Windows.Forms.DataGridViewLinkColumn();
            this.S_Delete = new System.Windows.Forms.DataGridViewImageColumn();
            this.lnkSolvent = new System.Windows.Forms.LinkLabel();
            this.pnlCatalyst = new System.Windows.Forms.Panel();
            this.dgvCatalyst = new System.Windows.Forms.DataGridView();
            this.C_RPP_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.C_SER_NUM_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.C_NumType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.C_Num = new System.Windows.Forms.DataGridViewLinkColumn();
            this.C_NrnReg = new System.Windows.Forms.DataGridViewLinkColumn();
            this.C_Name = new System.Windows.Forms.DataGridViewLinkColumn();
            this.C_Delete = new System.Windows.Forms.DataGridViewImageColumn();
            this.lnkCatalyst = new System.Windows.Forms.LinkLabel();
            this.pnlRSN = new System.Windows.Forms.Panel();
            this.dgvRSN = new System.Windows.Forms.DataGridView();
            this.colRSN_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCVT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFreeText = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRSNLevel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lnkEditRSN = new System.Windows.Forms.LinkLabel();
            this.pnlConditions = new System.Windows.Forms.Panel();
            this.dgvConditions = new System.Windows.Forms.DataGridView();
            this.colTemperature = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPressure = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lnkEditCondition = new System.Windows.Forms.LinkLabel();
            this.chemRenditor = new MDL.Draw.Renditor.Renditor();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewLinkColumn1 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn2 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn3 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewLinkColumn4 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn5 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn6 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewImageColumn2 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewLinkColumn7 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn8 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn9 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewImageColumn3 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewLinkColumn10 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn11 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn12 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewImageColumn4 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewLinkColumn13 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn14 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn15 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn16 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewImageColumn5 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewLinkColumn17 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewLinkColumn18 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewImageColumn6 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewLinkColumn19 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn20 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn21 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewLinkColumn22 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewImageColumn7 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewLinkColumn23 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewLinkColumn24 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewImageColumn8 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splContPartpnts_CndRSN)).BeginInit();
            this.splContPartpnts_CndRSN.Panel1.SuspendLayout();
            this.splContPartpnts_CndRSN.Panel2.SuspendLayout();
            this.splContPartpnts_CndRSN.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splContPartpnts)).BeginInit();
            this.splContPartpnts.Panel1.SuspendLayout();
            this.splContPartpnts.Panel2.SuspendLayout();
            this.splContPartpnts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splContRct_Solv)).BeginInit();
            this.splContRct_Solv.Panel1.SuspendLayout();
            this.splContRct_Solv.Panel2.SuspendLayout();
            this.splContRct_Solv.SuspendLayout();
            this.pnlReactant.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReactant)).BeginInit();
            this.pnlAgent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAgent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splContAgt_Catly)).BeginInit();
            this.splContAgt_Catly.Panel1.SuspendLayout();
            this.splContAgt_Catly.Panel2.SuspendLayout();
            this.splContAgt_Catly.SuspendLayout();
            this.pnlSolvent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSolvent)).BeginInit();
            this.pnlCatalyst.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCatalyst)).BeginInit();
            this.pnlRSN.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRSN)).BeginInit();
            this.pnlConditions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvConditions)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.AutoScroll = true;
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.splContPartpnts_CndRSN);
            this.pnlMain.Controls.Add(this.chemRenditor);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(994, 308);
            this.pnlMain.TabIndex = 0;
            // 
            // splContPartpnts_CndRSN
            // 
            this.splContPartpnts_CndRSN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContPartpnts_CndRSN.Location = new System.Drawing.Point(0, 0);
            this.splContPartpnts_CndRSN.Name = "splContPartpnts_CndRSN";
            this.splContPartpnts_CndRSN.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splContPartpnts_CndRSN.Panel1
            // 
            this.splContPartpnts_CndRSN.Panel1.Controls.Add(this.splContPartpnts);
            // 
            // splContPartpnts_CndRSN.Panel2
            // 
            this.splContPartpnts_CndRSN.Panel2.Controls.Add(this.pnlRSN);
            this.splContPartpnts_CndRSN.Panel2.Controls.Add(this.pnlConditions);
            this.splContPartpnts_CndRSN.Size = new System.Drawing.Size(994, 308);
            this.splContPartpnts_CndRSN.SplitterDistance = 213;
            this.splContPartpnts_CndRSN.SplitterWidth = 3;
            this.splContPartpnts_CndRSN.TabIndex = 13;
            // 
            // splContPartpnts
            // 
            this.splContPartpnts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContPartpnts.Location = new System.Drawing.Point(0, 0);
            this.splContPartpnts.Name = "splContPartpnts";
            // 
            // splContPartpnts.Panel1
            // 
            this.splContPartpnts.Panel1.Controls.Add(this.splContRct_Solv);
            // 
            // splContPartpnts.Panel2
            // 
            this.splContPartpnts.Panel2.Controls.Add(this.splContAgt_Catly);
            this.splContPartpnts.Size = new System.Drawing.Size(994, 213);
            this.splContPartpnts.SplitterDistance = 435;
            this.splContPartpnts.SplitterWidth = 3;
            this.splContPartpnts.TabIndex = 12;
            // 
            // splContRct_Solv
            // 
            this.splContRct_Solv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splContRct_Solv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContRct_Solv.Location = new System.Drawing.Point(0, 0);
            this.splContRct_Solv.Name = "splContRct_Solv";
            this.splContRct_Solv.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splContRct_Solv.Panel1
            // 
            this.splContRct_Solv.Panel1.Controls.Add(this.pnlReactant);
            // 
            // splContRct_Solv.Panel2
            // 
            this.splContRct_Solv.Panel2.Controls.Add(this.pnlAgent);
            this.splContRct_Solv.Size = new System.Drawing.Size(435, 213);
            this.splContRct_Solv.SplitterDistance = 108;
            this.splContRct_Solv.SplitterWidth = 3;
            this.splContRct_Solv.TabIndex = 0;
            // 
            // pnlReactant
            // 
            this.pnlReactant.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlReactant.BackColor = System.Drawing.Color.White;
            this.pnlReactant.Controls.Add(this.dgvReactant);
            this.pnlReactant.Controls.Add(this.lnlReactant);
            this.pnlReactant.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlReactant.Location = new System.Drawing.Point(0, 0);
            this.pnlReactant.Name = "pnlReactant";
            this.pnlReactant.Size = new System.Drawing.Size(433, 106);
            this.pnlReactant.TabIndex = 6;
            // 
            // dgvReactant
            // 
            this.dgvReactant.AllowUserToAddRows = false;
            this.dgvReactant.AllowUserToDeleteRows = false;
            this.dgvReactant.AllowUserToResizeRows = false;
            this.dgvReactant.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvReactant.BackgroundColor = System.Drawing.Color.LightGray;
            this.dgvReactant.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvReactant.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Red;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvReactant.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvReactant.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReactant.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.R_RPP_ID,
            this.R_SER_NUM_ID,
            this.R_NumType,
            this.R_Num,
            this.R_NrnReg,
            this.R_Name,
            this.R_Delete});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FloralWhite;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvReactant.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvReactant.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvReactant.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvReactant.Location = new System.Drawing.Point(0, 16);
            this.dgvReactant.MultiSelect = false;
            this.dgvReactant.Name = "dgvReactant";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvReactant.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.dgvReactant.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvReactant.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvReactant.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvReactant.Size = new System.Drawing.Size(433, 90);
            this.dgvReactant.TabIndex = 0;
            this.dgvReactant.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvReactant_CellContentClick);
            this.dgvReactant.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvReactant_CellDoubleClick);
            this.dgvReactant.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvReactant_CellEnter);
            this.dgvReactant.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvReactant_RowPostPaint);
            // 
            // R_RPP_ID
            // 
            this.R_RPP_ID.HeaderText = "RPP_ID";
            this.R_RPP_ID.Name = "R_RPP_ID";
            this.R_RPP_ID.ReadOnly = true;
            this.R_RPP_ID.Visible = false;
            // 
            // R_SER_NUM_ID
            // 
            this.R_SER_NUM_ID.HeaderText = "SerNUMID";
            this.R_SER_NUM_ID.Name = "R_SER_NUM_ID";
            this.R_SER_NUM_ID.ReadOnly = true;
            this.R_SER_NUM_ID.Visible = false;
            // 
            // R_NumType
            // 
            this.R_NumType.HeaderText = "NumType";
            this.R_NumType.Name = "R_NumType";
            this.R_NumType.ReadOnly = true;
            this.R_NumType.Visible = false;
            // 
            // R_Num
            // 
            this.R_Num.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Red;
            dataGridViewCellStyle2.NullValue = "0";
            this.R_Num.DefaultCellStyle = dataGridViewCellStyle2;
            this.R_Num.HeaderText = "Num";
            this.R_Num.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.R_Num.LinkColor = System.Drawing.Color.Red;
            this.R_Num.Name = "R_Num";
            this.R_Num.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.R_Num.ToolTipText = "Edit Reactant";
            this.R_Num.TrackVisitedState = false;
            this.R_Num.Width = 55;
            // 
            // R_NrnReg
            // 
            this.R_NrnReg.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.R_NrnReg.HeaderText = "RegNo";
            this.R_NrnReg.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.R_NrnReg.Name = "R_NrnReg";
            this.R_NrnReg.ReadOnly = true;
            this.R_NrnReg.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.R_NrnReg.TrackVisitedState = false;
            this.R_NrnReg.Width = 87;
            // 
            // R_Name
            // 
            this.R_Name.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.R_Name.FillWeight = 90.90909F;
            this.R_Name.HeaderText = "Name";
            this.R_Name.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.R_Name.Name = "R_Name";
            this.R_Name.ReadOnly = true;
            this.R_Name.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // R_Delete
            // 
            this.R_Delete.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.R_Delete.FillWeight = 10F;
            this.R_Delete.HeaderText = "";
            this.R_Delete.Image = global::IndxReactNarr.Properties.Resources.delete_row;
            this.R_Delete.Name = "R_Delete";
            this.R_Delete.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.R_Delete.ToolTipText = "Delete Reactant";
            this.R_Delete.Width = 30;
            // 
            // lnlReactant
            // 
            this.lnlReactant.AutoSize = true;
            this.lnlReactant.BackColor = System.Drawing.Color.White;
            this.lnlReactant.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lnlReactant.Dock = System.Windows.Forms.DockStyle.Top;
            this.lnlReactant.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnlReactant.ForeColor = System.Drawing.Color.Red;
            this.lnlReactant.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnlReactant.LinkColor = System.Drawing.Color.Red;
            this.lnlReactant.Location = new System.Drawing.Point(0, 0);
            this.lnlReactant.Name = "lnlReactant";
            this.lnlReactant.Size = new System.Drawing.Size(72, 16);
            this.lnlReactant.TabIndex = 2;
            this.lnlReactant.TabStop = true;
            this.lnlReactant.Tag = "Reactant";
            this.lnlReactant.Text = "Reactant +";
            this.toolTip1.SetToolTip(this.lnlReactant, "Add Reactant");
            this.lnlReactant.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnlReactant_LinkClicked);
            // 
            // pnlAgent
            // 
            this.pnlAgent.BackColor = System.Drawing.Color.White;
            this.pnlAgent.Controls.Add(this.dgvAgent);
            this.pnlAgent.Controls.Add(this.lnkAgent);
            this.pnlAgent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAgent.Location = new System.Drawing.Point(0, 0);
            this.pnlAgent.Name = "pnlAgent";
            this.pnlAgent.Size = new System.Drawing.Size(433, 100);
            this.pnlAgent.TabIndex = 7;
            // 
            // dgvAgent
            // 
            this.dgvAgent.AllowUserToAddRows = false;
            this.dgvAgent.AllowUserToDeleteRows = false;
            this.dgvAgent.AllowUserToResizeRows = false;
            this.dgvAgent.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAgent.BackgroundColor = System.Drawing.Color.LightGray;
            this.dgvAgent.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Brown;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAgent.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvAgent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAgent.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.A_RPP_ID,
            this.A_SER_NUM_ID,
            this.A_NumType,
            this.A_Num,
            this.A_NrnReg,
            this.A_Name,
            this.A_Delete});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FloralWhite;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvAgent.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgvAgent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAgent.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvAgent.Location = new System.Drawing.Point(0, 16);
            this.dgvAgent.MultiSelect = false;
            this.dgvAgent.Name = "dgvAgent";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAgent.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            this.dgvAgent.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvAgent.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvAgent.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvAgent.Size = new System.Drawing.Size(433, 84);
            this.dgvAgent.TabIndex = 1;
            this.dgvAgent.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAgent_CellContentClick);
            this.dgvAgent.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAgent_CellDoubleClick);
            this.dgvAgent.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAgent_CellEnter);
            this.dgvAgent.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvAgent_RowPostPaint);
            // 
            // A_RPP_ID
            // 
            this.A_RPP_ID.HeaderText = "RPP_ID";
            this.A_RPP_ID.Name = "A_RPP_ID";
            this.A_RPP_ID.ReadOnly = true;
            this.A_RPP_ID.Visible = false;
            // 
            // A_SER_NUM_ID
            // 
            this.A_SER_NUM_ID.HeaderText = "SER_NUM_ID";
            this.A_SER_NUM_ID.Name = "A_SER_NUM_ID";
            this.A_SER_NUM_ID.ReadOnly = true;
            this.A_SER_NUM_ID.Visible = false;
            // 
            // A_NumType
            // 
            this.A_NumType.HeaderText = "NumType";
            this.A_NumType.Name = "A_NumType";
            this.A_NumType.ReadOnly = true;
            this.A_NumType.Visible = false;
            // 
            // A_Num
            // 
            this.A_Num.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.NullValue = "0";
            this.A_Num.DefaultCellStyle = dataGridViewCellStyle7;
            this.A_Num.HeaderText = "Num";
            this.A_Num.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.A_Num.LinkColor = System.Drawing.Color.Red;
            this.A_Num.Name = "A_Num";
            this.A_Num.ReadOnly = true;
            this.A_Num.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.A_Num.TrackVisitedState = false;
            this.A_Num.Width = 55;
            // 
            // A_NrnReg
            // 
            this.A_NrnReg.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.A_NrnReg.HeaderText = "RegNo";
            this.A_NrnReg.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.A_NrnReg.Name = "A_NrnReg";
            this.A_NrnReg.ReadOnly = true;
            this.A_NrnReg.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.A_NrnReg.TrackVisitedState = false;
            this.A_NrnReg.Width = 87;
            // 
            // A_Name
            // 
            this.A_Name.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.A_Name.FillWeight = 90.90909F;
            this.A_Name.HeaderText = "Name";
            this.A_Name.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.A_Name.Name = "A_Name";
            this.A_Name.ReadOnly = true;
            this.A_Name.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // A_Delete
            // 
            this.A_Delete.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.A_Delete.FillWeight = 10F;
            this.A_Delete.HeaderText = "";
            this.A_Delete.Image = global::IndxReactNarr.Properties.Resources.delete_row;
            this.A_Delete.Name = "A_Delete";
            this.A_Delete.ToolTipText = "Delete Agent";
            this.A_Delete.Width = 30;
            // 
            // lnkAgent
            // 
            this.lnkAgent.AutoSize = true;
            this.lnkAgent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lnkAgent.Dock = System.Windows.Forms.DockStyle.Top;
            this.lnkAgent.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkAgent.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkAgent.LinkColor = System.Drawing.Color.Brown;
            this.lnkAgent.Location = new System.Drawing.Point(0, 0);
            this.lnkAgent.Name = "lnkAgent";
            this.lnkAgent.Size = new System.Drawing.Size(54, 16);
            this.lnkAgent.TabIndex = 3;
            this.lnkAgent.TabStop = true;
            this.lnkAgent.Tag = "Agent";
            this.lnkAgent.Text = "Agent +";
            this.lnkAgent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolTip1.SetToolTip(this.lnkAgent, "Add Agent");
            this.lnkAgent.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnlReactant_LinkClicked);
            // 
            // splContAgt_Catly
            // 
            this.splContAgt_Catly.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splContAgt_Catly.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splContAgt_Catly.Location = new System.Drawing.Point(0, 0);
            this.splContAgt_Catly.Name = "splContAgt_Catly";
            this.splContAgt_Catly.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splContAgt_Catly.Panel1
            // 
            this.splContAgt_Catly.Panel1.Controls.Add(this.pnlSolvent);
            // 
            // splContAgt_Catly.Panel2
            // 
            this.splContAgt_Catly.Panel2.Controls.Add(this.pnlCatalyst);
            this.splContAgt_Catly.Size = new System.Drawing.Size(556, 213);
            this.splContAgt_Catly.SplitterDistance = 108;
            this.splContAgt_Catly.SplitterWidth = 3;
            this.splContAgt_Catly.TabIndex = 0;
            // 
            // pnlSolvent
            // 
            this.pnlSolvent.BackColor = System.Drawing.Color.White;
            this.pnlSolvent.Controls.Add(this.dgvSolvent);
            this.pnlSolvent.Controls.Add(this.lnkSolvent);
            this.pnlSolvent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlSolvent.Location = new System.Drawing.Point(0, 0);
            this.pnlSolvent.Name = "pnlSolvent";
            this.pnlSolvent.Size = new System.Drawing.Size(554, 106);
            this.pnlSolvent.TabIndex = 8;
            // 
            // dgvSolvent
            // 
            this.dgvSolvent.AllowUserToAddRows = false;
            this.dgvSolvent.AllowUserToDeleteRows = false;
            this.dgvSolvent.AllowUserToResizeRows = false;
            this.dgvSolvent.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSolvent.BackgroundColor = System.Drawing.Color.LightGray;
            this.dgvSolvent.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.OrangeRed;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSolvent.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.dgvSolvent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSolvent.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.S_RPP_ID,
            this.S_SER_NUM_ID,
            this.S_NumType,
            this.S_Num,
            this.S_NrnReg,
            this.S_Name,
            this.S_Delete});
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FloralWhite;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvSolvent.DefaultCellStyle = dataGridViewCellStyle13;
            this.dgvSolvent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSolvent.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvSolvent.Location = new System.Drawing.Point(0, 16);
            this.dgvSolvent.MultiSelect = false;
            this.dgvSolvent.Name = "dgvSolvent";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSolvent.RowHeadersDefaultCellStyle = dataGridViewCellStyle14;
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.Black;
            this.dgvSolvent.RowsDefaultCellStyle = dataGridViewCellStyle15;
            this.dgvSolvent.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvSolvent.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvSolvent.Size = new System.Drawing.Size(554, 90);
            this.dgvSolvent.TabIndex = 1;
            this.dgvSolvent.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSolvent_CellContentClick);
            this.dgvSolvent.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSolvent_CellDoubleClick);
            this.dgvSolvent.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSolvent_CellEnter);
            this.dgvSolvent.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvSolvent_RowPostPaint);
            // 
            // S_RPP_ID
            // 
            this.S_RPP_ID.HeaderText = "RPP_ID";
            this.S_RPP_ID.Name = "S_RPP_ID";
            this.S_RPP_ID.Visible = false;
            // 
            // S_SER_NUM_ID
            // 
            this.S_SER_NUM_ID.HeaderText = "SER_NUM_ID";
            this.S_SER_NUM_ID.Name = "S_SER_NUM_ID";
            this.S_SER_NUM_ID.ReadOnly = true;
            this.S_SER_NUM_ID.Visible = false;
            // 
            // S_NumType
            // 
            this.S_NumType.HeaderText = "NumType";
            this.S_NumType.Name = "S_NumType";
            this.S_NumType.ReadOnly = true;
            this.S_NumType.Visible = false;
            // 
            // S_Num
            // 
            this.S_Num.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.NullValue = "0";
            this.S_Num.DefaultCellStyle = dataGridViewCellStyle12;
            this.S_Num.HeaderText = "Num";
            this.S_Num.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.S_Num.LinkColor = System.Drawing.Color.Red;
            this.S_Num.Name = "S_Num";
            this.S_Num.ReadOnly = true;
            this.S_Num.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.S_Num.TrackVisitedState = false;
            this.S_Num.Width = 55;
            // 
            // S_NrnReg
            // 
            this.S_NrnReg.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.S_NrnReg.HeaderText = "RegNo";
            this.S_NrnReg.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.S_NrnReg.Name = "S_NrnReg";
            this.S_NrnReg.ReadOnly = true;
            this.S_NrnReg.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.S_NrnReg.TrackVisitedState = false;
            this.S_NrnReg.Width = 87;
            // 
            // S_Name
            // 
            this.S_Name.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.S_Name.FillWeight = 93.75F;
            this.S_Name.HeaderText = "Name";
            this.S_Name.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.S_Name.Name = "S_Name";
            this.S_Name.ReadOnly = true;
            this.S_Name.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // S_Delete
            // 
            this.S_Delete.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.S_Delete.HeaderText = "";
            this.S_Delete.Image = global::IndxReactNarr.Properties.Resources.delete_row;
            this.S_Delete.Name = "S_Delete";
            this.S_Delete.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.S_Delete.ToolTipText = "Delete Solvent";
            this.S_Delete.Width = 30;
            // 
            // lnkSolvent
            // 
            this.lnkSolvent.AutoSize = true;
            this.lnkSolvent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lnkSolvent.Dock = System.Windows.Forms.DockStyle.Top;
            this.lnkSolvent.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkSolvent.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkSolvent.LinkColor = System.Drawing.Color.OrangeRed;
            this.lnkSolvent.Location = new System.Drawing.Point(0, 0);
            this.lnkSolvent.Name = "lnkSolvent";
            this.lnkSolvent.Size = new System.Drawing.Size(62, 16);
            this.lnkSolvent.TabIndex = 4;
            this.lnkSolvent.TabStop = true;
            this.lnkSolvent.Tag = "Solvent";
            this.lnkSolvent.Text = "Solvent +";
            this.lnkSolvent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lnkSolvent.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnlReactant_LinkClicked);
            // 
            // pnlCatalyst
            // 
            this.pnlCatalyst.BackColor = System.Drawing.Color.White;
            this.pnlCatalyst.Controls.Add(this.dgvCatalyst);
            this.pnlCatalyst.Controls.Add(this.lnkCatalyst);
            this.pnlCatalyst.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlCatalyst.Location = new System.Drawing.Point(0, 0);
            this.pnlCatalyst.Name = "pnlCatalyst";
            this.pnlCatalyst.Size = new System.Drawing.Size(554, 100);
            this.pnlCatalyst.TabIndex = 9;
            // 
            // dgvCatalyst
            // 
            this.dgvCatalyst.AllowUserToAddRows = false;
            this.dgvCatalyst.AllowUserToDeleteRows = false;
            this.dgvCatalyst.AllowUserToResizeRows = false;
            this.dgvCatalyst.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCatalyst.BackgroundColor = System.Drawing.Color.LightGray;
            this.dgvCatalyst.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.Green;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCatalyst.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.dgvCatalyst.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCatalyst.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.C_RPP_ID,
            this.C_SER_NUM_ID,
            this.C_NumType,
            this.C_Num,
            this.C_NrnReg,
            this.C_Name,
            this.C_Delete});
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FloralWhite;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCatalyst.DefaultCellStyle = dataGridViewCellStyle18;
            this.dgvCatalyst.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCatalyst.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvCatalyst.Location = new System.Drawing.Point(0, 16);
            this.dgvCatalyst.MultiSelect = false;
            this.dgvCatalyst.Name = "dgvCatalyst";
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCatalyst.RowHeadersDefaultCellStyle = dataGridViewCellStyle19;
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.Black;
            this.dgvCatalyst.RowsDefaultCellStyle = dataGridViewCellStyle20;
            this.dgvCatalyst.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvCatalyst.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvCatalyst.Size = new System.Drawing.Size(554, 84);
            this.dgvCatalyst.TabIndex = 1;
            this.dgvCatalyst.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCatalyst_CellContentClick);
            this.dgvCatalyst.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCatalyst_CellDoubleClick);
            this.dgvCatalyst.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCatalyst_CellEnter);
            this.dgvCatalyst.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvCatalyst_RowPostPaint);
            // 
            // C_RPP_ID
            // 
            this.C_RPP_ID.HeaderText = "RPP_ID";
            this.C_RPP_ID.Name = "C_RPP_ID";
            this.C_RPP_ID.ReadOnly = true;
            this.C_RPP_ID.Visible = false;
            // 
            // C_SER_NUM_ID
            // 
            this.C_SER_NUM_ID.HeaderText = "SER_NUM_ID";
            this.C_SER_NUM_ID.Name = "C_SER_NUM_ID";
            this.C_SER_NUM_ID.ReadOnly = true;
            this.C_SER_NUM_ID.Visible = false;
            // 
            // C_NumType
            // 
            this.C_NumType.HeaderText = "NumType";
            this.C_NumType.Name = "C_NumType";
            this.C_NumType.ReadOnly = true;
            this.C_NumType.Visible = false;
            // 
            // C_Num
            // 
            this.C_Num.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle17.NullValue = "0";
            this.C_Num.DefaultCellStyle = dataGridViewCellStyle17;
            this.C_Num.HeaderText = "Num";
            this.C_Num.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.C_Num.LinkColor = System.Drawing.Color.Red;
            this.C_Num.Name = "C_Num";
            this.C_Num.ReadOnly = true;
            this.C_Num.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.C_Num.TrackVisitedState = false;
            this.C_Num.Width = 55;
            // 
            // C_NrnReg
            // 
            this.C_NrnReg.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.C_NrnReg.HeaderText = "RegNo";
            this.C_NrnReg.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.C_NrnReg.Name = "C_NrnReg";
            this.C_NrnReg.ReadOnly = true;
            this.C_NrnReg.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.C_NrnReg.TrackVisitedState = false;
            this.C_NrnReg.Width = 87;
            // 
            // C_Name
            // 
            this.C_Name.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.C_Name.HeaderText = "Name";
            this.C_Name.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.C_Name.Name = "C_Name";
            this.C_Name.ReadOnly = true;
            this.C_Name.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // C_Delete
            // 
            this.C_Delete.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.C_Delete.HeaderText = "";
            this.C_Delete.Image = global::IndxReactNarr.Properties.Resources.delete_row;
            this.C_Delete.Name = "C_Delete";
            this.C_Delete.Width = 30;
            // 
            // lnkCatalyst
            // 
            this.lnkCatalyst.AutoSize = true;
            this.lnkCatalyst.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lnkCatalyst.Dock = System.Windows.Forms.DockStyle.Top;
            this.lnkCatalyst.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkCatalyst.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkCatalyst.LinkColor = System.Drawing.Color.Green;
            this.lnkCatalyst.Location = new System.Drawing.Point(0, 0);
            this.lnkCatalyst.Name = "lnkCatalyst";
            this.lnkCatalyst.Size = new System.Drawing.Size(68, 16);
            this.lnkCatalyst.TabIndex = 4;
            this.lnkCatalyst.TabStop = true;
            this.lnkCatalyst.Tag = "Catalyst";
            this.lnkCatalyst.Text = "Catalyst +";
            this.lnkCatalyst.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lnkCatalyst.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnlReactant_LinkClicked);
            // 
            // pnlRSN
            // 
            this.pnlRSN.BackColor = System.Drawing.Color.White;
            this.pnlRSN.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlRSN.Controls.Add(this.dgvRSN);
            this.pnlRSN.Controls.Add(this.lnkEditRSN);
            this.pnlRSN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRSN.Location = new System.Drawing.Point(435, 0);
            this.pnlRSN.Name = "pnlRSN";
            this.pnlRSN.Size = new System.Drawing.Size(559, 92);
            this.pnlRSN.TabIndex = 11;
            // 
            // dgvRSN
            // 
            this.dgvRSN.AllowUserToAddRows = false;
            this.dgvRSN.AllowUserToDeleteRows = false;
            this.dgvRSN.AllowUserToResizeRows = false;
            this.dgvRSN.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvRSN.BackgroundColor = System.Drawing.Color.LightGray;
            this.dgvRSN.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.Color.Purple;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRSN.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle21;
            this.dgvRSN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRSN.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colRSN_ID,
            this.colCVT,
            this.colFreeText,
            this.colRSNLevel});
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.Color.FloralWhite;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvRSN.DefaultCellStyle = dataGridViewCellStyle22;
            this.dgvRSN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvRSN.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvRSN.Location = new System.Drawing.Point(0, 16);
            this.dgvRSN.MultiSelect = false;
            this.dgvRSN.Name = "dgvRSN";
            this.dgvRSN.ReadOnly = true;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRSN.RowHeadersDefaultCellStyle = dataGridViewCellStyle23;
            dataGridViewCellStyle24.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.Color.BurlyWood;
            this.dgvRSN.RowsDefaultCellStyle = dataGridViewCellStyle24;
            this.dgvRSN.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvRSN.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FloralWhite;
            this.dgvRSN.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvRSN.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvRSN.Size = new System.Drawing.Size(555, 72);
            this.dgvRSN.TabIndex = 1;
            this.dgvRSN.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRSN_CellEnter);
            this.dgvRSN.CellLeave += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgRSN_CellLeave);
            this.dgvRSN.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvRSN_RowPostPaint);
            // 
            // colRSN_ID
            // 
            this.colRSN_ID.HeaderText = "RSN_ID";
            this.colRSN_ID.Name = "colRSN_ID";
            this.colRSN_ID.ReadOnly = true;
            this.colRSN_ID.Visible = false;
            // 
            // colCVT
            // 
            this.colCVT.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colCVT.FillWeight = 73.85786F;
            this.colCVT.HeaderText = "CVT";
            this.colCVT.Name = "colCVT";
            this.colCVT.ReadOnly = true;
            this.colCVT.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colCVT.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colFreeText
            // 
            this.colFreeText.FillWeight = 73.85786F;
            this.colFreeText.HeaderText = "FreeText";
            this.colFreeText.Name = "colFreeText";
            this.colFreeText.ReadOnly = true;
            this.colFreeText.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colRSNLevel
            // 
            this.colRSNLevel.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colRSNLevel.FillWeight = 152.2843F;
            this.colRSNLevel.HeaderText = "Rxn/Stage";
            this.colRSNLevel.Name = "colRSNLevel";
            this.colRSNLevel.ReadOnly = true;
            this.colRSNLevel.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colRSNLevel.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colRSNLevel.Width = 80;
            // 
            // lnkEditRSN
            // 
            this.lnkEditRSN.AutoSize = true;
            this.lnkEditRSN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lnkEditRSN.Dock = System.Windows.Forms.DockStyle.Top;
            this.lnkEditRSN.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkEditRSN.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkEditRSN.LinkColor = System.Drawing.Color.Purple;
            this.lnkEditRSN.Location = new System.Drawing.Point(0, 0);
            this.lnkEditRSN.Name = "lnkEditRSN";
            this.lnkEditRSN.Size = new System.Drawing.Size(47, 16);
            this.lnkEditRSN.TabIndex = 204;
            this.lnkEditRSN.TabStop = true;
            this.lnkEditRSN.Tag = "RSN";
            this.lnkEditRSN.Text = "RSN +";
            this.toolTip1.SetToolTip(this.lnkEditRSN, "Edit RSN");
            this.lnkEditRSN.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkEditRSN_LinkClicked);
            // 
            // pnlConditions
            // 
            this.pnlConditions.BackColor = System.Drawing.Color.White;
            this.pnlConditions.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlConditions.Controls.Add(this.dgvConditions);
            this.pnlConditions.Controls.Add(this.lnkEditCondition);
            this.pnlConditions.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlConditions.Location = new System.Drawing.Point(0, 0);
            this.pnlConditions.Name = "pnlConditions";
            this.pnlConditions.Size = new System.Drawing.Size(435, 92);
            this.pnlConditions.TabIndex = 10;
            // 
            // dgvConditions
            // 
            this.dgvConditions.AllowUserToAddRows = false;
            this.dgvConditions.AllowUserToResizeRows = false;
            this.dgvConditions.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvConditions.BackgroundColor = System.Drawing.Color.LightGray;
            this.dgvConditions.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvConditions.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle25;
            this.dgvConditions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvConditions.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTemperature,
            this.colTime,
            this.colPH,
            this.colPressure});
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.Color.FloralWhite;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvConditions.DefaultCellStyle = dataGridViewCellStyle26;
            this.dgvConditions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvConditions.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvConditions.Location = new System.Drawing.Point(0, 16);
            this.dgvConditions.MultiSelect = false;
            this.dgvConditions.Name = "dgvConditions";
            this.dgvConditions.ReadOnly = true;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvConditions.RowHeadersDefaultCellStyle = dataGridViewCellStyle27;
            dataGridViewCellStyle28.ForeColor = System.Drawing.Color.Black;
            this.dgvConditions.RowsDefaultCellStyle = dataGridViewCellStyle28;
            this.dgvConditions.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvConditions.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvConditions.Size = new System.Drawing.Size(431, 72);
            this.dgvConditions.TabIndex = 1;
            this.dgvConditions.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvConditions_RowPostPaint);
            // 
            // colTemperature
            // 
            this.colTemperature.HeaderText = "Temperature";
            this.colTemperature.Name = "colTemperature";
            this.colTemperature.ReadOnly = true;
            this.colTemperature.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colTime
            // 
            this.colTime.HeaderText = "Time";
            this.colTime.Name = "colTime";
            this.colTime.ReadOnly = true;
            this.colTime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colPH
            // 
            this.colPH.HeaderText = "pH";
            this.colPH.Name = "colPH";
            this.colPH.ReadOnly = true;
            this.colPH.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colPressure
            // 
            this.colPressure.HeaderText = "Pressure";
            this.colPressure.Name = "colPressure";
            this.colPressure.ReadOnly = true;
            this.colPressure.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // lnkEditCondition
            // 
            this.lnkEditCondition.AutoSize = true;
            this.lnkEditCondition.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lnkEditCondition.Dock = System.Windows.Forms.DockStyle.Top;
            this.lnkEditCondition.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkEditCondition.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkEditCondition.Location = new System.Drawing.Point(0, 0);
            this.lnkEditCondition.Name = "lnkEditCondition";
            this.lnkEditCondition.Size = new System.Drawing.Size(81, 16);
            this.lnkEditCondition.TabIndex = 204;
            this.lnkEditCondition.TabStop = true;
            this.lnkEditCondition.Tag = "Conditions";
            this.lnkEditCondition.Text = "Conditions +";
            this.toolTip1.SetToolTip(this.lnkEditCondition, "Edit Conditions");
            this.lnkEditCondition.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkEditCondition_LinkClicked);
            // 
            // chemRenditor
            // 
            this.chemRenditor.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chemRenditor.AutoSizeStructure = true;
            this.chemRenditor.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.chemRenditor.BinHexSketch = "01030004412400214372656174656420627920416363656C7279734472617720342E322E302E36303" +
    "502040000005805000000005905000000000B0B0005417269616C780000140200";
            this.chemRenditor.ChimeString = null;
            this.chemRenditor.ClearingEnabled = true;
            this.chemRenditor.CopyingEnabled = true;
            this.chemRenditor.DisplayOnEmpty = null;
            this.chemRenditor.EditingEnabled = true;
            this.chemRenditor.FileName = null;
            this.chemRenditor.HighlightInfo = "";
            this.chemRenditor.IsBitmapFromOLE = true;
            this.chemRenditor.Location = new System.Drawing.Point(389, 19);
            molecule1.ArrowDir = MDL.Draw.ArrowDirType.No;
            molecule1.ArrowStyle = MDL.Draw.ArrowStyleType.Empty;
            molecule1.AtomValenceDisplay = true;
            molecule1.BaseFormBoxSetting = 0;
            molecule1.BondLineThickness = 0D;
            molecule1.CarbonLabelDisplay = false;
            molecule1.ChemLabelFont = null;
            molecule1.ChemLabelFontString = "(none)";
            molecule1.ColorAtomsByTypeInSketch = false;
            molecule1.ConfigLabelFont = null;
            molecule1.ConfigLabelFontString = "(none)";
            molecule1.ConvertRingBondIntoOneToMany = true;
            molecule1.Coords = null;
            molecule1.DashSpacing = 0.1D;
            molecule1.DisplaySinCys = false;
            molecule1.DisplaySulfurInCysSequence = false;
            molecule1.DoubleBondWidth = 0.18D;
            molecule1.FillColor = System.Drawing.Color.Empty;
            molecule1.FillStyle = MDL.Draw.ChemGraphicsObject.FillStyles.SOLID;
            molecule1.ForeColor = System.Drawing.Color.Empty;
            molecule1.ForeColorString = "";
            molecule1.ForSubsequenceQuery = false;
            molecule1.HighlightChildren = "";
            molecule1.HighlightColor = System.Drawing.Color.Blue;
            molecule1.HydrogenDisplayMode = MDL.Draw.Chemistry.Atom.HydrogenDisplayMode.Off;
            molecule1.Id = 26;
            molecule1.Initial = "";
            molecule1.IsAModel = false;
            molecule1.IsARotatedModel = false;
            molecule1.KeepRSLabelsInSketch = true;
            molecule1.LastModifyChemText = -1;
            molecule1.MaintainXMLChildOrderFlag = false;
            molecule1.MustPerceiveStereo = true;
            molecule1.PenColor = System.Drawing.Color.Empty;
            molecule1.PenStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            molecule1.PenStyleToken = 0;
            molecule1.PenWidth = ((byte)(0));
            molecule1.PenWidthUnit = MDL.Draw.ChemGraphicsObject.PenWidthUnits.Default;
            molecule1.RefId = 26;
            molecule1.Replaced = false;
            molecule1.RgroupCleeanUpNeeded = false;
            molecule1.RgroupLabelsPresentFlag = false;
            molecule1.RLabelAtAbsCenter = "R";
            molecule1.RLabelAtAndCenter = "R*";
            molecule1.RLabelAtOrCenter = "(R)";
            molecule1.ScaleLabelsToBondLength = false;
            molecule1.Selected = false;
            molecule1.SequenceDictionary = null;
            molecule1.SequenceNeedsRealign = false;
            molecule1.SequenceView = MDL.Draw.Chemistry.Molecule.SequenceViewEnum.None;
            molecule1.Size = 0;
            molecule1.SkcWritten = false;
            molecule1.SkNumber = ((short)(0));
            molecule1.SLabelAtAbsCenter = "S";
            molecule1.SLabelAtAndCenter = "S*";
            molecule1.SLabelAtOrCenter = "(S)";
            molecule1.StandardBondLength = 0D;
            molecule1.StereoChemistryMode = MDL.Draw.Chemistry.Molecule.StereoChemistryModeEnum.And;
            molecule1.TextBorder = 0.1D;
            molecule1.Transparent = false;
            molecule1.UndoableEditListener = null;
            molecule1.WedgeWidth = 0.1D;
            molecule1.ZLayer = -99975;
            this.chemRenditor.Molecule = molecule1;
            this.chemRenditor.MolfileString = "";
            this.chemRenditor.Name = "chemRenditor";
            this.chemRenditor.OldScalingMode = MDL.Draw.Renderer.Preferences.StructureScalingMode.ScaleToFitBox;
            this.chemRenditor.PastingEnabled = true;
            displayPreferences1.AtomAtomDisplayMode = MDL.Draw.Renderer.Preferences.AtomAtomMappingDisplayMode.On;
            this.chemRenditor.Preferences = displayPreferences1;
            this.chemRenditor.PreferencesFileName = "default.xml";
            this.chemRenditor.RendererBorderStyle = System.Windows.Forms.ButtonBorderStyle.Inset;
            this.chemRenditor.RenditorMolecule = molecule1;
            this.chemRenditor.RenditorName = "Demo Renditor";
            this.chemRenditor.Size = new System.Drawing.Size(27, 2);
            this.chemRenditor.SketchString = "AQMABEEkACFDcmVhdGVkIGJ5IEFjY2VscnlzRHJhdyA0LjIuMC42MDUCBAAAAFgFAAAAAFkFAAAAAAsLA" +
    "AVBcmlhbHgAABQCAA==";
            this.chemRenditor.SmilesString = "";
            this.chemRenditor.TabIndex = 5;
            this.chemRenditor.URLEncodedMolfileString = "";
            this.chemRenditor.UseLocalXMLConfig = false;
            this.chemRenditor.Visible = false;
            this.chemRenditor.EditorReturned += new MDL.Draw.Renditor.EditorReturnedHandler(this.ChemRenditor_EditorReturned);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.FillWeight = 73.85786F;
            this.dataGridViewTextBoxColumn1.HeaderText = "CVT";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.FillWeight = 73.85786F;
            this.dataGridViewTextBoxColumn2.HeaderText = "FreeText";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Visible = false;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn3.FillWeight = 152.2843F;
            this.dataGridViewTextBoxColumn3.HeaderText = "Rxn/Stage";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn3.Visible = false;
            this.dataGridViewTextBoxColumn3.Width = 80;
            // 
            // dataGridViewLinkColumn1
            // 
            this.dataGridViewLinkColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle29.NullValue = "0";
            this.dataGridViewLinkColumn1.DefaultCellStyle = dataGridViewCellStyle29;
            this.dataGridViewLinkColumn1.HeaderText = "C_Num";
            this.dataGridViewLinkColumn1.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn1.LinkColor = System.Drawing.Color.Red;
            this.dataGridViewLinkColumn1.Name = "dataGridViewLinkColumn1";
            this.dataGridViewLinkColumn1.ReadOnly = true;
            this.dataGridViewLinkColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn1.ToolTipText = "Edit Reactant";
            this.dataGridViewLinkColumn1.TrackVisitedState = false;
            this.dataGridViewLinkColumn1.Width = 55;
            // 
            // dataGridViewLinkColumn2
            // 
            this.dataGridViewLinkColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle30.NullValue = "0";
            this.dataGridViewLinkColumn2.DefaultCellStyle = dataGridViewCellStyle30;
            this.dataGridViewLinkColumn2.HeaderText = "C_9000";
            this.dataGridViewLinkColumn2.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn2.LinkColor = System.Drawing.Color.Green;
            this.dataGridViewLinkColumn2.Name = "dataGridViewLinkColumn2";
            this.dataGridViewLinkColumn2.ReadOnly = true;
            this.dataGridViewLinkColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn2.TrackVisitedState = false;
            this.dataGridViewLinkColumn2.Width = 55;
            // 
            // dataGridViewLinkColumn3
            // 
            this.dataGridViewLinkColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle31.NullValue = "0";
            this.dataGridViewLinkColumn3.DefaultCellStyle = dataGridViewCellStyle31;
            this.dataGridViewLinkColumn3.FillWeight = 90.90909F;
            this.dataGridViewLinkColumn3.HeaderText = "C_8500";
            this.dataGridViewLinkColumn3.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn3.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.dataGridViewLinkColumn3.Name = "dataGridViewLinkColumn3";
            this.dataGridViewLinkColumn3.ReadOnly = true;
            this.dataGridViewLinkColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn3.TrackVisitedState = false;
            this.dataGridViewLinkColumn3.Width = 55;
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewImageColumn1.FillWeight = 10F;
            this.dataGridViewImageColumn1.HeaderText = "C_Mol";
            this.dataGridViewImageColumn1.Image = global::IndxReactNarr.Properties.Resources.delete_row;
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            this.dataGridViewImageColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewImageColumn1.ToolTipText = "Delete Reactant";
            this.dataGridViewImageColumn1.Visible = false;
            this.dataGridViewImageColumn1.Width = 30;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn4.FillWeight = 152.2843F;
            this.dataGridViewTextBoxColumn4.HeaderText = "Temperature";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Visible = false;
            this.dataGridViewTextBoxColumn4.Width = 76;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Time";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn5.Visible = false;
            this.dataGridViewTextBoxColumn5.Width = 76;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn6.FillWeight = 93.75F;
            this.dataGridViewTextBoxColumn6.HeaderText = "pH";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn6.Visible = false;
            // 
            // dataGridViewLinkColumn4
            // 
            this.dataGridViewLinkColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle32.NullValue = "0";
            this.dataGridViewLinkColumn4.DefaultCellStyle = dataGridViewCellStyle32;
            this.dataGridViewLinkColumn4.HeaderText = "C_NrnReg";
            this.dataGridViewLinkColumn4.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn4.LinkColor = System.Drawing.Color.Red;
            this.dataGridViewLinkColumn4.Name = "dataGridViewLinkColumn4";
            this.dataGridViewLinkColumn4.ReadOnly = true;
            this.dataGridViewLinkColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn4.TrackVisitedState = false;
            this.dataGridViewLinkColumn4.Width = 87;
            // 
            // dataGridViewLinkColumn5
            // 
            this.dataGridViewLinkColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle33.NullValue = "0";
            this.dataGridViewLinkColumn5.DefaultCellStyle = dataGridViewCellStyle33;
            this.dataGridViewLinkColumn5.HeaderText = "C_8000";
            this.dataGridViewLinkColumn5.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn5.LinkColor = System.Drawing.Color.Red;
            this.dataGridViewLinkColumn5.Name = "dataGridViewLinkColumn5";
            this.dataGridViewLinkColumn5.ReadOnly = true;
            this.dataGridViewLinkColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn5.TrackVisitedState = false;
            this.dataGridViewLinkColumn5.Width = 55;
            // 
            // dataGridViewLinkColumn6
            // 
            this.dataGridViewLinkColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewLinkColumn6.FillWeight = 93.75F;
            this.dataGridViewLinkColumn6.HeaderText = "C_Subst_Name";
            this.dataGridViewLinkColumn6.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn6.Name = "dataGridViewLinkColumn6";
            this.dataGridViewLinkColumn6.ReadOnly = true;
            this.dataGridViewLinkColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewLinkColumn6.TrackVisitedState = false;
            // 
            // dataGridViewImageColumn2
            // 
            this.dataGridViewImageColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewImageColumn2.FillWeight = 10F;
            this.dataGridViewImageColumn2.HeaderText = "C_Subst_Mol";
            this.dataGridViewImageColumn2.Image = global::IndxReactNarr.Properties.Resources.delete_row;
            this.dataGridViewImageColumn2.Name = "dataGridViewImageColumn2";
            this.dataGridViewImageColumn2.ReadOnly = true;
            this.dataGridViewImageColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewImageColumn2.ToolTipText = "Delete Solvent";
            this.dataGridViewImageColumn2.Width = 80;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "Pressure";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Visible = false;
            this.dataGridViewTextBoxColumn7.Width = 76;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn8.FillWeight = 93.75F;
            this.dataGridViewTextBoxColumn8.HeaderText = "C_Name";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn8.Visible = false;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn9.FillWeight = 90.90909F;
            this.dataGridViewTextBoxColumn9.HeaderText = "C_Subst_Num";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn9.Visible = false;
            // 
            // dataGridViewLinkColumn7
            // 
            this.dataGridViewLinkColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle34.NullValue = "0";
            this.dataGridViewLinkColumn7.DefaultCellStyle = dataGridViewCellStyle34;
            this.dataGridViewLinkColumn7.HeaderText = "S_Num";
            this.dataGridViewLinkColumn7.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn7.LinkColor = System.Drawing.Color.Red;
            this.dataGridViewLinkColumn7.Name = "dataGridViewLinkColumn7";
            this.dataGridViewLinkColumn7.ReadOnly = true;
            this.dataGridViewLinkColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn7.TrackVisitedState = false;
            this.dataGridViewLinkColumn7.Width = 55;
            // 
            // dataGridViewLinkColumn8
            // 
            this.dataGridViewLinkColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle35.NullValue = "0";
            this.dataGridViewLinkColumn8.DefaultCellStyle = dataGridViewCellStyle35;
            this.dataGridViewLinkColumn8.HeaderText = "S_9000";
            this.dataGridViewLinkColumn8.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn8.LinkColor = System.Drawing.Color.Green;
            this.dataGridViewLinkColumn8.Name = "dataGridViewLinkColumn8";
            this.dataGridViewLinkColumn8.ReadOnly = true;
            this.dataGridViewLinkColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn8.TrackVisitedState = false;
            this.dataGridViewLinkColumn8.Width = 55;
            // 
            // dataGridViewLinkColumn9
            // 
            this.dataGridViewLinkColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle36.NullValue = "0";
            this.dataGridViewLinkColumn9.DefaultCellStyle = dataGridViewCellStyle36;
            this.dataGridViewLinkColumn9.FillWeight = 90.90909F;
            this.dataGridViewLinkColumn9.HeaderText = "S_8500";
            this.dataGridViewLinkColumn9.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn9.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.dataGridViewLinkColumn9.Name = "dataGridViewLinkColumn9";
            this.dataGridViewLinkColumn9.ReadOnly = true;
            this.dataGridViewLinkColumn9.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn9.TrackVisitedState = false;
            this.dataGridViewLinkColumn9.Width = 55;
            // 
            // dataGridViewImageColumn3
            // 
            this.dataGridViewImageColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewImageColumn3.FillWeight = 10F;
            this.dataGridViewImageColumn3.HeaderText = "S_Mol";
            this.dataGridViewImageColumn3.Image = global::IndxReactNarr.Properties.Resources.delete_row;
            this.dataGridViewImageColumn3.Name = "dataGridViewImageColumn3";
            this.dataGridViewImageColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewImageColumn3.ToolTipText = "Delete Agent";
            this.dataGridViewImageColumn3.Visible = false;
            this.dataGridViewImageColumn3.Width = 30;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn10.HeaderText = "C_Subst_Loc";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn10.Visible = false;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn11.HeaderText = "C_Subst_Molecule";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn11.Visible = false;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn12.FillWeight = 90.90909F;
            this.dataGridViewTextBoxColumn12.HeaderText = "C_Subst_Author";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn12.Visible = false;
            // 
            // dataGridViewLinkColumn10
            // 
            this.dataGridViewLinkColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle37.NullValue = "0";
            this.dataGridViewLinkColumn10.DefaultCellStyle = dataGridViewCellStyle37;
            this.dataGridViewLinkColumn10.HeaderText = "S_NrnReg";
            this.dataGridViewLinkColumn10.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn10.LinkColor = System.Drawing.Color.Red;
            this.dataGridViewLinkColumn10.Name = "dataGridViewLinkColumn10";
            this.dataGridViewLinkColumn10.ReadOnly = true;
            this.dataGridViewLinkColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn10.TrackVisitedState = false;
            this.dataGridViewLinkColumn10.Width = 87;
            // 
            // dataGridViewLinkColumn11
            // 
            this.dataGridViewLinkColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle38.NullValue = "0";
            this.dataGridViewLinkColumn11.DefaultCellStyle = dataGridViewCellStyle38;
            this.dataGridViewLinkColumn11.FillWeight = 93.75F;
            this.dataGridViewLinkColumn11.HeaderText = "S_8000";
            this.dataGridViewLinkColumn11.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn11.Name = "dataGridViewLinkColumn11";
            this.dataGridViewLinkColumn11.ReadOnly = true;
            this.dataGridViewLinkColumn11.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn11.TrackVisitedState = false;
            this.dataGridViewLinkColumn11.Width = 55;
            // 
            // dataGridViewLinkColumn12
            // 
            this.dataGridViewLinkColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewLinkColumn12.FillWeight = 93.75F;
            this.dataGridViewLinkColumn12.HeaderText = "S_Subst_Name";
            this.dataGridViewLinkColumn12.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn12.Name = "dataGridViewLinkColumn12";
            this.dataGridViewLinkColumn12.ReadOnly = true;
            this.dataGridViewLinkColumn12.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewLinkColumn12.TrackVisitedState = false;
            // 
            // dataGridViewImageColumn4
            // 
            this.dataGridViewImageColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewImageColumn4.FillWeight = 93.75F;
            this.dataGridViewImageColumn4.HeaderText = "S_Subst_Mol";
            this.dataGridViewImageColumn4.Image = global::IndxReactNarr.Properties.Resources.delete_row;
            this.dataGridViewImageColumn4.Name = "dataGridViewImageColumn4";
            this.dataGridViewImageColumn4.ReadOnly = true;
            this.dataGridViewImageColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewImageColumn4.Width = 80;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn13.HeaderText = "C_Subst_Other";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn13.Visible = false;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn14.FillWeight = 93.75F;
            this.dataGridViewTextBoxColumn14.HeaderText = "S_Name";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn14.Visible = false;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn15.FillWeight = 73.85786F;
            this.dataGridViewTextBoxColumn15.HeaderText = "S_Subst_Num";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn15.Visible = false;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn16.FillWeight = 93.75F;
            this.dataGridViewTextBoxColumn16.HeaderText = "S_Subst_Loc";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn17.FillWeight = 93.75F;
            this.dataGridViewTextBoxColumn17.HeaderText = "S_Subst_Molecule";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn17.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn17.Visible = false;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn18.FillWeight = 93.75F;
            this.dataGridViewTextBoxColumn18.HeaderText = "S_Subst_Author";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            this.dataGridViewTextBoxColumn18.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn18.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn18.Visible = false;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn19.FillWeight = 93.75F;
            this.dataGridViewTextBoxColumn19.HeaderText = "S_Subst_Other";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            this.dataGridViewTextBoxColumn19.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn19.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn19.Visible = false;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn20.FillWeight = 152.2843F;
            this.dataGridViewTextBoxColumn20.HeaderText = "A_Name";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn20.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn20.Visible = false;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn21.HeaderText = "A_Subst_Num";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            this.dataGridViewTextBoxColumn21.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn21.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn21.Visible = false;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn22.HeaderText = "A_Subst_Loc";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            this.dataGridViewTextBoxColumn22.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn22.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn22.Visible = false;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn23.HeaderText = "A_Subst_Molecule";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            this.dataGridViewTextBoxColumn23.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn23.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn23.Visible = false;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn24.HeaderText = "A_Subst_Author";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            this.dataGridViewTextBoxColumn24.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn24.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn24.Visible = false;
            // 
            // dataGridViewLinkColumn13
            // 
            this.dataGridViewLinkColumn13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle39.NullValue = "0";
            this.dataGridViewLinkColumn13.DefaultCellStyle = dataGridViewCellStyle39;
            this.dataGridViewLinkColumn13.HeaderText = "A_Num";
            this.dataGridViewLinkColumn13.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn13.LinkColor = System.Drawing.Color.Red;
            this.dataGridViewLinkColumn13.Name = "dataGridViewLinkColumn13";
            this.dataGridViewLinkColumn13.ReadOnly = true;
            this.dataGridViewLinkColumn13.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn13.TrackVisitedState = false;
            this.dataGridViewLinkColumn13.Width = 55;
            // 
            // dataGridViewLinkColumn14
            // 
            this.dataGridViewLinkColumn14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle40.NullValue = "0";
            this.dataGridViewLinkColumn14.DefaultCellStyle = dataGridViewCellStyle40;
            this.dataGridViewLinkColumn14.HeaderText = "A_9000";
            this.dataGridViewLinkColumn14.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn14.LinkColor = System.Drawing.Color.Green;
            this.dataGridViewLinkColumn14.Name = "dataGridViewLinkColumn14";
            this.dataGridViewLinkColumn14.ReadOnly = true;
            this.dataGridViewLinkColumn14.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn14.TrackVisitedState = false;
            this.dataGridViewLinkColumn14.Width = 55;
            // 
            // dataGridViewLinkColumn15
            // 
            this.dataGridViewLinkColumn15.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle41.NullValue = "0";
            this.dataGridViewLinkColumn15.DefaultCellStyle = dataGridViewCellStyle41;
            this.dataGridViewLinkColumn15.HeaderText = "A_8500";
            this.dataGridViewLinkColumn15.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn15.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.dataGridViewLinkColumn15.Name = "dataGridViewLinkColumn15";
            this.dataGridViewLinkColumn15.ReadOnly = true;
            this.dataGridViewLinkColumn15.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn15.TrackVisitedState = false;
            this.dataGridViewLinkColumn15.Width = 55;
            // 
            // dataGridViewLinkColumn16
            // 
            this.dataGridViewLinkColumn16.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewLinkColumn16.HeaderText = "A_NrnReg";
            this.dataGridViewLinkColumn16.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn16.Name = "dataGridViewLinkColumn16";
            this.dataGridViewLinkColumn16.ReadOnly = true;
            this.dataGridViewLinkColumn16.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn16.TrackVisitedState = false;
            this.dataGridViewLinkColumn16.Width = 87;
            // 
            // dataGridViewImageColumn5
            // 
            this.dataGridViewImageColumn5.HeaderText = "A_Mol";
            this.dataGridViewImageColumn5.Name = "dataGridViewImageColumn5";
            this.dataGridViewImageColumn5.Visible = false;
            // 
            // dataGridViewLinkColumn17
            // 
            this.dataGridViewLinkColumn17.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle42.NullValue = "0";
            this.dataGridViewLinkColumn17.DefaultCellStyle = dataGridViewCellStyle42;
            this.dataGridViewLinkColumn17.HeaderText = "A_8000";
            this.dataGridViewLinkColumn17.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn17.Name = "dataGridViewLinkColumn17";
            this.dataGridViewLinkColumn17.ReadOnly = true;
            this.dataGridViewLinkColumn17.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn17.TrackVisitedState = false;
            this.dataGridViewLinkColumn17.Width = 55;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn25.HeaderText = "A_Subst_Other";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.ReadOnly = true;
            this.dataGridViewTextBoxColumn25.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn25.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn25.Visible = false;
            // 
            // dataGridViewLinkColumn18
            // 
            this.dataGridViewLinkColumn18.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewLinkColumn18.HeaderText = "A_Subst_Name";
            this.dataGridViewLinkColumn18.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn18.Name = "dataGridViewLinkColumn18";
            this.dataGridViewLinkColumn18.ReadOnly = true;
            this.dataGridViewLinkColumn18.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewLinkColumn18.TrackVisitedState = false;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn26.HeaderText = "R_Name";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.ReadOnly = true;
            this.dataGridViewTextBoxColumn26.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn26.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn26.Visible = false;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn27.HeaderText = "R_Subst_Num";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.ReadOnly = true;
            this.dataGridViewTextBoxColumn27.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn27.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn27.Visible = false;
            // 
            // dataGridViewImageColumn6
            // 
            this.dataGridViewImageColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewImageColumn6.HeaderText = "A_Subst_Mol";
            this.dataGridViewImageColumn6.Name = "dataGridViewImageColumn6";
            this.dataGridViewImageColumn6.ReadOnly = true;
            this.dataGridViewImageColumn6.Width = 80;
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn28.HeaderText = "R_Subst_Loc";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            this.dataGridViewTextBoxColumn28.ReadOnly = true;
            this.dataGridViewTextBoxColumn28.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn28.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn29.HeaderText = "R_Subst_Molecule";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            this.dataGridViewTextBoxColumn29.ReadOnly = true;
            this.dataGridViewTextBoxColumn29.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn29.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn29.Visible = false;
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn30.HeaderText = "R_Subst_Author";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.ReadOnly = true;
            this.dataGridViewTextBoxColumn30.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn30.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn30.Visible = false;
            // 
            // dataGridViewLinkColumn19
            // 
            this.dataGridViewLinkColumn19.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle43.ForeColor = System.Drawing.Color.Red;
            dataGridViewCellStyle43.NullValue = "0";
            this.dataGridViewLinkColumn19.DefaultCellStyle = dataGridViewCellStyle43;
            this.dataGridViewLinkColumn19.HeaderText = "R_Num";
            this.dataGridViewLinkColumn19.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn19.LinkColor = System.Drawing.Color.Red;
            this.dataGridViewLinkColumn19.Name = "dataGridViewLinkColumn19";
            this.dataGridViewLinkColumn19.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn19.TrackVisitedState = false;
            this.dataGridViewLinkColumn19.Width = 55;
            // 
            // dataGridViewLinkColumn20
            // 
            this.dataGridViewLinkColumn20.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle44.ForeColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle44.NullValue = "0";
            this.dataGridViewLinkColumn20.DefaultCellStyle = dataGridViewCellStyle44;
            this.dataGridViewLinkColumn20.HeaderText = "R_9000";
            this.dataGridViewLinkColumn20.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn20.LinkColor = System.Drawing.Color.Green;
            this.dataGridViewLinkColumn20.Name = "dataGridViewLinkColumn20";
            this.dataGridViewLinkColumn20.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn20.TrackVisitedState = false;
            this.dataGridViewLinkColumn20.Width = 55;
            // 
            // dataGridViewLinkColumn21
            // 
            this.dataGridViewLinkColumn21.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle45.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle45.NullValue = "0";
            this.dataGridViewLinkColumn21.DefaultCellStyle = dataGridViewCellStyle45;
            this.dataGridViewLinkColumn21.HeaderText = "R_8500";
            this.dataGridViewLinkColumn21.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn21.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.dataGridViewLinkColumn21.Name = "dataGridViewLinkColumn21";
            this.dataGridViewLinkColumn21.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn21.TrackVisitedState = false;
            this.dataGridViewLinkColumn21.Width = 55;
            // 
            // dataGridViewLinkColumn22
            // 
            this.dataGridViewLinkColumn22.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewLinkColumn22.HeaderText = "R_NrnReg";
            this.dataGridViewLinkColumn22.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn22.Name = "dataGridViewLinkColumn22";
            this.dataGridViewLinkColumn22.ReadOnly = true;
            this.dataGridViewLinkColumn22.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn22.TrackVisitedState = false;
            this.dataGridViewLinkColumn22.Width = 87;
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn31.HeaderText = "R_Subst_Other";
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.ReadOnly = true;
            this.dataGridViewTextBoxColumn31.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn31.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn31.Visible = false;
            // 
            // dataGridViewImageColumn7
            // 
            this.dataGridViewImageColumn7.HeaderText = "R_Mol";
            this.dataGridViewImageColumn7.Name = "dataGridViewImageColumn7";
            this.dataGridViewImageColumn7.Visible = false;
            // 
            // dataGridViewLinkColumn23
            // 
            this.dataGridViewLinkColumn23.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle46.NullValue = "0";
            this.dataGridViewLinkColumn23.DefaultCellStyle = dataGridViewCellStyle46;
            this.dataGridViewLinkColumn23.HeaderText = "R_8000";
            this.dataGridViewLinkColumn23.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn23.LinkColor = System.Drawing.Color.Blue;
            this.dataGridViewLinkColumn23.Name = "dataGridViewLinkColumn23";
            this.dataGridViewLinkColumn23.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewLinkColumn23.TrackVisitedState = false;
            this.dataGridViewLinkColumn23.Width = 55;
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn32.HeaderText = "R_Subst_Loc";
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            this.dataGridViewTextBoxColumn32.ReadOnly = true;
            this.dataGridViewTextBoxColumn32.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn32.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn32.Visible = false;
            // 
            // dataGridViewLinkColumn24
            // 
            this.dataGridViewLinkColumn24.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewLinkColumn24.HeaderText = "R_Subst_Name";
            this.dataGridViewLinkColumn24.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.dataGridViewLinkColumn24.Name = "dataGridViewLinkColumn24";
            this.dataGridViewLinkColumn24.ReadOnly = true;
            this.dataGridViewLinkColumn24.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewLinkColumn24.TrackVisitedState = false;
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn33.HeaderText = "R_Subst_Molecule";
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            this.dataGridViewTextBoxColumn33.ReadOnly = true;
            this.dataGridViewTextBoxColumn33.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn33.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn33.Visible = false;
            // 
            // dataGridViewTextBoxColumn34
            // 
            this.dataGridViewTextBoxColumn34.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn34.HeaderText = "R_Subst_Author";
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            this.dataGridViewTextBoxColumn34.ReadOnly = true;
            this.dataGridViewTextBoxColumn34.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn34.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn34.Visible = false;
            // 
            // dataGridViewImageColumn8
            // 
            this.dataGridViewImageColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewImageColumn8.HeaderText = "R_Subst_Mol";
            this.dataGridViewImageColumn8.Name = "dataGridViewImageColumn8";
            this.dataGridViewImageColumn8.ReadOnly = true;
            this.dataGridViewImageColumn8.Width = 80;
            // 
            // dataGridViewTextBoxColumn35
            // 
            this.dataGridViewTextBoxColumn35.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn35.HeaderText = "R_Subst_Other";
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            this.dataGridViewTextBoxColumn35.ReadOnly = true;
            this.dataGridViewTextBoxColumn35.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn35.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn36
            // 
            this.dataGridViewTextBoxColumn36.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn36.HeaderText = "R_Subst_Other";
            this.dataGridViewTextBoxColumn36.Name = "dataGridViewTextBoxColumn36";
            this.dataGridViewTextBoxColumn36.ReadOnly = true;
            this.dataGridViewTextBoxColumn36.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn36.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ucParticipants
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.LightGray;
            this.Controls.Add(this.pnlMain);
            this.Name = "ucParticipants";
            this.Size = new System.Drawing.Size(994, 308);
            this.Load += new System.EventHandler(this.ucParticipants_Load);
            this.pnlMain.ResumeLayout(false);
            this.splContPartpnts_CndRSN.Panel1.ResumeLayout(false);
            this.splContPartpnts_CndRSN.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splContPartpnts_CndRSN)).EndInit();
            this.splContPartpnts_CndRSN.ResumeLayout(false);
            this.splContPartpnts.Panel1.ResumeLayout(false);
            this.splContPartpnts.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splContPartpnts)).EndInit();
            this.splContPartpnts.ResumeLayout(false);
            this.splContRct_Solv.Panel1.ResumeLayout(false);
            this.splContRct_Solv.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splContRct_Solv)).EndInit();
            this.splContRct_Solv.ResumeLayout(false);
            this.pnlReactant.ResumeLayout(false);
            this.pnlReactant.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReactant)).EndInit();
            this.pnlAgent.ResumeLayout(false);
            this.pnlAgent.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAgent)).EndInit();
            this.splContAgt_Catly.Panel1.ResumeLayout(false);
            this.splContAgt_Catly.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splContAgt_Catly)).EndInit();
            this.splContAgt_Catly.ResumeLayout(false);
            this.pnlSolvent.ResumeLayout(false);
            this.pnlSolvent.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSolvent)).EndInit();
            this.pnlCatalyst.ResumeLayout(false);
            this.pnlCatalyst.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCatalyst)).EndInit();
            this.pnlRSN.ResumeLayout(false);
            this.pnlRSN.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRSN)).EndInit();
            this.pnlConditions.ResumeLayout(false);
            this.pnlConditions.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvConditions)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        public System.Windows.Forms.DataGridView dgvRSN;
        public System.Windows.Forms.DataGridView dgvConditions;
        private System.Windows.Forms.Panel pnlReactant;
        private MDL.Draw.Renditor.Renditor chemRenditor;
        private System.Windows.Forms.Panel pnlAgent;
        private System.Windows.Forms.Panel pnlSolvent;
        private System.Windows.Forms.Panel pnlCatalyst;
        private System.Windows.Forms.Panel pnlConditions;
        private System.Windows.Forms.Panel pnlRSN;
        private ToolTip toolTip1;
        public DataGridView dgvReactant;
        public DataGridView dgvCatalyst;
        public DataGridView dgvSolvent;
        public DataGridView dgvAgent;
        private LinkLabel lnkEditRSN;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private DataGridViewLinkColumn dataGridViewLinkColumn1;
        private DataGridViewLinkColumn dataGridViewLinkColumn2;
        private DataGridViewLinkColumn dataGridViewLinkColumn3;
        private DataGridViewLinkColumn dataGridViewLinkColumn4;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private DataGridViewImageColumn dataGridViewImageColumn1;
        private DataGridViewLinkColumn dataGridViewLinkColumn5;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private DataGridViewLinkColumn dataGridViewLinkColumn6;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private DataGridViewImageColumn dataGridViewImageColumn2;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private DataGridViewLinkColumn dataGridViewLinkColumn7;
        private DataGridViewLinkColumn dataGridViewLinkColumn8;
        private DataGridViewLinkColumn dataGridViewLinkColumn9;
        private DataGridViewLinkColumn dataGridViewLinkColumn10;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private DataGridViewImageColumn dataGridViewImageColumn3;
        private DataGridViewLinkColumn dataGridViewLinkColumn11;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private DataGridViewLinkColumn dataGridViewLinkColumn12;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private DataGridViewImageColumn dataGridViewImageColumn4;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private DataGridViewLinkColumn dataGridViewLinkColumn13;
        private DataGridViewLinkColumn dataGridViewLinkColumn14;
        private DataGridViewLinkColumn dataGridViewLinkColumn15;
        private DataGridViewLinkColumn dataGridViewLinkColumn16;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private DataGridViewImageColumn dataGridViewImageColumn5;
        private DataGridViewLinkColumn dataGridViewLinkColumn17;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private DataGridViewLinkColumn dataGridViewLinkColumn18;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private DataGridViewImageColumn dataGridViewImageColumn6;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private DataGridViewLinkColumn dataGridViewLinkColumn19;
        private DataGridViewLinkColumn dataGridViewLinkColumn20;
        private DataGridViewLinkColumn dataGridViewLinkColumn21;
        private DataGridViewLinkColumn dataGridViewLinkColumn22;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private DataGridViewImageColumn dataGridViewImageColumn7;
        private DataGridViewLinkColumn dataGridViewLinkColumn23;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private DataGridViewLinkColumn dataGridViewLinkColumn24;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private DataGridViewImageColumn dataGridViewImageColumn8;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private DataGridViewTextBoxColumn colTemperature;
        private DataGridViewTextBoxColumn colTime;
        private DataGridViewTextBoxColumn colPH;
        private DataGridViewTextBoxColumn colPressure;
        private DataGridViewTextBoxColumn colRSN_ID;
        private DataGridViewTextBoxColumn colCVT;
        private DataGridViewTextBoxColumn colFreeText;
        private DataGridViewTextBoxColumn colRSNLevel;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
        private SplitContainer splContPartpnts_CndRSN;
        private SplitContainer splContPartpnts;
        private SplitContainer splContRct_Solv;
        private SplitContainer splContAgt_Catly;
        private LinkLabel lnlReactant;
        private LinkLabel lnkEditCondition;
        private LinkLabel lnkAgent;
        private LinkLabel lnkSolvent;
        private LinkLabel lnkCatalyst;
        private DataGridViewTextBoxColumn R_RPP_ID;
        private DataGridViewTextBoxColumn R_SER_NUM_ID;
        private DataGridViewTextBoxColumn R_NumType;
        private DataGridViewLinkColumn R_Num;
        private DataGridViewLinkColumn R_NrnReg;
        private DataGridViewLinkColumn R_Name;
        private DataGridViewImageColumn R_Delete;
        private DataGridViewTextBoxColumn S_RPP_ID;
        private DataGridViewTextBoxColumn S_SER_NUM_ID;
        private DataGridViewTextBoxColumn S_NumType;
        private DataGridViewLinkColumn S_Num;
        private DataGridViewLinkColumn S_NrnReg;
        private DataGridViewLinkColumn S_Name;
        private DataGridViewImageColumn S_Delete;
        private DataGridViewTextBoxColumn A_RPP_ID;
        private DataGridViewTextBoxColumn A_SER_NUM_ID;
        private DataGridViewTextBoxColumn A_NumType;
        private DataGridViewLinkColumn A_Num;
        private DataGridViewLinkColumn A_NrnReg;
        private DataGridViewLinkColumn A_Name;
        private DataGridViewImageColumn A_Delete;
        private DataGridViewTextBoxColumn C_RPP_ID;
        private DataGridViewTextBoxColumn C_SER_NUM_ID;
        private DataGridViewTextBoxColumn C_NumType;
        private DataGridViewLinkColumn C_Num;
        private DataGridViewLinkColumn C_NrnReg;
        private DataGridViewLinkColumn C_Name;
        private DataGridViewImageColumn C_Delete;
        
    }
}
