﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using System.Linq;
//using mshtml;
using HtmlRichText;
using System.Text.RegularExpressions;
using IndxReactNarrBLL;
using IndxReactNarr.Generic;
using IndxReactNarrBll;
using IndxReactNarr.UserControls;
using IndxReactNarr.Common;
using IndxReactNarrDAL;
using IndxReactNarr.Curation.ExperimentalProcedures;

namespace IndxReactNarr
{
    public partial class ucExpProceduresCuration : UserControl
    {
        public ucExpProceduresCuration()
        {
            InitializeComponent();
        }

        public int documentid = 0;
        public int reactionID = 0;
        //public int rowindex = 0;
        DataSet dsFandR = new DataSet();

        private DataSet _dsFandR = null;
        public DataSet DsFindAndReplace
        {
            get { return _dsFandR; }
            set { _dsFandR = value; }
        }

        public int Rxn_ID { get; set; }

        public DataTable TAN_Reactions { get; set; }
        public DataTable TAN_Documents { get; set; }
        public DataTable AnalogousRxns { get; set; }

        public string TANType { get; set; }

        public string SelectedCompound { get; set; }
        public DataTable RxnProductCompds { get; set; }

        string paraSplitter = "``PARA``";
        string dataSplitter = "``DATA``";

        public DataTable RxnFindingsData { get; set; }

        string IsCombinedDoc = string.Empty;
        string IsPageLabelBlank = string.Empty;

        public void SetRxnDocRefFileName(int docID)
        {
            try
            {
                if (docID > 0 && TAN_Documents != null)
                {
                    var rxnDocs = from row in TAN_Documents.AsEnumerable()
                                  where row.Field<Int64>("TAN_DOC_ID") == docID
                                  select row;
                    if (rxnDocs != null)
                    {
                        foreach (var r in rxnDocs)
                        {
                            txtDocRef.Text = r["FILE_TYPE1"].ToString();
                            txtDocRef.Tag = r["TAN_DOC_ID"].ToString();
                            txtDocRefFileName.Text = r["FILE_NAME"].ToString();

                            txtPageSize_X.Text = r["PAGE_SIZE_X"].ToString();
                            txtPageSize_Y.Text = r["PAGE_SIZE_Y"].ToString();

                            IsCombinedDoc = r["IS_COMBINED_DOC"].ToString();
                            IsPageLabelBlank = r["IS_PAGE_LABEL_BLANK"].ToString();

                           // DisableChkBoxAndLabel();

                            if (txtDocRef.Text.Trim() == "doc 1" && IsCombinedDoc == "Y")
                            {
                                lblpglabel.Enabled = true;
                                txtPageLabel.Enabled = true;
                                txtPageLabel.Text = "";
                                chkEmptyPgLabel.Enabled = true;
                            }
                            else if (txtDocRef.Text.Trim() == "doc 1" && IsCombinedDoc == "N")
                            {
                                lblpglabel.Enabled = true;
                                txtPageLabel.Enabled = true;
                                txtPageLabel.Text = "";
                                chkEmptyPgLabel.Checked = false;
                                chkEmptyPgLabel.Enabled = false;
                            }
                            else if (txtDocRef.Text.Trim() != "doc 1" && IsPageLabelBlank == "Y")
                            {
                                lblpglabel.Enabled = false;
                                txtPageLabel.Enabled = false;
                                txtPageLabel.Text = "";
                                chkEmptyPgLabel.Checked = false;
                                chkEmptyPgLabel.Enabled = false;
                            }
                            else if (txtDocRef.Text.Trim() != "doc 1" && IsPageLabelBlank == "N")
                            {
                                lblpglabel.Enabled = true;
                                txtPageLabel.Enabled = true;
                                txtPageLabel.Text = "";
                                chkEmptyPgLabel.Checked = false;
                                chkEmptyPgLabel.Enabled = false;
                            }
                            else 
                            {
                                lblpglabel.Enabled = true;
                                txtPageLabel.Enabled = true;
                                txtPageLabel.Text = "";

                                chkEmptyPgLabel.Checked = false;
                                chkEmptyPgLabel.Enabled = true; 
                            
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void DisableChkBoxAndLabel()
        {
            try
            {
                //lblpglabel.Enabled = false;
                //txtPageLabel.Enabled = false;
                //txtPageLabel.Text = "";
                //chkEmptyPgLabel.Checked = false;
                //chkEmptyPgLabel.Enabled = false;

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void ClearControlValues()
        {
            try
            {
                txtRxnNum.Clear();
                txtRxnSeq.Clear();
                txtPageNo.Clear();
                txtPageLabel.Clear();
                txtOffset_X.Clear();
                txtOffset_Y.Clear();
                txtPageSize_X.Clear();
                txtPageSize_Y.Clear();
                txtNarrID.Clear();
                                
                txtDocRef.Clear();                          
                txtDocRef.Tag = "";                

                txtDocRefFileName.Clear();

                rbnExpProcedure.Checked = true;

                chkMappingUpdate.Checked = false;

                ucHrtbTextLine.hrtbPara.Clear();
                uchrtbYieldText.hrtbPara.Clear();
                uchrtbProcSteps.hrtbPara.Clear();

                uchrtbReferencePara.hrtbPara.Clear();
                uchrtbDataForFindings_New.hrtbPara.Clear();

                while (flPnlData.Controls.Count > 0)
                {
                    var controltoremove = flPnlData.Controls[0];
                    flPnlData.Controls.Remove(controltoremove);
                    controltoremove.Dispose();
                }

                while (flPnlPara.Controls.Count > 0)
                {
                    var controltoremove = flPnlPara.Controls[0];
                    flPnlPara.Controls.Remove(controltoremove);
                    controltoremove.Dispose();
                }

                while (flPnlRxnFindings.Controls.Count > 0)
                {
                    var controltoremove = flPnlRxnFindings.Controls[0];
                    flPnlRxnFindings.Controls.Remove(controltoremove);
                    controltoremove.Dispose();
                }

                lblDataCnt.Text = "0";
                lblParaCnt.Text = "0";
                lblProcStepCount.Text = "0";
                lblRxnFindingsCnt.Text = "0";

                lblpglabel.Enabled = true;
                txtPageLabel.Enabled = true;
                txtPageLabel.Text = "";

                chkEmptyPgLabel.Checked = false;
                chkEmptyPgLabel.Enabled = true;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #region Allow Numbers,Dot,Hyphen,BackSpace when keypress

        private void txtpagenumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            AllowNumsBackSpaceDotAndHyphen(e);
        }

        private void txtxoffset_KeyPress(object sender, KeyPressEventArgs e)
        {
            AllowNumsBackSpaceDotAndHyphen(e);
        }

        private void txtyoffset_KeyPress(object sender, KeyPressEventArgs e)
        {
            AllowNumsBackSpaceDotAndHyphen(e);
        }

        private void txtypagesize_KeyPress(object sender, KeyPressEventArgs e)
        {
            AllowNumsBackSpaceDotAndHyphen(e);
        }

        private void txtxpagesize_KeyPress(object sender, KeyPressEventArgs e)
        {
            AllowNumsBackSpaceDotAndHyphen(e);
        }

        private static void AllowNumsBackSpaceDotAndHyphen(KeyPressEventArgs e)
        {
            try
            {
                // Asci--------char
                //   48         '0'
                //   57         '9'
                //    8         'BackSpace'
                //   46         '.'
                //   45         '-'
                if (((e.KeyChar >= 48 && e.KeyChar <= 57) || e.KeyChar == 8 || e.KeyChar == 46 || e.KeyChar == 45) != true)
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }


        #endregion

        /// <summary>
        /// Gets Html data from the FlowLayoutPanel
        /// </summary>
        /// <param name="controlType"></param>
        /// <returns>Html string</returns>
        /// 
        FlowLayoutPanel flPanel = null;
        ucHtmlRichText ucHrtb;
        string strHtml = "";
        private string GetPara_DataFromControls(string controlType)
        {
            string strPara_Data = "";
            try
            {
                string strSplitter = "";
                if (controlType.ToUpper() == "PARA")
                {
                    flPanel = flPnlPara;
                    strSplitter = paraSplitter;
                }
                else if (controlType.ToUpper() == "DATA")
                {
                    flPanel = flPnlData;
                    strSplitter = dataSplitter;
                }

                if (flPanel != null && flPanel.Controls.Count > 0)
                {
                    for (int i = 0; i < flPanel.Controls.Count; i++)
                    {
                        ucHrtb = flPanel.Controls[i] as ucHtmlRichText;
                        if (ucHrtb != null)
                        {
                            if (!string.IsNullOrEmpty(ucHrtb.hrtbPara.Text.Trim()))
                            {
                                strHtml = ucHrtb.GetHtmlStringFromControl();

                                if (!string.IsNullOrEmpty(strHtml))
                                {
                                    strPara_Data = string.IsNullOrEmpty(strPara_Data) ? strHtml : strPara_Data + strSplitter + strHtml;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strPara_Data;
        }

        /// <summary>
        /// Binds Reaction data to control
        /// </summary>
        /// <param name="rxnRow"></param>
        /// 
        DataTable dtProducts = null;
        DataTable dtOtherPartpnts = null;
        DataTable dtRxnSubstances = null;

        public void BindReactionDataToControls(DataRow rxnRow, DataTable rxnSubstances, DataTable rxnFindings)
        {
            try
            {
                //Clear control values
                ClearControlValues();

                if (rxnRow != null)
                {
                    //Reaction ID
                    if (rxnRow["RXN_ID"] != null)
                    {
                        int rxnID = 0;
                        int.TryParse(rxnRow["RXN_ID"].ToString(), out rxnID);
                        Rxn_ID = rxnID;
                    }

                    txtNarrID.Text = rxnRow["RXN_NAR_ID"].ToString();
                    txtRxnNum.Text = rxnRow["RXN_NUM"].ToString();
                    txtRxnSeq.Text = rxnRow["RXN_SEQ"].ToString();
                    txtPageNo.Text = rxnRow["PAGE_NO"].ToString();

                    txtPageLabel.Text = rxnRow["PAGE_LABEL"].ToString();

                    txtOffset_X.Text = rxnRow["OFFSET_X"].ToString();
                    txtOffset_Y.Text = rxnRow["OFFSET_Y"].ToString();
                    txtPageSize_X.Text = rxnRow["PAGE_SIZE_X"].ToString();
                    txtPageSize_Y.Text = rxnRow["PAGE_SIZE_Y"].ToString();

                    rbnMissingRxn.Checked = (Convert.ToString(rxnRow["IS_MISSING_RXN"]).Equals("Y"));
                    rbnNoExpDetails.Checked = (Convert.ToString(rxnRow["NO_EXP_DETAILS"]).Equals("Y"));
                    rbnGeneralTypical.Checked = (Convert.ToString(rxnRow["IS_GENERAL_TYPICAL"]).Equals("Y"));

                    chkEmptyPgLabel.Enabled = true;
                    chkEmptyPgLabel.Checked = (Convert.ToString(rxnRow["IS_NO_PAGE_LABEL"]).Equals("Y"));
                    //TextLine
                    if (!string.IsNullOrEmpty(rxnRow["TEXT_LINE"].ToString()))
                    {
                        ucHrtbTextLine.BindDataToControl(rxnRow["TEXT_LINE"].ToString());
                    }

                    //Procedure Text
                    if (!string.IsNullOrEmpty(rxnRow["PROCEDURE_TEXT"].ToString()))
                    {
                        uchrtbProcSteps.BindDataToControl(rxnRow["PROCEDURE_TEXT"].ToString());
                    }

                    //Yield Text
                    if (!string.IsNullOrEmpty(rxnRow["YIELD_TEXT"].ToString()))
                    {
                        uchrtbYieldText.BindDataToControl(rxnRow["YIELD_TEXT"].ToString());
                    }

                    //Doc Reference
                    if (rxnRow["TAN_DOC_ID"] != null)
                    {
                        int docrefID = 0;
                        int.TryParse(rxnRow["TAN_DOC_ID"].ToString(), out docrefID);
                        SetRxnDocRefFileName(docrefID);

                        //Set Page Label enabled is false, if Document wise Page label is blank
                        if (CheckDocumentPageLabelBlank(docrefID))
                        {
                            txtPageLabel.Text = "";
                            txtPageLabel.Enabled = false;
                            lblpglabel.Enabled = false;
                        }
                        else
                        {
                            txtPageLabel.Text = rxnRow["PAGE_LABEL"].ToString();
                            lblpglabel.Enabled = true;
                        }
                    }


                    //Set Analogous Reactions
                    if (Rxn_ID > 0 && TAN_Reactions != null && TAN_Reactions.Rows.Count > 0)
                    {
                        var rows = TAN_Reactions.AsEnumerable()
                                         .Where(r => r.Field<Int64>("RXN_ID") != Rxn_ID && r.Field<string>("IS_ANALOGOUS") == "N");

                        DataTable dtAnalogous = rows.Any() ? rows.CopyToDataTable() : TAN_Reactions.Clone();
                        if (dtAnalogous != null && dtAnalogous.Rows.Count > 0)
                        {
                            AnalogousRxns = dtAnalogous;
                        }
                    }

                    //Set Analogous Reaction
                    if (rxnRow["IS_ANALOGOUS"] != null)
                    {
                        if (rxnRow["IS_ANALOGOUS"].ToString().ToUpper() == "Y")
                        {
                            rbnAnalogousTo.Checked = true;

                            cmbAnalogousTo.SelectedValue = rxnRow["ANALOGOUS_RXN_ID"];
                        }
                        else
                        {
                            rbnAnalogousTo.Checked = false;
                        }
                    }
                    else
                    {
                        rbnAnalogousTo.Checked = false;
                    }

                    //Set Para
                    if (!string.IsNullOrEmpty(rxnRow["PARA_TEXT"].ToString()))
                    {
                        string[] saPara = rxnRow["PARA_TEXT"].ToString().Split(new string[] { paraSplitter }, StringSplitOptions.RemoveEmptyEntries);
                        if (saPara != null && saPara.Length > 0)
                        {
                            for (int i = 0; i < saPara.Length; i++)
                            {
                                CreateParaAndBindToPanel("PARA", saPara[i].Trim());
                            }
                        }
                    }

                    //Set Data
                    if (!string.IsNullOrEmpty(rxnRow["DATA_TEXT"].ToString()))
                    {
                        string[] saData = rxnRow["DATA_TEXT"].ToString().Split(new string[] { dataSplitter }, StringSplitOptions.RemoveEmptyEntries);
                        if (saData != null && saData.Length > 0)
                        {
                            for (int i = 0; i < saData.Length; i++)
                            {
                                CreateParaAndBindToPanel("DATA", saData[i].Trim());
                            }
                        }
                    }
                }

                //Reaction Substances
                if (rxnSubstances != null)
                {
                    dtRxnSubstances = rxnSubstances;

                    var prodRows = rxnSubstances.AsEnumerable()
                                         .Where(r => r.Field<string>("SUBST_ROLE") == "product");
                    dtProducts = prodRows.Any() ? prodRows.CopyToDataTable() : rxnSubstances.Clone();

                    var otherRows = rxnSubstances.AsEnumerable()
                                         .Where(r => r.Field<string>("SUBST_ROLE") != "product");
                    dtOtherPartpnts = otherRows.Any() ? otherRows.CopyToDataTable() : rxnSubstances.Clone();

                    //If Reaction Product count = 1, then enable Auto Findings button else disable
                    //btnAutoFindingsNew.Enabled = dtProducts.Rows.Count == 1 ? true : false;
                }

                //New code for handling mapping update - Exp.Procedures extension work - 11th March 2016
                if (!string.IsNullOrEmpty(rxnRow["IS_MAPPING_UPDATED"].ToString()))
                {
                    chkMappingUpdate.Checked = rxnRow["IS_MAPPING_UPDATED"].ToString() == "Y" ? true : false;
                }

                //New reaction findings - 20AUG2015
                BindReactionFindingsDataToControls(rxnFindings);

                //Bind Reference Para and Data to controls
                BindReferenceParaAndDataValuesToControls("PARA");
                BindReferenceParaAndDataValuesToControls("DATA");

                //Set Labels count
                SetPara_Data_ProcSteps_FindingsLabelsCount();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private bool CheckDocumentPageLabelBlank(int tanDocID)
        {
            bool blStatus = false;
            try
            {
                if (TAN_Documents != null && TAN_Documents.Rows.Count > 0 && tanDocID > 0)
                {
                    var rows = TAN_Documents.AsEnumerable()
                                             .Where(r => r.Field<Int64>("TAN_DOC_ID") == tanDocID && r.Field<string>("IS_PAGE_LABEL_BLANK") == "Y");

                    DataTable dtAnalogous = rows.Any() ? rows.CopyToDataTable() : TAN_Reactions.Clone();
                    if (dtAnalogous != null && dtAnalogous.Rows.Count > 0)
                    {
                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private DataTable GetRxnFindingsWithRtfColumn(DataTable rxnFindings)
        {
            DataTable dtRxnFindings = null;
            try
            {
                if (rxnFindings != null)
                {
                    dtRxnFindings = rxnFindings.Copy();

                    if (!dtRxnFindings.Columns.Contains("FINDING_VALUE_RTF"))
                    {
                        dtRxnFindings.Columns.Add("FINDING_VALUE_RTF");
                    }

                    for (int i = 0; i < dtRxnFindings.Rows.Count; i++)
                    {
                        if (dtRxnFindings.Rows[i]["FINDING_VALUE"] != null)
                        {
                            dtRxnFindings.Rows[i]["FINDING_VALUE_RTF"] = Html_RtfConversions.Instance.GetRTFfromHTMLString(dtRxnFindings.Rows[i]["FINDING_VALUE"].ToString(), false);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtRxnFindings;
        }

        public NarrReactionsBO GetNarrReactionDataFromUserControl()
        {
            NarrReactionsBO narRxnData = null;
            try
            {
                if (Rxn_ID > 0)
                {
                    narRxnData = new NarrReactionsBO();
                    narRxnData.RXN_ID = Rxn_ID;

                    if (!rbnMissingRxn.Checked)
                    {
                        if (txtDocRef.Tag != null)
                        {
                            int docRefID = 0;
                            int.TryParse(txtDocRef.Tag.ToString(), out docRefID);
                            if (docRefID > 0)
                            {
                                narRxnData.RxnDocID = docRefID;
                            }
                        }
                    }
                    narRxnData.PageNo = txtPageNo.Text.Trim();
                    narRxnData.PageLabel = txtPageLabel.Text.Trim();
                    narRxnData.XOffSet = !rbnMissingRxn.Checked ? txtOffset_X.Text.Trim() : "";
                    narRxnData.YOffSet = !rbnMissingRxn.Checked ? txtOffset_Y.Text.Trim() : "";
                    narRxnData.IsNoPageLabel = chkEmptyPgLabel.Checked ? "Y" : "N";

                    narRxnData.IsMappingUpdated = chkMappingUpdate.Checked ? "Y" : "N";

                    double dblXPageSize = 0;
                    double.TryParse(txtPageSize_X.Text.Trim(), out dblXPageSize);

                    double dblYPageSize = 0;
                    double.TryParse(txtPageSize_Y.Text.Trim(), out dblYPageSize);

                    narRxnData.XPageSize = dblXPageSize;
                    narRxnData.YPageSize = dblYPageSize;
                    narRxnData.IsGeneralTypical = rbnGeneralTypical.Checked ? "Y" : "N";
                    narRxnData.NoExpDetails = rbnNoExpDetails.Checked ? "Y" : "N";
                    narRxnData.IsMissingRxn = rbnMissingRxn.Checked ? "Y" : "N";
                    
                    narRxnData.TextLine = ucHrtbTextLine.GetHtmlStringFromControl();
                    narRxnData.YieldText = uchrtbYieldText.GetHtmlStringFromControl();
                    narRxnData.ProcedureText = uchrtbProcSteps.GetHtmlStringFromControl();

                    //Para & Data
                    narRxnData.Para = GetPara_DataFromControls("PARA");//Get Para from UserControl          
                    narRxnData.Data = GetPara_DataFromControls("DATA");//Get Data from UserControl

                    //Analogous Reaction
                    narRxnData.IsAnalogous = rbnAnalogousTo.Checked ? "Y" : "N";
                    if (rbnAnalogousTo.Checked)
                    {
                        if (cmbAnalogousTo.SelectedItem != null)
                        {
                            narRxnData.AnalogousRxnID = Convert.ToInt32(cmbAnalogousTo.SelectedValue);
                        }
                    }

                    //Reaction Findings
                    narRxnData.ReactionFindings = GetReactionFindingsFromUserControl_New();//GetReactionFindingsFromUserControl();

                    narRxnData.UserID = GlobalVariables.URID;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return narRxnData;
        }

        private RxnFindings GetReactionFindingsFromUserControl_New()
        {
            RxnFindings rxnFinding = null;
            ucRxnFinding ucFinding = null;

            try
            {
                if (Rxn_ID > 0)
                {
                    rxnFinding = new RxnFindings();
                    rxnFinding.RxnID = Rxn_ID;

                    if (flPnlRxnFindings.Controls.Count > 0)
                    {
                        List<string> lstFindings = new List<string>();
                        List<string> lstFindingValue = new List<string>();
                        List<string> lstRefComp = new List<string>();
                        string findingType = "";

                        for (int i = 0; i < flPnlRxnFindings.Controls.Count; i++)
                        {
                            ucFinding = flPnlRxnFindings.Controls[i] as ucRxnFinding;

                            if (ucFinding != null)
                            {
                                findingType = "";
                                findingType = ucFinding.cmbFindingType.Text.ToString();

                                //Finding Type
                                lstFindings.Add(findingType);

                                //Finding Value
                                if (findingType.ToUpper() == "EQUIPMENT/MATERIALS" || findingType.ToUpper() == "SCALE")
                                {
                                    lstFindingValue.Add(ucFinding.cmbFindingMaterials.Text);

                                    //Reference Compound
                                    lstRefComp.Add("");
                                }
                                else
                                {
                                    lstFindingValue.Add(ucFinding.uchrtbFindingData.GetHtmlStringFromControl());

                                    if (findingType.ToUpper() == "SAFETY")
                                    {
                                        //Reference Compound
                                        lstRefComp.Add("");
                                    }
                                    else
                                    {

                                        //Reference Compound
                                        lstRefComp.Add(ucFinding.cmbFindingRefCompound.Text);
                                    }
                                }
                            }
                        }

                        rxnFinding.FindingTypes = lstFindings;
                        rxnFinding.FindingValues = lstFindingValue;
                        rxnFinding.RefCompounds = lstRefComp;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            finally
            {
                ucFinding = null;
            }
            return rxnFinding;
        }

        public bool ValidateNarrReactionData(bool skipValidations, out string errMsgOut)
        {
            bool blStatus = true;
            string strErrMsg = "";
                       
            try
            {
                 string errMsg = "";
                              

                //New condition to handle Missing reactions in Exp.Procedures extension task - 15th Mar 2016
                if (!rbnMissingRxn.Checked)
                {
                    if (string.IsNullOrEmpty(ucHrtbTextLine.hrtbPara.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "TextLine is mandatory";
                        blStatus = false;
                    }

                    if (rbnGeneralTypical.Checked)
                    {
                        if (flPnlPara.Controls.Count < 2)
                        {
                            strErrMsg = strErrMsg.Trim() + Environment.NewLine + "For GeneralTypical reactions, >= 2 Paras should be there.";
                            blStatus = false;
                        }
                    }
                    else if (rbnAnalogousTo.Checked)
                    {
                        if (flPnlPara.Controls.Count != 1 && skipValidations == false)//For Experimental Procedures extension work, skip this validation
                        {
                            strErrMsg = strErrMsg.Trim() + Environment.NewLine + "For Analogous reactions, only one Para should be there.";
                            blStatus = false;
                        }
                    }
                    else if (rbnNoExpDetails.Checked)
                    {
                        if (flPnlPara.Controls.Count > 1 && skipValidations == false)//For Experimental Procedures extension work, skip this validation
                        {
                            strErrMsg = strErrMsg.Trim() + Environment.NewLine + "For No Experimental details, only zero/one Para should be there.";
                            blStatus = false;
                        }
                    }
                    else if (rbnExpProcedure.Checked)
                    {
                        if (flPnlPara.Controls.Count != 2 && skipValidations == false)//For Experimental Procedures extension work, skip this validation
                        {
                            strErrMsg = strErrMsg.Trim() + Environment.NewLine + "For Experimental procedures, 2 Paras should be there.";
                            blStatus = false;
                        }
                    }

                    //Page No
                    if (string.IsNullOrEmpty(txtPageNo.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Page No. is mandatory";
                        blStatus = false;
                    }
                    else
                    {
                        int intPageNo = 0;
                        int.TryParse(txtPageNo.Text.Trim(), out intPageNo);
                        if (intPageNo == 0)
                        {
                            strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Page No. should be > 0";
                            blStatus = false;
                        }
                    }

                    int intPageLabel = 0;

                    //Doc Ref
                    if (txtDocRef.Tag == null)
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Doc Ref is mandatory";
                        blStatus = false;
                    }
                    else if (chkEmptyPgLabel.Enabled == true && chkEmptyPgLabel.Checked == true && !string.IsNullOrEmpty(txtPageLabel.Text))
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "If No Pg.Label is Checked then, Page Label should be Empty";
                        blStatus = false;

                    }
                    else if (txtDocRef.Text.Trim() == "doc 1" && IsCombinedDoc == "N")
                    {
                        //Page Label
                        if (string.IsNullOrEmpty(txtPageLabel.Text.Trim()))
                        {
                            strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Page Label is mandatory";
                            blStatus = false;
                        }
                        else
                        {
                            //If doc1, page label should be number

                            int.TryParse(txtPageLabel.Text.Trim(), out intPageLabel);
                            if (intPageLabel == 0 && txtDocRef.Text.Trim().ToUpper() == "DOC 1" && skipValidations == false)
                            {
                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "If doc 1, Page Label should be number";
                                blStatus = false;
                            }

                        }
                    }
                    else if (txtDocRef.Text.Trim() == "doc 1" && IsCombinedDoc == "Y")
                    {
                        if (string.IsNullOrEmpty(txtPageLabel.Text.Trim()) && chkEmptyPgLabel.Checked == false)
                        {
                            strErrMsg = strErrMsg.Trim() + Environment.NewLine + "If doc 1, Page label should be mentioned (or) No Pg.Label should be checked";
                            blStatus = false;
                        }
                        else if (!string.IsNullOrEmpty(txtPageLabel.Text.Trim()))
                        {
                            if (txtDocRef.Text.Trim().ToUpper() == "DOC 1")//New validation on 15th Oct 2015
                            {
                                if (!Validations.ValidatePageLabel(txtPageLabel.Text.Trim(), ref errMsg))
                                {
                                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + errMsg;
                                    blStatus = false;
                                }
                            }
                        }

                        //Code commented on 15th Oct 2015
                        //int.TryParse(txtPageLabel.Text.Trim(), out intPageLabel);
                        //if (intPageLabel == 0 && txtDocRef.Text.Trim().ToUpper() == "DOC 1")
                        //{
                        //    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "If doc 1, Page Label should be number";
                        //    blStatus = false;
                        //}

                    }
                    else if (txtDocRef.Text.Trim() != "doc 1" && IsPageLabelBlank == "N")
                    {
                        if (string.IsNullOrEmpty(txtPageLabel.Text.Trim()))
                        {
                            strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Page Label is mandatory";
                            blStatus = false;
                        }
                        else
                        {
                            //Code commented on 15th Oct 2015
                            ////int.TryParse(txtPageLabel.Text.Trim(), out intPageLabel);
                            //if (intPageLabel == 0)
                            //{
                            //    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "If " + txtDocRef.Text.Trim() + " , Page Label should be number";
                            //    blStatus = false;
                            //}

                            if (!Validations.ValidatePageLabel(txtPageLabel.Text.Trim(), ref errMsg))//New validation on 16th Oct 2015
                            {
                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + txtDocRef.Text.Trim() + " , " + errMsg;
                                blStatus = false;
                            }
                        }
                    }

                    //Validate Page Label               
                    if (TANType.ToUpper() == "PATENT" && !string.IsNullOrEmpty(txtPageLabel.Text.Trim()))
                    {
                        int pageLbl = 0;
                        if (!int.TryParse(txtPageLabel.Text.Trim(), out pageLbl))
                        {
                            strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Page Label should be integer";
                            blStatus = false;
                        }
                    }
                    else
                    {
                        if (!Validations.ValidatePageLabel(txtPageLabel.Text.Trim(), ref errMsg))
                        {
                            strErrMsg = strErrMsg.Trim() + Environment.NewLine + errMsg.Trim();
                            blStatus = false;
                        }
                    }

                    //X Page Size
                    if (string.IsNullOrEmpty(txtPageSize_X.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "X Page Size is mandatory";
                        blStatus = false;
                    }
                    else
                    {
                        double xPageSize = 0;
                        double.TryParse(txtPageSize_X.Text.Trim(), out xPageSize);
                        if (xPageSize == 0)
                        {
                            strErrMsg = strErrMsg.Trim() + Environment.NewLine + "X Page Size should be > 0";
                            blStatus = false;
                        }
                    }

                    //Y Page Size
                    if (string.IsNullOrEmpty(txtPageSize_Y.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Y Page Size is mandatory";
                        blStatus = false;
                    }
                    else
                    {
                        double yPageSize = 0;
                        double.TryParse(txtPageSize_Y.Text.Trim(), out yPageSize);
                        if (yPageSize == 0)
                        {
                            strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Y Page Size should be > 0";
                            blStatus = false;
                        }
                    }

                    //X Page OffSet
                    if (string.IsNullOrEmpty(txtOffset_X.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Page X Offset is mandatory";
                        blStatus = false;
                    }
                    else
                    {
                        double xPageOffset = 0;
                        double.TryParse(txtOffset_X.Text.Trim(), out xPageOffset);
                        if (xPageOffset == 0)
                        {
                            strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Page X Offset should be > 0";
                            blStatus = false;
                        }
                    }

                    //Y Page OffSet
                    if (string.IsNullOrEmpty(txtOffset_Y.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Page Y Offset is mandatory";
                        blStatus = false;
                    }
                    else
                    {
                        double yPageOffset = 0;
                        double.TryParse(txtOffset_Y.Text.Trim(), out yPageOffset);
                        if (yPageOffset == 0)
                        {
                            strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Page Y Offset should be > 0";
                            blStatus = false;
                        }
                    }

                    //Analogous Reaction
                    if (rbnAnalogousTo.Checked && cmbAnalogousTo.SelectedItem == null)
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Analogous Reaction is mandatory";
                        blStatus = false;
                    }

                    ////Validate Page Label
                    #region MyRegion
                    //string errMsg = "";
                    //if (TANType.ToUpper() == "PATENT")
                    //{
                    //    int pageLbl = 0;
                    //    if (!int.TryParse(txtPageLabel.Text.Trim(), out pageLbl))
                    //    {
                    //        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Page Label should be integer";
                    //        blStatus = false;
                    //    }
                    //}
                    //else
                    //{
                    //    if (!Validations.ValidatePageLabel(txtPageLabel.Text.Trim(), ref errMsg))
                    //    {
                    //        strErrMsg = strErrMsg.Trim() + Environment.NewLine + errMsg.Trim();
                    //        blStatus = false;
                    //    }
                    //} 
                    #endregion

                    //Empty Para verification
                    if (flPnlPara.Controls.Count > 0)
                    {
                        ucHtmlRichText ucHrtb;
                        for (int i = 0; i < flPnlPara.Controls.Count; i++)
                        {
                            ucHrtb = flPnlPara.Controls[i] as ucHtmlRichText;
                            if (ucHrtb != null)
                            {
                                if (string.IsNullOrEmpty(ucHrtb.hrtbPara.Text.Trim()))
                                {
                                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Empty Para -" + (i + 1);
                                    blStatus = false;
                                }
                            }
                        }
                    }

                    //Empty Data verification
                    if (flPnlData.Controls.Count > 0)
                    {
                        ucHtmlRichText ucHrtb;
                        for (int i = 0; i < flPnlData.Controls.Count; i++)
                        {
                            ucHrtb = flPnlData.Controls[i] as ucHtmlRichText;
                            if (ucHrtb != null)
                            {
                                if (string.IsNullOrEmpty(ucHrtb.hrtbPara.Text.Trim()))
                                {
                                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Empty Data -" + (i + 1);
                                    blStatus = false;
                                }
                            }
                        }
                    }

                    //Validate UniCodes in PARA
                    if (flPnlPara.Controls.Count > 0)
                    {
                        string unicodeErr = "";
                        ucHtmlRichText ucHrtb;
                        for (int i = 0; i < flPnlPara.Controls.Count; i++)
                        {
                            ucHrtb = flPnlPara.Controls[i] as ucHtmlRichText;
                            if (ucHrtb != null)
                            {
                                if (!string.IsNullOrEmpty(ucHrtb.hrtbPara.Text.Trim()))
                                {
                                    if (!ucHrtb.ValidateUniCodes(out unicodeErr))
                                    {
                                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "PARA " + unicodeErr;
                                        blStatus = false;
                                    }
                                }
                            }
                        }
                    }

                    //Validate UniCodes in DATA
                    if (flPnlData.Controls.Count > 0)
                    {
                        string unicodeErr = "";
                        ucHtmlRichText ucHrtb;
                        for (int i = 0; i < flPnlData.Controls.Count; i++)
                        {
                            ucHrtb = flPnlData.Controls[i] as ucHtmlRichText;
                            if (ucHrtb != null)
                            {
                                if (!string.IsNullOrEmpty(ucHrtb.hrtbPara.Text.Trim()))
                                {
                                    if (!ucHrtb.ValidateUniCodes(out unicodeErr))
                                    {
                                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "DATA " + unicodeErr;
                                        blStatus = false;
                                    }
                                }
                            }
                        }
                    }

                    //For No Experimental details, Procedure Steps are not mandatory
                    if (!rbnNoExpDetails.Checked && string.IsNullOrEmpty(uchrtbProcSteps.hrtbPara.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Procedure steps are mandatory";
                        blStatus = false;
                    }

                    //For No Experimental details/Analogous rxn, Reaction findings are not mandatory
                    if (!rbnNoExpDetails.Checked && !rbnAnalogousTo.Checked && flPnlData.Controls.Count > 0 && flPnlRxnFindings.Controls.Count == 0) //dgvRxnFindings.Rows.Count == 0 |
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Reaction findings are mandatory";
                        blStatus = false;
                    }

                    //Validate Reaction Findings in Panel
                    string findingErrors = "";
                    if (!ValidateRxnFindingValues(out findingErrors))
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + findingErrors;
                        blStatus = false;
                    }

                    #region Old code commented, code moved to Method
                    //if (flPnlRxnFindings.Controls.Count > 0)
                    //{
                    //    string unicodeErr = "";
                    //    ucRxnFinding ucFinding;

                    //    for (int i = 0; i < flPnlRxnFindings.Controls.Count; i++)
                    //    {
                    //        ucFinding = flPnlRxnFindings.Controls[i] as ucRxnFinding;
                    //        if (ucHrtb != null)
                    //        {
                    //            //Finding Data
                    //            if (ucFinding.uchrtbFindingData.Visible && string.IsNullOrEmpty(ucFinding.uchrtbFindingData.hrtbPara.Text.Trim()))
                    //            {
                    //                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Empty Finding value-" + (i + 1);
                    //                blStatus = false;
                    //            }
                    //            else if (ucFinding.uchrtbFindingData.Visible && !ucFinding.uchrtbFindingData.ValidateUniCodes(out unicodeErr))
                    //            {
                    //                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Invalid Finding value-" + (i + 1) + unicodeErr;
                    //                blStatus = false;
                    //            }
                    //            else if (ucFinding.cmbFindingMaterials.Visible && string.IsNullOrEmpty(ucFinding.cmbFindingType.Text))
                    //            {
                    //                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Empty Finding value-" + (i + 1);
                    //                blStatus = false;
                    //            }

                    //            //Finding Type
                    //            if (string.IsNullOrEmpty(ucFinding.cmbFindingType.Text))
                    //            {
                    //                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Empty Finding Type -" + (i + 1);
                    //                blStatus = false;
                    //            }

                    //            //Reference Compound
                    //            if (ucFinding.cmbFindingRefCompound.Enabled && string.IsNullOrEmpty(ucFinding.cmbFindingRefCompound.Text))
                    //            {
                    //                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Empty Reference Compouns -" + (i + 1);
                    //                blStatus = false;
                    //            }
                    //        }
                    //    }

                    //    //Validate duplicate findings
                    //    List<string> lstNonDuplicateTypes = new List<string>();
                    //    List<string> lstDuplicateTypes = new List<string>();
                    //    for (int i = 0; i < flPnlRxnFindings.Controls.Count; i++)
                    //    {
                    //        ucFinding = flPnlRxnFindings.Controls[i] as ucRxnFinding;
                    //        if (ucHrtb != null)
                    //        {
                    //            if (!string.IsNullOrEmpty(ucFinding.cmbFindingType.Text) && !string.IsNullOrEmpty(ucFinding.cmbFindingRefCompound.Text))
                    //            {
                    //                if (!lstNonDuplicateTypes.Contains(ucFinding.cmbFindingType.Text + "-" + ucFinding.cmbFindingRefCompound.Text))
                    //                {
                    //                    lstNonDuplicateTypes.Add(ucFinding.cmbFindingType.Text + "-" + ucFinding.cmbFindingRefCompound.Text);
                    //                }
                    //                else
                    //                {
                    //                    lstDuplicateTypes.Add(ucFinding.cmbFindingType.Text + "-" + ucFinding.cmbFindingRefCompound.Text);
                    //                }
                    //            }
                    //        }
                    //    }

                    //    if (lstDuplicateTypes.Count > 0)
                    //    {
                    //        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Duplicate Finding Types -" + string.Join(", ", lstDuplicateTypes.ToArray()); ;
                    //        blStatus = false;
                    //    }


                    //    #region  Validate Other Reaction Finding Types

                    //    for (int i = 0; i < flPnlRxnFindings.Controls.Count; i++)
                    //    {
                    //        ucFinding = flPnlRxnFindings.Controls[i] as ucRxnFinding;
                    //        if (ucHrtb != null && !string.IsNullOrEmpty(ucFinding.uchrtbFindingData.hrtbPara.Text.Trim())
                    //                           && !string.IsNullOrEmpty(ucFinding.cmbFindingType.Text))
                    //        {
                    //            if (!ValidateOtherRxnFindingTypes(ucFinding, i, out strErr))
                    //            {
                    //                strErrMsg += strErr.Trim() + Environment.NewLine;
                    //                blStatus = false;
                    //            }
                    //        }
                    //    }

                    //    #endregion
                    //} 
                    #endregion

                    #region Validate Procedure Steps

                    string procStepsErrors = "";
                    if (!ValidateRxnProcedureSteps(out procStepsErrors))
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + procStepsErrors;
                        blStatus = false;
                    }

                    #region Old code commented, code moved to Method
                    //string[] lines = null;
                    //string[] Sentences = null;
                    //var RegForSpacePeriod = new System.Text.RegularExpressions.Regex(@"(?<!\d)\.(?!\d)");

                    //if (!string.IsNullOrEmpty(uchrtbProcSteps.hrtbPara.Text.Trim()))
                    //{
                    //    lines = uchrtbProcSteps.hrtbPara.Text.Trim().Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);

                    //    // New Validation on 26th aug 2015
                    //    // Sentence should not start with words like 'Afterwards', 'After that' , 'Then' 'Next', 'And'

                    //    if (CheckForProcedureTextLinesContainsInValidWords(lines, out strErr))
                    //    {
                    //        foreach (string line in lines)
                    //        {
                    //            Sentences = Regex.Split(line, @"(?<!\d)\.(?!\d)");

                    //            if (!CheckForDuplicateSentencesInProcedureTextLine(Sentences, out strErr, Array.IndexOf(lines, line)))
                    //            {
                    //                strErrMsg += strErr.Trim() + Environment.NewLine;
                    //                blStatus = false;
                    //            }
                    //        }
                    //    }
                    //    else
                    //    {
                    //        strErrMsg += strErr.Trim() + Environment.NewLine;
                    //        blStatus = false;
                    //    }
                    //} 
                    #endregion

                    #endregion

                }
                else //Missing reaction, Exp.Procedures extension work validation, 15th March 2016
                {
                    string missingRxnErrors = "";
                    if (!ValidateControlValuesForMissingReaction(out missingRxnErrors))
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + missingRxnErrors;
                        blStatus = false;
                    }
                }

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsgOut = strErrMsg.Trim();
            return blStatus;
        }

        private bool ValidateControlValuesForMissingReaction(out string errMsgOut)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (!string.IsNullOrEmpty(txtPageNo.Text.Trim()))
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Missing reaction Page No should be empty";
                    blStatus = false;
                }

                if (!string.IsNullOrEmpty(txtPageLabel.Text.Trim()))
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Missing reaction Page Label should be empty";
                    blStatus = false;
                }

                if (!string.IsNullOrEmpty(txtDocRef.Text.Trim()))
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Missing reaction Doc Ref. should be empty";
                    blStatus = false;
                }

                if (!string.IsNullOrEmpty(txtDocRefFileName.Text.Trim()))
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Missing reaction Doc Ref. File Name should be empty";
                    blStatus = false;
                }

                if (!string.IsNullOrEmpty(txtOffset_X.Text.Trim()))
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Missing reaction Page X Offset should be empty";
                    blStatus = false;
                }

                if (!string.IsNullOrEmpty(txtOffset_Y.Text.Trim()))
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Missing reaction Page Y Offset should be empty";
                    blStatus = false;
                }

                if (!String.IsNullOrEmpty(ucHrtbTextLine.hrtbPara.Text.Trim()))
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Missing Reaction Textline should be empty.";
                    blStatus = false;
                }

                if (!String.IsNullOrEmpty(uchrtbYieldText.hrtbPara.Text.Trim()))
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Missing Reaction Yield Text should be empty.";
                    blStatus = false;
                }

                if (flPnlPara.Controls.Count > 0)
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Missing reaction should not have Para.";
                    blStatus = false;
                }

                if (flPnlData.Controls.Count > 0)
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Missing reaction should not have Data.";
                    blStatus = false;
                }

                if (!String.IsNullOrEmpty(uchrtbProcSteps.hrtbPara.Text.Trim()))
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Missing Reaction Procedure Steps should be empty.";
                    blStatus = false;
                }

                if (flPnlRxnFindings.Controls.Count > 0)
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Missing reaction should not have Reaction Findings.";
                    blStatus = false;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsgOut = strErrMsg.Trim();
            return blStatus;
        }

        private bool ValidateRxnFindingValues(out string errMsgOut)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                //Validate Reaction Findings in Panel
                if (flPnlRxnFindings.Controls.Count > 0)
                {
                    string unicodeErr = "";
                    ucRxnFinding ucFinding;

                    for (int i = 0; i < flPnlRxnFindings.Controls.Count; i++)
                    {
                        ucFinding = flPnlRxnFindings.Controls[i] as ucRxnFinding;
                        if (ucHrtb != null)
                        {
                            //Finding Data
                            if (ucFinding.uchrtbFindingData.Visible && string.IsNullOrEmpty(ucFinding.uchrtbFindingData.hrtbPara.Text.Trim()))
                            {
                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Empty Finding value-" + (i + 1);
                                blStatus = false;
                            }
                            else if (ucFinding.uchrtbFindingData.Visible && !ucFinding.uchrtbFindingData.ValidateUniCodes(out unicodeErr))
                            {
                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Invalid Finding value-" + (i + 1) + unicodeErr;
                                blStatus = false;
                            }
                            else if (ucFinding.cmbFindingMaterials.Visible && string.IsNullOrEmpty(ucFinding.cmbFindingType.Text))
                            {
                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Empty Finding value-" + (i + 1);
                                blStatus = false;
                            }

                            //Finding Type
                            if (string.IsNullOrEmpty(ucFinding.cmbFindingType.Text))
                            {
                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Empty Finding Type -" + (i + 1);
                                blStatus = false;
                            }

                            //Reference Compound
                            if (ucFinding.cmbFindingRefCompound.Enabled && string.IsNullOrEmpty(ucFinding.cmbFindingRefCompound.Text))
                            {
                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Empty Reference Compouns -" + (i + 1);
                                blStatus = false;
                            }
                        }
                    }

                    //Validate duplicate findings
                    List<string> lstNonDuplicateTypes = new List<string>();
                    List<string> lstDuplicateTypes = new List<string>();
                    for (int i = 0; i < flPnlRxnFindings.Controls.Count; i++)
                    {
                        ucFinding = flPnlRxnFindings.Controls[i] as ucRxnFinding;
                        if (ucHrtb != null)
                        {
                            if (!string.IsNullOrEmpty(ucFinding.cmbFindingType.Text) && !string.IsNullOrEmpty(ucFinding.cmbFindingRefCompound.Text))
                            {
                                if (!lstNonDuplicateTypes.Contains(ucFinding.cmbFindingType.Text + "-" + ucFinding.cmbFindingRefCompound.Text))
                                {
                                    lstNonDuplicateTypes.Add(ucFinding.cmbFindingType.Text + "-" + ucFinding.cmbFindingRefCompound.Text);
                                }
                                else
                                {
                                    lstDuplicateTypes.Add(ucFinding.cmbFindingType.Text + "-" + ucFinding.cmbFindingRefCompound.Text);
                                }
                            }
                        }
                    }

                    if (lstDuplicateTypes.Count > 0)
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Duplicate Finding Types -" + string.Join(", ", lstDuplicateTypes.ToArray()); ;
                        blStatus = false;
                    }
                    
                    #region  Validate Other Reaction Finding Types
                    
                    string strErr = "";

                    for (int i = 0; i < flPnlRxnFindings.Controls.Count; i++)
                    {
                        ucFinding = flPnlRxnFindings.Controls[i] as ucRxnFinding;
                        if (ucHrtb != null && !string.IsNullOrEmpty(ucFinding.uchrtbFindingData.hrtbPara.Text.Trim())
                                           && !string.IsNullOrEmpty(ucFinding.cmbFindingType.Text))
                        {
                            if (!ValidateOtherRxnFindingTypes(ucFinding, i, out strErr))
                            {
                                strErrMsg += strErr.Trim() + Environment.NewLine;
                                blStatus = false;
                            }
                        }
                    }

                    #endregion
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsgOut = strErrMsg.Trim();
            return blStatus;
        }

        private bool ValidateRxnProcedureSteps(out string errMsgOut)
        {
            bool blStatus = true;
            string strErrMsg = "";  
            try
            {
                string[] lines = null;
                string[] Sentences = null;
                var RegForSpacePeriod = new System.Text.RegularExpressions.Regex(@"(?<!\d)\.(?!\d)");

                if (!string.IsNullOrEmpty(uchrtbProcSteps.hrtbPara.Text.Trim()))
                {
                    lines = uchrtbProcSteps.hrtbPara.Text.Trim().Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);

                    // New Validation on 26th aug 2015
                    // Sentence should not start with words like 'Afterwards', 'After that' , 'Then' 'Next', 'And'
                    string strErr = "";
                    if (CheckForProcedureTextLinesContainsInValidWords(lines, out strErr))
                    {
                        foreach (string line in lines)
                        {
                            Sentences = Regex.Split(line, @"(?<!\d)\.(?!\d)");

                            if (!CheckForDuplicateSentencesInProcedureTextLine(Sentences, out strErr, Array.IndexOf(lines, line)))
                            {
                                strErrMsg += strErr.Trim() + Environment.NewLine;
                                blStatus = false;
                            }
                        }
                    }
                    else
                    {
                        strErrMsg += strErr.Trim() + Environment.NewLine;
                        blStatus = false;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsgOut = strErrMsg.Trim();
            return blStatus;
        }

        public bool ValidateRxnProcedureAndFindings(out string errMsgOut)
        {
            bool blStatus = true;
            string strErrMsg = "";           
            try
            {
                //Validate Reaction Findings in Panel
                
                string findingErrors = "";
                if (!ValidateRxnFindingValues(out findingErrors))
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + findingErrors;
                    blStatus = false;
                }

                string procStepsErrors = "";
                if (!ValidateRxnProcedureSteps(out procStepsErrors))
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + procStepsErrors;
                    blStatus = false;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsgOut = strErrMsg.Trim();
            return blStatus;
        }

        private bool CheckForDuplicateSentencesInProcedureTextLine(string[] Sentences, out string strErr, int index)
        {
            bool valid = true;
            string errmsg = string.Empty;

            try
            {
                if (Sentences.Count() > 0)
                {
                    var DupSentence = Sentences.GroupBy(x => x)
                                         .Where(g => g.Count() > 1)
                                         .Select(y => y.Key)
                                         .ToList();
                    if (DupSentence.Any())
                    {
                        errmsg = errmsg.Trim() + Environment.NewLine + "Line " + index + 1 + " has duplicate sentence";
                        valid = false;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            strErr = errmsg.Trim();
            return valid;
        }

        private bool CheckForProcedureTextLinesContainsInValidWords(string[] lines, out string strErr)
        {
            bool valid = true;
            string errmsg = string.Empty;
            string[] InvalidWords = new string[] { "Afterwards", "After wards", "After that", "Then", "Next", "And" };

            // Sentence should not start with words like 'Afterwards', 'After that' , 'Then' 'Next', 'And'
            try
            {
                if (lines.Count() > 0)
                {
                    foreach (var line in lines)
                    {
                        foreach (var InvalidWord in InvalidWords)
                        {
                            if (line.ToUpper().StartsWith(InvalidWord.ToUpper()))
                            {
                                errmsg = errmsg.Trim() + Environment.NewLine + "Procedure Steps Line  " + Array.IndexOf(lines, line) + 1 + " Starts With - " + InvalidWord;
                                valid = false;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            strErr = errmsg.Trim();
            return valid;
        }

        private static bool ValidateOtherRxnFindingTypes(ucRxnFinding ucFinding, int i, out  string strErrMsg)
        {
            bool blStatus = true;
            string errMsgOut = string.Empty;

            try
            {
                if (GlobalVariables.FindingTypesData != null)
                {
                    foreach (DataRow Row in GlobalVariables.FindingTypesData.Rows)
                    {
                        if (Row["FINDING_TYPE_NAME"].ToString() != ucFinding.cmbFindingType.Text)
                        {
                            if (ucFinding.uchrtbFindingData.hrtbPara.Text.Trim().Contains(Row["FINDING_TYPE_NAME"].ToString()))
                            {
                                if (Row["FINDING_TYPE_NAME"].ToString() != "m/z" && Row["FINDING_TYPE_NAME"].ToString() != "dec")
                                {
                                    errMsgOut = errMsgOut.Trim() + Environment.NewLine + "Invalid Finding Type present in Finding Value " + (i + 1) + " - " + Row["FINDING_TYPE_NAME"].ToString();
                                    blStatus = false;
                                }

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            strErrMsg = errMsgOut.Trim();
            return blStatus;
        }

        private void CreateParaAndBindToPanel(string cntrlType, string htmlContent)
        {
            try
            {
                ucHtmlRichText ucHrtb = new ucHtmlRichText();
                ucHrtb.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                                | System.Windows.Forms.AnchorStyles.Right)));

                ucHrtb.Height = 100;
                if (!string.IsNullOrEmpty(htmlContent))
                {
                    ucHrtb.BindDataToControl(htmlContent);
                }

                if (cntrlType.ToUpper() == "PARA")
                {
                    ucHrtb.Width = flPnlPara.Width - 28;
                    // Is general typical have single para or Noexp details will have not more than single para.
                    if (rbnNoExpDetails.Checked)
                    {
                        if (flPnlPara.Controls.Count < 1)
                        {
                            flPnlPara.Controls.Add(ucHrtb);
                        }
                    }
                    else
                    {
                        flPnlPara.Controls.Add(ucHrtb);
                    }

                    lblParaCnt.Text = flPnlPara.Controls.Count.ToString();
                }
                else if (cntrlType.ToUpper() == "DATA")
                {
                    ucHrtb.Width = flPnlData.Width - 28;

                    flPnlData.Controls.Add(ucHrtb);
                    lblDataCnt.Text = flPnlData.Controls.Count.ToString();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public void SetPara_Data_ProcSteps_FindingsLabelsCount()
        {
            try
            {
                string procedureHtml = uchrtbProcSteps.GetHtmlStringFromControl();

                lblParaCnt.Text = flPnlPara.Controls.Count.ToString();
                lblDataCnt.Text = flPnlData.Controls.Count.ToString();

                if (!string.IsNullOrEmpty(procedureHtml))
                {
                    string[] saProc = procedureHtml.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
                    lblProcStepCount.Text = saProc != null ? saProc.Length.ToString() : "0";
                }

                lblRxnFindingsCnt.Text = flPnlRxnFindings.Controls.Count.ToString();//dgvRxnFindings.RowCount.ToString();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void lnkData_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                CreateParaAndBindToPanel("DATA", "");
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private int GetActiveControlIndexFromFlowLayoutPanel(FlowLayoutPanel flPanel)
        {
            int cntrlIdx = 0;
            try
            {
                if (flPanel != null && flPanel.Controls.Count > 0)
                {
                    ucHtmlRichText ucHB = null;
                    for (int i = 0; i < flPanel.Controls.Count; i++)
                    {
                        ucHB = flPanel.Controls[i] as ucHtmlRichText;
                        if (ucHB != null)
                        {
                            if (ucHB.hrtbPara.Focused)
                            {
                                cntrlIdx = i;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return cntrlIdx;
        }

        private HtmlRichTextBox GetActiveControlFromFlowLayoutPanel(FlowLayoutPanel flPanel)
        {
            HtmlRichTextBox hrtbActive = null;
            try
            {
                if (flPanel != null && flPanel.Controls.Count > 0)
                {
                    ucHtmlRichText ucHB = null;
                    for (int i = 0; i < flPanel.Controls.Count; i++)
                    {
                        ucHB = flPanel.Controls[i] as ucHtmlRichText;
                        if (ucHB != null)
                        {
                            if (ucHB.hrtbPara.Focused)
                            {
                                hrtbActive = ucHB.hrtbPara;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return hrtbActive;
        }

        private HtmlRichTextBox GetActiveControlFromFindingsFlowLayoutPanel()
        {
            HtmlRichTextBox hrtbActive = null;
            try
            {
                if (flPnlRxnFindings.Controls.Count > 0)
                {
                    ucRxnFinding ucFinding = null;
                    for (int i = 0; i < flPnlRxnFindings.Controls.Count; i++)
                    {
                        ucFinding = flPnlRxnFindings.Controls[i] as ucRxnFinding;
                        if (ucFinding != null)
                        {
                            if (ucFinding.uchrtbFindingData.hrtbPara.Focused)
                            {
                                hrtbActive = ucFinding.uchrtbFindingData.hrtbPara;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return hrtbActive;
        }

        public HtmlRichTextBox GetActiveControl()
        {
            HtmlRichTextBox hrtbActive = null;
            try
            {
                //Text Line
                if (ucHrtbTextLine.hrtbPara.Focused)
                {
                    hrtbActive = ucHrtbTextLine.hrtbPara;
                    return hrtbActive;
                }

                //Para
                hrtbActive = GetActiveControlFromFlowLayoutPanel(flPnlPara);
                if (hrtbActive != null)
                {
                    return hrtbActive;
                }

                //Data
                hrtbActive = GetActiveControlFromFlowLayoutPanel(flPnlData);
                if (hrtbActive != null)
                {
                    return hrtbActive;
                }

                //Yield Text
                if (uchrtbYieldText.hrtbPara.Focused)
                {
                    hrtbActive = uchrtbYieldText.hrtbPara;
                    return hrtbActive;
                }

                //Procedure Steps
                if (uchrtbProcSteps.hrtbPara.Focused)
                {
                    hrtbActive = uchrtbProcSteps.hrtbPara;
                    return hrtbActive;
                }

                //Reaction Findings
                hrtbActive = GetActiveControlFromFindingsFlowLayoutPanel();
                if (hrtbActive != null)
                {
                    return hrtbActive;
                }

                //if (uchrtbDataText.hrtbPara.Focused)
                //{
                //    hrtbActive = uchrtbDataText.hrtbPara;
                //    return hrtbActive;
                //}                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return hrtbActive;
        }

        private void GetCopiedPageSizes()
        {
            try
            {
                if (Clipboard.GetData(DataFormats.Text) != null)
                {
                    string str = Clipboard.GetData(DataFormats.Text).ToString();
                    if (str.Contains("PAGESIZES : "))
                    {
                        char[] c = new char[1] { ':' };
                        string[] strxy = str.Split(c, StringSplitOptions.RemoveEmptyEntries);
                        if (strxy != null)
                        {
                            txtPageSize_Y.Text = strxy[1].Trim();
                            txtPageSize_X.Text = strxy[2].Trim();
                            Clipboard.Clear();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetCopiedPageCoOrdinates()
        {
            try
            {
                if (Clipboard.GetData(DataFormats.Text) != null)
                {
                    string str = Clipboard.GetData(DataFormats.Text).ToString();
                    if (str.Contains("XYOFFSETS : "))
                    {
                        char[] c = new char[1] { ':' };
                        string[] strxy = str.Split(c, StringSplitOptions.RemoveEmptyEntries);
                        if (strxy != null)
                        {
                            txtOffset_X.Text = strxy[1].Trim();
                            txtOffset_Y.Text = strxy[2].Trim();
                            Clipboard.Clear();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtPageSize_X_Click(object sender, EventArgs e)
        {
            try
            {
                GetCopiedPageSizes();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtOffset_X_Click(object sender, EventArgs e)
        {
            try
            {
                GetCopiedPageCoOrdinates();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void flPnlPara_SizeChanged(object sender, EventArgs e)
        {
            try
            {
                if (flPnlPara != null)
                {
                    if (flPnlPara.Controls.Count > 0)
                    {
                        ucHtmlRichText ucHB = null;
                        for (int i = 0; i < flPnlPara.Controls.Count; i++)
                        {
                            ucHB = flPnlPara.Controls[i] as ucHtmlRichText;
                            if (ucHB != null)
                            {
                                ucHB.Width = flPnlPara.Width - 28;
                                //ucHrtb.Height = 100;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void flPnlData_SizeChanged(object sender, EventArgs e)
        {
            try
            {
                if (flPnlData != null)
                {
                    if (flPnlData.Controls.Count > 0)
                    {
                        ucHtmlRichText ucHB = null;
                        for (int i = 0; i < flPnlData.Controls.Count; i++)
                        {
                            ucHB = flPnlData.Controls[i] as ucHtmlRichText;
                            if (ucHB != null)
                            {
                                ucHB.Width = flPnlData.Width - 28;
                                //ucHrtb.Height = 100;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void copyXYOffsetsTSMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtOffset_X.Text.Trim()) && !string.IsNullOrEmpty(txtOffset_Y.Text.Trim()))
                {
                    double xoffset = Convert.ToDouble(txtOffset_X.Text);
                    double yoffset = Convert.ToDouble(txtOffset_Y.Text);

                    if (MessageBox.Show("X offset value '" + xoffset.ToString("0.00") + "',Y Offset value '" + yoffset.ToString("0.00") + "', Do you want to save these values in clipboard?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        Clipboard.Clear();
                        Clipboard.SetData(DataFormats.Text, "XYOFFSETS : " + xoffset.ToString("0.00") + ":" + yoffset.ToString("0.00"));
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnAnalogousTo_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (rbnAnalogousTo.Checked)
                {
                    cmbAnalogousTo.Enabled = true;
                    if (AnalogousRxns != null)
                    {
                        if (AnalogousRxns.Rows.Count > 0)
                        {
                            cmbAnalogousTo.DataSource = AnalogousRxns;
                            cmbAnalogousTo.ValueMember = "RXN_ID";
                            cmbAnalogousTo.DisplayMember = "RXN_NAR_ID";// "RXN_NUM";

                            cmbAnalogousTo.SelectedValue = -1;
                        }
                        else
                        {

                        }
                    }
                }
                else
                {
                    cmbAnalogousTo.Enabled = false;
                    cmbAnalogousTo.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnMissingRxn_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (rbnMissingRxn.Checked)
                {
                    DialogResult diaRes = MessageBox.Show("Do you want to make this reaction as missing reaction ?\r\n If Yes, Textline, Para, Data set to null.", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (diaRes == System.Windows.Forms.DialogResult.Yes)
                    {
                        ucHrtbTextLine.hrtbPara.Clear();
                        flPnlPara.Controls.Clear();
                        flPnlData.Controls.Clear();
                        flPnlRxnFindings.Controls.Clear();
                        txtDocRef.Clear();
                        txtDocRef.Tag = "";
                        txtDocRefFileName.Clear();
                        txtOffset_X.Clear();
                        txtOffset_Y.Clear();
                        txtPageNo.Clear();


                        lblParaCnt.Text = "0";
                        lblDataCnt.Text = "0";
                    }
                    else
                    {
                        rbnExpProcedure.Checked = true;

                    }
                }
                else
                {

                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbtnDeletePara_Click(object sender, EventArgs e)
        {
            try
            {
                if (flPnlPara.Controls.Count > 0)
                {
                    DialogResult diaRes = MessageBox.Show("Do you want to delete the selected Para?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (diaRes == DialogResult.Yes)
                    {
                        int cntrlIndx = GetActiveControlIndexFromFlowLayoutPanel(flPnlPara);

                        if (cntrlIndx >= 0)
                        {
                            flPnlPara.Controls.RemoveAt(cntrlIndx);
                        }

                        if (flPnlPara.Controls.Count >= 1)
                        {
                            flPnlPara.Controls[flPnlPara.Controls.Count - 1].Focus();
                        }
                        lblParaCnt.Text = flPnlPara.Controls.Count.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbtnAddPara_Click(object sender, EventArgs e)
        {
            try
            {
                CreateParaAndBindToPanel("PARA", "");
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbtnAddData_Click(object sender, EventArgs e)
        {
            try
            {
                CreateParaAndBindToPanel("DATA", "");
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbtnDeleteData_Click(object sender, EventArgs e)
        {
            try
            {
                if (flPnlData.Controls.Count > 0)
                {
                    DialogResult diaRes = MessageBox.Show("Do you want to delete the selected Data?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (diaRes == DialogResult.Yes)
                    {
                        int cntrlIndx = GetActiveControlIndexFromFlowLayoutPanel(flPnlData);

                        if (cntrlIndx >= 0)
                        {
                            flPnlData.Controls.RemoveAt(cntrlIndx);
                        }

                        if (flPnlData.Controls.Count >= 1)
                        {
                            flPnlData.Controls[flPnlData.Controls.Count - 1].Focus();
                        }
                        lblDataCnt.Text = flPnlData.Controls.Count.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tcProc_DataText_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (tcProc_DataText.SelectedTab.Name == tpProcedure.Name)
                {
                    BindReferenceParaAndDataValuesToControls("PARA");
                }
                else if (tcProc_DataText.SelectedTab.Name == tpRxnFindings_New.Name)
                {
                    BindReferenceParaAndDataValuesToControls("DATA");
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindReferenceParaAndDataValuesToControls(string controlName)
        {
            try
            {
                if (controlName == "PARA")
                {
                    string strData = GetPara_DataFromControls(controlName);
                    strData = strData.Replace(paraSplitter, "\r\n");

                    uchrtbReferencePara.BindDataToControl(strData);
                    uchrtbReferencePara.hrtbPara.ReadOnly = true;
                    uchrtbReferencePara.hrtbPara.BackColor = Color.AliceBlue;
                }
                else if (controlName == "DATA")
                {
                    string strData = GetPara_DataFromControls(controlName);

                    //string strTemp = GetDataForReactionFindings(strData);

                    strData = strData.Replace(dataSplitter, "\r\n");

                    //uchrtbDataForFindings.BindDataToControl(strData);
                    //uchrtbDataForFindings.hrtbPara.ReadOnly = true;
                    //uchrtbDataForFindings.hrtbPara.BackColor = Color.AliceBlue;

                    uchrtbDataForFindings_New.BindDataToControl(strData);
                    uchrtbDataForFindings_New.hrtbPara.ReadOnly = true;
                    uchrtbDataForFindings_New.hrtbPara.BackColor = Color.AliceBlue;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetDataForReactionFindings(string dataText)
        {
            string strData = "";
            try
            {
                //Get Reaction Product Compounds From Compounds grid
                List<string> lstRxnProds = null;// GetReactionProductCompoundsFromGrid();

                List<string> lstData = dataText.Split(new string[] { dataSplitter }, StringSplitOptions.RemoveEmptyEntries).ToList();

                string strData_Final = string.Empty;
                if (lstRxnProds != null && lstRxnProds.Count > 0 && lstData != null && lstData.Count > 0)
                {
                    if (lstRxnProds.Count == 1 && lstData.Count == 1)
                    {
                        lstData[0] = lstData[0].Insert(0, "<bold>" + lstRxnProds[0].Trim() + "</bold>" + "\r\n");
                    }
                    else
                    {
                        for (int i = 0; i < lstData.Count; i++)
                        {
                            lstData[i] = lstData[i].Insert(0, "<bold>" + lstRxnProds[i].Trim() + "</bold>" + "\r\n");
                        }
                    }

                    strData = string.Join("\r\n", lstData.ToArray());
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strData.Trim();
        }

        private List<string> GetReactionProductCompoundsFromGrid()
        {
            List<string> lstRxnProds = null;
            try
            {
                //if (dgvRxnSubsts_Products.Rows.Count > 0)
                //{
                //    lstRxnProds = new List<string>();

                //    foreach (DataGridViewRow dr in dgvRxnSubsts_Products.Rows)
                //    {
                //        lstRxnProds.Add("Substance: " + dr.Cells[colSubstID.Name].Value.ToString() + " (" + dr.Cells[colSubstRegNo.Name].Value.ToString() + ")");
                //    }
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstRxnProds;
        }

        private void cmbAnalogousTo_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                if (cmbAnalogousTo.SelectedValue != null && rbnAnalogousTo.Checked)
                {
                    if (string.IsNullOrEmpty(uchrtbProcSteps.hrtbPara.Text.Trim()))
                    {
                        int anlogRxnID = Convert.ToInt32(cmbAnalogousTo.SelectedValue);
                        //Get Analogous reaction procedure steps and bind to control
                        DataTable analogRxnData = NarrativesDB.GetReactionDataOnRxnID(anlogRxnID);
                        if (analogRxnData != null && analogRxnData.Rows.Count > 0)
                        {
                            if (!string.IsNullOrEmpty(analogRxnData.Rows[0]["PROCEDURE_TEXT"].ToString()))
                            {
                                uchrtbProcSteps.BindDataToControl(analogRxnData.Rows[0]["PROCEDURE_TEXT"].ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string ReformatFindingsHtmlString(string findingsHtml)
        {
            string reformtHtml = findingsHtml;
            try
            {
                #region Class level code commented
                //const string repl_1H = "~~1H NMR";
                //const string repl_13C = "~~13C NMR";
                //const string repl_29S = "~~29Si NMR";
                //const string repl_31P = "~~31P NMR";
                //const string repl_IR = "~~FT IR";
                //const string repl_HRMS = "~~HRMS";
                //const string repl_MS = "~~ESI-MS";
                //const string repl_MP = "~~MP";
                //const string repl_BP = "~~BP";
                //const string repl_RF = "~~RF";
                //const string repl_EA = "~~Anal. Calcd for";
                //const string repl_UV = "~~UV/vis";
                //const string repl_RT = "~~Rt";
                //const string repl_AD = "~~[α]D";

                ////1H NMR 
                //reformtHtml = reformtHtml.Replace("<sup>1</sup>H NMR", repl_1H);
                //reformtHtml = reformtHtml.Replace("<sup>1</sup>H NMR", repl_1H);
                //reformtHtml = reformtHtml.Replace("<sup>1</sup>H-NMR", repl_1H);
                //reformtHtml = reformtHtml.Replace("1 HNMR", repl_1H);
                //reformtHtml = reformtHtml.Replace("1H-NMR", repl_1H);
                //reformtHtml = reformtHtml.Replace("1HNMR", repl_1H);
                //reformtHtml = reformtHtml.Replace("iHNMR", repl_1H);
                //reformtHtml = reformtHtml.Replace("δH", repl_1H);
                //reformtHtml = reformtHtml.Replace("δ<sub>H</sub>", repl_1H);
                //reformtHtml = reformtHtml.Replace(". NMR", repl_1H);

                ////11B NMR
                //reformtHtml = reformtHtml.Replace("<sup>11</sup>B NMR", "11B NMR");
                //reformtHtml = reformtHtml.Replace("11BNMR", "11B NMR");

                ////13C NMR
                //reformtHtml = reformtHtml.Replace("<sup>13</sup>C NMR", repl_13C);
                //reformtHtml = reformtHtml.Replace("<sup>13</sup>CNMR", repl_13C); 
                //reformtHtml = reformtHtml.Replace("δ<sub>C</sub>", repl_13C);
                //reformtHtml = reformtHtml.Replace("δC", repl_13C);

                ////15N NMR
                //reformtHtml = reformtHtml.Replace("<sup>15</sup>N NMR", "15N NMR");
                //reformtHtml = reformtHtml.Replace("15NNMR", "15N NMR"); 

                ////19F NMR
                //reformtHtml = reformtHtml.Replace("<sup>19</sup>F NMR", "19F NMR");
                //reformtHtml = reformtHtml.Replace("19FNMR", "19F NMR");

                ////29Si NMR
                //reformtHtml = reformtHtml.Replace("29Si NMR", repl_29S);
                //reformtHtml = reformtHtml.Replace("29 Si NMR", repl_29S);
                //reformtHtml = reformtHtml.Replace("29Si MASS NMR", repl_29S);

                ////31P NMR
                //reformtHtml = reformtHtml.Replace("<sup>31</sup>P NMR", repl_31P);
                //reformtHtml = reformtHtml.Replace("31P-NMR", repl_31P);
                //reformtHtml = reformtHtml.Replace("31PNMR", repl_31P);
                //reformtHtml = reformtHtml.Replace("δP", repl_31P);
                //reformtHtml = reformtHtml.Replace("δ<sub>P</sub>", repl_31P);

                ////IR
                //reformtHtml = reformtHtml.Replace("FT IR", repl_IR);
                //reformtHtml = reformtHtml.Replace("IR (cm<sup>-1</sup>):", repl_IR);
                //reformtHtml = reformtHtml.Replace("v<sub>max</sub>", repl_IR);
                //reformtHtml = reformtHtml.Replace("&#957;<sub>max</sub>", repl_IR);

                ////HRMS
                //reformtHtml = reformtHtml.Replace("ESI HRMS", repl_HRMS);
                //reformtHtml = reformtHtml.Replace("HRMS-ESI", repl_HRMS);
                //reformtHtml = reformtHtml.Replace("HR MS", repl_HRMS);
                //reformtHtml = reformtHtml.Replace("HRESIMS", repl_HRMS);
                //reformtHtml = reformtHtml.Replace("HRMS (CI, NH3)", repl_HRMS);
                //reformtHtml = reformtHtml.Replace("HRMS (DART+)", repl_HRMS);
                //reformtHtml = reformtHtml.Replace("HRMS (EI)", repl_HRMS);
                //reformtHtml = reformtHtml.Replace("HRMS (EIMS)", repl_HRMS);
                //reformtHtml = reformtHtml.Replace("HRMS (ESI)", repl_HRMS);
                //reformtHtml = reformtHtml.Replace("HRMS (ESI-TOF)", repl_HRMS);
                //reformtHtml = reformtHtml.Replace("HRMS (FAB)", repl_HRMS);
                //reformtHtml = reformtHtml.Replace("HRMS (FAB+)", repl_HRMS);
                //reformtHtml = reformtHtml.Replace("HRMS FI", repl_HRMS);
                //reformtHtml = reformtHtml.Replace("HRMS MALDI TOF", repl_HRMS);
                //reformtHtml = reformtHtml.Replace("HRMS-MALDI", repl_HRMS);
                //reformtHtml = reformtHtml.Replace("HRMS MALDI TOF", repl_HRMS);
                //reformtHtml = reformtHtml.Replace("HRMS", repl_HRMS);

                ////MS
                //reformtHtml = reformtHtml.Replace("ESI-MS", repl_MS);
                //reformtHtml = reformtHtml.Replace("MS-ESI", repl_MS);

                ////MP
                //reformtHtml = reformtHtml.Replace("MP", repl_MP);
                //reformtHtml = reformtHtml.Replace("M.P.", repl_MP);
                //reformtHtml = reformtHtml.Replace("Mp", repl_MP);
                //reformtHtml = reformtHtml.Replace("m.p.", repl_MP);
                ////reformtHtml = reformtHtml.Replace("mp", repl_MP);
                //reformtHtml = reformtHtml.Replace("mp.", repl_MP);

                ////Boiling Point
                ////reformtHtml = reformtHtml.Replace("bp", repl_BP);
                //reformtHtml = reformtHtml.Replace("b.p", repl_BP);
                //reformtHtml = reformtHtml.Replace("B.P.", repl_BP);
                //reformtHtml = reformtHtml.Replace("Boiling point", repl_BP);
                //reformtHtml = reformtHtml.Replace("BP", repl_BP);
                //reformtHtml = reformtHtml.Replace("bp.", repl_BP);

                ////RF
                //reformtHtml = reformtHtml.Replace("R<sub>f</sub>", repl_RF);
                //reformtHtml = reformtHtml.Replace("Rf", repl_RF);
                //reformtHtml = reformtHtml.Replace("Rf=", repl_RF);

                ////Elemental Analysis
                //reformtHtml = reformtHtml.Replace("elemental Anal. Calcd (%) for", repl_EA);
                //reformtHtml = reformtHtml.Replace("Anal. Calc, for", repl_EA);
                //reformtHtml = reformtHtml.Replace("Anal, calcd. (%) for", repl_EA);
                //reformtHtml = reformtHtml.Replace("Anal Calcd for", repl_EA);
                //reformtHtml = reformtHtml.Replace("Anal.Calcd for", repl_EA);
                //reformtHtml = reformtHtml.Replace("Anal. calc, for", repl_EA);
                //reformtHtml = reformtHtml.Replace("Elemental analysis calculated (%) for", repl_EA);

                ////Crystal Data
                //reformtHtml = reformtHtml.Replace("Crystal data of", "Crystal Data");

                ////m/z
                //reformtHtml = reformtHtml.Replace("<ital>m/z</ital>(ESI)", "M/Z");
                //reformtHtml = reformtHtml.Replace("EI (+) MS <ital>m/z</ital> =", "M/Z");

                ////U/V
                //reformtHtml = reformtHtml.Replace(". UV/vis:", repl_UV);
                //reformtHtml = reformtHtml.Replace("UV/vis=", repl_UV);
                //reformtHtml = reformtHtml.Replace("UV/vis;", repl_UV);
                //reformtHtml = reformtHtml.Replace("UV-vis (CHCl3)", repl_UV);

                ////[a]D
                //reformtHtml = reformtHtml.Replace(".[α]D20", repl_AD);
                //reformtHtml = reformtHtml.Replace(".[α]D22", repl_AD);
                //reformtHtml = reformtHtml.Replace(".[α]D23", repl_AD);
                //reformtHtml = reformtHtml.Replace(".[α]D24", repl_AD);
                //reformtHtml = reformtHtml.Replace(".[α]D25", repl_AD);

                ////Rt (Reaction Time)
                //reformtHtml = reformtHtml.Replace(". reaction time", repl_RT);
                //reformtHtml = reformtHtml.Replace(". Rt:", repl_RT);
                //reformtHtml = reformtHtml.Replace(". Rt=", repl_RT);                
                #endregion

                GlobalVariables.FindingTypeReplData = NarrativesDB.GetFindingTypeReplacements();
                if (GlobalVariables.FindingTypeReplData != null)
                {
                    foreach (DataRow dr in GlobalVariables.FindingTypeReplData.Rows)
                    {
                        reformtHtml = reformtHtml.Replace(dr["ARTICLE_VALUE"].ToString(), dr["REPLACEMENT_VALUE"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return reformtHtml;
        }

        private void AddFindingToRxnFindings(string findingType, string findingValue, string refSubstance)
        {
            try
            {
                if (RxnFindingsData == null)
                {
                    RxnFindingsData = new DataTable();
                    RxnFindingsData.Columns.Add("FINDING_TYPE");
                    RxnFindingsData.Columns.Add("REFERENCE_SUBSTANCE");
                    RxnFindingsData.Columns.Add("FINDING_VALUE");
                    RxnFindingsData.Columns.Add("FINDING_VALUE_RTF");
                    RxnFindingsData.Columns.Add("RF_ID");
                }

                DataRow dRow = RxnFindingsData.NewRow();

                dRow["FINDING_TYPE"] = findingType;
                dRow["REFERENCE_SUBSTANCE"] = refSubstance;
                dRow["FINDING_VALUE"] = findingValue;
                dRow["FINDING_VALUE_RTF"] = Html_RtfConversions.Instance.GetRTFfromHTMLString(findingValue, false);
                dRow["RF_ID"] = 0;
                RxnFindingsData.Rows.Add(dRow);

                ////--------------------------------------------------------------------------
                //DataRow dRow = RxnFindingsData.NewRow();
                //dRow["FINDING_TYPE"] = findingType;
                //dRow["REFERENCE_SUBSTANCE"] = refSubstance;
                //dRow["FINDING_VALUE"] = findingValue;
                //dRow["RF_ID"] = 0;
                //RxnFindingsData.Rows.Add(dRow);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnHelpFindings_Click(object sender, EventArgs e)
        {
            try
            {
                using (IndxReactNarr.Curation.ExperimentalProcedures.frmFindingsMaster fndMaster = new Curation.ExperimentalProcedures.frmFindingsMaster())
                {
                    fndMaster.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbAddFinding_Click(object sender, EventArgs e)
        {
            try
            {
                AddNewReactionFinding();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void AddNewReactionFinding()
        {
            try
            {
                DataTable rxnProdSubsts = null;
                if (dtRxnSubstances != null && dtRxnSubstances.Rows.Count > 0)
                {
                    var prodRows = dtRxnSubstances.AsEnumerable()
                                            .Where(r => r.Field<string>("SUBST_ROLE") == "product");
                    rxnProdSubsts = prodRows.Any() ? prodRows.CopyToDataTable() : dtRxnSubstances.Clone();
                }
                ucRxnFinding ucrxnFind = new ucRxnFinding();
                ucrxnFind.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                                | System.Windows.Forms.AnchorStyles.Right)));

                ucrxnFind.Height = 60;
                ucrxnFind.Width = flPnlRxnFindings.Width - 28;
                ucrxnFind.RxnSubstances = rxnProdSubsts;
                ucrxnFind.BindFindingTypesAndSubstancesToControls();

                flPnlRxnFindings.Controls.Add(ucrxnFind);

                lblRxnFindingsCnt.Text = flPnlRxnFindings.Controls.Count.ToString();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbDeleteFinding_Click(object sender, EventArgs e)
        {
            try
            {
                if (flPnlRxnFindings.Controls.Count > 0)
                {
                    //Get Selected Findings count
                    List<int> selFindings = GetSeletedFindingsList();
                    if (selFindings != null && selFindings.Count > 0)
                    {
                        DialogResult diaRes = MessageBox.Show("Do you want to delete selected Findings?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (diaRes == DialogResult.Yes)
                        {
                            int selFindingsCnt = selFindings.Count;
                            // int cntr = 0;

                            ucRxnFinding rxnFinding = null;
                            int cntr = flPnlRxnFindings.Controls.Count - 1;
                            while (selFindingsCnt > 0)
                            {
                                rxnFinding = flPnlRxnFindings.Controls[cntr] as ucRxnFinding;
                                if (rxnFinding.chkDeleteFlag.Checked)
                                {
                                    flPnlPara.Controls.Remove(rxnFinding);
                                    rxnFinding.Dispose();

                                    selFindingsCnt--;
                                }
                                cntr--;
                            }

                            //int cntrlIndx = GetActiveControlIndexFromFindingsFlowLayoutPanel();
                            //if (cntrlIndx >= 0)
                            //{
                            //    flPnlRxnFindings.Controls.RemoveAt(cntrlIndx);
                            //}

                            //if (flPnlRxnFindings.Controls.Count >= 1)
                            //{
                            //    flPnlRxnFindings.Controls[flPnlRxnFindings.Controls.Count - 1].Focus();
                            //}
                            lblRxnFindingsCnt.Text = flPnlRxnFindings.Controls.Count.ToString();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Findings are not selected", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private List<int> GetSeletedFindingsList()
        {
            List<int> selFindingsList = null;
            try
            {
                if (flPnlRxnFindings.Controls.Count > 0)
                {
                    selFindingsList = new List<int>();

                    ucRxnFinding ucFinding = null;
                    for (int i = 0; i < flPnlRxnFindings.Controls.Count; i++)
                    {
                        ucFinding = flPnlRxnFindings.Controls[i] as ucRxnFinding;
                        if (ucFinding != null)
                        {
                            if (ucFinding.chkDeleteFlag.Checked)
                            {
                                selFindingsList.Add(i);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return selFindingsList;
        }

        private int GetActiveControlIndexFromFindingsFlowLayoutPanel()
        {
            int cntrlIdx = -1;
            try
            {
                if (flPnlRxnFindings != null && flPnlRxnFindings.Controls.Count > 0)
                {
                    ucRxnFinding ucFinding = null;
                    for (int i = 0; i < flPnlRxnFindings.Controls.Count; i++)
                    {
                        ucFinding = flPnlRxnFindings.Controls[i] as ucRxnFinding;
                        if (ucFinding != null)
                        {
                            if (ucFinding.uchrtbFindingData.hrtbPara.Focused)
                            {
                                cntrlIdx = i;
                            }
                            else if (ucFinding.cmbFindingType.Focused)
                            {
                                cntrlIdx = i;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return cntrlIdx;
        }

        private void BindReactionFindingsDataToControls(DataTable rxnFindingsData)
        {
            try
            {
                if (rxnFindingsData != null && rxnFindingsData.Rows.Count > 0)
                {
                    DataTable rxnProdSubsts = null;
                    if (dtRxnSubstances != null && dtRxnSubstances.Rows.Count > 0)
                    {
                        var prodRows = dtRxnSubstances.AsEnumerable()
                                                .Where(r => r.Field<string>("SUBST_ROLE") == "product");
                        rxnProdSubsts = prodRows.Any() ? prodRows.CopyToDataTable() : dtRxnSubstances.Clone();
                    }

                    //flPnlRxnFindings.Controls.Clear();                    
                    foreach (DataRow dr in rxnFindingsData.Rows)
                    {
                        ucRxnFinding ucrxnFind = new ucRxnFinding();
                        ucrxnFind.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                                        | System.Windows.Forms.AnchorStyles.Right)));

                        ucrxnFind.Height = 60;
                        ucrxnFind.Width = flPnlRxnFindings.Width - 28;
                        ucrxnFind.RxnSubstances = rxnProdSubsts;
                        ucrxnFind.FindingValue = dr["FINDING_VALUE"].ToString();
                        ucrxnFind.SeltdFindingType = dr["FINDING_TYPE"].ToString();
                        ucrxnFind.FindingTypeRefSubst = dr["REFERENCE_SUBSTANCE"].ToString();
                        ucrxnFind.BindFindingTypesAndSubstancesToControls();

                        flPnlRxnFindings.Controls.Add(ucrxnFind);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void flPnlRxnFindings_SizeChanged(object sender, EventArgs e)
        {
            try
            {
                if (flPnlRxnFindings != null && flPnlRxnFindings.Controls.Count > 0)
                {
                    for (int i = 0; i < flPnlRxnFindings.Controls.Count; i++)
                    {
                        flPnlRxnFindings.Controls[i].Width = flPnlRxnFindings.Width - 28;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnAutoFindingsNew_Click(object sender, EventArgs e)
        {
            try
            {
                #region Code commented
                //if (!string.IsNullOrEmpty(uchrtbDataForFindings_New.hrtbPara.Text.Trim()))
                //{
                //    string rtfData = Html_RtfConversions.Instance.GetFormattedRtfFromRtf(uchrtbDataForFindings_New.hrtbPara.Rtf, true);
                //    //rtfData = rtfData.Replace(";", "~~");

                //    string html = Html_RtfConversions.Instance.GetHTMLFromRTFString(rtfData);

                //    //Reformat Html
                //    html = ReformatFindingsHtmlString(html);

                //    string[] saFindings = html.Split(new string[] { "~~" }, StringSplitOptions.RemoveEmptyEntries);
                //    if (saFindings != null && saFindings.Length > 0)
                //    {
                //        string refSubstance = "";
                //        string findingType = "";
                //        string findingValue = "";

                //        //if (dgvRxnSubsts_Products.Rows.Count == 1)
                //        //{
                //        //    refSubstance = dgvRxnSubsts_Products.SelectedRows[0].Cells[colSubstID.Name].Value.ToString();
                //        //}

                //        for (int i = 0; i < saFindings.Length; i++)
                //        {
                //            findingType = "";
                //            findingValue = "";

                //            findingValue = saFindings[i].Trim();

                //            if (findingValue.Trim().StartsWith("<sup>1</sup>H NMR") || findingValue.Trim().StartsWith("NMR"))//1H NMR 
                //            {
                //                findingValue = findingValue.Replace("<sup>1</sup>H NMR", "").Trim();
                //                findingType = "1H NMR";
                //            }
                //            else if (findingValue.Trim().StartsWith("<sup>13</sup>C NMR") || findingValue.Trim().StartsWith("<sup>13</sup>CNMR"))
                //            {
                //                findingValue = findingValue.Replace("<sup>13</sup>C NMR", "").Replace("<sup>13</sup>CNMR", "").Trim();
                //                findingType = "13C NMR";
                //            }
                //            else if (findingValue.Trim().StartsWith("IR"))
                //            {
                //                findingValue = findingValue.Replace("IR", "").Replace("FT IR", "").Replace("IR (cm<sup>-1</sup>):", "").Trim();
                //                findingType = "IR";
                //            }
                //            else if (findingValue.Trim().StartsWith("ESI HRMS") || findingValue.Trim().StartsWith("HRMS") || findingValue.Trim().StartsWith("HRMS-ESI"))//HRMS
                //            {
                //                findingValue = findingValue.Replace("ESI HRMS", "").Replace("HRMS", "").Replace("HRMS-ESI", "").Trim();
                //                findingType = "HRMS";
                //            }
                //            else if (findingValue.Trim().StartsWith("[&#945;]"))
                //            {
                //                findingType = "[a]D";
                //            }
                //            else if (findingValue.Trim().StartsWith("mp") || findingValue.Trim().StartsWith("MP"))
                //            {
                //                findingValue = findingValue.Replace("mp", "").Replace("MP", "").Trim();
                //                findingType = "MP";
                //            }
                //            else if (findingValue.Trim().StartsWith("m/z"))
                //            {
                //                findingType = "m/z";
                //            }
                //            else if (findingValue.Trim().StartsWith("Anal. Calcd for"))
                //            {
                //                findingValue = findingValue.Replace("Anal. Calcd for", "").Trim();
                //                findingType = "elemental analysis";
                //            }
                //            else if (findingValue.Trim().StartsWith("Rf "))
                //            {
                //                findingValue = findingValue.Replace("Rf", "").Trim();
                //                findingType = "Rf";
                //            }
                //            //Add finding to Reaction findings
                //            if (!string.IsNullOrEmpty(findingType))
                //            {
                //                AddFindingToRxnFindings(findingType, findingValue, refSubstance);
                //            }
                //        }
                //    }
                //} 
                #endregion

                RxnFindingsData = null;

                GetReactionAutoFindingsFromData();

                if (RxnFindingsData != null)
                {
                    using (frmAutoFindings_Test frmAutoFind = new frmAutoFindings_Test())
                    {
                        frmAutoFind.RxnAutoFindings = RxnFindingsData;
                        frmAutoFind.ShowDialog();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetReactionAutoFindingsFromData()
        {
            try
            {
                if (!string.IsNullOrEmpty(uchrtbDataForFindings_New.hrtbPara.Text.Trim()))
                {
                    string rtfData = Html_RtfConversions.Instance.GetFormattedRtfFromRtf(uchrtbDataForFindings_New.hrtbPara.Rtf, true);
                    //rtfData = rtfData.Replace(";", "~~");

                    string html = Html_RtfConversions.Instance.GetHTMLFromRTFString(rtfData);

                    //Reformat Html
                    html = ReformatFindingsHtmlString(html);

                    string[] saFindings = html.Split(new string[] { "~~" }, StringSplitOptions.RemoveEmptyEntries);
                    if (saFindings != null && saFindings.Length > 0)
                    {
                        string refSubstance = "";
                        string findingType = "";
                        string findingValue = "";

                        //if (dgvRxnSubsts_Products.Rows.Count == 1)
                        //{
                        //    refSubstance = dgvRxnSubsts_Products.SelectedRows[0].Cells[colSubstID.Name].Value.ToString();
                        //}

                        refSubstance = SelectedCompound;

                        for (int i = 0; i < saFindings.Length; i++)
                        {
                            findingType = "";
                            findingValue = "";

                            findingValue = saFindings[i].Trim();

                            if (findingValue.Trim().StartsWith("1H NMR"))
                            {
                                findingValue = findingValue.Replace("1H NMR", "");
                                findingType = "1H NMR";
                            }
                            else if (findingValue.Trim().StartsWith("11B NMR"))
                            {
                                findingValue = findingValue.Replace("11B NMR", "");
                                findingType = "11B NMR";
                            }
                            else if (findingValue.Trim().StartsWith("13C NMR"))
                            {
                                findingValue = findingValue.Replace("13C NMR", "");
                                findingType = "13C NMR";
                            }
                            else if (findingValue.Trim().StartsWith("15N NMR"))
                            {
                                findingValue = findingValue.Replace("15N NMR", "");
                                findingType = "15N NMR";
                            }
                            else if (findingValue.Trim().StartsWith("19F NMR"))
                            {
                                findingValue = findingValue.Replace("19F NMR", "");
                                findingType = "19F NMR";
                            }
                            else if (findingValue.Trim().StartsWith("29SI NMR"))
                            {
                                findingValue = findingValue.Replace("29SI NMR", "");
                                findingType = "29SI NMR";
                            }
                            else if (findingValue.Trim().StartsWith("31P NMR"))
                            {
                                findingValue = findingValue.Replace("31P NMR", "");
                                findingType = "31P NMR";
                            }
                            else if (findingValue.Trim().StartsWith("FT IR"))
                            {
                                findingValue = findingValue.Replace("FT IR", "");
                                findingType = "IR";
                            }
                            else if (findingValue.Trim().StartsWith("HRMS"))
                            {
                                findingValue = findingValue.Replace("HRMS", "");
                                findingType = "HRMS";
                            }
                            else if (findingValue.Trim().StartsWith("ESI-MS"))
                            {
                                findingValue = findingValue.Replace("ESI-MS", "");
                                findingType = "ESI-MS";
                            }
                            else if (findingValue.Trim().StartsWith("[a]D") || findingValue.Trim().StartsWith("[&#945;]"))
                            {
                                findingType = "[a]D";
                            }
                            else if (findingValue.Trim().StartsWith("MP"))
                            {
                                findingValue = findingValue.Replace("MP", "");
                                findingType = "MP";
                            }
                            else if (findingValue.Trim().StartsWith("BP"))
                            {
                                findingValue = findingValue.Replace("BP", "");
                                findingType = "BP";
                            }
                            else if (findingValue.Trim().StartsWith("M/Z"))
                            {
                                findingType = "m/z";
                            }
                            else if (findingValue.Trim().StartsWith("Anal. Calcd for"))
                            {
                                findingValue = findingValue.Replace("Anal. Calcd for", "");
                                findingType = "elemental analysis";
                            }
                            else if (findingValue.Trim().StartsWith("RF"))
                            {
                                findingValue = findingValue.Replace("RF", "");
                                findingType = "Rf";
                            }
                            else if (findingValue.Trim().StartsWith("RT"))
                            {
                                findingValue = findingValue.Replace("RT", "");
                                findingType = "Rt";
                            }
                            else if (findingValue.Trim().StartsWith("UV/vis"))
                            {
                                findingValue = findingValue.Replace("UV/vis", "");
                                findingType = "UV/vis";
                            }

                            //Add finding to Reaction findings
                            if (!string.IsNullOrEmpty(findingType))
                            {
                                AddFindingToRxnFindings(findingType, findingValue.Trim(), refSubstance);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void chkEmptyPgLabel_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (chkEmptyPgLabel.Checked == true)
                {
                    txtPageLabel.Clear();
                    lblpglabel.Enabled = false;
                    txtPageLabel.Enabled = false;
                }
                else 
                {
                    txtPageLabel.Clear();
                    lblpglabel.Enabled = true;
                    txtPageLabel.Enabled = true;
                
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }

        }
    }
}