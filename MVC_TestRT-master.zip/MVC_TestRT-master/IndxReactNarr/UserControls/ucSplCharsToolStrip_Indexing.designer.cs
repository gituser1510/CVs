﻿namespace IndxReactNarr.UserControls
{
    partial class ucSplCharsToolStrip_Indexing
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucSplCharsToolStrip_Indexing));
            this.tsSpecialChars = new System.Windows.Forms.ToolStrip();
            this.tsbAlpha = new System.Windows.Forms.ToolStripButton();
            this.tsbBeta = new System.Windows.Forms.ToolStripButton();
            this.tsbGamma = new System.Windows.Forms.ToolStripButton();
            this.tsbDelta = new System.Windows.Forms.ToolStripButton();
            this.tsbEpsilon = new System.Windows.Forms.ToolStripButton();
            this.tsbZeta = new System.Windows.Forms.ToolStripButton();
            this.tsbEta = new System.Windows.Forms.ToolStripButton();
            this.tsbTheta = new System.Windows.Forms.ToolStripButton();
            this.tsbIota = new System.Windows.Forms.ToolStripButton();
            this.tsbKappa = new System.Windows.Forms.ToolStripButton();
            this.tsbLamda = new System.Windows.Forms.ToolStripButton();
            this.tsbMu = new System.Windows.Forms.ToolStripButton();
            this.tsbNu = new System.Windows.Forms.ToolStripButton();
            this.tsbXi = new System.Windows.Forms.ToolStripButton();
            this.tsbOmicron = new System.Windows.Forms.ToolStripButton();
            this.tsbPi = new System.Windows.Forms.ToolStripButton();
            this.tsbRho = new System.Windows.Forms.ToolStripButton();
            this.tsbSigma = new System.Windows.Forms.ToolStripButton();
            this.tsbTau = new System.Windows.Forms.ToolStripButton();
            this.tsupsilon = new System.Windows.Forms.ToolStripButton();
            this.tsbPhi = new System.Windows.Forms.ToolStripButton();
            this.tsbChi = new System.Windows.Forms.ToolStripButton();
            this.tsbPsi = new System.Windows.Forms.ToolStripButton();
            this.tsbOmega = new System.Windows.Forms.ToolStripButton();
            this.tsbDegree = new System.Windows.Forms.ToolStripButton();
            this.tsbApprox = new System.Windows.Forms.ToolStripButton();
            this.tsbPlusMinus = new System.Windows.Forms.ToolStripButton();
            this.tsbDot = new System.Windows.Forms.ToolStripButton();
            this.tsbLessThanEqual = new System.Windows.Forms.ToolStripButton();
            this.tsbGreaterthanEqual = new System.Windows.Forms.ToolStripButton();
            this.tsbAmstagon = new System.Windows.Forms.ToolStripButton();
            this.tsbDegrees = new System.Windows.Forms.ToolStripButton();
            this.ts1triplebond = new System.Windows.Forms.ToolStripButton();
            this.tsbGreaterThan = new System.Windows.Forms.ToolStripButton();
            this.tsbLessThan = new System.Windows.Forms.ToolStripButton();
            this.tsbLeftRightArrow = new System.Windows.Forms.ToolStripButton();
            this.tsbLeftRightDoubleArrow = new System.Windows.Forms.ToolStripButton();
            this.tsbEqualTo = new System.Windows.Forms.ToolStripButton();
            this.tsbNotEqualTo = new System.Windows.Forms.ToolStripButton();
            this.tsbLeftArrow = new System.Windows.Forms.ToolStripButton();
            this.tsbRightArrow = new System.Windows.Forms.ToolStripButton();
            this.tsbSquareRoot = new System.Windows.Forms.ToolStripButton();
            this.tsbInfinite = new System.Windows.Forms.ToolStripButton();
            this.tsbRegister = new System.Windows.Forms.ToolStripButton();
            this.tsbCopyRight = new System.Windows.Forms.ToolStripButton();
            this.tsbYen = new System.Windows.Forms.ToolStripButton();
            this.tsbPipe = new System.Windows.Forms.ToolStripButton();
            this.tsFontStyles = new System.Windows.Forms.ToolStrip();
            this.tsbBold = new System.Windows.Forms.ToolStripButton();
            this.tsbUnderline = new System.Windows.Forms.ToolStripButton();
            this.tsbItalic = new System.Windows.Forms.ToolStripButton();
            this.tsbStrikeout = new System.Windows.Forms.ToolStripButton();
            this.tsCaseChange = new System.Windows.Forms.ToolStripButton();
            this.tsbRegular = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbSuperscript = new System.Windows.Forms.ToolStripButton();
            this.tsbSubscript = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbSmallCaps = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbUndo = new System.Windows.Forms.ToolStripButton();
            this.tsbRedo = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbConvFormula = new System.Windows.Forms.ToolStripButton();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.tsUpperGreek = new System.Windows.Forms.ToolStrip();
            this.tsbAlpha_U = new System.Windows.Forms.ToolStripButton();
            this.tsbBeta_U = new System.Windows.Forms.ToolStripButton();
            this.tsbGamma_U = new System.Windows.Forms.ToolStripButton();
            this.tsbDelta_U = new System.Windows.Forms.ToolStripButton();
            this.tsbEpsilon_U = new System.Windows.Forms.ToolStripButton();
            this.tsbZeta_U = new System.Windows.Forms.ToolStripButton();
            this.tsbEta_U = new System.Windows.Forms.ToolStripButton();
            this.tsbTheta_U = new System.Windows.Forms.ToolStripButton();
            this.tsbIota_U = new System.Windows.Forms.ToolStripButton();
            this.tsbKappa_U = new System.Windows.Forms.ToolStripButton();
            this.tsbLamda_U = new System.Windows.Forms.ToolStripButton();
            this.tsbMu_U = new System.Windows.Forms.ToolStripButton();
            this.tsbNu_U = new System.Windows.Forms.ToolStripButton();
            this.tsbXi_U = new System.Windows.Forms.ToolStripButton();
            this.tsbOmicron_U = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton25 = new System.Windows.Forms.ToolStripButton();
            this.tsbRho_U = new System.Windows.Forms.ToolStripButton();
            this.tsbSigma_U = new System.Windows.Forms.ToolStripButton();
            this.tsbTau_U = new System.Windows.Forms.ToolStripButton();
            this.tsbUpsilon_U = new System.Windows.Forms.ToolStripButton();
            this.tsbPhi_U = new System.Windows.Forms.ToolStripButton();
            this.tsbChi_U = new System.Windows.Forms.ToolStripButton();
            this.tsbPsi_U = new System.Windows.Forms.ToolStripButton();
            this.tsbOmega_U = new System.Windows.Forms.ToolStripButton();
            this.tsSpecialChars.SuspendLayout();
            this.tsFontStyles.SuspendLayout();
            this.tsUpperGreek.SuspendLayout();
            this.SuspendLayout();
            // 
            // tsSpecialChars
            // 
            this.tsSpecialChars.BackColor = System.Drawing.Color.White;
            this.tsSpecialChars.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsSpecialChars.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbAlpha,
            this.tsbBeta,
            this.tsbGamma,
            this.tsbDelta,
            this.tsbEpsilon,
            this.tsbZeta,
            this.tsbEta,
            this.tsbTheta,
            this.tsbIota,
            this.tsbKappa,
            this.tsbLamda,
            this.tsbMu,
            this.tsbNu,
            this.tsbXi,
            this.tsbOmicron,
            this.tsbPi,
            this.tsbRho,
            this.tsbSigma,
            this.tsbTau,
            this.tsupsilon,
            this.tsbPhi,
            this.tsbChi,
            this.tsbPsi,
            this.tsbOmega,
            this.tsbDegree,
            this.tsbApprox,
            this.tsbPlusMinus,
            this.tsbDot,
            this.tsbLessThanEqual,
            this.tsbGreaterthanEqual,
            this.tsbAmstagon,
            this.tsbDegrees,
            this.ts1triplebond,
            this.tsbGreaterThan,
            this.tsbLessThan,
            this.tsbLeftRightArrow,
            this.tsbLeftRightDoubleArrow,
            this.tsbEqualTo,
            this.tsbNotEqualTo,
            this.tsbLeftArrow,
            this.tsbRightArrow,
            this.tsbSquareRoot,
            this.tsbInfinite,
            this.tsbRegister,
            this.tsbCopyRight,
            this.tsbYen});
            this.tsSpecialChars.Location = new System.Drawing.Point(0, 0);
            this.tsSpecialChars.Name = "tsSpecialChars";
            this.tsSpecialChars.Size = new System.Drawing.Size(1156, 25);
            this.tsSpecialChars.TabIndex = 45;
            this.tsSpecialChars.Tag = "XC";
            this.tsSpecialChars.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.tsSpecialChars_ItemClicked);
            // 
            // tsbAlpha
            // 
            this.tsbAlpha.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbAlpha.Image = ((System.Drawing.Image)(resources.GetObject("tsbAlpha.Image")));
            this.tsbAlpha.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAlpha.Name = "tsbAlpha";
            this.tsbAlpha.Size = new System.Drawing.Size(23, 22);
            this.tsbAlpha.Tag = "&#945;";
            this.tsbAlpha.Text = "α";
            this.tsbAlpha.ToolTipText = "alpha";
            // 
            // tsbBeta
            // 
            this.tsbBeta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbBeta.Image = ((System.Drawing.Image)(resources.GetObject("tsbBeta.Image")));
            this.tsbBeta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbBeta.Name = "tsbBeta";
            this.tsbBeta.Size = new System.Drawing.Size(23, 22);
            this.tsbBeta.Tag = "&beta;";
            this.tsbBeta.Text = "β";
            this.tsbBeta.ToolTipText = "beta";
            // 
            // tsbGamma
            // 
            this.tsbGamma.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbGamma.Image = ((System.Drawing.Image)(resources.GetObject("tsbGamma.Image")));
            this.tsbGamma.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbGamma.Name = "tsbGamma";
            this.tsbGamma.Size = new System.Drawing.Size(23, 22);
            this.tsbGamma.Tag = "&#947; ";
            this.tsbGamma.Text = "γ";
            this.tsbGamma.ToolTipText = "gamma";
            // 
            // tsbDelta
            // 
            this.tsbDelta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbDelta.Image = ((System.Drawing.Image)(resources.GetObject("tsbDelta.Image")));
            this.tsbDelta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDelta.Name = "tsbDelta";
            this.tsbDelta.Size = new System.Drawing.Size(23, 22);
            this.tsbDelta.Tag = "&#948;";
            this.tsbDelta.Text = "δ";
            this.tsbDelta.ToolTipText = "delta";
            // 
            // tsbEpsilon
            // 
            this.tsbEpsilon.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbEpsilon.Image = ((System.Drawing.Image)(resources.GetObject("tsbEpsilon.Image")));
            this.tsbEpsilon.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbEpsilon.Name = "tsbEpsilon";
            this.tsbEpsilon.Size = new System.Drawing.Size(23, 22);
            this.tsbEpsilon.Tag = "&#949;";
            this.tsbEpsilon.Text = "ε";
            this.tsbEpsilon.ToolTipText = "epsilon";
            // 
            // tsbZeta
            // 
            this.tsbZeta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbZeta.Image = ((System.Drawing.Image)(resources.GetObject("tsbZeta.Image")));
            this.tsbZeta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbZeta.Name = "tsbZeta";
            this.tsbZeta.Size = new System.Drawing.Size(23, 22);
            this.tsbZeta.Tag = "&#950";
            this.tsbZeta.Text = "ζ";
            this.tsbZeta.ToolTipText = "Zeta";
            // 
            // tsbEta
            // 
            this.tsbEta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbEta.Image = ((System.Drawing.Image)(resources.GetObject("tsbEta.Image")));
            this.tsbEta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbEta.Name = "tsbEta";
            this.tsbEta.Size = new System.Drawing.Size(23, 22);
            this.tsbEta.Tag = "&#951;";
            this.tsbEta.Text = "η";
            this.tsbEta.ToolTipText = "Eta";
            // 
            // tsbTheta
            // 
            this.tsbTheta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbTheta.Image = ((System.Drawing.Image)(resources.GetObject("tsbTheta.Image")));
            this.tsbTheta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbTheta.Name = "tsbTheta";
            this.tsbTheta.Size = new System.Drawing.Size(23, 22);
            this.tsbTheta.Tag = "&#952;";
            this.tsbTheta.Text = "θ";
            this.tsbTheta.ToolTipText = "Theta";
            // 
            // tsbIota
            // 
            this.tsbIota.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbIota.Image = ((System.Drawing.Image)(resources.GetObject("tsbIota.Image")));
            this.tsbIota.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbIota.Name = "tsbIota";
            this.tsbIota.Size = new System.Drawing.Size(23, 22);
            this.tsbIota.Tag = "&#953;";
            this.tsbIota.Text = "ι";
            this.tsbIota.ToolTipText = "Iota";
            // 
            // tsbKappa
            // 
            this.tsbKappa.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbKappa.Image = ((System.Drawing.Image)(resources.GetObject("tsbKappa.Image")));
            this.tsbKappa.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbKappa.Name = "tsbKappa";
            this.tsbKappa.Size = new System.Drawing.Size(23, 22);
            this.tsbKappa.Tag = "&#954;";
            this.tsbKappa.Text = "κ";
            this.tsbKappa.ToolTipText = "Kappa";
            // 
            // tsbLamda
            // 
            this.tsbLamda.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbLamda.Image = ((System.Drawing.Image)(resources.GetObject("tsbLamda.Image")));
            this.tsbLamda.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLamda.Name = "tsbLamda";
            this.tsbLamda.Size = new System.Drawing.Size(23, 22);
            this.tsbLamda.Tag = "&#955;";
            this.tsbLamda.Text = "λ";
            this.tsbLamda.ToolTipText = "Lamda";
            // 
            // tsbMu
            // 
            this.tsbMu.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbMu.Image = ((System.Drawing.Image)(resources.GetObject("tsbMu.Image")));
            this.tsbMu.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbMu.Name = "tsbMu";
            this.tsbMu.Size = new System.Drawing.Size(23, 22);
            this.tsbMu.Tag = "&#956;";
            this.tsbMu.Text = "μ";
            this.tsbMu.ToolTipText = "Mu";
            // 
            // tsbNu
            // 
            this.tsbNu.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbNu.Image = ((System.Drawing.Image)(resources.GetObject("tsbNu.Image")));
            this.tsbNu.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbNu.Name = "tsbNu";
            this.tsbNu.Size = new System.Drawing.Size(23, 22);
            this.tsbNu.Tag = "&#957;";
            this.tsbNu.Text = "ν";
            this.tsbNu.ToolTipText = "Nu";
            // 
            // tsbXi
            // 
            this.tsbXi.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbXi.Image = ((System.Drawing.Image)(resources.GetObject("tsbXi.Image")));
            this.tsbXi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbXi.Name = "tsbXi";
            this.tsbXi.Size = new System.Drawing.Size(23, 22);
            this.tsbXi.Tag = "&#958;";
            this.tsbXi.Text = "ξ";
            this.tsbXi.ToolTipText = "ksi";
            // 
            // tsbOmicron
            // 
            this.tsbOmicron.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbOmicron.Image = ((System.Drawing.Image)(resources.GetObject("tsbOmicron.Image")));
            this.tsbOmicron.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbOmicron.Name = "tsbOmicron";
            this.tsbOmicron.Size = new System.Drawing.Size(23, 22);
            this.tsbOmicron.Tag = "&#959;";
            this.tsbOmicron.Text = "ο";
            this.tsbOmicron.ToolTipText = "omicron";
            // 
            // tsbPi
            // 
            this.tsbPi.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPi.Image = ((System.Drawing.Image)(resources.GetObject("tsbPi.Image")));
            this.tsbPi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPi.Name = "tsbPi";
            this.tsbPi.Size = new System.Drawing.Size(23, 22);
            this.tsbPi.Tag = "&#960;";
            this.tsbPi.Text = "π";
            this.tsbPi.ToolTipText = "Pi";
            // 
            // tsbRho
            // 
            this.tsbRho.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbRho.Image = ((System.Drawing.Image)(resources.GetObject("tsbRho.Image")));
            this.tsbRho.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRho.Name = "tsbRho";
            this.tsbRho.Size = new System.Drawing.Size(23, 22);
            this.tsbRho.Tag = "&#961;";
            this.tsbRho.Text = "ρ";
            this.tsbRho.ToolTipText = "Rho";
            // 
            // tsbSigma
            // 
            this.tsbSigma.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbSigma.Image = ((System.Drawing.Image)(resources.GetObject("tsbSigma.Image")));
            this.tsbSigma.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSigma.Name = "tsbSigma";
            this.tsbSigma.Size = new System.Drawing.Size(23, 22);
            this.tsbSigma.Tag = "&#963;";
            this.tsbSigma.Text = "σ";
            this.tsbSigma.ToolTipText = "sigma";
            // 
            // tsbTau
            // 
            this.tsbTau.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbTau.Image = ((System.Drawing.Image)(resources.GetObject("tsbTau.Image")));
            this.tsbTau.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbTau.Name = "tsbTau";
            this.tsbTau.Size = new System.Drawing.Size(23, 22);
            this.tsbTau.Tag = "&#964;";
            this.tsbTau.Text = "τ";
            this.tsbTau.ToolTipText = "tau";
            // 
            // tsupsilon
            // 
            this.tsupsilon.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsupsilon.Image = ((System.Drawing.Image)(resources.GetObject("tsupsilon.Image")));
            this.tsupsilon.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsupsilon.Name = "tsupsilon";
            this.tsupsilon.Size = new System.Drawing.Size(23, 22);
            this.tsupsilon.Tag = "&#965;";
            this.tsupsilon.Text = "υ";
            this.tsupsilon.ToolTipText = "upsilon";
            // 
            // tsbPhi
            // 
            this.tsbPhi.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPhi.Image = ((System.Drawing.Image)(resources.GetObject("tsbPhi.Image")));
            this.tsbPhi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPhi.Name = "tsbPhi";
            this.tsbPhi.Size = new System.Drawing.Size(23, 22);
            this.tsbPhi.Tag = "&#966;";
            this.tsbPhi.Text = "φ";
            this.tsbPhi.ToolTipText = "phi";
            // 
            // tsbChi
            // 
            this.tsbChi.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbChi.Image = ((System.Drawing.Image)(resources.GetObject("tsbChi.Image")));
            this.tsbChi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbChi.Name = "tsbChi";
            this.tsbChi.Size = new System.Drawing.Size(23, 22);
            this.tsbChi.Tag = "&#967;";
            this.tsbChi.Text = "χ";
            this.tsbChi.ToolTipText = "chi";
            // 
            // tsbPsi
            // 
            this.tsbPsi.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPsi.Image = ((System.Drawing.Image)(resources.GetObject("tsbPsi.Image")));
            this.tsbPsi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPsi.Name = "tsbPsi";
            this.tsbPsi.Size = new System.Drawing.Size(23, 22);
            this.tsbPsi.Tag = "&#936;";
            this.tsbPsi.Text = "ψ";
            this.tsbPsi.ToolTipText = "psi";
            // 
            // tsbOmega
            // 
            this.tsbOmega.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbOmega.Image = ((System.Drawing.Image)(resources.GetObject("tsbOmega.Image")));
            this.tsbOmega.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbOmega.Name = "tsbOmega";
            this.tsbOmega.Size = new System.Drawing.Size(23, 22);
            this.tsbOmega.Tag = "&#969;";
            this.tsbOmega.Text = "ω";
            this.tsbOmega.ToolTipText = "omega";
            // 
            // tsbDegree
            // 
            this.tsbDegree.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbDegree.Image = ((System.Drawing.Image)(resources.GetObject("tsbDegree.Image")));
            this.tsbDegree.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDegree.Name = "tsbDegree";
            this.tsbDegree.Size = new System.Drawing.Size(23, 22);
            this.tsbDegree.Tag = "&#176;";
            this.tsbDegree.Text = "°";
            this.tsbDegree.ToolTipText = "degree";
            // 
            // tsbApprox
            // 
            this.tsbApprox.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbApprox.Image = ((System.Drawing.Image)(resources.GetObject("tsbApprox.Image")));
            this.tsbApprox.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbApprox.Name = "tsbApprox";
            this.tsbApprox.Size = new System.Drawing.Size(23, 22);
            this.tsbApprox.Tag = "&#126;";
            this.tsbApprox.Text = "~";
            // 
            // tsbPlusMinus
            // 
            this.tsbPlusMinus.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPlusMinus.Image = ((System.Drawing.Image)(resources.GetObject("tsbPlusMinus.Image")));
            this.tsbPlusMinus.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPlusMinus.Name = "tsbPlusMinus";
            this.tsbPlusMinus.Size = new System.Drawing.Size(23, 22);
            this.tsbPlusMinus.Tag = "&#177;";
            this.tsbPlusMinus.Text = "±";
            this.tsbPlusMinus.ToolTipText = "Plus or Minus";
            // 
            // tsbDot
            // 
            this.tsbDot.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbDot.Image = ((System.Drawing.Image)(resources.GetObject("tsbDot.Image")));
            this.tsbDot.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDot.Name = "tsbDot";
            this.tsbDot.Size = new System.Drawing.Size(23, 22);
            this.tsbDot.Tag = "&#8226;";
            this.tsbDot.Text = "•";
            this.tsbDot.ToolTipText = "Center Dot";
            // 
            // tsbLessThanEqual
            // 
            this.tsbLessThanEqual.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbLessThanEqual.Image = ((System.Drawing.Image)(resources.GetObject("tsbLessThanEqual.Image")));
            this.tsbLessThanEqual.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLessThanEqual.Name = "tsbLessThanEqual";
            this.tsbLessThanEqual.Size = new System.Drawing.Size(23, 22);
            this.tsbLessThanEqual.Tag = "&#8804;";
            this.tsbLessThanEqual.Text = "≤";
            // 
            // tsbGreaterthanEqual
            // 
            this.tsbGreaterthanEqual.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbGreaterthanEqual.Image = ((System.Drawing.Image)(resources.GetObject("tsbGreaterthanEqual.Image")));
            this.tsbGreaterthanEqual.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbGreaterthanEqual.Name = "tsbGreaterthanEqual";
            this.tsbGreaterthanEqual.Size = new System.Drawing.Size(23, 22);
            this.tsbGreaterthanEqual.Tag = "&#8805;";
            this.tsbGreaterthanEqual.Text = "≥";
            // 
            // tsbAmstagon
            // 
            this.tsbAmstagon.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbAmstagon.Image = ((System.Drawing.Image)(resources.GetObject("tsbAmstagon.Image")));
            this.tsbAmstagon.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAmstagon.Name = "tsbAmstagon";
            this.tsbAmstagon.Size = new System.Drawing.Size(23, 22);
            this.tsbAmstagon.Tag = "&#197; ";
            this.tsbAmstagon.Text = "Å";
            // 
            // tsbDegrees
            // 
            this.tsbDegrees.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbDegrees.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDegrees.Name = "tsbDegrees";
            this.tsbDegrees.Size = new System.Drawing.Size(23, 22);
            this.tsbDegrees.Tag = "&#x2248;";
            this.tsbDegrees.Text = "°";
            this.tsbDegrees.ToolTipText = "Degrees";
            this.tsbDegrees.Visible = false;
            // 
            // ts1triplebond
            // 
            this.ts1triplebond.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ts1triplebond.Font = new System.Drawing.Font("Symbol", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.ts1triplebond.Image = ((System.Drawing.Image)(resources.GetObject("ts1triplebond.Image")));
            this.ts1triplebond.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ts1triplebond.Name = "ts1triplebond";
            this.ts1triplebond.Size = new System.Drawing.Size(23, 22);
            this.ts1triplebond.Tag = "&#8801;";
            this.ts1triplebond.Text = "";
            this.ts1triplebond.ToolTipText = "Triple Bond";
            // 
            // tsbGreaterThan
            // 
            this.tsbGreaterThan.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbGreaterThan.Image = ((System.Drawing.Image)(resources.GetObject("tsbGreaterThan.Image")));
            this.tsbGreaterThan.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbGreaterThan.Name = "tsbGreaterThan";
            this.tsbGreaterThan.Size = new System.Drawing.Size(23, 22);
            this.tsbGreaterThan.Text = "≥";
            this.tsbGreaterThan.ToolTipText = "Greater Than or Equal";
            this.tsbGreaterThan.Visible = false;
            // 
            // tsbLessThan
            // 
            this.tsbLessThan.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsbLessThan.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLessThan.Name = "tsbLessThan";
            this.tsbLessThan.Size = new System.Drawing.Size(23, 22);
            this.tsbLessThan.Text = "≤";
            this.tsbLessThan.ToolTipText = "Less Than or Equal";
            this.tsbLessThan.Visible = false;
            // 
            // tsbLeftRightArrow
            // 
            this.tsbLeftRightArrow.Font = new System.Drawing.Font("Symbol", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.tsbLeftRightArrow.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLeftRightArrow.Name = "tsbLeftRightArrow";
            this.tsbLeftRightArrow.Size = new System.Drawing.Size(26, 22);
            this.tsbLeftRightArrow.Tag = "&#8596;";
            this.tsbLeftRightArrow.Text = "";
            this.tsbLeftRightArrow.ToolTipText = "Left Right Arrow";
            // 
            // tsbLeftRightDoubleArrow
            // 
            this.tsbLeftRightDoubleArrow.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbLeftRightDoubleArrow.Font = new System.Drawing.Font("Symbol", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.tsbLeftRightDoubleArrow.Image = ((System.Drawing.Image)(resources.GetObject("tsbLeftRightDoubleArrow.Image")));
            this.tsbLeftRightDoubleArrow.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLeftRightDoubleArrow.Name = "tsbLeftRightDoubleArrow";
            this.tsbLeftRightDoubleArrow.Size = new System.Drawing.Size(26, 22);
            this.tsbLeftRightDoubleArrow.Tag = "&#8660;";
            this.tsbLeftRightDoubleArrow.Text = "Û";
            // 
            // tsbEqualTo
            // 
            this.tsbEqualTo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbEqualTo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbEqualTo.Name = "tsbEqualTo";
            this.tsbEqualTo.Size = new System.Drawing.Size(23, 22);
            this.tsbEqualTo.Text = "=";
            this.tsbEqualTo.ToolTipText = "Equal To";
            // 
            // tsbNotEqualTo
            // 
            this.tsbNotEqualTo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbNotEqualTo.Name = "tsbNotEqualTo";
            this.tsbNotEqualTo.Size = new System.Drawing.Size(23, 22);
            this.tsbNotEqualTo.Tag = "&#8800;";
            this.tsbNotEqualTo.Text = "≠";
            this.tsbNotEqualTo.ToolTipText = "Not Equal to";
            // 
            // tsbLeftArrow
            // 
            this.tsbLeftArrow.Font = new System.Drawing.Font("Symbol", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.tsbLeftArrow.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLeftArrow.Name = "tsbLeftArrow";
            this.tsbLeftArrow.Size = new System.Drawing.Size(25, 22);
            this.tsbLeftArrow.Tag = "&#8592;";
            this.tsbLeftArrow.Text = "";
            this.tsbLeftArrow.ToolTipText = "Left Arrow";
            // 
            // tsbRightArrow
            // 
            this.tsbRightArrow.Font = new System.Drawing.Font("Symbol", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.tsbRightArrow.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRightArrow.Name = "tsbRightArrow";
            this.tsbRightArrow.Size = new System.Drawing.Size(25, 22);
            this.tsbRightArrow.Tag = "&#8594;";
            this.tsbRightArrow.Text = "";
            this.tsbRightArrow.ToolTipText = "Right Arrow";
            // 
            // tsbSquareRoot
            // 
            this.tsbSquareRoot.Font = new System.Drawing.Font("Symbol", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.tsbSquareRoot.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSquareRoot.Name = "tsbSquareRoot";
            this.tsbSquareRoot.Size = new System.Drawing.Size(23, 22);
            this.tsbSquareRoot.Tag = "&#8730;";
            this.tsbSquareRoot.Text = "Ö";
            this.tsbSquareRoot.ToolTipText = "Square Root";
            // 
            // tsbInfinite
            // 
            this.tsbInfinite.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbInfinite.Image = ((System.Drawing.Image)(resources.GetObject("tsbInfinite.Image")));
            this.tsbInfinite.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbInfinite.Name = "tsbInfinite";
            this.tsbInfinite.Size = new System.Drawing.Size(24, 22);
            this.tsbInfinite.Tag = "&#8734;";
            this.tsbInfinite.Text = "∞";
            // 
            // tsbRegister
            // 
            this.tsbRegister.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbRegister.Image = ((System.Drawing.Image)(resources.GetObject("tsbRegister.Image")));
            this.tsbRegister.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRegister.Name = "tsbRegister";
            this.tsbRegister.Size = new System.Drawing.Size(24, 22);
            this.tsbRegister.Tag = "&#174;";
            this.tsbRegister.Text = "®";
            // 
            // tsbCopyRight
            // 
            this.tsbCopyRight.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbCopyRight.Image = ((System.Drawing.Image)(resources.GetObject("tsbCopyRight.Image")));
            this.tsbCopyRight.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCopyRight.Name = "tsbCopyRight";
            this.tsbCopyRight.Size = new System.Drawing.Size(24, 22);
            this.tsbCopyRight.Tag = "&#169;";
            this.tsbCopyRight.Text = "©";
            // 
            // tsbYen
            // 
            this.tsbYen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbYen.Image = ((System.Drawing.Image)(resources.GetObject("tsbYen.Image")));
            this.tsbYen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbYen.Name = "tsbYen";
            this.tsbYen.Size = new System.Drawing.Size(23, 22);
            this.tsbYen.Tag = "&#165;";
            this.tsbYen.Text = "¥";
            // 
            // tsbPipe
            // 
            this.tsbPipe.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPipe.Image = ((System.Drawing.Image)(resources.GetObject("tsbPipe.Image")));
            this.tsbPipe.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPipe.Name = "tsbPipe";
            this.tsbPipe.Size = new System.Drawing.Size(23, 22);
            this.tsbPipe.Tag = "&#124;";
            this.tsbPipe.Text = "|";
            this.tsbPipe.Visible = false;
            // 
            // tsFontStyles
            // 
            this.tsFontStyles.BackColor = System.Drawing.Color.White;
            this.tsFontStyles.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tsFontStyles.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsFontStyles.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbBold,
            this.tsbUnderline,
            this.tsbItalic,
            this.tsbStrikeout,
            this.tsCaseChange,
            this.tsbRegular,
            this.toolStripSeparator1,
            this.tsbSuperscript,
            this.tsbSubscript,
            this.toolStripSeparator2,
            this.tsbSmallCaps,
            this.toolStripSeparator5,
            this.tsbUndo,
            this.tsbRedo,
            this.toolStripSeparator4,
            this.tsbConvFormula});
            this.tsFontStyles.Location = new System.Drawing.Point(0, 49);
            this.tsFontStyles.Name = "tsFontStyles";
            this.tsFontStyles.Size = new System.Drawing.Size(1156, 25);
            this.tsFontStyles.TabIndex = 46;
            this.tsFontStyles.Tag = "XC";
            // 
            // tsbBold
            // 
            this.tsbBold.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbBold.Image = ((System.Drawing.Image)(resources.GetObject("tsbBold.Image")));
            this.tsbBold.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbBold.Name = "tsbBold";
            this.tsbBold.Size = new System.Drawing.Size(23, 22);
            this.tsbBold.Text = "Bold";
            this.tsbBold.Click += new System.EventHandler(this.tsbBold_Click);
            // 
            // tsbUnderline
            // 
            this.tsbUnderline.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbUnderline.Image = ((System.Drawing.Image)(resources.GetObject("tsbUnderline.Image")));
            this.tsbUnderline.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbUnderline.Name = "tsbUnderline";
            this.tsbUnderline.Size = new System.Drawing.Size(23, 22);
            this.tsbUnderline.Text = "Underline";
            this.tsbUnderline.Click += new System.EventHandler(this.tsbUnderline_Click);
            // 
            // tsbItalic
            // 
            this.tsbItalic.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbItalic.Image = ((System.Drawing.Image)(resources.GetObject("tsbItalic.Image")));
            this.tsbItalic.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbItalic.Name = "tsbItalic";
            this.tsbItalic.Size = new System.Drawing.Size(23, 22);
            this.tsbItalic.Text = "italic";
            this.tsbItalic.Click += new System.EventHandler(this.tsbItalic_Click);
            // 
            // tsbStrikeout
            // 
            this.tsbStrikeout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbStrikeout.Image = ((System.Drawing.Image)(resources.GetObject("tsbStrikeout.Image")));
            this.tsbStrikeout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbStrikeout.Name = "tsbStrikeout";
            this.tsbStrikeout.Size = new System.Drawing.Size(23, 22);
            this.tsbStrikeout.Text = "StrikeOut";
            this.tsbStrikeout.Visible = false;
            // 
            // tsCaseChange
            // 
            this.tsCaseChange.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsCaseChange.Image = global::IndxReactNarr.Properties.Resources.CaseChange;
            this.tsCaseChange.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsCaseChange.Name = "tsCaseChange";
            this.tsCaseChange.Size = new System.Drawing.Size(23, 22);
            this.tsCaseChange.Text = "Case change";
            this.tsCaseChange.Click += new System.EventHandler(this.tsCaseChange_Click);
            // 
            // tsbRegular
            // 
            this.tsbRegular.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbRegular.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsbRegular.Image = ((System.Drawing.Image)(resources.GetObject("tsbRegular.Image")));
            this.tsbRegular.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRegular.Name = "tsbRegular";
            this.tsbRegular.Size = new System.Drawing.Size(23, 22);
            this.tsbRegular.Text = "R";
            this.tsbRegular.ToolTipText = "Regular";
            this.tsbRegular.Click += new System.EventHandler(this.tsbRegular_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            this.toolStripSeparator1.Visible = false;
            // 
            // tsbSuperscript
            // 
            this.tsbSuperscript.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSuperscript.Image = ((System.Drawing.Image)(resources.GetObject("tsbSuperscript.Image")));
            this.tsbSuperscript.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSuperscript.Name = "tsbSuperscript";
            this.tsbSuperscript.Size = new System.Drawing.Size(23, 22);
            this.tsbSuperscript.Text = "Superscript";
            this.tsbSuperscript.Click += new System.EventHandler(this.tsbSuperscript_Click);
            // 
            // tsbSubscript
            // 
            this.tsbSubscript.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSubscript.Image = ((System.Drawing.Image)(resources.GetObject("tsbSubscript.Image")));
            this.tsbSubscript.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSubscript.Name = "tsbSubscript";
            this.tsbSubscript.Size = new System.Drawing.Size(23, 22);
            this.tsbSubscript.Text = "Subscript";
            this.tsbSubscript.Click += new System.EventHandler(this.tsbSubscript_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            this.toolStripSeparator2.Visible = false;
            // 
            // tsbSmallCaps
            // 
            this.tsbSmallCaps.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSmallCaps.Image = ((System.Drawing.Image)(resources.GetObject("tsbSmallCaps.Image")));
            this.tsbSmallCaps.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSmallCaps.Name = "tsbSmallCaps";
            this.tsbSmallCaps.Size = new System.Drawing.Size(23, 22);
            this.tsbSmallCaps.Text = "toolStripButton1";
            this.tsbSmallCaps.ToolTipText = "Small Caps";
            this.tsbSmallCaps.Visible = false;
            this.tsbSmallCaps.Click += new System.EventHandler(this.tsbSmallCaps_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            this.toolStripSeparator5.Visible = false;
            // 
            // tsbUndo
            // 
            this.tsbUndo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbUndo.Image = ((System.Drawing.Image)(resources.GetObject("tsbUndo.Image")));
            this.tsbUndo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbUndo.Name = "tsbUndo";
            this.tsbUndo.Size = new System.Drawing.Size(23, 22);
            this.tsbUndo.Text = "Undo";
            this.tsbUndo.Click += new System.EventHandler(this.tsbUndo_Click);
            // 
            // tsbRedo
            // 
            this.tsbRedo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRedo.Image = ((System.Drawing.Image)(resources.GetObject("tsbRedo.Image")));
            this.tsbRedo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRedo.Name = "tsbRedo";
            this.tsbRedo.Size = new System.Drawing.Size(23, 22);
            this.tsbRedo.Text = "Redo";
            this.tsbRedo.Click += new System.EventHandler(this.tsbRedo_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbConvFormula
            // 
            this.tsbConvFormula.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbConvFormula.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsbConvFormula.Image = ((System.Drawing.Image)(resources.GetObject("tsbConvFormula.Image")));
            this.tsbConvFormula.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbConvFormula.Name = "tsbConvFormula";
            this.tsbConvFormula.Size = new System.Drawing.Size(102, 22);
            this.tsbConvFormula.Text = "Convert Formula";
            this.tsbConvFormula.Click += new System.EventHandler(this.tsbConvFormula_Click);
            // 
            // fontDialog1
            // 
            this.fontDialog1.Color = System.Drawing.SystemColors.ControlText;
            // 
            // tsUpperGreek
            // 
            this.tsUpperGreek.BackColor = System.Drawing.Color.White;
            this.tsUpperGreek.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsUpperGreek.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbAlpha_U,
            this.tsbBeta_U,
            this.tsbGamma_U,
            this.tsbDelta_U,
            this.tsbEpsilon_U,
            this.tsbZeta_U,
            this.tsbEta_U,
            this.tsbTheta_U,
            this.tsbIota_U,
            this.tsbKappa_U,
            this.tsbLamda_U,
            this.tsbMu_U,
            this.tsbNu_U,
            this.tsbXi_U,
            this.tsbOmicron_U,
            this.toolStripButton25,
            this.tsbRho_U,
            this.tsbSigma_U,
            this.tsbTau_U,
            this.tsbUpsilon_U,
            this.tsbPhi_U,
            this.tsbChi_U,
            this.tsbPsi_U,
            this.tsbOmega_U});
            this.tsUpperGreek.Location = new System.Drawing.Point(0, 25);
            this.tsUpperGreek.Name = "tsUpperGreek";
            this.tsUpperGreek.Size = new System.Drawing.Size(1156, 25);
            this.tsUpperGreek.TabIndex = 47;
            this.tsUpperGreek.Tag = "XC";
            this.tsUpperGreek.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.tsSpecialChars_ItemClicked);
            // 
            // tsbAlpha_U
            // 
            this.tsbAlpha_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbAlpha_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbAlpha_U.Image")));
            this.tsbAlpha_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAlpha_U.Name = "tsbAlpha_U";
            this.tsbAlpha_U.Size = new System.Drawing.Size(23, 22);
            this.tsbAlpha_U.Tag = "&#913;";
            this.tsbAlpha_U.Text = "Α";
            this.tsbAlpha_U.ToolTipText = "Upper Alpha";
            // 
            // tsbBeta_U
            // 
            this.tsbBeta_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbBeta_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbBeta_U.Image")));
            this.tsbBeta_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbBeta_U.Name = "tsbBeta_U";
            this.tsbBeta_U.Size = new System.Drawing.Size(23, 22);
            this.tsbBeta_U.Tag = "&#914;";
            this.tsbBeta_U.Text = "Β";
            // 
            // tsbGamma_U
            // 
            this.tsbGamma_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbGamma_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbGamma_U.Image")));
            this.tsbGamma_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbGamma_U.Name = "tsbGamma_U";
            this.tsbGamma_U.Size = new System.Drawing.Size(23, 22);
            this.tsbGamma_U.Tag = "&#915; ";
            this.tsbGamma_U.Text = "Γ";
            this.tsbGamma_U.ToolTipText = "gamma";
            // 
            // tsbDelta_U
            // 
            this.tsbDelta_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbDelta_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbDelta_U.Image")));
            this.tsbDelta_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDelta_U.Name = "tsbDelta_U";
            this.tsbDelta_U.Size = new System.Drawing.Size(23, 22);
            this.tsbDelta_U.Tag = "&#916;";
            this.tsbDelta_U.Text = "Δ";
            this.tsbDelta_U.ToolTipText = "delta";
            // 
            // tsbEpsilon_U
            // 
            this.tsbEpsilon_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbEpsilon_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbEpsilon_U.Image")));
            this.tsbEpsilon_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbEpsilon_U.Name = "tsbEpsilon_U";
            this.tsbEpsilon_U.Size = new System.Drawing.Size(23, 22);
            this.tsbEpsilon_U.Tag = "&#917;";
            this.tsbEpsilon_U.Text = "Ε";
            this.tsbEpsilon_U.ToolTipText = "epsilon";
            // 
            // tsbZeta_U
            // 
            this.tsbZeta_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbZeta_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbZeta_U.Image")));
            this.tsbZeta_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbZeta_U.Name = "tsbZeta_U";
            this.tsbZeta_U.Size = new System.Drawing.Size(23, 22);
            this.tsbZeta_U.Tag = "&#918;";
            this.tsbZeta_U.Text = "Ζ";
            this.tsbZeta_U.ToolTipText = "Zeta";
            // 
            // tsbEta_U
            // 
            this.tsbEta_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbEta_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbEta_U.Image")));
            this.tsbEta_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbEta_U.Name = "tsbEta_U";
            this.tsbEta_U.Size = new System.Drawing.Size(23, 22);
            this.tsbEta_U.Tag = "&#919;";
            this.tsbEta_U.Text = "Η";
            this.tsbEta_U.ToolTipText = "Eta";
            // 
            // tsbTheta_U
            // 
            this.tsbTheta_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbTheta_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbTheta_U.Image")));
            this.tsbTheta_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbTheta_U.Name = "tsbTheta_U";
            this.tsbTheta_U.Size = new System.Drawing.Size(23, 22);
            this.tsbTheta_U.Tag = "&#920;";
            this.tsbTheta_U.Text = "Θ";
            this.tsbTheta_U.ToolTipText = "Theta";
            // 
            // tsbIota_U
            // 
            this.tsbIota_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbIota_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbIota_U.Image")));
            this.tsbIota_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbIota_U.Name = "tsbIota_U";
            this.tsbIota_U.Size = new System.Drawing.Size(23, 22);
            this.tsbIota_U.Tag = "&#921;";
            this.tsbIota_U.Text = "Ι";
            this.tsbIota_U.ToolTipText = "Iota";
            // 
            // tsbKappa_U
            // 
            this.tsbKappa_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbKappa_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbKappa_U.Image")));
            this.tsbKappa_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbKappa_U.Name = "tsbKappa_U";
            this.tsbKappa_U.Size = new System.Drawing.Size(23, 22);
            this.tsbKappa_U.Tag = "&#922;";
            this.tsbKappa_U.Text = "Κ";
            this.tsbKappa_U.ToolTipText = "Kappa";
            // 
            // tsbLamda_U
            // 
            this.tsbLamda_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbLamda_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbLamda_U.Image")));
            this.tsbLamda_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLamda_U.Name = "tsbLamda_U";
            this.tsbLamda_U.Size = new System.Drawing.Size(23, 22);
            this.tsbLamda_U.Tag = "&#923;";
            this.tsbLamda_U.Text = "Λ";
            this.tsbLamda_U.ToolTipText = "Lamda";
            // 
            // tsbMu_U
            // 
            this.tsbMu_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbMu_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbMu_U.Image")));
            this.tsbMu_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbMu_U.Name = "tsbMu_U";
            this.tsbMu_U.Size = new System.Drawing.Size(23, 22);
            this.tsbMu_U.Tag = "&#924;";
            this.tsbMu_U.Text = "Μ";
            this.tsbMu_U.ToolTipText = "Mu";
            // 
            // tsbNu_U
            // 
            this.tsbNu_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbNu_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbNu_U.Image")));
            this.tsbNu_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbNu_U.Name = "tsbNu_U";
            this.tsbNu_U.Size = new System.Drawing.Size(23, 22);
            this.tsbNu_U.Tag = "&#925;";
            this.tsbNu_U.Text = "Ν";
            this.tsbNu_U.ToolTipText = "Nu";
            // 
            // tsbXi_U
            // 
            this.tsbXi_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbXi_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbXi_U.Image")));
            this.tsbXi_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbXi_U.Name = "tsbXi_U";
            this.tsbXi_U.Size = new System.Drawing.Size(23, 22);
            this.tsbXi_U.Tag = "&#926;";
            this.tsbXi_U.Text = "Ξ";
            this.tsbXi_U.ToolTipText = "ksi";
            // 
            // tsbOmicron_U
            // 
            this.tsbOmicron_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbOmicron_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbOmicron_U.Image")));
            this.tsbOmicron_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbOmicron_U.Name = "tsbOmicron_U";
            this.tsbOmicron_U.Size = new System.Drawing.Size(23, 22);
            this.tsbOmicron_U.Tag = "&#927;";
            this.tsbOmicron_U.Text = "Ο";
            this.tsbOmicron_U.ToolTipText = "omicron";
            // 
            // toolStripButton25
            // 
            this.toolStripButton25.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton25.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton25.Image")));
            this.toolStripButton25.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton25.Name = "toolStripButton25";
            this.toolStripButton25.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton25.Tag = "&#928;";
            this.toolStripButton25.Text = "Π";
            this.toolStripButton25.ToolTipText = "Pi";
            // 
            // tsbRho_U
            // 
            this.tsbRho_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbRho_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbRho_U.Image")));
            this.tsbRho_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRho_U.Name = "tsbRho_U";
            this.tsbRho_U.Size = new System.Drawing.Size(23, 22);
            this.tsbRho_U.Tag = "&#929;";
            this.tsbRho_U.Text = "Ρ";
            this.tsbRho_U.ToolTipText = "Rho";
            // 
            // tsbSigma_U
            // 
            this.tsbSigma_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbSigma_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbSigma_U.Image")));
            this.tsbSigma_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSigma_U.Name = "tsbSigma_U";
            this.tsbSigma_U.Size = new System.Drawing.Size(23, 22);
            this.tsbSigma_U.Tag = "&#931;";
            this.tsbSigma_U.Text = "Σ";
            this.tsbSigma_U.ToolTipText = "Sigma";
            // 
            // tsbTau_U
            // 
            this.tsbTau_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbTau_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbTau_U.Image")));
            this.tsbTau_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbTau_U.Name = "tsbTau_U";
            this.tsbTau_U.Size = new System.Drawing.Size(23, 22);
            this.tsbTau_U.Tag = "&#932;";
            this.tsbTau_U.Text = "Τ";
            this.tsbTau_U.ToolTipText = "Tau";
            // 
            // tsbUpsilon_U
            // 
            this.tsbUpsilon_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbUpsilon_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbUpsilon_U.Image")));
            this.tsbUpsilon_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbUpsilon_U.Name = "tsbUpsilon_U";
            this.tsbUpsilon_U.Size = new System.Drawing.Size(23, 22);
            this.tsbUpsilon_U.Tag = "&#933;";
            this.tsbUpsilon_U.Text = "Υ";
            this.tsbUpsilon_U.ToolTipText = "upsilon";
            // 
            // tsbPhi_U
            // 
            this.tsbPhi_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPhi_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbPhi_U.Image")));
            this.tsbPhi_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPhi_U.Name = "tsbPhi_U";
            this.tsbPhi_U.Size = new System.Drawing.Size(23, 22);
            this.tsbPhi_U.Tag = "&#934;";
            this.tsbPhi_U.Text = "Φ";
            this.tsbPhi_U.ToolTipText = "phi";
            // 
            // tsbChi_U
            // 
            this.tsbChi_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbChi_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbChi_U.Image")));
            this.tsbChi_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbChi_U.Name = "tsbChi_U";
            this.tsbChi_U.Size = new System.Drawing.Size(23, 22);
            this.tsbChi_U.Tag = "&#935;";
            this.tsbChi_U.Text = "Χ";
            this.tsbChi_U.ToolTipText = "chi";
            // 
            // tsbPsi_U
            // 
            this.tsbPsi_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPsi_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbPsi_U.Image")));
            this.tsbPsi_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPsi_U.Name = "tsbPsi_U";
            this.tsbPsi_U.Size = new System.Drawing.Size(23, 22);
            this.tsbPsi_U.Tag = "&#936;";
            this.tsbPsi_U.Text = "Ψ";
            this.tsbPsi_U.ToolTipText = "psi";
            // 
            // tsbOmega_U
            // 
            this.tsbOmega_U.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbOmega_U.Image = ((System.Drawing.Image)(resources.GetObject("tsbOmega_U.Image")));
            this.tsbOmega_U.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbOmega_U.Name = "tsbOmega_U";
            this.tsbOmega_U.Size = new System.Drawing.Size(23, 22);
            this.tsbOmega_U.Tag = "&#937;";
            this.tsbOmega_U.Text = "Ω";
            this.tsbOmega_U.ToolTipText = "omega";
            // 
            // ucSplCharsToolStrip_Indexing
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.tsUpperGreek);
            this.Controls.Add(this.tsFontStyles);
            this.Controls.Add(this.tsSpecialChars);
            this.Name = "ucSplCharsToolStrip_Indexing";
            this.Size = new System.Drawing.Size(1156, 74);
            this.tsSpecialChars.ResumeLayout(false);
            this.tsSpecialChars.PerformLayout();
            this.tsFontStyles.ResumeLayout(false);
            this.tsFontStyles.PerformLayout();
            this.tsUpperGreek.ResumeLayout(false);
            this.tsUpperGreek.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.ToolStrip tsSpecialChars;
        private System.Windows.Forms.ToolStripButton tsbAlpha;
        private System.Windows.Forms.ToolStripButton tsbBeta;
        private System.Windows.Forms.ToolStripButton tsbGamma;
        private System.Windows.Forms.ToolStripButton tsbDelta;
        private System.Windows.Forms.ToolStripButton tsbEpsilon;
        private System.Windows.Forms.ToolStripButton tsbZeta;
        private System.Windows.Forms.ToolStripButton tsbEta;
        private System.Windows.Forms.ToolStripButton tsbTheta;
        private System.Windows.Forms.ToolStripButton tsbIota;
        private System.Windows.Forms.ToolStripButton tsbKappa;
        private System.Windows.Forms.ToolStripButton tsbLamda;
        private System.Windows.Forms.ToolStripButton tsbMu;
        private System.Windows.Forms.ToolStripButton tsbNu;
        private System.Windows.Forms.ToolStripButton tsbXi;
        private System.Windows.Forms.ToolStripButton tsbOmicron;
        private System.Windows.Forms.ToolStripButton tsbPi;
        private System.Windows.Forms.ToolStripButton tsbRho;
        private System.Windows.Forms.ToolStripButton tsbSigma;
        private System.Windows.Forms.ToolStripButton tsupsilon;
        private System.Windows.Forms.ToolStripButton tsbPhi;
        private System.Windows.Forms.ToolStripButton tsbChi;
        private System.Windows.Forms.ToolStripButton tsbPsi;
        private System.Windows.Forms.ToolStripButton tsbOmega;
        private System.Windows.Forms.ToolStripButton tsbDegree;
        private System.Windows.Forms.ToolStripButton tsbPipe;
        private System.Windows.Forms.ToolStripButton tsbApprox;
        private System.Windows.Forms.ToolStripButton tsbPlusMinus;
        private System.Windows.Forms.ToolStripButton tsbDot;
        private System.Windows.Forms.ToolStripButton tsbLessThanEqual;
        private System.Windows.Forms.ToolStripButton tsbGreaterthanEqual;
        private System.Windows.Forms.ToolStripButton tsbAmstagon;
        private System.Windows.Forms.ToolStripButton ts1triplebond;
        private System.Windows.Forms.ToolStripButton tsbGreaterThan;
        private System.Windows.Forms.ToolStripButton tsbLessThan;
        private System.Windows.Forms.ToolStripButton tsbLeftRightArrow;
        private System.Windows.Forms.ToolStripButton tsbLeftRightDoubleArrow;
        private System.Windows.Forms.ToolStripButton tsbDegrees;
        private System.Windows.Forms.ToolStripButton tsbEqualTo;
        private System.Windows.Forms.ToolStrip tsFontStyles;
        private System.Windows.Forms.ToolStripButton tsbBold;
        private System.Windows.Forms.ToolStripButton tsbUnderline;
        private System.Windows.Forms.ToolStripButton tsbItalic;
        private System.Windows.Forms.ToolStripButton tsbStrikeout;
        private System.Windows.Forms.ToolStripButton tsbRegular;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tsbSuperscript;
        private System.Windows.Forms.ToolStripButton tsbSubscript;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton tsbSmallCaps;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton tsbUndo;
        private System.Windows.Forms.ToolStripButton tsbRedo;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.ToolStripButton tsCaseChange;
        private System.Windows.Forms.ToolStripButton tsbNotEqualTo;
        private System.Windows.Forms.ToolStripButton tsbLeftArrow;
        private System.Windows.Forms.ToolStripButton tsbRightArrow;
        private System.Windows.Forms.ToolStripButton tsbSquareRoot;
        public System.Windows.Forms.ToolStrip tsUpperGreek;
        private System.Windows.Forms.ToolStripButton tsbAlpha_U;
        private System.Windows.Forms.ToolStripButton tsbBeta_U;
        private System.Windows.Forms.ToolStripButton tsbGamma_U;
        private System.Windows.Forms.ToolStripButton tsbDelta_U;
        private System.Windows.Forms.ToolStripButton tsbEpsilon_U;
        private System.Windows.Forms.ToolStripButton tsbZeta_U;
        private System.Windows.Forms.ToolStripButton tsbEta_U;
        private System.Windows.Forms.ToolStripButton tsbTheta_U;
        private System.Windows.Forms.ToolStripButton tsbIota_U;
        private System.Windows.Forms.ToolStripButton tsbKappa_U;
        private System.Windows.Forms.ToolStripButton tsbLamda_U;
        private System.Windows.Forms.ToolStripButton tsbMu_U;
        private System.Windows.Forms.ToolStripButton tsbNu_U;
        private System.Windows.Forms.ToolStripButton tsbXi_U;
        private System.Windows.Forms.ToolStripButton tsbOmicron_U;
        private System.Windows.Forms.ToolStripButton toolStripButton25;
        private System.Windows.Forms.ToolStripButton tsbRho_U;
        private System.Windows.Forms.ToolStripButton tsbSigma_U;
        private System.Windows.Forms.ToolStripButton tsbTau_U;
        private System.Windows.Forms.ToolStripButton tsbUpsilon_U;
        private System.Windows.Forms.ToolStripButton tsbPhi_U;
        private System.Windows.Forms.ToolStripButton tsbChi_U;
        private System.Windows.Forms.ToolStripButton tsbPsi_U;
        private System.Windows.Forms.ToolStripButton tsbOmega_U;
        private System.Windows.Forms.ToolStripButton tsbTau;
        private System.Windows.Forms.ToolStripButton tsbInfinite;
        public System.Windows.Forms.ToolStripButton tsbConvFormula;
        private System.Windows.Forms.ToolStripButton tsbRegister;
        private System.Windows.Forms.ToolStripButton tsbCopyRight;
        private System.Windows.Forms.ToolStripButton tsbYen;
    }
}
