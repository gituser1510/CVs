﻿namespace IndxReactNarr
{
    partial class ucGetReaction
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            MDL.Draw.Chemistry.Molecule molecule1 = new MDL.Draw.Chemistry.Molecule();
            MDL.Draw.Renderer.Preferences.DisplayPreferences displayPreferences1 = new MDL.Draw.Renderer.Preferences.DisplayPreferences();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.splCont = new System.Windows.Forms.SplitContainer();
            this.tlpnlProd = new System.Windows.Forms.TableLayoutPanel();
            this.pnlNUM = new System.Windows.Forms.Panel();
            this.btnPdf = new System.Windows.Forms.Button();
            this.lnkEdit = new System.Windows.Forms.LinkLabel();
            this.lblSnoVal = new System.Windows.Forms.Label();
            this.lblSno = new System.Windows.Forms.Label();
            this.lblProdVal = new System.Windows.Forms.Label();
            this.lblProduct = new System.Windows.Forms.Label();
            this.rtxtPartpnts = new System.Windows.Forms.RichTextBox();
            this.ChemRenditor = new MDL.Draw.Renditor.Renditor();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splCont)).BeginInit();
            this.splCont.Panel1.SuspendLayout();
            this.splCont.Panel2.SuspendLayout();
            this.splCont.SuspendLayout();
            this.pnlNUM.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.splCont);
            this.pnlMain.Controls.Add(this.ChemRenditor);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(924, 414);
            this.pnlMain.TabIndex = 0;
            // 
            // splCont
            // 
            this.splCont.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splCont.Location = new System.Drawing.Point(0, 0);
            this.splCont.Name = "splCont";
            this.splCont.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splCont.Panel1
            // 
            this.splCont.Panel1.Controls.Add(this.tlpnlProd);
            this.splCont.Panel1.Controls.Add(this.pnlNUM);
            // 
            // splCont.Panel2
            // 
            this.splCont.Panel2.Controls.Add(this.rtxtPartpnts);
            this.splCont.Size = new System.Drawing.Size(924, 414);
            this.splCont.SplitterDistance = 318;
            this.splCont.TabIndex = 0;
            this.splCont.TabStop = false;
            // 
            // tlpnlProd
            // 
            this.tlpnlProd.AutoScroll = true;
            this.tlpnlProd.ColumnCount = 1;
            this.tlpnlProd.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpnlProd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpnlProd.Location = new System.Drawing.Point(0, 23);
            this.tlpnlProd.Name = "tlpnlProd";
            this.tlpnlProd.RowCount = 1;
            this.tlpnlProd.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpnlProd.Size = new System.Drawing.Size(924, 295);
            this.tlpnlProd.TabIndex = 0;
            // 
            // pnlNUM
            // 
            this.pnlNUM.BackColor = System.Drawing.Color.LemonChiffon;
            this.pnlNUM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlNUM.Controls.Add(this.btnPdf);
            this.pnlNUM.Controls.Add(this.lnkEdit);
            this.pnlNUM.Controls.Add(this.lblSnoVal);
            this.pnlNUM.Controls.Add(this.lblSno);
            this.pnlNUM.Controls.Add(this.lblProdVal);
            this.pnlNUM.Controls.Add(this.lblProduct);
            this.pnlNUM.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlNUM.Location = new System.Drawing.Point(0, 0);
            this.pnlNUM.Name = "pnlNUM";
            this.pnlNUM.Size = new System.Drawing.Size(924, 23);
            this.pnlNUM.TabIndex = 0;
            this.pnlNUM.Click += new System.EventHandler(this.pnlNUM_Click);
            // 
            // btnPdf
            // 
            this.btnPdf.Location = new System.Drawing.Point(656, -1);
            this.btnPdf.Name = "btnPdf";
            this.btnPdf.Size = new System.Drawing.Size(75, 23);
            this.btnPdf.TabIndex = 1;
            this.btnPdf.Text = "Pdf";
            this.btnPdf.UseVisualStyleBackColor = true;
            this.btnPdf.Visible = false;
            this.btnPdf.Click += new System.EventHandler(this.btnPdf_Click);
            // 
            // lnkEdit
            // 
            this.lnkEdit.AutoSize = true;
            this.lnkEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkEdit.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkEdit.LinkColor = System.Drawing.Color.Magenta;
            this.lnkEdit.Location = new System.Drawing.Point(353, 2);
            this.lnkEdit.Name = "lnkEdit";
            this.lnkEdit.Size = new System.Drawing.Size(109, 18);
            this.lnkEdit.TabIndex = 0;
            this.lnkEdit.TabStop = true;
            this.lnkEdit.Text = "Go to Reaction";
            this.lnkEdit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkEdit_LinkClicked);
            // 
            // lblSnoVal
            // 
            this.lblSnoVal.AutoSize = true;
            this.lblSnoVal.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSnoVal.ForeColor = System.Drawing.Color.Blue;
            this.lblSnoVal.Location = new System.Drawing.Point(38, 2);
            this.lblSnoVal.Name = "lblSnoVal";
            this.lblSnoVal.Size = new System.Drawing.Size(15, 17);
            this.lblSnoVal.TabIndex = 0;
            this.lblSnoVal.Text = "0";
            // 
            // lblSno
            // 
            this.lblSno.AutoSize = true;
            this.lblSno.Location = new System.Drawing.Point(-1, 2);
            this.lblSno.Name = "lblSno";
            this.lblSno.Size = new System.Drawing.Size(42, 17);
            this.lblSno.TabIndex = 0;
            this.lblSno.Text = "S.No.";
            // 
            // lblProdVal
            // 
            this.lblProdVal.AutoSize = true;
            this.lblProdVal.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProdVal.ForeColor = System.Drawing.Color.Red;
            this.lblProdVal.Location = new System.Drawing.Point(178, 1);
            this.lblProdVal.Name = "lblProdVal";
            this.lblProdVal.Size = new System.Drawing.Size(16, 17);
            this.lblProdVal.TabIndex = 0;
            this.lblProdVal.Text = "0";
            // 
            // lblProduct
            // 
            this.lblProduct.AutoSize = true;
            this.lblProduct.Location = new System.Drawing.Point(117, 2);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(61, 17);
            this.lblProduct.TabIndex = 0;
            this.lblProduct.Text = "Product: ";
            // 
            // rtxtPartpnts
            // 
            this.rtxtPartpnts.BackColor = System.Drawing.Color.White;
            this.rtxtPartpnts.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rtxtPartpnts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtxtPartpnts.ForeColor = System.Drawing.Color.Blue;
            this.rtxtPartpnts.Location = new System.Drawing.Point(0, 0);
            this.rtxtPartpnts.Name = "rtxtPartpnts";
            this.rtxtPartpnts.ReadOnly = true;
            this.rtxtPartpnts.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
            this.rtxtPartpnts.Size = new System.Drawing.Size(924, 92);
            this.rtxtPartpnts.TabIndex = 0;
            this.rtxtPartpnts.TabStop = false;
            this.rtxtPartpnts.Text = "";
            // 
            // ChemRenditor
            // 
            this.ChemRenditor.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.ChemRenditor.AutoSizeStructure = true;
            this.ChemRenditor.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.ChemRenditor.BinHexSketch = "01030004412400214372656174656420627920416363656C7279734472617720342E322E302E36303" +
    "502040000005805000000005905000000000B0B0005417269616C780000140200";
            this.ChemRenditor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ChemRenditor.ChimeString = null;
            this.ChemRenditor.ClearingEnabled = true;
            this.ChemRenditor.CopyingEnabled = true;
            this.ChemRenditor.DisplayOnEmpty = null;
            this.ChemRenditor.EditingEnabled = true;
            this.ChemRenditor.FileName = null;
            this.ChemRenditor.HighlightInfo = "";
            this.ChemRenditor.IsBitmapFromOLE = true;
            this.ChemRenditor.Location = new System.Drawing.Point(510, 34);
            molecule1.ArrowDir = MDL.Draw.ArrowDirType.No;
            molecule1.ArrowStyle = MDL.Draw.ArrowStyleType.Empty;
            molecule1.AtomValenceDisplay = true;
            molecule1.BaseFormBoxSetting = 0;
            molecule1.BondLineThickness = 0D;
            molecule1.CarbonLabelDisplay = false;
            molecule1.ChemLabelFont = null;
            molecule1.ChemLabelFontString = "(none)";
            molecule1.ColorAtomsByTypeInSketch = false;
            molecule1.ConfigLabelFont = null;
            molecule1.ConfigLabelFontString = "(none)";
            molecule1.ConvertRingBondIntoOneToMany = true;
            molecule1.Coords = null;
            molecule1.DashSpacing = 0.1D;
            molecule1.DisplaySinCys = false;
            molecule1.DisplaySulfurInCysSequence = false;
            molecule1.DoubleBondWidth = 0.18D;
            molecule1.FillColor = System.Drawing.Color.Empty;
            molecule1.FillStyle = MDL.Draw.ChemGraphicsObject.FillStyles.SOLID;
            molecule1.ForeColor = System.Drawing.Color.Empty;
            molecule1.ForeColorString = "";
            molecule1.ForSubsequenceQuery = false;
            molecule1.HighlightChildren = "";
            molecule1.HighlightColor = System.Drawing.Color.Blue;
            molecule1.HydrogenDisplayMode = MDL.Draw.Chemistry.Atom.HydrogenDisplayMode.Off;
            molecule1.Id = 18;
            molecule1.Initial = "";
            molecule1.IsAModel = false;
            molecule1.IsARotatedModel = false;
            molecule1.KeepRSLabelsInSketch = true;
            molecule1.LastModifyChemText = -1;
            molecule1.MaintainXMLChildOrderFlag = false;
            molecule1.MustPerceiveStereo = true;
            molecule1.PenColor = System.Drawing.Color.Empty;
            molecule1.PenStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            molecule1.PenStyleToken = 0;
            molecule1.PenWidth = ((byte)(0));
            molecule1.PenWidthUnit = MDL.Draw.ChemGraphicsObject.PenWidthUnits.Default;
            molecule1.RefId = 18;
            molecule1.Replaced = false;
            molecule1.RgroupCleeanUpNeeded = false;
            molecule1.RgroupLabelsPresentFlag = false;
            molecule1.RLabelAtAbsCenter = "R";
            molecule1.RLabelAtAndCenter = "R*";
            molecule1.RLabelAtOrCenter = "(R)";
            molecule1.ScaleLabelsToBondLength = false;
            molecule1.Selected = false;
            molecule1.SequenceDictionary = null;
            molecule1.SequenceNeedsRealign = false;
            molecule1.SequenceView = MDL.Draw.Chemistry.Molecule.SequenceViewEnum.None;
            molecule1.Size = 0;
            molecule1.SkcWritten = false;
            molecule1.SkNumber = ((short)(0));
            molecule1.SLabelAtAbsCenter = "S";
            molecule1.SLabelAtAndCenter = "S*";
            molecule1.SLabelAtOrCenter = "(S)";
            molecule1.StandardBondLength = 0D;
            molecule1.StereoChemistryMode = MDL.Draw.Chemistry.Molecule.StereoChemistryModeEnum.And;
            molecule1.TextBorder = 0.1D;
            molecule1.Transparent = false;
            molecule1.UndoableEditListener = null;
            molecule1.WedgeWidth = 0.1D;
            molecule1.ZLayer = -99983;
            this.ChemRenditor.Molecule = molecule1;
            this.ChemRenditor.MolfileString = "";
            this.ChemRenditor.Name = "ChemRenditor";
            this.ChemRenditor.OldScalingMode = MDL.Draw.Renderer.Preferences.StructureScalingMode.ScaleToFitBox;
            this.ChemRenditor.PastingEnabled = true;
            displayPreferences1.AtomAtomDisplayMode = MDL.Draw.Renderer.Preferences.AtomAtomMappingDisplayMode.On;
            this.ChemRenditor.Preferences = displayPreferences1;
            this.ChemRenditor.PreferencesFileName = "default.xml";
            this.ChemRenditor.RendererBorderStyle = System.Windows.Forms.ButtonBorderStyle.Inset;
            this.ChemRenditor.RenditorMolecule = molecule1;
            this.ChemRenditor.RenditorName = "Demo Renditor";
            this.ChemRenditor.Size = new System.Drawing.Size(307, 300);
            this.ChemRenditor.SketchString = "AQMABEEkACFDcmVhdGVkIGJ5IEFjY2VscnlzRHJhdyA0LjIuMC42MDUCBAAAAFgFAAAAAFkFAAAAAAsLA" +
    "AVBcmlhbHgAABQCAA==";
            this.ChemRenditor.SmilesString = "";
            this.ChemRenditor.TabIndex = 10;
            this.ChemRenditor.URLEncodedMolfileString = "";
            this.ChemRenditor.UseLocalXMLConfig = false;
            this.ChemRenditor.Visible = false;
            // 
            // ucGetReaction
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.pnlMain);
            this.Name = "ucGetReaction";
            this.Size = new System.Drawing.Size(924, 414);
            this.pnlMain.ResumeLayout(false);
            this.splCont.Panel1.ResumeLayout(false);
            this.splCont.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splCont)).EndInit();
            this.splCont.ResumeLayout(false);
            this.pnlNUM.ResumeLayout(false);
            this.pnlNUM.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.RichTextBox rtxtPartpnts;
        public System.Windows.Forms.TableLayoutPanel tlpnlProd;
        private MDL.Draw.Renditor.Renditor ChemRenditor;
        private System.Windows.Forms.Panel pnlNUM;
        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.Label lblProdVal;
        private System.Windows.Forms.Label lblSnoVal;
        private System.Windows.Forms.Label lblSno;
        private System.Windows.Forms.LinkLabel lnkEdit;
        public System.Windows.Forms.SplitContainer splCont;
        private System.Windows.Forms.Button btnPdf;
    }
}
