﻿namespace IndxReactNarr.UserControls
{
    partial class ucRxnFinding
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlValueCntrls = new System.Windows.Forms.Panel();
            this.uchrtbFindingData = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.cmbFindingMaterials = new System.Windows.Forms.ComboBox();
            this.pnlLnkCntrls = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbFindingRefCompound = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbFindingType = new System.Windows.Forms.ComboBox();
            this.chkDeleteFlag = new System.Windows.Forms.CheckBox();
            this.pnlMain.SuspendLayout();
            this.pnlValueCntrls.SuspendLayout();
            this.pnlLnkCntrls.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.SeaShell;
            this.pnlMain.Controls.Add(this.pnlValueCntrls);
            this.pnlMain.Controls.Add(this.pnlLnkCntrls);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(881, 60);
            this.pnlMain.TabIndex = 0;
            // 
            // pnlValueCntrls
            // 
            this.pnlValueCntrls.Controls.Add(this.uchrtbFindingData);
            this.pnlValueCntrls.Controls.Add(this.cmbFindingMaterials);
            this.pnlValueCntrls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlValueCntrls.Location = new System.Drawing.Point(242, 0);
            this.pnlValueCntrls.Name = "pnlValueCntrls";
            this.pnlValueCntrls.Size = new System.Drawing.Size(639, 60);
            this.pnlValueCntrls.TabIndex = 5;
            // 
            // uchrtbFindingData
            // 
            this.uchrtbFindingData.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.uchrtbFindingData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uchrtbFindingData.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uchrtbFindingData.HighlightMaterials = false;
            this.uchrtbFindingData.Location = new System.Drawing.Point(0, 0);
            this.uchrtbFindingData.Name = "uchrtbFindingData";
            this.uchrtbFindingData.PreserveMultiLines = false;
            this.uchrtbFindingData.Size = new System.Drawing.Size(639, 60);
            this.uchrtbFindingData.TabIndex = 0;
            // 
            // cmbFindingMaterials
            // 
            this.cmbFindingMaterials.DisplayMember = "SUBST_IDENTIFIER";
            this.cmbFindingMaterials.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFindingMaterials.FormattingEnabled = true;
            this.cmbFindingMaterials.Location = new System.Drawing.Point(3, 17);
            this.cmbFindingMaterials.Name = "cmbFindingMaterials";
            this.cmbFindingMaterials.Size = new System.Drawing.Size(204, 25);
            this.cmbFindingMaterials.TabIndex = 208;
            this.cmbFindingMaterials.ValueMember = "SUBST_IDENTIFIER";
            this.cmbFindingMaterials.Visible = false;
            // 
            // pnlLnkCntrls
            // 
            this.pnlLnkCntrls.Controls.Add(this.chkDeleteFlag);
            this.pnlLnkCntrls.Controls.Add(this.label2);
            this.pnlLnkCntrls.Controls.Add(this.cmbFindingRefCompound);
            this.pnlLnkCntrls.Controls.Add(this.label1);
            this.pnlLnkCntrls.Controls.Add(this.cmbFindingType);
            this.pnlLnkCntrls.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlLnkCntrls.Location = new System.Drawing.Point(0, 0);
            this.pnlLnkCntrls.Name = "pnlLnkCntrls";
            this.pnlLnkCntrls.Size = new System.Drawing.Size(242, 60);
            this.pnlLnkCntrls.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Ref.Comp";
            // 
            // cmbFindingRefCompound
            // 
            this.cmbFindingRefCompound.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFindingRefCompound.FormattingEnabled = true;
            this.cmbFindingRefCompound.Location = new System.Drawing.Point(75, 32);
            this.cmbFindingRefCompound.Name = "cmbFindingRefCompound";
            this.cmbFindingRefCompound.Size = new System.Drawing.Size(164, 25);
            this.cmbFindingRefCompound.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Type";
            // 
            // cmbFindingType
            // 
            this.cmbFindingType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFindingType.FormattingEnabled = true;
            this.cmbFindingType.Location = new System.Drawing.Point(76, 4);
            this.cmbFindingType.Name = "cmbFindingType";
            this.cmbFindingType.Size = new System.Drawing.Size(163, 25);
            this.cmbFindingType.TabIndex = 0;           
            this.cmbFindingType.SelectedValueChanged += new System.EventHandler(this.cmbFindingType_SelectedValueChanged);
            // 
            // chkDeleteFlag
            // 
            this.chkDeleteFlag.AutoSize = true;
            this.chkDeleteFlag.Location = new System.Drawing.Point(4, 5);
            this.chkDeleteFlag.Name = "chkDeleteFlag";
            this.chkDeleteFlag.Size = new System.Drawing.Size(15, 14);
            this.chkDeleteFlag.TabIndex = 4;
            this.chkDeleteFlag.UseVisualStyleBackColor = true;
            // 
            // ucRxnFinding
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.pnlMain);
            this.Name = "ucRxnFinding";
            this.Size = new System.Drawing.Size(881, 60);
            this.pnlMain.ResumeLayout(false);
            this.pnlValueCntrls.ResumeLayout(false);
            this.pnlLnkCntrls.ResumeLayout(false);
            this.pnlLnkCntrls.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlLnkCntrls;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        public ucHtmlRichText uchrtbFindingData;
        public System.Windows.Forms.ComboBox cmbFindingRefCompound;
        public System.Windows.Forms.ComboBox cmbFindingType;
        private System.Windows.Forms.Panel pnlValueCntrls;
        public System.Windows.Forms.ComboBox cmbFindingMaterials;
        public System.Windows.Forms.CheckBox chkDeleteFlag;
    }
}
