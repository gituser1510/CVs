﻿namespace IndxReactNarr
{
    partial class uccasnartool_new
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uccasnartool_new));
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlNumInfo = new System.Windows.Forms.Panel();
            this.txtfilename = new System.Windows.Forms.TextBox();
            this.lblSeq = new System.Windows.Forms.Label();
            this.lblreactioncasreactonnumber = new System.Windows.Forms.Label();
            this.txtCASReactnumber = new System.Windows.Forms.TextBox();
            this.lblPageNumber = new System.Windows.Forms.Label();
            this.txtdocref = new System.Windows.Forms.TextBox();
            this.txtpagenumber = new System.Windows.Forms.TextBox();
            this.lblpglabel = new System.Windows.Forms.Label();
            this.txtrxnseq = new System.Windows.Forms.TextBox();
            this.txtpagelabel = new System.Windows.Forms.TextBox();
            this.txtyoffset = new System.Windows.Forms.TextBox();
            this.lbldocref = new System.Windows.Forms.Label();
            this.lblYoffSet = new System.Windows.Forms.Label();
            this.txtxoffset = new System.Windows.Forms.TextBox();
            this.lblfilename = new System.Windows.Forms.Label();
            this.lblXoffSet = new System.Windows.Forms.Label();
            this.lblXPageSize = new System.Windows.Forms.Label();
            this.lblYPageSize = new System.Windows.Forms.Label();
            this.txtypagesize = new System.Windows.Forms.TextBox();
            this.txtxpagesize = new System.Windows.Forms.TextBox();
            this.lblTextLine = new System.Windows.Forms.Label();
            this.chkIsMissingRxn = new System.Windows.Forms.CheckBox();
            this.rtxttextlinepreview = new HtmlRichText.HtmlRichTextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.TsPaste = new System.Windows.Forms.ToolStripMenuItem();
            this.tsWordWrap = new System.Windows.Forms.ToolStripMenuItem();
            this.TshScrollbar = new System.Windows.Forms.ToolStripMenuItem();
            this.tsvscrollbars = new System.Windows.Forms.ToolStripMenuItem();
            this.tsboth = new System.Windows.Forms.ToolStripMenuItem();
            this.transferToTextEditorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearBackColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spellCheckToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyXYOffsetsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsnsubscript = new System.Windows.Forms.ToolStripMenuItem();
            this.superscriptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.italicToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.boldToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addParaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cmbAnalogousTo = new System.Windows.Forms.ComboBox();
            this.chkIsAnalogous = new System.Windows.Forms.CheckBox();
            this.chkisgeneralprocempty = new System.Windows.Forms.CheckBox();
            this.chkisGeneralTypical = new System.Windows.Forms.CheckBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.splCntparaData = new System.Windows.Forms.SplitContainer();
            this.flPnlPara = new System.Windows.Forms.FlowLayoutPanel();
            this.ucHtmlRichText1 = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.pnlParaHdr = new System.Windows.Forms.Panel();
            this.lblParaCnt = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lnkAddPara = new System.Windows.Forms.LinkLabel();
            this.btnDeletePara = new System.Windows.Forms.Button();
            this.splDataData2 = new System.Windows.Forms.SplitContainer();
            this.flPnlData = new System.Windows.Forms.FlowLayoutPanel();
            this.ucHtmlRichText3 = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.pnlDataHdr = new System.Windows.Forms.Panel();
            this.lblDataCnt = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lnkData = new System.Windows.Forms.LinkLabel();
            this.btnDeleteData = new System.Windows.Forms.Button();
            this.lblData2 = new System.Windows.Forms.Label();
            this.rtxtdata1 = new HtmlRichText.HtmlRichTextBox();
            this.txtnarrativeid = new System.Windows.Forms.TextBox();
            this.lblNarId = new System.Windows.Forms.Label();
            this.tb1rtxteditor = new onlyconnect.HtmlEditor();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.pnlMain.SuspendLayout();
            this.pnlNumInfo.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.splCntparaData.Panel1.SuspendLayout();
            this.splCntparaData.Panel2.SuspendLayout();
            this.splCntparaData.SuspendLayout();
            this.flPnlPara.SuspendLayout();
            this.pnlParaHdr.SuspendLayout();
            this.splDataData2.Panel1.SuspendLayout();
            this.splDataData2.Panel2.SuspendLayout();
            this.splDataData2.SuspendLayout();
            this.flPnlData.SuspendLayout();
            this.pnlDataHdr.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.pnlNumInfo);
            this.pnlMain.Controls.Add(this.lblTextLine);
            this.pnlMain.Controls.Add(this.chkIsMissingRxn);
            this.pnlMain.Controls.Add(this.rtxttextlinepreview);
            this.pnlMain.Controls.Add(this.cmbAnalogousTo);
            this.pnlMain.Controls.Add(this.chkIsAnalogous);
            this.pnlMain.Controls.Add(this.chkisgeneralprocempty);
            this.pnlMain.Controls.Add(this.chkisGeneralTypical);
            this.pnlMain.Controls.Add(this.btnDelete);
            this.pnlMain.Controls.Add(this.splCntparaData);
            this.pnlMain.Controls.Add(this.txtnarrativeid);
            this.pnlMain.Controls.Add(this.lblNarId);
            this.pnlMain.Controls.Add(this.tb1rtxteditor);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1029, 432);
            this.pnlMain.TabIndex = 0;
            // 
            // pnlNumInfo
            // 
            this.pnlNumInfo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlNumInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlNumInfo.Controls.Add(this.txtfilename);
            this.pnlNumInfo.Controls.Add(this.lblSeq);
            this.pnlNumInfo.Controls.Add(this.lblreactioncasreactonnumber);
            this.pnlNumInfo.Controls.Add(this.txtCASReactnumber);
            this.pnlNumInfo.Controls.Add(this.lblPageNumber);
            this.pnlNumInfo.Controls.Add(this.txtdocref);
            this.pnlNumInfo.Controls.Add(this.txtpagenumber);
            this.pnlNumInfo.Controls.Add(this.lblpglabel);
            this.pnlNumInfo.Controls.Add(this.txtrxnseq);
            this.pnlNumInfo.Controls.Add(this.txtpagelabel);
            this.pnlNumInfo.Controls.Add(this.txtyoffset);
            this.pnlNumInfo.Controls.Add(this.lbldocref);
            this.pnlNumInfo.Controls.Add(this.lblYoffSet);
            this.pnlNumInfo.Controls.Add(this.txtxoffset);
            this.pnlNumInfo.Controls.Add(this.lblfilename);
            this.pnlNumInfo.Controls.Add(this.lblXoffSet);
            this.pnlNumInfo.Controls.Add(this.lblXPageSize);
            this.pnlNumInfo.Controls.Add(this.lblYPageSize);
            this.pnlNumInfo.Controls.Add(this.txtypagesize);
            this.pnlNumInfo.Controls.Add(this.txtxpagesize);
            this.pnlNumInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlNumInfo.Location = new System.Drawing.Point(0, 0);
            this.pnlNumInfo.Name = "pnlNumInfo";
            this.pnlNumInfo.Size = new System.Drawing.Size(1029, 31);
            this.pnlNumInfo.TabIndex = 201;
            // 
            // txtfilename
            // 
            this.txtfilename.BackColor = System.Drawing.Color.White;
            this.txtfilename.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfilename.Location = new System.Drawing.Point(231, 4);
            this.txtfilename.Name = "txtfilename";
            this.txtfilename.ReadOnly = true;
            this.txtfilename.Size = new System.Drawing.Size(136, 21);
            this.txtfilename.TabIndex = 2;
            this.txtfilename.TextChanged += new System.EventHandler(this.txtCASReactnumber_TextChanged);
            // 
            // lblSeq
            // 
            this.lblSeq.AutoSize = true;
            this.lblSeq.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSeq.ForeColor = System.Drawing.Color.Crimson;
            this.lblSeq.Location = new System.Drawing.Point(70, 7);
            this.lblSeq.Name = "lblSeq";
            this.lblSeq.Size = new System.Drawing.Size(29, 15);
            this.lblSeq.TabIndex = 10;
            this.lblSeq.Text = "Seq";
            // 
            // lblreactioncasreactonnumber
            // 
            this.lblreactioncasreactonnumber.AutoSize = true;
            this.lblreactioncasreactonnumber.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblreactioncasreactonnumber.ForeColor = System.Drawing.Color.Crimson;
            this.lblreactioncasreactonnumber.Location = new System.Drawing.Point(-2, 6);
            this.lblreactioncasreactonnumber.Name = "lblreactioncasreactonnumber";
            this.lblreactioncasreactonnumber.Size = new System.Drawing.Size(34, 15);
            this.lblreactioncasreactonnumber.TabIndex = 4;
            this.lblreactioncasreactonnumber.Text = "Num";
            this.lblreactioncasreactonnumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtCASReactnumber
            // 
            this.txtCASReactnumber.BackColor = System.Drawing.Color.FloralWhite;
            this.txtCASReactnumber.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCASReactnumber.ForeColor = System.Drawing.Color.Blue;
            this.txtCASReactnumber.Location = new System.Drawing.Point(35, 3);
            this.txtCASReactnumber.Name = "txtCASReactnumber";
            this.txtCASReactnumber.ReadOnly = true;
            this.txtCASReactnumber.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtCASReactnumber.Size = new System.Drawing.Size(32, 21);
            this.txtCASReactnumber.TabIndex = 100;
            this.txtCASReactnumber.Text = "0";
            this.txtCASReactnumber.TextChanged += new System.EventHandler(this.txtCASReactnumber_TextChanged);
            // 
            // lblPageNumber
            // 
            this.lblPageNumber.AutoSize = true;
            this.lblPageNumber.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageNumber.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblPageNumber.Location = new System.Drawing.Point(373, 7);
            this.lblPageNumber.Name = "lblPageNumber";
            this.lblPageNumber.Size = new System.Drawing.Size(58, 15);
            this.lblPageNumber.TabIndex = 0;
            this.lblPageNumber.Text = "Page No.";
            // 
            // txtdocref
            // 
            this.txtdocref.BackColor = System.Drawing.Color.White;
            this.txtdocref.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdocref.Location = new System.Drawing.Point(162, 4);
            this.txtdocref.Name = "txtdocref";
            this.txtdocref.ReadOnly = true;
            this.txtdocref.Size = new System.Drawing.Size(44, 21);
            this.txtdocref.TabIndex = 1;
            this.txtdocref.Text = "doc1";
            this.txtdocref.TextChanged += new System.EventHandler(this.txtCASReactnumber_TextChanged);
            this.txtdocref.Leave += new System.EventHandler(this.txtdocref_Leave);
            // 
            // txtpagenumber
            // 
            this.txtpagenumber.BackColor = System.Drawing.Color.White;
            this.txtpagenumber.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpagenumber.Location = new System.Drawing.Point(431, 5);
            this.txtpagenumber.Multiline = true;
            this.txtpagenumber.Name = "txtpagenumber";
            this.txtpagenumber.Size = new System.Drawing.Size(41, 20);
            this.txtpagenumber.TabIndex = 2;
            this.txtpagenumber.TextChanged += new System.EventHandler(this.txtCASReactnumber_TextChanged);
            this.txtpagenumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtpagenumber_KeyPress);
            this.txtpagenumber.Leave += new System.EventHandler(this.txtpagenumber_Leave);
            // 
            // lblpglabel
            // 
            this.lblpglabel.AutoSize = true;
            this.lblpglabel.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpglabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblpglabel.Location = new System.Drawing.Point(481, 7);
            this.lblpglabel.Name = "lblpglabel";
            this.lblpglabel.Size = new System.Drawing.Size(70, 15);
            this.lblpglabel.TabIndex = 0;
            this.lblpglabel.Text = "Page Label";
            // 
            // txtrxnseq
            // 
            this.txtrxnseq.BackColor = System.Drawing.Color.FloralWhite;
            this.txtrxnseq.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrxnseq.ForeColor = System.Drawing.Color.Blue;
            this.txtrxnseq.Location = new System.Drawing.Point(101, 4);
            this.txtrxnseq.Name = "txtrxnseq";
            this.txtrxnseq.ReadOnly = true;
            this.txtrxnseq.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtrxnseq.Size = new System.Drawing.Size(31, 21);
            this.txtrxnseq.TabIndex = 102;
            this.txtrxnseq.Text = "0";
            this.txtrxnseq.TextChanged += new System.EventHandler(this.txtCASReactnumber_TextChanged);
            // 
            // txtpagelabel
            // 
            this.txtpagelabel.BackColor = System.Drawing.Color.White;
            this.txtpagelabel.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpagelabel.Location = new System.Drawing.Point(552, 4);
            this.txtpagelabel.Name = "txtpagelabel";
            this.txtpagelabel.Size = new System.Drawing.Size(39, 21);
            this.txtpagelabel.TabIndex = 3;
            this.txtpagelabel.TextChanged += new System.EventHandler(this.txtCASReactnumber_TextChanged);
            this.txtpagelabel.Leave += new System.EventHandler(this.txtpagelabel_Leave);
            // 
            // txtyoffset
            // 
            this.txtyoffset.BackColor = System.Drawing.Color.White;
            this.txtyoffset.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtyoffset.Location = new System.Drawing.Point(982, 4);
            this.txtyoffset.Multiline = true;
            this.txtyoffset.Name = "txtyoffset";
            this.txtyoffset.ReadOnly = true;
            this.txtyoffset.Size = new System.Drawing.Size(40, 20);
            this.txtyoffset.TabIndex = 7;
            this.txtyoffset.Click += new System.EventHandler(this.txtyoffset_Click);
            this.txtyoffset.TextChanged += new System.EventHandler(this.txtCASReactnumber_TextChanged);
            this.txtyoffset.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtyoffset_KeyPress);
            // 
            // lbldocref
            // 
            this.lbldocref.AutoSize = true;
            this.lbldocref.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldocref.ForeColor = System.Drawing.Color.Crimson;
            this.lbldocref.Location = new System.Drawing.Point(135, 7);
            this.lbldocref.Name = "lbldocref";
            this.lbldocref.Size = new System.Drawing.Size(29, 15);
            this.lbldocref.TabIndex = 5;
            this.lbldocref.Text = "Doc";
            // 
            // lblYoffSet
            // 
            this.lblYoffSet.AutoSize = true;
            this.lblYoffSet.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYoffSet.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblYoffSet.Location = new System.Drawing.Point(928, 7);
            this.lblYoffSet.Name = "lblYoffSet";
            this.lblYoffSet.Size = new System.Drawing.Size(53, 15);
            this.lblYoffSet.TabIndex = 7;
            this.lblYoffSet.Text = "Y Off Set";
            // 
            // txtxoffset
            // 
            this.txtxoffset.BackColor = System.Drawing.Color.White;
            this.txtxoffset.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtxoffset.Location = new System.Drawing.Point(887, 4);
            this.txtxoffset.Multiline = true;
            this.txtxoffset.Name = "txtxoffset";
            this.txtxoffset.ReadOnly = true;
            this.txtxoffset.Size = new System.Drawing.Size(40, 20);
            this.txtxoffset.TabIndex = 5;
            this.txtxoffset.Click += new System.EventHandler(this.txtxoffset_Click);
            this.txtxoffset.TextChanged += new System.EventHandler(this.txtCASReactnumber_TextChanged);
            this.txtxoffset.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtxoffset_KeyPress);
            // 
            // lblfilename
            // 
            this.lblfilename.AutoSize = true;
            this.lblfilename.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfilename.ForeColor = System.Drawing.Color.Crimson;
            this.lblfilename.Location = new System.Drawing.Point(206, 6);
            this.lblfilename.Name = "lblfilename";
            this.lblfilename.Size = new System.Drawing.Size(27, 15);
            this.lblfilename.TabIndex = 8;
            this.lblfilename.Text = "File";
            // 
            // lblXoffSet
            // 
            this.lblXoffSet.AutoSize = true;
            this.lblXoffSet.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblXoffSet.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblXoffSet.Location = new System.Drawing.Point(833, 7);
            this.lblXoffSet.Name = "lblXoffSet";
            this.lblXoffSet.Size = new System.Drawing.Size(53, 15);
            this.lblXoffSet.TabIndex = 7;
            this.lblXoffSet.Text = "X Off Set";
            // 
            // lblXPageSize
            // 
            this.lblXPageSize.AutoSize = true;
            this.lblXPageSize.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblXPageSize.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblXPageSize.Location = new System.Drawing.Point(596, 7);
            this.lblXPageSize.Name = "lblXPageSize";
            this.lblXPageSize.Size = new System.Drawing.Size(72, 15);
            this.lblXPageSize.TabIndex = 6;
            this.lblXPageSize.Text = "X Page Size";
            // 
            // lblYPageSize
            // 
            this.lblYPageSize.AutoSize = true;
            this.lblYPageSize.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYPageSize.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblYPageSize.Location = new System.Drawing.Point(713, 7);
            this.lblYPageSize.Name = "lblYPageSize";
            this.lblYPageSize.Size = new System.Drawing.Size(72, 15);
            this.lblYPageSize.TabIndex = 6;
            this.lblYPageSize.Text = "Y Page Size";
            // 
            // txtypagesize
            // 
            this.txtypagesize.BackColor = System.Drawing.Color.White;
            this.txtypagesize.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtypagesize.Location = new System.Drawing.Point(787, 5);
            this.txtypagesize.Multiline = true;
            this.txtypagesize.Name = "txtypagesize";
            this.txtypagesize.ReadOnly = true;
            this.txtypagesize.Size = new System.Drawing.Size(40, 20);
            this.txtypagesize.TabIndex = 6;
            this.txtypagesize.Click += new System.EventHandler(this.txtypagesize_Click);
            this.txtypagesize.TextChanged += new System.EventHandler(this.txtCASReactnumber_TextChanged);
            this.txtypagesize.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtypagesize_KeyPress);
            // 
            // txtxpagesize
            // 
            this.txtxpagesize.BackColor = System.Drawing.Color.White;
            this.txtxpagesize.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtxpagesize.Location = new System.Drawing.Point(669, 4);
            this.txtxpagesize.Multiline = true;
            this.txtxpagesize.Name = "txtxpagesize";
            this.txtxpagesize.ReadOnly = true;
            this.txtxpagesize.Size = new System.Drawing.Size(40, 20);
            this.txtxpagesize.TabIndex = 4;
            this.txtxpagesize.Click += new System.EventHandler(this.txtxpagesize_Click);
            this.txtxpagesize.TextChanged += new System.EventHandler(this.txtCASReactnumber_TextChanged);
            this.txtxpagesize.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtxpagesize_KeyPress);
            // 
            // lblTextLine
            // 
            this.lblTextLine.AutoSize = true;
            this.lblTextLine.BackColor = System.Drawing.Color.White;
            this.lblTextLine.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTextLine.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblTextLine.Location = new System.Drawing.Point(2, 67);
            this.lblTextLine.Name = "lblTextLine";
            this.lblTextLine.Size = new System.Drawing.Size(54, 15);
            this.lblTextLine.TabIndex = 57;
            this.lblTextLine.Text = "Text line";
            // 
            // chkIsMissingRxn
            // 
            this.chkIsMissingRxn.AutoSize = true;
            this.chkIsMissingRxn.BackColor = System.Drawing.Color.White;
            this.chkIsMissingRxn.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIsMissingRxn.Location = new System.Drawing.Point(778, 40);
            this.chkIsMissingRxn.Name = "chkIsMissingRxn";
            this.chkIsMissingRxn.Size = new System.Drawing.Size(121, 19);
            this.chkIsMissingRxn.TabIndex = 12;
            this.chkIsMissingRxn.Text = "Missing Reaction";
            this.chkIsMissingRxn.UseVisualStyleBackColor = false;
            this.chkIsMissingRxn.Click += new System.EventHandler(this.chkIsMissingRxn_Click);
            // 
            // rtxttextlinepreview
            // 
            this.rtxttextlinepreview.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rtxttextlinepreview.BackColor = System.Drawing.Color.White;
            this.rtxttextlinepreview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rtxttextlinepreview.ContextMenuStrip = this.contextMenuStrip1;
            this.rtxttextlinepreview.Location = new System.Drawing.Point(56, 64);
            this.rtxttextlinepreview.Name = "rtxttextlinepreview";
            this.rtxttextlinepreview.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.rtxttextlinepreview.Size = new System.Drawing.Size(969, 47);
            this.rtxttextlinepreview.TabIndex = 13;
            this.rtxttextlinepreview.Text = "";
            this.rtxttextlinepreview.Click += new System.EventHandler(this.rtxttextlinepreview_Click);
            this.rtxttextlinepreview.TextChanged += new System.EventHandler(this.rtxttextlinepreview_TextChanged_1);
            this.rtxttextlinepreview.KeyDown += new System.Windows.Forms.KeyEventHandler(this.rtxttextlinepreview_KeyDown);
            this.rtxttextlinepreview.Leave += new System.EventHandler(this.rtxttextlinepreview_Leave);
            this.rtxttextlinepreview.MouseDown += new System.Windows.Forms.MouseEventHandler(this.rtxttextlinepreview_MouseDown);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.BackColor = System.Drawing.Color.White;
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsPaste,
            this.tsWordWrap,
            this.TshScrollbar,
            this.tsvscrollbars,
            this.tsboth,
            this.transferToTextEditorToolStripMenuItem,
            this.formatToolStripMenuItem,
            this.clearBackColorToolStripMenuItem,
            this.addDataToolStripMenuItem,
            this.spellCheckToolStripMenuItem,
            this.copyXYOffsetsToolStripMenuItem,
            this.tsnsubscript,
            this.superscriptToolStripMenuItem,
            this.italicToolStripMenuItem,
            this.boldToolStripMenuItem,
            this.addParaToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(207, 356);
            // 
            // TsPaste
            // 
            this.TsPaste.BackColor = System.Drawing.Color.White;
            this.TsPaste.Name = "TsPaste";
            this.TsPaste.Size = new System.Drawing.Size(206, 22);
            this.TsPaste.Text = "Paste";
            this.TsPaste.Visible = false;
            this.TsPaste.Click += new System.EventHandler(this.TsPaste_Click);
            // 
            // tsWordWrap
            // 
            this.tsWordWrap.BackColor = System.Drawing.Color.White;
            this.tsWordWrap.Checked = true;
            this.tsWordWrap.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsWordWrap.Name = "tsWordWrap";
            this.tsWordWrap.Size = new System.Drawing.Size(206, 22);
            this.tsWordWrap.Text = "WordWrap";
            this.tsWordWrap.Click += new System.EventHandler(this.tsWordWrap_Click);
            // 
            // TshScrollbar
            // 
            this.TshScrollbar.BackColor = System.Drawing.Color.White;
            this.TshScrollbar.Name = "TshScrollbar";
            this.TshScrollbar.Size = new System.Drawing.Size(206, 22);
            this.TshScrollbar.Text = "Horizontal Scrollbars";
            this.TshScrollbar.Click += new System.EventHandler(this.TshScrollbar_Click);
            // 
            // tsvscrollbars
            // 
            this.tsvscrollbars.BackColor = System.Drawing.Color.White;
            this.tsvscrollbars.Name = "tsvscrollbars";
            this.tsvscrollbars.Size = new System.Drawing.Size(206, 22);
            this.tsvscrollbars.Text = "Vertical Scrollbars";
            this.tsvscrollbars.Click += new System.EventHandler(this.tsvscrollbars_Click);
            // 
            // tsboth
            // 
            this.tsboth.BackColor = System.Drawing.Color.White;
            this.tsboth.Name = "tsboth";
            this.tsboth.Size = new System.Drawing.Size(206, 22);
            this.tsboth.Text = "Both";
            this.tsboth.Click += new System.EventHandler(this.tsboth_Click);
            // 
            // transferToTextEditorToolStripMenuItem
            // 
            this.transferToTextEditorToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.transferToTextEditorToolStripMenuItem.Name = "transferToTextEditorToolStripMenuItem";
            this.transferToTextEditorToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F8;
            this.transferToTextEditorToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.transferToTextEditorToolStripMenuItem.Text = "Transfer to TextEditor";
            this.transferToTextEditorToolStripMenuItem.Click += new System.EventHandler(this.transferToTextEditorToolStripMenuItem_Click);
            // 
            // formatToolStripMenuItem
            // 
            this.formatToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.formatToolStripMenuItem.Name = "formatToolStripMenuItem";
            this.formatToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F9;
            this.formatToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.formatToolStripMenuItem.Text = "Format";
            this.formatToolStripMenuItem.Click += new System.EventHandler(this.formatToolStripMenuItem_Click);
            // 
            // clearBackColorToolStripMenuItem
            // 
            this.clearBackColorToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.clearBackColorToolStripMenuItem.Name = "clearBackColorToolStripMenuItem";
            this.clearBackColorToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F10;
            this.clearBackColorToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.clearBackColorToolStripMenuItem.Text = "Clear BackColor";
            this.clearBackColorToolStripMenuItem.Click += new System.EventHandler(this.clearBackColorToolStripMenuItem_Click);
            // 
            // addDataToolStripMenuItem
            // 
            this.addDataToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.addDataToolStripMenuItem.Name = "addDataToolStripMenuItem";
            this.addDataToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.addDataToolStripMenuItem.Text = "Add Data";
            this.addDataToolStripMenuItem.Click += new System.EventHandler(this.addDataToolStripMenuItem_Click);
            // 
            // spellCheckToolStripMenuItem
            // 
            this.spellCheckToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.spellCheckToolStripMenuItem.Name = "spellCheckToolStripMenuItem";
            this.spellCheckToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F12;
            this.spellCheckToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.spellCheckToolStripMenuItem.Text = "SpellCheck";
            this.spellCheckToolStripMenuItem.Click += new System.EventHandler(this.spellCheckToolStripMenuItem_Click);
            // 
            // copyXYOffsetsToolStripMenuItem
            // 
            this.copyXYOffsetsToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.copyXYOffsetsToolStripMenuItem.Name = "copyXYOffsetsToolStripMenuItem";
            this.copyXYOffsetsToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.copyXYOffsetsToolStripMenuItem.Text = "Copy XY offsets";
            this.copyXYOffsetsToolStripMenuItem.Visible = false;
            // 
            // tsnsubscript
            // 
            this.tsnsubscript.BackColor = System.Drawing.Color.White;
            this.tsnsubscript.Name = "tsnsubscript";
            this.tsnsubscript.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.tsnsubscript.Size = new System.Drawing.Size(206, 22);
            this.tsnsubscript.Text = "Subscript";
            this.tsnsubscript.Click += new System.EventHandler(this.tsnsubscript_Click);
            // 
            // superscriptToolStripMenuItem
            // 
            this.superscriptToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.superscriptToolStripMenuItem.Name = "superscriptToolStripMenuItem";
            this.superscriptToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F3;
            this.superscriptToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.superscriptToolStripMenuItem.Text = "Superscript";
            this.superscriptToolStripMenuItem.Click += new System.EventHandler(this.superscriptToolStripMenuItem_Click);
            // 
            // italicToolStripMenuItem
            // 
            this.italicToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.italicToolStripMenuItem.Name = "italicToolStripMenuItem";
            this.italicToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F4;
            this.italicToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.italicToolStripMenuItem.Text = "Italic";
            this.italicToolStripMenuItem.Click += new System.EventHandler(this.italicToolStripMenuItem_Click);
            // 
            // boldToolStripMenuItem
            // 
            this.boldToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.boldToolStripMenuItem.Name = "boldToolStripMenuItem";
            this.boldToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5;
            this.boldToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.boldToolStripMenuItem.Text = "Bold";
            this.boldToolStripMenuItem.Click += new System.EventHandler(this.boldToolStripMenuItem_Click);
            // 
            // addParaToolStripMenuItem
            // 
            this.addParaToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.addParaToolStripMenuItem.Name = "addParaToolStripMenuItem";
            this.addParaToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.addParaToolStripMenuItem.Text = "Add Para";
            this.addParaToolStripMenuItem.Click += new System.EventHandler(this.addParaToolStripMenuItem_Click);
            // 
            // cmbAnalogousTo
            // 
            this.cmbAnalogousTo.BackColor = System.Drawing.Color.White;
            this.cmbAnalogousTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAnalogousTo.FormattingEnabled = true;
            this.cmbAnalogousTo.Location = new System.Drawing.Point(252, 36);
            this.cmbAnalogousTo.Name = "cmbAnalogousTo";
            this.cmbAnalogousTo.Size = new System.Drawing.Size(102, 24);
            this.cmbAnalogousTo.TabIndex = 9;
            this.cmbAnalogousTo.Visible = false;
            this.cmbAnalogousTo.SelectionChangeCommitted += new System.EventHandler(this.cmbAnalogousTo_SelectionChangeCommitted);
            // 
            // chkIsAnalogous
            // 
            this.chkIsAnalogous.AutoSize = true;
            this.chkIsAnalogous.BackColor = System.Drawing.Color.White;
            this.chkIsAnalogous.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIsAnalogous.Location = new System.Drawing.Point(138, 39);
            this.chkIsAnalogous.Name = "chkIsAnalogous";
            this.chkIsAnalogous.Size = new System.Drawing.Size(113, 19);
            this.chkIsAnalogous.TabIndex = 8;
            this.chkIsAnalogous.Text = "Is Analogous To";
            this.chkIsAnalogous.UseVisualStyleBackColor = false;
            this.chkIsAnalogous.CheckStateChanged += new System.EventHandler(this.chkIsAnalogous_CheckStateChanged);
            // 
            // chkisgeneralprocempty
            // 
            this.chkisgeneralprocempty.AutoSize = true;
            this.chkisgeneralprocempty.BackColor = System.Drawing.Color.White;
            this.chkisgeneralprocempty.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkisgeneralprocempty.Location = new System.Drawing.Point(613, 39);
            this.chkisgeneralprocempty.Name = "chkisgeneralprocempty";
            this.chkisgeneralprocempty.Size = new System.Drawing.Size(159, 19);
            this.chkisgeneralprocempty.TabIndex = 11;
            this.chkisgeneralprocempty.Text = "No Experimental Details";
            this.chkisgeneralprocempty.UseVisualStyleBackColor = false;
            this.chkisgeneralprocempty.Click += new System.EventHandler(this.chkisgeneralprocempty_Click);
            // 
            // chkisGeneralTypical
            // 
            this.chkisGeneralTypical.AutoSize = true;
            this.chkisGeneralTypical.BackColor = System.Drawing.Color.White;
            this.chkisGeneralTypical.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkisGeneralTypical.Location = new System.Drawing.Point(485, 39);
            this.chkisGeneralTypical.Name = "chkisGeneralTypical";
            this.chkisGeneralTypical.Size = new System.Drawing.Size(117, 19);
            this.chkisGeneralTypical.TabIndex = 10;
            this.chkisGeneralTypical.Text = "IsGeneralTypical";
            this.chkisGeneralTypical.UseVisualStyleBackColor = false;
            this.chkisGeneralTypical.Click += new System.EventHandler(this.chkisGeneralTypical_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.White;
            this.btnDelete.Enabled = false;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.Location = new System.Drawing.Point(1002, 35);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(21, 23);
            this.btnDelete.TabIndex = 68;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Visible = false;
            // 
            // splCntparaData
            // 
            this.splCntparaData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splCntparaData.BackColor = System.Drawing.Color.White;
            this.splCntparaData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splCntparaData.Location = new System.Drawing.Point(2, 117);
            this.splCntparaData.Name = "splCntparaData";
            this.splCntparaData.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splCntparaData.Panel1
            // 
            this.splCntparaData.Panel1.Controls.Add(this.flPnlPara);
            this.splCntparaData.Panel1.Controls.Add(this.pnlParaHdr);
            // 
            // splCntparaData.Panel2
            // 
            this.splCntparaData.Panel2.Controls.Add(this.splDataData2);
            this.splCntparaData.Size = new System.Drawing.Size(1024, 310);
            this.splCntparaData.SplitterDistance = 167;
            this.splCntparaData.TabIndex = 67;
            // 
            // flPnlPara
            // 
            this.flPnlPara.AutoScroll = true;
            this.flPnlPara.BackColor = System.Drawing.Color.WhiteSmoke;
            this.flPnlPara.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flPnlPara.Controls.Add(this.ucHtmlRichText1);
            this.flPnlPara.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flPnlPara.Location = new System.Drawing.Point(0, 29);
            this.flPnlPara.Name = "flPnlPara";
            this.flPnlPara.Size = new System.Drawing.Size(1022, 136);
            this.flPnlPara.TabIndex = 1;
            // 
            // ucHtmlRichText1
            // 
            this.ucHtmlRichText1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ucHtmlRichText1.Location = new System.Drawing.Point(3, 3);
            this.ucHtmlRichText1.Name = "ucHtmlRichText1";
            this.ucHtmlRichText1.Size = new System.Drawing.Size(994, 69);
            this.ucHtmlRichText1.TabIndex = 0;
            // 
            // pnlParaHdr
            // 
            this.pnlParaHdr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlParaHdr.Controls.Add(this.lblParaCnt);
            this.pnlParaHdr.Controls.Add(this.label1);
            this.pnlParaHdr.Controls.Add(this.lnkAddPara);
            this.pnlParaHdr.Controls.Add(this.btnDeletePara);
            this.pnlParaHdr.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlParaHdr.Location = new System.Drawing.Point(0, 0);
            this.pnlParaHdr.Name = "pnlParaHdr";
            this.pnlParaHdr.Size = new System.Drawing.Size(1022, 29);
            this.pnlParaHdr.TabIndex = 0;
            // 
            // lblParaCnt
            // 
            this.lblParaCnt.AutoSize = true;
            this.lblParaCnt.BackColor = System.Drawing.Color.White;
            this.lblParaCnt.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParaCnt.ForeColor = System.Drawing.Color.Red;
            this.lblParaCnt.Location = new System.Drawing.Point(195, 5);
            this.lblParaCnt.Name = "lblParaCnt";
            this.lblParaCnt.Size = new System.Drawing.Size(14, 15);
            this.lblParaCnt.TabIndex = 72;
            this.lblParaCnt.Text = "1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(114, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 15);
            this.label1.TabIndex = 71;
            this.label1.Text = "Para Count: ";
            // 
            // lnkAddPara
            // 
            this.lnkAddPara.AutoSize = true;
            this.lnkAddPara.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkAddPara.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkAddPara.Location = new System.Drawing.Point(2, 5);
            this.lnkAddPara.Name = "lnkAddPara";
            this.lnkAddPara.Size = new System.Drawing.Size(38, 16);
            this.lnkAddPara.TabIndex = 70;
            this.lnkAddPara.TabStop = true;
            this.lnkAddPara.Text = "Para";
            this.toolTip1.SetToolTip(this.lnkAddPara, "Add Para");
            this.lnkAddPara.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkAddPara_LinkClicked);
            // 
            // btnDeletePara
            // 
            this.btnDeletePara.BackColor = System.Drawing.Color.White;
            this.btnDeletePara.Enabled = false;
            this.btnDeletePara.Image = global::IndxReactNarr.Properties.Resources.close_box_red;
            this.btnDeletePara.Location = new System.Drawing.Point(51, 3);
            this.btnDeletePara.Name = "btnDeletePara";
            this.btnDeletePara.Size = new System.Drawing.Size(20, 20);
            this.btnDeletePara.TabIndex = 69;
            this.toolTip1.SetToolTip(this.btnDeletePara, "Delete Selected Para");
            this.btnDeletePara.UseVisualStyleBackColor = false;
            this.btnDeletePara.Visible = false;
            this.btnDeletePara.Click += new System.EventHandler(this.btnDeletePara_Click);
            // 
            // splDataData2
            // 
            this.splDataData2.BackColor = System.Drawing.Color.White;
            this.splDataData2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splDataData2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splDataData2.Location = new System.Drawing.Point(0, 0);
            this.splDataData2.Name = "splDataData2";
            this.splDataData2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splDataData2.Panel1
            // 
            this.splDataData2.Panel1.Controls.Add(this.flPnlData);
            this.splDataData2.Panel1.Controls.Add(this.pnlDataHdr);
            // 
            // splDataData2.Panel2
            // 
            this.splDataData2.Panel2.Controls.Add(this.lblData2);
            this.splDataData2.Panel2.Controls.Add(this.rtxtdata1);
            this.splDataData2.Panel2Collapsed = true;
            this.splDataData2.Size = new System.Drawing.Size(1024, 139);
            this.splDataData2.SplitterDistance = 84;
            this.splDataData2.TabIndex = 21;
            // 
            // flPnlData
            // 
            this.flPnlData.AutoScroll = true;
            this.flPnlData.BackColor = System.Drawing.Color.WhiteSmoke;
            this.flPnlData.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flPnlData.Controls.Add(this.ucHtmlRichText3);
            this.flPnlData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flPnlData.Location = new System.Drawing.Point(0, 29);
            this.flPnlData.Name = "flPnlData";
            this.flPnlData.Size = new System.Drawing.Size(1022, 108);
            this.flPnlData.TabIndex = 2;
            // 
            // ucHtmlRichText3
            // 
            this.ucHtmlRichText3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ucHtmlRichText3.Location = new System.Drawing.Point(3, 3);
            this.ucHtmlRichText3.Name = "ucHtmlRichText3";
            this.ucHtmlRichText3.Size = new System.Drawing.Size(994, 69);
            this.ucHtmlRichText3.TabIndex = 1;
            // 
            // pnlDataHdr
            // 
            this.pnlDataHdr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlDataHdr.Controls.Add(this.lblDataCnt);
            this.pnlDataHdr.Controls.Add(this.label3);
            this.pnlDataHdr.Controls.Add(this.lnkData);
            this.pnlDataHdr.Controls.Add(this.btnDeleteData);
            this.pnlDataHdr.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlDataHdr.Location = new System.Drawing.Point(0, 0);
            this.pnlDataHdr.Name = "pnlDataHdr";
            this.pnlDataHdr.Size = new System.Drawing.Size(1022, 29);
            this.pnlDataHdr.TabIndex = 1;
            // 
            // lblDataCnt
            // 
            this.lblDataCnt.AutoSize = true;
            this.lblDataCnt.BackColor = System.Drawing.Color.White;
            this.lblDataCnt.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataCnt.ForeColor = System.Drawing.Color.Red;
            this.lblDataCnt.Location = new System.Drawing.Point(195, 6);
            this.lblDataCnt.Name = "lblDataCnt";
            this.lblDataCnt.Size = new System.Drawing.Size(14, 15);
            this.lblDataCnt.TabIndex = 74;
            this.lblDataCnt.Text = "1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(114, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 15);
            this.label3.TabIndex = 73;
            this.label3.Text = "Data Count: ";
            // 
            // lnkData
            // 
            this.lnkData.AutoSize = true;
            this.lnkData.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkData.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkData.Location = new System.Drawing.Point(2, 5);
            this.lnkData.Name = "lnkData";
            this.lnkData.Size = new System.Drawing.Size(37, 16);
            this.lnkData.TabIndex = 70;
            this.lnkData.TabStop = true;
            this.lnkData.Text = "Data";
            this.toolTip1.SetToolTip(this.lnkData, "Add Data");
            this.lnkData.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkData_LinkClicked);
            // 
            // btnDeleteData
            // 
            this.btnDeleteData.BackColor = System.Drawing.Color.White;
            this.btnDeleteData.Enabled = false;
            this.btnDeleteData.Image = global::IndxReactNarr.Properties.Resources.close_box_red;
            this.btnDeleteData.Location = new System.Drawing.Point(51, 3);
            this.btnDeleteData.Name = "btnDeleteData";
            this.btnDeleteData.Size = new System.Drawing.Size(20, 20);
            this.btnDeleteData.TabIndex = 69;
            this.toolTip1.SetToolTip(this.btnDeleteData, "Delete Seleted Data");
            this.btnDeleteData.UseVisualStyleBackColor = false;
            this.btnDeleteData.Visible = false;
            this.btnDeleteData.Click += new System.EventHandler(this.btnDeleteData_Click);
            // 
            // lblData2
            // 
            this.lblData2.AutoSize = true;
            this.lblData2.BackColor = System.Drawing.Color.White;
            this.lblData2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblData2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblData2.Location = new System.Drawing.Point(6, 0);
            this.lblData2.Name = "lblData2";
            this.lblData2.Size = new System.Drawing.Size(46, 14);
            this.lblData2.TabIndex = 63;
            this.lblData2.Text = "Data2 : ";
            // 
            // rtxtdata1
            // 
            this.rtxtdata1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rtxtdata1.BackColor = System.Drawing.Color.White;
            this.rtxtdata1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rtxtdata1.ContextMenuStrip = this.contextMenuStrip1;
            this.rtxtdata1.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtxtdata1.Location = new System.Drawing.Point(4, 15);
            this.rtxtdata1.Name = "rtxtdata1";
            this.rtxtdata1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.rtxtdata1.Size = new System.Drawing.Size(785, 89);
            this.rtxtdata1.TabIndex = 20;
            this.rtxtdata1.Text = "";
            this.rtxtdata1.TextChanged += new System.EventHandler(this.rtxttextlinepreview_TextChanged_1);
            this.rtxtdata1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.rtxtdata1_KeyDown);
            this.rtxtdata1.Leave += new System.EventHandler(this.rtxtdata1_Leave);
            // 
            // txtnarrativeid
            // 
            this.txtnarrativeid.BackColor = System.Drawing.Color.FloralWhite;
            this.txtnarrativeid.Location = new System.Drawing.Point(56, 37);
            this.txtnarrativeid.Name = "txtnarrativeid";
            this.txtnarrativeid.ReadOnly = true;
            this.txtnarrativeid.Size = new System.Drawing.Size(56, 22);
            this.txtnarrativeid.TabIndex = 103;
            this.txtnarrativeid.Text = "nar";
            this.txtnarrativeid.TextChanged += new System.EventHandler(this.txtCASReactnumber_TextChanged);
            // 
            // lblNarId
            // 
            this.lblNarId.AutoSize = true;
            this.lblNarId.BackColor = System.Drawing.Color.White;
            this.lblNarId.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNarId.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblNarId.Location = new System.Drawing.Point(7, 40);
            this.lblNarId.Name = "lblNarId";
            this.lblNarId.Size = new System.Drawing.Size(46, 15);
            this.lblNarId.TabIndex = 58;
            this.lblNarId.Text = "Narr ID";
            // 
            // tb1rtxteditor
            // 
            this.tb1rtxteditor.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb1rtxteditor.BackColor = System.Drawing.Color.White;
            this.tb1rtxteditor.DefaultComposeSettings.BackColor = System.Drawing.Color.White;
            this.tb1rtxteditor.DefaultComposeSettings.DefaultFont = new System.Drawing.Font("Arial", 10F);
            this.tb1rtxteditor.DefaultComposeSettings.Enabled = false;
            this.tb1rtxteditor.DefaultComposeSettings.ForeColor = System.Drawing.Color.Black;
            this.tb1rtxteditor.DocumentEncoding = onlyconnect.EncodingType.WindowsCurrent;
            this.tb1rtxteditor.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb1rtxteditor.IsDesignMode = true;
            this.tb1rtxteditor.Location = new System.Drawing.Point(117, 181);
            this.tb1rtxteditor.Margin = new System.Windows.Forms.Padding(10);
            this.tb1rtxteditor.Name = "tb1rtxteditor";
            this.tb1rtxteditor.OpenLinksInNewWindow = true;
            this.tb1rtxteditor.SelectionAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb1rtxteditor.SelectionBackColor = System.Drawing.Color.Empty;
            this.tb1rtxteditor.SelectionBullets = false;
            this.tb1rtxteditor.SelectionFont = null;
            this.tb1rtxteditor.SelectionForeColor = System.Drawing.Color.Empty;
            this.tb1rtxteditor.SelectionNumbering = false;
            this.tb1rtxteditor.Size = new System.Drawing.Size(795, 71);
            this.tb1rtxteditor.TabIndex = 66;
            this.tb1rtxteditor.Tag = "";
            this.tb1rtxteditor.Visible = false;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.BackColor = System.Drawing.Color.White;
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(160, 26);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.BackColor = System.Drawing.Color.White;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(159, 22);
            this.toolStripMenuItem1.Text = "Copy XY Offsets";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // uccasnartool_new
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ContextMenuStrip = this.contextMenuStrip2;
            this.Controls.Add(this.pnlMain);
            this.Name = "uccasnartool_new";
            this.Size = new System.Drawing.Size(1029, 432);
            this.Load += new System.EventHandler(this.uccasnartool_Load);
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.pnlNumInfo.ResumeLayout(false);
            this.pnlNumInfo.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.splCntparaData.Panel1.ResumeLayout(false);
            this.splCntparaData.Panel2.ResumeLayout(false);
            this.splCntparaData.ResumeLayout(false);
            this.flPnlPara.ResumeLayout(false);
            this.pnlParaHdr.ResumeLayout(false);
            this.pnlParaHdr.PerformLayout();
            this.splDataData2.Panel1.ResumeLayout(false);
            this.splDataData2.Panel2.ResumeLayout(false);
            this.splDataData2.Panel2.PerformLayout();
            this.splDataData2.ResumeLayout(false);
            this.flPnlData.ResumeLayout(false);
            this.pnlDataHdr.ResumeLayout(false);
            this.pnlDataHdr.PerformLayout();
            this.contextMenuStrip2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblNarId;
        private System.Windows.Forms.Label lblTextLine;
        private System.Windows.Forms.Label lblYoffSet;
        private System.Windows.Forms.Label lblpglabel;
        private System.Windows.Forms.Label lblYPageSize;
        private System.Windows.Forms.Label lblXoffSet;
        private System.Windows.Forms.Label lblXPageSize;
        private System.Windows.Forms.Label lblPageNumber;
        private System.Windows.Forms.Label lblreactioncasreactonnumber;
        private System.Windows.Forms.Label lbldocref;
        private System.Windows.Forms.Label lblfilename;
        private System.Windows.Forms.Label lblSeq;
        public System.Windows.Forms.TextBox txtnarrativeid;
        public System.Windows.Forms.TextBox txtyoffset;
        public System.Windows.Forms.TextBox txtypagesize;
        public System.Windows.Forms.TextBox txtpagelabel;
        public System.Windows.Forms.TextBox txtxoffset;
        public System.Windows.Forms.TextBox txtxpagesize;
        public System.Windows.Forms.TextBox txtpagenumber;
        public System.Windows.Forms.TextBox txtrxnseq;
        public System.Windows.Forms.TextBox txtCASReactnumber;
        public System.Windows.Forms.TextBox txtfilename;
        public System.Windows.Forms.TextBox txtdocref;
        public HtmlRichText.HtmlRichTextBox rtxttextlinepreview;
        private onlyconnect.HtmlEditor tb1rtxteditor;
        public System.Windows.Forms.Panel pnlMain;
        public System.Windows.Forms.SplitContainer splCntparaData;
        private System.Windows.Forms.ToolStripMenuItem tsWordWrap;
        private System.Windows.Forms.ToolStripMenuItem TshScrollbar;
        private System.Windows.Forms.ToolStripMenuItem tsvscrollbars;
        private System.Windows.Forms.ToolStripMenuItem tsboth;
        public System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        public System.Windows.Forms.ToolStripMenuItem transferToTextEditorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearBackColorToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem TsPaste;
        private System.Windows.Forms.ToolStripMenuItem formatToolStripMenuItem;
        public HtmlRichText.HtmlRichTextBox rtxtdata1;
        private System.Windows.Forms.Label lblData2;
        public System.Windows.Forms.SplitContainer splDataData2;
        private System.Windows.Forms.ToolStripMenuItem addDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spellCheckToolStripMenuItem;
        public System.Windows.Forms.CheckBox chkisGeneralTypical;
        private System.Windows.Forms.ToolStripMenuItem copyXYOffsetsToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        public System.Windows.Forms.CheckBox chkisgeneralprocempty;
        private System.Windows.Forms.ToolStripMenuItem tsnsubscript;
        private System.Windows.Forms.ToolStripMenuItem superscriptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem italicToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem boldToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addParaToolStripMenuItem;
        public System.Windows.Forms.CheckBox chkIsAnalogous;
        public System.Windows.Forms.ComboBox cmbAnalogousTo;
        public System.Windows.Forms.CheckBox chkIsMissingRxn;
        private System.Windows.Forms.Panel pnlNumInfo;
        public System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Panel pnlParaHdr;
        private System.Windows.Forms.FlowLayoutPanel flPnlPara;
        public System.Windows.Forms.Button btnDeletePara;
        private UserControls.ucHtmlRichText ucHtmlRichText1;
        private System.Windows.Forms.LinkLabel lnkAddPara;
        private System.Windows.Forms.Panel pnlDataHdr;
        private System.Windows.Forms.LinkLabel lnkData;
        public System.Windows.Forms.Button btnDeleteData;
        private System.Windows.Forms.FlowLayoutPanel flPnlData;
        private UserControls.ucHtmlRichText ucHtmlRichText3;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label lblParaCnt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblDataCnt;
        private System.Windows.Forms.Label label3;
    }
}
