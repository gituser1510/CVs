﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Collections;
using System.IO;
//using mshtml;
using HtmlRichText;
using System.Text.RegularExpressions;
using IndxReactNarrBLL;
using IndxReactNarr.Generic;
using IndxReactNarrBll;
using IndxReactNarr.UserControls;
using IndxReactNarr.Common;

namespace IndxReactNarr
{
    public partial class ucNarCuration : UserControl
    {
        public ucNarCuration()
        {
            InitializeComponent();
        }

        public int documentid = 0;
        public int reactionID = 0;
        //public int rowindex = 0;
        DataSet dsFandR = new DataSet();

        private DataSet _dsFandR = null;
        public DataSet DsFindAndReplace
        {
            get { return _dsFandR; }
            set { _dsFandR = value; }
        }

        public int Rxn_ID { get; set; }

        public DataTable TAN_Reactions { get; set; }
        public DataTable TAN_Documents { get; set; }
        public DataTable AnalogousRxns { get; set; }

        public string TANType { get; set; }

        string paraSplitter = "``PARA``";
        string dataSplitter = "``DATA``";

        /// <summary>
        /// Handles the Load event of the uccasnartool control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void uccasnartool_Load(object sender, EventArgs e)
        {
            try
            {
                //if (!Generic.globalVariables.IsPatent)
                //{
                //    chkisGeneralTypical.Enabled = false;
                //    chkisgeneralprocempty.Enabled = false;
                //}

                //if (Generic.globalVariables.IsPatent)
                //{
                //    txtdocref.ReadOnly = true;
                //    txtdocref.Text = "doc1";
                //}
                //else
                //{
                //    txtdocref.Text = "";
                //    txtdocref.ReadOnly = false;
                //}

                //htsymbols = HtFindAndReplace;
                // FillDocrefs();
                //                FillRXNNum();
                // FillCasReactnum();
                //  FillCasReactSequences();

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public void SetRxnDocRefFileName(int docID)
        {
            try
            {
                if (docID > 0 && TAN_Documents != null)
                {
                    var rxnDocs = from row in TAN_Documents.AsEnumerable()
                                  where row.Field<Int64>("TAN_DOC_ID") == docID
                                  select row;
                    if (rxnDocs != null)
                    {
                        foreach (var r in rxnDocs)
                        {
                            txtDocRef.Text = r["FILE_TYPE1"].ToString();
                            txtDocRef.Tag = r["TAN_DOC_ID"].ToString();
                            txtDocRefFileName.Text = r["FILE_NAME"].ToString();

                            txtPageSize_X.Text = r["PAGE_SIZE_X"].ToString();
                            txtPageSize_Y.Text = r["PAGE_SIZE_Y"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void ClearControlValues()
        {
            try
            {
                txtRxnNum.Clear();
                txtRxnSeq.Clear();
                txtPageNo.Clear();
                txtPageLabel.Clear();
                txtOffset_X.Clear();
                txtOffset_Y.Clear();
                txtPageSize_X.Clear();
                txtPageSize_Y.Clear();
                txtNarrID.Clear();

                txtDocRef.Clear();
                txtDocRefFileName.Clear();

                //rbnAnalogousTo.Checked = false;
                //rbnGeneralTypical.Checked = false;
                //rbnMissingRxn.Checked = false;

                rbnExpProcedure.Checked = true;

                ucHrtbTextLine.hrtbPara.Clear();

                flPnlData.Controls.Clear();
                flPnlPara.Controls.Clear();

                lblDataCnt.Text = "0";
                lblParaCnt.Text = "0";
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #region Allow Numbers,Dot,Hyphen,BackSpace when keypress

        private void txtpagenumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            AllowNumsBackSpaceDotAndHyphen(e);
        }

        private void txtxoffset_KeyPress(object sender, KeyPressEventArgs e)
        {
            AllowNumsBackSpaceDotAndHyphen(e);
        }

        private void txtyoffset_KeyPress(object sender, KeyPressEventArgs e)
        {
            AllowNumsBackSpaceDotAndHyphen(e);
        }

        private void txtypagesize_KeyPress(object sender, KeyPressEventArgs e)
        {
            AllowNumsBackSpaceDotAndHyphen(e);
        }

        private void txtxpagesize_KeyPress(object sender, KeyPressEventArgs e)
        {
            AllowNumsBackSpaceDotAndHyphen(e);
        }

        private static void AllowNumsBackSpaceDotAndHyphen(KeyPressEventArgs e)
        {
            try
            {
                // Asci--------char
                //   48         '0'
                //   57         '9'
                //    8         'BackSpace'
                //   46         '.'
                //   45         '-'
                if (((e.KeyChar >= 48 && e.KeyChar <= 57) || e.KeyChar == 8 || e.KeyChar == 46 || e.KeyChar == 45) != true)
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }


        #endregion

        /// <summary>
        /// Gets Html data from the FlowLayoutPanel
        /// </summary>
        /// <param name="controlType"></param>
        /// <returns>Html string</returns>
        private string GetPara_DataFromControls(string controlType)
        {
            string strPara_Data = "";
            try
            {
                FlowLayoutPanel flPanel = null;
                string strSplitter = "";
                if (controlType.ToUpper() == "PARA")
                {
                    flPanel = flPnlPara;
                    strSplitter = paraSplitter;
                }
                else if (controlType.ToUpper() == "DATA")
                {
                    flPanel = flPnlData;
                    strSplitter = dataSplitter;
                }

                if (flPanel != null)
                {
                    if (flPanel.Controls.Count > 0)
                    {
                        for (int i = 0; i < flPanel.Controls.Count; i++)
                        {
                            ucHtmlRichText ucHrtb = flPanel.Controls[i] as ucHtmlRichText;
                            if (ucHrtb != null)
                            {
                                if (!string.IsNullOrEmpty(ucHrtb.hrtbPara.Text))
                                {
                                    string strHtml = ucHrtb.GetHtmlStringFromControl();
                                    if (!string.IsNullOrEmpty(strHtml))
                                    {

                                        if (string.IsNullOrEmpty(strPara_Data))
                                        {
                                            strPara_Data = strHtml;
                                        }
                                        else
                                        {
                                            strPara_Data = strPara_Data + strSplitter + strHtml;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strPara_Data;
        }

        /// <summary>
        /// Binds Reaction data to control
        /// </summary>
        /// <param name="rxnRow"></param>
        public void BindReactionDataToControls(DataRow rxnRow)
        {
            try
            {
                //Clear control values
                ClearControlValues();

                if (rxnRow != null)
                {
                    txtNarrID.Text = rxnRow["RXN_NAR_ID"].ToString();

                    txtRxnNum.Text = rxnRow["RXN_NUM"].ToString();
                    txtRxnSeq.Text = rxnRow["RXN_SEQ"].ToString();
                    txtPageNo.Text = rxnRow["PAGE_NO"].ToString();
                    txtPageLabel.Text = rxnRow["PAGE_LABEL"].ToString();
                    txtOffset_X.Text = rxnRow["OFFSET_X"].ToString();
                    txtOffset_Y.Text = rxnRow["OFFSET_Y"].ToString();
                
                    txtPageSize_X.Text = rxnRow["PAGE_SIZE_X"].ToString();
                    txtPageSize_Y.Text = rxnRow["PAGE_SIZE_Y"].ToString();

                    rbnMissingRxn.Checked = (Convert.ToString(rxnRow["IS_MISSING_RXN"]).Equals("Y"));
                    rbnNoExpDetails.Checked = (Convert.ToString(rxnRow["NO_EXP_DETAILS"]).Equals("Y"));
                    rbnGeneralTypical.Checked = (Convert.ToString(rxnRow["IS_GENERAL_TYPICAL"]).Equals("Y"));
                    
                    if (!string.IsNullOrEmpty(rxnRow["TEXT_LINE"].ToString()))
                    {
                        ucHrtbTextLine.BindDataToControl(rxnRow["TEXT_LINE"].ToString());
                    }

                    if (rxnRow["RXN_ID"] != null)
                    {
                        int rxnID = 0;
                        int.TryParse(rxnRow["RXN_ID"].ToString(), out rxnID);
                        Rxn_ID = rxnID;
                    }

                    //DocReference
                    if (rxnRow["TAN_DOC_ID"] != null)
                    {
                        int docrefID = 0;
                        int.TryParse(rxnRow["TAN_DOC_ID"].ToString(), out docrefID);
                        SetRxnDocRefFileName(docrefID);
                    }

                    //Set Analogous Reactions
                    if (Rxn_ID > 0 && TAN_Reactions != null)
                    {
                        DataView view = TAN_Reactions.AsEnumerable().Where(r => r.Field<Int64>("RXN_ID") != Rxn_ID && r.Field<string>("IS_ANALOGOUS") == "N").AsDataView();
                        if (view != null)
                        {
                            DataTable dtAnalogous = view.ToTable();
                            if (dtAnalogous != null)
                            {
                                AnalogousRxns = dtAnalogous;
                            }
                        }
                    }

                    //Set Analogous Reaction
                    if (rxnRow["IS_ANALOGOUS"] != null)
                    {
                        if (rxnRow["IS_ANALOGOUS"].ToString().ToUpper() == "Y")
                        {
                            rbnAnalogousTo.Checked = true;

                            cmbAnalogousTo.SelectedValue = rxnRow["ANALOGOUS_RXN_ID"];
                        }
                        else
                        {
                            rbnAnalogousTo.Checked = false;
                        }
                    }
                    else
                    {
                        rbnAnalogousTo.Checked = false;
                    }

                    //Set Para
                    if (!string.IsNullOrEmpty(rxnRow["PARA_TEXT"].ToString()))
                    {
                        flPnlPara.Controls.Clear();

                        string[] saPara = rxnRow["PARA_TEXT"].ToString().Split(new string[] { paraSplitter }, StringSplitOptions.RemoveEmptyEntries);
                        if (saPara != null)
                        {
                            for (int i = 0; i < saPara.Length; i++)
                            {
                                CreateParaAndBindToPanel("PARA", saPara[i].Trim());
                            }
                        }
                        flPnlPara.Refresh();
                    }

                    //Set Data
                    if (!string.IsNullOrEmpty(rxnRow["DATA_TEXT"].ToString()))
                    {
                        flPnlData.Controls.Clear();
                        string[] saData = rxnRow["DATA_TEXT"].ToString().Split(new string[] { dataSplitter }, StringSplitOptions.RemoveEmptyEntries);
                        if (saData != null)
                        {
                            for (int i = 0; i < saData.Length; i++)
                            {
                                CreateParaAndBindToPanel("DATA", saData[i].Trim());
                            }
                        }
                        flPnlData.Refresh();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        /// <summary>
        /// Get Reaction Data from User Control
        /// </summary>
        /// <returns>NarrReactionsBO</returns>
        public NarrReactionsBO GetNarrReactionDataFromUserControl()
        {
            NarrReactionsBO narRxnData = null;
            try
            {
                if (Rxn_ID > 0)
                {
                    narRxnData = new NarrReactionsBO();
                    narRxnData.RXN_ID = Rxn_ID;
                    if (txtDocRef.Tag != null)
                    {
                        int docRefID = 0;
                        int.TryParse(txtDocRef.Tag.ToString(), out docRefID);
                        if (docRefID > 0)
                        {
                            narRxnData.RxnDocID = docRefID;
                        }
                    }
                    narRxnData.PageNo = txtPageNo.Text.Trim();
                    narRxnData.PageLabel = txtPageLabel.Text.Trim();
                    narRxnData.XOffSet = txtOffset_X.Text.Trim();
                    narRxnData.YOffSet = txtOffset_Y.Text.Trim();

                    double dblXPageSize = 0;
                    double.TryParse(txtPageSize_X.Text.Trim(), out dblXPageSize);

                    double dblYPageSize = 0;
                    double.TryParse(txtPageSize_Y.Text.Trim(), out dblYPageSize);

                    narRxnData.XPageSize = dblXPageSize;
                    narRxnData.YPageSize = dblYPageSize;
                    narRxnData.IsGeneralTypical = rbnGeneralTypical.Checked ? "Y" : "N";
                    narRxnData.NoExpDetails = rbnNoExpDetails.Checked ? "Y" : "N";
                    narRxnData.IsMissingRxn = rbnMissingRxn.Checked ? "Y" : "N";
                    
                    narRxnData.Para = GetPara_DataFromControls("PARA");//Get Para from UserControl
                    narRxnData.Data = GetPara_DataFromControls("DATA");//Get Data from UserControl
                    narRxnData.TextLine = ucHrtbTextLine.GetHtmlStringFromControl();
                    
                    narRxnData.IsAnalogous = rbnAnalogousTo.Checked ? "Y" : "N";
                    if (rbnAnalogousTo.Checked)
                    {
                        if (cmbAnalogousTo.SelectedItem != null)
                        {
                            narRxnData.AnalogousRxnID = Convert.ToInt32(cmbAnalogousTo.SelectedValue);
                        }
                    }
                    narRxnData.UserID = GlobalVariables.URID;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return narRxnData;
        }

        /// <summary>
        /// Validate Reaction User Inputs
        /// </summary>
        /// <param name="errMsgOut"></param>
        /// <returns>Boolean</returns>
        public bool ValidateNarrReactionData(out string errMsgOut)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                //Doc Ref
                if (txtDocRef.Tag == null)
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Doc Ref is mandatory";
                    blStatus = false;
                }
                
                //TextLine                
                if (rbnMissingRxn.Checked)
                {
                    if (!String.IsNullOrEmpty(ucHrtbTextLine.hrtbPara.Text.Trim()))
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Missing Reaction Textline should be null.";
                        blStatus = false;
                    }
                    if (flPnlPara.Controls.Count > 0)
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Missing reaction should not have Para.";
                        blStatus = false;
                    }
                }
                else if (string.IsNullOrEmpty(ucHrtbTextLine.hrtbPara.Text.Trim()))
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "TextLine is mandatory";
                    blStatus = false;
                }
                
                if (rbnGeneralTypical.Checked)
                {
                    if (flPnlPara.Controls.Count < 2)
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "For GeneralTypical reactions, >= 2 Paras should be there.";
                        blStatus = false;
                    }
                }
                else if(rbnAnalogousTo.Checked)
                {
                    if (flPnlPara.Controls.Count != 1)
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "For Analogous reactions, only one Para should be there.";
                        blStatus = false;
                    }                    
                }
                else if (rbnNoExpDetails.Checked)
                {
                    if (flPnlPara.Controls.Count > 1)
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "For No Experimental details only zero/one Para should be there.";
                        blStatus = false;
                    }
                }
                else if(rbnExpProcedure.Checked)
                {
                    if (flPnlPara.Controls.Count != 2)
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "For Experimental procedures 2 Paras should be there.";
                        blStatus = false;
                    }
                }               

                //Page No
                if (string.IsNullOrEmpty(txtPageNo.Text.Trim()))
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Page No is mandatory";
                    blStatus = false;
                }
                else 
                {
                    int intPageNo = 0;
                    int.TryParse(txtPageNo.Text.Trim(), out intPageNo);
                    if (intPageNo == 0)
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Page No should be > 0";
                        blStatus = false;
                    }
                }

                //Page Label
                if (string.IsNullOrEmpty(txtPageLabel.Text.Trim()))
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Page Label is mandatory";
                    blStatus = false;
                }
                else
                {
                    //int intPageLabel = 0;
                    //int.TryParse(txtPageLabel.Text.Trim(), out intPageLabel);
                    //if (intPageLabel == 0)
                    //{
                    //    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Page Label should be > 0";
                    //    blStatus = false;
                    //}

                    //Validate Page Label
                    string errMsg = "";
                    if (TANType.ToUpper() == "PATENT")
                    {
                        int pageLbl = 0;
                        if (!int.TryParse(txtPageLabel.Text.Trim(), out pageLbl))
                        {
                            strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Page Label should be integer";
                            blStatus = false;
                        }
                    }
                    else
                    {
                        if (!Validations.ValidatePageLabel(txtPageLabel.Text.Trim(), ref errMsg))
                        {
                            strErrMsg = strErrMsg.Trim() + Environment.NewLine + errMsg.Trim();
                            blStatus = false;
                        }
                    }
                }

                //X Page Size
                if (string.IsNullOrEmpty(txtPageSize_X.Text.Trim()))
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "X Page Size is mandatory";
                    blStatus = false;
                }
                else
                {
                    double xPageSize = 0;
                    double.TryParse(txtPageSize_X.Text.Trim(), out xPageSize);
                    if (xPageSize == 0)
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "X Page Size should be > 0";
                        blStatus = false;
                    }
                }

                //Y Page Size
                if (string.IsNullOrEmpty(txtPageSize_Y.Text.Trim()))
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Y Page Size is mandatory";
                    blStatus = false;
                }
                else
                {
                    double yPageSize = 0;
                    double.TryParse(txtPageSize_Y.Text.Trim(), out yPageSize);
                    if (yPageSize == 0)
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Y Page Size should be > 0";
                        blStatus = false;
                    }
                }

                //X Page OffSet
                if (string.IsNullOrEmpty(txtOffset_X.Text.Trim()))
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Page X Offset is mandatory";
                    blStatus = false;
                }
                else
                {
                    double xPageOffset = 0;
                    double.TryParse(txtOffset_X.Text.Trim(), out xPageOffset);
                    if (xPageOffset == 0)
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Page X Offset should be > 0";
                        blStatus = false;
                    }
                }

                //Y Page OffSet
                if (string.IsNullOrEmpty(txtOffset_Y.Text.Trim()))
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Page Y Offset is mandatory";
                    blStatus = false;
                }
                else
                {
                    double yPageOffset = 0;
                    double.TryParse(txtOffset_Y.Text.Trim(), out yPageOffset);
                    if (yPageOffset == 0)
                    {
                        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Page Y Offset should be > 0";
                        blStatus = false;
                    }
                }
                                
                //Analogous Reaction
                if (rbnAnalogousTo.Checked && cmbAnalogousTo.SelectedItem == null)
                {
                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Analogous Reaction is mandatory";
                    blStatus = false;
                }

                ////Validate Page Label
                //string errMsg = "";
                //if (TANType.ToUpper() == "PATENT")
                //{
                //    int pageLbl = 0;
                //    if (!int.TryParse(txtPageLabel.Text.Trim(), out pageLbl))
                //    {
                //        strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Page Label should be integer";
                //        blStatus = false;
                //    }
                //}
                //else
                //{
                //    if (!Validations.ValidatePageLabel(txtPageLabel.Text.Trim(), ref errMsg))
                //    {
                //        strErrMsg = strErrMsg.Trim() + Environment.NewLine + errMsg.Trim();
                //        blStatus = false;
                //    }
                //}
                       
                if (flPnlPara.Controls.Count > 0)
                {
                    for (int i = 0; i < flPnlPara.Controls.Count; i++)
                    {
                        ucHtmlRichText ucHrtb = flPnlPara.Controls[i] as ucHtmlRichText;
                        if (ucHrtb != null)
                        {
                            if (string.IsNullOrEmpty(ucHrtb.hrtbPara.Text))
                            {
                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Empty Para -" + (i + 1);
                                blStatus = false;
                            }
                        }
                    }
                }                

                if (flPnlData.Controls.Count > 0)
                {
                    for (int i = 0; i < flPnlData.Controls.Count; i++)
                    {
                        ucHtmlRichText ucHrtb = flPnlData.Controls[i] as ucHtmlRichText;
                        if (ucHrtb != null)
                        {
                            if (string.IsNullOrEmpty(ucHrtb.hrtbPara.Text.Trim()))
                            {
                                strErrMsg = strErrMsg.Trim() + Environment.NewLine + "Empty Data -" + (i + 1);
                                blStatus = false;
                            }
                        }
                    }
                }
               
                //Validate UniCodes in PARA
                if (flPnlPara.Controls.Count > 0)
                {
                    string unicodeErr = "";
                    for (int i = 0; i < flPnlPara.Controls.Count; i++)
                    {
                        ucHtmlRichText ucHrtb = flPnlPara.Controls[i] as ucHtmlRichText;
                        if (ucHrtb != null)
                        {
                            if (!string.IsNullOrEmpty(ucHrtb.hrtbPara.Text.Trim()))
                            {
                                if (!ucHrtb.ValidateUniCodes(out unicodeErr))
                                {
                                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "PARA " + unicodeErr;
                                    blStatus = false;
                                }
                            }
                        }
                    }
                }

                //Validate UniCodes in DATA
                if (flPnlData.Controls.Count > 0)
                {
                    string unicodeErr = "";
                    for (int i = 0; i < flPnlData.Controls.Count; i++)
                    {
                        ucHtmlRichText ucHrtb = flPnlData.Controls[i] as ucHtmlRichText;
                        if (ucHrtb != null)
                        {
                            if (!string.IsNullOrEmpty(ucHrtb.hrtbPara.Text.Trim()))
                            {
                                if (!ucHrtb.ValidateUniCodes(out unicodeErr))
                                {
                                    strErrMsg = strErrMsg.Trim() + Environment.NewLine + "DATA " + unicodeErr;
                                    blStatus = false;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsgOut = strErrMsg.Trim();
            return blStatus;
        }


        ucHtmlRichText ucHrtb;
        private void CreateParaAndBindToPanel(string cntrlType, string htmlContent)
        {
            try
            {               
                ucHrtb = new ucHtmlRichText();
                ucHrtb.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                                | System.Windows.Forms.AnchorStyles.Right)));
                ucHrtb.Width = flPnlPara.Width - 28;
             
                ucHrtb.Height = 150;
                if (!string.IsNullOrEmpty(htmlContent))
                {
                    ucHrtb.BindDataToControl(htmlContent);
                }

                if (cntrlType.ToUpper() == "PARA")
                {
                    // Is general typical have single para or Noexp details will have not more than single para.
                    if (rbnNoExpDetails.Checked)
                    {
                        if (flPnlPara.Controls.Count < 1)
                        {
                            flPnlPara.Controls.Add(ucHrtb);
                        }
                    }
                    else
                    {
                        flPnlPara.Controls.Add(ucHrtb);
                    }
                    lblParaCnt.Text = flPnlPara.Controls.Count.ToString();
                }
                else if (cntrlType.ToUpper() == "DATA")
                {
                    flPnlData.Controls.Add(ucHrtb);
                    lblDataCnt.Text = flPnlData.Controls.Count.ToString();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void lnkAddPara_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {                
                CreateParaAndBindToPanel("PARA", "");
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
               
        private void lnkData_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                CreateParaAndBindToPanel("DATA", "");
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private int GetActiveControlIndexFromFlowLayoutPanel(FlowLayoutPanel flPanel)
        {
            int cntrlIdx = 0;
            try
            {
                if (flPanel != null)
                {
                    if (flPanel.Controls.Count > 0)
                    {
                        ucHtmlRichText ucHB = null;
                        for (int i = 0; i < flPanel.Controls.Count; i++)
                        {
                            ucHB = flPanel.Controls[i] as ucHtmlRichText;
                            if (ucHB != null)
                            {
                                if (ucHB.hrtbPara.Focused)
                                {
                                    cntrlIdx = i;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return cntrlIdx;
        }

        private HtmlRichTextBox GetActiveControlFromFlowLayoutPanel(FlowLayoutPanel flPanel)
        {
            HtmlRichTextBox hrtbActive = null;
            try
            {
                if (flPanel != null)
                {
                    if (flPanel.Controls.Count > 0)
                    {
                        ucHtmlRichText ucHB = null;
                        for (int i = 0; i < flPanel.Controls.Count; i++)
                        {
                            ucHB = flPanel.Controls[i] as ucHtmlRichText;
                            if (ucHB != null)
                            {
                                if (ucHB.hrtbPara.Focused)
                                {
                                    hrtbActive = ucHB.hrtbPara;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return hrtbActive;
        }

        public HtmlRichTextBox GetActiveControl()
        {
            HtmlRichTextBox hrtbActive = null;
            try
            {
                if (ucHrtbTextLine.hrtbPara.Focused)
                {
                    hrtbActive = ucHrtbTextLine.hrtbPara;
                    return hrtbActive;
                }

                hrtbActive = GetActiveControlFromFlowLayoutPanel(flPnlPara);
                if (hrtbActive != null)
                {
                    return hrtbActive;
                }

                hrtbActive = GetActiveControlFromFlowLayoutPanel(flPnlData);
                if (hrtbActive != null)
                {
                    return hrtbActive;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return hrtbActive;
        }

        private void GetCopiedPageSizes()
        {
            try
            {
                if (Clipboard.GetData(DataFormats.Text) != null)
                {
                    string str = Clipboard.GetData(DataFormats.Text).ToString();
                    if (str.Contains("PAGESIZES : "))
                    {
                        char[] c = new char[1] { ':' };
                        string[] strxy = str.Split(c, StringSplitOptions.RemoveEmptyEntries);
                        if (strxy != null)
                        {
                            txtPageSize_Y.Text = strxy[1].Trim();
                            txtPageSize_X.Text = strxy[2].Trim();
                            Clipboard.Clear();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetCopiedPageCoOrdinates()
        {
            try
            {
                if (Clipboard.GetData(DataFormats.Text) != null)
                {
                    string str = Clipboard.GetData(DataFormats.Text).ToString();
                    if (str.Contains("XYOFFSETS : "))
                    {
                        char[] c = new char[1] { ':' };
                        string[] strxy = str.Split(c, StringSplitOptions.RemoveEmptyEntries);
                        if (strxy != null)
                        {
                            txtOffset_X.Text = strxy[1].Trim();
                            txtOffset_Y.Text = strxy[2].Trim();
                            Clipboard.Clear();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnDeleteData_Click(object sender, EventArgs e)
        {
            try
            {
                if (flPnlData.Controls.Count > 0)
                {
                    int cntrlIndx = GetActiveControlIndexFromFlowLayoutPanel(flPnlData);
                    if (cntrlIndx >= 1)
                    {
                        flPnlData.Controls.RemoveAt(cntrlIndx);
                    }

                    flPnlData.Controls[flPnlData.Controls.Count - 1].Focus();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        //TODO: need to review.
        private void tsbtnDeletePara_Click(object sender, EventArgs e)
        {
            try
            {
                if (flPnlPara.Controls.Count > 0)
                {
                    DialogResult diaRes = MessageBox.Show("Do you want to delete the selected PARA?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (diaRes == DialogResult.Yes)
                    {
                        int cntrlIndx = GetActiveControlIndexFromFlowLayoutPanel(flPnlPara);
                        
                        if (cntrlIndx >= 0)
                        {
                            flPnlPara.Controls.RemoveAt(cntrlIndx);
                        }

                        //// No experimental detail reaction containing single para or no para information
                        //if (chkNoExpDetails.Checked)
                        //{
                        //    if (cntrlIndx >= 0)
                        //    {
                        //        flPnlPara.Controls.RemoveAt(cntrlIndx);
                        //    }
                        //}

                        if (flPnlPara.Controls.Count >= 1)
                        {
                            flPnlPara.Controls[flPnlPara.Controls.Count - 1].Focus();
                        }
                        lblParaCnt.Text = flPnlPara.Controls.Count.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbtnDeleteData_Click(object sender, EventArgs e)
        {
            try
            {
                if (flPnlData.Controls.Count > 0)
                {
                  DialogResult diaRes =  MessageBox.Show("Do you want to delete the selected DATA?",GlobalVariables.MessageCaption, MessageBoxButtons.YesNo,MessageBoxIcon.Question);
                  if (diaRes == DialogResult.Yes)
                  {
                      int cntrlIndx = GetActiveControlIndexFromFlowLayoutPanel(flPnlData);
                      
                      if (cntrlIndx >= 0)
                      {
                          flPnlData.Controls.RemoveAt(cntrlIndx);
                      }

                      if (flPnlData.Controls.Count >= 1)
                      {
                          flPnlData.Controls[flPnlData.Controls.Count - 1].Focus();
                      }
                      lblDataCnt.Text = flPnlData.Controls.Count.ToString();
                  }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        

        private void txtPageSize_X_Click(object sender, EventArgs e)
        {
            try
            {
                GetCopiedPageSizes();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtOffset_X_Click(object sender, EventArgs e)
        {
            try
            {
                GetCopiedPageCoOrdinates();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        

        //TODO: need to review size change of usercontrol when panel size changes
        private void flPnlPara_SizeChanged(object sender, EventArgs e)
        {
            try
            {
                if (flPnlPara != null)
                {
                    if (flPnlPara.Controls.Count > 0)
                    {
                        ucHtmlRichText ucHB = null;
                        for (int i = 0; i < flPnlPara.Controls.Count; i++)
                        {
                            ucHB = flPnlPara.Controls[i] as ucHtmlRichText;
                            if (ucHB != null)
                            {
                                ucHB.Width = flPnlPara.Width - 28;
                                //ucHrtb.Height = 100;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void flPnlData_SizeChanged(object sender, EventArgs e)
        {
            try
            {
                if (flPnlData != null)
                {
                    if (flPnlData.Controls.Count > 0)
                    {
                        ucHtmlRichText ucHB = null;
                        for (int i = 0; i < flPnlData.Controls.Count; i++)
                        {
                            ucHB = flPnlData.Controls[i] as ucHtmlRichText;
                            if (ucHB != null)
                            {
                                ucHB.Width = flPnlData.Width - 28;
                                //ucHrtb.Height = 100;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void copyXYOffsetsTSMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtOffset_X.Text.Trim()) && !string.IsNullOrEmpty(txtOffset_Y.Text.Trim()))
                {
                    double xoffset = Convert.ToDouble(txtOffset_X.Text);
                    double yoffset = Convert.ToDouble(txtOffset_Y.Text);
                 
                    if (MessageBox.Show("X offset value '" + xoffset.ToString("0.00") + "',Y Offset value '" + yoffset.ToString("0.00") + "', Do you want to save these values in clipboard?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        Clipboard.Clear();
                        Clipboard.SetData(DataFormats.Text, "XYOFFSETS : " + xoffset.ToString("0.00") + ":" + yoffset.ToString("0.00"));
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void CreateParasByDefaultOnSelectedOption(string selOption)
        {
            try
            {
                if (!string.IsNullOrEmpty(selOption.Trim()))
                {
                    switch (selOption.Trim().ToUpper())
                    {
                        case "ANALOGOUS_TO":

                            ucHtmlRichText ucHrtb = new ucHtmlRichText();
                            ucHrtb.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                                            | System.Windows.Forms.AnchorStyles.Right)));
                            ucHrtb.Width = flPnlPara.Width - 28;
                            //TODO: need to check increase the height of users control.
                            ucHrtb.Height = 150;
                            flPnlPara.Controls.Add(ucHrtb);

                            break;
                        case "EXP_PROCEDURE":

                            break;
                        case "GENERAL_TYPICAL":

                            break;
                        case "NO_EXP_DETAILS":

                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnAnalogousTo_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (rbnAnalogousTo.Checked)
                {
                    cmbAnalogousTo.Enabled = true;
                    if (AnalogousRxns != null)
                    {
                        if (AnalogousRxns.Rows.Count > 0)
                        {
                            cmbAnalogousTo.DataSource = AnalogousRxns;
                            cmbAnalogousTo.ValueMember = "RXN_ID";
                            cmbAnalogousTo.DisplayMember = "RXN_NAR_ID";// "RXN_NUM";

                            cmbAnalogousTo.SelectedValue = -1;
                        }
                        else
                        {

                        }
                    }
                }
                else
                {
                    cmbAnalogousTo.Enabled = false;
                    cmbAnalogousTo.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnMissingRxn_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (rbnMissingRxn.Checked)
                {
                    DialogResult diaRes = MessageBox.Show("Do you want to make this reaction as missing reaction ?\r\n If Yes, Textline, Para, Data set to null.", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (diaRes == System.Windows.Forms.DialogResult.Yes)
                    {
                        ucHrtbTextLine.hrtbPara.Clear();
                        flPnlData.Controls.Clear();
                        flPnlPara.Controls.Clear();

                        lnkAddPara.Enabled = false;
                        lnkData.Enabled = false;

                        lblParaCnt.Text = "0";
                        lblDataCnt.Text = "0";
                    }
                    else
                    {
                        rbnExpProcedure.Checked = true;

                        lnkAddPara.Enabled = true;
                        lnkData.Enabled = true;
                    }
                }
                else
                {
                    lnkAddPara.Enabled = true;
                    lnkData.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnGeneralTypical_CheckedChanged(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
    }
}