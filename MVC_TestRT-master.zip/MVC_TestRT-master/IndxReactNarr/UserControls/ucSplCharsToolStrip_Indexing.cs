﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

using HtmlRichText;
using IndxReactNarr.Generic;
using IndxReactNarr.Curation.Narratives;

namespace IndxReactNarr.UserControls
{
    public partial class ucSplCharsToolStrip_Indexing : UserControl
    {
        public ucSplCharsToolStrip_Indexing()
        {
            InitializeComponent();
        }

        frmOrganicIndexing frmIndexing = null;
        frmMacroIndexing frmMIndexing = null;
        frmFindAndReplace frmFindRep = null;
        HtmlRichTextBox htrtfbox = null;

        public Hashtable GetHTMLReplacementsForSpecialCharsToolStripItems()
        {
            Hashtable htSplChars = new Hashtable();
            try
            {
                foreach (ToolStripItem i in tsSpecialChars.Items)
                {
                    if (!string.IsNullOrEmpty(i.Text))//Code by Sairam on 25Sep 2013
                    {
                        if (!htSplChars.ContainsKey(i.Text))
                        {
                            htSplChars.Add(i.Text, i.Tag);
                        }
                    }
                }
                if (!htSplChars.ContainsKey("≡"))
                {
                    htSplChars.Add("≡", "&#8801;");
                }
                if (!htSplChars.ContainsKey("&#8801;"))
                {
                    htSplChars.Add("&#8801;", "≡");
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return htSplChars;
        }

        private void tsSpecialChars_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            try
            {
                Button btnSender = sender as Button;
                if (sender != null)
                {
                    htrtfbox = htrtfbox = GetActiveControlFromParentForm();
                    if (htrtfbox != null)
                    {
                        if (htrtfbox.Name != "hrtbKeywords")
                        {
                            //string strtext = objHRTB.Text;
                            //int start = objHRTB.SelectionStart;
                            //objHRTB.SelectionFont = new Font(objHRTB.Font.Name, objHRTB.Font.Size);
                            //objHRTB.Select(start, 1);
                            //objHRTB.SelectedText = btnSender.Text;

                            Hashtable hts = new Hashtable();
                            hts.Add("171", "&#8596;");//Left Right Arrow
                            hts.Add("172", "&#8592;");//Left Arrow                               
                            hts.Add("174", "&#8594;");//Right Arrow                                                     
                            hts.Add("222", "&#8658;");//rightwards double arrow
                            hts.Add("219", "&#8660;");//left right double arrow                            
                            hts.Add("187", "&#8776;");//almost equal to                               
                            hts.Add("201", "&#8835;");//superset of
                            hts.Add("221", "&#8730;");//Square Root
                            hts.Add("261", "&#8801;");//Identical to                                  

                            if (e.ClickedItem.Tag != null)
                            {
                                if (!hts.ContainsValue(e.ClickedItem.Tag))
                                {
                                    if (e.ClickedItem.Name.ToUpper() != "TS1TRIPLEBOND" && e.ClickedItem.Name.ToUpper() != "TOOLSTRIPBUTTON61")//&& e.ClickedItem.Tag.ToString() != "&#957;"
                                    {
                                        string strtext = htrtfbox.Text;
                                        int start = htrtfbox.SelectionStart;
                                        htrtfbox.SelectionFont = new Font(htrtfbox.Font.Name, htrtfbox.Font.Size);
                                        htrtfbox.Select(start, 0);
                                        htrtfbox.SelectedText = e.ClickedItem.Text;
                                    }
                                }

                                if (e.ClickedItem.Tag.ToString() == "&#8801;")//Identical to
                                {
                                    int start = htrtfbox.SelectionStart;
                                    htrtfbox.Select(start, 0);
                                    //htrtfbox.SelectedRtf = @"{\rtf1\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil\fcharset128 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\cf1\f0\fs17\'81\'df\f1\fs20\cf0\fs17\par}";
                                    htrtfbox.SelectedRtf = @"{\rtf1\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil\fcharset128 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\cf1\f0\fs17\'81\'df\f1\fs20\cf0\fs17}";
                                    htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                                }
                                else if (e.ClickedItem.Tag.ToString() == "&#8596;")//Left Right Arrow
                                {
                                    int start = htrtfbox.SelectionStart;
                                    htrtfbox.Select(start, 0);
                                    htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                                    htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8596?\cf0\f1\fs17}";
                                    htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                                }
                                else if (e.ClickedItem.Tag.ToString() == "&#8594;")//Right Arrow    
                                {
                                    int start = htrtfbox.SelectionStart;
                                    htrtfbox.Select(start, 0);
                                    htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8594?\cf0\f1\fs17}";
                                    htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                                }
                                else if (e.ClickedItem.Tag.ToString() == "&#8592;")//Left Arrow
                                {
                                    int start = htrtfbox.SelectionStart;
                                    htrtfbox.Select(start, 0);
                                    htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                                    htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8592?\cf0\f1\fs17}";
                                    htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                                }
                                else if (e.ClickedItem.Tag.ToString() == "&#8658;")//rightwards double arrow
                                {
                                    int start = htrtfbox.SelectionStart;
                                    htrtfbox.Select(start, 0);
                                    htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                                    htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset2 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\ltrpar\f0\fs22\'de\f1\fs17}";
                                    htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                                }
                                else if (e.ClickedItem.Tag.ToString() == "&#8660;")//left right double arrow
                                {
                                    int start = htrtfbox.SelectionStart;
                                    htrtfbox.Select(start, 0);
                                    //htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset0 Cambria Math;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8660?\cf0\f1\fs17}";
                                    htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset0 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8660?\cf0\f1\fs17}";
                                    htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                                }
                                else if (e.ClickedItem.Tag.ToString() == "&#8776;")//almost equal to 
                                {
                                    int start = htrtfbox.SelectionStart;
                                    htrtfbox.Select(start, 0);

                                    htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset2 Symbol;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\ltrpar\sa200\sl276\slmult1\sub\b\f0\fs32\'bb\nosupersub\b0\f1\fs17}";
                                    htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                                }
                                else if (e.ClickedItem.Tag.ToString() == "&#8730;")//Square Root
                                {
                                    int start = htrtfbox.SelectionStart;
                                    htrtfbox.Select(start, 0);

                                    htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}{\colortbl ;\red0\green0\blue0;}\viewkind4\uc1\pard\ltrpar\cf1\f0\fs22\u8730?\cf0\f1\fs17}";
                                    htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                                }
                                else if (e.ClickedItem.Tag.ToString() == "&#x2245;")//Approximately Equal To
                                {
                                    int start = htrtfbox.SelectionStart;
                                    htrtfbox.Select(start, 0);

                                    htrtfbox.SelectedRtf = @"{\rtf1\fbidis\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\froman\fprq2\fcharset2 Symbol;}}{\colortbl ;\red0\green0\blue0;}\uc1\pard\ltrpar\cf1\f0\fs22 @}";
                                    htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                                }
                            }
                            else //Some Special chars contains Symbols and doesn't have Tag
                            {
                                //string strtext = htrtfbox.Text;
                                //int start = htrtfbox.SelectionStart;
                                //htrtfbox.SelectionFont = new Font(htrtfbox.Font.Name, htrtfbox.Font.Style);
                                //htrtfbox.Select(start, 0);
                                //htrtfbox.SelectedText = e.ClickedItem.Text;

                                //Font orgFnt = new Font(htrtfbox.Font, htrtfbox.Font.Style);
                                //Font fnt = new Font(htrtfbox.Font, htrtfbox.Font.Style);

                                htrtfbox.SelectionLength = htrtfbox.SelectionLength;// 1; // not sure about this one
                                htrtfbox.SelectionFont = new Font("Symbol", htrtfbox.Font.Size);
                                htrtfbox.SelectionBackColor = System.Drawing.Color.Aqua;
                                htrtfbox.SelectedText = e.ClickedItem.Text;
                                //htrtfbox.SelectionBackColor = System.Drawing.Color.White;
                                //htrtfbox.SelectionFont = orgFnt;

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private HtmlRichTextBox GetActiveControlFromParentForm()
        {
            HtmlRichTextBox hrtbActive = null;
            try
            {

                frmIndexing = this.Parent.Parent as frmOrganicIndexing;
                if (frmIndexing != null)
                {
                    hrtbActive = frmIndexing.GetActiveControlFromForm();
                    return hrtbActive;
                }

                frmMIndexing = this.Parent.Parent as frmMacroIndexing;
                if (frmMIndexing != null)
                {
                    hrtbActive = frmMIndexing.GetActiveControlFromForm();
                    return hrtbActive;
                }

                frmFindRep = this.Parent.Parent as frmFindAndReplace;
                if (frmFindRep != null)
                {
                    hrtbActive = frmFindRep.GetActiveControlFromForm();
                    return hrtbActive;
                }

                try
                {
                    frmNarrCuration_New frmNarratives = this.Parent.Parent.Parent.Parent.Parent.Parent as frmNarrCuration_New;
                    if (frmNarratives != null)
                    {
                        hrtbActive = frmNarratives.ucNarCuration1.GetActiveControl();
                        return hrtbActive;
                    }

                    frmExpProceduresCuration frmExpProc = this.Parent.Parent.Parent.Parent.Parent.Parent as frmExpProceduresCuration;
                    if (frmExpProc != null)
                    {
                        hrtbActive = frmExpProc.ucExpProcCuration.GetActiveControl();
                        return hrtbActive;
                    }
                }
                catch
                {

                }

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return hrtbActive;
        }
              
        List<Control> lstHtmlControls = new List<Control>();

        private List<Control> GetAllHtmlControls(Control container)
        {
            try
            {
                foreach (Control c in container.Controls)
                {
                    GetAllHtmlControls(c);
                    if (c is HtmlRichTextBox) lstHtmlControls.Add(c);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return lstHtmlControls;
        }
      
        #region Format

        private void ConvertHtmlToRtf(string strtext, HtmlRichText.HtmlRichTextBox rtfxcontrol)
        {
            strtext = strtext.Replace("<bold>", "<b>");
            strtext = strtext.Replace("</bold>", "</b>");
            strtext = strtext.Replace("<ital>", "<I>");
            strtext = strtext.Replace("</ital>", "</I>");
            strtext = strtext.Replace("<sup>", "<SUP>");
            strtext = strtext.Replace("</sup>", "</SUP>");
            strtext = strtext.Replace("<sub>", "<SUB>");
            strtext = strtext.Replace("</sub>", "</SUB>");
            try
            {

                SautinSoft.HtmlToRtf h = new SautinSoft.HtmlToRtf();


                //specify some options
                h.OutputFormat = SautinSoft.HtmlToRtf.eOutputFormat.Rtf;
                h.Encoding = SautinSoft.HtmlToRtf.eEncoding.AutoSelect;
                h.PageStyle.PageSize.Letter();


                string htmlstring = strtext;
                string rtf = h.ConvertString(htmlstring);

                rtfxcontrol.Rtf = rtf;

                string strremovetext = rtfxcontrol.Rtf;
                rtfxcontrol.Rtf = strremovetext;// RemoveTrialVersionstring(strremovetext).Trim();

                RemoveTrialVersionstring("", rtfxcontrol);
            }
            catch (Exception ex)
            {
                //  ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        int indexOfSearchText = 0;
        int start = 0;
        public int FindMyText(string txtToSearch, int searchStart, int searchEnd, HtmlRichText.HtmlRichTextBox rtb)
        {

            // Set the return value to -1 by default.
            int retVal = -1;

            // A valid starting index should be specified.
            // if indexOfSearchText = -1, the end of search
            if (searchStart >= 0 && indexOfSearchText >= 0)
            {
                // A valid ending index
                if (searchEnd > searchStart || searchEnd == -1)
                {
                    rtb.Refresh();
                    // Find the position of search string in RichTextBox
                    indexOfSearchText = rtb.Find(txtToSearch, searchStart, searchEnd, RichTextBoxFinds.MatchCase);

                    retVal = indexOfSearchText;

                }
            }
            return retVal;
        }

        private void RemoveTrialVersionstring(string strrtfstring, HtmlRichText.HtmlRichTextBox rtbox)
        {
            string str1 = "________________________________________________________";
            string str2 = "Trial version converts only first 100000 characters. Evaluation only.";
            string str3 = "Converted by HTML-to-RTF Pro DLL .Net 3.5.4.21.";
            string str4 = "(Licensed version doesn't display this notice!)";
            string str5 = "- Get license for the HTML-to-RTF Pro DLL .Net <http://www.sautinsoft.com/products/html-to-rtf/order.php>";
            string str6 = "\n\n\n\n\n\n";

            string[] strvalues = new string[6] { str1, str2, str3, str4, str5, str6 };
            try
            {

                foreach (string str in strvalues)
                {
                    if (rtbox.Text.Contains(str))
                    {
                        bool blnloop = false;
                        int startindex = 0;

                        indexOfSearchText = 0;
                        start = 0;
                        while (blnloop == false)
                        {

                            if (str.Length > 0)
                            {
                                startindex = FindMyText(str.Trim(), start, rtbox.Text.Length, rtbox);
                                if (startindex == -1)
                                {
                                    blnloop = true;
                                }
                            }

                            if (startindex >= 0)
                            {
                                // Set the highlight color as red
                                int endindex = str.Length;
                                // Highlight the search string
                                rtbox.Select(startindex, endindex);
                                rtbox.SelectedRtf = "";
                                blnloop = true;
                                rtbox.SelectAll();
                                //start = startindex + endindex;
                                // continue;

                            }
                        }
                        continue;

                    }
                }
            }
            catch (Exception ex)
            {
                // ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        HtmlRichTextBox rtfformula = new HtmlRichTextBox();
        //frmfindandreplace frmreplace = null;
        //private void tsbFindReplace_Click(object sender, EventArgs e)
        //{
        //    string strfindwhat = "";
        //    string strreplacertf = "";
        //    frmreplace = new frmfindandreplace();
        //    bool isfound = false;
        //    try
        //    {
        //        if (frmIndexing == null)
        //        {
        //            GetIndexingCurationFormObj();
        //        }

        //        HtmlRichText.HtmlRichTextBox htrtfbox = GetFocusedControlFromForm(frmIndexing);

        //        if (frmreplace.ShowDialog() != DialogResult.OK)
        //        {
        //            btnok_Click(null, null);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString()); // Exceptions.CASExceptions.WriteErrorLog(ex.ToString());
        //    }
        //}

        //frmFind and replace
        void btnok_Click(object sender, EventArgs e)
        {
            #region Old code
            //bool isfound = false;

            //if (frmreplace.IsFound)
            //{

            //    if (!frmreplace.ReplaceChecked)
            //    {
            //        //foreach (Control c in tableLayoutPanel1.Controls)
            //        //foreach (Control c in pnlUserControl.Controls)
            //        //{
            //        //    if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
            //        //    {
            //        //        uccasnartool_new uc = (uccasnartool_new)c;
            //        //        foreach (Control t in uc.pnlMain.Controls)
            //        //        {
            //        //            if (t.GetType().BaseType.Name.ToUpper() == "TEXTBOXBASE")
            //        //            {
            //        //                if (t.Text.Contains(frmreplace.findwith))
            //        //                {
            //        //                    isfound = true;
            //        //                    t.Focus();
            //        //                }
            //        //            }
            //        //        }

            //        //    }
            //        //}

            //        //if (_currentPage < _PageCount)
            //        //{
            //        //    if (MessageBox.Show("Do you want to search in next page", "CAS Narrative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
            //        //    {
            //        //        for (int i = _currentPage; i < _PageCount; i++)
            //        //        {
            //        //            _currentPage++;
            //        //            LoadPage();
            //        //        }

            //        //        foreach (Control c in tableLayoutPanel1.Controls)
            //        //        {
            //        //            if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
            //        //            {
            //        //                uccasnartool uc = (uccasnartool)c;
            //        //                foreach (Control t in uc.panel1.Controls)
            //        //                {
            //        //                    if (t.GetType().BaseType.Name.ToUpper() == "TEXTBOXBASE")
            //        //                    {
            //        //                        if (t.Text.Contains(frmreplace.findwith))
            //        //                        {
            //        //                            isfound = true;
            //        //                            t.Focus();
            //        //                        }
            //        //                    }
            //        //                }

            //        //            }
            //        //        }
            //        //    }
            //        //}



            //    }
            //    // foreach (Control c in tableLayoutPanel1.Controls)
            //    //foreach (Control c in pnlUserControl.Controls)
            //    //{
            //    //    if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
            //    //    {
            //    //        uccasnartool_new uc = (uccasnartool_new)c;

            //    //FindStringINRichTextbox(frmreplace.findwith, uccasnartool_new1.rtxttextlinepreview);

            //    //FindStringINRichTextbox(frmreplace.findwith, uccasnartool_new1.rtxtdatapreview);

            //    //FindStringINRichTextbox(frmreplace.findwith, uccasnartool_new1.rtxtparapreview);

            //    //FindStringINRichTextbox(frmreplace.findwith, uccasnartool_new1.txtpara1);

            //    //FindStringINRichTextbox(frmreplace.findwith, uccasnartool_new1.rtxtdata1);

            //    foreach (Control item in lstHtmlControls)
            //    {
            //        FindStringINRichTextbox(frmreplace.findwith, (HtmlRichTextBox)item);
            //    }


            //    //    }
            //    //}
            //    //if (_currentPage < _PageCount)
            //    //{

            //    //        for (int i = _currentPage; i < _PageCount; i++)
            //    //        {
            //    //            if (MessageBox.Show("Do you want to replace in next page", "CAS Narrative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
            //    //            {
            //    //            _currentPage++;

            //    //            LoadPage();

            //    //            foreach (Control c in tableLayoutPanel1.Controls)
            //    //            {
            //    //                if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
            //    //                {
            //    //                    uccasnartool uc = (uccasnartool)c;

            //    //                    FindStringINRichTextbox(frmreplace.findwith, uc.rtxttextlinepreview);

            //    //                    FindStringINRichTextbox(frmreplace.findwith, uc.rtxtdatapreview);

            //    //                    FindStringINRichTextbox(frmreplace.findwith, uc.rtxtparapreview);

            //    //                    FindStringINRichTextbox(frmreplace.findwith, uc.txtpara1);



            //    //                }
            //    //            }
            //    //        }
            //    //    }
            //    //}

            //    if (!frmreplace.ReplaceChecked && !isfound)
            //    {
            //        MessageBox.Show("No results found", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //        return;
            //    }
            //} 
            #endregion
        }   

        private void tsbBold_Click(object sender, EventArgs e)
        {
            try
            {
                htrtfbox = GetActiveControlFromParentForm();
                if (htrtfbox != null)
                {
                    Bold(htrtfbox);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public static void Bold(HtmlRichText.HtmlRichTextBox htrtfbox)
        {
            try
            {
                if (htrtfbox != null)
                {
                    if (htrtfbox.Name != "hrtbKeywords")
                    {
                        if (htrtfbox.SelectedText != null)
                        {
                            if (htrtfbox.SelectionFont == null)
                                htrtfbox.SelectionFont = new Font(htrtfbox.Font, htrtfbox.Font.Style ^ FontStyle.Bold);
                            else
                                htrtfbox.SelectionFont = new Font(htrtfbox.SelectionFont, htrtfbox.SelectionFont.Style ^ FontStyle.Bold);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbUnderline_Click(object sender, EventArgs e)
        {
            try
            {
                htrtfbox = GetActiveControlFromParentForm();
                UnderLine(htrtfbox);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString()); // ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public static void UnderLine(HtmlRichText.HtmlRichTextBox htrtfbox)
        {
            try
            {
                if (htrtfbox != null)
                {
                    if (htrtfbox.Name != "hrtbKeywords")
                    {
                        if (htrtfbox.SelectedText != null)
                        {
                            if (htrtfbox.SelectionFont == null)
                                htrtfbox.SelectionFont = new Font(htrtfbox.Font, htrtfbox.Font.Style ^ FontStyle.Underline);
                            else
                                htrtfbox.SelectionFont = new Font(htrtfbox.SelectionFont, htrtfbox.SelectionFont.Style ^ FontStyle.Underline);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbItalic_Click(object sender, EventArgs e)
        {
            try
            {
                htrtfbox = GetActiveControlFromParentForm();
                if (htrtfbox != null)
                {
                    Italic(htrtfbox);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public static void Italic(HtmlRichText.HtmlRichTextBox htrtfbox)
        {
            try
            {
                if (htrtfbox != null)
                {
                    if (htrtfbox.Name != "hrtbKeywords")
                    {
                        if (htrtfbox.SelectedText != null)
                        {
                            if (htrtfbox.SelectionFont == null)
                                htrtfbox.SelectionFont = new Font(htrtfbox.Font, htrtfbox.Font.Style ^ FontStyle.Italic);
                            else
                                htrtfbox.SelectionFont = new Font(htrtfbox.SelectionFont, htrtfbox.SelectionFont.Style ^ FontStyle.Italic);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbRegular_Click(object sender, EventArgs e)
        {
            try
            {
                htrtfbox = GetActiveControlFromParentForm();
                if (htrtfbox != null)
                {
                    Regular(htrtfbox);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public static void Regular(HtmlRichText.HtmlRichTextBox htrtfbox)
        {
            try
            {
                if (htrtfbox != null)
                {
                    if (htrtfbox.Name != "hrtbKeywords")
                    {
                        if (htrtfbox.SelectedText != null)
                        {
                            if (htrtfbox.SelectionFont == null)
                                htrtfbox.SelectionFont = new Font(htrtfbox.Font, htrtfbox.Font.Style ^ FontStyle.Regular);
                            else
                                htrtfbox.SelectionFont = new Font(htrtfbox.SelectionFont, htrtfbox.SelectionFont.Style ^ FontStyle.Regular);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbSuperscript_Click(object sender, EventArgs e)
        {
            try
            {
                htrtfbox = GetActiveControlFromParentForm();
                if (htrtfbox != null)
                {
                    SuperScript(htrtfbox);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public static void SuperScript(HtmlRichText.HtmlRichTextBox htrtfbox)
        {
            try
            {
                if (htrtfbox != null)
                {
                    if (htrtfbox.Name != "hrtbKeywords")
                    {
                        if (!htrtfbox.IsSuperScript())
                        {
                            htrtfbox.SetSuperScript(true);
                            htrtfbox.SetSubScript(false);
                        }
                        else
                            htrtfbox.SetSuperScript(false);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbSubscript_Click(object sender, EventArgs e)
        {
            try
            {
                htrtfbox = GetActiveControlFromParentForm();
                if (htrtfbox != null)
                {
                    SubScript(htrtfbox);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public static void SubScript(HtmlRichText.HtmlRichTextBox htrtfbox)
        {
            try
            {
                if (htrtfbox != null)
                {
                    if (htrtfbox.Name != "hrtbKeywords")
                    {
                        if (!htrtfbox.IsSubScript())
                        {
                            htrtfbox.SetSubScript(true);
                            htrtfbox.SetSuperScript(false);
                        }
                        else
                            htrtfbox.SetSubScript(false);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbSmallCaps_Click(object sender, EventArgs e)
        {
            try
            {
                htrtfbox = GetActiveControlFromParentForm();
                if (htrtfbox != null)
                {
                    SmallCaps(htrtfbox);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public void SmallCaps(HtmlRichText.HtmlRichTextBox htrtfbox)
        {
            try
            {
                if (htrtfbox != null)
                {
                    if (htrtfbox.Name != "hrtbKeywords")
                    {
                        if (htrtfbox.SelectionFont != null)
                            fontDialog1.Font = htrtfbox.SelectionFont;
                        else
                            fontDialog1.Font = htrtfbox.Font;

                        if (fontDialog1.ShowDialog() == DialogResult.OK)
                        {
                            if (htrtfbox.SelectionFont != null)
                                htrtfbox.SelectionFont = fontDialog1.Font;
                            else
                                if (htrtfbox.SelectedText != null)
                                {
                                    htrtfbox.SelectionFont = fontDialog1.Font;
                                }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbUndo_Click(object sender, EventArgs e)
        {
            try
            {
                htrtfbox = GetActiveControlFromParentForm();
                if (htrtfbox != null)
                {
                    htrtfbox.Undo();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbRedo_Click(object sender, EventArgs e)
        {
            try
            {
                htrtfbox = GetActiveControlFromParentForm();
                if (htrtfbox != null)
                {
                    htrtfbox.Redo();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsbConvFormula_Click(object sender, EventArgs e)
        {   
            try
            {
                htrtfbox = GetActiveControlFromParentForm();
                if (htrtfbox != null)
                {
                    ConvertFormula(htrtfbox);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public void ConvertFormula(HtmlRichText.HtmlRichTextBox htrtfbox)
        {
            try
            {
                if (htrtfbox != null)
                {
                    if (htrtfbox.Name != "hrtbKeywords")
                    {
                        if (htrtfbox.SelectedText != null)
                        {

                            rtfformula.Text = "";
                            rtfformula.Rtf = htrtfbox.SelectedRtf;
                            int startposition = htrtfbox.SelectionStart;
                            int endpostion = htrtfbox.SelectionLength;
                            string a = htrtfbox.SelectedText;
                            for (int i = 0; i < a.Length; i++)
                            {

                                string x = a.Substring(i, 1);

                                if (char.IsNumber(Convert.ToChar(x)))
                                {
                                    rtfformula.Select(i, 1);
                                    rtfformula.SetSubScript(true);
                                    rtfformula.SetSuperScript(false);
                                }
                            }
                            //Zero First Test
                            for (int i = 0; i < a.Length; i++)
                            {
                                string x = a.Substring(i, 1);
                                bool iszerofirst = false;
                                int zerofirstindex = 0;
                                bool isafterzeronumber = false;
                                if (char.IsNumber(Convert.ToChar(x)))
                                {
                                    if (Convert.ToInt32(x) == 0)
                                    {
                                        iszerofirst = true;
                                        zerofirstindex = i;
                                        Char[] ca = a.ToCharArray();
                                        if (ca != null && ca.Length > 0)
                                        {
                                            if (ca.Length > zerofirstindex + 1)
                                            {
                                                string _strvalue = ca[zerofirstindex].ToString() + ca[zerofirstindex + 1].ToString();
                                                if (char.IsNumber(ca[zerofirstindex + 1]))
                                                {
                                                    if (MessageBox.Show("Zero exists before numeric value in formula, value is " + _strvalue + " . Is it correct?", "CAS Narrative", MessageBoxButtons.YesNo, MessageBoxIcon.Information) != DialogResult.Yes)
                                                    {
                                                        return;
                                                    }
                                                    else
                                                        break;

                                                }
                                            }
                                        }
                                    }
                                }

                            }

                            //If c repeates in formula more than one times
                            int ccount = 0;
                            bool isnumber = false;
                            for (int i = 0; i < a.Length; i++)
                            {

                                string x = a.Substring(i, 1);
                                if (x.ToString().ToUpper() == "C")
                                {
                                    if (a.Length > i + 1)
                                    {
                                        string y = a.Substring(i + 1, 1);
                                        if (char.IsNumber(Convert.ToChar(y)))
                                        {
                                            ccount++;
                                        }
                                    }
                                }
                            }
                            if (ccount > 1)
                            {
                                if (MessageBox.Show("C repeates " + ccount + " times in formula, is it correct formula?", "CAS Narrative", MessageBoxButtons.YesNo, MessageBoxIcon.Information) != DialogResult.Yes)
                                {
                                    return;
                                }

                            }




                            if (rtfformula.SelectedText != null)
                            {
                                for (int i = 0; i < rtfformula.Text.Length; i++)
                                {
                                    if (rtfformula.Text.Substring(i, 1) == "0")
                                    {
                                        rtfformula.Select(i, 1);
                                        rtfformula.SelectionBackColor = Color.Red;

                                    }
                                }
                            }
                            rtfformula.SelectAll();
                            htrtfbox.SelectedRtf = rtfformula.SelectedRtf.Replace("\r\n", "");




                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void tsCaseChange_Click(object sender, EventArgs e)
        {
            try
            {
                htrtfbox = GetActiveControlFromParentForm();
                if (htrtfbox != null)
                {
                    Casechange(htrtfbox);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public static void Casechange(HtmlRichText.HtmlRichTextBox htrtfbox)
        {
            try
            {
                if (htrtfbox != null)
                {
                    if (htrtfbox.SelectedText != null)
                    {
                        if (IsUpper(htrtfbox.SelectedText))
                        {
                            htrtfbox.SelectedText = htrtfbox.SelectedText.ToLower();
                        }
                        else
                        {
                            htrtfbox.SelectedText = htrtfbox.SelectedText.ToUpper();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public static bool IsUpper(string value)
        {
            try
            {
                // Consider string to be uppercase if it has no lowercase letters.
                for (int i = 0; i < value.Length; i++)
                {
                    if (char.IsLower(value[i]))
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return true;
        }
    }
}
