﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace IndxReactNarr.UserControls
{
    public partial class ucPara_Data_Multiple : UserControl
    {
        public ucPara_Data_Multiple()
        {
            InitializeComponent();
        }
    }
}
