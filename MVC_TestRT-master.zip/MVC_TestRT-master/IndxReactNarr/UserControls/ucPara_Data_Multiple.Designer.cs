﻿namespace IndxReactNarr.UserControls
{
    partial class ucPara_Data_Multiple
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucPara_Data_Multiple));
            this.pnlTop = new System.Windows.Forms.Panel();
            this.ucHtmlRichText1 = new IndxReactNarr.UserControls.ucHtmlRichText();
            this.btnDelete = new System.Windows.Forms.Button();
            this.lblPara1 = new System.Windows.Forms.Label();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlTop.Controls.Add(this.lblPara1);
            this.pnlTop.Controls.Add(this.btnDelete);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1103, 19);
            this.pnlTop.TabIndex = 0;
            // 
            // ucHtmlRichText1
            // 
            this.ucHtmlRichText1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucHtmlRichText1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ucHtmlRichText1.Location = new System.Drawing.Point(0, 19);
            this.ucHtmlRichText1.Name = "ucHtmlRichText1";
            this.ucHtmlRichText1.Size = new System.Drawing.Size(1103, 71);
            this.ucHtmlRichText1.TabIndex = 1;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.White;
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnDelete.Enabled = false;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.Location = new System.Drawing.Point(1078, 0);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(21, 15);
            this.btnDelete.TabIndex = 69;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Visible = false;
            // 
            // lblPara1
            // 
            this.lblPara1.AutoSize = true;
            this.lblPara1.BackColor = System.Drawing.Color.White;
            this.lblPara1.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblPara1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPara1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblPara1.Location = new System.Drawing.Point(0, 0);
            this.lblPara1.Name = "lblPara1";
            this.lblPara1.Size = new System.Drawing.Size(34, 15);
            this.lblPara1.TabIndex = 70;
            this.lblPara1.Text = "Para";
            this.lblPara1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ucPara_Data_Multiple
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ucHtmlRichText1);
            this.Controls.Add(this.pnlTop);
            this.Name = "ucPara_Data_Multiple";
            this.Size = new System.Drawing.Size(1103, 90);
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTop;
        private ucHtmlRichText ucHtmlRichText1;
        public System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label lblPara1;
    }
}
