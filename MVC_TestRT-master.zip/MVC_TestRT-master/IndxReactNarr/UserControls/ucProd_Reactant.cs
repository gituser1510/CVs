﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace IndxReactNarr
{
    public partial class ucProd_Reactant : UserControl
    {
        public ucProd_Reactant()
        {
            InitializeComponent();
        }

        private string _nrnnum = "";
        public string NrnNum
        {
            get
            { return _nrnnum; }
            set
            {
                _nrnnum = value;
                lblNrnNum.Text = _nrnnum;                                                       
            }
        }

        private string _stage = "";
        public string StageName
        {
            get
            { return _stage; }
            set
            {
                _stage = value;
                lblStage.Text = _stage;
            }
        }

        private Image _chemimg = null;
        public Image ChemImage
        {
            get
            { return _chemimg; }
            set
            {
                _chemimg = value;
                pbChemImg.Image = _chemimg;               
            }
        }

        public string ChemHexCode
        {
            get;
            set;
        }
    }
}
