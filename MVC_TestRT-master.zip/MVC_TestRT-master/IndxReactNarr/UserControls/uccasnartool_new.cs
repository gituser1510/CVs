﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Collections;
using System.IO;
//using mshtml;
using HtmlRichText;
using System.Text.RegularExpressions;
using IndxReactNarrBLL;
using IndxReactNarr.Generic;
using IndxReactNarrBll;
using IndxReactNarr.UserControls;

namespace IndxReactNarr
{
    public partial class uccasnartool_new : UserControl
    {
        public uccasnartool_new()
        {
            try
            {
                InitializeComponent();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #region Public properties

        public bool IsCloseClicked
        {
            get;
            set;
        }

        private clsCASChild _tandetails = null;
        public clsCASChild TanDetails
        {
            get { return _tandetails; }
            set { _tandetails = value; }
        }

        public int documentid = 0;
        public int reactionID = 0;
        //public int rowindex = 0;
        DataSet dsFandR = new DataSet();

        private DataSet _dsFandR = null;
        public DataSet DsFindAndReplace
        {
            get { return _dsFandR; }
            set { _dsFandR = value; }
        }

        private DataSet _dsFielnames = null;
        public DataSet DsTanFilenames
        {
            get { return _dsFielnames; }
            set { _dsFielnames = value; }
        }

        //private Hashtable _htfindandreplace = null;
        //public Hashtable HtFindAndReplace
        //{
        //    get { return _htfindandreplace; }
        //    set { _htfindandreplace = value; }
        //}

        private Hashtable _htsymbols = null;
        public Hashtable HtSymbols
        {
            get { return _htsymbols; }
            set { _htsymbols = value; }
        }

        private bool _isclicked = false;
        public bool Clicked
        {
            get { return _isclicked; }
            set { _isclicked = value; }
        }

        private string _strRtf = "";
        public string RTFData
        {
            get { return _strRtf; }
            set { _strRtf = value; }
        }

        private string _strTAN = "";
        public string TAN
        {
            get { return _strTAN; }
            set { _strTAN = value; }
        }

        private int _Rxn_ID = 0;
        public int Rxn_ID
        {
            get { return _Rxn_ID; }
            set { _Rxn_ID = value; }
        }

        //Hashtable htsymbols = new Hashtable();
        //  AutoCompleteStringCollection _autocompleSupplementID = new AutoCompleteStringCollection();
        AutoCompleteStringCollection _autocompledocrefs = new AutoCompleteStringCollection();
        // AutoCompleteStringCollection _autoCompleRxnNum = new AutoCompleteStringCollection();
        //  AutoCompleteStringCollection _autoCompleRxnSEQ = new AutoCompleteStringCollection();
        // AutoCompleteStringCollection _autocompleNarrative = new AutoCompleteStringCollection();

        #endregion

        //public void loadFields()
        //{
        //    try
        //    {
        //        dsFandR = Generic.globalVariables.DsFindAndReplace;
        //        rtxttextlinepreview.ZoomFactor = (float)1.1;
        //        rtxtdatapreview.ZoomFactor = (float)1.1;
        //        rtxtparapreview.ZoomFactor = (float)1.1;
        //        txtpara1.ZoomFactor = (float)1.1;

        //        rtxttextlinepreview.TextChanged -= new EventHandler(rtxttextlinepreview_TextChanged_1);
        //        rtxtparapreview.TextChanged -= new EventHandler(rtxttextlinepreview_TextChanged_1);
        //        txtpara1.TextChanged -= new EventHandler(rtxttextlinepreview_TextChanged_1);
        //        rtxtdatapreview.TextChanged -= new EventHandler(rtxttextlinepreview_TextChanged_1);
        //        rtxtdata1.TextChanged -= new EventHandler(rtxttextlinepreview_TextChanged_1);

        //        txtCASReactnumber.TextChanged -= new EventHandler(txtCASReactnumber_TextChanged);
        //        txtrxnseq.TextChanged -= new EventHandler(txtCASReactnumber_TextChanged);
        //        txtdocref.TextChanged -= new EventHandler(txtCASReactnumber_TextChanged);
        //        txtfilename.TextChanged -= new EventHandler(txtCASReactnumber_TextChanged);
        //        txtpagenumber.TextChanged -= new EventHandler(txtCASReactnumber_TextChanged);
        //        txtpagelabel.TextChanged -= new EventHandler(txtCASReactnumber_TextChanged);
        //        txtxpagesize.TextChanged -= new EventHandler(txtCASReactnumber_TextChanged);
        //        txtxoffset.TextChanged -= new EventHandler(txtCASReactnumber_TextChanged);
        //        txtypagesize.TextChanged -= new EventHandler(txtCASReactnumber_TextChanged);
        //        txtyoffset.TextChanged -= new EventHandler(txtCASReactnumber_TextChanged);
        //        //  txtnarrativeid.TextChanged -= new EventHandler(txtCASReactnumber_TextChanged);

        //        //  chkisGeneralTypical.CheckStateChanged -= new EventHandler(chkisGeneralTypical_CheckStateChanged);
        //        chkisgeneralprocempty.CheckStateChanged -= new EventHandler(chkisgeneralprocempty_CheckStateChanged);

        //        if (TanDetails != null)
        //        {
        //            if (TanDetails.Rxnseq != null && TanDetails.Rxnseq.ToString() != "")
        //                txtrxnseq.Text = TanDetails.Rxnseq.ToString("0000");

        //            if (TanDetails.ReactionCasReactantNumber != null && TanDetails.ReactionCasReactantNumber.ToString() != "")
        //                txtCASReactnumber.Text = TanDetails.ReactionCasReactantNumber.ToString("0000");

        //            if (TanDetails.DocRef != null && TanDetails.DocRef != "")
        //                txtdocref.Text = TanDetails.DocRef;

        //            if (TanDetails.PageNumber != null && TanDetails.PageNumber.ToString() != "")
        //                txtpagenumber.Text = TanDetails.PageNumber.ToString();

        //            txtpagelabel.Text = TanDetails.PageLabel;

        //            txtfilename.Text = TanDetails.filename;

        //            if (TanDetails.XResUnit != null)
        //                txtxpageunit.Text = "inch";

        //            if (TanDetails.XOffset != null && TanDetails.XOffset.ToString() != "")
        //                txtxoffset.Text = TanDetails.XOffset.ToString();

        //            if (TanDetails.XPageSize != null && TanDetails.XPageSize.ToString() != "")
        //                txtxpagesize.Text = TanDetails.XPageSize.ToString();


        //            if (TanDetails.YOffset != null && TanDetails.YOffset.ToString() != "")
        //                txtyoffset.Text = TanDetails.YOffset.ToString();

        //            if (TanDetails.YPageSize != null && TanDetails.YPageSize.ToString() != "")
        //                txtypagesize.Text = TanDetails.YPageSize.ToString();

        //            if (TanDetails.YResUnit != null && TanDetails.YResUnit != "")
        //                txtyresunit.Text = TanDetails.YResUnit.ToString();

        //            chkisGeneralTypical.Checked = TanDetails.isGeneralTypical;

        //            chkisgeneralprocempty.Checked = TanDetails.noexperimentaldetails;

        //            //rtxttextlinepreview.AddHTML(TanDetails.TextLine);
        //            ConvertHtmlToRtf(TanDetails.TextLine, rtxttextlinepreview);
        //            if (TanDetails.TextLine != null)
        //                rtxttextlinepreview.Tag = TanDetails.TextLine;

        //            SetNarId(TanDetails.NarrativeID);

        //            //rtxtdatapreview.AddHTML(TanDetails.Data);
        //            ConvertHtmlToRtf(TanDetails.Data, rtxtdatapreview);
        //            if (TanDetails.Data != null)
        //                rtxtdatapreview.Tag = TanDetails.Data;

        //            //rtxtparapreview.AddHTML(TanDetails.Para);
        //            ConvertHtmlToRtf(TanDetails.Para, rtxtparapreview);
        //            if (TanDetails.Para != null)
        //                rtxtparapreview.Tag = TanDetails.Para;

        //            //txtpara1.AddHTML(TanDetails.Para1);
        //            ConvertHtmlToRtf(TanDetails.Para1, txtpara1);
        //            if (TanDetails.Para1 != null)
        //                txtpara1.Tag = TanDetails.Para1;

        //            ConvertHtmlToRtf(TanDetails.Data1, rtxtdata1);
        //            if (TanDetails.Data1 != null)
        //                rtxtdata1.Tag = TanDetails.Data1;

        //            documentid = TanDetails.DocumentID;
        //            reactionID = TanDetails.ReactionID;

        //            //Heighlight Analogous text in Para1 & Para2
        //            //   if (this.txtnarrativeid.Text.Contains("analogousTo=nar"))
        //            if (chkIsAnalogous.Checked)
        //            {
        //                HighlightAnalogous();
        //            }

        //            //Highlight special charaters based on Journal/Patent
        //            HeighlightSplChrPatentJournal();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    finally
        //    {
        //        rtxttextlinepreview.TextChanged += new EventHandler(rtxttextlinepreview_TextChanged_1);
        //        rtxtparapreview.TextChanged += new EventHandler(rtxttextlinepreview_TextChanged_1);
        //        txtpara1.TextChanged += new EventHandler(rtxttextlinepreview_TextChanged_1);
        //        rtxtdatapreview.TextChanged += new EventHandler(rtxttextlinepreview_TextChanged_1);
        //        rtxtdata1.TextChanged += new EventHandler(rtxttextlinepreview_TextChanged_1);

        //        txtCASReactnumber.TextChanged += new EventHandler(txtCASReactnumber_TextChanged);
        //        txtrxnseq.TextChanged += new EventHandler(txtCASReactnumber_TextChanged);
        //        txtdocref.TextChanged += new EventHandler(txtCASReactnumber_TextChanged);
        //        txtfilename.TextChanged += new EventHandler(txtCASReactnumber_TextChanged);
        //        txtpagenumber.TextChanged += new EventHandler(txtCASReactnumber_TextChanged);
        //        txtpagelabel.TextChanged += new EventHandler(txtCASReactnumber_TextChanged);
        //        txtxpagesize.TextChanged += new EventHandler(txtCASReactnumber_TextChanged);
        //        txtxoffset.TextChanged += new EventHandler(txtCASReactnumber_TextChanged);
        //        txtypagesize.TextChanged += new EventHandler(txtCASReactnumber_TextChanged);
        //        txtyoffset.TextChanged += new EventHandler(txtCASReactnumber_TextChanged);
        //        //txtnarrativeid.TextChanged += new EventHandler(txtCASReactnumber_TextChanged);
        //        // chkisGeneralTypical.CheckStateChanged += new EventHandler(chkisGeneralTypical_CheckStateChanged);
        //        chkisgeneralprocempty.CheckStateChanged += new EventHandler(chkisgeneralprocempty_CheckStateChanged);
        //    }
        //}

        void chkisgeneralprocempty_CheckStateChanged(object sender, EventArgs e)
        {
            try
            {
                if (chkisgeneralprocempty.Checked)
                {
                    TanDetails.noexperimentaldetails = chkisgeneralprocempty.Checked;
                }
                else
                {
                    if (TanDetails.noexperimentaldetails == null)
                        TanDetails.noexperimentaldetails = false;

                    TanDetails.noexperimentaldetails = false;
                    chkisgeneralprocempty.Checked = false;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        //public CAS_Nar_Bll.clsCASChild GetReactionDetails()
        //{
        //    CAS_Nar_Bll.clsCASChild objreacdetails = new CAS_Nar_Bll.clsCASChild();
        //    try
        //    {
        //        objreacdetails.Rxnseq = Convert.ToInt32(txtrxnseq.Text);
        //        objreacdetails.ReactionCasReactantNumber = Convert.ToInt32(txtCASReactnumber.Text);
        //        objreacdetails.DocRef = txtdocref.Text.ToLower();
        //        objreacdetails.PageNumber = Convert.ToInt32(txtpagenumber.Text);
        //        objreacdetails.PageLabel = txtpagelabel.Text;

        //        objreacdetails.filename = txtfilename.Text;

        //        objreacdetails.XResUnit = txtxpageunit.Text;
        //        objreacdetails.XOffset = Convert.ToDouble(txtxoffset.Text);
        //        objreacdetails.XPageSize = Convert.ToDouble(TanDetails.XPageSize.ToString());
        //        //objreacdetails.XResValue = "inch";

        //        objreacdetails.YOffset = Convert.ToDouble(TanDetails.YOffset.ToString());
        //        objreacdetails.YPageSize = Convert.ToDouble(TanDetails.YPageSize.ToString());
        //        objreacdetails.YResUnit = txtyresunit.Text.ToString();
        //        //objreacdetails.YResValue = "inch";
        //        //txtyresvalue.Text = LstDocumentDetails[_recnumber].YResValue.ToString();
        //        objreacdetails.TextLine = rtxttextlinepreview.Text;
        //        objreacdetails.Para = rtxtparapreview.Text;
        //        //   objreacdetails.NarrativeID = txtnarrativeid.Text;

        //        objreacdetails.NarrativeID = GetNarId(); //txtnarrativeid.Text;

        //        objreacdetails.Para1 = txtpara1.Text;
        //        objreacdetails.Data = rtxtdatapreview.Text;
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //    return objreacdetails;
        //}

        //private void rtxttextlinepreview_TextChanged(object sender, EventArgs e)
        //{

        //}

        SautinSoft.HtmlToRtf h = null;
        public void ConvertHtmlToRtf(string strtext, HtmlRichText.HtmlRichTextBox rtfxcontrol)
        {

            try
            {
                if (rtfxcontrol != null)
                {
                    if (strtext != null && strtext != "")
                    {
                        //strtext = strtext.Replace("?", " "); Code commented by Sairam on 18th Nov 2013
                        strtext = strtext.Replace("<", "&lt;");
                        strtext = strtext.Replace(">", "&gt;");
                        strtext = strtext.Replace("&lt;bold&gt;", "<bold>");
                        strtext = strtext.Replace("&lt;/bold&gt;", "</bold>");
                        strtext = strtext.Replace("&lt;ital&gt;", "<ital>");
                        strtext = strtext.Replace("&lt;/ital&gt;", "</ital>");
                        strtext = strtext.Replace("&lt;sup&gt;", "<sup>");
                        strtext = strtext.Replace("&lt;/sup&gt;", "</sup>");
                        strtext = strtext.Replace("&lt;sub&gt;", "<sub>");
                        strtext = strtext.Replace("&lt;/sub&gt;", "</sub>");
                        strtext = strtext.Replace("<bold>", "<b>");
                        strtext = strtext.Replace("</bold>", "</b>");
                        strtext = strtext.Replace("<ital>", "<I>");
                        strtext = strtext.Replace("</ital>", "</I>");
                        strtext = strtext.Replace("<sup>", "<SUP>");
                        strtext = strtext.Replace("</sup>", "</SUP>");
                        strtext = strtext.Replace("<sub>", "<SUB>");
                        strtext = strtext.Replace("</sub>", "</SUB>");

                        h = new SautinSoft.HtmlToRtf();

                        //specify some options
                        h.OutputFormat = SautinSoft.HtmlToRtf.eOutputFormat.Rtf;
                        h.Encoding = SautinSoft.HtmlToRtf.eEncoding.AutoSelect;
                        h.PageStyle.PageSize.Letter();
                        h.FontFace = SautinSoft.HtmlToRtf.eFontFace.f_Calibri;

                        //string htmlstring = strtext;
                        //string rtf = h.ConvertString(strtext);

                        rtfxcontrol.Rtf = h.ConvertString(strtext);

                        //string strremovetext = rtfxcontrol.Rtf;
                        //rtfxcontrol.Rtf = strremovetext;

                        RemoveTrialVersionstring("", rtfxcontrol);
                    }
                    else
                    {
                        rtfxcontrol.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {
               // ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #region PreviewTextAndSetBackColor when keydown

        public void rtxttextlinepreview_KeyDown(object sender, KeyEventArgs e)
        {
            PreviewTextAndSetBackColor(sender, e);
        }

        private void rtxtparapreview_KeyDown(object sender, KeyEventArgs e)
        {
            PreviewTextAndSetBackColor(sender, e);
       
        }
   
        private void txtpara1_KeyDown(object sender, KeyEventArgs e)
        {
            PreviewTextAndSetBackColor(sender, e);
        }

        private void rtxtdatapreview_KeyDown(object sender, KeyEventArgs e)
        {
            PreviewTextAndSetBackColor(sender, e);
        }

        private void rtxtdata1_KeyDown(object sender, KeyEventArgs e)
        {
            PreviewTextAndSetBackColor(sender, e);
        }

        private void PreviewTextAndSetBackColor(object sender, KeyEventArgs e)
        {
            try
            {
                if (sender != null)
                {
                    HtmlRichTextBox htmltxt = (HtmlRichTextBox)sender;

                    if (e.KeyCode == Keys.F7)
                    {
                        GetPreviewTextfromRichtextbox(htmltxt);
                    }
                    else if (e.Control && e.KeyCode == Keys.V)
                    {
                        //rtxtparapreview.SelectionBackColor = Color.White;
                    }

                    if (e.KeyCode == Keys.Back)
                    {
                        htmltxt.SelectionBackColor = Color.White;
                        htmltxt.BackColor = Color.White;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        frmpreviewtext frmpre = null;
        private void HighlightUnknowSymbols(HtmlRichText.HtmlRichTextBox rtf)
        {

            try
            {
                ArrayList ht = new ArrayList();
                ht.Add("ä");
                ht.Add("");
                ht.Add("_");
                ht.Add("(()");
                ht.Add("íL");
                ht.Add("−");
                ht.Add("â");
                ht.Add("î");
                ht.Add("è");
                ht.Add("í");
                ht.Add("¢");//ãåö×ÃÄÅ
                ht.Add("é");
                ht.Add("ê");
                ht.Add("ë");
                ht.Add("ì");
                ht.Add("í");
                ht.Add("î");
                ht.Add("ï");
                ht.Add("ð");
                ht.Add("â");
                ht.Add("Á");
                ht.Add("À");
                ht.Add("Æ");
                ht.Add("¶");
                ht.Add("£");
                ht.Add("ø");
                ht.Add("À");
                ht.Add("Â");
                ht.Add("ù");
                ht.Add("ú");
                ht.Add("û");
                ht.Add("ü");


                for (int i = 0; i < ht.Count; i++)
                {
                    if (rtf.Text.Contains(ht[i].ToString()))
                    {
                        bool blnloop = false;
                        int startindex = 0;
                        indexOfSearchText = 0;
                        int start = 0;
                        while (blnloop == false)
                        {
                            if (ht[i].ToString().Length > 0)
                            {
                                startindex = FindMyText(ht[i].ToString(), start, rtf.Text.Length, rtf);
                                if (startindex == -1)
                                {
                                    blnloop = true;
                                }
                            }

                            if (startindex >= 0)
                            {
                                // Set the highlight color as red
                                int endindex = ht[i].ToString().Length;
                                // Highlight the search string
                                rtf.Select(startindex, endindex);

                                rtf.SelectionBackColor = Color.Red;

                                start = startindex + endindex;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
              //  ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        int indexOfSearchText = 0;
        int start = 0;
        private void RemoveTrialVersionstring(string strrtfstring, HtmlRichText.HtmlRichTextBox rtbox)
        {
            string str1 = "________________________________________________________";
            string str2 = "Trial version converts only first 100000 characters. Evaluation only.";
            string str3 = "Converted by HTML-to-RTF Pro DLL .Net 3.5.4.21.";
            string str4 = "(Licensed version doesn't display this notice!)";
            string str5 = "- Get license for the HTML-to-RTF Pro DLL .Net <http://www.sautinsoft.com/products/html-to-rtf/order.php>";
            string str6 = "\n\n\n\n\n\n";

            string[] strvalues = new string[6] { str1, str2, str3, str4, str5, str6 };
            try
            {

                foreach (string str in strvalues)
                {
                    if (rtbox.Text.Contains(str))
                    {
                        bool blnloop = false;
                        int startindex = 0;

                        indexOfSearchText = 0;
                        start = 0;
                        while (blnloop == false)
                        {

                            if (str.Length > 0)
                            {
                                startindex = FindMyText(str.Trim(), start, rtbox.Text.Length, rtbox);
                                if (startindex == -1)
                                {
                                    blnloop = true;
                                }
                            }

                            if (startindex >= 0)
                            {
                                // Set the highlight color as red
                                int endindex = str.Length;
                                // Highlight the search string
                                rtbox.Select(startindex, endindex);
                                rtbox.SelectedRtf = "";
                                blnloop = true;
                                rtbox.SelectAll();
                                //start = startindex + endindex;
                                // continue;

                            }
                        }
                        continue;

                    }
                }

                rtbox.Rtf = rtbox.Rtf.ToString().Replace("\r\n", "").Trim();
                //rtbox.Text = rtbox.Text.Trim();
                rtbox.Text.Trim();
            }
            catch (Exception ex)
            {
              //  ErrorHandling.WriteErrorLog(ex.ToString());
            }


        }

        /// <summary>
        /// Find Text
        /// </summary>
        /// <param name="txtToSearch"></param>
        /// <param name="searchStart"></param>
        /// <param name="searchEnd"></param>
        /// <param name="rtb"></param>
        /// <returns></returns>
        public int FindMyText(string txtToSearch, int searchStart, int searchEnd, HtmlRichText.HtmlRichTextBox rtb)
        {
            // Unselect the previously searched string
            //if (searchStart > 0 && searchEnd > 0 && indexOfSearchText >= 0)
            //{
            //    return -1;
            //   // rtb.Undo();
            //}

            // Set the return value to -1 by default.
            int retVal = -1;

            // A valid starting index should be specified.
            // if indexOfSearchText = -1, the end of search
            if (searchStart >= 0 && indexOfSearchText >= 0)
            {
                // A valid ending index
                if (searchEnd > searchStart || searchEnd == -1)
                {
                    rtb.Refresh();
                    // Find the position of search string in RichTextBox
                    indexOfSearchText = rtb.Find(txtToSearch, searchStart, searchEnd, RichTextBoxFinds.None);
                    //indexOfSearchText = rtb.Find(txtToSearch);
                    // Determine whether the text was found in richTextBox1.
                    //if (indexOfSearchText != searchStart)
                    //{
                    // Return the index to the specified search text.
                    retVal = indexOfSearchText;
                    //}
                    //else
                    //{
                    //    return -1;
                    //}
                }
            }
            return retVal;
        }

        #region SetBackColorWhite when Click

        private void rtxttextlinepreview_Click(object sender, EventArgs e)
        {
            SetBackColorWhite(sender);
        }

        private void rtxtparapreview_Click(object sender, EventArgs e)
        {
            SetBackColorWhite(sender);
        }

        private void txtpara1_Click(object sender, EventArgs e)
        {
            SetBackColorWhite(sender);
        }

        private void rtxtdatapreview_Click(object sender, EventArgs e)
        {
            SetBackColorWhite(sender);
        }

        private static void SetBackColorWhite(object sender)
        {
            try
            {
                if (sender != null)
                {
                    HtmlRichTextBox htmltxt = (HtmlRichTextBox)sender;
                    htmltxt.BackColor = Color.White;
                }
            }
            catch (Exception ex)
            {

                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }


        #endregion

        private void uccasnartool_Load(object sender, EventArgs e)
        {
            try
            {
                //if (!Generic.globalVariables.IsPatent)
                //{
                //    chkisGeneralTypical.Enabled = false;
                //    chkisgeneralprocempty.Enabled = false;
                //}

                //if (Generic.globalVariables.IsPatent)
                //{
                //    txtdocref.ReadOnly = true;
                //    txtdocref.Text = "doc1";
                //}
                //else
                //{
                //    txtdocref.Text = "";
                //    txtdocref.ReadOnly = false;
                //}

                //htsymbols = HtFindAndReplace;
                // FillDocrefs();
                //                FillRXNNum();
                // FillCasReactnum();
                //  FillCasReactSequences();

            }
            catch (Exception ex)
            {
               // ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        //public void FillRXNNum()
        //{
        //    for (int i = 1; i <= 10000; i++)
        //    {
        //        _autoCompleRxnNum.Add(i.ToString());
        //    }
        //    txtCASReactnumber.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
        //    txtCASReactnumber.AutoCompleteSource = AutoCompleteSource.CustomSource;
        //    txtCASReactnumber.AutoCompleteCustomSource = _autoCompleRxnNum;
        //}

        //public void FillCasReactnum()
        //{
        //    if (Generic.globalVariables.HtNumAndSeq != null)
        //    {
        //        if (Generic.globalVariables.HtNumAndSeq.Count > 0)
        //        {
        //            for (int i = 0; i < Generic.globalVariables.HtNumAndSeq.Count; i++)
        //            {
        //                if (Generic.globalVariables.HtNumAndSeq[i].SEQ != 0)
        //                    _autoCompleRxnNum.Add(Generic.globalVariables.HtNumAndSeq[i].NUM.ToString("0000"));
        //            }
        //            txtCASReactnumber.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
        //            txtCASReactnumber.AutoCompleteSource = AutoCompleteSource.CustomSource;
        //            txtCASReactnumber.AutoCompleteCustomSource = _autoCompleRxnNum;
        //        }


        //    }
        //}

        //public void FillCasReactSequences()
        //{
        //    if (Generic.globalVariables.HtNumAndSeq != null)
        //    {
        //        if (Generic.globalVariables.HtNumAndSeq.Count > 0)
        //        {
        //            for (int i = 0; i < Generic.globalVariables.HtNumAndSeq.Count; i++)
        //            {
        //                if (Generic.globalVariables.HtNumAndSeq[i].NUM != 0)
        //                    _autoCompleRxnSEQ.Add(Generic.globalVariables.HtNumAndSeq[i].SEQ.ToString("0000"));
        //            }
        //            txtrxnseq.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
        //            txtrxnseq.AutoCompleteSource = AutoCompleteSource.CustomSource;
        //            txtrxnseq.AutoCompleteCustomSource = _autoCompleRxnSEQ;
        //        }
        //    }
        //}

        //public void FillRXNSeq()
        //{
        //    for (int i = 1; i <= 3; i++)
        //    {
        //        _autoCompleRxnSEQ.Add(i.ToString());
        //    }
        //    txtrxnseq.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
        //    txtrxnseq.AutoCompleteSource = AutoCompleteSource.CustomSource;
        //    txtrxnseq.AutoCompleteCustomSource = _autoCompleRxnSEQ;
        //}

        //public void FillNarrative()
        //{
        //    _autocompleNarrative.Add("nar");
        //    _autocompleNarrative.Add("nar analogousTo=nar");
        //    txtnarrativeid.AutoCompleteMode = AutoCompleteMode.Append;
        //    txtnarrativeid.AutoCompleteSource = AutoCompleteSource.CustomSource;
        //    txtnarrativeid.AutoCompleteCustomSource = _autocompleNarrative;
        //}

        //private void txtnarrativeid_KeyPress(object sender, KeyPressEventArgs e)
        //{
        //    try
        //    {
        //        int narrativeidlimit = 99999;// Convert.ToInt32(ConfigurationSettings.AppSettings["NarrativeIDLimit"]);
        //        if (txtnarrativeid.Text != null)
        //        {
        //            if (txtnarrativeid.Text.StartsWith("nar") && txtnarrativeid.Text.Length < Convert.ToInt32(3 + narrativeidlimit.ToString().Length + 1))
        //            {
        //                if (e.KeyChar.ToString() == "a")
        //                {
        //                    //TanDetails.isGeneralTypical

        //                    if (!TanDetails.isGeneralTypical)
        //                    {
        //                        string strtxt = txtnarrativeid.Text;
        //                        txtnarrativeid.Text = strtxt + "analogousTo=nar";
        //                        txtnarrativeid.Select(txtnarrativeid.Text.Length + 1, 1);
        //                        e.Handled = true;
        //                    }
        //                    else
        //                    {
        //                        MessageBox.Show("IsGeneralTypical does not carry analogousTo", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //                        e.Handled = false;
        //                    }
        //                }
        //            }

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}

        //private void txtCASReactnumber_KeyPress(object sender, KeyPressEventArgs e)
        //{
        //    try
        //    {
        //        if (((e.KeyChar >= 48 && e.KeyChar <= 57) || e.KeyChar == 8 || e.KeyChar == 46 || e.KeyChar == 45) != true)
        //        {
        //            e.Handled = true;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message.ToString());
        //    }
        //}

        //private void txtrxnseq_KeyPress(object sender, KeyPressEventArgs e)
        //{
        //    try
        //    {
        //        if (((e.KeyChar >= 48 && e.KeyChar <= 57) || e.KeyChar == 8 || e.KeyChar == 46 || e.KeyChar == 45) != true)
        //        {
        //            e.Handled = true;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message.ToString());
        //    }
        //}

        #region Allow Numbers,Dot,Hyphen,BackSpace when keypress

        private void txtpagenumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            AllowNumsBackSpaceDotAndHyphen(e);
        }

        private void txtxoffset_KeyPress(object sender, KeyPressEventArgs e)
        {
            AllowNumsBackSpaceDotAndHyphen(e);
        }

        private void txtyoffset_KeyPress(object sender, KeyPressEventArgs e)
        {
            AllowNumsBackSpaceDotAndHyphen(e);
        }

        private void txtypagesize_KeyPress(object sender, KeyPressEventArgs e)
        {
            AllowNumsBackSpaceDotAndHyphen(e);
        }

        private void txtxpagesize_KeyPress(object sender, KeyPressEventArgs e)
        {
            AllowNumsBackSpaceDotAndHyphen(e);
        }

        private static void AllowNumsBackSpaceDotAndHyphen(KeyPressEventArgs e)
        {
            try
            {
                // Asci--------char
                //   48         '0'
                //   57         '9'
                //    8         'BackSpace'
                //   46         '.'
                //   45         '-'
                if (((e.KeyChar >= 48 && e.KeyChar <= 57) || e.KeyChar == 8 || e.KeyChar == 46 || e.KeyChar == 45) != true)
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }


        #endregion

        //public void btnDelete_Click(object sender, EventArgs e)
        //{
        //    Clicked = true;
        //}

        //public void txtnarrativeid_Leave(object sender, EventArgs e)
        //{
        //    txtnarrativeid.Tag = this.Name;
        //    if (txtnarrativeid.Text.Contains("analogousTo=nar"))
        //    {
        //        chkisgeneralprocempty.Checked = false;
        //    }
        //}

        #region PageSize and offsets

        private void txtxpagesize_Click(object sender, EventArgs e)
        {
            GetPastePageSize();
        }

        private void GetPastePageSize()
        {
            try
            {

                // Assign page Size ( if page size is 0 or null ).
                if (Clipboard.GetData(DataFormats.Text) != null)
                {
                    string str = Clipboard.GetData(DataFormats.Text).ToString();
                    if (str.Contains("PAGESIZES : ") && (txtxpagesize.Text == "" || txtxpagesize.Text == "0") && (txtypagesize.Text == "" || txtypagesize.Text == "0"))
                    {
                        double XPageSize = 0.0;
                        double YPageSize = 0.0;
                        char[] c = new char[1] { ':' };
                        string[] strxy = str.Split(c, StringSplitOptions.RemoveEmptyEntries);
                        if (strxy != null)
                        {
                            XPageSize = Convert.ToDouble(strxy[1].Trim());
                            YPageSize = Convert.ToDouble(strxy[2].Trim());
                            // Update total usercontrol pagesizes in tablelayoutcontrol.
                            for (int i = 0; i < this.Parent.Controls.Count; i++)
                            {
                                Control cn = this.Parent.Controls[i];
                                if (cn.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
                                {
                                    uccasnartool_new uc = (uccasnartool_new)cn;
                                    if (uc.txtdocref.Text == txtdocref.Text)
                                    {
                                        uc.txtxpagesize.Text = strxy[1].Trim();
                                        uc.txtypagesize.Text = strxy[2].Trim();
                                    }
                                }
                            }
                            // UpdateAllPageSizeDetails(XPageSize, YPageSize, txtdocref.Text);
                            Clipboard.Clear();
                        }
                    }
                    // if already has Page size It overrides in all usercontrol of tan.
                    else if (str.Contains("PAGESIZES : ") && txtxpagesize.Text != "" & txtypagesize.Text != "")
                    {
                        string strmsg = " Do you want update " + txtdocref.Text + " Pagesize values ? ";
                        if (MessageBox.Show(strmsg, "CAS Narrative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                        {
                            double XPageSize = 0.0;
                            double YPageSize = 0.0;
                            char[] c = new char[1] { ':' };
                            string[] strxy = str.Split(c, StringSplitOptions.RemoveEmptyEntries);
                            if (strxy != null)
                            {
                                XPageSize = Convert.ToDouble(strxy[1].Trim());
                                YPageSize = Convert.ToDouble(strxy[2].Trim());

                                //if (DAL.CASNarrativeDataAccess.UpdateAllPageSizes(TAN, txtdocref.Text, XPageSize, YPageSize))

                                // Update total usercontrol pagesizes in tablelayoutcontrol.
                                for (int i = 0; i < this.Parent.Controls.Count; i++)
                                {
                                    Control cn = this.Parent.Controls[i];
                                    if (cn.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
                                    {
                                        uccasnartool_new uc = (uccasnartool_new)cn;
                                        if (uc.txtdocref.Text == txtdocref.Text)
                                        {
                                            uc.txtxpagesize.Text = XPageSize.ToString();
                                            uc.txtypagesize.Text = YPageSize.ToString();
                                        }
                                    }
                                }

                                //UpdateAllPageSizeDetails(XPageSize, YPageSize, txtdocref.Text);
                                Clipboard.Clear();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        //// Update all pagesizes throw out tan.
        //private void UpdateAllPageSizeDetails(double xPagesize, double yPagesize, string docRef)
        //{
        //    if(frmTANView_new._lsttanchild!=null)
        //    {
        //        if (frmTANView_new._lsttanchild.Count != 0)
        //    {
        //        for (int i = 0; i < frmTANView_new._lsttanchild.Count; i++)
        //        {
        //            if (frmTANView_new._lsttanchild[i].DocRef == docRef)
        //            {
        //                frmTANView_new._lsttanchild[i].XPageSize = xPagesize;
        //                frmTANView_new._lsttanchild[i].YPageSize = yPagesize;

        //            }
        //        }
        //    }
        //    }
        //}

        private void GetPasteCoordinates()
        {
            try
            {
                // Assign in pageoffset ( if page offset is 0 or null ).
                if (Clipboard.GetData(DataFormats.Text) != null)
                {
                    string str = Clipboard.GetData(DataFormats.Text).ToString();
                    if (str.Contains("XYOFFSETS : ") && (txtxoffset.Text == "" || txtxoffset.Text == "0") && (txtyoffset.Text == "" || txtyoffset.Text == "0"))
                    {
                        char[] c = new char[1] { ':' };
                        string[] strxy = str.Split(c, StringSplitOptions.RemoveEmptyEntries);
                        if (strxy != null)
                        {
                            txtxoffset.Text = strxy[1].Trim();
                            txtyoffset.Text = strxy[2].Trim();
                            Clipboard.Clear();
                        }
                    }
                    // if already has Page offset It overrides.
                    else if (str.Contains("XYOFFSETS : ") && txtxoffset.Text != "" & txtyoffset.Text != "")
                    {
                        string strmsg = " Do you want update " + txtdocref.Text + " offset values ? ";
                        if (MessageBox.Show(strmsg, "CAS Narrative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                        {
                            char[] c = new char[1] { ':' };
                            string[] strxy = str.Split(c, StringSplitOptions.RemoveEmptyEntries);
                            if (strxy != null)
                            {
                                txtxoffset.Text = strxy[1].Trim();
                                txtyoffset.Text = strxy[2].Trim();
                                Clipboard.Clear();
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtxoffset_Click(object sender, EventArgs e)
        {
            GetPasteCoordinates();
        }

        private void txtyoffset_Click(object sender, EventArgs e)
        {
            GetPasteCoordinates();
        }

        private void txtypagesize_Click(object sender, EventArgs e)
        {
            GetPastePageSize();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtxoffset.Text != null && txtxoffset.Text != "" && Convert.ToDouble(txtxoffset.Text) != 0)
                {
                    double xoffset = Convert.ToDouble(txtxoffset.Text);
                    double yoffset = Convert.ToDouble(txtyoffset.Text);
                    if (MessageBox.Show("X offset value '" + xoffset.ToString("0.00") + "',Y Offset value '" + yoffset.ToString("0.00") + "', Do you want to save these values in clipboard?", "CAS Narrative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {

                        Clipboard.Clear();
                        Clipboard.SetData(DataFormats.Text, "XYOFFSETS : " + xoffset.ToString("0.00") + ":" + yoffset.ToString("0.00"));
                    }


                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        #region AddPreZeros

        //private void txtCASReactnumber_Validated(object sender, EventArgs e)
        //{
        //    AddPreZeros(sender);
        //}

        //private void txtrxnseq_Validated(object sender, EventArgs e)
        //{
        //    AddPreZeros(sender);
        //}

        //private static void AddPreZeros(object sender)
        //{
        //    try
        //    {
        //        TextBox txt = new TextBox();
        //        if (sender != null)
        //        {
        //            txt = (TextBox)sender;
        //        }

        //        if (txt.Text != null)
        //        {
        //            int i = Convert.ToInt32(txt.Text);
        //            txt.Text = i.ToString("0000");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}


        #endregion

        #region ToolStrip WordWrap,Horizental,Vertical,both scroll,tranfertotexteditor,Clear,Format

        private void tsWordWrap_Click(object sender, EventArgs e)
        {
            bool blntrue = false;
            if (tsWordWrap.Checked)
            {
                blntrue = false;
                tsWordWrap.Checked = false;
            }
            else
            {
                blntrue = true;
                tsWordWrap.Checked = true;
            }
            if (blntrue)
            {
                if (rtxtdatapreview.Focused)
                {
                    rtxtdatapreview.WordWrap = true;

                }
                if (rtxtparapreview.Focused)
                {
                    rtxtparapreview.WordWrap = true;

                }
                if (txtpara1.Focused)
                {
                    txtpara1.WordWrap = true;
                }

            }
            else
            {
                tsWordWrap.Checked = false;
                if (rtxtdatapreview.Focused)
                {
                    rtxtdatapreview.WordWrap = false;
                }
                if (rtxtparapreview.Focused)
                {
                    rtxtparapreview.WordWrap = false;

                }
                if (txtpara1.Focused)
                {
                    txtpara1.WordWrap = false;
                }
            }

        }

        private void TshScrollbar_Click(object sender, EventArgs e)
        {
            bool blntrue = false;
            if (TshScrollbar.Checked)
            {
                blntrue = false;
                TshScrollbar.Checked = false;
            }
            else
            {
                blntrue = true;
                TshScrollbar.Checked = true;
            }
            if (blntrue)
            {
                if (rtxtdatapreview.Focused)
                {
                    rtxtdatapreview.ScrollBars = RichTextBoxScrollBars.Horizontal;
                }
                if (rtxtparapreview.Focused)
                {
                    rtxtparapreview.ScrollBars = RichTextBoxScrollBars.Horizontal;
                }
                if (txtpara1.Focused)
                {
                    txtpara1.ScrollBars = RichTextBoxScrollBars.Horizontal;
                }
            }
            else
            {
                if (rtxtdatapreview.Focused)
                {
                    rtxtdatapreview.ScrollBars = RichTextBoxScrollBars.None;
                }
                if (rtxtparapreview.Focused)
                {
                    rtxtparapreview.ScrollBars = RichTextBoxScrollBars.None;
                }
                if (txtpara1.Focused)
                {
                    txtpara1.ScrollBars = RichTextBoxScrollBars.None;
                }

            }

        }

        private void tsvscrollbars_Click(object sender, EventArgs e)
        {
            bool blntrue = false;
            if (tsvscrollbars.Checked)
            {
                blntrue = false;
                tsvscrollbars.Checked = false;
            }
            else
            {
                blntrue = true;
                tsvscrollbars.Checked = true;
            }
            if (blntrue)
            {
                if (rtxtdatapreview.Focused)
                {
                    rtxtdatapreview.ScrollBars = RichTextBoxScrollBars.Vertical;
                }
                if (rtxtparapreview.Focused)
                {
                    rtxtparapreview.ScrollBars = RichTextBoxScrollBars.Vertical;
                }
                if (txtpara1.Focused)
                {
                    txtpara1.ScrollBars = RichTextBoxScrollBars.Vertical;
                }
            }
            else
            {
                if (rtxtdatapreview.Focused)
                {
                    rtxtdatapreview.ScrollBars = RichTextBoxScrollBars.None;
                }
                if (rtxtparapreview.Focused)
                {
                    rtxtparapreview.ScrollBars = RichTextBoxScrollBars.None;
                }
                if (txtpara1.Focused)
                {
                    txtpara1.ScrollBars = RichTextBoxScrollBars.None;
                }
            }
        }

        private void tsboth_Click(object sender, EventArgs e)
        {
            bool blntrue = false;
            if (tsboth.Checked)
            {
                blntrue = false;
                tsboth.Checked = false;
            }
            else
            {
                blntrue = true;
                tsboth.Checked = true;
            }
            if (blntrue)
            {
                if (rtxtdatapreview.Focused)
                {
                    rtxtdatapreview.ScrollBars = RichTextBoxScrollBars.Both;
                }
                if (rtxtparapreview.Focused)
                {
                    rtxtparapreview.ScrollBars = RichTextBoxScrollBars.Both;
                }
                if (txtpara1.Focused)
                {
                    txtpara1.ScrollBars = RichTextBoxScrollBars.Both;
                }
            }
            else
            {
                if (rtxtdatapreview.Focused)
                {
                    rtxtdatapreview.ScrollBars = RichTextBoxScrollBars.None;
                }
                if (rtxtparapreview.Focused)
                {
                    rtxtparapreview.ScrollBars = RichTextBoxScrollBars.None;
                }
                if (txtpara1.Focused)
                {
                    txtpara1.ScrollBars = RichTextBoxScrollBars.None;
                }

            }
        }

        private void TsPaste_Click(object sender, EventArgs e)
        {
            TsPaste.CheckOnClick = true;
        }

        private void transferToTextEditorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {

                if (rtxtdatapreview.Focused)
                {
                    if (rtxtdatapreview.Rtf != null)
                        RTFData = rtxtdatapreview.Rtf;

                    rtxtdatapreview.BackColor = Color.LightBlue;
                    rtxtparapreview.BackColor = Color.White;
                    txtpara1.BackColor = Color.White;
                    rtxttextlinepreview.BackColor = Color.White;

                }
                if (rtxtparapreview.Focused)
                {
                    if (rtxtparapreview.Rtf != null)
                        RTFData = rtxtparapreview.Rtf;
                    rtxtparapreview.BackColor = Color.LightBlue;

                    rtxtdatapreview.BackColor = Color.White;

                    txtpara1.BackColor = Color.White;
                    rtxttextlinepreview.BackColor = Color.White;


                }
                if (txtpara1.Focused)
                {
                    if (txtpara1.Rtf != null)
                        RTFData = txtpara1.Rtf;
                    txtpara1.BackColor = Color.LightBlue;


                    rtxtparapreview.BackColor = Color.White;

                    rtxtdatapreview.BackColor = Color.White;


                    rtxttextlinepreview.BackColor = Color.White;


                }
                if (rtxttextlinepreview.Focused)
                {
                    if (rtxttextlinepreview.Rtf != null)
                        RTFData = rtxttextlinepreview.Rtf;
                    rtxttextlinepreview.BackColor = Color.LightBlue;

                    txtpara1.BackColor = Color.White;

                    rtxtparapreview.BackColor = Color.White;

                    rtxtdatapreview.BackColor = Color.White;



                }
                if (RTFData != null)
                {
                    transferToTextEditorToolStripMenuItem.Tag = RTFData;
                }
                transferToTextEditorToolStripMenuItem.Checked = true;

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }

        }

        private void clearBackColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (rtxtdatapreview.Focused)
                {
                    rtxtdatapreview.SelectionBackColor = Color.White;
                }
                if (rtxtparapreview.Focused)
                {
                    rtxtparapreview.SelectionBackColor = Color.White;
                }
                if (txtpara1.Focused)
                {
                    txtpara1.SelectionBackColor = Color.White;
                }
                if (rtxttextlinepreview.Focused)
                {
                    rtxttextlinepreview.SelectionBackColor = Color.White;
                }

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void formatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            #region Old code commented by Sairam on 15th Nov 2013
            //try
            //{

            //    if (rtxtdatapreview.Focused)
            //    {
            //        FormatText(rtxtdatapreview);
            //    }
            //    if (rtxtparapreview.Focused)
            //    {

            //        FormatText(rtxtparapreview);
            //    }
            //    if (txtpara1.Focused)
            //    {

            //        FormatText(txtpara1);
            //    }
            //    if (rtxttextlinepreview.Focused)
            //    {

            //        FormatText(rtxttextlinepreview);
            //    }
            //    if (rtxtdata1.Focused)
            //    {

            //        FormatText(rtxtdata1);
            //    }

            //}
            //catch (Exception ex)
            //{
            //    ErrorHandling.WriteErrorLog(ex.ToString());
            //} 
            #endregion

            try
            {
                if (rtxtdatapreview.Focused)
                {
                    FormatText(rtxtdatapreview);
                    HtmlRichTextBox[] ControlsToHeighlight = new HtmlRichTextBox[] { this.rtxtdatapreview };
                    // Heighlight Special character with Red color.
                    // To the Fields of TextLine,Para1,Para2,Data in Usercontrol.
                    HeighlightSpecialCharacters(Generic.globalVariables.LstSpecialChar_Pat_journal, Color.Orange, ControlsToHeighlight);
                }
                if (rtxtparapreview.Focused)
                {

                    FormatText(rtxtparapreview);
                    HtmlRichTextBox[] ControlsToHeighlight = new HtmlRichTextBox[] { this.rtxtparapreview };
                    // Heighlight Special character with Red color.
                    // To the Fields of TextLine,Para1,Para2,Data in Usercontrol.
                    HeighlightSpecialCharacters(Generic.globalVariables.LstSpecialChar_Pat_journal, Color.Orange, ControlsToHeighlight);
                }
                if (txtpara1.Focused)
                {
                    FormatText(txtpara1);
                    HtmlRichTextBox[] ControlsToHeighlight = new HtmlRichTextBox[] { this.txtpara1 };
                    // Heighlight Special character with Red color.
                    // To the Fields of TextLine,Para1,Para2,Data in Usercontrol.
                    HeighlightSpecialCharacters(Generic.globalVariables.LstSpecialChar_Pat_journal, Color.Orange, ControlsToHeighlight);

                }
                if (rtxttextlinepreview.Focused)
                {
                    FormatText(rtxttextlinepreview);
                    HtmlRichTextBox[] ControlsToHeighlight = new HtmlRichTextBox[] { this.rtxttextlinepreview };
                    // Heighlight Special character with Red color.
                    // To the Fields of TextLine,Para1,Para2,Data in Usercontrol.
                    HeighlightSpecialCharacters(Generic.globalVariables.LstSpecialChar_Pat_journal, Color.Orange, ControlsToHeighlight);
                }
                if (rtxtdata1.Focused)
                {
                    FormatText(rtxtdata1);
                    HtmlRichTextBox[] ControlsToHeighlight = new HtmlRichTextBox[] { this.rtxtdata1 };
                    // Heighlight Special character with Red color.
                    // To the Fields of TextLine,Para1,Para2,Data in Usercontrol.
                    HeighlightSpecialCharacters(Generic.globalVariables.LstSpecialChar_Pat_journal, Color.Orange, ControlsToHeighlight);
                }
                // Heighlight Analogous When nar analogous to another nar.
                HighlightAnalogous();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }


        private void FormatText(HtmlRichText.HtmlRichTextBox _rtf)
        {
            SautinSoft.RtfToHtml r = new SautinSoft.RtfToHtml();

            r.OutputFormat = SautinSoft.eOutputFormat.HTML_401;//SautinSoft.RtfToHtml.eOutputFormat.HTML_401;//
            r.Encoding = SautinSoft.eEncoding.UTF_8;//SautinSoft.RtfToHtml.eEncoding.UTF_8;

            string rtfString = _rtf.Rtf.ToString();
            //rtfString = rtfString.Replace("?", " "); //Code commented by Sairam on 18th Nov 2013
            rtfString = rtfString.Replace("<", "&lt;");
            rtfString = rtfString.Replace(">", "&gt;");
            string htmlString = "";

            htmlString = r.ConvertString(rtfString);
            //r.Serial = "112426524068666867007561616-44728270";

            Hashtable htsymbols = HtSymbols;

            if (htsymbols != null)
            {
                try
                {
                    foreach (string strkey in htsymbols.Keys)
                    {
                        if (strkey != "")
                        {
                            if (htmlString.Contains(strkey))
                            {
                                htmlString = htmlString.Replace(strkey, htsymbols[strkey].ToString());
                            }
                        }
                    }
                }
                catch (Exception ex)
                {

                }
            }
            //tb1rtftextbox.GetHTML(true,true)

            tb1rtxteditor.Document.body.innerHTML = htmlString;

            // htmlString = "";

            string strremovestr1 = "Trial version can convert no more than 30000 symbols.";
            string strremovestr2 = "Get the full \r\nfeatured version!</A>";
            string strremovestr3 = "";

            //htmlString = r.ConvertString(rtfString);
            tb1rtxteditor.SelectAll();

            IHTMLSelectionObject objselection = tb1rtxteditor.Document.selection;
            IHTMLTxtRange objrange = (IHTMLTxtRange)objselection.createRange();

            string strtempfilepath = AppDomain.CurrentDomain.BaseDirectory + "temp.txt";
            //htmlString = element.innerHTML;
            htmlString = objrange.htmlText;
            StreamReader sr = new StreamReader(strtempfilepath);
            strremovestr3 = sr.ReadToEnd();

            if (htmlString.Contains(strremovestr1))
            {
                htmlString = htmlString.Replace(strremovestr1, "");
            }
            if (htmlString.Contains(strremovestr2))
            {
                htmlString = htmlString.Replace(strremovestr2, "");
            }

            if (!string.IsNullOrEmpty(strremovestr3))
            {
                if (htmlString.Contains(strremovestr3))
                {
                    htmlString = htmlString.Replace(strremovestr3, "");
                }
            }

            string strpreview = validations.richtextvalidations.stripHTMLTags(htmlString);
            strpreview = strpreview.Replace("&lt;", "<");
            strpreview = strpreview.Replace("&gt;", ">");
            strpreview = strpreview.Replace("&amp;", "&");
            strpreview = validations.richtextvalidations.FindAndReplaceStrings(strpreview, Generic.globalVariables.DsFindAndReplace);
            strpreview = strpreview.Replace("&nbsp;", " ").TrimEnd();
            strpreview = strpreview.Replace("<bold></bold>", "");
            strpreview = strpreview.Replace("<ital><bold></bold></ital>", "");
            strpreview = strpreview.Replace("<ital></ital>", "");
            strpreview = strpreview.Replace("<bold> </bold>", "");

            string strtext = strpreview;
            strtext = strtext.Replace("<bold>", "<b>");
            strtext = strtext.Replace("</bold>", "</b>");
            strtext = strtext.Replace("<ital>", "<I>");
            strtext = strtext.Replace("</ital>", "</I>");
            strtext = strtext.Replace("<sup>", "<SUP>");
            strtext = strtext.Replace("</sup>", "</SUP>");
            strtext = strtext.Replace("<sub>", "<SUB>");
            strtext = strtext.Replace("</sub>", "</SUB>");
            try
            {
                SautinSoft.HtmlToRtf h = new SautinSoft.HtmlToRtf();

                //specify some options
                h.OutputFormat = SautinSoft.HtmlToRtf.eOutputFormat.Rtf;
                h.Encoding = SautinSoft.HtmlToRtf.eEncoding.AutoSelect;
                h.PageStyle.PageSize.Letter();
                //h.FontFace = SautinSoft.HtmlToRtf.eFontFace.f_Verdana;
                h.FontFace = SautinSoft.HtmlToRtf.eFontFace.f_Calibri;
                string _htmlstring = strtext;
                string rtf = h.ConvertString(_htmlstring);

                _rtf.Rtf = rtf;

                string strremovetext = _rtf.Rtf;
                _rtf.Rtf = strremovetext;

                RemoveTrialVersionstring("", _rtf);

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }


        #endregion

        #region Preview from richtextbox

        private void GetPreviewTextfromRichtextbox(HtmlRichText.HtmlRichTextBox rtf)
        {
            try
            {
                SautinSoft.RtfToHtml r = new SautinSoft.RtfToHtml();

                r.OutputFormat = SautinSoft.eOutputFormat.HTML_401;//SautinSoft.RtfToHtml.eOutputFormat.HTML_401;
                r.Encoding = SautinSoft.eEncoding.UTF_8;//SautinSoft.RtfToHtml.eEncoding.UTF_8;

                string rtfFile = rtf.Rtf.ToString();
                string rtfString = rtf.Rtf.ToString();
                string htmlString = "";

                //htmlString = tb1rtftextbox.GetHTML(true, true);
                htmlString = r.ConvertString(rtfString);

                Hashtable htsymbols = HtSymbols;

                if (htsymbols != null)
                {
                    foreach (string strkey in htsymbols.Keys)
                    {
                        if (htmlString.Contains(strkey))
                        {
                            htmlString = htmlString.Replace(strkey, htsymbols[strkey].ToString());
                        }
                    }
                }
                //tb1rtftextbox.GetHTML(true,true)

                //f
                tb1rtxteditor.Document.body.innerHTML = htmlString;
                if (validations.Validatations.CheckFormIsOpenedORnot("frmpreviewtext", frmpre))
                {
                    frmpre.Close();
                }

                frmpre = new frmpreviewtext();

                htmlString = "";
                //h
                string strremovestr1 = "Trial version can convert no more than 30000 symbols.";
                string strremovestr2 = "Get the full \r\nfeatured version!</A>";
                string strremovestr3 = "";



                //htmlString = r.ConvertString(rtfString);
                //f
                tb1rtxteditor.SelectAll();

                IHTMLSelectionObject objselection = tb1rtxteditor.Document.selection;
                IHTMLTxtRange objrange = (IHTMLTxtRange)objselection.createRange();
                //h


                string strtempfilepath = AppDomain.CurrentDomain.BaseDirectory + "temp.txt";
                //htmlString = element.innerHTML;
                htmlString = objrange.htmlText;
                StreamReader sr = new StreamReader(strtempfilepath);
                strremovestr3 = sr.ReadToEnd();

                if (!string.IsNullOrEmpty(strremovestr1))
                {
                    if (htmlString.Contains(strremovestr1))
                    {
                        htmlString = htmlString.Replace(strremovestr1, "");
                    }
                }

                if (!string.IsNullOrEmpty(strremovestr2))
                {
                    if (htmlString.Contains(strremovestr2))
                    {
                        htmlString = htmlString.Replace(strremovestr2, "");
                    }
                }

                if (!string.IsNullOrEmpty(strremovestr3))
                {
                    if (htmlString.Contains(strremovestr3))
                    {
                        htmlString = htmlString.Replace(strremovestr3, "");
                    }
                }

                string strpreview = validations.richtextvalidations.stripHTMLTags(htmlString);
                strpreview = strpreview.Replace("&lt;", "<");
                strpreview = strpreview.Replace("&gt;", ">");
                strpreview = strpreview.Replace("&amp;", "&");
                strpreview = validations.richtextvalidations.FindAndReplaceStrings(strpreview, Generic.globalVariables.DsFindAndReplace);
                strpreview = strpreview.Replace("&nbsp;", " ").TrimEnd();
                strpreview = strpreview.Replace("<bold></bold>", "");
                strpreview = strpreview.Replace("<ital><bold></bold></ital>", "");
                strpreview = strpreview.Replace("<ital></ital>", "");
                strpreview = strpreview.Replace("<bold> </bold>", "");

                frmpre.PreviewString = strpreview.Trim();

                frmpre.Show();




            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        SautinSoft.RtfToHtml r = null;
        private string GetPreviewStringfromRichtextbox(HtmlRichText.HtmlRichTextBox rtf)
        {
            try
            {
                r = new SautinSoft.RtfToHtml();
                r.OutputFormat = SautinSoft.eOutputFormat.HTML_401;//SautinSoft.RtfToHtml.eOutputFormat.HTML_401;
                r.Encoding = SautinSoft.eEncoding.UTF_8;//SautinSoft.RtfToHtml.eEncoding.UTF_8;

                //string rtfFile = rtf.Rtf.ToString();
                // string rtfString = rtf.Rtf.ToString();
                string htmlString = "";

                //htmlString = tb1rtftextbox.GetHTML(true, true);
                htmlString = r.ConvertString(rtf.Rtf.ToString());

                Hashtable htsymbols = HtSymbols;

                if (htsymbols != null)
                {
                    try
                    {
                        foreach (string strkey in htsymbols.Keys)
                        {
                            if (!string.IsNullOrEmpty(strkey))
                            {
                                if (htmlString.Contains(strkey))
                                {
                                    htmlString = htmlString.Replace(strkey, htsymbols[strkey].ToString());
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                }
                //tb1rtftextbox.GetHTML(true,true)

                tb1rtxteditor.Document.body.innerHTML = htmlString;
                if (validations.Validatations.CheckFormIsOpenedORnot("frmpreviewtext", frmpre))
                {
                    frmpre.Close();
                }

                frmpre = new frmpreviewtext();

                htmlString = "";

                string strremovestr1 = "Trial version can convert no more than 30000 symbols.";
                string strremovestr2 = "Get the full \r\nfeatured version!</A>";
                string strremovestr3 = "";

                //htmlString = r.ConvertString(rtfString);
                tb1rtxteditor.SelectAll();

                IHTMLSelectionObject objselection = tb1rtxteditor.Document.selection;
                IHTMLTxtRange objrange = (IHTMLTxtRange)objselection.createRange();

                string strtempfilepath = AppDomain.CurrentDomain.BaseDirectory + "temp.txt";
                //htmlString = element.innerHTML;
                htmlString = objrange.htmlText;
                StreamReader sr = new StreamReader(strtempfilepath);
                strremovestr3 = sr.ReadToEnd();

                if (htmlString.Contains(strremovestr1))
                {
                    htmlString = htmlString.Replace(strremovestr1, "");
                }
                if (htmlString.Contains(strremovestr2))
                {
                    htmlString = htmlString.Replace(strremovestr2, "");
                }

                if (!string.IsNullOrEmpty(strremovestr3))
                {
                    if (htmlString.Contains(strremovestr3))
                    {
                        htmlString = htmlString.Replace(strremovestr3, "");
                    }
                }

                string strpreview = validations.richtextvalidations.stripHTMLTags(htmlString);
                strpreview = strpreview.Replace("&lt;", "<");
                strpreview = strpreview.Replace("&gt;", ">");
                strpreview = strpreview.Replace("&amp;", "&");
                strpreview = validations.richtextvalidations.FindAndReplaceStrings(strpreview, Generic.globalVariables.DsFindAndReplace);
                strpreview = strpreview.Replace("&nbsp;", " ").TrimEnd();
                strpreview = strpreview.Replace("<bold></bold>", "");
                strpreview = strpreview.Replace("<ital><bold></bold></ital>", "");
                strpreview = strpreview.Replace("<ital></ital>", "");
                strpreview = strpreview.Replace("<bold> </bold>", "");

                return strpreview;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return null;
        }


        #endregion

        //private void rtxtparapreview_TextChanged(object sender, EventArgs e)
        //{

        //}

        #region GetHtmlFromRichTextbox when leave

        private void rtxtdata1_Leave(object sender, EventArgs e)
        {
            try
            {
                rtxtdata1.Tag = GetHtmlFromRichTextbox(rtxtdata1);
            }
            catch (WarningException ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rtxtparapreview_Leave(object sender, EventArgs e)
        {
            try
            {
                rtxtparapreview.Tag = GetHtmlFromRichTextbox(rtxtparapreview);
            }
            catch (WarningException ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rtxttextlinepreview_Leave(object sender, EventArgs e)
        {
            try
            {
                rtxttextlinepreview.Tag = GetHtmlFromRichTextbox(rtxttextlinepreview);
            }
            catch (WarningException ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtpara1_Leave(object sender, EventArgs e)
        {
            try
            {
                txtpara1.Tag = GetHtmlFromRichTextbox(txtpara1);
            }
            catch (WarningException ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rtxtdatapreview_Leave(object sender, EventArgs e)
        {
            try
            {
                rtxtdatapreview.Tag = GetHtmlFromRichTextbox(rtxtdatapreview);
            }
            catch (WarningException ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        SautinSoft.RtfToHtml rtfToHtml = null;
        private string GetHtmlFromRichTextbox(HtmlRichText.HtmlRichTextBox _rtf)
        {
            try
            {
                rtfToHtml = new SautinSoft.RtfToHtml();

                rtfToHtml.OutputFormat = SautinSoft.eOutputFormat.HTML_401;
                rtfToHtml.Encoding = SautinSoft.eEncoding.UTF_8;

                // string rtfFile = _rtf.Rtf.ToString();
                string rtfString = _rtf.Rtf.ToString();

                //rtfString = rtfString.Replace("?", " "); //Code commented by Sairam on 14th Nov 2013
                rtfString = rtfString.Replace("<", "&lt;");
                rtfString = rtfString.Replace(">", "&gt;");

                string htmlString = "";

                htmlString = rtfToHtml.ConvertString(rtfString);

                Hashtable htsymbols = HtSymbols;

                if (htsymbols != null)
                {
                    foreach (string strkey in htsymbols.Keys)
                    {
                        if (htmlString.Contains(strkey))
                        {
                            htmlString = htmlString.Replace(strkey, htsymbols[strkey].ToString());
                        }
                    }
                }
                //tb1rtftextbox.GetHTML(true,true)
                if (tb1rtxteditor.Document.body == null)
                {
                    return "";
                }

                tb1rtxteditor.Document.body.innerHTML = htmlString;

                htmlString = "";

                string strremovestr1 = "Trial version can convert no more than 30000 symbols.";
                string strremovestr2 = "Get the full \r\nfeatured version!</A>";
                string strremovestr3 = "";

                //htmlString = r.ConvertString(rtfString);
                tb1rtxteditor.SelectAll();

                IHTMLSelectionObject objselection = tb1rtxteditor.Document.selection;
                IHTMLTxtRange objrange = (IHTMLTxtRange)objselection.createRange();

                string strtempfilepath = AppDomain.CurrentDomain.BaseDirectory + "temp.txt";
                //htmlString = element.innerHTML;
                htmlString = objrange.htmlText;
                StreamReader sr = new StreamReader(strtempfilepath);
                strremovestr3 = sr.ReadToEnd();
                if (htmlString.Contains(strremovestr1))
                {
                    htmlString = htmlString.Replace(strremovestr1, "");
                }
                if (htmlString.Contains(strremovestr2))
                {
                    htmlString = htmlString.Replace(strremovestr2, "");
                }

                if (!string.IsNullOrEmpty(strremovestr3))
                {
                    if (htmlString.Contains(strremovestr3))
                    {
                        htmlString = htmlString.Replace(strremovestr3, "");
                    }
                }

                string strpreview = validations.richtextvalidations.stripHTMLTags(htmlString);
                strpreview = strpreview.Replace("&lt;", "<");
                strpreview = strpreview.Replace("&gt;", ">");
                strpreview = strpreview.Replace("&amp;", "&");

                strpreview = validations.richtextvalidations.FindAndReplaceStrings(strpreview, Generic.globalVariables.DsFindAndReplace);
                strpreview = strpreview.Replace("&nbsp;", " ").TrimEnd();
                strpreview = strpreview.Replace("<bold></bold>", "");
                strpreview = strpreview.Replace("<ital><bold></bold></ital>", "");
                strpreview = strpreview.Replace("<ital></ital>", "");
                strpreview = strpreview.Replace("<bold> </bold>", "");
                return strpreview;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
                return "";
            }
            return "";
        }

        #endregion

        private void rtxttextlinepreview_TextChanged_1(object sender, EventArgs e)
        {
            try
            {
                if (sender != null)
                {
                    if (chkisgeneralprocempty.Checked)
                    {
                        if (rtxtparapreview.Text != null && rtxtparapreview.Text != "")
                        {
                            MessageBox.Show("No experimental details checked, para1 field should be empty", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            chkisgeneralprocempty.Checked = false;
                        }
                    }

                    HtmlRichText.HtmlRichTextBox hts = (HtmlRichText.HtmlRichTextBox)sender;
                    HighlightUnknowSymbols(hts); //commented by Sairam


                    if (hts.Name == "rtxttextlinepreview")
                    {
                        TanDetails.TextLine = GetPreviewStringfromRichtextbox(hts);
                    }
                    else if (hts.Name == "rtxtparapreview")
                    {
                        TanDetails.Para = GetPreviewStringfromRichtextbox(hts);
                    }
                    else if (hts.Name == "txtpara1")
                    {
                        TanDetails.Para1 = GetPreviewStringfromRichtextbox(hts);
                    }
                    else if (hts.Name == "rtxtdatapreview")
                    {
                        TanDetails.Data = GetPreviewStringfromRichtextbox(hts);
                    }
                    else if (hts.Name == "rtxtdata1")
                    {
                        TanDetails.Data1 = GetPreviewStringfromRichtextbox(hts);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        //private void txtrxnseq_Leave(object sender, EventArgs e)
        //{
        //    txtrxnseq.Tag = this.Name;
        //    if (txtrxnseq.Text == null || txtrxnseq.Text == "0000")
        //    {
        //        MessageBox.Show("Please enter reaction sequence", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //        txtrxnseq.Focus();
        //    }
        //    else
        //    {
        //        if (Generic.globalVariables.HtNumAndSeq != null)
        //        {
        //            if (Generic.globalVariables.HtNumAndSeq.Count > 0)
        //            {
        //                bool isfound = false;
        //                for (int i = 0; i < Generic.globalVariables.HtNumAndSeq.Count; i++)
        //                {
        //                    if (Generic.globalVariables.HtNumAndSeq[i].SEQ.ToString("0000") == Convert.ToInt32(txtrxnseq.Text).ToString("0000"))
        //                    {
        //                        isfound = true;
        //                    }
        //                }
        //                if (!isfound)
        //                {
        //                    MessageBox.Show("Please enter correct reaction sequence for this TAN", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //                    //txtrxnseq.Focus();
        //                }
        //            }
        //        }
        //    }
        //}


        //private void uccasnartool_KeyDown(object sender, KeyEventArgs e)
        //{

        //}

        //private void button1_Click(object sender, EventArgs e)
        //{

        //}

        //private void txtnarrativeid_KeyDown(object sender, KeyEventArgs e)
        //{
        //    if (e.Control && e.KeyCode == Keys.F)
        //    {
        //        button1_Click(null, null);
        //    }
        //}

        //SautinSoft.RtfToHtml objRtfToHtml;
        ///// <summary>
        ///// Code by Sairam on 31st Oct 2013
        ///// </summary>
        ///// <param name="_rtf"></param>
        //private void FormatRichTextBoxText(HtmlRichText.HtmlRichTextBox _rtf)
        //{
        //    try
        //    {
        //        objRtfToHtml = new SautinSoft.RtfToHtml();
        //        objRtfToHtml.OutputFormat = SautinSoft.eOutputFormat.HTML_401;// SautinSoft.eOutputFormat.HTML_401;
        //        objRtfToHtml.Encoding = SautinSoft.eEncoding.UTF_8;

        //        string rtfString = _rtf.Rtf.ToString();
        //        // rtfString = rtfString.Replace("?", " "); Code commented by Sairam on 31st Oct 2013
        //        rtfString = rtfString.Replace("<", "&lt;");
        //        rtfString = rtfString.Replace(">", "&gt;");

        //        string htmlString = objRtfToHtml.ConvertString(rtfString);

        //        Hashtable htsymbols = HtSymbols;

        //        if (htsymbols != null)
        //        {
        //            try
        //            {
        //                foreach (string strkey in htsymbols.Keys)
        //                {
        //                    if (strkey != "")
        //                    {
        //                        if (htmlString.Contains(strkey))
        //                        {
        //                            htmlString = htmlString.Replace(strkey, htsymbols[strkey].ToString());
        //                        }
        //                    }
        //                }
        //            }
        //            catch (Exception ex)
        //            {

        //            }
        //        }

        //        tb1rtxteditor.Document.body.innerHTML = htmlString;

        //        // htmlString = "";

        //        string strremovestr1 = "Trial version can convert no more than 30000 symbols.";
        //        string strremovestr2 = "Get the full \r\nfeatured version!</A>";
        //        string strremovestr3 = "";

        //        tb1rtxteditor.SelectAll();

        //        IHTMLSelectionObject objselection = tb1rtxteditor.Document.selection;
        //        IHTMLTxtRange objrange = (IHTMLTxtRange)objselection.createRange();

        //        string strtempfilepath = AppDomain.CurrentDomain.BaseDirectory + "temp.txt";
        //        //htmlString = element.innerHTML;
        //        htmlString = objrange.htmlText;
        //        StreamReader sr = new StreamReader(strtempfilepath);
        //        strremovestr3 = sr.ReadToEnd();

        //        if (htmlString.Contains(strremovestr1))
        //        {
        //            htmlString = htmlString.Replace(strremovestr1, "");
        //        }
        //        if (htmlString.Contains(strremovestr2))
        //        {
        //            htmlString = htmlString.Replace(strremovestr2, "");
        //        }

        //        if (!string.IsNullOrEmpty(strremovestr3))
        //        {
        //            if (htmlString.Contains(strremovestr3))
        //            {
        //                htmlString = htmlString.Replace(strremovestr3, "");
        //            }
        //        }

        //        string strpreview = validations.richtextvalidations.stripHTMLTags(htmlString);
        //        strpreview = strpreview.Replace("&lt;", "<");
        //        strpreview = strpreview.Replace("&gt;", ">");
        //        strpreview = strpreview.Replace("&amp;", "&");
        //        strpreview = validations.richtextvalidations.FindAndReplaceStrings(strpreview, Generic.globalVariables.DsFindAndReplace);
        //        strpreview = strpreview.Replace("&nbsp;", " ").TrimEnd();
        //        strpreview = strpreview.Replace("<bold></bold>", "");
        //        strpreview = strpreview.Replace("<ital><bold></bold></ital>", "");
        //        strpreview = strpreview.Replace("<ital></ital>", "");
        //        strpreview = strpreview.Replace("<bold> </bold>", "");

        //        string strtext = strpreview;
        //        strtext = strtext.Replace("<bold>", "<b>");
        //        strtext = strtext.Replace("</bold>", "</b>");
        //        strtext = strtext.Replace("<ital>", "<I>");
        //        strtext = strtext.Replace("</ital>", "</I>");
        //        strtext = strtext.Replace("<sup>", "<SUP>");
        //        strtext = strtext.Replace("</sup>", "</SUP>");
        //        strtext = strtext.Replace("<sub>", "<SUB>");
        //        strtext = strtext.Replace("</sub>", "</SUB>");
        //        try
        //        {
        //            SautinSoft.HtmlToRtf objHtmlToRtf = new SautinSoft.HtmlToRtf();

        //            //specify some options
        //            objHtmlToRtf.OutputFormat = SautinSoft.HtmlToRtf.eOutputFormat.Rtf;
        //            objHtmlToRtf.Encoding = SautinSoft.HtmlToRtf.eEncoding.AutoSelect;
        //            objHtmlToRtf.FontFace = SautinSoft.HtmlToRtf.eFontFace.f_Calibri;
        //            objHtmlToRtf.PageStyle.PageSize.Letter();

        //            string _htmlstring = strtext;
        //            string rtf = objHtmlToRtf.ConvertString(_htmlstring);

        //            _rtf.Rtf = rtf;

        //            string strremovetext = _rtf.Rtf;
        //            _rtf.Rtf = strremovetext;

        //            RemoveTrialVersionstring("", _rtf);

        //        }
        //        catch (Exception ex)
        //        {
        //            ErrorHandling.WriteErrorLog(ex.ToString());
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}

        //public void FillFilename()
        //{
        //    try
        //    {
        //        if (Generic.globalVariables.DsTanFilenames != null)
        //        {
        //            if (txtdocref.Text != null)
        //            {
        //                if (Generic.globalVariables.DsTanFilenames.Tables.Count > 0)
        //                {
        //                    if (Generic.globalVariables.DsTanFilenames.Tables[0].Rows.Count > 0)
        //                    {
        //                        DataRow[] dr = Generic.globalVariables.DsTanFilenames.Tables[0].Select("TAN='" + TAN + "'");

        //                        if (dr != null)
        //                        {
        //                            if (dr.Length > 0)
        //                            {
        //                                if (txtdocref.Text != "")
        //                                {
        //                                    if (dr[0][txtdocref.Text.ToLower()] != null)
        //                                    {
        //                                        txtfilename.Text = dr[0]["doc1"].ToString();
        //                                    }
        //                                    else
        //                                        txtfilename.Text = "";

        //                                }
        //                            }
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}

        #region DocRef And Auto fill FileNames
        /// <summary>
        /// Fill docrefs in text box when appropriate doc selected.
        /// </summary>
        public void FillDocrefs()
        {
            for (int i = 1; i <= Generic.globalVariables.NoOfDocsAvailable; i++)
            {
                _autocompledocrefs.Add("doc" + i.ToString());
            }

            //_autocompledocrefs.Add("doc1");
            //_autocompledocrefs.Add("doc2");
            //_autocompledocrefs.Add("doc3");
            //_autocompledocrefs.Add("doc4");
            txtdocref.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txtdocref.AutoCompleteSource = AutoCompleteSource.CustomSource;
            txtdocref.AutoCompleteCustomSource = _autocompledocrefs;
        }

        /// <summary>
        /// Fill doc file name and its XpageSize and YpageSize if exists.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtdocref_Leave(object sender, EventArgs e)
        {
            txtdocref.Tag = this.Name;
            Hashtable htdocrefs = new Hashtable();
            //for (int i = 1; i < 20; i++)
            //{
            //    htdocrefs.Add(i, "doc" + i.ToString());
            //}

            for (int i = 1; i <= Generic.globalVariables.NoOfDocsAvailable; i++)
            {
                htdocrefs.Add(i, "doc" + i.ToString());
            }

            if (!htdocrefs.ContainsValue(txtdocref.Text))
            {
                MessageBox.Show("Please select correct docref from list", "CAS Narrative tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            #region ChangeFileName

            try
            {
                if (Generic.globalVariables.DsTanFilenames != null)
                {
                    if (txtdocref.Text != null)
                    {
                        if (Generic.globalVariables.DsTanFilenames.Tables.Count > 0)
                        {
                            if (Generic.globalVariables.DsTanFilenames.Tables[0].Rows.Count > 0)
                            {
                                DataRow[] dr = Generic.globalVariables.DsTanFilenames.Tables[0].Select("TAN='" + TAN + "'");

                                if (dr != null)
                                {
                                    if (dr.Length > 0)
                                    {
                                        if (dr[0][txtdocref.Text.ToLower()] != null)
                                        {
                                            txtfilename.Text = dr[0][txtdocref.Text].ToString();
                                        }
                                        else
                                            txtfilename.Text = "";

                                    }
                                }



                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            #endregion

            #region GetPagesizeOffsets
            try
            {
                TextBox t = (TextBox)sender;
                string xpagesize = "";
                string ypagesize = "";
                if (t.Text != null && t.Text != "")
                {

                    string x = "";
                    string y = "";
                    string Xoffset = "";
                    string Yoffset = "";
                    if (frmNarrTANView.GetPageXY(out x, out y, out Xoffset, out Yoffset, t.Text))
                    {
                        txtxpagesize.Text = x;
                        txtypagesize.Text = y;
                        //txtxoffset.Text = Xoffset;
                        //txtyoffset.Text = Yoffset;
                    }
                    else
                    {
                        //txtxpagesize.Text = null;
                        //txtypagesize.Text = null;
                        //txtxoffset.Text = null;
                        //txtyoffset.Text = null;

                        txtxpagesize.Text = "";
                        txtypagesize.Text = "";
                        txtxoffset.Text = "";
                        txtyoffset.Text = "";


                    }
                }

            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            #endregion

            #region UpdateChangedValueto TanDetails.
            try
            {
                if (sender != null)
                {
                    TextBox t = (TextBox)sender;
                    if (t.Text != null && t.Text != "")
                    {
                        // Reflect changes to TanDetails if has any changes.
                        TanDetails.DocRef = t.Text.ToLower();
                        double xpageSize;
                        double ypageSize;
                        double xOffset;
                        double yOffset;
                        double.TryParse(txtxpagesize.Text, out xpageSize);
                        double.TryParse(txtypagesize.Text, out ypageSize);
                        double.TryParse(txtxoffset.Text, out xOffset);
                        double.TryParse(txtyoffset.Text, out yOffset);

                        TanDetails.XPageSize = xpageSize;
                        TanDetails.XOffset = xOffset;
                        TanDetails.YPageSize = ypageSize;
                        TanDetails.YOffset = yOffset;

                        txtxpagesize.Text = xpageSize.ToString();
                        txtxoffset.Text = xOffset.ToString();
                        txtypagesize.Text = ypageSize.ToString();
                        txtyoffset.Text = yOffset.ToString();




                        // throw exception.
                        //TanDetails.XPageSize = Convert.ToDouble(txtxpagesize.Text);
                        //TanDetails.XOffset = Convert.ToDouble(txtypagesize.Text);
                        //TanDetails.YPageSize = Convert.ToDouble(txtyoffset.Text);
                        //TanDetails.YOffset = Convert.ToDouble(txtyoffset.Text);
                    }
                    // rtxttextlinepreview.TextChanged -= new EventHandler(rtxttextlinepreview_TextChanged_1);


                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            #endregion

            #region retain existed page sizes

            TextBox temp = (TextBox)sender;
            if (temp.Text != null && temp.Text != "")
            {
                string x = "";
                string y = "";
                if (frmNarrTANView.GetPageXY(out x, out y, temp.Text))
                {
                    // foreach (Control c in tableLayoutPanel1.Controls)
                    //foreach (Control c in pnlUserControl.Controls)
                    //{
                    //    if (c.GetType().BaseType.Name.ToString().ToUpper() == "USERCONTROL")
                    //    {
                    //        uccasnartool_new uc = (uccasnartool_new)c;
                    if (this.Name.ToUpper() == temp.Tag.ToString().ToUpper())
                    {
                        this.txtxpagesize.Text = x;
                        this.txtypagesize.Text = y;
                    }
                    //        }
                    //    }
                }
            }
            #endregion
        }

        #endregion

        #region Page label Validation on leave.

        /// <summary>
        /// Perform page label validations.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtpagelabel_Leave(object sender, EventArgs e)
        {
            try
            {
                string strerrormsg = "";

                if (txtdocref.Text == null && txtdocref.Text == "")
                    return;

                if (txtpagenumber.Text == null && txtpagenumber.Text == "")
                    return;

                if (Generic.globalVariables.IsPatent)
                {
                    if (IsValidAlphaNumeric(txtpagelabel.Text))
                    {
                        MessageBox.Show("Page label can't be alphanumeric for patents", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtpagelabel.Focus();
                    }
                    else if (!IsValidText(txtpagelabel.Text))
                    {
                        MessageBox.Show("Page label can't be special characters for patents", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtpagelabel.Focus();
                    }
                }

                if (!Generic.globalVariables.IsPatent)
                {
                    if (txtdocref.Text.ToLower().Trim() == "doc1")
                    {
                        if (txtpagelabel.Text.Trim() == "" || txtpagelabel.Text == null)
                        {
                            if (MessageBox.Show("Page label can't be empty", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Warning) == DialogResult.OK)
                                txtpagelabel.Focus();
                        }
                    }
                    else if (txtdocref.Text.ToLower().Trim() == "doc2")
                    {
                        if (txtpagelabel.Text == "")
                        {
                            if (MessageBox.Show("Page label is be empty, Do you want to continue?", "CAS Narative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                            {
                                txtpagelabel.Focus();
                                return;
                            }
                        }
                    }
                }
                else if (txtpagelabel.Text.Trim() == "" || txtpagelabel.Text == null)
                {
                    if (Generic.globalVariables.IsPatent)
                    {
                        if (MessageBox.Show("Page label is be empty", "CAS Narrative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                        {
                            txtpagelabel.Focus();
                            return;
                        }
                    }
                    else
                    {
                        if (MessageBox.Show("Page label is be empty, Do you want to continue?", "CAS Narative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                        {
                            txtpagelabel.Focus();
                            return;
                        }

                    }
                }
                if (!Generic.globalVariables.IsPatent)
                {

                    if (txtpagelabel.Text != null && txtpagelabel.Text != "")
                    {
                        if (txtpagelabel.Text.Length == 1)
                        {
                            if (char.IsLetter(Convert.ToChar(txtpagelabel.Text)))
                            {
                                if (!validations.Validatations.IsPageLabelCorrectFormat(txtpagenumber.Text, txtpagelabel.Text.ToLower(), txtdocref.Text, out strerrormsg))
                                {
                                    MessageBox.Show(strerrormsg, "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    txtpagelabel.Focus();

                                }
                            }
                        }
                    }

                    if (txtpagelabel.Text != null && txtpagelabel.Text != "")
                    {
                        if (txtdocref.Text.ToLower() == "doc2")
                        {
                            if (!txtpagelabel.Text.ToLower().Contains("s"))
                            {
                                if (MessageBox.Show("DocRef is Doc2, Page number does not contains 's', Is It OK?", "CAS Narrative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                                {
                                    txtpagelabel.Focus();
                                }

                            }
                        }
                        else if (txtdocref.Text.ToLower() == "doc1")
                        {
                            if (IsValidAlphaNumeric(txtpagelabel.Text))
                            {
                                MessageBox.Show("Page label can't be alphanumeric for doc1", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                //txtpagelabel.Focus();

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        /// <summary>
        /// Check Is valid alphanumeric or not.
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns>return true if Valid Alphanumeric,else false.</returns>
        public static bool IsValidAlphaNumeric(string inputStr)
        {
            //make sure the user provided us with data to check
            //if not then return false
            if (string.IsNullOrEmpty(inputStr))
                return false;


            bool isnumber = false;
            bool ischar = false;
            for (int i = 0; i < inputStr.Length; i++)
            {
                if (char.IsNumber(inputStr[i]))
                {
                    isnumber = true;

                }
                else
                {

                    ischar = true;
                }
            }
            if (isnumber && ischar)
                return true;
            else if (isnumber && (!ischar))
                return false;
            else if ((!isnumber) && (ischar))
                return false;

            //now we need to loop through the string, examining each character
            //for (int i = 0; i < inputStr.Length; i++)
            //{
            //    //if this character isn't a letter and it isn't a number then return false
            //    //because it means this isn't a valid alpha numeric string
            //    if (!(char.IsLetter(inputStr[i])) && (!(char.IsNumber(inputStr[i]))))
            //        return false;
            //}
            ////we made it this far so return true
            return true;
        }

        /// <summary>
        ///  Checks for valid text against special characters.
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns>If it is contains special char returns false, else true.</returns>
        public static bool IsValidText(string inputStr)
        {
            //make sure the user provided us with data to check
            //if not then return false
            if (string.IsNullOrEmpty(inputStr))
                return false;

            string[] strspecialChars = new string[] { "`", "!", "@", "#", "%", "^", "&", "*", "(", ")", "-", "=", "+", "_", "<", ">", ".", "~", ",", "//", "\\", "?" };

            for (int i = 0; i < strspecialChars.Length; i++)
            {
                if (inputStr.Contains(strspecialChars[i]))
                {
                    return false;
                }
            }

            bool isnumber = false;
            bool ischar = false;
            for (int i = 0; i < inputStr.Length; i++)
            {
                if (!char.IsNumber(inputStr[i]))
                {
                    isnumber = true;
                }
            }
            if (isnumber)
                return false;
            else
                return true;


            return true;
        }

        #endregion

        //private void txtCASReactnumber_Leave(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        txtCASReactnumber.Tag = this.Name;
        //        if (txtCASReactnumber.Text == null || txtCASReactnumber.Text == "0000")
        //        {
        //            MessageBox.Show("Please enter reaction number", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //            txtCASReactnumber.Focus();
        //        }
        //        else
        //        {

        //            if (Generic.globalVariables.HtNumAndSeq != null)
        //            {
        //                if (Generic.globalVariables.HtNumAndSeq.Count > 0)
        //                {
        //                    bool isfound = false;
        //                    for (int i = 0; i < Generic.globalVariables.HtNumAndSeq.Count; i++)
        //                    {
        //                        if (Generic.globalVariables.HtNumAndSeq[i].NUM.ToString("0000") == Convert.ToInt32(txtCASReactnumber.Text).ToString("0000"))
        //                        {

        //                            isfound = true;
        //                        }
        //                    }
        //                    if (!isfound)
        //                    {
        //                        MessageBox.Show("Please enter correct reaction number for this TAN", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //                        txtCASReactnumber.Focus();
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorHandling.WriteErrorLog(ex.ToString());
        //    }
        //}

        private void txtCASReactnumber_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (sender != null)
                {
                    TextBox t = (TextBox)sender;
                    if (t.Text != null && t.Text != "")
                    {

                        if (t.Name == "txtCASReactnumber")
                        {
                            if (t.Text != null && t.Text != "")
                                TanDetails.ReactionCasReactantNumber = Convert.ToInt32(t.Text.Trim());

                        }
                        else if (t.Name == "txtrxnseq")
                        {
                            if (t.Text != null && t.Text != "")
                                TanDetails.Rxnseq = Convert.ToInt32(t.Text.Trim());
                        }
                        else if (t.Name == "txtdocref")
                        {
                            //TanDetails.DocRef = t.Text.ToLower();
                        }
                        else if (t.Name == "txtfilename")
                        {
                            TanDetails.filename = t.Text;
                        }
                        else if (t.Name == "txtpagenumber")
                        {
                            if (t.Text != null && t.Text != "")
                                TanDetails.PageNumber = Convert.ToInt32(t.Text.Trim());
                        }
                        else if (t.Name == "txtpagelabel")
                        {
                            if (t.Text != null)
                                TanDetails.PageLabel = t.Text;
                        }
                        else if (t.Name == "txtxpagesize")
                        {
                            if (t.Text != null && t.Text != "")
                            {
                                TanDetails.XPageSize = Convert.ToDouble(t.Text.Trim());
                            }
                        }
                        else if (t.Name == "txtxoffset")
                        {
                            if (t.Text != null && t.Text != "")
                                TanDetails.XOffset = Convert.ToDouble(t.Text.Trim());
                        }
                        else if (t.Name == "txtypagesize")
                        {
                            if (t.Text != null && t.Text != "")
                                TanDetails.YPageSize = Convert.ToDouble(t.Text.Trim());
                        }
                        else if (t.Name == "txtyoffset")
                        {
                            if (t.Text != null && t.Text != "")
                                TanDetails.YOffset = Convert.ToDouble(t.Text.Trim());
                        }
                        else if (t.Name == "txtnarrativeid")
                        {
                            //TanDetails.NarrativeID = t.Text;
                            TanDetails.NarrativeID = GetNarId();
                        }
                        TanDetails.XResUnit = "inch";
                        TanDetails.YResUnit = "inch";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #region Page Number Validation On leave.

        /// <summary>
        /// Perform page label and page number validations
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtpagenumber_Leave(object sender, EventArgs e)
        {
            if (Generic.globalVariables.IsPatent)
            {
                if (txtpagenumber.Text == null && txtpagenumber.Text == "")
                {
                    MessageBox.Show("Page label can't be empty", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtpagenumber.Focus();
                }
            }
            else
            {
                if (txtpagenumber.Text == null && txtpagenumber.Text == "")
                {
                    if (MessageBox.Show("Page label is empty, Do you want to continue?", "CAS Narrative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                    {
                        txtpagenumber.Focus();
                    }

                }

            }

        }

        #endregion

        //private void rtxtdata1_Click(object sender, EventArgs e)
        //{

        //}

        #region EnableToolStrip when mouse down

        private void rtxtdatapreview_MouseDown(object sender, MouseEventArgs e)
        {
            EnableToolStrip(e);

        }

        private void txtpara1_MouseDown(object sender, MouseEventArgs e)
        {
            EnableToolStrip(e);
        }

        private void rtxtparapreview_MouseDown(object sender, MouseEventArgs e)
        {
            EnableToolStrip(e);
        }

        private void rtxttextlinepreview_MouseDown(object sender, MouseEventArgs e)
        {
            EnableToolStrip(e);
        }

        /// <summary>
        /// Enable Tool Strip menu when mouse right button clicked.
        /// </summary>
        /// <param name="e"></param>
        private void EnableToolStrip(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (rtxtdatapreview.Focused)
                    addDataToolStripMenuItem.Enabled = true;
                else
                    addDataToolStripMenuItem.Enabled = false;

                if (rtxtparapreview.Focused)
                    addParaToolStripMenuItem.Enabled = true;
                else
                    addParaToolStripMenuItem.Enabled = false;
            }
        }

        #endregion

        #region Spell Checking

        frmspellcheck objspell = null;
        /// <summary>
        /// Opens Spell check window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void spellCheckToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (rtxtdatapreview.Focused)
                {
                    if (rtxtdatapreview.Text != null)
                    {
                        if (validations.Validatations.CheckFormIsOpenedORnot("frmspellcheck", objspell))
                        {
                            objspell.Close();

                        }
                        rtxtdatapreview.BackColor = Color.LightGray;
                        objspell = new frmspellcheck();
                        objspell.FormClosing += new FormClosingEventHandler(objspell_FormClosing);
                        objspell.RtfData = rtxtdatapreview.Rtf;
                        objspell.TextBoxName = "data";
                        objspell.Show();

                    }
                }
                else if (rtxtparapreview.Focused)
                {
                    if (rtxtparapreview.Text != null)
                    {
                        if (validations.Validatations.CheckFormIsOpenedORnot("frmspellcheck", objspell))
                        {
                            objspell.Close();

                        }
                        rtxtparapreview.BackColor = Color.LightGray;
                        objspell = new frmspellcheck();
                        objspell.FormClosing += new FormClosingEventHandler(objspell_FormClosing);
                        objspell.RtfData = rtxtparapreview.Rtf;
                        objspell.TextBoxName = "para1";
                        objspell.Show();

                    }
                }
                else if (rtxttextlinepreview.Focused)
                {
                    if (rtxttextlinepreview.Text != null)
                    {
                        if (validations.Validatations.CheckFormIsOpenedORnot("frmspellcheck", objspell))
                        {
                            objspell.Close();

                        }
                        rtxttextlinepreview.BackColor = Color.LightGray;
                        objspell = new frmspellcheck();
                        objspell.FormClosing += new FormClosingEventHandler(objspell_FormClosing);
                        objspell.RtfData = rtxttextlinepreview.Rtf;
                        objspell.TextBoxName = "textline";
                        objspell.Show();
                    }
                }
                else if (txtpara1.Focused)
                {
                    if (txtpara1.Text != null)
                    {
                        if (validations.Validatations.CheckFormIsOpenedORnot("frmspellcheck", objspell))
                        {
                            objspell.Close();

                        }
                        txtpara1.BackColor = Color.LightGray;
                        objspell = new frmspellcheck();
                        objspell.FormClosing += new FormClosingEventHandler(objspell_FormClosing);
                        objspell.RtfData = txtpara1.Rtf;
                        objspell.TextBoxName = "para2";
                        objspell.Show();

                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }

        }

        /// <summary>
        /// When closing the spell check window catch rtf from it and assign to control.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void objspell_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (objspell.TextBoxName == "data")
                {
                    if (objspell.Status)
                    {
                        rtxtdatapreview.Rtf = objspell.RtfData;
                    }


                }
                else if (objspell.TextBoxName == "para1")
                {
                    if (objspell.Status)
                    {
                        rtxtparapreview.Rtf = objspell.RtfData;
                    }


                }
                else if (objspell.TextBoxName == "textline")
                {
                    if (objspell.Status)
                    {
                        rtxttextlinepreview.Rtf = objspell.RtfData;
                    }

                }
                else if (objspell.TextBoxName == "para2")
                {
                    if (objspell.Status)
                    {
                        txtpara1.Rtf = objspell.RtfData;
                    }

                }
                txtpara1.BackColor = Color.White;
                rtxttextlinepreview.BackColor = Color.White;
                rtxtparapreview.BackColor = Color.White;
                rtxtdatapreview.BackColor = Color.White;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }

        }

        #endregion

        #region IsGeneralTypical, No expermental.

        //private void chkisGeneralTypical_CheckStateChanged(object sender, EventArgs e)
        //{
        //    //  IsGeneralTypicalValidations();
        //}

        /// <summary>
        /// Is General Typical validations like combined procedure, Is para1 empty.
        /// </summary>
        /// <returns></returns>
        public bool IsGeneralTypicalValidations()
        {
            bool Status = true;
            try
            {
                if (chkisGeneralTypical.Checked)
                {
                    chkisgeneralprocempty.Checked = false;
                    //  if (!txtnarrativeid.Text.Contains("analogousTo=nar"))
                    if (!chkIsAnalogous.Checked)
                    {
                        if (MessageBox.Show("Is it a Combined Procedure ?", "CAS Narrative Tool", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            TanDetails.isGeneralTypical = chkisGeneralTypical.Checked;
                            if (rtxtparapreview.Text == null)
                            {
                                MessageBox.Show("Para1 can't be blank for IsGeneralTypical", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                chkisGeneralTypical.Checked = false;
                                Status = false;
                                return Status;
                            }
                            if (rtxtparapreview.Text.ToString().Trim() == "")
                            {
                                MessageBox.Show("Para1 can't be blank for IsGeneralTypical", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                chkisGeneralTypical.Checked = false;
                                Status = false;
                                return Status;
                            }
                        }
                        else
                            chkisGeneralTypical.Checked = false;
                    }
                    else
                    {
                        MessageBox.Show("Can't check IsGeneralTypical, because narrative id anaolous to another narid");
                        chkisGeneralTypical.Checked = false;
                        Status = false;
                        return Status;
                    }
                }
                else
                {
                    if (TanDetails.isGeneralTypical == null)
                        TanDetails.isGeneralTypical = false;

                    TanDetails.isGeneralTypical = false;
                    chkisGeneralTypical.Checked = false;
                }
                return Status;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return Status;
        }

        private void chkisgeneralprocempty_Click(object sender, EventArgs e)
        {
            NoExpermentDetailsValidation();
            IsFinalProductExistsInPara2();
        }

        #region Added by kranthi April 7th 2014	In Case of No experimental, "Final Product" not reflected in Para 2 Column.

        /// <summary>
        /// In Case of No experimental, "Final Product" not reflected in Para 2 Column.
        /// </summary>
        /// <returns></returns>
        public bool IsFinalProductExistsInPara2()
        {
            bool Status = true;
            try
            {

                if (chkisgeneralprocempty.Checked)
                {
                    Regex r = new Regex("Final+\\s+product", RegexOptions.IgnoreCase);
                    if (r.IsMatch(this.txtpara1.Text))
                    {
                        MessageBox.Show("No experimental details checked,\"Final Product\" should not reflect in Para 2", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        chkisgeneralprocempty.Checked = false;
                        Status = false;
                    }
                }
                return Status;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return Status;
        }

        #endregion

        /// <summary>
        /// No expermental Validations like No experimental details checked, para1 field should be empty
        /// </summary>
        /// <returns></returns>
        public bool NoExpermentDetailsValidation()
        {
            bool Status = true;
            try
            {
                if (chkisgeneralprocempty.Checked)
                {
                    ////if noexpdetails checked para1 should be empty both cases
                    if (rtxtparapreview.Text != null && rtxtparapreview.Text != "")
                    {
                        MessageBox.Show("No experimental details checked, para1 field should be empty", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        chkisgeneralprocempty.Checked = false;
                        return false;
                    }


                    //if (txtnarrativeid.Text.Contains("analogousTo=nar"))
                    if (chkIsAnalogous.Checked)
                    {
                        chkisgeneralprocempty.Checked = false;
                    }

                    chkisGeneralTypical.Checked = false;

                }
                return Status;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return Status;
        }

        #endregion

        #region Subscript,SuperScript,Bold,Italic

        private void tsnsubscript_Click(object sender, EventArgs e)
        {
            try
            {
                if (sender != null)
                {
                    HtmlRichText.HtmlRichTextBox textbox = null;
                    if (rtxtdatapreview.Focused)
                    {
                        textbox = (HtmlRichText.HtmlRichTextBox)rtxtdatapreview;
                    }
                    else if (rtxtparapreview.Focused)
                    {
                        textbox = (HtmlRichText.HtmlRichTextBox)rtxtparapreview;
                    }
                    else if (rtxttextlinepreview.Focused)
                    {
                        textbox = (HtmlRichText.HtmlRichTextBox)rtxttextlinepreview;
                    }
                    else if (txtpara1.Focused)
                    {
                        textbox = (HtmlRichText.HtmlRichTextBox)txtpara1;
                    }
                    if (textbox != null)
                    {
                        if (!textbox.IsSubScript())
                        {
                            textbox.SetSuperScript(false);
                            textbox.SetSubScript(true);
                        }
                        else
                            textbox.SetSubScript(false);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void superscriptToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (sender != null)
                {
                    HtmlRichText.HtmlRichTextBox textbox = null;
                    if (rtxtdatapreview.Focused)
                    {
                        textbox = (HtmlRichText.HtmlRichTextBox)rtxtdatapreview;
                    }
                    else if (rtxtparapreview.Focused)
                    {
                        textbox = (HtmlRichText.HtmlRichTextBox)rtxtparapreview;
                    }
                    else if (rtxttextlinepreview.Focused)
                    {
                        textbox = (HtmlRichText.HtmlRichTextBox)rtxttextlinepreview;
                    }
                    else if (txtpara1.Focused)
                    {
                        textbox = (HtmlRichText.HtmlRichTextBox)txtpara1;
                    }
                    if (textbox != null)
                    {
                        if (!textbox.IsSuperScript())
                        {
                            textbox.SetSuperScript(true);
                            textbox.SetSubScript(false);
                        }
                        else
                            textbox.SetSuperScript(false);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void italicToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (sender != null)
                {
                    HtmlRichText.HtmlRichTextBox textbox = null;
                    if (rtxtdatapreview.Focused)
                    {
                        textbox = (HtmlRichText.HtmlRichTextBox)rtxtdatapreview;
                    }
                    else if (rtxtparapreview.Focused)
                    {
                        textbox = (HtmlRichText.HtmlRichTextBox)rtxtparapreview;
                    }
                    else if (rtxttextlinepreview.Focused)
                    {
                        textbox = (HtmlRichText.HtmlRichTextBox)rtxttextlinepreview;
                    }
                    else if (txtpara1.Focused)
                    {
                        textbox = (HtmlRichText.HtmlRichTextBox)txtpara1;
                    }
                    if (textbox != null)
                    {
                        if (textbox.SelectedText != null)
                        {
                            if (textbox.SelectionFont == null)
                                textbox.SelectionFont = new Font(textbox.Font, textbox.Font.Style ^ FontStyle.Italic);
                            else
                                textbox.SelectionFont = new Font(textbox.SelectionFont, textbox.SelectionFont.Style ^ FontStyle.Italic);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void boldToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (sender != null)
                {
                    HtmlRichText.HtmlRichTextBox textbox = null;
                    if (rtxtdatapreview.Focused)
                    {
                        textbox = (HtmlRichText.HtmlRichTextBox)rtxtdatapreview;
                    }
                    else if (rtxtparapreview.Focused)
                    {
                        textbox = (HtmlRichText.HtmlRichTextBox)rtxtparapreview;
                    }
                    else if (rtxttextlinepreview.Focused)
                    {
                        textbox = (HtmlRichText.HtmlRichTextBox)rtxttextlinepreview;
                    }
                    else if (txtpara1.Focused)
                    {
                        textbox = (HtmlRichText.HtmlRichTextBox)txtpara1;
                    }
                    if (textbox != null)
                    {
                        if (textbox.SelectedText != null)
                        {
                            if (textbox.SelectionFont == null)
                                textbox.SelectionFont = new Font(textbox.Font, textbox.Font.Style ^ FontStyle.Bold);
                            else
                                textbox.SelectionFont = new Font(textbox.SelectionFont, textbox.SelectionFont.Style ^ FontStyle.Bold);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }

        }


        #endregion

        #region Add data or para

        private void addParaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (rtxtparapreview.Focused)
            {
                if (rtxtparapreview.Text != null)
                {
                    string strtext = rtxtparapreview.Text;
                    int start = rtxtparapreview.SelectionStart + 2;
                    rtxtparapreview.SelectionFont = new Font(rtxtparapreview.Font.Name, rtxtparapreview.Font.Size);
                    rtxtparapreview.Select(start, 7);

                    rtxtparapreview.SelectedText = "\n<PARA>\n";

                }
            }
            else
            {
                MessageBox.Show("Please Select PARA Field", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }

        private void addDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (rtxtdatapreview.Focused)
            {
                if (rtxtdatapreview.Text != null)
                {
                    string strtext = rtxtdatapreview.Text;
                    int start = rtxtdatapreview.SelectionStart + 2;
                    rtxtdatapreview.SelectionFont = new Font(rtxtdatapreview.Font.Name, rtxtdatapreview.Font.Size);
                    rtxtdatapreview.Select(start, 7);
                    rtxtdatapreview.SelectedText = "\n<DATA>\n";

                }
            }
            else
            {
                MessageBox.Show("Please Select Data Field", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

        }


        #endregion

        #region Highlight

        /// <summary>
        /// Heighlight Special character with Red color.
        /// </summary>
        public void HeighlightSplChrPatentJournal()
        {
            try
            {
                HtmlRichTextBox[] ControlsToHeighlight = new HtmlRichTextBox[] { this.rtxttextlinepreview, this.rtxtparapreview, this.txtpara1, this.rtxtdatapreview };
                /// To the Fields of TextLine,Para1,Para2,Data in Usercontrol.
                HeighlightSpecialCharacters(Generic.globalVariables.LstSpecialChar_Pat_journal, Color.Orange, ControlsToHeighlight);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #region HeighlightSpecialChar

        int HeighlightSearchIndex = 0;

        /// <summary>
        /// Heighlight key values of patent/journal with Red color.
        /// </summary>
        /// <param name="lstSpecialChar"> </param>
        /// <param name="heighlightWithColor">heighlight with color </param>
        /// <param name="controlsToHeighlight">TextLine,Para1,Para2,Data in Usercontrol.</param>
        private void HeighlightSpecialCharacters(List<string> lstSpecialChar, Color heighlightWithColor, HtmlRichTextBox[] controlsToHeighlight)
        {
            try
            {
                string Word = null;
                int startindex = 0;

                foreach (HtmlRichTextBox item in controlsToHeighlight)
                {
                    for (int i = 0; i < lstSpecialChar.Count; i++)
                    {
                        Word = lstSpecialChar[i].ToString();
                        HeighlightSearchIndex = 0;
                        int SourceStringStartIndex = 0;
                        startindex = FindMyText(item, Word, SourceStringStartIndex, item.TextLength);
                        while (startindex >= 0)
                        {
                            // Setting Heighlight color.
                            item.SelectionBackColor = heighlightWithColor;

                            // Find the end index. End Index = number of characters in textbox
                            int endindex = Word.Length;

                            // select the search string
                            item.Select(startindex, endindex);

                            SourceStringStartIndex = startindex + endindex;
                            startindex = FindMyText(item, Word, SourceStringStartIndex, item.TextLength);
                        }
                    }
                    item.Select(0, 0);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        /// <summary>
        /// To find another existence of same word control. 
        /// </summary>
        /// <param name="item">control name. </param>
        /// <param name="txtToSearch">word to search. </param>
        /// <param name="searchStart">start index of text to search with in.</param>
        /// <param name="searchEnd">End index of text to search with in. </param>
        /// <returns></returns>
        public int FindMyText(HtmlRichTextBox item, string txtToSearch, int searchStart, int searchEnd)
        { // Set the return value to -1 by default.
            int retVal = -1;
            try
            {


                // A valid starting index should be specified.
                // if indexOfSearchText = -1, the end of search
                if (searchStart >= 0 && HeighlightSearchIndex >= 0)
                {
                    // A valid ending index
                    if (searchEnd > searchStart || searchEnd == -1)
                    {
                        // Find the position of search string in RichTextBox
                        HeighlightSearchIndex = item.Find(txtToSearch, searchStart, searchEnd, RichTextBoxFinds.MatchCase);
                        // Determine whether the text was found in richTextBox1.
                        if (HeighlightSearchIndex != -1)
                        {
                            // Return the index to the specified search text.
                            retVal = HeighlightSearchIndex;
                        }
                    }
                }
                return retVal;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return retVal;
        }

        #endregion

        /// <summary>
        /// Heighlight Analogous When nar analogous to another nar.
        /// </summary>
        public void HighlightAnalogous()
        {

            try
            {
                HtmlRichTextBox[] ControlsToHeighlight = new HtmlRichTextBox[] { this.rtxtparapreview, this.txtpara1 };
                List<string> lstAnalogous = new List<string>();
                lstAnalogous.Add("ANALOGOUS");
                // Heighlight Special character with Red color.
                // To the Fields of TextLine,Para1,Para2,Data in Usercontrol.
                HeighlightSpecialCharacters(lstAnalogous, Color.Yellow, ControlsToHeighlight);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }


        #endregion

        #region CheckUniChars In New Form

        /// <summary>
        /// returns the unicode list from the four controls
        /// </summary>
        /// <param name="ucSerialNum"></param>
        /// <returns></returns>
        public List<UniCodeChar> CheckUniChars()
        {
            HtmlRichTextBox[] Controls = new HtmlRichTextBox[] { this.rtxttextlinepreview, this.rtxtparapreview, this.txtpara1, this.rtxtdatapreview };
            try
            {
                List<UniCodeChar> lstUniCode = new List<UniCodeChar>();
                foreach (HtmlRichTextBox item in Controls)
                {
                    ValidateUniCodeChar.ValidateUnicodes(item, GetNarId(), ref lstUniCode);
                }
                return lstUniCode;
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        #endregion

        #region Nar analogous check box And Combobox Added By kranthi On 28-March-2014.

        private void chkIsAnalogous_CheckStateChanged(object sender, EventArgs e)
        {
            try
            {
                if (chkIsAnalogous.Checked)
                {
                    if (!chkisGeneralTypical.Checked)
                    {
                        cmbAnalogousTo.Visible = true;
                        if (cmbAnalogousTo != null)
                        {
                            if (cmbAnalogousTo.Items.Count == 0)
                            {
                                FillNarIdToComboBox();
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("IsGeneralTypical does not carry analogousTo", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        chkIsAnalogous.Checked = false;
                    }
                    if (chkIsAnalogous.Checked)
                    {
                        chkisgeneralprocempty.Checked = false;
                    }
                }
                else
                {
                    cmbAnalogousTo.Visible = false;
                    //cmbAnalogousTo.Items.Clear();
                    cmbAnalogousTo.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        /// <summary>
        /// Fill analogous to nar Id combobox if nar analogous to another nar.
        /// </summary>
        public void FillNarIdToComboBox()
        {
            #region old code.
            //  cmbAnalogousTo.Items.Clear();
            //for (int i = 1; i <= Generic.globalVariables.HtNumAndSeq.Count; i++)
            //{
            //    cmbAnalogousTo.Items.Add("nar" + i);
            //}
            //for (int i = 0; i < frmTANView_new.dtDocumet_ids.Rows.Count; i++)
            //{
            //    if (frmTANView_new.dtDocumet_ids.Rows[i]["curation_complete_status"].ToString().ToUpper() != "FALSE")
            //    {
            //        if (frmTANView_new.dtDocumet_ids.Rows[i]["narativeid"] != null)
            //        {
            //            string narId = frmTANView_new.dtDocumet_ids.Rows[i]["narativeid"].ToString();
            //            string rxn = frmTANView_new.dtDocumet_ids.Rows[i]["casreactnum"].ToString();
            //            string seq = frmTANView_new.dtDocumet_ids.Rows[i]["reactionseq"].ToString();


            //            if (narId.Contains("analogousTo=nar"))
            //            {
            //                string[] strsplit = new string[1] { " " };
            //                string[] strtexts = narId.Split(strsplit, StringSplitOptions.RemoveEmptyEntries);
            //                if (strtexts != null)
            //                {
            //                    cmbAnalogousTo.Items.Add(rxn + "_" + seq);
            //                }
            //            }
            //            else
            //            {
            //                cmbAnalogousTo.Items.Add(rxn + "_" + seq);
            //            }

            //        }
            //    }
            //} 
            #endregion

            cmbAnalogousTo.DataSource = null;
            var results = (from m in frmNarrTANView.dtDocumet_ids.AsEnumerable()
                           where m.Field<bool>("curation_complete_status").Equals(true) && m.Field<string>("narativeid") != null
                           select m).CopyToDataTable();
            DataTable dtAnalogousToNarId = (DataTable)results;
            if (dtAnalogousToNarId.Rows.Count != 0)
            {
                cmbAnalogousTo.DisplayMember = "narativeid";
                cmbAnalogousTo.ValueMember = "id";
                cmbAnalogousTo.DataSource = dtAnalogousToNarId;
            }
        }

        /// <summary>
        /// Set Nar Id.
        /// </summary>
        /// <param name="NarIdToSet"></param>
        public void SetNarId(string NarIdToSet)
        {
            try
            {
                #region Old code for set NarId along with anologous to narId
                //if (NarIdToSet.Contains("analogousTo=nar"))
                //{
                //    string[] strsplit = new string[1] { " " };
                //    string[] strtexts = NarIdToSet.Split(strsplit, StringSplitOptions.RemoveEmptyEntries);
                //    if (strtexts != null)
                //    {
                //        chkIsAnalogous.Checked = true;
                //        cmbAnalogousTo.Visible = true;
                //        FillNarIdToComboBox();
                //        strsplit = new string[1] { "=" };
                //        string[] Nar = strtexts[1].Split(strsplit, StringSplitOptions.RemoveEmptyEntries);
                //        var results = (from m in frmTANView_new.dtDocumet_ids.AsEnumerable()

                //                       where m.Field<string>("narativeid").Equals(Nar[1])

                //                       select m).CopyToDataTable();
                //        DataTable dr = (DataTable)results;
                //        string rxnseq = null;
                //        for (int i = 0; i < dr.Rows.Count; i++)
                //        {
                //            rxnseq = dr.Rows[i]["casreactnum"].ToString() + "_" + dr.Rows[i]["reactionseq"].ToString();

                //        }
                //        cmbAnalogousTo.SelectedIndex = cmbAnalogousTo.FindStringExact(rxnseq);


                //        txtnarrativeid.Text = strtexts[0].ToString();

                //    }
                //}
                // else
                //{ 
                #endregion

                txtnarrativeid.Text = NarIdToSet;
                //}
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        /// <summary>
        /// Get NarId.
        /// </summary>
        /// <returns></returns>
        public string GetNarId()
        {
            String NarIdText = null;
            try
            {

                //if (!chkIsAnalogous.Checked)
                {
                    NarIdText = txtnarrativeid.Text;
                }
                #region Old code Get nar id along with anologous to nar id.
                //else
                //{
                //    if (cmbAnalogousTo.SelectedItem != null)
                //    {
                //        NarIdText = txtnarrativeid.Text + " analogousTo=" + cmbAnalogousTo.SelectedItem.ToString();
                //    }
                //}

                #endregion                return NarIdText;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return NarIdText;
        }

        /// <summary>
        /// Reset NarId as well anologous if anologous to another nar.
        /// </summary>
        public void ResetNarId()
        {
            txtnarrativeid.Text = "";
            chkIsAnalogous.Checked = false;
            cmbAnalogousTo.Visible = false;
            //            cmbAnalogousTo.Items.Clear();
            cmbAnalogousTo.DataSource = null;
        }

        /// <summary>
        /// Analogous to nar Id validations like Can't analogous to same,
        /// Mapped reaction para1 cann't be empty, reaction's para1 can't be empty.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbAnalogousTo_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {

                if (chkIsAnalogous.Checked)
                {
                    if (cmbAnalogousTo.SelectedItem != null)
                    {
                        // if (txtnarrativeid.Text.Trim() == cmbAnalogousTo.SelectedItem.ToString())
                        // if (txtCASReactnumber.Text.Trim() + "_" + txtrxnseq.Text.Trim() == cmbAnalogousTo.Text)
                        if (txtnarrativeid.Text.Trim() == cmbAnalogousTo.Text)
                        {
                            MessageBox.Show("narid analogousTo narid's  can not be same", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            chkIsAnalogous.Checked = false;
                            cmbAnalogousTo.SelectedIndex = -1;
                            cmbAnalogousTo.Focus();
                            return;
                        }
                        if (!IsRichTextboxIsEmptry(rtxtparapreview))
                        {
                            MessageBox.Show("Nar ID is mapped for this reaction, Para field should be empty", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            chkIsAnalogous.Checked = false;
                            cmbAnalogousTo.SelectedIndex = -1;
                            rtxtparapreview.Focus();
                            return;
                        }
                        if (CheckNarIDAnalogoustoNarIDparaFieldEmptry(cmbAnalogousTo.Text))
                        {
                            MessageBox.Show("Para1 field is empty, Can't give analogousTo " + cmbAnalogousTo.Text, "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            chkIsAnalogous.Checked = false;
                            cmbAnalogousTo.Focus();
                            return;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        /// <summary>
        /// Checking mapped reacion para field is empty or not.
        /// </summary>
        /// <param name="narId"></param>
        /// <returns>Returns true if empty,else false.</returns>
        private bool CheckNarIDAnalogoustoNarIDparaFieldEmptry(string narId)
        {
            try
            {
                bool Status = false;
                if (frmNarrTANView._lsttanchild != null)
                {
                    if (frmNarrTANView._lsttanchild.Count > 0)
                    {
                        for (int i = 0; i < frmNarrTANView._lsttanchild.Count; i++)
                        {
                            string[] strsplit = new string[1] { " " };
                            string[] strtexts = frmNarrTANView._lsttanchild[i].NarrativeID.Split(strsplit, StringSplitOptions.RemoveEmptyEntries);

                            if (strtexts.Length > 0)
                            {
                                if (strtexts[0].Equals(narId))
                                {
                                    HtmlRichTextBox temp = new HtmlRichTextBox();
                                    ConvertHtmlToRtf(frmNarrTANView._lsttanchild[i].Para, temp);
                                    if (!IsRichTextboxIsEmptry(temp))
                                    {
                                        return Status;
                                    }
                                    else
                                        Status = true;
                                    return Status;
                                }
                            }
                        }
                    }
                }
                return Status;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        /// <summary>
        /// Checks Richtext box is empty or not.
        /// </summary>
        /// <param name="_rtf"></param>
        /// <returns>Returns true if empty,else false.</returns>
        private bool IsRichTextboxIsEmptry(HtmlRichText.HtmlRichTextBox _rtf)
        {
            try
            {
                if (_rtf.Text == null)
                {
                    return true;
                }
                else
                {
                    string strtext = _rtf.Text;
                    strtext = strtext.Replace("\r\n", "");
                    strtext = strtext.Replace("\n", "");
                    strtext = strtext.Replace(" ", "");
                    if (strtext.Length == 0)
                    {
                        return true;
                    }
                    else
                        return false;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return false;
        }

        #endregion

        /// <summary>
        /// Reset all fields or user control.
        /// </summary>
        public void ResetFields()
        {
            try
            {
                txtrxnseq.Text = "";

                txtCASReactnumber.Text = "";

                txtdocref.Text = "";

                txtpagenumber.Text = "";

                txtpagelabel.Text = "";

                txtfilename.Text = "";

                txtxpageunit.Text = "inch";
                txtyresunit.Text = "inch";

                txtxoffset.Text = "";

                txtxpagesize.Text = "";
                txtyoffset.Text = "";

                txtypagesize.Text = "";
                chkisGeneralTypical.Checked = false;

                chkisgeneralprocempty.Checked = false;

                rtxttextlinepreview.Text = "";

                ResetNarId();
                rtxtdatapreview.Text = "";
                rtxtparapreview.Text = "";

                txtpara1.Text = "";

                rtxtdata1.Text = "";

                documentid = 0;
                reactionID = 0;
            }
            catch (Exception ex)
            {

                ErrorHandling.WriteErrorLog(ex.ToString());
            }

        }

        /// <summary>
        /// Reset fields for missing reation. 
        /// </summary>
        public void ResetFieldsforMissingRxn()
        {
            try
            {
                // txtrxnseq.Text = "";

                //                txtCASReactnumber.Text = "";

                txtdocref.Text = "";

                txtpagenumber.Text = "";

                txtpagelabel.Text = "";

                txtfilename.Text = "";

                txtxpageunit.Text = "inch";
                txtyresunit.Text = "inch";

                txtxoffset.Text = "";

                txtxpagesize.Text = "";
                txtyoffset.Text = "";

                txtypagesize.Text = "";
                chkisGeneralTypical.Checked = false;

                chkisgeneralprocempty.Checked = false;

                rtxttextlinepreview.Text = "";

                ResetNarId();
                rtxtdatapreview.Text = "";
                rtxtparapreview.Text = "";

                txtpara1.Text = "";

                rtxtdata1.Text = "";
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }

        }

        /// <summary>
        /// Is General Typical validations like combined procedure, Is para1 empty.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void chkisGeneralTypical_Click(object sender, EventArgs e)
        {
            IsGeneralTypicalValidations();
        }

        /// <summary>
        /// Confirmation from user for setting reaction as missing reation.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void chkIsMissingRxn_Click(object sender, EventArgs e)
        {
            if (chkIsMissingRxn.Checked)
            {
                //int cardCount = frmTANView_new.dtDocumet_ids.AsEnumerable().Where(p => p.Field<int>("SpotID") ==).Count(); validate if nar id analogous to some other reaction or not.

                if (MessageBox.Show("Do you want to make this reaction as missing reaction ? ", "CAS Narrative Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    ResetFieldsforMissingRxn();
                    chkIsMissingRxn.Checked = true;
                }
                else
                {
                    chkIsMissingRxn.Checked = false;
                }
            }
            else
            {
                MessageBox.Show("Do you want to make this reaction as not missing ?\n Click on update to generated narId.", "CAS Narrative Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
                
        private void lnkAddPara_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                ucHtmlRichText ucHrtb = new ucHtmlRichText();
                ucHrtb.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                                | System.Windows.Forms.AnchorStyles.Right))); 
                flPnlPara.Controls.Add(ucHrtb);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void lnkData_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                try
                {
                    ucHtmlRichText ucHrtb = new ucHtmlRichText();
                    ucHrtb.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                                    | System.Windows.Forms.AnchorStyles.Right)));
                    flPnlData.Controls.Add(ucHrtb);
                }
                catch (Exception ex)
                {
                    ErrorHandling.WriteErrorLog(ex.ToString());
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private int GetActiveControlIndexFromFlowLayoutPanel(FlowLayoutPanel flPanel)
        {
            int cntrlIdx = 0;
            try
            {
                if (flPanel != null)
                {
                    if (flPanel.Controls.Count > 0)
                    {
                        ucHtmlRichText ucHB = null;
                        for (int i = 0; i < flPanel.Controls.Count; i++)
                        {
                            ucHB = flPanel.Controls[i] as ucHtmlRichText;
                            if (ucHB != null)
                            {
                                if (ucHB.hrtbPara.Focused)
                                {
                                    cntrlIdx = i;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return cntrlIdx;
        }

        private void btnDeletePara_Click(object sender, EventArgs e)
        {
            try
            {
                if (flPnlPara.Controls.Count > 1)
                {
                    int cntrlIndx = GetActiveControlIndexFromFlowLayoutPanel(flPnlPara);
                    if (cntrlIndx >= 1)
                    {
                        flPnlPara.Controls.RemoveAt(cntrlIndx);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnDeleteData_Click(object sender, EventArgs e)
        {
            try
            {
                if (flPnlData.Controls.Count > 1)
                {
                    int cntrlIndx = GetActiveControlIndexFromFlowLayoutPanel(flPnlData);
                    if (cntrlIndx >= 1)
                    {
                        flPnlData.Controls.RemoveAt(cntrlIndx);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}