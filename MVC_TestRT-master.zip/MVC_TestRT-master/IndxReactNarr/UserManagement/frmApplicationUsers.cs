﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarrDAL;
using IndxReactNarr.Generic;
using IndxReactNarr.Common;

namespace IndxReactNarr.UserManagement
{
    public partial class frmApplicationUsers : Form
    {
        public frmApplicationUsers()
        {
            InitializeComponent();
        }

        private void frmApplicationUsers_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;

                DataTable dtAppUsers = UserManagementDB.GetUserTeamUsersDetails();
                if (dtAppUsers != null)
                {
                    if (GlobalVariables.RoleName != RolesMaster.ADMIN)
                    {

                        DataTable teamUsers = dtAppUsers.AsEnumerable()
                                                .Where(r => r.Field<string>("APPLICATION") == GlobalVariables.ApplicationName)
                                                .CopyToDataTable();
                        if (teamUsers != null)
                        {
                            dgvTeam.AutoGenerateColumns = false;
                            dgvTeam.DataSource = teamUsers;
                        }
                    }
                    else
                    {
                        dgvTeam.AutoGenerateColumns = false;
                        dgvTeam.DataSource = dtAppUsers;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvTeam_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();
                while (strRowNumber.Length < dgvTeam.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvTeam.Font);

                if (dgvTeam.RowHeadersWidth < (int)(size.Width + 20)) dgvTeam.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
