﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarrDAL;
using System.Configuration;
using IndxReactNarr;
using System.DirectoryServices;
using IndxReactNarr.Generic;
using IndxReactNarr.Common;
#endregion

namespace IndxReactNarr
{
    public partial class frmLogin : Form
    {      
        public frmLogin()
        {
            InitializeComponent();
        }
                
        private void frmLogin_Load(object sender, EventArgs e)
        {
            try
            {
                GetUserNamesAndSetToUserNameTxtBox_AutoComplete();

                FillRolesDropDownList();

                txtUserName.Focus();                
            }
            catch (Exception ex)
            {                
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
               
        #region Methods

        /// <summary>
        /// Fill Roles drop down.
        /// </summary>
        private void FillRolesDropDownList()
        {
            try
            {
                DataTable dtRoles = UserManagementDB.GetRoles();
                if (dtRoles != null)
                {
                    if (dtRoles.Rows.Count > 0)
                    {                       
                        cmbRole.DataSource = dtRoles;
                        cmbRole.DisplayMember = "ROLE_NAME";
                        cmbRole.ValueMember = "ROLE_ID";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        /// <summary>
        /// Validates User inputs & LDAP Authentication
        /// </summary>
        /// <param name="errMsg"></param>
        /// <returns></returns>
        private bool ValidateUserInputs(out string errMsg)
        {
            bool blStatus = true;
            string strErrMsg = "";
            try
            {
                if (string.IsNullOrEmpty(txtUserName.Text.Trim()))
                {
                    strErrMsg = strErrMsg.Trim() + "\r\n" + "User name can't be null";
                    blStatus = false;
                }

                if (string.IsNullOrEmpty(txtPassword.Text.Trim()))
                {
                    strErrMsg = strErrMsg.Trim() + "\r\n" + "Password can't be null";
                    blStatus = false;
                }
                if (cmbModule.Text == null && cmbModule.Text == "")
                {
                    strErrMsg = strErrMsg.Trim() + "\r\n" + " Please select module";
                    blStatus = false;
                }
              }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            errMsg = strErrMsg.Trim();
            return blStatus;
        }
       
        private bool ValidateUserAgainstLDAP()
        {
            bool flag = false;
            try
            {
                if (!string.IsNullOrEmpty(txtUserName.Text.Trim()))
                {
                    string adPath = "LDAP://gvkbio.com:389/DC=gvkbio,DC=com";
               
                    LdapAuthentication ldap = new LdapAuthentication(adPath);
                    //Checking User credentials using LDAP Server.
                    if (ldap.IsAuthenticated("GVKBIO", txtUserName.Text.Trim(), txtPassword.Text.Trim()))
                    {
                        flag = true;
                    }
                    else if (ldap.IsAuthenticated("EXCELRA", txtUserName.Text.Trim(), txtPassword.Text.Trim()))
                    {
                        flag = true;
                    }
                }
                else
                {
                    MessageBox.Show("User can't be null", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return flag;
        }

        #endregion

        #region Events
        
        /// <summary>
        /// Validate LDAP user & give access to appplication.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnLogin_Click(object sender, EventArgs e)
        {            
            try
            {              

                string strErrMsg = "";
                //string strEncrpPwd = Encryption.EncriptDecript.Decrypt("4pvhAYq1jtpZBtvz/zgwBw==");

                if (ValidateUserInputs(out strErrMsg))
                {
                    string strModule = "";
                    string strApplication = "";

                    if (cmbApplication.Text == Common.AppVariables.OrgIndxAppName)
                    {
                        strApplication = Enums.ApplicationName.ORGANIC.ToString();
                    }
                    else if (cmbApplication.Text == Common.AppVariables.MacroIndxAppName)
                    {
                        strApplication = Enums.ApplicationName.MACRO.ToString();
                    }
                    else if (cmbApplication.Text == Common.AppVariables.NarrAppName)
                    {
                        strApplication = Enums.ApplicationName.NARRATIVES.ToString();
                    }
                    else if (cmbApplication.Text == Common.AppVariables.ReactAppName)
                    {
                        strApplication = Enums.ApplicationName.REACT.ToString();
                    }
                    else if (cmbApplication.Text == Common.AppVariables.ExpProcedureAppName)
                    {
                        strApplication = Enums.ApplicationName.EXPPROCEDURES.ToString();
                    }

                    if (cmbApplication.Text == Common.AppVariables.NarrAppName || cmbApplication.Text == Common.AppVariables.ExpProcedureAppName)
                    {
                        strModule = "NAR";
                    }
                    else if (cmbApplication.Text == Common.AppVariables.ReactAppName)
                    {
                        strModule = "RXN";
                    }
                    else
                    {
                        strModule = cmbModule.Text;
                    }

                    //Get User Details
                    DataTable dtUserDetails = UserManagementDB.GetUserDetailsByUserNameAndRoleId(txtUserName.Text.Trim(), Convert.ToInt32(cmbRole.SelectedValue), strApplication, strModule);
                    if (dtUserDetails != null && dtUserDetails.Rows.Count > 0)
                    {
                        char isLDAPUser = Convert.ToChar(dtUserDetails.Rows[0]["IS_LDAP_USER"]);
                        if (isLDAPUser == 'N')
                        {
                            DataTable dtUserCredentilas = UserManagementDB.GetUserCredentialsByUserNameAndPassword(txtUserName.Text.Trim(), txtPassword.Text.Trim());
                            if (dtUserCredentilas != null && dtUserCredentilas.Rows.Count > 0)
                            {
                                //Filling Data into Global variables.
                                GlobalVariables.UserName = txtUserName.Text.Trim();
                                GlobalVariables.RoleName = cmbRole.Text;
                                GlobalVariables.RoleID = Convert.ToInt32(cmbRole.SelectedValue);
                                GlobalVariables.UserID = Convert.ToInt32(dtUserDetails.Rows[0]["USER_ID"].ToString());
                                GlobalVariables.URID = Convert.ToInt32(dtUserDetails.Rows[0]["UR_ID"].ToString());                               
                                GlobalVariables.ApplicationName = strApplication;
                                GlobalVariables.ModuleName = strModule;

                                DialogResult = DialogResult.OK;
                                this.Close();
                            }
                            else
                            {
                                MessageBox.Show("Invalid User Name / Password", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            // LDAP user exists or not
                            if (ValidateUserAgainstLDAP())
                            {
                                //Filling Data into Global variables.
                                GlobalVariables.UserName = txtUserName.Text.Trim();
                                GlobalVariables.RoleName = cmbRole.Text;
                                GlobalVariables.RoleID = Convert.ToInt32(cmbRole.SelectedValue);
                                GlobalVariables.UserID = Convert.ToInt32(dtUserDetails.Rows[0]["USER_ID"].ToString());
                                GlobalVariables.URID = Convert.ToInt32(dtUserDetails.Rows[0]["UR_ID"].ToString());
                                GlobalVariables.IsLoginSuccess = true;                                
                                GlobalVariables.ApplicationName = strApplication;
                                GlobalVariables.ModuleName = strModule;

                                DialogResult = DialogResult.OK;
                                this.Close();
                            }
                            else
                            {
                                MessageBox.Show("Invalid User Name / Password", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }//End LDAP.
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid User Name / Password / Role", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show(strErrMsg, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        #endregion

        private void GetUserNamesAndSetToUserNameTxtBox_AutoComplete()
        {
            try
            {
                using (DataTable dtUserNames = UserManagementDB.GetActiveUserDetails())
                {
                    if (dtUserNames != null)
                    {
                        if (dtUserNames.Rows.Count > 0)
                        {
                            AutoCompleteStringCollection usrNameColl = new AutoCompleteStringCollection();

                            for (int i = 0; i < dtUserNames.Rows.Count; i++)
                            {
                                if (dtUserNames.Rows[i][0] != null)
                                {
                                    usrNameColl.Add(dtUserNames.Rows[i]["USER_NAME"].ToString());
                                }
                            }

                            txtUserName.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                            txtUserName.AutoCompleteSource = AutoCompleteSource.CustomSource;
                            txtUserName.AutoCompleteCustomSource = usrNameColl;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString() + ConnectionDB.GetConnectionString());
            }
        }

        private void cmbRole_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbRole.SelectedItem != null)
                {
                    if (cmbRole.Text.ToUpper() == RolesMaster.ADMIN.ToUpper() || cmbRole.Text.ToUpper() == RolesMaster.PM.ToUpper())
                    {
                        //cmbApplication.SelectedIndex = -1;
                        //cmbApplication.Enabled = false;

                        cmbModule.SelectedIndex = -1;
                        cmbModule.Enabled = false;
                    }
                    else if (cmbRole.Text.ToUpper() == RolesMaster.TOOL_MANAGER.ToUpper())
                    {
                        //cmbApplication.SelectedIndex = 0;
                        cmbApplication.Enabled = true;

                        cmbModule.SelectedIndex = -1;
                        cmbModule.Enabled = false;
                    }
                    else
                    {
                        cmbApplication.SelectedIndex = 0;
                        cmbApplication.Enabled = true;

                        cmbModule.SelectedIndex = 0;
                        cmbModule.Enabled = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void cmbApplication_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbApplication.SelectedItem != null)
                {
                    //Add Modules on Application
                    AddModulesOnApplication(cmbApplication.Text.ToUpper());

                    if (cmbApplication.Text.ToUpper() == AppVariables.ReactAppName.ToUpper())
                    {
                        cmbModule.SelectedIndex = 0;
                        cmbModule.Enabled = false;
                    }
                    else if (cmbApplication.Text.ToUpper() == AppVariables.NarrAppName.ToUpper() ||
                        cmbApplication.Text.ToUpper() == AppVariables.ExpProcedureAppName.ToUpper())
                    {
                        cmbModule.SelectedIndex = 0;
                        cmbModule.Enabled = false;
                    }
                    else if (cmbRole.Text.ToUpper() == RolesMaster.TOOL_MANAGER.ToUpper())
                    {
                        cmbModule.SelectedIndex = -1;
                        cmbModule.Enabled = false;
                    }
                    else
                    {
                        cmbModule.SelectedIndex = 0;
                        cmbModule.Enabled = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void AddModulesOnApplication(string application)
        {
            try
            {
                cmbModule.Items.Clear();

                switch (application.ToUpper())
                {
                    case "REACTION ANALYSIS":
                        cmbModule.Items.Add(Enums.ModuleName.RXN);
                        break;
                    case "NARRATIVES":
                    case "EXPERIMENTAL PROCEDURES":
                        cmbModule.Items.Add(Enums.ModuleName.NAR);
                        break;                   
                    case "ORGANIC INDEXING":
                    case "MACRO INDEXING":
                        cmbModule.Items.Add(Enums.ModuleName.INDX);
                        cmbModule.Items.Add(Enums.ModuleName.RXN);
                        break;             
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
