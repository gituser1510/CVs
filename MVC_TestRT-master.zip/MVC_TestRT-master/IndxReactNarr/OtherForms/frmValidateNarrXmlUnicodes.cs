﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Xml.Linq;
using System.Globalization;
using IndxReactNarr.Generic;

namespace IndxReactNarr
{
    public partial class frmCheckUniCodes : Form
    {
        public frmCheckUniCodes()
        {
            InitializeComponent();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;           

            StringBuilder strouterror = new StringBuilder();
            try
            {
                if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
                {
                    Hashtable htreactioncount = new Hashtable();
                    string strpath = folderBrowserDialog1.SelectedPath;
                    textBox1.Text = strpath;

                    if (System.IO.Directory.Exists(strpath))
                    {
                        string[] strfilenames = System.IO.Directory.GetFiles(strpath, "*.xml");
                        if (strfilenames != null)
                        {
                            foreach (string s in strfilenames)
                            {
                                CheckUnicodesInXml(s, ref strouterror);
                            }

                            dgvNotAllowedCodes.DataSource = NonAllowedData;
                            dgvAllowedCodes.DataSource = AllowedData;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        DataTable NonAllowedData = null;
        DataTable AllowedData = null;

        private void DefineReportTables()
        {
            try
            {
                if (NonAllowedData == null)
                {
                    NonAllowedData = new DataTable();
                    NonAllowedData.Columns.Add("TAN");
                    NonAllowedData.Columns.Add("RxnNum");
                    NonAllowedData.Columns.Add("RxnSeq");
                    NonAllowedData.Columns.Add("Tag Name");                    
                    NonAllowedData.Columns.Add("NonAllowed Char");
                    NonAllowedData.Columns.Add("Replacement");
                }
                if (AllowedData == null)
                {
                    AllowedData = new DataTable();
                    AllowedData.Columns.Add("TAN");
                    AllowedData.Columns.Add("RxnNum");
                    AllowedData.Columns.Add("RxnSeq");
                    AllowedData.Columns.Add("Tag Name");                    
                    AllowedData.Columns.Add("Allowed Char");
                    AllowedData.Columns.Add("Replacement");
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void CheckUnicodesInXml(string strfilepath, ref StringBuilder stroutput)
        {
            try
            {
                string strtan = "";
                string xmlFilePath = strfilepath;
                strtan = System.IO.Path.GetFileNameWithoutExtension(strfilepath);

                DefineReportTables();

                IEnumerable<XElement> qryreaction = null;
                try
                {
                    XElement xElm = XElement.Load(strfilepath);
                    Hashtable htana = new Hashtable();
                    IEnumerable<XElement> qrydocs = from c in xElm.Elements("documents")
                                                    select c;
                    qryreaction = from c in xElm.Elements("reaction")
                                  select c;
                }
                catch (Exception ex)
                {

                }
                foreach (XElement _xe in qryreaction)
                {                   
                    IEnumerable<XElement> _rxndoctext = _xe.Elements("docText");
                    IEnumerable<XElement> _rxnnarative = _rxndoctext.Elements("narrative");
                    IEnumerable<XAttribute> _rxnnarrativeid = _rxnnarative.Attributes("id");
                    IEnumerable<XAttribute> _rxnnumber = _xe.Attributes("num");                    
                    IEnumerable<XAttribute> _rxnsequence = _xe.Attributes("seq");
                    IEnumerable<XElement> _location = _xe.Elements("location");

                    string strRxnNum = _rxnnumber.ElementAt(0).Value.ToString();
                    string strRxnSeq = _rxnsequence.ElementAt(0).Value.ToString();

                    //reading textline
                    try
                    {
                        IEnumerable<XElement> _para = _rxnnarative.Elements("para");
                        string strpara1 = "";
                        string strpara2 = "";
                        if (_para.Count() > 1)
                        {
                            strpara1 = _para.ElementAt(0).Value.ToString();
                            ValidateUnicodeCharactersInString(strpara1, strtan, strRxnNum, strRxnSeq, "Para1");
                            
                            strpara2 = _para.ElementAt(1).Value.ToString();
                            ValidateUnicodeCharactersInString(strpara2, strtan, strRxnNum, strRxnSeq, "Para2");
                        }
                        else if (_para.Count() == 1)
                        {
                            strpara1 = _para.ElementAt(0).Value.ToString();
                            ValidateUnicodeCharactersInString(strpara1, strtan, strRxnNum, strRxnSeq, "Para1");
                        }
                    }
                    catch
                    {
                    }
                    //reading para1,para2
                    try
                    {
                        IEnumerable<XElement> _textline = _location.Elements("textLine");
                        string strtextline = _textline.ElementAt(0).Value.ToString();
                        ValidateUnicodeCharactersInString(strtextline, strtan, strRxnNum, strRxnSeq, "textLine");
                    }
                    catch
                    {
                    }
                    //data
                    try
                    {
                        IEnumerable<XElement> _data = _rxndoctext.Elements("data");
                        string strData = _data.Elements("para").ElementAt(0).Value.ToString();
                        ValidateUnicodeCharactersInString(strData, strtan, strRxnNum, strRxnSeq, "Data");
                    }
                    catch
                    { }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }           
        }
       
        private void Form1_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }  

        private bool ValidateUnicodeCharactersInString(string inputstring, out string unicodestring)
        {
            bool blStatus = false;
            string strUnicode = "";
            try
            {
                String originalString = inputstring;// "This string contains the unicode character Pi(π)";
                Byte[] bytes = Encoding.UTF32.GetBytes(originalString);
                StringBuilder asAscii = new StringBuilder();
                StringBuilder nonAscii = new StringBuilder();

                for (int idx = 0; idx < bytes.Length; idx += 4)
                {
                    uint codepoint = BitConverter.ToUInt32(bytes, idx);

                    if (codepoint >= 0000 && codepoint <= 0008)//U+0000 – U+0008(decimal is 0000-0008) (Hex is &#x0000; - &#x0008;) - Disallowed by Xml - Characters found: 9
                    {
                        char c = System.BitConverter.ToChar(bytes, idx);
                        nonAscii.AppendFormat("Not Allowed: " + c + " - Replacement:  " + "&#x{0:X4}; ", codepoint);
                        blStatus = true;
                    }
                    else if (codepoint >= 0011 && codepoint <= 0012)//U+000B – U+000C(decimal is 0011-0012) (Hex is &#x000B; - &#x000C;) - Disallowed by Xml - Characters found: 2
                    {
                        char c = System.BitConverter.ToChar(bytes, idx);
                        nonAscii.AppendFormat("Not Allowed: " + c + " - Replacement:  " + "&#x{0:X4}; ", codepoint);
                        blStatus = true;
                    }
                    else if (codepoint >= 0014 && codepoint <= 0031)//U+000E – U+001F (decimal is 0014-0031) (Hex is &#x000E; - &#x001F;) - Disallowed by Xml - Characters found: 18
                    {
                        char c = System.BitConverter.ToChar(bytes, idx);
                        nonAscii.AppendFormat("Not Allowed: " + c + " - Replacement:  " + "&#x{0:X4}; ", codepoint);
                        blStatus = true;
                    }
                    else if (codepoint >= 55296 && codepoint <= 56319)//U+D800 - U+DBFF decimal range is 55296-56319 - Disallowed by Xml - Characters found: 1024
                    {
                        char c = System.BitConverter.ToChar(bytes, idx);
                        nonAscii.AppendFormat("Not Allowed: " + c + " - Replacement:  " + "&#x{0:X4}; ", codepoint);
                        blStatus = true;
                    }
                    else if (codepoint >= 56320 && codepoint <= 57343)//U+DC00 - U+DFFF (decimal is 56320-57343)(Hex is &#xDC00; - &#xDFFF;)-Disallowed by Xml - Characters found: 1024
                    {
                        char c = System.BitConverter.ToChar(bytes, idx);
                        nonAscii.AppendFormat("Not Allowed: " + c + " - Replacement:  " + "&#x{0:X4}; ", codepoint);
                        blStatus = true;
                    }
                    else if (codepoint >= 57344 && codepoint <= 63743)//U+E000 - U+F8FF (decimal is - 57344-63743) (Hex is - &#xE000; - &#xF8FF;) disallowed by CAS (Unicode Private Use Area)- Characters found: 6400
                    {
                        char c = System.BitConverter.ToChar(bytes, idx);
                        nonAscii.AppendFormat("Not Allowed: " + c + " - Replacement:  " + "&#x{0:X4}; ", codepoint);                     
                        blStatus = true;
                    }                    
                    else if (codepoint >= 0127 && codepoint <= 0159)//U+007F to U+009F (decimal is 0127-0159) (Hex is &#x007F; - &#x009F;) - disallowed by CAS (control codes) -Characters found: 33
                    {
                        char c = System.BitConverter.ToChar(bytes, idx);
                        nonAscii.AppendFormat("Not Allowed: " + c + " - Replacement:  " + "&#x{0:X4}; ", codepoint);
                        blStatus = true;
                    }
                    else if (codepoint >= 65536)//U+10000 to U+10FFFF (decimal is 65536-0) (Hex is &#x10000; - ;) - disallowed by CAS (outside of Unicode Basic Multilingual Plane) -Characters found: -
                    {
                        char c = System.BitConverter.ToChar(bytes, idx);
                        nonAscii.AppendFormat("Not Allowed: " + c + " - Replacement:  " + "&#x{0:X4}; ", codepoint);
                        blStatus = true;
                    }
                    //else if (codepoint >= 63744 && codepoint <= 65533)//U+F900 – U+FFFD (decimal is 65536-0) (Hex is &#xF900; - &#xFFFD;) - Allowed - Characters found: 1603
                    //{
                    //    char c = System.BitConverter.ToChar(bytes, idx);
                    //    nonAscii.AppendFormat("Allowed : " + c + " - Replacement:  " + "&#x{0:X4}; ", codepoint);
                    //    blStatus = true;
                    //}
                    //else if (codepoint >= 0160 && codepoint <= 55291)//U+00A0 – U+D7FF (Decimal is 0160 - 55291) (Hex is &#x00A0; - &#xD7FB;) - Allowed
                    //{
                    //    char c = System.BitConverter.ToChar(bytes, idx);
                    //    nonAscii.AppendFormat("Allowed : " + c + " - Replacement:  " + "&#x{0:X4}; ", codepoint);
                    //    blStatus = true;
                    //}
                    //Allowed - U+F900 – U+FFFD (Decimal is 63744 - 65533) (Hex is &#xF900; - &#xFFFD;)
                    //Allowed - U+00A0 – U+D7FF (Decimal is 0160 - 0) (Hex is &#x00A0; - 0)
                    

                    //if (codepoint > 127)
                    //{
                    //    //Encoding.ASCII.GetBytes(codepoint.ToString());
                    //    //string s = codepoint.ToString("\\u{0:x4}" );
                    //    //nonAscii.AppendFormat("\\u{0:x4}", codepoint);

                    //    StringBuilder temp = new StringBuilder();
                    //    temp.AppendFormat("\\u{0:x4}", codepoint);
                    //    string encodedValue = "\\u" + ((int)codepoint).ToString("x4");

                    //    //blStatus = true;
                    //}
                }
                strUnicode = nonAscii.ToString();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            unicodestring = strUnicode;
            return blStatus;
        }

        private bool ValidateUnicodeCharactersInString(string inputstring,string tan, string rxnnum,string rxnseq, string tag)
        {
            bool blStatus = false;           
            try
            {
                String originalString = inputstring;
                Byte[] bytes = Encoding.UTF32.GetBytes(originalString);           
                uint codepoint = 0;

                //U+0000 – U+0008(decimal is 0000-0008) (Hex is &#x0000; - &#x0008;) - Disallowed by Xml - Characters found: 9
                //U+000B – U+000C(decimal is 0011-0012) (Hex is &#x000B; - &#x000C;) - Disallowed by Xml - Characters found: 2
                //U+000E – U+001F (decimal is 0014-0031) (Hex is &#x000E; - &#x001F;) - Disallowed by Xml - Characters found: 18
                //U+D800 - U+DBFF decimal range is 55296-56319 - Disallowed by Xml - Characters found: 1024
                //U+DC00 - U+DFFF (decimal is 56320-57343)(Hex is &#xDC00; - &#xDFFF;)-Disallowed by Xml - Characters found: 1024
                //U+E000 - U+F8FF (decimal is - 57344-63743) (Hex is - &#xE000; - &#xF8FF;) disallowed by CAS (Unicode Private Use Area)- Characters found: 6400
                //U+007F - U+009F (decimal is 0127-0159) (Hex is &#x007F; - &#x009F;) - disallowed by CAS (control codes) -Characters found: 33
                //U+10000 to U+10FFFF (decimal is 65536-0) (Hex is &#x10000; - ;) - disallowed by CAS (outside of Unicode Basic Multilingual Plane) -Characters found: -
                //U+2103 - ℃ - 8451 - Disallowed - 23rd Apr 2015

                for (int idx = 0; idx < bytes.Length; idx += 4)
                {
                    codepoint = 0;
                    codepoint = BitConverter.ToUInt32(bytes, idx); 
                   
                    //Not Allowed Unicodes
                    if ((codepoint >= 0000 && codepoint <= 0008) || (codepoint >= 0011 && codepoint <= 0012) || (codepoint >= 0014 && codepoint <= 0031) ||
                        (codepoint >= 55296 && codepoint <= 56319) || (codepoint >= 56320 && codepoint <= 57343) || (codepoint >= 57344 && codepoint <= 63743) ||
                        (codepoint >= 0127 && codepoint <= 0159) || (codepoint >= 65536) || (codepoint == 8451))
                    {                        
                        blStatus = true;

                        DataRow dtRow = NonAllowedData.NewRow();
                        dtRow["TAN"] = tan;
                        dtRow["RxnNum"] = rxnnum;
                        dtRow["RxnSeq"] = rxnseq;
                        dtRow["Tag Name"] = tag;                        
                        dtRow["NonAllowed Char"] = System.BitConverter.ToChar(bytes, idx);
                        dtRow["Replacement"] = string.Format("&#x{0:X4};", codepoint);
                        NonAllowedData.Rows.Add(dtRow);
                    }
         
                    //Allowed Unicodes
                    //U+F900 – U+FFFD (decimal is 65536-0) (Hex is &#xF900; - &#xFFFD;) - Allowed - Characters found: 1603
                    //U+00A0 – U+D7FF (Decimal is 0160 - 55291) (Hex is &#x00A0; - &#xD7FB;) - Allowed
                    //U+2282 - (Subset of) Decimal - 8834 & Hex - 2282 - Allowed - New code as on 24th Jan 2013

                    //Only these characters are allowed: U+0009,U+000A,U+000D,U+0020-U+007E,U+00A0-U+2102,U+2104-U+2108,U+210A-U+D7FF,U+F900-U+FFFD - 23rd Apr 2015

                    if ((codepoint >= 63744 && codepoint <= 65533) || (codepoint >= 0160 && codepoint <= 55291) || codepoint == 8834) 
                    {
                        char c = System.BitConverter.ToChar(bytes, idx);
                        //sbAllCode.AppendFormat("Allowed : " + c + " - Replacement:  " + "&#x{0:X4}; ", codepoint);
                        blStatus = true;

                        DataRow dtRow = AllowedData.NewRow();
                        dtRow["TAN"] = tan;
                        dtRow["RxnNum"] = rxnnum;
                        dtRow["RxnSeq"] = rxnseq;
                        dtRow["Tag Name"] = tag;                        
                        dtRow["Allowed Char"] = c;
                        dtRow["Replacement"] = string.Format("&#x{0:X4};", codepoint);
                        AllowedData.Rows.Add(dtRow);
                    }                    
                }      
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }           
            return blStatus;
        }

        private void dgvNotAllowedCodes_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvNotAllowedCodes.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvNotAllowedCodes.Font);

                if (dgvNotAllowedCodes.RowHeadersWidth < (int)(size.Width + 20)) dgvNotAllowedCodes.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvAllowedCodes_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvAllowedCodes.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvAllowedCodes.Font);

                if (dgvAllowedCodes.RowHeadersWidth < (int)(size.Width + 20)) dgvAllowedCodes.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        
    }
}
