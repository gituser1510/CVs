﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using Keyoti.RapidSpell.Grid;
using IndxReactNarrDAL;

namespace IndxReactNarr
{
    public partial class frmFinalChecks_Supervisor : Form
    {
        public frmFinalChecks_Supervisor()
        {
            InitializeComponent();
        }

        public string SelOption = "";

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtBatchName.Text.Trim() != "")
                {
                    string strSelOpt = GetSelectedOption();
                    if (strSelOpt.Trim() != "")
                    {
                        SelOption = strSelOpt;

                        int intBatchNo = 0;
                        int.TryParse(txtBatchNo.Text.Trim(),out intBatchNo);

                        DataTable dtResults = ReactDB.GetToolManagerFinalChecks(strSelOpt, txtBatchName.Text.Trim(), intBatchNo);
                        if (dtResults != null)
                        {
                            if (strSelOpt == "COMMENTS")
                            {
                                //btnUpdate.Visible = true;
                                
                                BindCommentsDataToGrid(dtResults);
                            }
                            else //any other option
                            {
                                btnUpdate.Visible = false;

                                dgvQryResults.Columns.Clear();
                                dgvQryResults.AutoGenerateColumns = true;
                                dgvQryResults.DataSource = dtResults;

                                for (int i = 3; i < dgvQryResults.Columns.Count; i++)
                                {
                                    dgvQryResults.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
                                    dgvQryResults.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                                    dgvQryResults.ReadOnly = true;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindCommentsDataToGrid(DataTable _dtcomments)
        {
            try
            {
                if (_dtcomments != null)
                {
                    dgvQryResults.DataError -= new DataGridViewDataErrorEventHandler(dgvQryResults_DataError);
                    dgvQryResults.DataError += new DataGridViewDataErrorEventHandler(dgvQryResults_DataError);
                    
                    DataTable dtResults = _dtcomments;

                    dgvQryResults.Columns.Clear();

                    dgvQryResults.Columns.Add("colTAN", "TAN");
                    dgvQryResults.Columns.Add("colComments", "Comments");
                    dgvQryResults.Columns.Add("colCommentType", "CommentType");
                    dgvQryResults.Columns.Add("colBatchNo", "BatchNo");

                    AYTDataGridViewTextBoxColumn aytUsrComments = new AYTDataGridViewTextBoxColumn();
                    aytUsrComments.Name = "colUserComments";
                    aytUsrComments.HeaderText = "User Comments";                    
                    dgvQryResults.Columns.Add(aytUsrComments);                    

                    DataTable dtTemp = dtResults;
                    dtTemp.Columns.Add("UserComments", typeof(string));

                    string[] splitter = { "\r\n" };
                    for (int i = 0; i < dtResults.Rows.Count; i++)
                    {
                        if (dtResults.Rows[i]["TAN_COMMENT"].ToString() != "")
                        {
                            if (dtResults.Rows[i]["TAN_COMMENT"].ToString().StartsWith("`"))//No default comments
                            {
                                dtResults.Rows[i]["UserComments"] = dtResults.Rows[i]["TAN_COMMENT"].ToString().Replace("`", "").Trim();
                                dtResults.Rows[i]["comments"] = "";
                            }
                            else if (dtResults.Rows[i]["TAN_COMMENT"].ToString().Contains("\r\n"))//default & user comments
                            {
                                string[] strArr = dtResults.Rows[i]["TAN_COMMENT"].ToString().Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                                if (strArr != null)
                                {
                                    if (strArr.Length == 2)
                                    {
                                        dtResults.Rows[i]["TAN_COMMENT"] = strArr[0];
                                        dtResults.Rows[i]["UserComments"] = strArr[1];
                                    }
                                }
                            }
                        }
                    }
                    dtResults.AcceptChanges();

                    dgvQryResults.AutoGenerateColumns = false;
                    dgvQryResults.DataSource = dtResults;

                    dgvQryResults.ReadOnly = false;

                    dgvQryResults.Columns["colTAN"].DataPropertyName = "TAN_NAME";
                    dgvQryResults.Columns["colTAN"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                    dgvQryResults.Columns["colTAN"].Width = 90;
                    dgvQryResults.Columns["colTAN"].ReadOnly = true;

                    dgvQryResults.Columns["colBatchNo"].DataPropertyName = "BATCH_NO";

                    dgvQryResults.Columns["colComments"].DataPropertyName = "TAN_COMMENT";
                    dgvQryResults.Columns["colComments"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                    dgvQryResults.Columns["colComments"].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                    dgvQryResults.Columns["colComments"].Width = 200;
                    dgvQryResults.Columns["colComments"].ReadOnly = true;

                    dgvQryResults.Columns["colCommentType"].DataPropertyName = "COMMENT_TYPE";
                    dgvQryResults.Columns["colCommentType"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                    dgvQryResults.Columns["colCommentType"].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                    dgvQryResults.Columns["colCommentType"].Width = 100;
                    dgvQryResults.Columns["colCommentType"].ReadOnly = true;

                    dgvQryResults.Columns["colUserComments"].DataPropertyName = dtResults.Columns["UserComments"].ColumnName;
                    dgvQryResults.Columns["colUserComments"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    dgvQryResults.Columns["colUserComments"].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                    dgvQryResults.Columns["colUserComments"].DefaultCellStyle.BackColor = Color.LightYellow;
                    dgvQryResults.Columns["colUserComments"].Width = 670;
                    dgvQryResults.Columns["colUserComments"].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                    dgvQryResults.Columns["colUserComments"].ReadOnly = false;

                    //Auto Resize rows
                    for (int i = 0; i < dgvQryResults.Rows.Count; i++)
                    {
                        dgvQryResults.AutoResizeRow(i, DataGridViewAutoSizeRowMode.AllCells);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
               
        private string GetSelectedOption()
        {
            string strSelOpt = "";
            try
            {
                if (rbnZeroPartpnts.Checked)
                {
                    strSelOpt = "ZERO PARTICIPANTS";
                }
                else if (rbnTemp_Direct.Checked)
                {
                    strSelOpt = "TEMP-DIRECTIONAL";
                }
                else if (rbnTemp_Range.Checked)
                {
                    strSelOpt = "TEMP-RANGE";
                }
                else if (rbnTime_Pressure.Checked)
                {
                    strSelOpt = "TIME-PRESSURE";
                }
                else if (rbnRxnNUM_Seq.Checked)
                {
                    strSelOpt = "NUM-SEQ";
                }
                else if (rbnComments.Checked)
                {
                    strSelOpt = "COMMENTS";
                }
                else if (rbnTAN_CAN.Checked)
                {
                    strSelOpt = "TAN-CAN-ANALYST";
                }
                else if (rbn8000_Name_Loc.Checked)
                {
                    strSelOpt = "SERIES-8000";
                }
                else if (rbnNoSolvRxns.Checked)
                {
                    strSelOpt = "NO SOLVENT REACTIONS";
                }
                else if (rbnMWaveRxns.Checked)
                {
                    strSelOpt = "MICROWAVE REACTIONS";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strSelOpt;
        }
        
        private void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dtResults = (DataTable)dgvQryResults.DataSource;

                if (dtResults != null)
                {
                    if (dtResults.Rows.Count > 0)
                    {
                        saveFileDialog1.Filter = "XlS|*.xls";
                        if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                        {
                            //if (CAS_Classes.Export.Excel_FromDataTable(saveFileDialog1.FileName, dtResults))
                            //{
                            //    MessageBox.Show("Exported to excel successfully", "Final Checks - Export", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            //}
                        }
                    }
                    else
                    {
                        MessageBox.Show("No data is available to export", "Final Checks - Export", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("No data is available to export", "Final Checks - Export", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void frmFinalChecks_Supervisor_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (SelOption == "8500-8000-COMMENTS")
                {
                    if (dgvQryResults.Rows.Count > 0)
                    {
                        DialogResult diaRes = MessageBox.Show("Do you want to save the modifications?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (diaRes == DialogResult.Yes)
                        {
                            DataTable dtComments = (DataTable)dgvQryResults.DataSource;
                            if (dtComments != null)
                            {
                                if (dtComments.Rows.Count > 0)
                                {
                                    string strTAN = "";
                                    string strComments = "";
                                    int intCntr = 0;

                                    for (int i = 0; i < dtComments.Rows.Count; i++)
                                    {
                                        strComments = "";
                                        strTAN = dtComments.Rows[i]["tan"].ToString();

                                        if (dtComments.Rows[i]["comments"].ToString().Trim() != "")
                                        {
                                            strComments = dtComments.Rows[i]["comments"].ToString().Trim();
                                            if (dtComments.Rows[i]["UserComments"].ToString().Trim() != "")
                                            {
                                                strComments = strComments + "\r\n" + dtComments.Rows[i]["UserComments"].ToString().Trim();
                                            }
                                        }
                                        else if (dtComments.Rows[i]["UserComments"].ToString().Trim() != "")
                                        {
                                            strComments = "`" + dtComments.Rows[i]["UserComments"].ToString().Trim();
                                        }

                                        //if (ReactDB.UpdateCommentsOnTANID(strTAN, strComments))
                                        //{
                                        //    intCntr = intCntr + 1;
                                        //}
                                        //else
                                        //{
                                        //    MessageBox.Show("Error in saving " + strTAN + " comments ", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        //    break;
                                        //}
                                    }
                                    if (intCntr == dtComments.Rows.Count)
                                    {
                                        MessageBox.Show("Updated comments successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void rbnZeroPartpnts_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                RadioButton rbn = (RadioButton)sender;

                if (!rbn.Checked)
                {
                    ResetDatainGrid();
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void ResetDatainGrid()
        {
            try
            {
                dgvQryResults.DataSource = null;
                dgvQryResults.Columns.Clear();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvQryResults_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvQryResults.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvQryResults.Font);

                if (dgvQryResults.RowHeadersWidth < (int)(size.Width + 20)) dgvQryResults.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvQryResults_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            // (No need to write anything in here)
            e.ThrowException = false;
        }        
    }
}
