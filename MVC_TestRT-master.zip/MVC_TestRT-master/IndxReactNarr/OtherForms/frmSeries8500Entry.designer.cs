﻿namespace IndxReactNarr
{
    partial class frmSeries8500Entry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            MDL.Draw.Renderer.Preferences.DisplayPreferences displayPreferences1 = new MDL.Draw.Renderer.Preferences.DisplayPreferences();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.splCont = new System.Windows.Forms.SplitContainer();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.ChemRenditor = new MDL.Draw.Renditor.Renditor();
            this.txtInchi = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtNrnReg = new System.Windows.Forms.TextBox();
            this.lblInchi = new System.Windows.Forms.Label();
            this.lblStruct = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblRegNo = new System.Windows.Forms.Label();
            this.dgvSeries8500 = new System.Windows.Forms.DataGridView();
            this.colNrnReg = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStructure = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colInchi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain.SuspendLayout();
            this.splCont.Panel1.SuspendLayout();
            this.splCont.Panel2.SuspendLayout();
            this.splCont.SuspendLayout();
            this.pnlTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSeries8500)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.splCont);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1151, 487);
            this.pnlMain.TabIndex = 0;
            // 
            // splCont
            // 
            this.splCont.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splCont.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splCont.Location = new System.Drawing.Point(0, 0);
            this.splCont.Name = "splCont";
            this.splCont.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splCont.Panel1
            // 
            this.splCont.Panel1.Controls.Add(this.pnlTop);
            // 
            // splCont.Panel2
            // 
            this.splCont.Panel2.Controls.Add(this.dgvSeries8500);
            this.splCont.Size = new System.Drawing.Size(1151, 487);
            this.splCont.SplitterDistance = 243;
            this.splCont.TabIndex = 2;
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.SystemColors.Control;
            this.pnlTop.Controls.Add(this.btnReset);
            this.pnlTop.Controls.Add(this.btnUpdate);
            this.pnlTop.Controls.Add(this.ChemRenditor);
            this.pnlTop.Controls.Add(this.txtInchi);
            this.pnlTop.Controls.Add(this.txtName);
            this.pnlTop.Controls.Add(this.txtNrnReg);
            this.pnlTop.Controls.Add(this.lblInchi);
            this.pnlTop.Controls.Add(this.lblStruct);
            this.pnlTop.Controls.Add(this.lblName);
            this.pnlTop.Controls.Add(this.lblRegNo);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1147, 239);
            this.pnlTop.TabIndex = 0;
            // 
            // btnReset
            // 
            this.btnReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReset.Location = new System.Drawing.Point(1062, 207);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 29);
            this.btnReset.TabIndex = 10;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdate.Location = new System.Drawing.Point(972, 207);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 29);
            this.btnUpdate.TabIndex = 9;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // ChemRenditor
            // 
            this.ChemRenditor.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.ChemRenditor.AutoSizeStructure = true;
            this.ChemRenditor.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.ChemRenditor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ChemRenditor.ChimeString = null;
            this.ChemRenditor.ClearingEnabled = true;
            this.ChemRenditor.CopyingEnabled = true;
            this.ChemRenditor.DisplayOnEmpty = "No Structure";
            this.ChemRenditor.EditingEnabled = true;
            this.ChemRenditor.FileName = null;
            this.ChemRenditor.HighlightInfo = null;
            this.ChemRenditor.IsBitmapFromOLE = true;
            this.ChemRenditor.Location = new System.Drawing.Point(72, 3);
            this.ChemRenditor.Metafile = null;
            this.ChemRenditor.Molecule = null;
            this.ChemRenditor.MolfileString = null;
            this.ChemRenditor.Name = "ChemRenditor";
            this.ChemRenditor.OldScalingMode = MDL.Draw.Renderer.Preferences.StructureScalingMode.ScaleToFitBox;
            this.ChemRenditor.PastingEnabled = true;
            this.ChemRenditor.Preferences = displayPreferences1;
            this.ChemRenditor.PreferencesFileName = "default.xml";
            this.ChemRenditor.RendererBorderStyle = System.Windows.Forms.ButtonBorderStyle.Inset;
            this.ChemRenditor.RenditorMolecule = null;
            this.ChemRenditor.RenditorName = "Demo Renditor";
            this.ChemRenditor.Size = new System.Drawing.Size(463, 233);
            this.ChemRenditor.SketchString = null;
            this.ChemRenditor.SmilesString = null;
            this.ChemRenditor.TabIndex = 8;
            this.ChemRenditor.URLEncodedMolfileString = null;
            this.ChemRenditor.UseLocalXMLConfig = false;
            this.ChemRenditor.StructureChanged += new System.EventHandler(this.ChemRenditor_StructureChanged);
            // 
            // txtInchi
            // 
            this.txtInchi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtInchi.BackColor = System.Drawing.Color.White;
            this.txtInchi.ForeColor = System.Drawing.Color.Blue;
            this.txtInchi.Location = new System.Drawing.Point(616, 94);
            this.txtInchi.Name = "txtInchi";
            this.txtInchi.ReadOnly = true;
            this.txtInchi.Size = new System.Drawing.Size(528, 25);
            this.txtInchi.TabIndex = 6;
            // 
            // txtName
            // 
            this.txtName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtName.Location = new System.Drawing.Point(616, 35);
            this.txtName.Multiline = true;
            this.txtName.Name = "txtName";
            this.txtName.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtName.Size = new System.Drawing.Size(528, 53);
            this.txtName.TabIndex = 5;
            // 
            // txtNrnReg
            // 
            this.txtNrnReg.ForeColor = System.Drawing.Color.Blue;
            this.txtNrnReg.Location = new System.Drawing.Point(616, 4);
            this.txtNrnReg.Name = "txtNrnReg";
            this.txtNrnReg.Size = new System.Drawing.Size(169, 25);
            this.txtNrnReg.TabIndex = 4;       
            this.txtNrnReg.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtNrnReg_KeyUp);
            // 
            // lblInchi
            // 
            this.lblInchi.AutoSize = true;
            this.lblInchi.Location = new System.Drawing.Point(560, 97);
            this.lblInchi.Name = "lblInchi";
            this.lblInchi.Size = new System.Drawing.Size(50, 17);
            this.lblInchi.TabIndex = 3;
            this.lblInchi.Text = "INCHI";
            // 
            // lblStruct
            // 
            this.lblStruct.AutoSize = true;
            this.lblStruct.Location = new System.Drawing.Point(4, 6);
            this.lblStruct.Name = "lblStruct";
            this.lblStruct.Size = new System.Drawing.Size(62, 17);
            this.lblStruct.TabIndex = 2;
            this.lblStruct.Text = "Structure";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(566, 38);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(44, 17);
            this.lblName.TabIndex = 1;
            this.lblName.Text = "Name";
            // 
            // lblRegNo
            // 
            this.lblRegNo.AutoSize = true;
            this.lblRegNo.Location = new System.Drawing.Point(541, 7);
            this.lblRegNo.Name = "lblRegNo";
            this.lblRegNo.Size = new System.Drawing.Size(69, 17);
            this.lblRegNo.TabIndex = 0;
            this.lblRegNo.Text = "NRNREG";
            // 
            // dgvSeries8500
            // 
            this.dgvSeries8500.AllowUserToAddRows = false;
            this.dgvSeries8500.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.dgvSeries8500.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSeries8500.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvSeries8500.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSeries8500.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colNrnReg,
            this.colName,
            this.colStructure,
            this.colInchi});
            this.dgvSeries8500.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSeries8500.Location = new System.Drawing.Point(0, 0);
            this.dgvSeries8500.Name = "dgvSeries8500";
            this.dgvSeries8500.ReadOnly = true;
            this.dgvSeries8500.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSeries8500.Size = new System.Drawing.Size(1147, 236);
            this.dgvSeries8500.TabIndex = 1;
            this.dgvSeries8500.Sorted += new System.EventHandler(this.dgvSeries8500_Sorted);
            this.dgvSeries8500.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSeries8500_RowEnter);
            this.dgvSeries8500.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvSeries8500_RowPostPaint);
            // 
            // colNrnReg
            // 
            this.colNrnReg.HeaderText = "RegistryNo";
            this.colNrnReg.Name = "colNrnReg";
            this.colNrnReg.ReadOnly = true;
            // 
            // colName
            // 
            this.colName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colName.HeaderText = "Name";
            this.colName.Name = "colName";
            this.colName.ReadOnly = true;
            // 
            // colStructure
            // 
            this.colStructure.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colStructure.HeaderText = "Structure";
            this.colStructure.Name = "colStructure";
            this.colStructure.ReadOnly = true;
            // 
            // colInchi
            // 
            this.colInchi.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colInchi.HeaderText = "Inchi";
            this.colInchi.Name = "colInchi";
            this.colInchi.ReadOnly = true;
            // 
            // frmSeries8500Entry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1151, 487);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmSeries8500Entry";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Series8500 Entry";
            this.Load += new System.EventHandler(this.frmSeries8500Entry_Load);
            this.pnlMain.ResumeLayout(false);
            this.splCont.Panel1.ResumeLayout(false);
            this.splCont.Panel2.ResumeLayout(false);
            this.splCont.ResumeLayout(false);
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSeries8500)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.DataGridView dgvSeries8500;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.TextBox txtInchi;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtNrnReg;
        private System.Windows.Forms.Label lblInchi;
        private System.Windows.Forms.Label lblStruct;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblRegNo;
        private MDL.Draw.Renditor.Renditor ChemRenditor;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.SplitContainer splCont;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNrnReg;
        private System.Windows.Forms.DataGridViewTextBoxColumn colName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStructure;
        private System.Windows.Forms.DataGridViewTextBoxColumn colInchi;
    }
}