﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Xml.Linq;
using IndxReactNarr.Generic;

namespace IndxReactNarr.OtherForms
{
    public partial class frmExtractProcedureCountFromXml : Form
    {
        public frmExtractProcedureCountFromXml()
        {
            InitializeComponent();
        }

        private void frmExtractProcedureCountFromXml_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void btnBrowseOutputXmls_Click(object sender, EventArgs e)
        {
            try
            {                
                if (folderBrowserDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    txtOutputXmlFilesPath.Text = folderBrowserDialog1.SelectedPath;                                       
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnBrowseInputXmls_Click(object sender, EventArgs e)
        {
            try
            {
                if (folderBrowserDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    txtInputFilesPath.Text = folderBrowserDialog1.SelectedPath;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindCountsDataToGrid(DataTable rxnCounts)
        {
            try
            {
                dgvProcedureCount.AutoGenerateColumns = false;
                dgvProcedureCount.DataSource = rxnCounts;

                colTAN.DataPropertyName = "TAN";
                colInputRxnsCnt.DataPropertyName = "IN_RXN_CNT";
                colOutputRxnCount.DataPropertyName = "OUT_RXN_CNT";
                colInputProcCnt.DataPropertyName = "IN_NAR_CNT";
                colOutputProcCount.DataPropertyName = "OUT_NAR_CNT";
                colWithProcStepsCnt.DataPropertyName = "WITH_PROC_STEP_CNT";
                colWithoutProcStepsCnt.DataPropertyName = "WITHOUT_PROC_STEP_CNT";
                colInputXmlError.DataPropertyName = "IN_XML_ERROR";
                colOutXmlError.DataPropertyName = "OUT_XML_ERROR";

                //Set counts
                lblTANCount.Text = rxnCounts.Rows.Count.ToString();
                lblInRxnsCount.Text = rxnCounts.Compute("sum([IN_RXN_CNT])", "[IN_RXN_CNT] is not null").ToString();
                lblOutRxnsCount.Text = rxnCounts.Compute("sum([OUT_RXN_CNT])", "[OUT_RXN_CNT] is not null").ToString();

                lblInNarProcCount.Text = rxnCounts.Compute("sum([IN_NAR_CNT])", "[IN_NAR_CNT] is not null").ToString();
                lblOutNarProcCount.Text = rxnCounts.Compute("sum([OUT_NAR_CNT])", "[OUT_NAR_CNT] is not null").ToString();

                lblRxnWithProcCnt.Text = rxnCounts.Compute("sum([WITH_PROC_STEP_CNT])", "[WITH_PROC_STEP_CNT] is not null").ToString();
                lblRxnWithoutProcCnt.Text = rxnCounts.Compute("sum([WITHOUT_PROC_STEP_CNT])", "[WITHOUT_PROC_STEP_CNT] is not null").ToString();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private DataTable ExtractCountsFromXmlFiles(string xmlFilesPath)
        {
            DataTable dtRxnProcCnts = null;
            try
            {
                string[] saXmlfiles = System.IO.Directory.GetFiles(xmlFilesPath, "*.xml");
                if (saXmlfiles != null && saXmlfiles.Length > 0)
                {
                    dtRxnProcCnts = new DataTable();
                    dtRxnProcCnts.Columns.Add("TAN", typeof(string));

                    dtRxnProcCnts.Columns.Add("IN_RXN_CNT", typeof(int));
                    dtRxnProcCnts.Columns.Add("OUT_RXN_CNT", typeof(int));

                    dtRxnProcCnts.Columns.Add("IN_NAR_CNT", typeof(int));
                    dtRxnProcCnts.Columns.Add("OUT_NAR_CNT", typeof(int));

                    dtRxnProcCnts.Columns.Add("WITH_PROC_STEP_CNT", typeof(int));
                    dtRxnProcCnts.Columns.Add("WITHOUT_PROC_STEP_CNT", typeof(int));

                    dtRxnProcCnts.Columns.Add("IN_XML_ERROR", typeof(string));
                    dtRxnProcCnts.Columns.Add("OUT_XML_ERROR", typeof(string));

                    XElement xEle;
                    int outRxnCnt = 0;
                    int withProcCnt = 0;
                    int withoutProcCnt = 0;
                    string strTAN = "";
                    int outNarProcCnt = 0;

                    int inNarProcCnt = 0;
                    int inRxnCnt = 0;
                    string inXmlError = "";

                    foreach (string xmlpath in saXmlfiles)
                    {
                        strTAN = System.IO.Path.GetFileNameWithoutExtension(xmlpath);

                        //txtInputFilesPath.Text, strTAN + ".xml"

                        DataRow dr = dtRxnProcCnts.NewRow();
                        dr["TAN"] = strTAN;

                        inNarProcCnt = GetNarrProcedureCountFromInputXmlFile(strTAN, txtInputFilesPath.Text, out inRxnCnt, out inXmlError);

                        dr["IN_RXN_CNT"] = inRxnCnt;
                        dr["IN_NAR_CNT"] = inNarProcCnt;
                        dr["IN_XML_ERROR"] = inXmlError;

                        try
                        {
                            outRxnCnt = 0;
                            withProcCnt = 0;
                            withoutProcCnt = 0;

                            xEle = XElement.Load(xmlpath);
                            outRxnCnt = xEle.Elements("reactions").Elements("reaction").Count();
                            outNarProcCnt = xEle.Elements("reactions").Elements("reaction").Elements("procedure").Count();

                            IEnumerable<XElement> eleRxns = from c in xEle.Elements("reactions").Elements("reaction")
                                                            select c;

                            //int withProc = xEle.Elements("reactions").Elements("reaction").Elements("template").Elements("protocol").Count();
                            //int woProcCnt = eleRxns.Count() - withProc;

                            //For each reaction in the TAN, count procedure steps
                            foreach (XElement xe in eleRxns)
                            {
                                try
                                {
                                    if (xe.Elements("template").Elements("protocol").Count() > 0)
                                    {
                                        withProcCnt = withProcCnt + 1;
                                    }
                                    else
                                    {
                                        withoutProcCnt = withoutProcCnt + 1;
                                    }
                                }
                                catch
                                {
                                    withoutProcCnt = withoutProcCnt + 1;
                                }
                            }

                            dr["OUT_RXN_CNT"] = outRxnCnt;
                            dr["OUT_NAR_CNT"] = outNarProcCnt;
                            dr["WITH_PROC_STEP_CNT"] = withProcCnt;
                            dr["WITHOUT_PROC_STEP_CNT"] = withoutProcCnt;
                        }
                        catch(Exception ex)
                        {
                            dr["OUT_XML_ERROR"] = ex.ToString();
                        }

                        dtRxnProcCnts.Rows.Add(dr);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtRxnProcCnts;
        }

        private int GetNarrProcedureCountFromInputXmlFile(string tan, string inputFilesPath, out int rxnCntOut, out string xmlErrorOut)
        {
            int narProcCnt = 0;
            int rxnCount = 0;
            string xmlError = "";
            try
            {
                string fileName = Path.Combine(inputFilesPath, tan + ".xml");

                string[] saTANXmlFile = Directory.GetFiles(inputFilesPath, tan + ".xml", SearchOption.AllDirectories);
                XElement xEle;

                if (saTANXmlFile != null && saTANXmlFile.Length > 0)
                {
                    try
                    {
                        xEle = XElement.Load(saTANXmlFile[0]);
                        rxnCount = xEle.Elements("reactions").Elements("reaction").Count();
                        narProcCnt = xEle.Elements("reactions").Elements("reaction").Elements("procedure").Count();
                    }
                    catch (Exception ex)
                    {
                        xmlError = ex.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            rxnCntOut = rxnCount;
            xmlErrorOut = xmlError;
            return narProcCnt;
        }

        private void dgvProcedureCount_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvProcedureCount.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvProcedureCount.Font);

                if (dgvProcedureCount.RowHeadersWidth < (int)(size.Width + 20)) dgvProcedureCount.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        private void btnExtract_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dtRxnCounts = ExtractCountsFromXmlFiles(txtOutputXmlFilesPath.Text);
                BindCountsDataToGrid(dtRxnCounts);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        
    }
}
