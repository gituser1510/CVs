﻿namespace IndxReactNarr
{
    partial class frmFinalChecks_Supervisor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvQryResults = new System.Windows.Forms.DataGridView();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnExport = new System.Windows.Forms.Button();
            this.grpQueries = new System.Windows.Forms.GroupBox();
            this.rbnMWaveRxns = new System.Windows.Forms.RadioButton();
            this.rbnNoSolvRxns = new System.Windows.Forms.RadioButton();
            this.rbn8000_Name_Loc = new System.Windows.Forms.RadioButton();
            this.rbnTAN_CAN = new System.Windows.Forms.RadioButton();
            this.rbnComments = new System.Windows.Forms.RadioButton();
            this.rbnRxnNUM_Seq = new System.Windows.Forms.RadioButton();
            this.rbnTime_Pressure = new System.Windows.Forms.RadioButton();
            this.rbnTemp_Range = new System.Windows.Forms.RadioButton();
            this.rbnTemp_Direct = new System.Windows.Forms.RadioButton();
            this.rbnZeroPartpnts = new System.Windows.Forms.RadioButton();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.txtBatchNo = new System.Windows.Forms.TextBox();
            this.lblBatchNo = new System.Windows.Forms.Label();
            this.txtBatchName = new System.Windows.Forms.TextBox();
            this.lblBatchName = new System.Windows.Forms.Label();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.dataGridView_AYT_Manager1 = new Keyoti.RapidSpell.Grid.DataGridView_AYT_Manager();
            this.rapidSpellAsYouType1 = new Keyoti.RapidSpell.RapidSpellAsYouType(this.components);
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQryResults)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.grpQueries.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.dgvQryResults);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(977, 521);
            this.pnlMain.TabIndex = 0;
            // 
            // dgvQryResults
            // 
            this.dgvQryResults.AllowUserToAddRows = false;
            this.dgvQryResults.AllowUserToDeleteRows = false;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.dgvQryResults.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvQryResults.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvQryResults.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvQryResults.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgvQryResults.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvQryResults.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvQryResults.Location = new System.Drawing.Point(0, 117);
            this.dgvQryResults.Name = "dgvQryResults";
            this.dgvQryResults.ReadOnly = true;
            this.dgvQryResults.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvQryResults.Size = new System.Drawing.Size(977, 404);
            this.dgvQryResults.TabIndex = 1;
            this.dgvQryResults.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgvQryResults_DataError);
            this.dgvQryResults.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvQryResults_RowPostPaint);
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.btnUpdate);
            this.pnlTop.Controls.Add(this.btnExport);
            this.pnlTop.Controls.Add(this.grpQueries);
            this.pnlTop.Controls.Add(this.btnSubmit);
            this.pnlTop.Controls.Add(this.txtBatchNo);
            this.pnlTop.Controls.Add(this.lblBatchNo);
            this.pnlTop.Controls.Add(this.txtBatchName);
            this.pnlTop.Controls.Add(this.lblBatchName);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(977, 117);
            this.pnlTop.TabIndex = 0;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdate.Location = new System.Drawing.Point(584, 84);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(129, 27);
            this.btnUpdate.TabIndex = 7;
            this.btnUpdate.Text = "Update Comments";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Visible = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnExport
            // 
            this.btnExport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExport.Location = new System.Drawing.Point(446, 84);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(105, 27);
            this.btnExport.TabIndex = 6;
            this.btnExport.Text = "Export Results";
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Visible = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // grpQueries
            // 
            this.grpQueries.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpQueries.Controls.Add(this.rbnMWaveRxns);
            this.grpQueries.Controls.Add(this.rbnNoSolvRxns);
            this.grpQueries.Controls.Add(this.rbn8000_Name_Loc);
            this.grpQueries.Controls.Add(this.rbnTAN_CAN);
            this.grpQueries.Controls.Add(this.rbnComments);
            this.grpQueries.Controls.Add(this.rbnRxnNUM_Seq);
            this.grpQueries.Controls.Add(this.rbnTime_Pressure);
            this.grpQueries.Controls.Add(this.rbnTemp_Range);
            this.grpQueries.Controls.Add(this.rbnTemp_Direct);
            this.grpQueries.Controls.Add(this.rbnZeroPartpnts);
            this.grpQueries.ForeColor = System.Drawing.Color.Blue;
            this.grpQueries.Location = new System.Drawing.Point(3, 3);
            this.grpQueries.Name = "grpQueries";
            this.grpQueries.Size = new System.Drawing.Size(969, 78);
            this.grpQueries.TabIndex = 5;
            this.grpQueries.TabStop = false;
            this.grpQueries.Text = "Select Query";
            // 
            // rbnMWaveRxns
            // 
            this.rbnMWaveRxns.AutoSize = true;
            this.rbnMWaveRxns.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnMWaveRxns.Location = new System.Drawing.Point(775, 24);
            this.rbnMWaveRxns.Name = "rbnMWaveRxns";
            this.rbnMWaveRxns.Size = new System.Drawing.Size(155, 21);
            this.rbnMWaveRxns.TabIndex = 9;
            this.rbnMWaveRxns.Text = "Microwave Reactions";
            this.rbnMWaveRxns.UseVisualStyleBackColor = true;
            this.rbnMWaveRxns.CheckedChanged += new System.EventHandler(this.rbnZeroPartpnts_CheckedChanged);
            // 
            // rbnNoSolvRxns
            // 
            this.rbnNoSolvRxns.AutoSize = true;
            this.rbnNoSolvRxns.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnNoSolvRxns.Location = new System.Drawing.Point(775, 51);
            this.rbnNoSolvRxns.Name = "rbnNoSolvRxns";
            this.rbnNoSolvRxns.Size = new System.Drawing.Size(153, 21);
            this.rbnNoSolvRxns.TabIndex = 8;
            this.rbnNoSolvRxns.Text = "No Solvent Reactions";
            this.rbnNoSolvRxns.UseVisualStyleBackColor = true;
            this.rbnNoSolvRxns.CheckedChanged += new System.EventHandler(this.rbnZeroPartpnts_CheckedChanged);
            // 
            // rbn8000_Name_Loc
            // 
            this.rbn8000_Name_Loc.AutoSize = true;
            this.rbn8000_Name_Loc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbn8000_Name_Loc.Location = new System.Drawing.Point(581, 51);
            this.rbn8000_Name_Loc.Name = "rbn8000_Name_Loc";
            this.rbn8000_Name_Loc.Size = new System.Drawing.Size(167, 21);
            this.rbn8000_Name_Loc.TabIndex = 7;
            this.rbn8000_Name_Loc.Text = "8000 - Name - Location";
            this.rbn8000_Name_Loc.UseVisualStyleBackColor = true;
            this.rbn8000_Name_Loc.CheckedChanged += new System.EventHandler(this.rbnZeroPartpnts_CheckedChanged);
            // 
            // rbnTAN_CAN
            // 
            this.rbnTAN_CAN.AutoSize = true;
            this.rbnTAN_CAN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnTAN_CAN.Location = new System.Drawing.Point(391, 51);
            this.rbnTAN_CAN.Name = "rbnTAN_CAN";
            this.rbnTAN_CAN.Size = new System.Drawing.Size(158, 21);
            this.rbnTAN_CAN.TabIndex = 6;
            this.rbnTAN_CAN.Text = "TAN - CAN - Analyst";
            this.rbnTAN_CAN.UseVisualStyleBackColor = true;
            this.rbnTAN_CAN.CheckedChanged += new System.EventHandler(this.rbnZeroPartpnts_CheckedChanged);
            // 
            // rbnComments
            // 
            this.rbnComments.AutoSize = true;
            this.rbnComments.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnComments.Location = new System.Drawing.Point(170, 51);
            this.rbnComments.Name = "rbnComments";
            this.rbnComments.Size = new System.Drawing.Size(171, 21);
            this.rbnComments.TabIndex = 5;
            this.rbnComments.Text = "8000 - 8500 - Comments";
            this.rbnComments.UseVisualStyleBackColor = true;
            this.rbnComments.CheckedChanged += new System.EventHandler(this.rbnZeroPartpnts_CheckedChanged);
            // 
            // rbnRxnNUM_Seq
            // 
            this.rbnRxnNUM_Seq.AutoSize = true;
            this.rbnRxnNUM_Seq.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnRxnNUM_Seq.Location = new System.Drawing.Point(11, 51);
            this.rbnRxnNUM_Seq.Name = "rbnRxnNUM_Seq";
            this.rbnRxnNUM_Seq.Size = new System.Drawing.Size(131, 21);
            this.rbnRxnNUM_Seq.TabIndex = 4;
            this.rbnRxnNUM_Seq.Text = "RXN NUM - Seq";
            this.rbnRxnNUM_Seq.UseVisualStyleBackColor = true;
            this.rbnRxnNUM_Seq.CheckedChanged += new System.EventHandler(this.rbnZeroPartpnts_CheckedChanged);
            // 
            // rbnTime_Pressure
            // 
            this.rbnTime_Pressure.AutoSize = true;
            this.rbnTime_Pressure.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnTime_Pressure.Location = new System.Drawing.Point(581, 24);
            this.rbnTime_Pressure.Name = "rbnTime_Pressure";
            this.rbnTime_Pressure.Size = new System.Drawing.Size(120, 21);
            this.rbnTime_Pressure.TabIndex = 3;
            this.rbnTime_Pressure.Text = "Time - Pressure";
            this.rbnTime_Pressure.UseVisualStyleBackColor = true;
            this.rbnTime_Pressure.CheckedChanged += new System.EventHandler(this.rbnZeroPartpnts_CheckedChanged);
            // 
            // rbnTemp_Range
            // 
            this.rbnTemp_Range.AutoSize = true;
            this.rbnTemp_Range.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnTemp_Range.Location = new System.Drawing.Point(391, 24);
            this.rbnTemp_Range.Name = "rbnTemp_Range";
            this.rbnTemp_Range.Size = new System.Drawing.Size(152, 21);
            this.rbnTemp_Range.TabIndex = 2;
            this.rbnTemp_Range.Text = "Temperature - Range";
            this.rbnTemp_Range.UseVisualStyleBackColor = true;
            this.rbnTemp_Range.CheckedChanged += new System.EventHandler(this.rbnZeroPartpnts_CheckedChanged);
            // 
            // rbnTemp_Direct
            // 
            this.rbnTemp_Direct.AutoSize = true;
            this.rbnTemp_Direct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnTemp_Direct.Location = new System.Drawing.Point(170, 24);
            this.rbnTemp_Direct.Name = "rbnTemp_Direct";
            this.rbnTemp_Direct.Size = new System.Drawing.Size(178, 21);
            this.rbnTemp_Direct.TabIndex = 1;
            this.rbnTemp_Direct.Text = "Temperature - Directional";
            this.rbnTemp_Direct.UseVisualStyleBackColor = true;
            this.rbnTemp_Direct.CheckedChanged += new System.EventHandler(this.rbnZeroPartpnts_CheckedChanged);
            // 
            // rbnZeroPartpnts
            // 
            this.rbnZeroPartpnts.AutoSize = true;
            this.rbnZeroPartpnts.Checked = true;
            this.rbnZeroPartpnts.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rbnZeroPartpnts.Location = new System.Drawing.Point(11, 24);
            this.rbnZeroPartpnts.Name = "rbnZeroPartpnts";
            this.rbnZeroPartpnts.Size = new System.Drawing.Size(127, 21);
            this.rbnZeroPartpnts.TabIndex = 0;
            this.rbnZeroPartpnts.TabStop = true;
            this.rbnZeroPartpnts.Text = "Zero Participants";
            this.rbnZeroPartpnts.UseVisualStyleBackColor = true;
            this.rbnZeroPartpnts.CheckedChanged += new System.EventHandler(this.rbnZeroPartpnts_CheckedChanged);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSubmit.Location = new System.Drawing.Point(342, 84);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 27);
            this.btnSubmit.TabIndex = 4;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // txtBatchNo
            // 
            this.txtBatchNo.ForeColor = System.Drawing.Color.Blue;
            this.txtBatchNo.Location = new System.Drawing.Point(288, 85);
            this.txtBatchNo.Name = "txtBatchNo";
            this.txtBatchNo.ReadOnly = true;
            this.txtBatchNo.Size = new System.Drawing.Size(40, 25);
            this.txtBatchNo.TabIndex = 3;
            this.txtBatchNo.Text = "1";
            this.txtBatchNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblBatchNo
            // 
            this.lblBatchNo.AutoSize = true;
            this.lblBatchNo.Location = new System.Drawing.Point(218, 89);
            this.lblBatchNo.Name = "lblBatchNo";
            this.lblBatchNo.Size = new System.Drawing.Size(69, 17);
            this.lblBatchNo.TabIndex = 2;
            this.lblBatchNo.Text = "Batch No.";
            // 
            // txtBatchName
            // 
            this.txtBatchName.ForeColor = System.Drawing.Color.Blue;
            this.txtBatchName.Location = new System.Drawing.Point(97, 85);
            this.txtBatchName.Name = "txtBatchName";
            this.txtBatchName.Size = new System.Drawing.Size(105, 25);
            this.txtBatchName.TabIndex = 1;
            this.txtBatchName.Text = "rxnfile.8000";
            // 
            // lblBatchName
            // 
            this.lblBatchName.AutoSize = true;
            this.lblBatchName.Location = new System.Drawing.Point(11, 89);
            this.lblBatchName.Name = "lblBatchName";
            this.lblBatchName.Size = new System.Drawing.Size(83, 17);
            this.lblBatchName.TabIndex = 0;
            this.lblBatchName.Text = "Batch Name";
            // 
            // dataGridView_AYT_Manager1
            // 
            this.dataGridView_AYT_Manager1.DataGridView = this.dgvQryResults;
            this.dataGridView_AYT_Manager1.RapidSpellAsYouType = this.rapidSpellAsYouType1;
            // 
            // rapidSpellAsYouType1
            // 
            this.rapidSpellAsYouType1.AddMenuText = "Add";
            this.rapidSpellAsYouType1.AllowAnyCase = false;
            this.rapidSpellAsYouType1.AllowMixedCase = false;
            this.rapidSpellAsYouType1.AutoCorrectEnabled = true;
            this.rapidSpellAsYouType1.CheckAsYouType = true;
            this.rapidSpellAsYouType1.CheckCompoundWords = false;
            this.rapidSpellAsYouType1.CheckDisabledTextBoxes = false;
            this.rapidSpellAsYouType1.CheckReadOnlyTextBoxes = false;
            this.rapidSpellAsYouType1.ConsiderationRange = 500;
            this.rapidSpellAsYouType1.ContextMenuStripEnabled = true;
            this.rapidSpellAsYouType1.DictFilePath = "";
            this.rapidSpellAsYouType1.FindCapitalizedSuggestions = false;
            this.rapidSpellAsYouType1.GUILanguage = Keyoti.RapidSpell.LanguageType.ENGLISH;
            this.rapidSpellAsYouType1.IgnoreAllMenuText = "Ignore All";
            this.rapidSpellAsYouType1.IgnoreCapitalizedWords = false;
            this.rapidSpellAsYouType1.IgnoreURLsAndEmailAddresses = true;
            this.rapidSpellAsYouType1.IgnoreWordsWithDigits = true;
            this.rapidSpellAsYouType1.IgnoreXML = false;
            this.rapidSpellAsYouType1.IncludeUserDictionaryInSuggestions = true;
            this.rapidSpellAsYouType1.LanguageParser = Keyoti.RapidSpell.LanguageType.ENGLISH;
            this.rapidSpellAsYouType1.LookIntoHyphenatedText = true;
            this.rapidSpellAsYouType1.OptionsEnabled = true;
            this.rapidSpellAsYouType1.OptionsFileName = "RapidSpell_UserSettings.xml";
            this.rapidSpellAsYouType1.OptionsStorageLocation = Keyoti.RapidSpell.Options.UserOptions.StorageType.IsolatedStorage;
            this.rapidSpellAsYouType1.RemoveDuplicateWordText = "Remove duplicate word";
            this.rapidSpellAsYouType1.SeparateHyphenWords = false;
            this.rapidSpellAsYouType1.ShowAddMenuOption = true;
            this.rapidSpellAsYouType1.ShowCutCopyPasteMenuOnTextBoxBase = true;
            this.rapidSpellAsYouType1.ShowSuggestionsContextMenu = true;
            this.rapidSpellAsYouType1.ShowSuggestionsWhenTextIsSelected = false;
            this.rapidSpellAsYouType1.SuggestionsMethod = Keyoti.RapidSpell.SuggestionsMethodType.HashingSuggestions;
            this.rapidSpellAsYouType1.SuggestSplitWords = true;
            this.rapidSpellAsYouType1.TextBoxBase = null;
            this.rapidSpellAsYouType1.TextComponent = null;
            this.rapidSpellAsYouType1.UnderlineColor = System.Drawing.Color.Red;
            this.rapidSpellAsYouType1.UnderlineStyle = Keyoti.RapidSpell.UnderlineStyle.Wavy;
            this.rapidSpellAsYouType1.UpdateAllTextBoxes = true;
            this.rapidSpellAsYouType1.UserDictionaryFile = "";
            this.rapidSpellAsYouType1.V2Parser = true;
            this.rapidSpellAsYouType1.WarnDuplicates = true;
            // 
            // frmFinalChecks_Supervisor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(977, 521);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmFinalChecks_Supervisor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Supervisor - Final Checks";
            this.Load += new System.EventHandler(this.frmFinalChecks_Supervisor_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvQryResults)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.grpQueries.ResumeLayout(false);
            this.grpQueries.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.TextBox txtBatchNo;
        private System.Windows.Forms.Label lblBatchNo;
        private System.Windows.Forms.TextBox txtBatchName;
        private System.Windows.Forms.Label lblBatchName;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.GroupBox grpQueries;
        private System.Windows.Forms.RadioButton rbnZeroPartpnts;
        private System.Windows.Forms.RadioButton rbnTemp_Direct;
        private System.Windows.Forms.RadioButton rbnTemp_Range;
        private System.Windows.Forms.RadioButton rbnRxnNUM_Seq;
        private System.Windows.Forms.RadioButton rbnTime_Pressure;
        private System.Windows.Forms.RadioButton rbnComments;
        private System.Windows.Forms.DataGridView dgvQryResults;
        private System.Windows.Forms.RadioButton rbnTAN_CAN;
        private System.Windows.Forms.RadioButton rbn8000_Name_Loc;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.RadioButton rbnNoSolvRxns;
        private System.Windows.Forms.RadioButton rbnMWaveRxns;
        private Keyoti.RapidSpell.Grid.DataGridView_AYT_Manager dataGridView_AYT_Manager1;
        private Keyoti.RapidSpell.RapidSpellAsYouType rapidSpellAsYouType1;
    }
}