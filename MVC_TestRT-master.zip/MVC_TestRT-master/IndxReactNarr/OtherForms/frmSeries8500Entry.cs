﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using IndxReactNarr.Generic;
using ReadCAS_CGM;

namespace IndxReactNarr
{
    public partial class frmSeries8500Entry : Form
    {
        public frmSeries8500Entry()
        {
            InitializeComponent();
        }

        public DataTable Ser8500_OrgRef { get; set; }

        private string Name_Old = "";
        private void frmSeries8500Entry_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;

                //Get Series 8500 Registry OrgRef Data and bind to grid
                DataTable dtSer8500_OrgRef = CASRxnDataAccess.GetSeries8500OrgRefData();
                if (dtSer8500_OrgRef != null)
                {
                    DataTable dtOrgRef = dtSer8500_OrgRef.Clone();
                    dtOrgRef.Columns["REG_NO"].DataType = System.Type.GetType("System.String");
                    dtOrgRef.Columns["ORGREF_NAME"].DataType = System.Type.GetType("System.String");
                    dtOrgRef.Columns["MOL_FILE"].DataType = System.Type.GetType("System.String");
                    dtOrgRef.Columns["INCHI_KEY"].DataType = System.Type.GetType("System.String");

                    foreach (DataRow dr in dtSer8500_OrgRef.Rows)
                    {
                        dtOrgRef.ImportRow(dr);
                    }
                    Ser8500_OrgRef = dtOrgRef;
                    BindSer8500_OrgRefDataToGrid(dtSer8500_OrgRef);

                    if (dgvSeries8500.Rows.Count > 0)
                    {
                        dgvSeries8500.Rows[0].Selected = true;

                        DataGridViewRow dgvRow = dgvSeries8500.SelectedRows[0];
                        BindSeries8500_OrgRefDataToControls(dgvRow);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindSer8500_OrgRefDataToGrid(DataTable ser8500_orgref)
        {
            try
            {
                if (ser8500_orgref != null)
                {
                    dgvSeries8500.AutoGenerateColumns = false;
                    dgvSeries8500.DataSource = ser8500_orgref;

                    colNrnReg.DataPropertyName = "REG_NO";
                    colName.DataPropertyName = "ORGREF_NAME";
                    colStructure.DataPropertyName = "MOL_FILE";
                    colInchi.DataPropertyName = "INCHI_KEY";                    
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindSeries8500_OrgRefDataToControls(DataGridViewRow gridrow)
        {
            try
            {
                //Clear Control values before assiging new values
                ResetControlValues(this.Controls);

                if (gridrow != null)
                {                    
                    ChemRenditor.MolfileString = gridrow.Cells["colStructure"].Value.ToString();
                    txtNrnReg.Text = gridrow.Cells["colNrnReg"].Value.ToString();
                    txtNrnReg.ReadOnly = true;

                    txtName.Text = gridrow.Cells["colName"].Value.ToString();
                    Name_Old = gridrow.Cells["colName"].Value.ToString(); //Name_Old is to strore existing value for Update purpose 

                    //txtInchi.Text = gridrow.Cells["colInchi"].Value.ToString();           
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void ResetControlValues(Control.ControlCollection cntrlcoll)
        {
            try
            {
                 ChemRenditor.MolfileString = "";
                 Name_Old = "";//Name_Old is to Store Current value for update purpose

                foreach (Control ctrl in cntrlcoll)
                {
                    TextBox tb = ctrl as TextBox;
                    ComboBox cb = ctrl as ComboBox;
                    Button btn = ctrl as Button;
                    if (tb != null)
                    {
                        tb.Clear();
                        if (tb.Name.ToUpper() == "TXTNRNREG")
                        {
                            tb.ReadOnly = false;
                        }
                    }
                    else if (cb != null)
                    {
                        cb.SelectedIndex = -1;
                    }
                    else if (btn != null)
                    {
                        btn.Enabled = true;
                    }
                    else
                    {
                        ResetControlValues(ctrl.Controls);
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvSeries8500_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    if (dgvSeries8500.SelectedRows.Count > 0)
                    {
                        DataGridViewRow dgvRow = dgvSeries8500.SelectedRows[0];

                        BindSeries8500_OrgRefDataToControls(dgvRow);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvSeries8500_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvSeries8500.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvSeries8500.Font);

                if (dgvSeries8500.RowHeadersWidth < (int)(size.Width + 20)) dgvSeries8500.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                //Re-bind Ser8500 OrgRef Data
                BindSer8500_OrgRefDataToGrid(Ser8500_OrgRef);
                
                //Clear All Control Values
                ResetControlValues(this.Controls);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvSeries8500_Sorted(object sender, EventArgs e)
        {
            try
            {
                //De-Select Grid Rows if any
                DeSelectGridRows();

                dgvSeries8500.Rows[0].Selected = true;
                DataGridViewRow dgvRow = dgvSeries8500.SelectedRows[0];
                BindSeries8500_OrgRefDataToControls(dgvRow);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void DeSelectGridRows()
        {
            try
            {
                if (dgvSeries8500.SelectedRows.Count > 0)
                {
                    for (int i = 0; i < dgvSeries8500.SelectedRows.Count; i++)
                    {
                        dgvSeries8500.SelectedRows[i].Selected = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtNrnReg.Text.Trim()))
                {
                    //Validate Registry No CheckSum
                    if (ValidateNrnReg_CheckSUM(Convert.ToInt32(txtNrnReg.Text.Trim())))
                    {
                       DataTable dtSer8500_OrgRef = DAL.CASRxnDataAccess.InsertSer8500_OrgRef(Convert.ToInt32(txtNrnReg.Text.Trim()),Name_Old, txtName.Text.Trim(), ChemRenditor.MolfileString, txtInchi.Text.Trim());
                       if (dtSer8500_OrgRef != null)
                       {
                           DataTable dtOrgRef = dtSer8500_OrgRef.Clone();
                           dtOrgRef.Columns["NRNREG"].DataType = System.Type.GetType("System.String");
                           dtOrgRef.Columns["NAME"].DataType = System.Type.GetType("System.String");
                           dtOrgRef.Columns["STRUCTURE"].DataType = System.Type.GetType("System.String");
                           dtOrgRef.Columns["STRUCT_INCHI"].DataType = System.Type.GetType("System.String");

                           foreach (DataRow dr in dtSer8500_OrgRef.Rows)
                           {
                               dtOrgRef.ImportRow(dr);
                           }
                           Ser8500_OrgRef = dtOrgRef;
                           BindSer8500_OrgRefDataToGrid(dtSer8500_OrgRef);

                           if (dgvSeries8500.Rows.Count > 0)
                           {
                               dgvSeries8500.Rows[0].Selected = true;

                               DataGridViewRow dgvRow = dgvSeries8500.SelectedRows[0];
                               BindSeries8500_OrgRefDataToControls(dgvRow);
                           }
                       }
                    }
                    else
                    {
                        MessageBox.Show(txtNrnReg.Text.Trim() + " is not a valid Reg.Number. CheckSum validation violated", "Add Series 8500 Registry No.", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    #region Code commented
                    //string strError = "";
                    //for (int i = 0; i < dgvSeries8500.Rows.Count; i++)
                    //{

                    //    if (ValidateNrnReg_CheckSUM(Convert.ToInt32(dgvSeries8500.Rows[i].Cells["colNrnReg"].Value.ToString())))
                    //    {

                    //    }
                    //    else
                    //    {
                    //        strError = strError + "\r\n" + dgvSeries8500.Rows[i].Cells["colNrnReg"].Value.ToString();                            
                    //    }
                    //}
                    //if (strError.Trim() != "")
                    //{
                    //    MessageBox.Show(strError);
                    //} 
                    #endregion
                }
                else
                {
                    MessageBox.Show("Please enter Registry Number", "Add Series 8500 Registry No.", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private bool ValidateNrnReg_CheckSUM(int nrnreg)
        {
            bool blStatus = false;
            try
            {
                if (nrnreg > 0)
                {
                    int checkSumDigit = 0;                    
                    string strNrnReg = nrnreg.ToString();
                    checkSumDigit = Convert.ToInt16(strNrnReg[strNrnReg.Length - 1].ToString());

                    char[] caNrnReg = strNrnReg.ToCharArray();
                    if (caNrnReg != null)
                    {
                        if (caNrnReg.Length > 0)
                        {
                            int intSum = 0;
                            int intTemp = caNrnReg.Length - 1;
                            for (int i = 0; i < caNrnReg.Length - 1; i++)
                            {
                                intSum = intSum + (Convert.ToInt32(caNrnReg[i].ToString()) * intTemp);
                                intTemp = intTemp - 1;
                            }
                            int intReminder = 0;
                            Math.DivRem(intSum, 10, out intReminder);

                            if (checkSumDigit == intReminder)
                            {
                                blStatus = true;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return blStatus;
        }

        private void ChemRenditor_StructureChanged(object sender, EventArgs e)
        {
            try
            {
                if (ChemRenditor.MolfileString != null)
                {
                    string strInchi = ReadCAS_CGM.ChemistryOperations.GetStructureInchiKey(ChemRenditor.MolfileString);
                    txtInchi.Text = strInchi;
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       

        private void txtNrnReg_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (txtNrnReg.Text.Trim() != "")
                {
                    DataView dvTemp = Ser8500_OrgRef.Copy().DefaultView;
                    dvTemp.RowFilter = "NRNREG Like '" + txtNrnReg.Text.Trim() + "%' ";
                    DataTable dtSer8500_OrgRef = dvTemp.ToTable();
                    if (dtSer8500_OrgRef != null)
                    {
                        BindSer8500_OrgRefDataToGrid(dtSer8500_OrgRef);
                    }
                }
                else
                {
                    BindSer8500_OrgRefDataToGrid(Ser8500_OrgRef);
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
