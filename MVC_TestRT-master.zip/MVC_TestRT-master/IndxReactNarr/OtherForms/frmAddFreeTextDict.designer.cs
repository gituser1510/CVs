﻿namespace IndxReactNarr
{
    partial class frmAddFreeTextDict
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvRSNFree = new System.Windows.Forms.DataGridView();
            this.colDTK_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFreetext = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdit = new System.Windows.Forms.DataGridViewLinkColumn();
            this.colDelete = new System.Windows.Forms.DataGridViewLinkColumn();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.btnReset = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtFreeText = new System.Windows.Forms.TextBox();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRSNFree)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.dgvRSNFree);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(990, 547);
            this.pnlMain.TabIndex = 0;
            // 
            // dgvRSNFree
            // 
            this.dgvRSNFree.AllowUserToAddRows = false;
            this.dgvRSNFree.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvRSNFree.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvRSNFree.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRSNFree.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colDTK_ID,
            this.colFreetext,
            this.colEdit,
            this.colDelete});
            this.dgvRSNFree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvRSNFree.Location = new System.Drawing.Point(0, 41);
            this.dgvRSNFree.Name = "dgvRSNFree";
            this.dgvRSNFree.ReadOnly = true;
            this.dgvRSNFree.Size = new System.Drawing.Size(990, 506);
            this.dgvRSNFree.TabIndex = 4;
            this.dgvRSNFree.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRSNFree_CellContentClick);
            this.dgvRSNFree.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvRSNFree_RowPostPaint);
            // 
            // colDTK_ID
            // 
            this.colDTK_ID.HeaderText = "DTKID";
            this.colDTK_ID.Name = "colDTK_ID";
            this.colDTK_ID.ReadOnly = true;
            this.colDTK_ID.Visible = false;
            // 
            // colFreetext
            // 
            this.colFreetext.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colFreetext.HeaderText = "Free Text";
            this.colFreetext.Name = "colFreetext";
            this.colFreetext.ReadOnly = true;
            // 
            // colEdit
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colEdit.DefaultCellStyle = dataGridViewCellStyle2;
            this.colEdit.HeaderText = "Edit";
            this.colEdit.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.colEdit.Name = "colEdit";
            this.colEdit.ReadOnly = true;
            this.colEdit.Text = "Edit";
            this.colEdit.UseColumnTextForLinkValue = true;
            // 
            // colDelete
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colDelete.DefaultCellStyle = dataGridViewCellStyle3;
            this.colDelete.HeaderText = "Delete";
            this.colDelete.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.colDelete.Name = "colDelete";
            this.colDelete.ReadOnly = true;
            this.colDelete.Text = "Delete";
            this.colDelete.UseColumnTextForLinkValue = true;
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.White;
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlTop.Controls.Add(this.btnReset);
            this.pnlTop.Controls.Add(this.label1);
            this.pnlTop.Controls.Add(this.btnSave);
            this.pnlTop.Controls.Add(this.txtFreeText);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(990, 41);
            this.pnlTop.TabIndex = 3;
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(908, 4);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 30);
            this.btnReset.TabIndex = 3;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "FreeText";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(818, 4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 30);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtFreeText
            // 
            this.txtFreeText.Location = new System.Drawing.Point(70, 7);
            this.txtFreeText.Name = "txtFreeText";
            this.txtFreeText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtFreeText.Size = new System.Drawing.Size(742, 25);
            this.txtFreeText.TabIndex = 1;
            // 
            // frmAddFreeTextDict
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(990, 547);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmAddFreeTextDict";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Add FreeText to Dictionary";
            this.Load += new System.EventHandler(this.frmAddFreeTextDict_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRSNFree)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtFreeText;
        private System.Windows.Forms.DataGridView dgvRSNFree;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDTK_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFreetext;
        private System.Windows.Forms.DataGridViewLinkColumn colEdit;
        private System.Windows.Forms.DataGridViewLinkColumn colDelete;
    }
}