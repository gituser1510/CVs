﻿namespace IndxReactNarr.OtherForms
{
    partial class frmXmlUnicodesValidation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.tcXmlValidation = new System.Windows.Forms.TabControl();
            this.tpComments = new System.Windows.Forms.TabPage();
            this.dgvComments = new System.Windows.Forms.DataGridView();
            this.tpRSN = new System.Windows.Forms.TabPage();
            this.tpSer8000 = new System.Windows.Forms.TabPage();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.btnExport = new System.Windows.Forms.Button();
            this.btnBrowseXML = new System.Windows.Forms.Button();
            this.txtXmlFile = new System.Windows.Forms.TextBox();
            this.lblBrowseXml = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.dgvRSN = new System.Windows.Forms.DataGridView();
            this.dgvSer8000 = new System.Windows.Forms.DataGridView();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.lblXmlStatus = new System.Windows.Forms.Label();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTAN_Cmnts = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colValidStatus_C = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colComments = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTAN_R = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnSeq = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRSN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRSN_Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTAN_S8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSer8000_s8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnNum_S8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRxnSeq_S8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSubstName_S8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain.SuspendLayout();
            this.tcXmlValidation.SuspendLayout();
            this.tpComments.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvComments)).BeginInit();
            this.tpRSN.SuspendLayout();
            this.tpSer8000.SuspendLayout();
            this.pnlTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRSN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSer8000)).BeginInit();
            this.pnlBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.tcXmlValidation);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1103, 487);
            this.pnlMain.TabIndex = 0;
            // 
            // tcXmlValidation
            // 
            this.tcXmlValidation.Controls.Add(this.tpComments);
            this.tcXmlValidation.Controls.Add(this.tpRSN);
            this.tcXmlValidation.Controls.Add(this.tpSer8000);
            this.tcXmlValidation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcXmlValidation.Location = new System.Drawing.Point(0, 34);
            this.tcXmlValidation.Name = "tcXmlValidation";
            this.tcXmlValidation.SelectedIndex = 0;
            this.tcXmlValidation.Size = new System.Drawing.Size(1103, 422);
            this.tcXmlValidation.TabIndex = 2;
            // 
            // tpComments
            // 
            this.tpComments.Controls.Add(this.dgvComments);
            this.tpComments.Location = new System.Drawing.Point(4, 26);
            this.tpComments.Name = "tpComments";
            this.tpComments.Padding = new System.Windows.Forms.Padding(3);
            this.tpComments.Size = new System.Drawing.Size(1095, 392);
            this.tpComments.TabIndex = 0;
            this.tpComments.Text = "Comments";
            this.tpComments.UseVisualStyleBackColor = true;
            // 
            // dgvComments
            // 
            this.dgvComments.AllowUserToAddRows = false;
            this.dgvComments.AllowUserToDeleteRows = false;
            this.dgvComments.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvComments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvComments.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTAN_Cmnts,
            this.colValidStatus_C,
            this.colComments});
            this.dgvComments.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvComments.Location = new System.Drawing.Point(3, 3);
            this.dgvComments.Name = "dgvComments";
            this.dgvComments.ReadOnly = true;
            this.dgvComments.Size = new System.Drawing.Size(1089, 386);
            this.dgvComments.TabIndex = 0;
            this.dgvComments.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvComments_RowPostPaint);
            // 
            // tpRSN
            // 
            this.tpRSN.Controls.Add(this.dgvRSN);
            this.tpRSN.Location = new System.Drawing.Point(4, 26);
            this.tpRSN.Name = "tpRSN";
            this.tpRSN.Padding = new System.Windows.Forms.Padding(3);
            this.tpRSN.Size = new System.Drawing.Size(1095, 392);
            this.tpRSN.TabIndex = 1;
            this.tpRSN.Text = "RSN";
            this.tpRSN.UseVisualStyleBackColor = true;
            // 
            // tpSer8000
            // 
            this.tpSer8000.Controls.Add(this.dgvSer8000);
            this.tpSer8000.Location = new System.Drawing.Point(4, 26);
            this.tpSer8000.Name = "tpSer8000";
            this.tpSer8000.Padding = new System.Windows.Forms.Padding(3);
            this.tpSer8000.Size = new System.Drawing.Size(1095, 392);
            this.tpSer8000.TabIndex = 2;
            this.tpSer8000.Text = "Series 8000";
            this.tpSer8000.UseVisualStyleBackColor = true;
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.btnExport);
            this.pnlTop.Controls.Add(this.btnBrowseXML);
            this.pnlTop.Controls.Add(this.txtXmlFile);
            this.pnlTop.Controls.Add(this.lblBrowseXml);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1103, 34);
            this.pnlTop.TabIndex = 1;
            // 
            // btnExport
            // 
            this.btnExport.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExport.Location = new System.Drawing.Point(842, 3);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(68, 27);
            this.btnExport.TabIndex = 6;
            this.btnExport.Text = "Export";
            this.btnExport.UseVisualStyleBackColor = true;
            // 
            // btnBrowseXML
            // 
            this.btnBrowseXML.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowseXML.Location = new System.Drawing.Point(781, 3);
            this.btnBrowseXML.Name = "btnBrowseXML";
            this.btnBrowseXML.Size = new System.Drawing.Size(35, 27);
            this.btnBrowseXML.TabIndex = 5;
            this.btnBrowseXML.Text = "...";
            this.btnBrowseXML.UseVisualStyleBackColor = true;
            this.btnBrowseXML.Click += new System.EventHandler(this.btnBrowseXML_Click);
            // 
            // txtXmlFile
            // 
            this.txtXmlFile.BackColor = System.Drawing.Color.White;
            this.txtXmlFile.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtXmlFile.Location = new System.Drawing.Point(98, 4);
            this.txtXmlFile.Name = "txtXmlFile";
            this.txtXmlFile.ReadOnly = true;
            this.txtXmlFile.Size = new System.Drawing.Size(677, 25);
            this.txtXmlFile.TabIndex = 4;
            // 
            // lblBrowseXml
            // 
            this.lblBrowseXml.AutoSize = true;
            this.lblBrowseXml.BackColor = System.Drawing.Color.White;
            this.lblBrowseXml.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBrowseXml.Location = new System.Drawing.Point(3, 8);
            this.lblBrowseXml.Name = "lblBrowseXml";
            this.lblBrowseXml.Size = new System.Drawing.Size(90, 17);
            this.lblBrowseXml.TabIndex = 3;
            this.lblBrowseXml.Text = "Browse XML";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // dgvRSN
            // 
            this.dgvRSN.AllowUserToAddRows = false;
            this.dgvRSN.AllowUserToDeleteRows = false;
            this.dgvRSN.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvRSN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRSN.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTAN_R,
            this.colRxnNo,
            this.colRxnSeq,
            this.colRSN,
            this.colRSN_Type});
            this.dgvRSN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvRSN.Location = new System.Drawing.Point(3, 3);
            this.dgvRSN.Name = "dgvRSN";
            this.dgvRSN.ReadOnly = true;
            this.dgvRSN.Size = new System.Drawing.Size(1089, 386);
            this.dgvRSN.TabIndex = 1;
            this.dgvRSN.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvRSN_RowPostPaint);
            // 
            // dgvSer8000
            // 
            this.dgvSer8000.AllowUserToAddRows = false;
            this.dgvSer8000.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.SeaShell;
            this.dgvSer8000.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSer8000.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvSer8000.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSer8000.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTAN_S8,
            this.colSer8000_s8,
            this.colRxnNum_S8,
            this.colRxnSeq_S8,
            this.colSubstName_S8});
            this.dgvSer8000.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSer8000.Location = new System.Drawing.Point(3, 3);
            this.dgvSer8000.Name = "dgvSer8000";
            this.dgvSer8000.ReadOnly = true;
            this.dgvSer8000.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSer8000.Size = new System.Drawing.Size(1089, 386);
            this.dgvSer8000.TabIndex = 1;
            this.dgvSer8000.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvSer8000_RowPostPaint);
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom.Controls.Add(this.lblXmlStatus);
            this.pnlBottom.Controls.Add(this.label1);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 456);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(1103, 31);
            this.pnlBottom.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Xml Status: ";
            // 
            // lblXmlStatus
            // 
            this.lblXmlStatus.AutoSize = true;
            this.lblXmlStatus.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblXmlStatus.ForeColor = System.Drawing.Color.Blue;
            this.lblXmlStatus.Location = new System.Drawing.Point(91, 6);
            this.lblXmlStatus.Name = "lblXmlStatus";
            this.lblXmlStatus.Size = new System.Drawing.Size(18, 17);
            this.lblXmlStatus.TabIndex = 1;
            this.lblXmlStatus.Text = "--";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn1.HeaderText = "TAN";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.HeaderText = "Comments";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn3.HeaderText = "TAN";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "RxnNo";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "RxnSeq";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn6.HeaderText = "FreeText";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn7.HeaderText = "TAN";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "Series8000";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn9.HeaderText = "SubstanceName";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn10.HeaderText = "SubstanceName";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "RxnSeq";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn12.HeaderText = "SubstanceName";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn13.HeaderText = "SubstanceName";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            // 
            // colTAN_Cmnts
            // 
            this.colTAN_Cmnts.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colTAN_Cmnts.HeaderText = "TAN";
            this.colTAN_Cmnts.Name = "colTAN_Cmnts";
            this.colTAN_Cmnts.ReadOnly = true;
            // 
            // colValidStatus_C
            // 
            this.colValidStatus_C.HeaderText = "Status";
            this.colValidStatus_C.Name = "colValidStatus_C";
            this.colValidStatus_C.ReadOnly = true;
            // 
            // colComments
            // 
            this.colComments.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colComments.HeaderText = "Comments";
            this.colComments.Name = "colComments";
            this.colComments.ReadOnly = true;
            // 
            // colTAN_R
            // 
            this.colTAN_R.HeaderText = "TAN";
            this.colTAN_R.Name = "colTAN_R";
            this.colTAN_R.ReadOnly = true;
            // 
            // colRxnNo
            // 
            this.colRxnNo.HeaderText = "RxnNo";
            this.colRxnNo.Name = "colRxnNo";
            this.colRxnNo.ReadOnly = true;
            // 
            // colRxnSeq
            // 
            this.colRxnSeq.HeaderText = "RxnSeq";
            this.colRxnSeq.Name = "colRxnSeq";
            this.colRxnSeq.ReadOnly = true;
            // 
            // colRSN
            // 
            this.colRSN.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colRSN.HeaderText = "RSN_Stage";
            this.colRSN.Name = "colRSN";
            this.colRSN.ReadOnly = true;
            // 
            // colRSN_Type
            // 
            this.colRSN_Type.HeaderText = "RSN_Reaction";
            this.colRSN_Type.Name = "colRSN_Type";
            this.colRSN_Type.ReadOnly = true;
            // 
            // colTAN_S8
            // 
            this.colTAN_S8.HeaderText = "TAN";
            this.colTAN_S8.Name = "colTAN_S8";
            this.colTAN_S8.ReadOnly = true;
            // 
            // colSer8000_s8
            // 
            this.colSer8000_s8.HeaderText = "Series8000";
            this.colSer8000_s8.Name = "colSer8000_s8";
            this.colSer8000_s8.ReadOnly = true;
            // 
            // colRxnNum_S8
            // 
            this.colRxnNum_S8.HeaderText = "RxnNUM";
            this.colRxnNum_S8.Name = "colRxnNum_S8";
            this.colRxnNum_S8.ReadOnly = true;
            // 
            // colRxnSeq_S8
            // 
            this.colRxnSeq_S8.HeaderText = "RxnSeq";
            this.colRxnSeq_S8.Name = "colRxnSeq_S8";
            this.colRxnSeq_S8.ReadOnly = true;
            // 
            // colSubstName_S8
            // 
            this.colSubstName_S8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colSubstName_S8.HeaderText = "SubstanceName";
            this.colSubstName_S8.Name = "colSubstName_S8";
            this.colSubstName_S8.ReadOnly = true;
            // 
            // frmXmlUnicodesValidation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1103, 487);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmXmlUnicodesValidation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Xml Unicodes Validation";
            this.Load += new System.EventHandler(this.frmXmlUnicodesValidation_Load);
            this.pnlMain.ResumeLayout(false);
            this.tcXmlValidation.ResumeLayout(false);
            this.tpComments.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvComments)).EndInit();
            this.tpRSN.ResumeLayout(false);
            this.tpSer8000.ResumeLayout(false);
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRSN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSer8000)).EndInit();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.Button btnBrowseXML;
        private System.Windows.Forms.TextBox txtXmlFile;
        private System.Windows.Forms.Label lblBrowseXml;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TabControl tcXmlValidation;
        private System.Windows.Forms.TabPage tpComments;
        private System.Windows.Forms.TabPage tpRSN;
        private System.Windows.Forms.TabPage tpSer8000;
        private System.Windows.Forms.DataGridView dgvComments;
        private System.Windows.Forms.DataGridView dgvRSN;
        private System.Windows.Forms.DataGridView dgvSer8000;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTAN_Cmnts;
        private System.Windows.Forms.DataGridViewTextBoxColumn colValidStatus_C;
        private System.Windows.Forms.DataGridViewTextBoxColumn colComments;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTAN_S8;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSer8000_s8;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnNum_S8;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnSeq_S8;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSubstName_S8;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Label lblXmlStatus;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTAN_R;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRxnSeq;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRSN;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRSN_Type;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
    }
}