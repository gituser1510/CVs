﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using System.Xml.Linq;

namespace IndxReactNarr
{
    public partial class frmValidateRSD : Form
    {
        public frmValidateRSD()
        {
            InitializeComponent();
        }

        private void ValidateRSD_StagesData(string _batchxmlpath)
        {
            try
            {
                if (_batchxmlpath.Trim() != "")
                {
                    //Read Batch xml Data to Dataset
                    DataSet dsBXmlData = new DataSet();
                    dsBXmlData.ReadXml(_batchxmlpath);

                    if (dsBXmlData != null)
                    {
                        if (dsBXmlData.Tables.Count > 0)
                        {
                            if (dsBXmlData.Tables["DOCUMENT"] != null)
                            {
                                DataTable dtRSN_Stage = CreateRSNDataTable();

                                string strTAN = "";
                                int intRxnNo = 0;
                                int intRxnID = 0;

                                int rxnProcID = 0;
                                int intStageCnt = 0;

                                int intProdNum = 0;
                                int intProdSeq = 0;

                                DataTable dtRxnProcess = null;                                                
                                DataTable dtSTAGE = null;
                                DataTable dtRXNID = null;

                                dtRxnProcess = dsBXmlData.Tables["RXNProcess"].Copy();
                                dtSTAGE = dsBXmlData.Tables["Stage"].Copy();
                                dtRXNID = dsBXmlData.Tables["RXNID"].Copy(); 
                               
                                for (int i = 0; i < dsBXmlData.Tables["DOCUMENT"].Rows.Count; i++)
                                {
                                    var docQry = (from r in dsBXmlData.Tables["RXNGRP"].AsEnumerable()
                                                  where r.Field<Int32>("DOCUMENT_Id") == Convert.ToInt32(dsBXmlData.Tables["DOCUMENT"].Rows[i]["DOCUMENT_Id"].ToString())
                                                  select r.Field<Int32>("RXNGRP_ID")).Distinct();

                                    foreach (int rxngrpid in docQry)
                                    {
                                        var rxnQry = (from r in dsBXmlData.Tables["RXN"].AsEnumerable()
                                                      where r.Field<Int32>("RXNGRP_ID") == rxngrpid
                                                      select r.Field<string>("RSD")).Distinct();

                                        DataView dvTemp = dsBXmlData.Tables["RXN"].Copy().DefaultView;
                                        dvTemp.RowFilter = "RXNGRP_ID = " + rxngrpid;
                                        DataTable dtRxn = dvTemp.ToTable();                                        

                                        if(dtRxn != null)
                                        {
                                            if (dtRxn.Rows.Count > 0)
                                            {
                                                DataRow dRow = null;                                               

                                                for (int rIndx = 0; rIndx < dtRxn.Rows.Count; rIndx++)
                                                {
                                                    intRxnID = Convert.ToInt32(dtRxn.Rows[rIndx]["Rxn_Id"].ToString());
                                                    
                                                    rxnProcID = GetRxnProcessIDOnRxnID(dtRxnProcess, intRxnID);

                                                    intStageCnt = GetStageCountOnRxnProcessID(dtSTAGE, rxnProcID);

                                                    intProdNum = GetProductNUM_SeqOnRxnID(dtRXNID, intRxnID, out intProdSeq);

                                                    strTAN = dsBXmlData.Tables["DOCUMENT"].Rows[i]["tan"].ToString();
                                                    intRxnNo = Convert.ToInt32(dtRxn.Rows[rIndx]["no"].ToString());

                                                    dRow = dtRSN_Stage.NewRow();
                                                    dRow["RXNNO"] = intRxnNo;
                                                    dRow["TAN"] = strTAN;
                                                    dRow["ProdNUM"] = intProdNum;
                                                    dRow["Seq"] = intProdSeq;
                                                    dRow["RSD"] = dtRxn.Rows[rIndx]["rsd"].ToString();
                                                    dRow["Length"] = dtRxn.Rows[rIndx]["rsd"].ToString().Length.ToString();
                                                    dRow["Semicolons"] = dtRxn.Rows[rIndx]["rsd"].ToString().Count(f => f == ';').ToString();
                                                    dRow["Stages"] = intStageCnt;
                                                    
                                                    dtRSN_Stage.Rows.Add(dRow);
                                                }
                                            }
                                        }
                                        #region Code Commented
                                        //DataRow dRow = null;
                                        //foreach (string rsd in rxnQry)
                                        //{
                                        //    dRow = dtRSN_Stage.NewRow();
                                        //    dRow["tan"] = dsBXmlData.Tables["DOCUMENT"].Rows[i]["tan"].ToString();
                                        //    dRow["rsd"] = rsd;
                                        //    dRow["CommaCount"] = rsd.Count(f => f == ';').ToString();
                                        //    dtRSN_Stage.Rows.Add(dRow);

                                        //    //var xrefGrpQry = (from r in dsBXmlData.Tables["XREFGRP"].AsEnumerable()
                                        //    //                  where r.Field<Int32>("RXN_Id") == rxnid
                                        //    //                  select r.Field<Int32>("XREFGRP_Id")).Distinct();
                                        //}

                                        //foreach (int rxnid in rxnQry)
                                        //{
                                        //    var xrefGrpQry = (from r in dsBXmlData.Tables["XREFGRP"].AsEnumerable()
                                        //                      where r.Field<Int32>("RXN_Id") == rxnid
                                        //                      select r.Field<Int32>("XREFGRP_Id")).Distinct();

                                        //    foreach (int xrefgrpid in xrefGrpQry)
                                        //    {
                                        //        //var nrnQry = (from r in dsBXmlData.Tables["NRN"].AsEnumerable()
                                        //        //              where r.Field<Int32>("XREFGRP_Id") == xrefgrpid
                                        //        //              select new { a = r.Field<string>("NRNNUM"), b = r.Field<string>("NRNREG") });

                                        //        DataView dtView = dsBXmlData.Tables["NRN"].DefaultView;
                                        //        dtView.RowFilter = "NRNNUM > 8999 and XREFGRP_Id = " + xrefgrpid;

                                        //        DataTable dtSer9000 = dtView.ToTable();

                                        //        if (dtSer9000 != null)
                                        //        {
                                        //            if (dtSer9000.Rows.Count > 0)
                                        //            {
                                        //                for (int k = 0; k < dtSer9000.Rows.Count; k++)
                                        //                {
                                        //                    DataView dtViewNrn = dtSer9000.DefaultView;
                                        //                    dtViewNrn.RowFilter = "NRNNUM = " + dtSer9000.Rows[k]["NRNNUM"];

                                        //                    DataTable dtSer9000Vals = dtViewNrn.ToTable();

                                        //                    if (dtSer9000Vals != null)
                                        //                    {
                                        //                        if (dtSer9000Vals.Rows.Count > 0)
                                        //                        {
                                        //                            string strNrnReg = "";
                                        //                            for (int m = 0; m < dtSer9000Vals.Rows.Count; m++)
                                        //                            {
                                        //                                intID = intID + 1;

                                        //                                DataRow dtRow9000 = dtSer9000Data.NewRow();
                                        //                                dtRow9000["ID"] = intID.ToString();
                                        //                                dtRow9000["TAN"] = dsBXmlData.Tables["DOCUMENT"].Rows[i]["TAN"].ToString();
                                        //                                dtRow9000["RXNNUM"] = null;//GetRXNNUM_On_RXNID(rxnid);
                                        //                                //dtRow9000["NRNNUM"] = dtSer9000Vals.Rows[m]["NRNNUM"].ToString();

                                        //                                if (strNrnReg == "")
                                        //                                {
                                        //                                    strNrnReg = dtSer9000Vals.Rows[m]["NRNREG"].ToString();
                                        //                                }
                                        //                                else
                                        //                                {
                                        //                                    strNrnReg = strNrnReg + "," + dtSer9000Vals.Rows[m]["NRNREG"].ToString();
                                        //                                }
                                        //                                dtRow9000["NRNREG"] = strNrnReg;
                                        //                                dtSer9000Data.Rows.Add(dtRow9000);                                                                        
                                        //                            }
                                        //                        }
                                        //                    }
                                        //                }
                                        //            }
                                        //        }
                                        //    }
                                        //} 
                                        #endregion
                                    }
                                }                               

                                //Bind Data to Errors grid
                                BindDataToGrid(dtRSN_Stage);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private int GetProductNUM_SeqOnRxnID(DataTable _rxnidtbl, int _rxnid,out int _prodseq)
        {
            int intProdNum = 0;
            int intProdSeq = 0;
            try
            {
                if (_rxnidtbl != null)
                {
                    if (_rxnidtbl.Rows.Count > 0)
                    {
                        DataRow[] drArr = _rxnidtbl.Select("Rxn_ID = " + _rxnid);
                        if (drArr != null)
                        {
                            if (drArr.Length > 0)
                            {
                                intProdNum = Convert.ToInt32(drArr[0]["RXNNUM"]);
                                intProdSeq = Convert.ToInt32(drArr[0]["RXNSEQ"]);                               
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            _prodseq = intProdSeq;
            return intProdNum;
        }

        private int GetRxnProcessIDOnRxnID(DataTable _rxnprocesstbl, int _rxnid)
        {
            int intRxnProcID = 0;
            try
            {
                if (_rxnprocesstbl != null)
                {
                    if (_rxnprocesstbl.Rows.Count > 0)
                    {
                        DataRow[] drArr = _rxnprocesstbl.Select("Rxn_ID = " + _rxnid);
                        if (drArr != null)
                        {
                            if (drArr.Length > 0)
                            {
                                intRxnProcID = Convert.ToInt32(drArr[0]["RxnProcess_Id"]);
                                return intRxnProcID;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return intRxnProcID;
        }

        private int GetStageCountOnRxnProcessID(DataTable _stagetbl, int _rxnprocessid)
        {
            int intStageCnt = 0;
            try
            {
                if (_stagetbl != null)
                {
                    if (_stagetbl.Rows.Count > 0)
                    {
                        DataRow[] drArr = _stagetbl.Select("RxnProcess_ID = " + _rxnprocessid);
                        if (drArr != null)
                        {
                            if (drArr.Length > 0)
                            {
                                intStageCnt = drArr.Length;
                                return intStageCnt;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return intStageCnt;
        }

        private DataTable CreateRSNDataTable()
        {
            try
            {
                DataTable dtRSNData = new DataTable();
                dtRSNData.Columns.Add("TAN", typeof(string));
                dtRSNData.Columns.Add("RXNNO", typeof(string));
                dtRSNData.Columns.Add("ProdNUM", typeof(string));
                dtRSNData.Columns.Add("Seq", typeof(string));
                dtRSNData.Columns.Add("RSD", typeof(string));
                dtRSNData.Columns.Add("Length", typeof(Int32));
                dtRSNData.Columns.Add("Semicolons", typeof(Int32));
                dtRSNData.Columns.Add("Stages", typeof(Int32));
                return dtRSNData;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return null;
        }

        private int GetStageTagCount(string _xmlpath,string _tan, int _rxnno)
        {
            try
            {
                if (_xmlpath.Trim() != "")
                {
                    XDocument xdoc = XDocument.Load(_xmlpath);

                    #region MyRegion
                    //var qry = from xele in xdoc.Element("RXNFILE").Descendants("DOCUMENT").Descendants()
                    //          where (string)xele.Element("TAN").Value == _tan
                    //          select xele;

                    //var query = from p in xdoc.Elements("RXNFILE").Elements("DOCUMENT")
                    //            where (string)p.Element("TAN").Value == _tan
                    //            select p;

                    //var q = from c in xdoc.Elements("RXNFILE").Descendants("DOCUMENT")
                    //        where (string)c.Element("TAN").Value == _tan
                    //        select c;

                    //var qr = from c in xdoc.Descendants().Elements("DOCUMENT").Descendants()
                    //         where c.Element("TAN").Value == _tan
                    //         select (XElement)c.Element("RXN"); 
                    #endregion

                    //xdoc.Descendants().Descendants().ElementAt(3).Elements().ElementAt(2).Value

                    #region MyRegion
                    //List<Reaction> questions = (from xele in xdoc.Descendants()
                    //                            where xele.Descendants().ElementAt(3).Elements().ElementAt(2).Value == "22429626Z"//_tan
                    //                            select new Reaction
                    //                                 {
                    //                                     stages =
                    //                                         (from reaction in
                    //                                              xdoc.Element("RXNFILE").Elements("DOCUMENT")
                    //                                          where reaction.Elements("RXN").Attributes("ID").ElementAt(0).Value == _rxnno.ToString()                                                             
                    //                                          select new STAGE()
                    //                                          {
                    //                                              content = (XElement)reaction.Elements("RXNPROCESS").Elements("STAGE")
                    //                                          }

                    //                                         ).ToList()
                    //                                 }
                    //                            ).ToList(); 
                    #endregion

                   

                   //List<Reaction> rxnstages = (from xele in xdoc.Descendants().Descendants().ElementAt(3).Elements()
                   //                             where xdoc.Descendants().Descendants().ElementAt(3).Elements().ElementAt(2).Value == _tan
                                                
                   //                             select new Reaction
                   //                             {
                   //                                 stages =
                   //                                     (from rxngrp in xele.Descendants("RXNGRP")
                   //                                      where (string)rxngrp.Elements("RXN").Attributes("ID").ElementAt(0).Value == _rxnno.ToString()
                   //                                      select new STAGE()
                   //                                      {
                   //                                          content = (XElement)rxngrp.Elements("RXNPROCESS").Descendants()
                   //                                      }

                   //                                     ).ToList()
                   //                             }
                   //                               ).ToList();

                    //var qryElement = (from xele in xdoc.Descendants().Descendants()
                    //                  where xdoc.Descendants().Descendants().ElementAt(3).Elements().ElementAt(2).Value == _tan
                    //                  select xele);

                    var qryElement = (from xele in xdoc.Descendants().Descendants().ElementAt(3).Elements()
                                      where xdoc.Descendants().Descendants().ElementAt(3).Elements().ElementAt(2).Value == _tan
                                      select xele.Parent);

                     //qryElement.Descendants().ElementAt(0).Attributes("NO").ElementAt(0).Value

                     //var qry = (from rxngrp in qryElement
                     //           where (string)qryElement.Descendants().ElementAt(0).Attributes("NO").ElementAt(0).Value == _rxnno.ToString()
                     //          select rxngrp.Descendants("RXNPROCESS").Elements("STAGE")).ToList();


                   // if (qry != null)
                   //{
                   //    return qry.Count;
                   //}
 
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return 0;
        }

        private void BindDataToGrid(DataTable _resulttbl)
        {
            try
            {
                if (_resulttbl != null)
                {
                    dgvRSD_Stage.DataSource = _resulttbl;

                    //dgvRSD_Stage.Columns["TAN"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                    dgvRSD_Stage.Columns["TAN"].Width = 80;
                    //dgvRSD_Stage.Columns["RXNNO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                    dgvRSD_Stage.Columns["RXNNO"].Width = 55;
                    //dgvRSD_Stage.Columns["ProdNUM"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                    dgvRSD_Stage.Columns["ProdNUM"].Width = 65;
                    //dgvRSD_Stage.Columns["Seq"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                    dgvRSD_Stage.Columns["Seq"].Width = 30;                  
                    //dgvRSD_Stage.Columns["RSD"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    dgvRSD_Stage.Columns["RSD"].Width = 570;
                    //dgvRSD_Stage.Columns["Length"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                    dgvRSD_Stage.Columns["Length"].Width = 45;
                    //dgvRSD_Stage.Columns["CommaCount"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                    dgvRSD_Stage.Columns["Semicolons"].Width = 55;
                    //dgvRSD_Stage.Columns["STAGECount"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                    dgvRSD_Stage.Columns["Stages"].Width = 55;

                    object objRSDCnt = _resulttbl.Compute("count(RSD)", "");
                    lblRSDCnt.Text = objRSDCnt.ToString();

                    object objSCCnt = _resulttbl.Compute("sum(Semicolons)", "");
                   lblSColonCnt.Text = objSCCnt.ToString();

                   object objStgCnt = _resulttbl.Compute("sum(Stages)", "");
                   lblStgCnt.Text = objStgCnt.ToString();

                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
               
        private void btnBrowseXML_Click(object sender, EventArgs e)
        {
            try
            {              
                OpenXmlFile();

                Cursor = Cursors.WaitCursor;

                ValidateRSD_StagesData(txtXmlFile.Text.Trim());

                Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void OpenXmlFile()
        {
            try
            {
                openFileDialog1.Filter = "XML Files (*.xml)|*.xml|Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
                openFileDialog1.FilterIndex = 1;
                openFileDialog1.Title = "Select a file to open";
                openFileDialog1.FileName = "";
                openFileDialog1.ShowDialog();

                if (openFileDialog1.FileName != "")
                {
                    string xmlFileName = openFileDialog1.FileName;
                    txtXmlFile.Text = xmlFileName.Trim();           
                }               
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void frmValidateRSD_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvRSD_Stage_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvRSD_Stage.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvRSD_Stage.Font);

                if (dgvRSD_Stage.RowHeadersWidth < (int)(size.Width + 20)) dgvRSD_Stage.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dtResults = (DataTable)dgvRSD_Stage.DataSource;

                if (dtResults != null)
                {
                    if (dtResults.Rows.Count > 0)
                    {
                        SaveFileDialog objSDialog = new SaveFileDialog();
                        objSDialog.Filter = "XlS|*.xls";
                        if (objSDialog.ShowDialog() == DialogResult.OK)
                        {
                            if (Common.Export.Excel_FromDataTable(objSDialog.FileName, dtResults))
                            {
                                MessageBox.Show("Exported to excel successfully", "Validate RSD", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("No data is available to export", "Validate RSD", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("No data is available to export", "Validate RSD", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
