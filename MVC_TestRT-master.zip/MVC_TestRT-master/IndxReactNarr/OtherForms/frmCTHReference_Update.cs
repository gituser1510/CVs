﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Collections;
using IndxReactNarr.Generic;
using IndxReactNarrDAL;
using IndxReactNarrBll;

namespace IndxReactNarr.OtherForms
{
    public partial class frmCTHReference_Update : Form
    {
        public frmCTHReference_Update()
        {
            InitializeComponent();
        }

        public DataTable NewCTHsData = null;
        public DataTable MasterCTHData = null;
        public DataTable NewTypeCTHs = null;

        private void frmCTHReference_Update_Load(object sender, EventArgs e)
        {
            try
            {
                WindowState = FormWindowState.Maximized;

                if (GlobalVariables.ConceptTextHeadings == null)
                {
                    GlobalVariables.ConceptTextHeadings = OrganicIndexingDB.GetIndexingConceptTextHeadings();
                }

                MasterCTHData = GlobalVariables.ConceptTextHeadings;// 
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                /*-------------- Browsing CTH Excel File ----------------*/

                DialogResult DR = ofdlg.ShowDialog();

                if (DR == DialogResult.OK)
                {
                    String CTH_Excel_Path = ofdlg.FileName;

                    txtFile_Upload.Text = CTH_Excel_Path;

                    String Conn_Str = @" Provider=Microsoft.ACE.OLEDB.12.0; Data Source=" + CTH_Excel_Path + "; Excel 12.0 Xml;HDR=YES";
                    OleDbConnection Con = new OleDbConnection(Conn_Str);
                    String Cmd_Str = "SELECT * FROM [Sheet1$]";
                    OleDbDataAdapter Da = new OleDbDataAdapter(Cmd_Str, Con);
                    DataSet Ds = new DataSet();

                    try
                    {
                        Con.Open();

                        Da.Fill(Ds, "CTH");

                        /* -------- Excel Columns Validation Code --------*/

                        ArrayList Al_Excell_Columns = new ArrayList();

                        Al_Excell_Columns.Add("Sno");
                        Al_Excell_Columns.Add("Name");
                        Al_Excell_Columns.Add("Class");
                        Al_Excell_Columns.Add("Type");
                        Al_Excell_Columns.Add("CategoryType");
                        Al_Excell_Columns.Add("Status");

                        ArrayList Al_Columns = new ArrayList();

                        foreach (DataColumn DC in Ds.Tables[0].Columns)
                        {
                            Al_Columns.Add(DC.ToString());
                        }

                        int Count = 0;

                        foreach (String Item in Al_Excell_Columns)
                        {
                            bool Check = Al_Columns.Contains(Item);

                            if (Check == true)
                            {
                                Count = Count + 1;
                            }
                        }            

                        if (Count < 5)
                        {
                            MessageBox.Show("Mismatch in Columns Names" + "\n Please Upload Excel File With the Same Column Names as in Display");
                        }
                        else
                        {
                            /* -------- ----------- --------*/

                            dgvCTH.AutoGenerateColumns = false;

                            colSno.DataPropertyName = "Sno";
                            colName.DataPropertyName = "Name";
                            colClass.DataPropertyName = "Class";
                            colType.DataPropertyName = "Type";
                            colCategoryType.DataPropertyName = "CategoryType";
                            colStatus.DataPropertyName = "Status";
                                                        
                            NewCTHsData = Ds.Tables[0];

                            /*---------------------- Validating New CTH Names with Master DB -------------------------*/

                            NewTypeCTHs = new DataTable();
                            NewTypeCTHs.Columns.Add("Sno", typeof(Int16));
                            NewTypeCTHs.Columns.Add("Class", typeof(String));
                            NewTypeCTHs.Columns.Add("Name", typeof(String));
                            NewTypeCTHs.Columns.Add("TYPE", typeof(String));
                            NewTypeCTHs.Columns.Add("CategoryType", typeof(String));
                            NewTypeCTHs.Columns.Add("Status", typeof(String));
                            
                            foreach (DataRow Dr in NewCTHsData.Rows)
                            {
                                if (!string.IsNullOrEmpty(Dr["Name"].ToString()))
                                {
                                    NewTypeCTHs.Rows.Add(Dr["Sno"], Dr["Class"], Dr["Name"], Dr["Type"], Dr["CategoryType"], "Check");
                                }
                            }

                            string filterCond = "";
                            foreach (DataRow dr in NewTypeCTHs.Rows)
                            {
                                filterCond = "CTH_Name = '" + dr["Name"].ToString().Trim() + "' and Application ='" + GlobalVariables.ApplicationName + "'";
                                DataRow[] dtArr = MasterCTHData.Select(filterCond);

                                if (dtArr != null && dtArr.Length > 0)//Existing
                                {
                                    dr["Status"] = "Existing";
                                }
                                else//New
                                {
                                    dr["Status"] = "New";
                                }
                            }

                            NewTypeCTHs.AcceptChanges();

                            dgvCTH.DataSource = NewTypeCTHs;

                            /*-------------------- Count of Records/Item in CTH File -------------------*/

                            if (NewTypeCTHs.Rows.Count != 0 && NewTypeCTHs.Rows.Count.ToString() != null)
                            {
                                DataRow[] DtArr_Exist = NewTypeCTHs.Select("Status='Existing'");

                                DataRow[] DtArr_New = NewTypeCTHs.Select("Status='NEW'");

                                int Tot_Count = NewTypeCTHs.Rows.Count;

                                int Exist_Count = DtArr_Exist.Length;

                                int New_Count = DtArr_New.Length;

                                lblTotCount.Text = lblTotCount.Text + Tot_Count;

                                lblExistCount.Text = lblExistCount.Text + Exist_Count;

                                lblNewCount.Text = lblNewCount.Text + New_Count;
                            }
                        }
                    }
                    catch 
                    {
                    
                    }
                    finally
                    {
                        Da.Dispose();
                        Con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvCTH.Rows.Count > 0)
                {                   
                    List<CTH_Properties> lstCTHProps = new List<CTH_Properties>();

                    String Class = string.Empty;
                    String Name = string.Empty;
                    String Type = string.Empty;
                    String Cat_Type = string.Empty;

                    DataView Dv = new DataView(NewTypeCTHs);
                    Dv.RowFilter = "Status='NEW'";
                    DataTable dtNewCTHs = Dv.ToTable();
                                       
                    if (dtNewCTHs != null && dtNewCTHs.Rows.Count > 0)
                    {
                        for (int i = 0; i < dtNewCTHs.Rows.Count; i++)
                        {                            
                            Class = Dv[i]["Class"].ToString();
                            Name = Dv[i]["Name"].ToString();
                            Type = Dv[i]["TYPE"].ToString();
                            Cat_Type = Dv[i]["CategoryType"].ToString();

                            lstCTHProps.Add(new CTH_Properties() { CTH_ID = i + 1, Class = Class, Name = Name, Type = Type, CategoryType = Cat_Type });
                        }

                        if (OrganicIndexingDB.UpdateAndGetIndexingCTHInfo(lstCTHProps, GlobalVariables.ApplicationName))
                        {
                            GlobalVariables.ConceptTextHeadings = OrganicIndexingDB.GetIndexingConceptTextHeadings();
                            MessageBox.Show("New CTHs uploaded sucessfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);

                            /*----- Clearing Data After Submission ------*/

                            dgvCTH.DataSource = null;
                            dgvCTH.Rows.Clear();

                            txtFile_Upload.Text = String.Empty;
                            lblTotCount.Text = String.Empty;
                            lblExistCount.Text = String.Empty;
                            lblNewCount.Text = String.Empty;
                        }
                        else
                        {
                            MessageBox.Show("Error in CTH upload", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }                       
                    }
                }
                else
                {
                    MessageBox.Show("Upload the CTH Excel File");
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        } 
    }
}

