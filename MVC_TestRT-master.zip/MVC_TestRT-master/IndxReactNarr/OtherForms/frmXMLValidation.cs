﻿
#region Import Assemblies

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;
using System.Xml.XPath;
using System.Xml.Linq;
using IndxReactNarr.Generic;
//using System.Windows.Documents;
//using CASRxnTool.Generic;

#endregion

namespace IndxReactNarr
{
    public partial class frmXMLValidation : Form
    {
        #region Constructor

        public frmXMLValidation()
        {
            InitializeComponent();
        }

        #endregion       

        private void frmXMLViewer_Validation_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());                
            }
        }         

        private void btnBrowseXML_Click(object sender, EventArgs e)
        {
            try
            {                
                OpenFile();
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnSchema_Click(object sender, EventArgs e)
        {
            try
            {
                if (true)//IsWellFormedXml
                {
                    ParseXMLFile();
                    //ParseXMLFile_New();
                }
                else
                {
                    MessageBox.Show("Please validate Wellformedness before validating XSD","",MessageBoxButtons.OK,MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void lstErrors_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (lstErrors.SelectedItem != null)
                {
                    string SelItem = null;
                    int linN = 0;
                    int colN = 0;
                    SelItem = lstErrors.SelectedItem.ToString();

                    if (!string.IsNullOrEmpty(SelItem))
                    {

                        linN = Convert.ToInt32(Regex.Replace(SelItem, "([0-9]+): ([0-9]+)(.*)", "$1"));
                        colN = Convert.ToInt32(Regex.Replace(SelItem, "([0-9]+): ([0-9]+)(.*)", "$2"));


                        MatchCollection mc = default(MatchCollection);
                        int i = 0;
                        int totc = 0;

                        mc = Regex.Matches(RichTextBox1.Text, "\\n", RegexOptions.Singleline);

                        try
                        {
                            RichTextBox1.Select(mc[linN - 2].Index + colN, 2);
                            RichTextBox1.SelectionColor = Color.Red;
                            RichTextBox1.Focus();
                        }
                        catch (Exception ex)
                        {
                            RichTextBox1.Focus();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void frmXMLViewer_Validation_Activated(object sender, EventArgs e)
        {
            RichTextBox1.Focus();
        }

        String strError = "";
        IXmlLineInfo lineInf = null;
        string xmlFileName = "";
        bool IsValidXmlFile = false;
        bool Changed = false;
        
        string strTAN = "";
        string strRXNNo = "";

        private void ParseXMLFile()
        {
            try
            {
                if (xmlFileName == null)
                {
                    MessageBox.Show("Please open an XML file for parsing", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                this.Cursor = Cursors.WaitCursor;

                //string strXSDPath = AppDomain.CurrentDomain.BaseDirectory + "findings-1.0.xsd";

                string strXSDPath = AppDomain.CurrentDomain.BaseDirectory + "CAS_React_Schema.xsd";

                if (File.Exists(strXSDPath))
                {
                    RichTextBox1.SaveFile(xmlFileName, RichTextBoxStreamType.PlainText);

                    XmlTextReader xmlTxtReader = new XmlTextReader(xmlFileName);
                    XmlValidatingReader xmlValReader = new XmlValidatingReader(xmlTxtReader);
                    
                    xmlValReader.ValidationType = ValidationType.Schema;
                    xmlValReader.Schemas.Add(null, strXSDPath);
                    strError = "";
                    lstErrors.Items.Clear();

                    xmlValReader.ValidationEventHandler += WriteErrorLog;

                    IsValidXmlFile = true;

                    // StreamWriter sr = new StreamWriter("c:\\TestXMLOUTPUT.txt");
                    string strRSD = "";
                    do
                    {
                        try
                        {
                            //xmlValReader.Read();
                            //if (xmlValReader.NodeType == XmlNodeType.Element)
                            //{
                            //    strRSD = xmlValReader.ReadContentAsString();
                            //}
                            //if (xmlValReader.Name.ToString() == "RSD" && strRSD.Length > 150)
                            //{
                            //    if (strRSD.Contains(";;") || strRSD.EndsWith(";"))
                            //    {
                            //        strError = lineInf.LineNumber.ToString() + ": " + lineInf.LinePosition.ToString() + " " + "Invalid RSD";
                            //        lstErrors.Items.Add(strError);
                            //    }
                            //}
                            if (xmlValReader.Read())
                            {
                                lineInf = (IXmlLineInfo)xmlValReader;
                                if (xmlValReader.Name.ToString() == "TAN")
                                {
                                    strRXNNo = "";
                                    strTAN = "";
                                    xmlValReader.Read();
                                    strTAN = xmlValReader.ReadContentAsString();
                                }
                                else if (xmlValReader.Name.ToString() == "RXN")
                                {
                                    if (xmlValReader.AttributeCount > 0)
                                    {
                                        strRXNNo = xmlValReader.GetAttribute("NO");
                                    }
                                }
                            }
                        }
                        catch (Exception exx)
                        {
                            try
                            {
                                IsValidXmlFile = false;

                                if (lineInf.HasLineInfo())
                                {
                                    strError = lineInf.LineNumber.ToString() + ": " + lineInf.LinePosition.ToString() + " " + exx.Message;
                                }

                                if (exx.Message.IndexOf("EndElement") > 1)
                                {
                                    break;
                                }
                                lstErrors.Items.Add(strError);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Some unexpected error occurred \r\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                break;
                            }
                        }
                    }
                    while (!xmlTxtReader.EOF);

                    xmlValReader.Close();
                    xmlTxtReader.Close();

                    Cursor = Cursors.Default;

                    if (IsValidXmlFile == false)
                    {
                        MessageBox.Show("File is not valid. File contains errors", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        MessageBox.Show("File is validated with XSD successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                }
                else
                {
                    MessageBox.Show("REACT Schema file not found", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void OpenFile()
        {
            try
            {
                openFileDialog1.Filter = "XML Files (*.xml)|*.xml|Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
                openFileDialog1.FilterIndex = 1;
                openFileDialog1.Title = "Select a file to open";
                openFileDialog1.FileName = "";
                openFileDialog1.ShowDialog();

                if (openFileDialog1.FileName != "")
                {

                    xmlFileName = openFileDialog1.FileName;

                    txtXmlFile.Text = xmlFileName.Trim();

                    RichTextBox1.LoadFile(openFileDialog1.FileName, RichTextBoxStreamType.PlainText);
                    this.Text = xmlFileName.Substring(xmlFileName.LastIndexOf("\\") + 1);
                }
                Changed = false;
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
               
        private void WriteErrorLog(object sender, ValidationEventArgs args)
        {
            try
            {
                #region Code Commented
                //XDocument xml = XDocument.Load(xmlFileName, LoadOptions.SetLineInfo);
                //var line = from x in xml.Descendants()
                //           let lineInfo = (IXmlLineInfo)x
                //           where lineInfo.LineNumber == lineInf.LineNumber
                //          select x.Parent.Name.LocalName.ToString();//.Ancestors("DOCUMENT");//.Descendants("TAN").ElementAt(0).Value;   
                #endregion          
                
                IsValidXmlFile = false;

                if (strRXNNo != "" && strTAN != "")
                {
                    strError = lineInf.LineNumber.ToString() + ": " + lineInf.LinePosition.ToString() + " " + args.Message + " RXN -" + strRXNNo + " TAN - " + strTAN + "";
                }
                else if (strRXNNo == "" && strTAN != "")
                {
                    strError = lineInf.LineNumber.ToString() + ": " + lineInf.LinePosition.ToString() + " " + args.Message + " TAN - " + strTAN + "";
                }
                else
                {
                    strError = lineInf.LineNumber.ToString() + ": " + lineInf.LinePosition.ToString() + " " + args.Message;
                }
                
                lstErrors.Items.Add(strError);
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void TabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (TabControl1.SelectedIndex == 1)
                {
                    RichTextBox1.SaveFile(xmlFileName, RichTextBoxStreamType.PlainText);
                    webBrowser1.Navigate(xmlFileName);
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void RichTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Point LocationCombo = new Point();

            //if (e.KeyChar == (char)'<')
            //{
            //    LocationCombo = RichTextBox1.GetPositionFromCharIndex(RichTextBox1.SelectionStart);
            //    LocationCombo.Y = LocationCombo.Y + RichTextBox1.Font.Height + 3;
            //    ComboBox1.Location = LocationCombo;
            //    ComboBox1.Visible = true;
            //    ComboBox1.DroppedDown = true;
            //    ComboBox1.Focus();
            //}
        } 

        bool IsWellFormedXml = false;
        private void btnWellFormNess_Click(object sender, EventArgs e)
        {
            try
            {
                lstErrors.Items.Clear();

                RichTextBox1.SaveFile(xmlFileName, RichTextBoxStreamType.PlainText);

                IsWellFormedXml = true;

                using (FileStream stream = File.OpenRead(AppDomain.CurrentDomain.BaseDirectory + "CAS_React_Schema.xsd"))
                {
                    XmlReaderSettings settings = new XmlReaderSettings();

                    XmlSchema schema = XmlSchema.Read(stream, OnXmlSyntaxError);
                    settings.ValidationType = ValidationType.Schema;
                    settings.Schemas.Add(schema);
                    settings.ValidationEventHandler += OnXmlSyntaxError;

                    string strError = "";
                    using (XmlReader validator = XmlReader.Create(txtXmlFile.Text.Trim(), settings))
                    {
                        try
                        {
                            // Validate the entire xml file
                            while (validator.Read())
                            {
                                lineInf = (IXmlLineInfo)validator;                                
                            }
                        }
                        catch (Exception ex)
                        {
                            if (lineInf.HasLineInfo())
                            {
                                strError = lineInf.LineNumber.ToString() + ": " + lineInf.LinePosition.ToString() + " " + ex.Message;
                            }
                            lstErrors.Items.Add(strError);
                        }
                    }
                }
                if (IsWellFormedXml)
                {
                    MessageBox.Show("Wellformed XML","Wellformed",MessageBoxButtons.OK,MessageBoxIcon.Information);
                }                
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void OnXmlSyntaxError(object sender, ValidationEventArgs args)
        {
            try
            {
                IsWellFormedXml = false;
                strError = lineInf.LineNumber.ToString() + ": " + lineInf.LinePosition.ToString() + " " + args.Message;
                lstErrors.Items.Add(strError);
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void ParseXMLFile_New()
        {
            try
            {
                if (xmlFileName == null)
                {
                    MessageBox.Show("Please open an XML file for parsing", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                this.Cursor = Cursors.WaitCursor;

                string strXSDPath = AppDomain.CurrentDomain.BaseDirectory + "CAS_React_Schema.xsd";

                RichTextBox1.SaveFile(xmlFileName, RichTextBoxStreamType.PlainText);
                //StreamWriter sr = new StreamWriter("c:\\TestXML_Out.txt");
                //============================================================
                using (FileStream stream = File.OpenRead(AppDomain.CurrentDomain.BaseDirectory + "CAS_React_Schema.xsd"))
                {
                    XmlReaderSettings settings = new XmlReaderSettings();

                    XmlSchema schema = XmlSchema.Read(stream, WriteErrorLog);
                    settings.ValidationType = ValidationType.Schema;
                    settings.Schemas.Add(schema);
                    settings.ValidationEventHandler += WriteErrorLog;
                    IsValidXmlFile = true;
                    string strError = "";
                    strError = "";
                    lstErrors.Items.Clear();
                    string strRSD = "";
                    using (XmlReader validator = XmlReader.Create(txtXmlFile.Text.Trim(), settings))
                    {
                        try
                        {
                            // Validate the entire xml file
                            while (validator.Read())
                            {
                               // strRSD = 
                                lineInf = (IXmlLineInfo)validator;
                               // sr.WriteLine(lineInf.LineNumber + " " + validator.Value.ToString());
                                if (validator.Name.ToString() == "TAN")
                                {
                                    strRXNNo = "";
                                    strTAN = "";
                                    validator.Read();
                                    strTAN = validator.ReadContentAsString();
                                }
                                else if (validator.Name.ToString() == "RXN")
                                {
                                    if (validator.AttributeCount > 0)
                                    {
                                        strRXNNo = validator.GetAttribute("NO");
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            IsValidXmlFile = false;
                            if (lineInf.HasLineInfo())
                            {
                                strError = lineInf.LineNumber.ToString() + ": " + lineInf.LinePosition.ToString() + " " + ex.Message;
                            }
                            lstErrors.Items.Add(strError);
                        }
                    }                    
                }
                
                //============================================================
                //XmlTextReader xmlTxtReader = new XmlTextReader(xmlFileName);
                //XmlValidatingReader xmlValReader = new XmlValidatingReader(xmlTxtReader);


                //xmlValReader.ValidationType = ValidationType.Schema;
                //xmlValReader.Schemas.Add(null, strXSDPath);
                //strError = "";
                //lstErrors.Items.Clear();

                //xmlValReader.ValidationEventHandler += WriteErrorLog;

                //IsValidXmlFile = true;

                //StreamWriter sr = new StreamWriter("c:\\TestXMLOUTPUT.txt");

                //do
                //{
                //    try
                //    {
                //        if (xmlValReader.Read())
                //        {
                //            lineInf = (IXmlLineInfo)xmlValReader;
                //            if (lineInf.LineNumber == 2397)
                //            {
                //                // MessageBox.Show("HI Error");
                //            }
                //            sr.WriteLine(lineInf.LineNumber.ToString() + " " + xmlValReader.Value.ToString());
                //            if (xmlValReader.Name.ToString() == "TAN")
                //            {
                //                strRXNNo = "";
                //                strTAN = "";
                //                xmlValReader.Read();
                //                strTAN = xmlValReader.ReadContentAsString();
                //            }
                //            else if (xmlValReader.Name.ToString() == "RXN")
                //            {
                //                if (xmlValReader.AttributeCount > 0)
                //                {
                //                    strRXNNo = xmlValReader.GetAttribute("NO");
                //                }
                //            }
                //        }
                //    }
                //    catch (Exception exx)
                //    {
                //        try
                //        {
                //            IsValidXmlFile = false;

                //            if (lineInf.HasLineInfo())
                //            {
                //                strError = lineInf.LineNumber.ToString() + ": " + lineInf.LinePosition.ToString() + " " + exx.Message;
                //            }

                //            if (exx.Message.IndexOf("EndElement") > 1)
                //            {
                //                break;
                //            }
                //            lstErrors.Items.Add(strError);
                //        }
                //        catch (Exception ex)
                //        {
                //            MessageBox.Show("Some unexpected error occurred \r\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //            break;
                //        }
                //    }
                //}
                //while (!xmlTxtReader.EOF);

                //xmlValReader.Close();
                //xmlTxtReader.Close();

                Cursor = Cursors.Default;

                if (IsValidXmlFile == false)
                {
                    MessageBox.Show("File is not valid. File contains errors", "Invalid XML File", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("File is validated with XSD successfully", "Valid XML File", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void SaveErrorsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (lstErrors.Items.Count > 0)
                {
                    SaveFileDialog objFDialog = new SaveFileDialog();

                    if (objFDialog.ShowDialog() == DialogResult.OK)
                    {
                        StreamWriter SW;
                        SW = new StreamWriter(objFDialog.FileName);

                        for (int i = 0; i < lstErrors.Items.Count; i++)
                        {
                            SW.WriteLine(lstErrors.Items[i].ToString());
                        }
                        SW.Close();
                        SW.Dispose();                
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnSaveErrors_Click(object sender, EventArgs e)
        {
            try
            {
                if (lstErrors.Items.Count > 0)
                {
                    SaveFileDialog objSDialog = new SaveFileDialog();
                    objSDialog.Filter = "TXT|.txt";
                    if (objSDialog.ShowDialog() == DialogResult.OK)
                    {
                        StreamWriter sw = new StreamWriter(objSDialog.FileName);
                        for (int i = 0; i < lstErrors.Items.Count; i++)
                        {
                            sw.WriteLine(lstErrors.Items[i].ToString());
                        }
                        sw.Close();
                        sw.Dispose();
                        MessageBox.Show("Exported xml errors to a file successfully","Export Errors",MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtXmlFile_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblBrowseXml_Click(object sender, EventArgs e)
        {

        }
    }
}
