﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Common;
using System.Xml.Linq;
using IndxReactNarr.Generic;

namespace IndxReactNarr.OtherForms
{
    public partial class frmXmlUnicodesValidation : Form
    {
        public frmXmlUnicodesValidation()
        {
            InitializeComponent();
        }

        public DataSet DsXmlData
        {
            get;
            set;
        }

        private void frmXmlUnicodesValidation_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;
            }
            catch (Exception ex)
            {

                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnBrowseXML_Click(object sender, EventArgs e)
        {
            
                try
            {
                openFileDialog1.Filter = "XML Files (*.xml)|*.xml|Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
                openFileDialog1.FilterIndex = 1;
                openFileDialog1.Title = "Select a file to open";
                openFileDialog1.FileName = "";
                openFileDialog1.ShowDialog();

                if (!string.IsNullOrEmpty(openFileDialog1.FileName))
                {
                    lblXmlStatus.Text = "--";

                    string xmlFileName = openFileDialog1.FileName;
                    txtXmlFile.Text = xmlFileName.Trim();
                    
                    //XElement xEle = XElement.Load(xmlFileName);
                    
                    //Read Batch xml Data to Dataset
                    DataSet dsBXmlData = new DataSet();
                    dsBXmlData.ReadXml(xmlFileName.Trim());
                    DsXmlData = dsBXmlData;

                    if (dsBXmlData != null)
                    {
                        DataTable dtTANComments = GetInvalidTANComments(dsBXmlData.Tables["DOCUMENT"]);
                        BindInvalidCommentsToGrid(dtTANComments);

                        DataTable dtSer8000 = GetInvalidSeries8000Data(dsBXmlData.Tables["SUBNAME"]);
                        BindInvalidSeries8000ToGrid(dtSer8000);

                        DataTable dtRSNData = GetInValidRSNDetails_New(dsBXmlData);
                        BindInvalidRSNDetailsToGrid(dtRSNData);
                    }

                    if (dgvRSN.Rows.Count > 0 || dgvSer8000.Rows.Count > 0 || dgvComments.Rows.Count > 0)
                    {
                        lblXmlStatus.Text = "In-valid Xml file";
                    }
                    else
                    {
                        lblXmlStatus.Text = "Valid Xml file";
                    }
                }               
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }            
        }

        private void BindInvalidCommentsToGrid(DataTable comments)
        {
            try
            {
                dgvComments.AutoGenerateColumns = false;
                dgvComments.DataSource = comments;
                colTAN_Cmnts.DataPropertyName = "TAN";
                colValidStatus_C.DataPropertyName = "STATUS";
                colComments.DataPropertyName = "COMMENTS";
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindInvalidSeries8000ToGrid(DataTable ser8000)
        {
            try
            {
                dgvSer8000.AutoGenerateColumns = false;
                dgvSer8000.DataSource = ser8000;

                colTAN_S8.DataPropertyName = "TAN";
                colSer8000_s8.DataPropertyName = "Ser8000";
                colRxnNum_S8.DataPropertyName = "RxnNUM";
                colRxnSeq_S8.DataPropertyName = "RxnSeq";
                colSubstName_S8.DataPropertyName = "SubstanceName";
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindInvalidRSNDetailsToGrid(DataTable rsnData)
        {
            try
            {
                dgvRSN.AutoGenerateColumns = false;
                dgvRSN.DataSource = rsnData;
                                
                colTAN_R.DataPropertyName = "TAN";                
                colRxnNo.DataPropertyName = "Rxn_NO";
                colRxnSeq.DataPropertyName = "Rxn_Seq";
                colRSN.DataPropertyName = "RSN";
                colRSN_Type.DataPropertyName = "RSN_TYPE";
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public DataTable GetInValidRSNDetails(DataSet xmlData)
        {
            DataTable dtRSNData = null;
            try
            {
                if (xmlData != null)
                {
                    if (xmlData.Tables.Count > 0)
                    {                        
                        if (xmlData.Tables["DOCUMENT"] != null)
                        {
                            dtRSNData = CreateRSNDataTable();

                            string strTAN = "";
                            string strR_Num_Seq = "";
                            string strRXNNo = "";

                            for (int i = 0; i < xmlData.Tables["DOCUMENT"].Rows.Count; i++)
                            {
                                strTAN = xmlData.Tables["DOCUMENT"].Rows[i]["TAN"].ToString();

                                var docQry = (from r in xmlData.Tables["RXNGRP"].AsEnumerable()
                                              where r.Field<Int32>("DOCUMENT_Id") == Convert.ToInt32(xmlData.Tables["DOCUMENT"].Rows[i]["DOCUMENT_Id"].ToString())
                                              select r.Field<Int32>("RXNGRP_ID")).Distinct();

                                foreach (int rxngrpid in docQry)
                                {
                                    var rxnQry = (from r in xmlData.Tables["RXN"].AsEnumerable()
                                                  where r.Field<Int32>("RXNGRP_ID") == rxngrpid
                                                  select r.Field<Int32>("RXN_ID")).Distinct();

                                    foreach (int rxnid in rxnQry)
                                    {
                                        var rxnNo = (from r in xmlData.Tables["RXN"].AsEnumerable()
                                                     where r.Field<Int32>("RXNGRP_ID") == rxngrpid
                                                        && r.Field<Int32>("RXN_ID") == rxnid
                                                     select r.Field<string>("NO"));

                                        strRXNNo = rxnNo.ElementAt(0).ToString();
                                        strR_Num_Seq = GetRXN_NUM_Seq_On_RXNID(rxnid);

                                        //Reaction RSN

                                        var rxnRSNQry = (from r in xmlData.Tables["RXNPROCESS"].AsEnumerable()
                                                         where r.Field<Int32>("RXN_Id") == rxnid
                                                         select r.Field<Int32>("RXNPROCESS_Id")).Distinct();

                                        int StgIndx = 0;
                                        foreach (int rxnprocid in rxnRSNQry)
                                        {
                                            StgIndx = StgIndx + 1;

                                            if (xmlData.Tables["RSN"].Columns.Contains("RXNPROCESS_Id"))
                                            {
                                                DataView dtView = xmlData.Tables["RSN"].DefaultView;
                                                dtView.RowFilter = "RXNPROCESS_Id = " + rxnprocid;
                                                DataTable dtRxnRSN = dtView.ToTable();

                                                if (dtRxnRSN != null)
                                                {
                                                    if (dtRxnRSN.Rows.Count > 0)
                                                    {
                                                        for (int k = 0; k < dtRxnRSN.Rows.Count; k++)
                                                        {
                                                            DataRow dtRow = dtRSNData.NewRow();
                                                            dtRow["TAN"] = strTAN;
                                                            dtRow["RXNNO"] = strRXNNo;
                                                            dtRow["NUM_SEQ"] = strR_Num_Seq;
                                                            dtRow["STAGE"] = "Stage" + StgIndx;
                                                            if (dtRxnRSN.Columns.Contains("RSN_Text"))
                                                            {
                                                                if (Validations.ValidateUnicodeCharactersInString(dtRxnRSN.Rows[k]["RSN_Text"].ToString()))
                                                                {
                                                                    dtRow["RSN_REACTION"] = dtRxnRSN.Rows[k]["RSN_Text"].ToString();
                                                                }
                                                            }
                                                            
                                                            dtRSNData.Rows.Add(dtRow);
                                                        }
                                                    }
                                                }
                                            }

                                            //Stage RSN
                                            var rxnStageQry = (from r in xmlData.Tables["STAGE"].AsEnumerable()
                                                               where r.Field<Int32>("RXNPROCESS_Id") == rxnprocid
                                                               select r.Field<Int32>("STAGE_Id")).Distinct();

                                            int intStgId = 0;
                                            foreach (int stageid in rxnStageQry)
                                            {
                                                intStgId = intStgId + 1;

                                                if (xmlData.Tables["RSN"].Columns.Contains("STAGE_Id"))
                                                {
                                                    DataView dtStageView = xmlData.Tables["RSN"].DefaultView;

                                                    dtStageView.RowFilter = "STAGE_Id = " + stageid;
                                                    DataTable dtStageRSN = dtStageView.ToTable();

                                                    if (dtStageRSN != null)
                                                    {
                                                        if (dtStageRSN.Rows.Count > 0)
                                                        {
                                                            for (int m = 0; m < dtStageRSN.Rows.Count; m++)
                                                            {
                                                                DataRow dtRow = dtRSNData.NewRow();
                                                                dtRow["TAN"] = strTAN;
                                                                dtRow["RXNNO"] = strRXNNo;
                                                                dtRow["NUM_SEQ"] = strR_Num_Seq;
                                                                dtRow["STAGE"] = "Stage" + intStgId;

                                                                if (Validations.ValidateUnicodeCharactersInString(dtStageRSN.Rows[m]["RSN_Text"].ToString()))
                                                                {
                                                                    dtRow["RSN_STAGE"] = dtStageRSN.Rows[m]["RSN_Text"].ToString();
                                                                }
                                                                dtRSNData.Rows.Add(dtRow);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            return dtRSNData;
                        }
                    }
                }               
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtRSNData;
        }

        public DataTable GetInValidRSNDetails_New(DataSet xmlData)
        {
            DataTable dtRSNData = null;
            try
            {
                if (xmlData != null)
                {
                    if (xmlData.Tables.Count > 0)
                    {
                        if (xmlData.Tables["RSN"] != null)
                        {
                            dtRSNData = CreateRSNDataTable();

                            string strTAN = "";
                            string strRxnSeq = "";
                            string strRxnNUM = "";
                            string strRSN = "";
                            string strRSNType = "";

                            for (int i = 0; i < xmlData.Tables["RSN"].Rows.Count; i++)
                            {
                                strRSN = xmlData.Tables["RSN"].Rows[i]["RSN_TEXT"].ToString();
                                strRSNType = xmlData.Tables["RSN"].Rows[i]["TYPE"].ToString();
                               
                                System.Text.RegularExpressions.Regex rg = new System.Text.RegularExpressions.Regex(@"([\p{L}]+)", System.Text.RegularExpressions.RegexOptions.Compiled);
                                System.Text.RegularExpressions.Match mt = rg.Match(strRSN);
                                
                                if (Validations.ValidateUnicodeCharactersInString(strRSN))
                                {
                                    DataRow dRow = dtRSNData.NewRow();
                                    dRow["RSN"] = strRSN;
                                    dRow["RSN_TYPE"] = strRSNType;

                                    //int rxnProcessID = Convert.ToInt32(xmlData.Tables["RSN"].Rows[i]["RXNPROCESS_ID"].ToString());

                                    var rxnProcrows = from row in DsXmlData.Tables["RXNPROCESS"].AsEnumerable()
                                                      where row.Field<Int32>("RXNPROCESS_ID") == Convert.ToInt32(xmlData.Tables["RSN"].Rows[i]["RXNPROCESS_ID"].ToString())
                                                      select new
                                                      {
                                                          rxnID = row.Field<Int32>("RXN_ID")
                                                      };


                                    if (rxnProcrows.Count() > 0)
                                    {
                                        int intRxnID = rxnProcrows.ElementAt(0).rxnID;
                                                                                
                                        //GetRxnNumSeq from RXNID table                          
                                        var rxnRows = from row in DsXmlData.Tables["RXNID"].AsEnumerable()
                                                      where row.Field<Int32>("RXN_ID") == intRxnID
                                                      select new
                                                      {
                                                          rxnNUM = row.Field<string>("RXNNUM"),
                                                          rxnSeq = row.Field<string>("RXNSEQ")
                                                      };
                                        if (rxnRows.Count() > 0)
                                        {
                                            strRxnNUM = rxnRows.ElementAt(0).rxnNUM;
                                            strRxnSeq = rxnRows.ElementAt(0).rxnSeq;
                                        }

                                        //Get RXNGRP_ID from RXNGRP table                                               
                                        var rxnsRows = from row in DsXmlData.Tables["RXN"].AsEnumerable()
                                                       where row.Field<Int32>("RXN_ID") == intRxnID
                                                       select new
                                                       {
                                                           rxnGrpID = row.Field<Int32>("RXNGRP_ID")
                                                       };
                                        if (rxnsRows.Count() > 0)
                                        {
                                            Int32 rxngrpID = rxnsRows.ElementAt(0).rxnGrpID;

                                            //Get Document ID from RXNGRP table
                                            var rxngrpRows = from row in DsXmlData.Tables["RXNGRP"].AsEnumerable()
                                                             where row.Field<Int32>("RXNGRP_ID") == rxngrpID
                                                             select new
                                                             {
                                                                 documentID = row.Field<Int32>("DOCUMENT_ID")
                                                             };
                                            if (rxngrpRows.Count() > 0)
                                            {
                                                Int32 documentID = rxngrpRows.ElementAt(0).documentID;

                                                //Get Document Name from DOCUMENT table
                                                var docRows = from row in DsXmlData.Tables["DOCUMENT"].AsEnumerable()
                                                              where row.Field<Int32>("DOCUMENT_ID") == documentID
                                                              select new
                                                              {
                                                                  tanName = row.Field<string>("TAN")
                                                              };
                                                if (docRows.Count() > 0)
                                                {
                                                    strTAN = docRows.ElementAt(0).tanName;
                                                }
                                            }
                                        }
                                    }

                                    dRow["RXN_NO"] = strRxnNUM;
                                    dRow["RXN_Seq"] = strRxnSeq;
                                    dRow["TAN"] = strTAN;
                                    dtRSNData.Rows.Add(dRow);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtRSNData;
        }

        private static DataTable CreateRSNDataTable()
        {
            try
            {
                DataTable dtRSNData = new DataTable();
                dtRSNData.Columns.Add("TAN", typeof(string));
                dtRSNData.Columns.Add("RXN_NO", typeof(string));
                dtRSNData.Columns.Add("RXN_Seq", typeof(string));               
                dtRSNData.Columns.Add("RSN", typeof(string));
                dtRSNData.Columns.Add("RSN_TYPE", typeof(string));

                return dtRSNData;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return null;
        }

        private string GetRXN_NUM_Seq_On_RXNID(int _rxnid)
        {
            try
            {
                var rxnNumQry = (from r in DsXmlData.Tables["RXNID"].AsEnumerable()
                                 where r.Field<Int32>("RXN_ID") == _rxnid
                                 select r.Field<string>("RXNNUM") + "-" + r.Field<string>("RXNSEQ"));

                return rxnNumQry.ElementAt(0).ToString();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return "";
        }

        private string GetRSN_XMLTAG(string _cvt, string _freetext)
        {
            try
            {
                if (_cvt.Trim() != "" && _freetext.Trim() != "")
                {
                    return "<RSN TYPE=\"" + _freetext.Trim() + "\">" + _cvt.Trim() + "</RSN>";
                }
                else if (_cvt.Trim() == "" && _freetext.Trim() != "")
                {
                    return "<RSN TYPE=" + _freetext.Trim() + "></RSN>";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return "";
        }

        public DataTable GetInvalidTANComments(DataTable tansData)
        {
            DataTable dtTANComments = null;
            try
            {
                if (tansData != null)
                {
                    dtTANComments = new DataTable();
                    dtTANComments.Columns.Add("TAN");                   
                    dtTANComments.Columns.Add("Comments");

                    #region MyRegion
                    //var docs = from doc in xEle.Descendants("DOCUMENT")
                    //           select new
                    //           {
                    //               tan = doc.Element("TAN").Value,
                    //               comments = doc.Element("COMMENTS").Value
                    //           };

                    //foreach (var doc in docs)
                    //{
                    //    DataRow dRow = dtTANComments.NewRow();
                    //    dRow["TAN"] = doc.tan;
                    //    dRow["COMMENTS"] = doc.comments;
                    //    if (Validations.ValidateUnicodeCharactersInString(doc.comments))
                    //    {
                    //        dRow["STATUS"] = "In-Valid";
                    //    }
                    //    else
                    //    {
                    //        dRow["STATUS"] = "Valid";
                    //    }

                    //    dtTANComments.Rows.Add(dRow);
                    //} 
                    #endregion

                    string strTAN = "";
                    string strComments = "";

                    for (int i = 0; i < tansData.Rows.Count; i++)
                    {
                        strTAN = tansData.Rows[i]["TAN"].ToString();
                        strComments = tansData.Rows[i]["COMMENTS"].ToString();
                        if (!string.IsNullOrEmpty(strComments))
                        {
                            if (Validations.ValidateUnicodeCharactersInString(strComments))
                            {
                                DataRow dRow = dtTANComments.NewRow();
                                dRow["TAN"] = strTAN;
                                dRow["COMMENTS"] = strComments;
                                dtTANComments.Rows.Add(dRow);
                            }
                        }
                    }                   
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtTANComments;
        }

        public DataTable GetInvalidSeries8000Data(DataTable ser8000Data)
        {
            DataTable dtSer8000 = null;
            try
            {
                if (ser8000Data != null)
                {
                    dtSer8000 = new DataTable();
                    dtSer8000.Columns.Add("TAN");
                    dtSer8000.Columns.Add("Ser8000");
                    dtSer8000.Columns.Add("RxnNUM");
                    dtSer8000.Columns.Add("RxnSeq");
                    dtSer8000.Columns.Add("SubstanceName");

                    string strTAN = "";
                    string strComments = "";


                    for (int i = 0; i < ser8000Data.Rows.Count; i++)
                    {
                       // strTAN = ser8000Data.Rows[i]["TAN"].ToString();
                        strComments = ser8000Data.Rows[i]["SUBNAME_Text"].ToString();
                        if (!string.IsNullOrEmpty(strComments))
                        {
                            if (Validations.ValidateUnicodeCharactersInString(strComments))
                            {
                                //Get TAN
                                string ser8000 = "";
                                string rxnNUM = "";
                                string rxnSeq = "";
                                strTAN = GetTANOnSUBDEFN_ID(Convert.ToInt32(ser8000Data.Rows[i]["SUBDEFN_ID"]), out ser8000, out rxnNUM, out rxnSeq);
                                //Get Series 8000

                                //Get RxnNum, RxnSeq

                                //Get TAN
                                DataRow dRow = dtSer8000.NewRow();
                                dRow["TAN"] = strTAN;
                                dRow["Ser8000"] = ser8000;
                                dRow["RxnNUM"] = rxnNUM;
                                dRow["RxnSeq"] = rxnSeq;
                                dRow["SubstanceName"] = strComments;
                                dtSer8000.Rows.Add(dRow);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return dtSer8000;
        }

        private string GetTANOnSUBDEFN_ID(int subdefnID, out string ser8000Val, out string rxnNum, out string rxnSeq)
        {
            string strTAN = "";
            string ser8000 = "";
            string strRxnNUM = "";
            string strRxnSeq = "";
            try
            {
                if (subdefnID > 0)
                {
                    var rows = from row in DsXmlData.Tables["SUBDEFN"].AsEnumerable()
                               where row.Field<Int32>("SUBDEFN_Id") == subdefnID
                                select new
                                {
                                    ser8000 = row.Field<string>("NRNNUM"),
                                    subDescID = row.Field<Int32>("SUBDESC_Id")
                                };

                    if (rows.Count() > 0)
                    {
                        ser8000 = rows.ElementAt(0).ser8000.ToString();
                        Int64 subDescId = rows.ElementAt(0).subDescID;

                        //Get SubDescID on SubDefnID
                        var defnRows = from row in DsXmlData.Tables["SUBDESC"].AsEnumerable()
                                       where row.Field<Int32>("SUBDESC_Id") == subDescId
                                       select new
                                       {
                                           rxnID = row.Field<Int32>("RXN_ID")
                                       };

                        if (defnRows.Count() > 0)
                        {
                            Int32 rxnID = defnRows.ElementAt(0).rxnID;

                            //GetRxnNumSeq from RXNID table                          
                            var rxnRows = from row in DsXmlData.Tables["RXNID"].AsEnumerable()
                                          where row.Field<Int32>("RXN_ID") == rxnID
                                           select new
                                           {
                                               rxnNUM = row.Field<string>("RXNNUM"),
                                               rxnSeq = row.Field<string>("RXNSEQ")
                                           };
                            if (rxnRows.Count() > 0)
                            {
                                strRxnNUM = rxnRows.ElementAt(0).rxnNUM;
                                strRxnSeq = rxnRows.ElementAt(0).rxnSeq;
                            }

                            //Get RXNGRP_ID from RXNGRP table                                               
                            var rxnsRows = from row in DsXmlData.Tables["RXN"].AsEnumerable()
                                           where row.Field<Int32>("RXN_ID") == rxnID
                                          select new
                                          {
                                              rxnGrpID = row.Field<Int32>("RXNGRP_ID")
                                          };
                            if (rxnsRows.Count() > 0)
                            {
                                Int32 rxngrpID = rxnsRows.ElementAt(0).rxnGrpID;

                                //Get Document ID from RXNGRP table
                                var rxngrpRows = from row in DsXmlData.Tables["RXNGRP"].AsEnumerable()
                                                 where row.Field<Int32>("RXNGRP_ID") == rxngrpID
                                                 select new
                                                 {
                                                     documentID = row.Field<Int32>("DOCUMENT_ID")
                                                 };
                                if (rxngrpRows.Count() > 0)
                                {
                                    Int32 documentID = rxngrpRows.ElementAt(0).documentID;

                                    //Get Document Name from DOCUMENT table
                                    var docRows = from row in DsXmlData.Tables["DOCUMENT"].AsEnumerable()
                                                  where row.Field<Int32>("DOCUMENT_ID") == documentID
                                                     select new
                                                     {
                                                         tanName = row.Field<string>("TAN")
                                                     };
                                    if (docRows.Count() > 0)
                                    {
                                        strTAN = docRows.ElementAt(0).tanName;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
            rxnNum = strRxnNUM;
            rxnSeq = strRxnSeq;
            ser8000Val = ser8000;
            return strTAN;
        }

        private void dgvSer8000_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvSer8000.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvSer8000.Font);

                if (dgvSer8000.RowHeadersWidth < (int)(size.Width + 20)) dgvSer8000.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvRSN_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvRSN.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvRSN.Font);

                if (dgvRSN.RowHeadersWidth < (int)(size.Width + 20)) dgvRSN.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvComments_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvComments.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvComments.Font);

                if (dgvComments.RowHeadersWidth < (int)(size.Width + 20)) dgvComments.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        
    }
}
