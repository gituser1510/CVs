﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;

namespace IndxReactNarr.OtherForms
{
    public partial class frmCTHReference : Form
    {
        public frmCTHReference()
        {
            InitializeComponent();
        }

        public DataTable CTHMasterData { get; set; }

        private void frmCTHReference_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;

                if (Generic.GlobalVariables.ConceptTextHeadings != null && Generic.GlobalVariables.ConceptTextHeadings.Rows.Count > 0)
                {
                    DataTable dtCTH = Generic.GlobalVariables.ConceptTextHeadings;

                    DataView dvCTH = dtCTH.Copy().DefaultView;
                    dvCTH.RowFilter = "APPLICATION = '" + GlobalVariables.ApplicationName + "'";
                    CTHMasterData = dvCTH.ToTable();

                    BindCTHDataToGrid(CTHMasterData);                 
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void GetFilteredDataBindToGrid()
        {
            try
            {
                string filterCond = "";
                if (!string.IsNullOrEmpty(txtCTHClass.Text.Trim()))
                {
                    filterCond = "CTH_CLASS like '" + txtCTHClass.Text.Trim() + "%'";
                }
                
                if (!string.IsNullOrEmpty(txtCTHName.Text.Trim()))
                {
                    filterCond = "CTH_NAME like '" + txtCTHName.Text.Trim() + "%'";
                }

                if (!string.IsNullOrEmpty(filterCond) && CTHMasterData != null)
                {
                    if (CTHMasterData.Rows.Count > 0)
                    {
                        using (DataView dtView = new DataView(CTHMasterData))
                        {
                            dtView.RowFilter = filterCond;
                            BindCTHDataToGrid(dtView.ToTable());
                        }
                    }
                }
                else
                {
                    dgvCTHReference.DataSource = CTHMasterData;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindCTHDataToGrid(DataTable cthData)
        {
            try
            {
                if (cthData != null)
                {
                    dgvCTHReference.AutoGenerateColumns = false;
                    dgvCTHReference.DataSource = cthData;

                    colCTHClass.DataPropertyName = "CTH_CLASS";
                    colCTHName.DataPropertyName = "CTH_NAME";                  
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvCTHReference_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvCTHReference.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvCTHReference.Font);

                if (dgvCTHReference.RowHeadersWidth < (int)(size.Width + 20)) dgvCTHReference.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtCTHClass_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilteredDataBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtCTHName_TextChanged(object sender, EventArgs e)
        {
            try
            {
                GetFilteredDataBindToGrid();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
    }
}
