﻿namespace IndxReactNarr.OtherForms
{
    partial class frmCTHReference
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.txtCTHName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.txtCTHClass = new System.Windows.Forms.TextBox();
            this.lblClass = new System.Windows.Forms.Label();
            this.dgvCTHReference = new System.Windows.Forms.DataGridView();
            this.colCTHClass = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCTHName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain.SuspendLayout();
            this.pnlTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCTHReference)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.dgvCTHReference);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(939, 455);
            this.pnlMain.TabIndex = 0;
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.txtCTHName);
            this.pnlTop.Controls.Add(this.lblName);
            this.pnlTop.Controls.Add(this.txtCTHClass);
            this.pnlTop.Controls.Add(this.lblClass);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(939, 35);
            this.pnlTop.TabIndex = 1;
            // 
            // txtCTHName
            // 
            this.txtCTHName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCTHName.BackColor = System.Drawing.Color.White;
            this.txtCTHName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCTHName.Location = new System.Drawing.Point(229, 4);
            this.txtCTHName.Name = "txtCTHName";
            this.txtCTHName.Size = new System.Drawing.Size(705, 25);
            this.txtCTHName.TabIndex = 14;
            this.txtCTHName.TextChanged += new System.EventHandler(this.txtCTHName_TextChanged);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(182, 7);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(44, 17);
            this.lblName.TabIndex = 13;
            this.lblName.Text = "Name";
            // 
            // txtCTHClass
            // 
            this.txtCTHClass.BackColor = System.Drawing.Color.White;
            this.txtCTHClass.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCTHClass.Location = new System.Drawing.Point(46, 4);
            this.txtCTHClass.Name = "txtCTHClass";
            this.txtCTHClass.Size = new System.Drawing.Size(125, 25);
            this.txtCTHClass.TabIndex = 10;
            this.txtCTHClass.TextChanged += new System.EventHandler(this.txtCTHClass_TextChanged);
            // 
            // lblClass
            // 
            this.lblClass.AutoSize = true;
            this.lblClass.Location = new System.Drawing.Point(3, 8);
            this.lblClass.Name = "lblClass";
            this.lblClass.Size = new System.Drawing.Size(40, 17);
            this.lblClass.TabIndex = 9;
            this.lblClass.Text = "Class";
            // 
            // dgvCTHReference
            // 
            this.dgvCTHReference.AllowUserToAddRows = false;
            this.dgvCTHReference.AllowUserToDeleteRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvCTHReference.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvCTHReference.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvCTHReference.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCTHReference.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCTHClass,
            this.colCTHName});
            this.dgvCTHReference.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCTHReference.Location = new System.Drawing.Point(0, 35);
            this.dgvCTHReference.Name = "dgvCTHReference";
            this.dgvCTHReference.ReadOnly = true;
            this.dgvCTHReference.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCTHReference.Size = new System.Drawing.Size(939, 420);
            this.dgvCTHReference.TabIndex = 8;
            this.dgvCTHReference.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvCTHReference_RowPostPaint);
            // 
            // colCTHClass
            // 
            this.colCTHClass.HeaderText = "Class";
            this.colCTHClass.Name = "colCTHClass";
            this.colCTHClass.ReadOnly = true;
            // 
            // colCTHName
            // 
            this.colCTHName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colCTHName.HeaderText = "Name";
            this.colCTHName.Name = "colCTHName";
            this.colCTHName.ReadOnly = true;
            // 
            // frmCTHReference
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(939, 455);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmCTHReference";
            this.ShowIcon = false;
            this.Text = "Concept Text Header Reference";
            this.Load += new System.EventHandler(this.frmCTHReference_Load);
            this.pnlMain.ResumeLayout(false);
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCTHReference)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.TextBox txtCTHName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtCTHClass;
        private System.Windows.Forms.Label lblClass;
        private System.Windows.Forms.DataGridView dgvCTHReference;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCTHClass;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCTHName;
    }
}