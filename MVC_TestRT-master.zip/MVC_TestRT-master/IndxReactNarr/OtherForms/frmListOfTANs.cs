﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using System.IO;
using IndxReactNarrDAL;
using IndxReactNarr.Common;
using IndxReactNarr.Curation.Narratives;
using IndxReactNarr.PdfExport;
#endregion

namespace IndxReactNarr
{
    public partial class frmListOfTANs : Form
    {
        #region Public Variables
           
        public DataTable BatchTANs
        {
            get;
            set;
        }

        #endregion

        public frmListOfTANs()
        {
            InitializeComponent();
        }      

        string shipmentName = "";

        #region Form Load

        private void frmListOfTANs_Load(object sender, EventArgs e)
        {
            try
            {       
                this.WindowState = FormWindowState.Maximized;
                txtShipmentName.Focus();

                //Get Shipment Names and Set Autofill
                GetShipmentNamesAndSetToUserNameTxtBox_AutoComplete();

                
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
        
        #endregion       

        private void GetShipmentNamesAndSetToUserNameTxtBox_AutoComplete()
        {
            try
            {
                DataTable dtTanTypes = null;
                DataTable dtShipments = null;
                using (dtShipments = ReactDB.GetShipmentDetailsByAppName(GlobalVariables.ApplicationName, out dtTanTypes))
                {
                    if (dtShipments != null)
                    {
                        if (dtShipments.Rows.Count > 0)
                        {
                            AutoCompleteStringCollection shipmentColl = new AutoCompleteStringCollection();

                            for (int i = 0; i < dtShipments.Rows.Count; i++)
                            {
                                if (dtShipments.Rows[i][0] != null)
                                {
                                    shipmentColl.Add(dtShipments.Rows[i]["SHIPMENT_NAME"].ToString());
                                }
                            }

                            txtShipmentName.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                            txtShipmentName.AutoCompleteSource = AutoCompleteSource.CustomSource;
                            txtShipmentName.AutoCompleteCustomSource = shipmentColl;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public void BindTANsToGrid(DataTable batchTans)
        {
            try
            {
                if (batchTans != null)
                {
                    //Hide Application based columns
                    //colIndexing.Visible = false;
                    colDocClass.Visible = false;
                    colTANPriority.Visible = false;
                    colRxnCount.Visible = false;
                    colIndexing.Visible = false;
                   
                   
                    lblTANCount.Text = batchTans.Rows.Count.ToString();

                    dgvTans.AutoGenerateColumns = false;
                    dgvTans.DataSource = batchTans;

                    colTAN_ID.DataPropertyName = "TAN_ID";
                    colTAN_Name.DataPropertyName = "TAN_NAME";
                                     
                    colIndexing.DataPropertyName = "TAN_NAME";
                    colReact.DataPropertyName = "TAN_NAME";  

                    colBatchNo.DataPropertyName = "BATCH_NO";
                    colRxnCount.DataPropertyName = "REACTION_CNT";
                    colTANPriority.DataPropertyName = "TAN_PRIORITY";
                    colTAN_Type.DataPropertyName = "TAN_TYPE";
                    colTaskStatus.DataPropertyName = "TASK_STATUS";

                    if (GlobalVariables.ApplicationName == Enums.ApplicationName.ORGANIC.ToString() 
                        || GlobalVariables.ApplicationName == Enums.ApplicationName.MACRO.ToString())
                    {
                        colIndexing.Visible = true;
                        colReact.Visible = true;
                        colRxnCount.Visible = true;
                    }
                    else if (GlobalVariables.ApplicationName == Enums.ApplicationName.REACT.ToString())
                    {
                        colReact.Visible = true;
                        colDocClass.Visible = true;
                        colTANPriority.Visible = true;
                        colRxnCount.Visible = true;
                    }
                    else if (GlobalVariables.ApplicationName == Enums.ApplicationName.NARRATIVES.ToString() || GlobalVariables.ApplicationName == Enums.ApplicationName.EXPPROCEDURES.ToString())
                    {
                     colRxnCount.Visible = true;
                    }
                }                             
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
       
        private void MakeGridColumnsReadOnly()
        {
            try
            {
                if (dgvTans.Columns.Count > 0)
                {
                    for (int i = 0; i < dgvTans.Columns.Count; i++)
                    {
                        dgvTans.Columns[i].ReadOnly = true;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }
                
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
       
        private void dgvTans_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                if (e.ColumnIndex < 0 || e.RowIndex < 0)
                {
                    return;
                }

                if (dgvTans.Columns[e.ColumnIndex].HeaderText.ToUpper() == "TAN")
                {
                    int tanID = 0;
                    int.TryParse(dgvTans.Rows[e.RowIndex].Cells[colTAN_ID.Name].Value.ToString(), out tanID);                    
                    if (tanID > 0)
                    {
                        if (GlobalVariables.ApplicationName == Enums.ApplicationName.REACT.ToString() || GlobalVariables.ApplicationName == Enums.ApplicationName.ORGANIC.ToString()
                            || GlobalVariables.ApplicationName == Enums.ApplicationName.MACRO.ToString())
                        {
                            LoadTANInReactionCurationForm(tanID, 0, 0);
                        }
                        else if (GlobalVariables.ApplicationName == Enums.ApplicationName.NARRATIVES.ToString())
                        {
                            LoadTANInNarrativesCurationForm(tanID, 0, 0);
                        }
                        else if (GlobalVariables.ApplicationName == Enums.ApplicationName.EXPPROCEDURES.ToString())
                        {
                            LoadTANInExpProceduresCurationForm(tanID, 0, 0);
                        }
                    }                  
                }
                else if (dgvTans.Columns[e.ColumnIndex].HeaderText.ToUpper() == "INDEXING")  
                {
                    int tanID = 0;
                    int.TryParse(dgvTans.Rows[e.RowIndex].Cells[colTAN_ID.Name].Value.ToString(), out tanID);
                    if (tanID > 0)
                    {
                        if (GlobalVariables.ApplicationName == Enums.ApplicationName.MACRO.ToString())
                        {
                            LoadTANInMacroIndexingCurationForm(tanID, 0, 0);
                        }
                        else if (GlobalVariables.ApplicationName == Enums.ApplicationName.ORGANIC.ToString())
                        {
                            LoadTANInOrganicIndexingCurationForm(tanID, 0, 0);
                        }
                    }
                }
                else if (dgvTans.Columns[e.ColumnIndex].Name == colReport.Name)//View Report
                {
                    frmTANReactionsReport frmReport = null; ;

                    bool frmOpen = false;

                    FormCollection frmColl = Application.OpenForms;
                    foreach (Form objfrm in frmColl)
                    {
                        if (objfrm.Name.ToUpper() == "FRMRXNREPORT")
                        {
                            frmReport = (frmTANReactionsReport)objfrm;
                            frmReport.WindowState = FormWindowState.Maximized;
                            frmReport.TAN_Name = dgvTans.Rows[e.RowIndex].Cells[colTAN_Name.Name].Value.ToString();
                            frmReport.TAN_ID = Convert.ToInt32(dgvTans.Rows[e.RowIndex].Cells[colTAN_ID.Name].Value.ToString());
                            frmReport.LoadTANDetailsReport();
                            frmReport.Show();
                            frmOpen = true;
                            break;
                        }
                    }
                    if (!frmOpen)
                    {
                        frmReport = new frmTANReactionsReport();
                        frmReport.TAN_Name = dgvTans.Rows[e.RowIndex].Cells[colTAN_Name.Name].Value.ToString();
                        frmReport.TAN_ID = Convert.ToInt32(dgvTans.Rows[e.RowIndex].Cells[colTAN_ID.Name].Value.ToString());
                        frmReport.LoadTANDetailsReport();
                        frmReport.MdiParent = MdiParent;
                        frmReport.Show();
                    }                   
                }
                else if (dgvTans.Columns[e.ColumnIndex].Name == colViewPdf.Name)//View PDF
                {
                    Cursor = Cursors.WaitCursor;

                    string strTAN_Pdf = dgvTans.Rows[e.RowIndex].Cells[colTAN_Name.Name].Value.ToString(); 
                    strTAN_Pdf = strTAN_Pdf + ".pdf";
                    string strBatch = txtShipmentName.Text.Trim();
                    strBatch = strBatch.Replace("rxnfile.", "");

                    using (FolderBrowserDialog objFDialog = new FolderBrowserDialog())
                    {
                        if (objFDialog.ShowDialog() == DialogResult.OK)
                        {
                            string strFilePath = objFDialog.SelectedPath;
                            string strPdfPath = strFilePath + "\\" + strTAN_Pdf;
                            if (!File.Exists(strPdfPath))
                            {
                                #region Linux server code commented
                                //string strServerpath = "/root/CASREACT_V2/TAN_Pdfs/" + strBatch.Trim() + "/";
                                //string strError_Out = "";
                                //if (CAS_Classes.DownloadPdf.CallPSCPAndDownLoadFile(strTAN_Pdf, strServerpath, strFilePath, out strError_Out))
                                //{
                                //    System.Diagnostics.Process.Start(strPdfPath);
                                //}
                                //else
                                //{
                                //    MessageBox.Show(strError_Out, "View PDF", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                //} 
                                #endregion

                                //New Windows server code as on 26th March 2013
                                string serverPath = System.Configuration.ConfigurationSettings.AppSettings["FileServerPath"].ToString() + "\\cas_app_files\\IRN";
                                string strFilepath = serverPath + "\\" + GlobalVariables.ApplicationName.ToString() + "\\" + shipmentName + "\\" + strTAN_Pdf;

                                string strError_Out = "";
                                if (Download_UploadPdf.DownloadFileFromWindowsServer(strFilepath, strPdfPath, out strError_Out))
                                {
                                    System.Diagnostics.Process.Start(strPdfPath);
                                }
                                else
                                {
                                    Cursor = Cursors.Default;
                                    MessageBox.Show(strError_Out, GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                            else
                            {
                                System.Diagnostics.Process.Start(strPdfPath);
                            }
                        }
                    }
                }
                else if (dgvTans.Columns[e.ColumnIndex].Name == colGetNUMs.Name)//Get NUMs 
                {
                    Cursor = Cursors.WaitCursor;

                    #region NUM Search form code commented
                    //string strTAN = dgvTans.Rows[e.RowIndex].Cells[colTAN_Name.Name].Value.ToString();
                    //string strBatchName = txtShipmentName.Text.Trim();//dgvTans.Rows[e.RowIndex].Cells["filename"].Value.ToString();
                    //string strCgmPath = AppDomain.CurrentDomain.BaseDirectory + strBatchName + ".cgm";
                    //if (File.Exists(strCgmPath))
                    //{
                    //    FormCollection frmColl = Application.OpenForms;
                    //    frmNUMSearch objNumSrch = null;
                    //    foreach (Form frm in frmColl)
                    //    {
                    //        if (frm.Name.ToUpper() == "FRMNUMSEARCH")
                    //        {
                    //            objNumSrch = (frmNUMSearch)frm;
                    //            objNumSrch.Close();
                    //            break;
                    //        }
                    //    }
                    //    objNumSrch = new frmNUMSearch();
                    //    objNumSrch.TAN = strTAN;
                    //    //objNumSrch.CAN = "";// txtCAN.Text.Trim();
                    //    objNumSrch.BatchName = strBatchName;
                    //    objNumSrch.Show();
                    //}
                    //else
                    //{
                    //    MessageBox.Show(strBatchName + ".cgm file not found in the setup folder", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //}
                    //Cursor = Cursors.Default; 
                    #endregion

                    using (FolderBrowserDialog objFoldBrowse = new FolderBrowserDialog())
                    {
                        if (objFoldBrowse.ShowDialog() == DialogResult.OK)
                        {
                            Cursor = Cursors.WaitCursor;

                            NumsExportToPdf numsExport = new NumsExportToPdf();
                            int tanID = Convert.ToInt32(dgvTans.Rows[e.RowIndex].Cells[colTAN_ID.Name].Value.ToString());
                            numsExport.TanNUMsData = ReactDB.GetNUM_RegNoDetailsOnTANID(tanID);
                            numsExport.TANDetails = ReactDB.GetTANDetailsOnTANID(tanID); ;
                            numsExport.PdfFilePath = objFoldBrowse.SelectedPath + "\\" + dgvTans.Rows[e.RowIndex].Cells[colTAN_Name.Name].Value.ToString() +"_NUMs.pdf";
                            if (numsExport.ExportTanNUMsToPDF())
                            {
                                Cursor = Cursors.Default;
                                System.Diagnostics.Process.Start(numsExport.PdfFilePath);
                            }
                            else
                            {
                                Cursor = Cursors.Default;
                                MessageBox.Show("Error in NUMs export", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }                
            }
            catch (Exception ex)
            {
                Generic.ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void LoadTANInReactionCurationForm(int tanID, int taskID, int taskAllocID)
        {
            try
            {
                frmReactCuration frmEntry = null;
                FormCollection frmColl = Application.OpenForms;
                foreach (Form objfrm in frmColl)
                {
                    if (objfrm.Name.ToUpper() == "FRMRXNENTRYSCREEN")
                    {
                        frmEntry = (frmReactCuration)objfrm;
                        frmEntry.Close();
                        break;
                    }
                }
                frmEntry = new frmReactCuration();
                frmEntry.TAN_ID = tanID;
                frmEntry.Task_ID = taskID;
                frmEntry.TaskAlloc_ID = taskAllocID;
                //frmEntry.TAN_Freezed = Convert.ToBoolean(_dtTanDetails.Rows[0]["tan_freezed"].ToString());
                frmEntry.MdiParent = this.MdiParent;
                frmEntry.Show();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        /// <summary>
        /// Load TAN in Organic Indexing form
        /// </summary>
        /// <param name="tan_id"></param>
        private void LoadTANInOrganicIndexingCurationForm(int tanID, int taskID, int taskAllocID)
        {
            try
            {
                frmOrganicIndexing frmIndexing = null;
                FormCollection frmColl = Application.OpenForms;
                foreach (Form objfrm in frmColl)
                {
                    if (objfrm.Name.ToUpper() == "FRMORGANICINDEXING")
                    {
                        frmIndexing = (frmOrganicIndexing)objfrm;
                        frmIndexing.Close();
                        break;
                    }
                }
                frmIndexing = new frmOrganicIndexing();
                frmIndexing.TAN_ID = tanID;
                frmIndexing.Task_ID = taskID;
                frmIndexing.TaskAlloc_ID = taskAllocID;
                frmIndexing.MdiParent = this.MdiParent;
                frmIndexing.Show();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void LoadTANInMacroIndexingCurationForm(int tanID, int taskID, int taskAllocID)
        {
            try
            {
                frmMacroIndexing frmMIndexing = null;
                FormCollection frmColl = Application.OpenForms;
                foreach (Form objfrm in frmColl)
                {
                    if (objfrm.Name.ToUpper() == "FRMMACROINDEXING")
                    {
                        frmMIndexing = (frmMacroIndexing)objfrm;
                        frmMIndexing.Close();
                        break;
                    }
                }
                frmMIndexing = new frmMacroIndexing();
                frmMIndexing.TAN_ID = tanID;
                frmMIndexing.Task_ID = taskID;
                frmMIndexing.TaskAlloc_ID = taskAllocID;
                frmMIndexing.MdiParent = this.MdiParent;
                frmMIndexing.Show();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        /// <summary>
        /// Load TAN in Narratives form
        /// </summary>
        /// <param name="tan_id"></param>
        private void LoadTANInNarrativesCurationForm(int tanID, int taskID, int taskAllocID)
        {
            try
            {
                frmNarrCuration_New frmNarratives = null;
                FormCollection frmColl = Application.OpenForms;
                foreach (Form objfrm in frmColl)
                {
                    if (objfrm.Name.ToUpper() == "FRMNARRCURATION_NEW")
                    {
                        frmNarratives = (frmNarrCuration_New)objfrm;
                        frmNarratives.Close();
                        break;
                    }
                }
                frmNarratives = new frmNarrCuration_New();
                frmNarratives.TAN_ID = tanID;
                frmNarratives.Task_ID = taskID;
                frmNarratives.TaskAlloc_ID = taskAllocID;
                frmNarratives.MdiParent = this.MdiParent;
                frmNarratives.Show();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void LoadTANInExpProceduresCurationForm(int tanID, int taskID, int taskAllocID)
        {
            try
            {
                frmExpProceduresCuration frmExpProc = null;
                FormCollection frmColl = Application.OpenForms;
                foreach (Form objfrm in frmColl)
                {
                    if (objfrm.Name.ToUpper() == "FRMEXPPROCEDURESCURATION")
                    {
                        frmExpProc = (frmExpProceduresCuration)objfrm;
                        frmExpProc.Close();
                        break;
                    }
                }
                frmExpProc = new frmExpProceduresCuration();
                frmExpProc.TAN_ID = tanID;
                frmExpProc.Task_ID = taskID;
                frmExpProc.TaskAlloc_ID = taskAllocID;
                frmExpProc.MdiParent = this.MdiParent;
                frmExpProc.Show();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnGetList_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;

                if (!string.IsNullOrEmpty(txtShipmentName.Text.Trim()))
                {
                    shipmentName = txtShipmentName.Text.Trim();

                    int intBNo = 0;
                    int.TryParse(txtBNo.Text.Trim(), out intBNo);                    
                    
                    DataTable dtBatchTANS = ShipmentMasterDB.GetTANsForExportOnApp_Shipment(GlobalVariables.ApplicationName, txtShipmentName.Text.Trim(), intBNo);
                    if (dtBatchTANS != null)
                    {
                        BatchTANs = dtBatchTANS;

                        txtTANSrch.Text = "";
                        BindTANsToGrid(dtBatchTANS);
                    }
                }

                Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvTans_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvTans.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvTans.Font);

                if (dgvTans.RowHeadersWidth < (int)(size.Width + 20)) dgvTans.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;

                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void txtTANSrch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (BatchTANs != null)
                {
                    if (!string.IsNullOrEmpty(txtTANSrch.Text.Trim()))
                    {
                        string strFCond = GetFilterCondition(txtTANSrch.Text.Trim());

                        DataTable dtAllTANs = BatchTANs.Copy();
                        DataView dvTemp = dtAllTANs.DefaultView;
                        dvTemp.RowFilter = strFCond;
                        DataTable dtTANs = dvTemp.ToTable();
                        BindTANsToGrid(dtTANs);
                    }
                    else
                    {
                        DataTable dtAllTANs = BatchTANs.Copy();
                        BindTANsToGrid(dtAllTANs);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private string GetFilterCondition(string _query_tan)
        {
            string strFCond = "";
            try
            {
                if (_query_tan.Trim().Contains(";"))
                {
                    string[] splitter = { ";" };
                    string[] strArrTans = _query_tan.Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);

                    if (strArrTans != null)
                    {
                        if (strArrTans.Length > 0)
                        {                           
                            for (int i = 0; i < strArrTans.Length; i++)
                            {
                                if (i == 0)
                                {
                                    strFCond = "TAN_NAME Like '" + strArrTans[i] + "%' ";
                                }
                                else
                                {
                                    strFCond += " OR" + " TAN_NAME Like '" + strArrTans[i] + "%'";
                                }
                            }
                        }
                    }
                }
                else
                {
                    strFCond = "TAN_NAME Like '" + _query_tan.Trim() + "%'";
                }
                return strFCond;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
            return strFCond;
        }

        private void txtBNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == 13)
                {
                    btnGetList_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }        
    }
}
