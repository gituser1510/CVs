﻿namespace IndxReactNarr.OtherForms
{
    partial class frmExtractProcedureCountFromXml
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvProcedureCount = new System.Windows.Forms.DataGridView();
            this.colTAN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colInputRxnsCnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOutputRxnCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colInputProcCnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOutputProcCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colWithProcStepsCnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colWithoutProcStepsCnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colInputXmlError = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOutXmlError = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.lblRxnWithoutProcCnt = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblRxnWithProcCnt = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblInRxnsCount = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblTANCount = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.btnExtract = new System.Windows.Forms.Button();
            this.btnBrowseInputXmls = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtInputFilesPath = new System.Windows.Forms.TextBox();
            this.btnBrowseOutputXmls = new System.Windows.Forms.Button();
            this.lblXmlPath = new System.Windows.Forms.Label();
            this.txtOutputXmlFilesPath = new System.Windows.Forms.TextBox();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblOutRxnsCount = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblInNarProcCount = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblOutNarProcCount = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProcedureCount)).BeginInit();
            this.pnlBottom.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.dgvProcedureCount);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1145, 479);
            this.pnlMain.TabIndex = 0;
            // 
            // dgvProcedureCount
            // 
            this.dgvProcedureCount.AllowUserToAddRows = false;
            this.dgvProcedureCount.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SeaShell;
            this.dgvProcedureCount.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvProcedureCount.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvProcedureCount.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvProcedureCount.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProcedureCount.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTAN,
            this.colInputRxnsCnt,
            this.colOutputRxnCount,
            this.colInputProcCnt,
            this.colOutputProcCount,
            this.colWithProcStepsCnt,
            this.colWithoutProcStepsCnt,
            this.colInputXmlError,
            this.colOutXmlError});
            this.dgvProcedureCount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvProcedureCount.Location = new System.Drawing.Point(0, 68);
            this.dgvProcedureCount.Name = "dgvProcedureCount";
            this.dgvProcedureCount.ReadOnly = true;
            this.dgvProcedureCount.Size = new System.Drawing.Size(1145, 359);
            this.dgvProcedureCount.TabIndex = 1;
            this.dgvProcedureCount.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvProcedureCount_RowPostPaint);
            // 
            // colTAN
            // 
            this.colTAN.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colTAN.HeaderText = "TAN";
            this.colTAN.Name = "colTAN";
            this.colTAN.ReadOnly = true;
            // 
            // colInputRxnsCnt
            // 
            this.colInputRxnsCnt.HeaderText = "In Rxns";
            this.colInputRxnsCnt.Name = "colInputRxnsCnt";
            this.colInputRxnsCnt.ReadOnly = true;
            // 
            // colOutputRxnCount
            // 
            this.colOutputRxnCount.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colOutputRxnCount.HeaderText = "Output Rxns.";
            this.colOutputRxnCount.Name = "colOutputRxnCount";
            this.colOutputRxnCount.ReadOnly = true;
            // 
            // colInputProcCnt
            // 
            this.colInputProcCnt.HeaderText = "In Nar.Procedures";
            this.colInputProcCnt.Name = "colInputProcCnt";
            this.colInputProcCnt.ReadOnly = true;
            // 
            // colOutputProcCount
            // 
            this.colOutputProcCount.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colOutputProcCount.HeaderText = "Out Nar.Procedures";
            this.colOutputProcCount.Name = "colOutputProcCount";
            this.colOutputProcCount.ReadOnly = true;
            this.colOutputProcCount.Width = 200;
            // 
            // colWithProcStepsCnt
            // 
            this.colWithProcStepsCnt.HeaderText = "With Proc.Steps";
            this.colWithProcStepsCnt.Name = "colWithProcStepsCnt";
            this.colWithProcStepsCnt.ReadOnly = true;
            // 
            // colWithoutProcStepsCnt
            // 
            this.colWithoutProcStepsCnt.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colWithoutProcStepsCnt.HeaderText = "Without Proc.Steps";
            this.colWithoutProcStepsCnt.Name = "colWithoutProcStepsCnt";
            this.colWithoutProcStepsCnt.ReadOnly = true;
            this.colWithoutProcStepsCnt.Width = 200;
            // 
            // colInputXmlError
            // 
            this.colInputXmlError.HeaderText = "Input Xml Error";
            this.colInputXmlError.Name = "colInputXmlError";
            this.colInputXmlError.ReadOnly = true;
            // 
            // colOutXmlError
            // 
            this.colOutXmlError.HeaderText = "Output Xml Error";
            this.colOutXmlError.Name = "colOutXmlError";
            this.colOutXmlError.ReadOnly = true;
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom.Controls.Add(this.lblOutNarProcCount);
            this.pnlBottom.Controls.Add(this.label10);
            this.pnlBottom.Controls.Add(this.lblInNarProcCount);
            this.pnlBottom.Controls.Add(this.label8);
            this.pnlBottom.Controls.Add(this.lblOutRxnsCount);
            this.pnlBottom.Controls.Add(this.label7);
            this.pnlBottom.Controls.Add(this.lblRxnWithoutProcCnt);
            this.pnlBottom.Controls.Add(this.label5);
            this.pnlBottom.Controls.Add(this.lblRxnWithProcCnt);
            this.pnlBottom.Controls.Add(this.label4);
            this.pnlBottom.Controls.Add(this.lblInRxnsCount);
            this.pnlBottom.Controls.Add(this.label3);
            this.pnlBottom.Controls.Add(this.lblTANCount);
            this.pnlBottom.Controls.Add(this.label1);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 427);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(1145, 52);
            this.pnlBottom.TabIndex = 2;
            // 
            // lblRxnWithoutProcCnt
            // 
            this.lblRxnWithoutProcCnt.AutoSize = true;
            this.lblRxnWithoutProcCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnWithoutProcCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblRxnWithoutProcCnt.Location = new System.Drawing.Point(800, 28);
            this.lblRxnWithoutProcCnt.Name = "lblRxnWithoutProcCnt";
            this.lblRxnWithoutProcCnt.Size = new System.Drawing.Size(16, 17);
            this.lblRxnWithoutProcCnt.TabIndex = 7;
            this.lblRxnWithoutProcCnt.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(540, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(256, 17);
            this.label5.TabIndex = 6;
            this.label5.Text = "No.of Rxns without Step wise procedures:";
            // 
            // lblRxnWithProcCnt
            // 
            this.lblRxnWithProcCnt.AutoSize = true;
            this.lblRxnWithProcCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRxnWithProcCnt.ForeColor = System.Drawing.Color.Blue;
            this.lblRxnWithProcCnt.Location = new System.Drawing.Point(800, 6);
            this.lblRxnWithProcCnt.Name = "lblRxnWithProcCnt";
            this.lblRxnWithProcCnt.Size = new System.Drawing.Size(16, 17);
            this.lblRxnWithProcCnt.TabIndex = 5;
            this.lblRxnWithProcCnt.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(556, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(240, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "No.of Rxns with Step wise Procedures:";
            // 
            // lblInRxnsCount
            // 
            this.lblInRxnsCount.AutoSize = true;
            this.lblInRxnsCount.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInRxnsCount.ForeColor = System.Drawing.Color.Blue;
            this.lblInRxnsCount.Location = new System.Drawing.Point(208, 6);
            this.lblInRxnsCount.Name = "lblInRxnsCount";
            this.lblInRxnsCount.Size = new System.Drawing.Size(16, 17);
            this.lblInRxnsCount.TabIndex = 3;
            this.lblInRxnsCount.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(150, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "In Rxns:";
            // 
            // lblTANCount
            // 
            this.lblTANCount.AutoSize = true;
            this.lblTANCount.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTANCount.ForeColor = System.Drawing.Color.Blue;
            this.lblTANCount.Location = new System.Drawing.Point(86, 6);
            this.lblTANCount.Name = "lblTANCount";
            this.lblTANCount.Size = new System.Drawing.Size(16, 17);
            this.lblTANCount.TabIndex = 1;
            this.lblTANCount.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "No.of TANs:";
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.btnExtract);
            this.pnlTop.Controls.Add(this.btnBrowseInputXmls);
            this.pnlTop.Controls.Add(this.label2);
            this.pnlTop.Controls.Add(this.txtInputFilesPath);
            this.pnlTop.Controls.Add(this.btnBrowseOutputXmls);
            this.pnlTop.Controls.Add(this.lblXmlPath);
            this.pnlTop.Controls.Add(this.txtOutputXmlFilesPath);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1145, 68);
            this.pnlTop.TabIndex = 0;
            // 
            // btnExtract
            // 
            this.btnExtract.Location = new System.Drawing.Point(1065, 33);
            this.btnExtract.Name = "btnExtract";
            this.btnExtract.Size = new System.Drawing.Size(75, 28);
            this.btnExtract.TabIndex = 6;
            this.btnExtract.Text = "Extract";
            this.btnExtract.UseVisualStyleBackColor = true;
            this.btnExtract.Click += new System.EventHandler(this.btnExtract_Click);
            // 
            // btnBrowseInputXmls
            // 
            this.btnBrowseInputXmls.Location = new System.Drawing.Point(955, 33);
            this.btnBrowseInputXmls.Name = "btnBrowseInputXmls";
            this.btnBrowseInputXmls.Size = new System.Drawing.Size(75, 28);
            this.btnBrowseInputXmls.TabIndex = 5;
            this.btnBrowseInputXmls.Text = "Browse";
            this.btnBrowseInputXmls.UseVisualStyleBackColor = true;
            this.btnBrowseInputXmls.Click += new System.EventHandler(this.btnBrowseInputXmls_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Input xml files path";
            // 
            // txtInputFilesPath
            // 
            this.txtInputFilesPath.BackColor = System.Drawing.Color.White;
            this.txtInputFilesPath.Location = new System.Drawing.Point(135, 34);
            this.txtInputFilesPath.Name = "txtInputFilesPath";
            this.txtInputFilesPath.ReadOnly = true;
            this.txtInputFilesPath.Size = new System.Drawing.Size(814, 25);
            this.txtInputFilesPath.TabIndex = 3;
            // 
            // btnBrowseOutputXmls
            // 
            this.btnBrowseOutputXmls.Location = new System.Drawing.Point(956, 2);
            this.btnBrowseOutputXmls.Name = "btnBrowseOutputXmls";
            this.btnBrowseOutputXmls.Size = new System.Drawing.Size(75, 28);
            this.btnBrowseOutputXmls.TabIndex = 2;
            this.btnBrowseOutputXmls.Text = "Browse";
            this.btnBrowseOutputXmls.UseVisualStyleBackColor = true;
            this.btnBrowseOutputXmls.Click += new System.EventHandler(this.btnBrowseOutputXmls_Click);
            // 
            // lblXmlPath
            // 
            this.lblXmlPath.AutoSize = true;
            this.lblXmlPath.Location = new System.Drawing.Point(4, 8);
            this.lblXmlPath.Name = "lblXmlPath";
            this.lblXmlPath.Size = new System.Drawing.Size(130, 17);
            this.lblXmlPath.TabIndex = 1;
            this.lblXmlPath.Text = "Output xml files path";
            // 
            // txtOutputXmlFilesPath
            // 
            this.txtOutputXmlFilesPath.BackColor = System.Drawing.Color.White;
            this.txtOutputXmlFilesPath.Location = new System.Drawing.Point(135, 4);
            this.txtOutputXmlFilesPath.Name = "txtOutputXmlFilesPath";
            this.txtOutputXmlFilesPath.ReadOnly = true;
            this.txtOutputXmlFilesPath.Size = new System.Drawing.Size(814, 25);
            this.txtOutputXmlFilesPath.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn1.HeaderText = "TAN";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 276;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn2.HeaderText = "Rxns.Count";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 275;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn3.HeaderText = "Procedures Count";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 276;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn4.HeaderText = "WithoutProcedures Count";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 275;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Xml Error";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 502;
            // 
            // lblOutRxnsCount
            // 
            this.lblOutRxnsCount.AutoSize = true;
            this.lblOutRxnsCount.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOutRxnsCount.ForeColor = System.Drawing.Color.Blue;
            this.lblOutRxnsCount.Location = new System.Drawing.Point(208, 29);
            this.lblOutRxnsCount.Name = "lblOutRxnsCount";
            this.lblOutRxnsCount.Size = new System.Drawing.Size(16, 17);
            this.lblOutRxnsCount.TabIndex = 9;
            this.lblOutRxnsCount.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(140, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 17);
            this.label7.TabIndex = 8;
            this.label7.Text = "Out Rxns:";
            // 
            // lblInNarProcCount
            // 
            this.lblInNarProcCount.AutoSize = true;
            this.lblInNarProcCount.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInNarProcCount.ForeColor = System.Drawing.Color.Blue;
            this.lblInNarProcCount.Location = new System.Drawing.Point(434, 6);
            this.lblInNarProcCount.Name = "lblInNarProcCount";
            this.lblInNarProcCount.Size = new System.Drawing.Size(16, 17);
            this.lblInNarProcCount.TabIndex = 11;
            this.lblInNarProcCount.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(304, 6);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(124, 17);
            this.label8.TabIndex = 10;
            this.label8.Text = "In Nar. Procedures:";
            // 
            // lblOutNarProcCount
            // 
            this.lblOutNarProcCount.AutoSize = true;
            this.lblOutNarProcCount.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOutNarProcCount.ForeColor = System.Drawing.Color.Blue;
            this.lblOutNarProcCount.Location = new System.Drawing.Point(434, 29);
            this.lblOutNarProcCount.Name = "lblOutNarProcCount";
            this.lblOutNarProcCount.Size = new System.Drawing.Size(16, 17);
            this.lblOutNarProcCount.TabIndex = 13;
            this.lblOutNarProcCount.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(294, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(134, 17);
            this.label10.TabIndex = 12;
            this.label10.Text = "Out Nar. Procedures:";
            // 
            // frmExtractProcedureCountFromXml
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1145, 479);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmExtractProcedureCountFromXml";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Extract Procedure Count From Xml";
            this.Load += new System.EventHandler(this.frmExtractProcedureCountFromXml_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProcedureCount)).EndInit();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.DataGridView dgvProcedureCount;
        private System.Windows.Forms.Label lblXmlPath;
        private System.Windows.Forms.TextBox txtOutputXmlFilesPath;
        private System.Windows.Forms.Button btnBrowseOutputXmls;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.Label lblRxnWithoutProcCnt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblRxnWithProcCnt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblInRxnsCount;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblTANCount;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtInputFilesPath;
        private System.Windows.Forms.Button btnBrowseInputXmls;
        private System.Windows.Forms.Button btnExtract;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTAN;
        private System.Windows.Forms.DataGridViewTextBoxColumn colInputRxnsCnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOutputRxnCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn colInputProcCnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOutputProcCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn colWithProcStepsCnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn colWithoutProcStepsCnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn colInputXmlError;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOutXmlError;
        private System.Windows.Forms.Label lblOutNarProcCount;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblInNarProcCount;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblOutRxnsCount;
        private System.Windows.Forms.Label label7;
    }
}