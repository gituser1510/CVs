﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;
using IndxReactNarrDAL;
using IndxReactNarrBll;

namespace IndxReactNarr
{
    public partial class frmAddFreeTextDict : Form
    {
        public frmAddFreeTextDict()
        {
            InitializeComponent();
        }
              
        int dtkID = 0;
        
        private void frmAddFreeTextDict_Load(object sender, EventArgs e)
        {
            try
            {
               this.WindowState = FormWindowState.Maximized;
          
               DictionaryTerm dictTerm = new DictionaryTerm();
               dictTerm.DTK_ID = dtkID;
               dictTerm.DTK_Value = "";
               dictTerm.DTK_Type = "FREETEXT";
               dictTerm.Option = "";

               DataTable dtFreeText = null;
               string strStatus = ReactDB.UpdateFreeTextDictionary(dictTerm, out dtFreeText);              
               BindDataToGrid(dtFreeText);
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtFreeText.Text.Trim()))
                {                                      
                    DictionaryTerm dictTerm = new DictionaryTerm();
                    dictTerm.DTK_ID = dtkID;
                    dictTerm.DTK_Value = txtFreeText.Text.Trim();
                    dictTerm.DTK_Type = "FREETEXT";
                    dictTerm.Option = dtkID == 0 ? "INSERT" : "UPDATE";

                    DataTable dtFreeText = null;
                    string strStatus = ReactDB.UpdateFreeTextDictionary(dictTerm, out dtFreeText);
                    if (strStatus.ToUpper() != "DUPLICATE")
                    {
                        BindDataToGrid(dtFreeText);

                        ResetUserInputs();

                        MessageBox.Show("FreeText saved successfully", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Duplicate FreeText term", GlobalVariables.MessageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void BindDataToGrid(DataTable _dtfreetext)
        {
            try
            {
                if (_dtfreetext != null)
                {
                    dgvRSNFree.AutoGenerateColumns = false;
                    dgvRSNFree.DataSource = _dtfreetext;
                    colFreetext.DataPropertyName = "DTK_VALUE";
                    colDTK_ID.DataPropertyName = "DTK_ID";
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void ResetUserInputs()
        {
            try
            {
                txtFreeText.Text = "";
                dtkID = 0;
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                ResetUserInputs();
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvRSNFree_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            try
            {
                string strRowNumber = (e.RowIndex + 1).ToString();

                while (strRowNumber.Length < dgvRSNFree.RowCount.ToString().Length) strRowNumber = "0" + strRowNumber;

                SizeF size = e.Graphics.MeasureString(strRowNumber, dgvRSNFree.Font);

                if (dgvRSNFree.RowHeadersWidth < (int)(size.Width + 20)) dgvRSNFree.RowHeadersWidth = (int)(size.Width + 20);

                Brush b = SystemBrushes.ControlText;
                e.Graphics.DrawString(strRowNumber, this.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2));
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void dgvRSNFree_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dgvRSNFree.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString().ToUpper() == "DELETE")
                {
                    DialogResult diaRes = MessageBox.Show("Do you want to delete?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (diaRes == DialogResult.Yes)
                    {
                        DictionaryTerm dictTerm = new DictionaryTerm();
                        dictTerm.DTK_ID = Convert.ToInt32(dgvRSNFree.Rows[e.RowIndex].Cells["colDTK_ID"].Value.ToString()); 
                        dictTerm.DTK_Value = dgvRSNFree.Rows[e.RowIndex].Cells["colFreeText"].Value.ToString();
                        dictTerm.DTK_Type = "FREETEXT";
                        dictTerm.Option = "DELETE";

                        DataTable dtFreeText = null;
                        string strStatus = ReactDB.UpdateFreeTextDictionary(dictTerm, out dtFreeText);
                        if (strStatus.ToUpper() == "DELETE SUCCESS")
                        {
                            BindDataToGrid(dtFreeText);

                            MessageBox.Show("FreeText deleted successfully", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Error);
                        }
                        else
                        {
                            MessageBox.Show("Error in FreeText delete", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Error);
                        }
                    }
                }
                else if (dgvRSNFree.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString().ToUpper() == "EDIT")
                {
                    DialogResult diaRes = MessageBox.Show("Do you want to edit?", GlobalVariables.MessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (diaRes == DialogResult.Yes)
                    {                        
                        dtkID = Convert.ToInt32(dgvRSNFree.Rows[e.RowIndex].Cells["colDTK_ID"].Value.ToString());
                        txtFreeText.Text = dgvRSNFree.Rows[e.RowIndex].Cells["colFreeText"].Value.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }    
    }
}
