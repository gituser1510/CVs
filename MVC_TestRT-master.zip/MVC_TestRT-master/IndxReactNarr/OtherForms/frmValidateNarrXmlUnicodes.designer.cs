﻿namespace IndxReactNarr
{
    partial class frmCheckUniCodes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblXmlPath = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.pnlBrowse = new System.Windows.Forms.Panel();
            this.splCont = new System.Windows.Forms.SplitContainer();
            this.dgvNotAllowedCodes = new System.Windows.Forms.DataGridView();
            this.lblNotAllowed = new System.Windows.Forms.Label();
            this.dgvAllowedCodes = new System.Windows.Forms.DataGridView();
            this.lblAllowed = new System.Windows.Forms.Label();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlBrowse.SuspendLayout();
            this.splCont.Panel1.SuspendLayout();
            this.splCont.Panel2.SuspendLayout();
            this.splCont.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNotAllowedCodes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAllowedCodes)).BeginInit();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblXmlPath
            // 
            this.lblXmlPath.AutoSize = true;
            this.lblXmlPath.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblXmlPath.Location = new System.Drawing.Point(3, 9);
            this.lblXmlPath.Name = "lblXmlPath";
            this.lblXmlPath.Size = new System.Drawing.Size(139, 17);
            this.lblXmlPath.TabIndex = 5;
            this.lblXmlPath.Text = "Select Xml folder path";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(148, 5);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(711, 25);
            this.textBox1.TabIndex = 4;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowse.Location = new System.Drawing.Point(872, 4);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(51, 27);
            this.btnBrowse.TabIndex = 3;
            this.btnBrowse.Text = "...";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // pnlBrowse
            // 
            this.pnlBrowse.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlBrowse.Controls.Add(this.lblXmlPath);
            this.pnlBrowse.Controls.Add(this.textBox1);
            this.pnlBrowse.Controls.Add(this.btnBrowse);
            this.pnlBrowse.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlBrowse.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlBrowse.Location = new System.Drawing.Point(0, 0);
            this.pnlBrowse.Name = "pnlBrowse";
            this.pnlBrowse.Size = new System.Drawing.Size(1226, 38);
            this.pnlBrowse.TabIndex = 8;
            // 
            // splCont
            // 
            this.splCont.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splCont.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splCont.Location = new System.Drawing.Point(0, 38);
            this.splCont.Name = "splCont";
            this.splCont.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splCont.Panel1
            // 
            this.splCont.Panel1.Controls.Add(this.dgvNotAllowedCodes);
            this.splCont.Panel1.Controls.Add(this.lblNotAllowed);
            // 
            // splCont.Panel2
            // 
            this.splCont.Panel2.Controls.Add(this.dgvAllowedCodes);
            this.splCont.Panel2.Controls.Add(this.lblAllowed);
            this.splCont.Size = new System.Drawing.Size(1226, 565);
            this.splCont.SplitterDistance = 340;
            this.splCont.TabIndex = 9;
            // 
            // dgvNotAllowedCodes
            // 
            this.dgvNotAllowedCodes.AllowUserToAddRows = false;
            this.dgvNotAllowedCodes.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvNotAllowedCodes.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvNotAllowedCodes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvNotAllowedCodes.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvNotAllowedCodes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNotAllowedCodes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvNotAllowedCodes.Location = new System.Drawing.Point(0, 21);
            this.dgvNotAllowedCodes.Name = "dgvNotAllowedCodes";
            this.dgvNotAllowedCodes.ReadOnly = true;
            this.dgvNotAllowedCodes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvNotAllowedCodes.Size = new System.Drawing.Size(1222, 315);
            this.dgvNotAllowedCodes.TabIndex = 8;
            this.dgvNotAllowedCodes.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvNotAllowedCodes_RowPostPaint);
            // 
            // lblNotAllowed
            // 
            this.lblNotAllowed.BackColor = System.Drawing.SystemColors.Info;
            this.lblNotAllowed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNotAllowed.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblNotAllowed.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNotAllowed.ForeColor = System.Drawing.Color.Red;
            this.lblNotAllowed.Location = new System.Drawing.Point(0, 0);
            this.lblNotAllowed.Name = "lblNotAllowed";
            this.lblNotAllowed.Size = new System.Drawing.Size(1222, 21);
            this.lblNotAllowed.TabIndex = 7;
            this.lblNotAllowed.Text = "Not Allowed Characters list";
            // 
            // dgvAllowedCodes
            // 
            this.dgvAllowedCodes.AllowUserToAddRows = false;
            this.dgvAllowedCodes.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvAllowedCodes.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvAllowedCodes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAllowedCodes.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvAllowedCodes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAllowedCodes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAllowedCodes.Location = new System.Drawing.Point(0, 21);
            this.dgvAllowedCodes.Name = "dgvAllowedCodes";
            this.dgvAllowedCodes.ReadOnly = true;
            this.dgvAllowedCodes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAllowedCodes.Size = new System.Drawing.Size(1222, 196);
            this.dgvAllowedCodes.TabIndex = 10;
            this.dgvAllowedCodes.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvAllowedCodes_RowPostPaint);
            // 
            // lblAllowed
            // 
            this.lblAllowed.BackColor = System.Drawing.SystemColors.Info;
            this.lblAllowed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAllowed.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblAllowed.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAllowed.ForeColor = System.Drawing.Color.Green;
            this.lblAllowed.Location = new System.Drawing.Point(0, 0);
            this.lblAllowed.Name = "lblAllowed";
            this.lblAllowed.Size = new System.Drawing.Size(1222, 21);
            this.lblAllowed.TabIndex = 8;
            this.lblAllowed.Text = "Allowed Characters list";
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.splCont);
            this.pnlMain.Controls.Add(this.pnlBrowse);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1226, 603);
            this.pnlMain.TabIndex = 10;
            // 
            // frmCheckUniCodes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1226, 603);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmCheckUniCodes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Narratives - Xml Unicodes Validation tool";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pnlBrowse.ResumeLayout(false);
            this.pnlBrowse.PerformLayout();
            this.splCont.Panel1.ResumeLayout(false);
            this.splCont.Panel2.ResumeLayout(false);
            this.splCont.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNotAllowedCodes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAllowedCodes)).EndInit();
            this.pnlMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblXmlPath;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Panel pnlBrowse;
        private System.Windows.Forms.SplitContainer splCont;
        private System.Windows.Forms.Label lblNotAllowed;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Label lblAllowed;
        private System.Windows.Forms.DataGridView dgvNotAllowedCodes;
        private System.Windows.Forms.DataGridView dgvAllowedCodes;
    }
}

