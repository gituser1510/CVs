﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IndxReactNarr.Generic;

namespace IndxReactNarr
{
    public partial class frmFind_Replace : Form
    {
        public frmFind_Replace()
        {
            InitializeComponent();
        }

        public frmExtractRSN ExtractRSNfrm
        { get; set; }

        //public frmFinalChecks FinalChecksfrm
        //{ get; set; }

        int rowIndx = 0;
        string strFindText = "";
        private void btnFindNext_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtFind.Text.Trim() != "")
                {
                    if (strFindText != txtFind.Text.Trim())
                    {
                        strFindText = txtFind.Text.Trim();
                        rowIndx = 0;
                    }
                    if (ExtractRSNfrm != null)
                    {
                        if (ExtractRSNfrm.dgRSN_DB.Rows.Count > 0)
                        {
                            DataGridViewCell curr_Cell = null;
                         
                            for (int i = rowIndx; i < ExtractRSNfrm.dgRSN_DB.Rows.Count; i++)
                            {
                                curr_Cell = null;
                                if (ExtractRSNfrm.dgRSN_DB.Rows[i].Cells["colFreeText"].Value.ToString().Contains(txtFind.Text.Trim()))
                                {
                                    ExtractRSNfrm.dgRSN_DB.Rows[i].Cells["colFreeText"].Selected = true;
                                    ExtractRSNfrm.dgRSN_DB.CurrentCell = ExtractRSNfrm.dgRSN_DB.Rows[i].Cells["colFreeText"];
                                    curr_Cell = ExtractRSNfrm.dgRSN_DB.CurrentCell;                                  
                                  
                                    rowIndx = i + 1;
                                    break;
                                }
                                rowIndx = i + 1;
                            }
                            if (rowIndx == ExtractRSNfrm.dgRSN_DB.Rows.Count)
                            {
                                MessageBox.Show("Reached end of the table");
                            }
                        }
                    }
                    //else if (FinalChecksfrm != null)
                    //{
                    //    if (FinalChecksfrm.dgvRSN.Rows.Count > 0)
                    //    {
                    //        DataGridViewCell curr_Cell = null;

                    //        for (int i = rowIndx; i < FinalChecksfrm.dgvRSN.Rows.Count; i++)
                    //        {
                    //            curr_Cell = null;
                    //            if (FinalChecksfrm.dgvRSN.Rows[i].Cells["colFreeText"].Value.ToString().Contains(txtFind.Text.Trim()))
                    //            {
                    //                FinalChecksfrm.dgvRSN.Rows[i].Cells["colFreeText"].Selected = true;
                    //                FinalChecksfrm.dgvRSN.CurrentCell = FinalChecksfrm.dgvRSN.Rows[i].Cells["colFreeText"];
                    //                curr_Cell = FinalChecksfrm.dgvRSN.CurrentCell;

                    //                rowIndx = i + 1;
                    //                break;
                    //            }
                    //            rowIndx = i + 1;
                    //        }
                    //        if (rowIndx == FinalChecksfrm.dgvRSN.Rows.Count)
                    //        {
                    //            MessageBox.Show("Reached end of the table");
                    //        }
                    //    }
                    //}
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnReplace_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtFind.Text.Trim() != "" && txtReplace.Text.Trim() != "")
                {
                    if (txtFind.Text.Trim() != txtReplace.Text.Trim())
                    {
                        if (ExtractRSNfrm != null)
                        {
                            if (ExtractRSNfrm.dgRSN_DB.Rows.Count > 0)
                            {
                                if (rowIndx > 0)
                                {
                                    string strCellValue = ExtractRSNfrm.dgRSN_DB.Rows[rowIndx - 1].Cells["colFreeText"].Value.ToString();
                                    strCellValue = strCellValue.Replace(txtFind.Text.Trim(), txtReplace.Text.Trim());
                                    ExtractRSNfrm.dgRSN_DB.Rows[rowIndx - 1].Cells["colFreeText"].Value = strCellValue;
                                }
                            }
                        }
                        //else if (FinalChecksfrm != null)
                        //{
                        //    if (FinalChecksfrm.dgvRSN.Rows.Count > 0)
                        //    {
                        //        if (rowIndx > 0)
                        //        {
                        //            string strCellValue = FinalChecksfrm.dgvRSN.Rows[rowIndx - 1].Cells["colFreeText"].Value.ToString();
                        //            strCellValue = strCellValue.Replace(txtFind.Text.Trim(), txtReplace.Text.Trim());
                        //            FinalChecksfrm.dgvRSN.Rows[rowIndx - 1].Cells["colFreeText"].Value = strCellValue;
                        //        }
                        //    }
                        //}
                    }
                    else
                    {
                        MessageBox.Show("Find and Replace values can't be same","",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnReplaceAll_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtFind.Text.Trim() != "" && txtReplace.Text.Trim() != "")
                {
                    if (txtFind.Text.Trim() != txtReplace.Text.Trim())
                    {
                        if (ExtractRSNfrm != null)
                        {
                            string strCellValue = "";
                            int intCntr = 0;
                            if (ExtractRSNfrm.dgRSN_DB.Rows.Count > 0)
                            {
                                for (int i = 0; i < ExtractRSNfrm.dgRSN_DB.Rows.Count; i++)
                                {
                                    strCellValue = ExtractRSNfrm.dgRSN_DB.Rows[i].Cells["colFreeText"].Value.ToString();
                                    if (strCellValue.Contains(txtFind.Text.Trim()))
                                    {
                                        strCellValue = strCellValue.Replace(txtFind.Text.Trim(), txtReplace.Text.Trim());
                                        ExtractRSNfrm.dgRSN_DB.Rows[i].Cells["colFreeText"].Value = strCellValue;
                                        intCntr = intCntr + 1;
                                    }
                                }
                                if (intCntr > 0)
                                {
                                    MessageBox.Show(intCntr + " occurances replaced");
                                }
                            }
                        }
                        //else if (FinalChecksfrm != null)
                        //{
                        //    string strCellValue = "";
                        //    int intCntr = 0;
                        //    if (FinalChecksfrm.dgvRSN.Rows.Count > 0)
                        //    {
                        //        for (int i = 0; i < FinalChecksfrm.dgvRSN.Rows.Count; i++)
                        //        {
                        //            strCellValue = FinalChecksfrm.dgvRSN.Rows[i].Cells["colFreeText"].Value.ToString();
                        //            if (strCellValue.Contains(txtFind.Text.Trim()))
                        //            {
                        //                strCellValue = strCellValue.Replace(txtFind.Text.Trim(), txtReplace.Text.Trim());
                        //                FinalChecksfrm.dgvRSN.Rows[i].Cells["colFreeText"].Value = strCellValue;
                        //                intCntr = intCntr + 1;
                        //            }
                        //        }
                        //        if (intCntr > 0)
                        //        {
                        //            MessageBox.Show(intCntr + " occurances replaced");
                        //        }
                        //    }
                        //}
                    }
                    else
                    {
                        MessageBox.Show("Find and Replace values can't be same", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }       
    }
}
