﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Mail;
using IndxReactNarr.Generic;
using IndxReactNarrDAL;

namespace IndxReactNarr
{
    public partial class frmUpdatesMail : Form
    {
        public frmUpdatesMail()
        {
            InitializeComponent();
        }

        private void frmUpdatesMail_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = FormWindowState.Maximized;

                DataTable userMailIDs = UserManagementDB.GetApplicationActiveUsers(GlobalVariables.ApplicationName);
                if (userMailIDs != null)
                {
                    var emailids = (from DataRow dr in userMailIDs.Rows
                                    select dr["EMAIL_ID"]).ToArray();

                    string[] saMiailIDs = emailids.Cast<string>().ToArray();
                    string strMailIDs = string.Join(";", saMiailIDs);

                    txtToUsers.Text = strMailIDs;
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        private void btnSendMail_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtToUsers.Text) && !string.IsNullOrEmpty(txtSubject.Text) && !string.IsNullOrEmpty(txtMailBody.Text))
                {     
                    string strSubject = txtSubject.Text.Trim();
                    string strBody = txtMailBody.Text.Trim();

                    string[] splitter = { ";" };
                    string[] saMailIDs = txtToUsers.Text.Trim().Split(splitter, StringSplitOptions.RemoveEmptyEntries);
                    if (saMailIDs != null)
                    {
                        if (saMailIDs.Length > 0)
                        {
                            for (int i = 0; i < saMailIDs.Length; i++)
                            {
                                SendMail(saMailIDs[i].Trim(), strSubject, strBody);
                            }
                        }
                    }                    
                }
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        public void SendMail(string user_mail_id,string mail_subject,string mail_body)
        {
            try
            { 
                SmtpClient client = new SmtpClient("192.168.0.108", 25);                
                MailAddress fromMail = new MailAddress("sairam.punyamantula@gvkbio.com");

                client.DeliveryMethod = SmtpDeliveryMethod.Network;               

                MailAddress toMail = new MailAddress(user_mail_id);                
                MailMessage message = new MailMessage(fromMail, toMail);
                message.Body = mail_body;                
                message.BodyEncoding = System.Text.Encoding.UTF8;
                message.Subject = mail_subject;
                message.SubjectEncoding = System.Text.Encoding.UTF8;

                // Set the method that is called back when the send operation ends.
                client.SendCompleted += new SendCompletedEventHandler(SendCompletedCallback);                
                client.Send(message);        
                message.Dispose();                
            }
            catch (Exception ex)
            {
                ErrorHandling.WriteErrorLog(ex.ToString());
            }
        }

        static bool mailSent = false;
        private static void SendCompletedCallback(object sender, AsyncCompletedEventArgs e)
        {
            // Get the unique identifier for this asynchronous operation.
            String token = (string)e.UserState;
            if (e.Cancelled)
            {
                // Console.WriteLine("[{0}] Send canceled.", token);
            }
            if (e.Error != null)
            {
                // Console.WriteLine("[{0}] {1}", token, e.Error.ToString());
            }
            else
            {
                //MessageBox.Show("Message sent.");
            }
            mailSent = true;
        }      
    }
}
