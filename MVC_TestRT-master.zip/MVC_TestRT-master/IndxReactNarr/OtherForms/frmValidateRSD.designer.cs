﻿namespace IndxReactNarr
{
    partial class frmValidateRSD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvRSD_Stage = new System.Windows.Forms.DataGridView();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.lblStgCnt = new System.Windows.Forms.Label();
            this.lblStage = new System.Windows.Forms.Label();
            this.lblSColonCnt = new System.Windows.Forms.Label();
            this.lblSemicol = new System.Windows.Forms.Label();
            this.lblRSDCnt = new System.Windows.Forms.Label();
            this.lblRSD = new System.Windows.Forms.Label();
            this.lblFormula = new System.Windows.Forms.Label();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.btnBrowseXML = new System.Windows.Forms.Button();
            this.txtXmlFile = new System.Windows.Forms.TextBox();
            this.lblBrowseXml = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btnExport = new System.Windows.Forms.Button();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRSD_Stage)).BeginInit();
            this.pnlBottom.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.dgvRSD_Stage);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Controls.Add(this.pnlTop);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(923, 528);
            this.pnlMain.TabIndex = 0;
            // 
            // dgvRSD_Stage
            // 
            this.dgvRSD_Stage.AllowUserToAddRows = false;
            this.dgvRSD_Stage.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dgvRSD_Stage.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvRSD_Stage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvRSD_Stage.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRSD_Stage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvRSD_Stage.Location = new System.Drawing.Point(0, 34);
            this.dgvRSD_Stage.Name = "dgvRSD_Stage";
            this.dgvRSD_Stage.ReadOnly = true;
            this.dgvRSD_Stage.Size = new System.Drawing.Size(923, 466);
            this.dgvRSD_Stage.TabIndex = 1;
            this.dgvRSD_Stage.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvRSD_Stage_RowPostPaint);
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlBottom.Controls.Add(this.lblStgCnt);
            this.pnlBottom.Controls.Add(this.lblStage);
            this.pnlBottom.Controls.Add(this.lblSColonCnt);
            this.pnlBottom.Controls.Add(this.lblSemicol);
            this.pnlBottom.Controls.Add(this.lblRSDCnt);
            this.pnlBottom.Controls.Add(this.lblRSD);
            this.pnlBottom.Controls.Add(this.lblFormula);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 500);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(923, 28);
            this.pnlBottom.TabIndex = 2;
            // 
            // lblStgCnt
            // 
            this.lblStgCnt.AutoSize = true;
            this.lblStgCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStgCnt.ForeColor = System.Drawing.Color.Red;
            this.lblStgCnt.Location = new System.Drawing.Point(651, 4);
            this.lblStgCnt.Name = "lblStgCnt";
            this.lblStgCnt.Size = new System.Drawing.Size(16, 17);
            this.lblStgCnt.TabIndex = 6;
            this.lblStgCnt.Text = "0";
            // 
            // lblStage
            // 
            this.lblStage.AutoSize = true;
            this.lblStage.ForeColor = System.Drawing.Color.Blue;
            this.lblStage.Location = new System.Drawing.Point(558, 4);
            this.lblStage.Name = "lblStage";
            this.lblStage.Size = new System.Drawing.Size(87, 17);
            this.lblStage.TabIndex = 5;
            this.lblStage.Text = "Stage Count: ";
            // 
            // lblSColonCnt
            // 
            this.lblSColonCnt.AutoSize = true;
            this.lblSColonCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSColonCnt.ForeColor = System.Drawing.Color.Red;
            this.lblSColonCnt.Location = new System.Drawing.Point(477, 4);
            this.lblSColonCnt.Name = "lblSColonCnt";
            this.lblSColonCnt.Size = new System.Drawing.Size(16, 17);
            this.lblSColonCnt.TabIndex = 4;
            this.lblSColonCnt.Text = "0";
            // 
            // lblSemicol
            // 
            this.lblSemicol.AutoSize = true;
            this.lblSemicol.ForeColor = System.Drawing.Color.Blue;
            this.lblSemicol.Location = new System.Drawing.Point(357, 4);
            this.lblSemicol.Name = "lblSemicol";
            this.lblSemicol.Size = new System.Drawing.Size(114, 17);
            this.lblSemicol.TabIndex = 3;
            this.lblSemicol.Text = "Semicolon Count: ";
            // 
            // lblRSDCnt
            // 
            this.lblRSDCnt.AutoSize = true;
            this.lblRSDCnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRSDCnt.ForeColor = System.Drawing.Color.Red;
            this.lblRSDCnt.Location = new System.Drawing.Point(295, 4);
            this.lblRSDCnt.Name = "lblRSDCnt";
            this.lblRSDCnt.Size = new System.Drawing.Size(16, 17);
            this.lblRSDCnt.TabIndex = 2;
            this.lblRSDCnt.Text = "0";
            // 
            // lblRSD
            // 
            this.lblRSD.AutoSize = true;
            this.lblRSD.ForeColor = System.Drawing.Color.Blue;
            this.lblRSD.Location = new System.Drawing.Point(210, 4);
            this.lblRSD.Name = "lblRSD";
            this.lblRSD.Size = new System.Drawing.Size(83, 17);
            this.lblRSD.TabIndex = 1;
            this.lblRSD.Text = "RSD Count: ";
            // 
            // lblFormula
            // 
            this.lblFormula.AutoSize = true;
            this.lblFormula.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFormula.ForeColor = System.Drawing.Color.Blue;
            this.lblFormula.Location = new System.Drawing.Point(2, 4);
            this.lblFormula.Name = "lblFormula";
            this.lblFormula.Size = new System.Drawing.Size(202, 17);
            this.lblFormula.TabIndex = 0;
            this.lblFormula.Text = "Stage = RSD + Semicolon ( ; )";
            // 
            // pnlTop
            // 
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.btnExport);
            this.pnlTop.Controls.Add(this.btnBrowseXML);
            this.pnlTop.Controls.Add(this.txtXmlFile);
            this.pnlTop.Controls.Add(this.lblBrowseXml);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(923, 34);
            this.pnlTop.TabIndex = 0;
            // 
            // btnBrowseXML
            // 
            this.btnBrowseXML.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowseXML.Location = new System.Drawing.Point(781, 3);
            this.btnBrowseXML.Name = "btnBrowseXML";
            this.btnBrowseXML.Size = new System.Drawing.Size(35, 27);
            this.btnBrowseXML.TabIndex = 5;
            this.btnBrowseXML.Text = "...";
            this.btnBrowseXML.UseVisualStyleBackColor = true;
            this.btnBrowseXML.Click += new System.EventHandler(this.btnBrowseXML_Click);
            // 
            // txtXmlFile
            // 
            this.txtXmlFile.BackColor = System.Drawing.Color.White;
            this.txtXmlFile.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtXmlFile.Location = new System.Drawing.Point(98, 4);
            this.txtXmlFile.Name = "txtXmlFile";
            this.txtXmlFile.ReadOnly = true;
            this.txtXmlFile.Size = new System.Drawing.Size(677, 25);
            this.txtXmlFile.TabIndex = 4;
            // 
            // lblBrowseXml
            // 
            this.lblBrowseXml.AutoSize = true;
            this.lblBrowseXml.BackColor = System.Drawing.Color.White;
            this.lblBrowseXml.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBrowseXml.Location = new System.Drawing.Point(3, 8);
            this.lblBrowseXml.Name = "lblBrowseXml";
            this.lblBrowseXml.Size = new System.Drawing.Size(97, 17);
            this.lblBrowseXml.TabIndex = 3;
            this.lblBrowseXml.Text = "Browse XML";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // btnExport
            // 
            this.btnExport.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExport.Location = new System.Drawing.Point(842, 3);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(68, 27);
            this.btnExport.TabIndex = 6;
            this.btnExport.Text = "Export";
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // frmValidateRSD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(923, 528);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmValidateRSD";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Validate RSD";
            this.Load += new System.EventHandler(this.frmValidateRSD_Load);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRSD_Stage)).EndInit();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Button btnBrowseXML;
        private System.Windows.Forms.TextBox txtXmlFile;
        private System.Windows.Forms.Label lblBrowseXml;
        private System.Windows.Forms.DataGridView dgvRSD_Stage;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Label lblFormula;
        private System.Windows.Forms.Label lblRSD;
        private System.Windows.Forms.Label lblStgCnt;
        private System.Windows.Forms.Label lblStage;
        private System.Windows.Forms.Label lblSColonCnt;
        private System.Windows.Forms.Label lblSemicol;
        private System.Windows.Forms.Label lblRSDCnt;
        private System.Windows.Forms.Button btnExport;
    }
}