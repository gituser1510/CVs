﻿namespace IndxReactNarr.OtherForms
{
    partial class frmCTHReference_Update
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSubmit = new System.Windows.Forms.Button();
            this.grpbxUploadFile = new System.Windows.Forms.GroupBox();
            this.lblFile = new System.Windows.Forms.Label();
            this.txtFile_Upload = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.ofdlg = new System.Windows.Forms.OpenFileDialog();
            this.colStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.dgvCTH = new System.Windows.Forms.DataGridView();
            this.colSno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colClass = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCategoryType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.lblNewCount = new System.Windows.Forms.Label();
            this.lblExistCount = new System.Windows.Forms.Label();
            this.lblTotCount = new System.Windows.Forms.Label();
            this.grpbxUploadFile.SuspendLayout();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCTH)).BeginInit();
            this.pnlBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSubmit
            // 
            this.btnSubmit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSubmit.Location = new System.Drawing.Point(1033, 3);
            this.btnSubmit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(78, 32);
            this.btnSubmit.TabIndex = 7;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // grpbxUploadFile
            // 
            this.grpbxUploadFile.BackColor = System.Drawing.Color.White;
            this.grpbxUploadFile.Controls.Add(this.lblFile);
            this.grpbxUploadFile.Controls.Add(this.txtFile_Upload);
            this.grpbxUploadFile.Controls.Add(this.btnBrowse);
            this.grpbxUploadFile.Dock = System.Windows.Forms.DockStyle.Top;
            this.grpbxUploadFile.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.grpbxUploadFile.Location = new System.Drawing.Point(0, 0);
            this.grpbxUploadFile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpbxUploadFile.Name = "grpbxUploadFile";
            this.grpbxUploadFile.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpbxUploadFile.Size = new System.Drawing.Size(1116, 50);
            this.grpbxUploadFile.TabIndex = 7;
            this.grpbxUploadFile.TabStop = false;
            this.grpbxUploadFile.Text = "Upload CTH";
            // 
            // lblFile
            // 
            this.lblFile.AutoSize = true;
            this.lblFile.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblFile.Location = new System.Drawing.Point(46, 24);
            this.lblFile.Name = "lblFile";
            this.lblFile.Size = new System.Drawing.Size(29, 17);
            this.lblFile.TabIndex = 2;
            this.lblFile.Text = "File";
            // 
            // txtFile_Upload
            // 
            this.txtFile_Upload.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFile_Upload.Location = new System.Drawing.Point(78, 19);
            this.txtFile_Upload.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtFile_Upload.Name = "txtFile_Upload";
            this.txtFile_Upload.Size = new System.Drawing.Size(920, 25);
            this.txtFile_Upload.TabIndex = 1;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBrowse.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnBrowse.Location = new System.Drawing.Point(1004, 18);
            this.btnBrowse.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(90, 26);
            this.btnBrowse.TabIndex = 0;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // colStatus
            // 
            this.colStatus.HeaderText = "Status";
            this.colStatus.Name = "colStatus";
            this.colStatus.ReadOnly = true;
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.dgvCTH);
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Controls.Add(this.grpbxUploadFile);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1116, 555);
            this.pnlMain.TabIndex = 2;
            // 
            // dgvCTH
            // 
            this.dgvCTH.AllowUserToAddRows = false;
            this.dgvCTH.AllowUserToDeleteRows = false;
            this.dgvCTH.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvCTH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCTH.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSno,
            this.colName,
            this.colClass,
            this.colType,
            this.colCategoryType,
            this.colStatus});
            this.dgvCTH.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCTH.GridColor = System.Drawing.SystemColors.Control;
            this.dgvCTH.Location = new System.Drawing.Point(0, 50);
            this.dgvCTH.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgvCTH.Name = "dgvCTH";
            this.dgvCTH.ReadOnly = true;
            this.dgvCTH.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCTH.Size = new System.Drawing.Size(1116, 466);
            this.dgvCTH.TabIndex = 4;
            // 
            // colSno
            // 
            this.colSno.HeaderText = "Sno";
            this.colSno.Name = "colSno";
            this.colSno.ReadOnly = true;
            // 
            // colName
            // 
            this.colName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colName.HeaderText = "Name";
            this.colName.Name = "colName";
            this.colName.ReadOnly = true;
            // 
            // colClass
            // 
            this.colClass.HeaderText = "Class";
            this.colClass.Name = "colClass";
            this.colClass.ReadOnly = true;
            // 
            // colType
            // 
            this.colType.HeaderText = "Type";
            this.colType.Name = "colType";
            this.colType.ReadOnly = true;
            // 
            // colCategoryType
            // 
            this.colCategoryType.HeaderText = "CategoryType";
            this.colCategoryType.Name = "colCategoryType";
            this.colCategoryType.ReadOnly = true;
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom.Controls.Add(this.lblNewCount);
            this.pnlBottom.Controls.Add(this.lblExistCount);
            this.pnlBottom.Controls.Add(this.lblTotCount);
            this.pnlBottom.Controls.Add(this.btnSubmit);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 516);
            this.pnlBottom.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(1116, 39);
            this.pnlBottom.TabIndex = 8;
            // 
            // lblNewCount
            // 
            this.lblNewCount.AutoSize = true;
            this.lblNewCount.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewCount.Location = new System.Drawing.Point(426, 10);
            this.lblNewCount.Name = "lblNewCount";
            this.lblNewCount.Size = new System.Drawing.Size(109, 17);
            this.lblNewCount.TabIndex = 10;
            this.lblNewCount.Text = "New Records : ";
            // 
            // lblExistCount
            // 
            this.lblExistCount.AutoSize = true;
            this.lblExistCount.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExistCount.Location = new System.Drawing.Point(218, 10);
            this.lblExistCount.Name = "lblExistCount";
            this.lblExistCount.Size = new System.Drawing.Size(134, 17);
            this.lblExistCount.TabIndex = 9;
            this.lblExistCount.Text = "Existing Records : ";
            // 
            // lblTotCount
            // 
            this.lblTotCount.AutoSize = true;
            this.lblTotCount.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotCount.Location = new System.Drawing.Point(4, 10);
            this.lblTotCount.Name = "lblTotCount";
            this.lblTotCount.Size = new System.Drawing.Size(156, 17);
            this.lblTotCount.TabIndex = 8;
            this.lblTotCount.Text = "Total No. of Records : ";
            // 
            // frmCTHReference_Update
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1116, 555);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmCTHReference_Update";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CTH Excel upload";
            this.Load += new System.EventHandler(this.frmCTHReference_Update_Load);
            this.grpbxUploadFile.ResumeLayout(false);
            this.grpbxUploadFile.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCTH)).EndInit();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.GroupBox grpbxUploadFile;
        private System.Windows.Forms.Label lblFile;
        private System.Windows.Forms.TextBox txtFile_Upload;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.OpenFileDialog ofdlg;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStatus;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.DataGridView dgvCTH;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSno;
        private System.Windows.Forms.DataGridViewTextBoxColumn colName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colClass;
        private System.Windows.Forms.DataGridViewTextBoxColumn colType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCategoryType;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Label lblNewCount;
        private System.Windows.Forms.Label lblExistCount;
        private System.Windows.Forms.Label lblTotCount;

    }
}